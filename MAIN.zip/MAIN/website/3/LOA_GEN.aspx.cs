﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class LOA_GEN : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DataSet ds = new DataSet();
    DataTable dt_obj = new DataTable();
    SqlCommand cmd_Obj = new SqlCommand();
    CreateLogFiles Err = new CreateLogFiles();
    ReportDocument rpt = new ReportDocument();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
            scriptManager.RegisterPostBackControl(this.btnSubmit);
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    bind();
                }
            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //txtLeadno.Enabled = false;
        txtLeadno.Text = "";
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            string ldNum = string.Empty;
            string loanno = string.Empty;
            foreach (GridViewRow grow in gvLOAgen.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    loanno = lnbtn.Text;                   
                }
            }
            
            ldNum = getLeadNo(loanno);
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd_Obj = new SqlCommand("RTS_SP_LOA", con);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.CommandTimeout = 24000000;
            cmd_Obj.Parameters.AddWithValue("@LOAN_NO", loanno);
            cmd_Obj.Parameters.AddWithValue("@LOA_MBY", Session["ID"].ToString());
            cmd_Obj.Parameters.AddWithValue("@PTYPE", "LOAGEN");
            int res = cmd_Obj.ExecuteNonQuery();
            if (res > 0)
            {
                rpt = new ReportDocument();
                rpt.Load(Server.MapPath("Reports/LOA.rpt"));
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                //assign the values to crystal report viewer
                rpt.SetParameterValue(0, loanno);
                //rpt.SetParameterValue(1, ldNum, rpt.Subreports[0].Name.ToString());                    
                rpt.SetParameterValue("@LDNO", ldNum, "PropertyDetailsLegalLOA.rpt");
                //rpt.SetParameterValue(9, Session["EMPNAME"].ToString());
                //rpt.SetParameterValue(10, Session["USR_ID"].ToString());

                rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Letter of Authority For " + txtLeadno.Text + "");
            }
            else
            {
                uscMsgBox1.AddMessage("LOA Generation Failed.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("LOA_GEN.aspx", false);
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = true;
        //SqlConnection con = new SqlConnection(strcon);
        //int ncount = 0;
        //foreach (GridViewRow grow in gvLegalRecvDoc.Rows)
        //{
        //    RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
        //    LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;            
        //    int index = grow.RowIndex;
        //    if (chkStat.Checked)
        //    {
        //        leadno = lnbtn.Text;
        //        appname = gvLegalRecvDoc.Rows[index].Cells[3].Text;
        //        pddt = gvLegalRecvDoc.Rows[index].Cells[4].Text;
        //        lnamt = gvLegalRecvDoc.Rows[index].Cells[5].Text;
        //        //lQuery = gvResolve.Rows[index].Cells[7].Text;
        //        ncount = ncount + 1;
        //        //rcvquery = gvResolve.Rows[index].Cells[6].Text;
        //        Session["Leadno"] = leadno;
        //        getLeadID(con);
        //        BindDocGid(con);
        //    }

        //    if (ncount == 0)
        //    {
        //        Panel2.Visible = false;
        //    }
        //}


        //btnSubmit.Enabled = true;
        //btnCancel.Enabled = true;

        //con.Close();
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        bindGrid();
    }

    protected void bindGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd_Obj = new SqlCommand("RTS_SP_LOA", con);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.CommandTimeout = 24000000;
            cmd_Obj.Parameters.AddWithValue("@LOAN_NO", txtLeadno.Text.Trim());
            cmd_Obj.Parameters.AddWithValue("@BR_ID", ddlBranch.SelectedItem.Text.Trim() != "--Select--" ? ddlBranch.SelectedValue : "");
            cmd_Obj.Parameters.AddWithValue("@PTYPE", "HOLOABIND");
            dt_obj = new DataTable();
            dt_obj.Load(cmd_Obj.ExecuteReader());
            if (dt_obj.Rows.Count > 0)
            {
                gvLOAgen.DataSource = dt_obj;
                gvLOAgen.DataBind();
            }
            else
            {
                uscMsgBox1.AddMessage("No record found", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
    }

    #region LOA
    protected string getLeadNo(string loanNum)
    {
        string ldNo = string.Empty;
        SqlConnection conLoa = new SqlConnection(strcon);
        SqlCommand cmdLoa = new SqlCommand();
        try
        {
            if (conLoa.State == ConnectionState.Broken || conLoa.State == ConnectionState.Closed)
                conLoa.Open();
            cmdLoa = new SqlCommand("RTS_SP_LOA", conLoa);
            cmdLoa.CommandType = CommandType.StoredProcedure;
            cmdLoa.CommandTimeout = 24000000;
            cmdLoa.Parameters.AddWithValue("@LOAN_NO", loanNum);
            cmdLoa.Parameters.AddWithValue("@PTYPE", "GETLDNOLOA");
            ldNo = Convert.ToString(cmdLoa.ExecuteScalar());
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmdLoa.Dispose();
            conLoa.Close();
            GC.Collect();
        }
        return ldNo;
    }
    #endregion
}