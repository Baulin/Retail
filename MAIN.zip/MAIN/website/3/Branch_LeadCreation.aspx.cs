﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;
using DataObjects;
using Resources;
using Utilities.Enums;


// Alter By Manimaran  On Nov 14 2014 .. Mani_Nov_14_01
public partial class Branch_LeadCreation : System.Web.UI.Page
{

    string brcode;
    string leadno;

    string[] arr_type = new string[3];
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DataSet ds3 = new DataSet();
    ClsCommon clscommon = new ClsCommon();
    //////////////////////////////////////// Product Ids OD/TL
    List<int> checkValues = new List<int> { 46, 47, 48 };

    protected void Page_Load(object sender, EventArgs e)
    {
      
            if (!IsPostBack)
            {
                if (Session["ID"] != null)
                {
                DateTime dt = DateTime.Now;
                txtLeaddate.Text = String.Format("{0:dd MMM yyyy}", dt);

                bind();
                bindArea();
                BIndRelation();
                BIndManufacture();
                srcbrnch.Disabled = false;
                srcbrnch1.Disabled = false;
                bindProductCategory();
                }
                else
                {
                    Response.Redirect("Expire.aspx");
                }
            }
      
    }
    public void BIndRelation()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Fetch_MR_RELATION", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            con.Close();
            ddlRelation.DataSource = ds1;
            ddlRelation.DataTextField = "RL_DESC";
            ddlRelation.DataValueField = "RL_ID";
            ddlRelation.DataBind();
            ddlRelation.Items.Insert(0, new ListItem("--Select--", ""));
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void BIndManufacture()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_FETCH_MANUFATURER", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            con.Close();
            ViewState["Manufacture"] = ds1.Tables[0];
            DataTable dt = ds1.Tables[0].DefaultView.ToTable(true, "NAME");
            ddlManufacture.DataSource = dt;
            ddlManufacture.DataTextField = "NAME";
            ddlManufacture.DataValueField = "NAME";
            ddlManufacture.DataBind();
            ddlManufacture.Items.Insert(0, new ListItem("--Select--", ""));
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void bindProductCategory()
    {
        try
        {
            DataSet dsdd = new DataSet();
            dsdd = clscommon.Get_Product_Category();
            ddlCategory.DataSource = dsdd;
            ddlCategory.DataTextField = "PC_NAME";
            ddlCategory.DataValueField = "PC_ID";
            ddlCategory.DataBind();
            ddlCategory.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void bindMainProduct(int mpc_id)
    {
        try
        {
            DataSet dsdd = new DataSet();
            dsdd = clscommon.Bind_Main_Product(mpc_id);
            ddlMainProduct.DataSource = dsdd;
            ddlMainProduct.DataTextField = "MPC_NAME";
            ddlMainProduct.DataValueField = "MPC_ID";
            ddlMainProduct.DataBind();
            ddlMainProduct.Items.Insert(0, new ListItem("--Select--", "0"));

            ddlProduct.Items.Clear();
            ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlScheme.Items.Clear();
            ddlScheme.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void bindMRProduct(int pr_mpc_id)
    {
        try
        {
            DataTable dtProduct = new DataTable();
            dtProduct = clscommon.Bind_MR_Product_By_Main_Product(pr_mpc_id).Tables[0];
            if (Session["BRTYPE"].ToString() == "V" && Session["USR_ACS"].ToString() == "7")
            {
                // dtProduct = dtProduct.Select("PR_CODE  LIKE  '%BL%'").CopyToDataTable();
                dtProduct = dtProduct.Select("PR_ID IN (9,10,11,15,16,22,23,28,31)").CopyToDataTable();
            }
            else if (Session["BRTYPE"].ToString() == "R" && Session["USR_ACS"].ToString() == "7")
            {
                // dtProduct = dtProduct.Select("PR_CODE NOT LIKE  '%BL%'").CopyToDataTable();
                dtProduct = dtProduct.Select("PR_ID NOT IN (9,10,11,15,16,22,23,28,31)").CopyToDataTable();
            }
            ddlProduct.DataSource = dtProduct;
            ddlProduct.DataTextField = "PR_CODE";
            ddlProduct.DataValueField = "PRD";
            ddlProduct.DataBind();
            ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlScheme.Items.Clear();
            ddlScheme.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void bindScheme(int pr_id)
    {
        try
        {
            DataSet dsdd = new DataSet();
            dsdd = clscommon.Bind_MR_Prod_Scheme_By_Product(pr_id);
            ddlScheme.DataSource = dsdd;
            ddlScheme.DataTextField = "MPS_NAME";
            ddlScheme.DataValueField = "MPS_ID";
            ddlScheme.DataBind();
            ddlScheme.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void bind()
    {
        try
        {
            //Altered By Manimaran May 08 2014
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Fetch_MR_EMP_TYPE", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);

            cmd = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da2 = new SqlDataAdapter(cmd);
            DataSet ds2 = new DataSet();
            da2.Fill(ds2);
            con.Close();
            ddlSourcetype.DataSource = ds1;
            ddlSourcetype.DataTextField = "ET_DESC";
            ddlSourcetype.DataValueField = "ET_ID";
            ddlSourcetype.DataBind();
            ddlSourcetype.Items.Insert(0, new ListItem("--Select--", "0"));

            ddlst_fle_hndle_type.DataSource = ds1;
            ddlst_fle_hndle_type.DataTextField = "ET_DESC";
            ddlst_fle_hndle_type.DataValueField = "ET_ID";
            ddlst_fle_hndle_type.DataBind();
            ddlst_fle_hndle_type.Items.Insert(0, new ListItem("--Select--", "0"));

            DataTable dtProduct = ds2.Tables[0];
            if (Session["BRTYPE"].ToString() == "V" && Session["USR_ACS"].ToString() == "7")
            {
                //dtProduct = ds2.Tables[0].Select("PR_CODE  LIKE  '%BL%'").CopyToDataTable();
                dtProduct = ds2.Tables[0].Select("PR_ID IN (9,10,11,15,16,22,23,28,31)").CopyToDataTable();
            }
            else if (Session["BRTYPE"].ToString() == "R" && Session["USR_ACS"].ToString() == "7")
            {
                // dtProduct = ds2.Tables[0].Select("PR_CODE NOT LIKE  '%BL%'").CopyToDataTable();
                dtProduct = ds2.Tables[0].Select("PR_ID NOT IN (9,10,11,15,16,22,23,28,31)").CopyToDataTable();
            }


            ddlProduct.DataSource = dtProduct;
            ddlProduct.DataTextField = "PR_CODE";
            ddlProduct.DataValueField = "PRD";
            ddlProduct.DataBind();
            ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    // Mani_Nov_14_01 
    public void bindArea()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
            cmddd.CommandType = CommandType.StoredProcedure;
            cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
            {
                cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
            }
            else
            {
                cmddd.Parameters.AddWithValue("@InputVal", 0);
            }
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlArea.DataSource = dsdd;
            ddlArea.DataTextField = "AR_NAME";
            ddlArea.DataValueField = "AR_ID";
            ddlArea.DataBind();
            ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlArea.SelectedValue = Session["AREA_ID"].ToString();

            bindBranch();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    // Mani_Nov_14_01 
    public void bindBranch()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

            ddlBranch.DataSource = dsrsn;
            ddlBranch.DataTextField = "BR_NAME";
            ddlBranch.DataValueField = "BR_ID";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
            if (Session["USR_ACS"].ToString() == "7")
            {
                ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
                ddlBranch.Enabled = false;
                ddlArea.Enabled = false;
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        #region TRANSACTION VARIABLES

        bool isSuccess = false;
        bool isChkSuccess = false;
        String leadNoSuffix = String.Empty;

        DataSet dsLeadNo = null;
        DataSet dsLeadInfo = null;

        SqlCommand sqlCmd1 = null;
        SqlCommand sqlCmd2 = null;
        SqlCommand sqlCmd3 = null;
        SqlCommand sqlCmd4 = null;
        SqlConnection sqlConn = null;
        SqlDataAdapter sqlDtAdptr1 = null;
        SqlDataAdapter sqlDtAdptr2 = null;
        SqlTransaction sqlTransaction = null;
                
        #endregion
              

        int cntSrcType = 0;
        cntSrcType = clscommon.Is_Source_Type_Validate(ddlSourcetype.SelectedValue);

        if(!checkValues.Contains(GetProdId(ddlProduct.SelectedItem.Value)) && (String.IsNullOrEmpty(txtUnoLeadNo.Text) || String.IsNullOrWhiteSpace(txtUnoLeadNo.Text)))
        {
            uscMsgBox1.AddMessage("Please select UNO Lead", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
        }
        else if (ddlMember.SelectedValue.ToString() == "Yes" && string.IsNullOrWhiteSpace(txtMemid.Text))
        {

            lblMemberID.Visible = true;
            uscMsgBox1.AddMessage("Please enter the member id", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
        }
        else if(string.IsNullOrWhiteSpace(txtAppname.Text))
        {
            uscMsgBox1.AddMessage("Please enter the applicant name", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
        }
        else if (string.IsNullOrWhiteSpace(txtMobileno.Text))
        {
            uscMsgBox1.AddMessage("Please enter the mobile no", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
        }
        else if (ddlProduct.SelectedItem.Text == "IB-TWL" && (ddlManufacture.SelectedItem.Text == "--Select--" || ddlModel.SelectedItem.Text == "--Select--"))
        {
            reqValMFC.Visible = true;
            reqValModel.Visible = true;
            reqValMFC.Text = "*";
            reqValModel.Text = "*";
        }
        else
            if (ddlSourcetype.SelectedItem.Text == "Liability Branch Lead" && ddlstsourcingbrnch.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please select the sourcing branch.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }
            else
                if (string.IsNullOrWhiteSpace(txtOldAgreementNo.Text) 
                && (Convert.ToInt32(ddlScheme.SelectedValue)==35
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Assessed_Product_Scheme.ATMA_VISHWAS_2020_MLAP_Pre_Topup)
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Assessed_Product_Scheme.ATMA_VISHWAS_2020_GLAP_Pre_Topup)
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Assessed_Product_Scheme.ATMA_VISHWAS_2020_ASL_Pre_Topup)
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Assessed_Product_Scheme.ATMA_VISHWAS_2020_BL_Assessed_Pre_Topup)
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Declared_Product_Scheme.ATMA_VISHWAS_2020_Salaried_LAP_Pre_Topup)
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Declared_Product_Scheme.ATMA_VISHWAS_2020_BL_Declared_Pre_Topup)))
                {
                    uscMsgBox1.AddMessage("Please enter the old agreement no.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
                }
                else
                    //Bala changes 13/03/2018
                   // if (ddlSourcetype.SelectedItem.Text != "Web Based Lead" && ddlRocode.SelectedItem.Text == "--Select--")
                    if (cntSrcType == 0 && ddlRocode.SelectedItem.Text == "--Select--")
                    {
                        uscMsgBox1.AddMessage("Please select the RO/SO Code.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
                    }
                    else if (ddlloginfee.SelectedItem.Text == "--Select--")
                    {
                        uscMsgBox1.AddMessage("Please select Login Fee Applicable.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
                    }
                    else if (ddlloginfee.SelectedValue == "Y" && string.IsNullOrWhiteSpace(txtloginfee.Text))
                    {
                        uscMsgBox1.AddMessage("Please enter the Login Fee .", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
                    }
                    else if (ddlloginfee.SelectedValue == "Y" && ddlinstrument.SelectedItem.Text == "--Select--")
                    {
                        uscMsgBox1.AddMessage("Please select the Nature of Instrument.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
                    }
                    else if (ddlloginfee.SelectedValue == "Y" &&  ddlinstrument.SelectedItem.Text != "--Select--" && string.IsNullOrWhiteSpace(txtinstrument.Text))
                    {
                        uscMsgBox1.AddMessage("Please Enter the Instrument number.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
                    }
                    else if(ddlst_fle_hndle_type.SelectedIndex == 0 && ddlSourcetype.SelectedIndex > 0 && ddlSourcetype.SelectedItem.Text == "Telecaller")
                    {
                        uscMsgBox1.AddMessage("Please select the File Handled By Type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
                    }
                    else if (ddlst_fle_hndle_by.SelectedIndex == 0 && ddlSourcetype.SelectedIndex > 0 && ddlSourcetype.SelectedItem.Text == "Telecaller")
                    {
                        uscMsgBox1.AddMessage("Please select the File Handled By.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
                    }
                    //else if (string.IsNullOrWhiteSpace(txtbx_fle_hndle_by.Text) && ddlSourcetype.SelectedIndex > 0 && ddlSourcetype.SelectedItem.Text == "Telecaller")
                    //{
                    //    uscMsgBox1.AddMessage("Please Enter the File Handled By Name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
                    //}

        else
            {
                lblMemberID.Visible = false;
                reqValMFC.Visible = false;
                reqValModel.Visible = false;

            #region TRANSACTION - LEAD CREATION
            try
                {

                using (sqlConn = new SqlConnection(strcon))
                {

                    sqlConn.Open();

                    //using (sqlTransaction = sqlConn.BeginTransaction(IsolationLevel.ReadCommitted))
                    //{
                        #region UNIQUE LEAD-NUMBER GENERATION

                        dsLeadNo = new DataSet();
                        sqlCmd1 = new SqlCommand(AppConstants.Proc_RTS_SP_CREATE_LEADID, sqlConn);
                        //sqlCmd1.Transaction = sqlTransaction;
                        sqlCmd1.CommandType = CommandType.StoredProcedure;
                        sqlCmd1.Parameters.Add("@BR_NAME", SqlDbType.VarChar).Value = ddlBranch.SelectedItem.Text.Trim();
                        sqlDtAdptr1 = new SqlDataAdapter(sqlCmd1);
                        sqlDtAdptr1.Fill(dsLeadNo);

                        brcode = dsLeadNo.Tables[1].Rows[0]["BR_CODE"].ToString();
                        if (dsLeadNo.Tables[0].Rows.Count > 0)
                        {
                            leadNoSuffix = dsLeadNo.Tables[0].Rows[0]["LD_ID"].ToString();
                        }
                        else
                        {
                            leadNoSuffix = "000001";
                        }

                        string[] PRARR1 = ddlProduct.SelectedIndex > 0 ? ddlProduct.SelectedValue.ToString().Split('-') : null;
                        txtLeadno.Text = PRARR1[1].ToString() + brcode + leadNoSuffix.PadLeft(6, '0');
                        leadno = txtLeadno.Text;

                    #endregion


                    #region CHECK LEAD DUPLICATION
                    if (checkValues.Contains(GetProdId(ddlProduct.SelectedItem.Value)))
                    {
                        isChkSuccess = true;
                        hdnUnoLeadBucketId.Value = "0";
                    }
                    else
                    {
                        UnoLeadDo chkUnoLeadDo = new UnoLeadDo();
                        chkUnoLeadDo.UN_LD_NO = (!String.IsNullOrEmpty(txtUnoLeadNo.Text) && !String.IsNullOrWhiteSpace(txtUnoLeadNo.Text)) ? txtUnoLeadNo.Text : String.Empty;

                        sqlCmd3 = new SqlCommand(AppConstants.Proc_RTS_SP_CHK_LEAD_DUPLICATION, sqlConn);
                        //sqlCmd3.Transaction = sqlTransaction;
                        sqlCmd3.CommandType = CommandType.StoredProcedure;
                        sqlCmd3.Parameters.AddWithValue(AppConstants.Param_UnoLeadNo, (!String.IsNullOrEmpty(txtUnoLeadNo.Text) && !String.IsNullOrWhiteSpace(txtUnoLeadNo.Text)) ? txtUnoLeadNo.Text : String.Empty);
                        SqlParameter chkTransResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                        chkTransResult.Direction = ParameterDirection.Output;
                        sqlCmd3.Parameters.Add(chkTransResult);
                        sqlCmd3.ExecuteScalar();
                        isChkSuccess = (bool)(chkTransResult.Value);
                    }
                        #endregion

                        if (isChkSuccess)
                        {
                            #region INSERT NEW LEAD

                            string sbrid = "";

                            if (ddlProduct.SelectedItem.Text == "IB-G-LAP" || ddlProduct.SelectedItem.Text == "IB-G-HF" || ddlProduct.SelectedItem.Text == "Housing-IB-G-HF")
                            {
                                sbrid = ddlstsourcingbrnch.SelectedItem.Text != "--Select--" ? ddlstsourcingbrnch.SelectedValue.ToString() : "0";
                            }
                            else
                            {
                                sbrid = ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "";
                            }

                            if (ddlSourcetype.SelectedItem.Text == "Liability Branch Lead")
                            {
                                sbrid = ddlstsourcingbrnch.SelectedItem.Text != "--Select--" ? ddlstsourcingbrnch.SelectedValue.ToString() : "0";
                            }

                            sqlCmd2 = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_BRANCH_LEAD, sqlConn);
                            sqlCmd2.Transaction = sqlTransaction;
                            sqlCmd2.CommandType = CommandType.StoredProcedure;
                            sqlCmd2.Parameters.Add("@Brance", SqlDbType.VarChar).Value = ddlBranch.SelectedItem.Text.Trim();
                            sqlCmd2.Parameters.Add("@LD_NO", SqlDbType.VarChar).Value = txtLeadno.Text.Trim();

                            string[] PRARR = ddlProduct.SelectedIndex > 0 ? ddlProduct.SelectedValue.ToString().Split('-') : null;
                            sqlCmd2.Parameters.Add("@LD_PR_ID", SqlDbType.VarChar).Value = PRARR[0].ToString();

                            sqlCmd2.Parameters.Add("@LD_PC_ID", SqlDbType.VarChar).Value = ddlCategory.SelectedValue.ToString();
                            sqlCmd2.Parameters.Add("@LD_MPC_ID", SqlDbType.VarChar).Value = ddlMainProduct.SelectedValue.ToString();
                            sqlCmd2.Parameters.Add("@LD_MPS_ID", SqlDbType.VarChar).Value = ddlScheme.SelectedValue.ToString();
                            sqlCmd2.Parameters.Add("@LD_SBR_ID", SqlDbType.NVarChar).Value = sbrid;
                            sqlCmd2.Parameters.Add("@LD_EMP_TYPE_ID", SqlDbType.NVarChar).Value = ddlSourcetype.SelectedValue.ToString();
                            sqlCmd2.Parameters.Add("@LD_REF_SOURCE", SqlDbType.NVarChar).Value = DDLReferenceSource.SelectedItem.ToString() != null ? DDLReferenceSource.SelectedItem.ToString() : (object)DBNull.Value;
                            sqlCmd2.Parameters.Add("@LD_REF_ID", SqlDbType.NVarChar).Value = TxtReferenceID.Text != null ? TxtReferenceID.Text : (object)DBNull.Value;
                            sqlCmd2.Parameters.Add("@LD_REF_NAME", SqlDbType.NVarChar).Value = TxtReferenceName.Text != null ? TxtReferenceName.Text : (object)DBNull.Value;
                            sqlCmd2.Parameters.Add("@LD_REF_PHNO", SqlDbType.NVarChar).Value = TxtContactNumber.Text != null ? TxtContactNumber.Text : (object)DBNull.Value;
                            sqlCmd2.Parameters.Add("@LD_ISM", SqlDbType.VarChar).Value = ddlMember.SelectedIndex > 0 ? ddlMember.SelectedIndex.ToString() : "";
                            sqlCmd2.Parameters.Add("@LD_MID", SqlDbType.VarChar).Value = txtMemid.Text.Trim();
                            sqlCmd2.Parameters.Add("@LD_APNAME", SqlDbType.VarChar).Value = txtAppname.Text.Trim().ToUpper();
                            sqlCmd2.Parameters.Add("@LD_ACNO", SqlDbType.VarChar).Value = txtMobileno.Text.Trim();
                            sqlCmd2.Parameters.Add("@LD_CBY", SqlDbType.VarChar).Value = Session["ID"] != null ? Session["ID"].ToString() : "";

                            if (ddlst_fle_hndle_type.SelectedIndex > 0)
                            {
                                sqlCmd2.Parameters.Add("@LD_FEMP_TYPE_ID", SqlDbType.NVarChar).Value = ddlst_fle_hndle_type.SelectedValue.ToString();
                                sqlCmd2.Parameters.Add("@FEMP_CODE", SqlDbType.VarChar).Value = Convert.ToString(Session["LD_FEMP_ID"]);
                            }

                            if(ddlSourcetype.SelectedIndex > 0 && ddlSourcetype.SelectedItem.Text == "Telecaller")
                            {
                                sqlCmd2.Parameters.Add("@EMP_CODE", SqlDbType.VarChar).Value = txtEmpCode.Text != null ? txtEmpCode.Text : "0";
                            }
                            else if (cntSrcType > 0)
                            {
                                sqlCmd2.Parameters.Add("@EMP_CODE", SqlDbType.VarChar).Value = Session["EMP_CODE"] != null ? Session["EMP_CODE"].ToString() : "0";
                            }
                            else
                            {
                                sqlCmd2.Parameters.Add("@EMP_CODE", SqlDbType.VarChar).Value = Session["codeid"] != null ? Session["codeid"].ToString() : "0";
                            }

                            sqlCmd2.Parameters.Add("@REF_ADDRESS", SqlDbType.VarChar).Value = txtRefAddress.Text;
                            sqlCmd2.Parameters.Add("@REF_LOAN_CYCLE", SqlDbType.VarChar).Value = dddlLoanCycle.SelectedIndex > 0 ? dddlLoanCycle.SelectedItem.Text : "";
                            sqlCmd2.Parameters.Add("@REF_REL", SqlDbType.VarChar).Value = ddlRelation.SelectedIndex > 0 ? ddlRelation.SelectedValue : (object)DBNull.Value;
                            sqlCmd2.Parameters.Add("@REF_CENT_LEAD", SqlDbType.VarChar).Value = txtCntrLeadName.Text;
                            sqlCmd2.Parameters.Add("@MANUFACTURE", SqlDbType.VarChar).Value = ddlManufacture.SelectedItem.Text.ToUpper() != "--SELECT--" ? ddlManufacture.SelectedItem.Text : "";
                            sqlCmd2.Parameters.Add("@MODEL", SqlDbType.VarChar).Value = ddlModel.SelectedItem.Text.ToUpper() != "--SELECT--" ? ddlModel.SelectedItem.Text : "";
                            sqlCmd2.Parameters.Add("@MRPRATE", SqlDbType.Decimal).Value = txtMRP.Text != "" ? Convert.ToDecimal(txtMRP.Text) : 0;
                            sqlCmd2.Parameters.Add("@LD_OLD_LOAN_NO", SqlDbType.NVarChar).Value = txtOldAgreementNo.Text != null ? txtOldAgreementNo.Text : (object)DBNull.Value;
                            sqlCmd2.Parameters.Add("@LD_LGNFE_APLCBL", SqlDbType.VarChar).Value = ddlloginfee.SelectedValue != "--Select--" ? ddlloginfee.SelectedValue : "";
                            sqlCmd2.Parameters.Add("@LD_LGN_FEE", SqlDbType.Decimal).Value = txtloginfee.Text != "" ? Convert.ToDouble(txtloginfee.Text) : 0;
                            sqlCmd2.Parameters.Add("@LD_OLD_LD_NO", SqlDbType.NVarChar).Value = txtoldleadno.Text != "" ? txtoldleadno.Text : (object)DBNull.Value;
                            sqlCmd2.Parameters.Add("@LD_INSTMNT", SqlDbType.NVarChar).Value = ddlinstrument.SelectedItem.Text != "--Select--" ? ddlinstrument.SelectedItem.Text : (object)DBNull.Value;
                            sqlCmd2.Parameters.Add("@LD_INSTMNT_NO", SqlDbType.NVarChar).Value = txtinstrument.Text != "" ? txtinstrument.Text : (object)DBNull.Value;
                            sqlCmd2.Parameters.Add(AppConstants.Param_UnoLeadNo, SqlDbType.NVarChar).Value = (!String.IsNullOrEmpty(txtUnoLeadNo.Text) && !String.IsNullOrWhiteSpace(txtUnoLeadNo.Text)) ? txtUnoLeadNo.Text : (object)DBNull.Value;
                            sqlCmd2.Parameters.Add(AppConstants.Param_UnoLeadBucketId, SqlDbType.Int).Value = ((Convert.ToInt64(hdnUnoLeadBucketId.Value) != 0) ? Convert.ToInt64(hdnUnoLeadBucketId.Value) : 0);

                            sqlDtAdptr2 = new SqlDataAdapter(sqlCmd2);
                            dsLeadInfo = new DataSet();
                            sqlDtAdptr2.Fill(dsLeadInfo);

                        #endregion

                        #region MARK UNO LEAD AS COMPLETE
                            if (checkValues.Contains(GetProdId(ddlProduct.SelectedItem.Value)))
                            {
                                isSuccess = true;                                
                            }
                            else
                            { 
                                UnoLeadDo unoLeadDo = new UnoLeadDo();
                                unoLeadDo.UN_LD_BUK_ID = (Convert.ToInt64(hdnUnoLeadBucketId.Value) != 0 ? Convert.ToInt64(hdnUnoLeadBucketId.Value) : 0);
                                unoLeadDo.UN_LD_NO = (!String.IsNullOrEmpty(txtUnoLeadNo.Text) && !String.IsNullOrWhiteSpace(txtUnoLeadNo.Text)) ? txtUnoLeadNo.Text : String.Empty;
                                unoLeadDo.UN_RTS_MBY = Convert.ToInt64(Session[AppConstants.ID]);
                                unoLeadDo.UserId = Convert.ToInt64(Session[AppConstants.ID]);

                                sqlCmd4 = new SqlCommand(AppConstants.Proc_RTS_SP_COMPLETE_UNO_LEAD, sqlConn);
                                sqlCmd4.Transaction = sqlTransaction;
                                sqlCmd4.CommandType = CommandType.StoredProcedure;
                                sqlCmd4.Parameters.AddWithValue(AppConstants.Param_UnoLeadBucketId, unoLeadDo.UN_LD_BUK_ID);
                                sqlCmd4.Parameters.AddWithValue(AppConstants.Param_UnoLeadNo, unoLeadDo.UN_LD_NO);
                                sqlCmd4.Parameters.AddWithValue(AppConstants.Param_UserId, unoLeadDo.UN_RTS_MBY);

                                SqlParameter transResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                                transResult.Direction = ParameterDirection.Output;
                                sqlCmd4.Parameters.Add(transResult);
                                sqlCmd4.ExecuteScalar();
                                isSuccess = (bool)(transResult.Value);
                            }
                        #endregion

                        #region TOP-UP LOAN VALIDATION

                        if (Convert.ToInt32(ddlScheme.SelectedValue) == 27 || Convert.ToInt32(ddlScheme.SelectedValue) == 28 || Convert.ToInt32(ddlScheme.SelectedValue) == 29)
                            {
                                SqlCommand sqlCmd5 = new SqlCommand("RTS_SP_BIND_BT_LEAD_DETAILS", sqlConn);
                                //sqlCmd5.Transaction = sqlTransaction;
                                sqlCmd5.CommandType = CommandType.StoredProcedure;
                                sqlCmd5.Parameters.AddWithValue("@TUP_LD_ID", leadno);
                                sqlCmd5.Parameters.AddWithValue("@TUP_BT_LD_NO", txtBTLoanNumber.Text);
                                sqlCmd5.Parameters.AddWithValue("@TUP_AREA", txtBTArea.Text);
                                sqlCmd5.Parameters.AddWithValue("@TUP_BRANCH", txtBTBranch.Text);
                                sqlCmd5.Parameters.AddWithValue("@TUP_CUST_NAME", txtBtCustomerName.Text);
                                sqlCmd5.Parameters.AddWithValue("@TUP_APRV_AMT", txtBTAprvAmt.Text);
                                //cmd1.Parameters.AddWithValue("@TUP_APRV_AMT", txtBTAprvAmt.Text);
                                if (Convert.ToInt32(ddlScheme.SelectedValue) == 27)
                                {
                                    // dtd = DateTime.ParseExact(txtBTAprvDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                                    //cmd1.Parameters.AddWithValue("@TUP_APRV_DATE", dtd);
                                }

                                sqlCmd5.Parameters.AddWithValue("@TUP_PR_NAME", txtBTProduct.Text);
                                sqlCmd5.Parameters.AddWithValue("@SCHEME_ID", ddlScheme.SelectedValue);
                                sqlCmd5.Parameters.AddWithValue("@ID", Session["ID"] != null ? Session["ID"].ToString() : "0");
                                sqlCmd5.Parameters.AddWithValue("@LD_NO", txtTopLeadNo.Text != "" ? txtTopLeadNo.Text : "");
                                sqlCmd5.Parameters.AddWithValue("@PTYPE", "INSERT");
                                sqlCmd5.ExecuteNonQuery();
                            }

                            #endregion

                            //if (isSuccess) { sqlTransaction.Commit(); }
                            //else { sqlTransaction.Rollback(); }
                        }
                    //}
                }

                    if (checkValues.Contains(GetProdId(ddlProduct.SelectedValue.ToString())))
                    {
                        txtAppname.Enabled = false;
                        txtMobileno.Enabled = false;
                        ddlloginfee.Enabled = false;
                        txtloginfee.Enabled = false;
                    }
                    ClearLeadDataPostSubmit();
                    if (isSuccess && dsLeadInfo.Tables[0].Rows.Count > 0)
                    {                       

                        uscMsgBox1.AddMessage("Lead No." + leadno + " is Created Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else
                    {
                        uscMsgBox1.AddMessage(ErrorMessages.MSG_CREATE_LEAD_FAIL, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                }
                catch (Exception ex)
                {
                    //if (sqlTransaction != null) { sqlTransaction.Rollback(); sqlTransaction.Dispose(); }
                    ErrorLog.WriteError(ex);
                }
                finally
                {
                    if (sqlConn != null && (sqlConn.State == ConnectionState.Open || sqlConn.State == ConnectionState.Broken)) { sqlConn.Close(); }
                    //if (sqlTransaction != null) { sqlTransaction.Dispose(); }
                }
            #endregion TRANSACTION - LEAD CREATION
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_LeadCreation.aspx");
    }
    protected void ddlSourcetype_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlSourcetype.SelectedItem.Text != "--Select--")
            {
                // if (!ddlProduct.SelectedItem.Text.StartsWith("G"))
                if (ddlProduct.SelectedItem.Text != "IB-G-LAP" && ddlProduct.SelectedItem.Text != "IB-G-HF"&&  ddlProduct.SelectedItem.Text != "Housing-IB-G-HF")
                {
                    ddlRocode.Enabled = true;
                    SqlConnection con = new SqlConnection(strcon);
                    con.Open();

                    SqlCommand cmd = new SqlCommand("RTS_SP_Fetch_Sourcetype_Values", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@EMP_BR_ID", SqlDbType.VarChar).Value = ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "";
                    cmd.Parameters.Add("@ET_DESC", SqlDbType.VarChar).Value = ddlSourcetype.SelectedItem.Text.ToString();

                    SqlDataAdapter showdata = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    showdata.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        con.Close();
                        ddlRocode.DataSource = ds;
                        ddlRocode.DataTextField = "EMPNAME";
                        ddlRocode.DataValueField = "VAL";
                        ddlRocode.DataBind();
                        ddlRocode.Items.Insert(0, new ListItem("--Select--", "0"));
                    }
                    else
                    {
                        ddlRocode.Items.Clear();
                        ddlRocode.Items.Insert(0, new ListItem("--Select--", "0"));
                    }
                }
                else
                {
                    ddlRocode.Enabled = true;
                    SqlConnection con = new SqlConnection(strcon);
                    con.Open();

                    SqlCommand cmd = new SqlCommand("RTS_SP_Fetch_Sourcetype_Values", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (ddlSourcetype.SelectedItem.Text == "Liability Branch Lead")
                    {
                        //  cmd.Parameters.Add("@EMP_BR_ID", SqlDbType.VarChar).Value = ddlstsourcingbrnch.SelectedItem.Text != "--Select--" ? ddlstsourcingbrnch.SelectedValue.ToString() : "";
                        cmd.Parameters.Add("@EMP_BR_ID", SqlDbType.VarChar).Value = ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "";
                    }
                    else
                    {
                        cmd.Parameters.Add("@EMP_BR_ID", SqlDbType.VarChar).Value = ddlstsourcingbrnch.SelectedItem.Text != "--Select--" ? ddlstsourcingbrnch.SelectedValue.ToString() : "";
                    }
                    cmd.Parameters.Add("@ET_DESC", SqlDbType.VarChar).Value = ddlSourcetype.SelectedItem.Text.ToString();

                    SqlDataAdapter showdata = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    showdata.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        con.Close();
                        ddlRocode.DataSource = ds;
                        ddlRocode.DataTextField = "EMPNAME";
                        ddlRocode.DataValueField = "VAL";
                        ddlRocode.DataBind();
                        ddlRocode.Items.Insert(0, new ListItem("--Select--", "0"));
                    }
                    else
                    {
                        ddlRocode.Items.Clear();
                        ddlRocode.Items.Insert(0, new ListItem("--Select--", "0"));
                    }
                }

                if (ddlProduct.SelectedItem.Text != "IB-G-LAP" && ddlProduct.SelectedItem.Text != "IB-G-HF" && ddlProduct.SelectedItem.Text != "Housing-IB-G-HF")
                {
                    if (ddlSourcetype.SelectedItem.Text == "Liability Branch Lead")
                    {
                        Bind_SRCING_BRANCH();
                        this.srcbrnch1.Disabled = false;
                    }
                    else
                    {
                        ddlstsourcingbrnch.SelectedIndex = 0;
                        this.srcbrnch1.Disabled = true;
                    }
                }
                else
                {
                    if (ddlSourcetype.SelectedItem.Text == "Liability Branch Lead")
                    {
                        Bind_SRCING_BRANCH();
                        this.srcbrnch1.Disabled = false;
                    }
                    else
                    {
                        ddlstsourcingbrnch.SelectedIndex = 0;
                        Bind_SRCING_BRANCH();
                    }

                }

                if (ddlSourcetype.SelectedItem.Text == "Telecaller")
                {
                    ddlRocode.Visible = false;
                    lblrosocode.Visible = false;
                    txtRoname.Visible = false;
                    lblrosoname.Visible = false;
                    lblempcode.Visible = true;
                    lblempname.Visible = true;
                    txtEmpCode.Visible = true;
                    txtEMpNAme.Visible = true;
                }
                else
                {
                    ddlRocode.Visible = true;
                    lblrosocode.Visible = true;
                    txtRoname.Visible = true;
                    lblrosoname.Visible = true;
                    lblempcode.Visible = false;
                    lblempname.Visible = false;
                    txtEmpCode.Visible = false;
                    txtEMpNAme.Visible = false;
                }

                    Clear_After_Change("SOURCING TYPE");
            }
            else
            {
                Clear();
                ddlSourcetype.SelectedIndex = 0;
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void ddlMember_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DDLReferenceSource.SelectedIndex = 0;
            TxtReferenceID.Text = "";
            TxtReferenceName.Text = "";
            TxtContactNumber.Text = "";
            txtMemid.Text = "";
            if (ddlMember.SelectedItem.Text == "Yes")
            {
                TxtReferenceID.Enabled = false;
                TxtReferenceName.Enabled = false;
                TxtContactNumber.Enabled = false;
                DDLReferenceSource.Enabled = false;
                txtRefAddress.Enabled = false;
                dddlLoanCycle.Enabled = false;
                ddlRelation.Enabled = false;
                txtCntrLeadName.Enabled = false;
                txtMemid.Enabled = true;
                txtMemid.Text = "";
                Clear();
            }
            else if (ddlMember.SelectedItem.Text == "--Select--")
            {
                TxtReferenceID.Enabled = false;
                TxtReferenceName.Enabled = false;
                TxtContactNumber.Enabled = false;
                DDLReferenceSource.Enabled = false;
                txtRefAddress.Enabled = false;
                dddlLoanCycle.Enabled = false;
                ddlRelation.Enabled = false;
                txtCntrLeadName.Enabled = false;
                txtLeadno.Text = "";
                if (ddlSourcetype.Items.Count > 0)
                    ddlSourcetype.SelectedIndex = 0;
                Clear();
            }
            else if (ddlMember.SelectedItem.Text == "No")
            {
                TxtReferenceID.Enabled = true;
                TxtReferenceName.Enabled = true;
                TxtContactNumber.Enabled = true;
                DDLReferenceSource.Enabled = true;
                txtRefAddress.Enabled = true;
                dddlLoanCycle.Enabled = true;
                ddlRelation.Enabled = true;
                txtCntrLeadName.Enabled = true;
                txtMemid.Enabled = false;
                txtMemid.Text = "";
                Clear();
            }
            else
            {
                txtMemid.Text = "";
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void leadcreation()
    {
        try
        {
            string a = "";
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Create_LeadID", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@BR_NAME", SqlDbType.VarChar).Value = ddlBranch.SelectedItem.Text.Trim();

            SqlDataAdapter dalead = new SqlDataAdapter(cmd);
            DataSet dslead = new DataSet();
            dalead.Fill(dslead);

            brcode = dslead.Tables[1].Rows[0]["BR_CODE"].ToString();

            con.Close();
            if (dslead.Tables[0].Rows.Count != 0)
            {
                a = dslead.Tables[0].Rows[0]["LD_ID"].ToString();
            }
            else
            {
                a = "000001";
            }


            string[] PRARR = ddlProduct.SelectedIndex > 0 ? ddlProduct.SelectedValue.ToString().Split('-') : null;
            txtLeadno.Text = PRARR[1].ToString() + brcode + a.PadLeft(6, '0');
            leadno = txtLeadno.Text;
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlRocode_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlRocode.SelectedIndex > 0)
        {

            try
            {

                arr_type = new string[3];

                arr_type = ddlRocode.SelectedValue.Split('|');
                if (arr_type != null)
                {
                    if (arr_type.Count() > 2)
                    {
                        if (arr_type[2].ToString() != "Employee" && arr_type[2].ToString() != "Branch")
                        {
                            TxtReferenceID.Enabled = false;
                            TxtReferenceName.Enabled = false;
                            TxtContactNumber.Enabled = false;
                            DDLReferenceSource.Enabled = false;
                            txtRefAddress.Enabled = false;
                            dddlLoanCycle.Enabled = false;
                            ddlRelation.Enabled = false;
                            txtCntrLeadName.Enabled = false;
                            txtMemid.Enabled = true;

                        }
                        else
                        {
                            TxtReferenceID.Enabled = true;
                            TxtReferenceName.Enabled = true;
                            TxtContactNumber.Enabled = true;
                            DDLReferenceSource.Enabled = true;
                            txtRefAddress.Enabled = true;
                            dddlLoanCycle.Enabled = true;
                            ddlRelation.Enabled = true;
                            txtCntrLeadName.Enabled = true;
                            if (ddlMember.SelectedItem.Text == "No")
                            {
                                txtMemid.Enabled = false;
                            }
                            else
                            {
                                txtMemid.Enabled = true;
                            }

                            txtMemid.Text = "";
                        }

                        Session["codeid"] = arr_type[0].ToString();
                        txtRoname.Text = arr_type[1].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                txtRoname.Text = "";
                ErrorLog.WriteError(ex);
                uscMsgBox1.AddMessage("Invalid Selection", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);                
            }

        }
        else
        {
            txtRoname.Text = "";
            //Bala changes 13/03/2018
            Session["codeid"] = null;
        }
        Clear_After_Change("RO");
    }
    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            bindMainProduct(Convert.ToInt32(ddlCategory.SelectedValue));


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlMainProduct_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            // bindMainProduct(Convert.ToInt32(ddlCategory.SelectedValue));

            bindMRProduct(Convert.ToInt32(ddlMainProduct.SelectedValue));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlProduct_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            trTWL.Visible = false;
            ddlstsourcingbrnch.SelectedIndex = 0;

            //string[] PRARR = ddlProduct.SelectedIndex > 0 ? ddlProduct.SelectedValue.ToString().Split('-') : null;

            bindScheme(GetProdId(ddlProduct.SelectedValue));


            ClearALL();
            if (ddlSourcetype.Items.Count > 0)
            {
                ddlSourcetype.SelectedIndex = 0;
            }

            // if (ddlProduct.SelectedValue.Contains("G"))
            if (ddlProduct.SelectedItem.Text == "IB-G-LAP" || ddlProduct.SelectedItem.Text == "IB-G-HF" || ddlProduct.SelectedItem.Text == "Housing-IB-G-HF")
            {
                this.srcbrnch.Disabled = false;
                this.srcbrnch1.Disabled = false;
                Bind_SRCING_BRANCH();
            }
            else
            {
                this.srcbrnch.Disabled = true;
                this.srcbrnch1.Disabled = true;
            }
            if (ddlProduct.SelectedValue.Contains("TWL"))
            {
                trTWL.Visible = true;
            }

            if (checkValues.Contains(GetProdId(ddlProduct.SelectedValue.ToString())))
            {
                txtAppname.Enabled = true;
                txtMobileno.Enabled = true;
                ddlloginfee.Enabled = true;
                txtloginfee.Enabled = true;
            }

            ddlManufacture.SelectedValue = "";
            ddlModel.SelectedValue = "";
            txtMRP.Text = "";
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void Bind_SRCING_BRANCH()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
            cmdrsn.CommandType = CommandType.StoredProcedure;



            if (Session["USR_ACS"].ToString() == "7")
            {
                cmdrsn.Parameters.AddWithValue("@AR_NAME", Session["AREANAME"] != null ? Session["AREANAME"].ToString() : "");
            }
            else
            {
                cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.Text : "");
            }

            if (ddlSourcetype.SelectedItem.Text == "Liability Branch Lead")
            {

                if (Session["USR_ACS"].ToString() == "7")
                {
                    cmdrsn.Parameters.AddWithValue("@EMP_TYPE", ddlSourcetype.SelectedValue);

                    cmdrsn.Parameters.AddWithValue("@BR_ID", Session["BRANCHID"] != null ? Session["BRANCHID"].ToString() : "");
                }
                else
                {
                    cmdrsn.Parameters.AddWithValue("@EMP_TYPE", ddlSourcetype.SelectedValue);
                    cmdrsn.Parameters.AddWithValue("@BR_ID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue : "");
                }
            }


            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

            ddlstsourcingbrnch.DataSource = dsrsn;
            ddlstsourcingbrnch.DataTextField = "BR_NAME";
            ddlstsourcingbrnch.DataValueField = "BR_ID";
            ddlstsourcingbrnch.DataBind();
            ddlstsourcingbrnch.Items.Insert(0, new ListItem("--Select--", "0"));

            if (ddlSourcetype.SelectedItem.Text != "Liability Branch Lead")
            {
                if (Session["USR_ACS"].ToString() == "7")
                {

                    ddlstsourcingbrnch.SelectedValue = Session["BRANCHID"] != null ? Session["BRANCHID"].ToString() : "0";
                }
                else
                {
                    ddlstsourcingbrnch.SelectedValue = "0";
                }
            }
            else
            {
                ddlstsourcingbrnch.SelectedValue = "0";
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }

    public void Clear()
    {
        try
        {
            if (ddlRocode.Items.Count > 0)
                ddlRocode.SelectedIndex = 0;

            txtRoname.Text = "";
            txtMemid.Text = "";
            //txtAppname.Text = "";
            //txtMobileno.Text = "";
            TxtReferenceID.Text = "";
            TxtReferenceName.Text = "";
            TxtContactNumber.Text = "";
            //if (ddlSourcetype.SelectedItem.Text != "Liability Branch Lead")
            //{
            //    if (ddlSourcetype.Items.Count > 0)
            //        ddlSourcetype.SelectedIndex = 0;
            //}
            if (ddlst_fle_hndle_type.Items.Count > 0)
                ddlst_fle_hndle_type.SelectedIndex = 0;

            if (ddlst_fle_hndle_by.Items.Count > 0)
                ddlst_fle_hndle_by.SelectedIndex = 0;
            txtbx_fle_hndle_by.Text = "";

            if (DDLReferenceSource.Items.Count > 0)
                DDLReferenceSource.SelectedIndex = 0;
            if (dddlLoanCycle.Items.Count > 0)
                dddlLoanCycle.SelectedIndex = 0;
            if (ddlRelation.Items.Count > 0)
                ddlRelation.SelectedIndex = 0;
            txtRefAddress.Text = "";
            txtCntrLeadName.Text = "";
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    public void ClearALL()
    {

        try
        {
        txtLeadno.Text = "";

        if (ddlSourcetype.SelectedItem.Text != "Liability Branch Lead")
        {
            //if (ddlSourcetype.Items.Count > 0)
            //{
            //    ddlSourcetype.SelectedIndex = 0;
            //}

            if (ddlMember.Items.Count > 0)
                ddlMember.SelectedIndex = 0;
        }
        Clear();
        trTWL.Visible = false;
        ddlManufacture.SelectedIndex = 0;
        ddlModel.SelectedIndex = 0;
        txtMRP.Text = "";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void ddlstsourcingbrnch_SelectedIndexChanged(object sender, EventArgs e)
    {
        ClearALL();
    }
    // Mani_Nov_14_01 
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

            ddlBranch.DataSource = dsrsn;
            ddlBranch.DataTextField = "BR_NAME";
            ddlBranch.DataValueField = "BR_ID";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlBranch.Enabled = true;
            txtLeadno.Text = "";
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void DDLReferenceSource_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DDLReferenceSource.SelectedItem.Text != "--Select--")
        {
            TxtReferenceID.Enabled = true;
            TxtReferenceName.Enabled = true;
            TxtContactNumber.Enabled = true;
            txtRefAddress.Enabled = true;

        }
        else
        {
            TxtReferenceID.Enabled = false;
            TxtReferenceName.Enabled = false;
            TxtContactNumber.Enabled = false;
        }
        Clear_After_Change("REFERENCE SOURCE");
    }
    protected void Clear_After_Change(string pass)
    {
        try
        {
            switch (pass)
            {
                case "RO":


                    if (DDLReferenceSource.Items.Count > 0)
                        DDLReferenceSource.SelectedIndex = 0;
                    TxtReferenceID.Text = "";
                    TxtReferenceName.Text = "";
                    txtRefAddress.Text = "";
                    if (dddlLoanCycle.Items.Count > 0)
                        dddlLoanCycle.SelectedIndex = 0;
                    if (ddlRelation.Items.Count > 0)
                        ddlRelation.SelectedIndex = 0;

                    TxtContactNumber.Text = "";
                    txtCntrLeadName.Text = "";
                    txtLeadno.Text = "";
                    txtMemid.Text = "";
                    //txtAppname.Text = "";
                    //txtMobileno.Text = "";
                    break;

                case "SOURCING TYPE":

                    if (ddlRocode.Items.Count > 0)
                        ddlRocode.SelectedIndex = 0;

                    txtRoname.Text = "";
                    if (DDLReferenceSource.Items.Count > 0)
                        DDLReferenceSource.SelectedIndex = 0;
                    TxtReferenceID.Text = "";
                    TxtReferenceName.Text = "";
                    txtRefAddress.Text = "";
                    if (dddlLoanCycle.Items.Count > 0)
                        dddlLoanCycle.SelectedIndex = 0;
                    if (ddlRelation.Items.Count > 0)
                        ddlRelation.SelectedIndex = 0;

                    TxtContactNumber.Text = "";
                    txtCntrLeadName.Text = "";
                    txtLeadno.Text = "";
                    txtMemid.Text = "";
                    //txtAppname.Text = "";
                    //txtMobileno.Text = "";
                    break;

                case "REFERENCE SOURCE":


                    TxtReferenceID.Text = "";
                    TxtReferenceName.Text = "";
                    txtRefAddress.Text = "";
                    if (dddlLoanCycle.Items.Count > 0)
                        dddlLoanCycle.SelectedIndex = 0;
                    if (ddlRelation.Items.Count > 0)
                        ddlRelation.SelectedIndex = 0;

                    TxtContactNumber.Text = "";
                    txtCntrLeadName.Text = "";
                    txtLeadno.Text = "";
                    txtMemid.Text = "";
                    //txtAppname.Text = "";
                    //txtMobileno.Text = "";
                    break;


            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void ddlManufacture_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataTable dt = (DataTable)ViewState["Manufacture"];
            if (dt != null && dt.Rows.Count > 0)
            {
                // DataTable dtTemp = dt.Select("NAME=" + ddlManufacture.SelectedItem.Text ).CopyToDataTable();
                DataRow[] dr = dt.Select("NAME = '" + ddlManufacture.SelectedItem.Text + "'");
                DataTable dtTemp = dr.CopyToDataTable();
                ddlModel.DataSource = dtTemp;
                ddlModel.DataTextField = "MFC_MODEL";
                ddlModel.DataValueField = "VALUE";
                ddlModel.DataBind();
                ddlModel.Items.Insert(0, new ListItem("--Select--", ""));

            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlModel_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string[] strVal = ddlModel.SelectedValue.ToString().Split('-');
            if (strVal.Length > 0)
            {
                txtMRP.Text = strVal[1].ToString();
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void btnBTSearch_Click(object sender, EventArgs e)
    {

    }
    protected void ddlScheme_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            // string strTopUp=clscommon.GetTopUpSchemes();
            //if(strTopUp.Contains(ddlScheme.SelectedValue)==true)
            if (Convert.ToInt32(ddlScheme.SelectedValue) == 28 || Convert.ToInt32(ddlScheme.SelectedValue) == 29)
            {
                txtTopLeadNo.Text = "";
                gvBT.Visible = false;
                trTopUp.Visible = true;
                trBT.Visible = false;
                trBT1.Visible = false;
                trBTTopUp12.Visible = true;
                btnSubmit.Enabled = false;
                trPreApproved.Visible = false;
            }
            else
             if (Convert.ToInt32(ddlScheme.SelectedValue) == 35
                || Convert.ToInt32(ddlScheme.SelectedValue) == 45
                || Convert.ToInt32(ddlScheme.SelectedValue) == 46
                || Convert.ToInt32(ddlScheme.SelectedValue) == 47
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Assessed_Product_Scheme.ATMA_VISHWAS_2020_MLAP_Pre_Topup)
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Assessed_Product_Scheme.ATMA_VISHWAS_2020_GLAP_Pre_Topup)
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Assessed_Product_Scheme.ATMA_VISHWAS_2020_ASL_Pre_Topup)
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Assessed_Product_Scheme.ATMA_VISHWAS_2020_BL_Assessed_Pre_Topup)
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Declared_Product_Scheme.ATMA_VISHWAS_2020_Salaried_LAP_Pre_Topup)
                || Convert.ToInt32(ddlScheme.SelectedValue) == Convert.ToInt32(Declared_Product_Scheme.ATMA_VISHWAS_2020_BL_Declared_Pre_Topup)
                )
             {
                 trTopUp.Visible = false;
                 trBT.Visible = false;
                 trBT1.Visible = false;
                 trBTTopUp12.Visible = false;
                 btnSubmit.Enabled = true;
                 trPreApproved.Visible = true;
             }
             else
            {
                trTopUp.Visible = false;
                trBT.Visible = false;
                trBT1.Visible = false;
                trBTTopUp12.Visible = false;
                btnSubmit.Enabled = true;
                trPreApproved.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtTopLeadNo_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (txtTopLeadNo.Text == "")
            {
                gvBT.Visible = false;
                gvBT.DataBind();
                btnSubmit.Enabled = false;
                uscMsgBox1.AddMessage("Please enter the valid lead no.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
                if (ddlScheme.SelectedValue == "0")
                {
                    uscMsgBox1.AddMessage("Please select the scheme.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
                else
                {
                    DataSet ds = new DataSet();
                    ds = clscommon.Bind_TopUp_Lead_Details(txtTopLeadNo.Text, Convert.ToInt32(ddlScheme.SelectedValue));
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        btnSubmit.Enabled = true;
                        gvBT.Visible = true;
                        gvBT.DataSource = ds;
                        gvBT.DataBind();

                    }
                    else
                    {
                        gvBT.Visible = false;
                        gvBT.DataBind();
                        btnSubmit.Enabled = false;
                        uscMsgBox1.AddMessage("No Records Found for entered lead no.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void gvradiantreceipt_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {

        }
    }
    protected void txtBTLoanNumber_TextChanged(object sender, EventArgs e)
    {
        if (txtBTLoanNumber.Text == "")
        {
            uscMsgBox1.AddMessage("Please enter the top up loan number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            btnSubmit.Enabled = false;
        }
        else
        {
            btnSubmit.Enabled = true;
        }
    }
    protected void txtOldAgreementNo_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if(txtOldAgreementNo.Text=="")
            {
                uscMsgBox1.AddMessage("Please enter the old agreement no.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtOldApplicantName.Text = "";
                txtOldLoanAmt.Text = "";
                    
            }
            else
            {
                DataSet ds = new DataSet();
                ds = clscommon.Bind_FETCH_Loan_Details(txtOldAgreementNo.Text.Trim());
                if(ds.Tables[0].Rows.Count>0)
                {
                    txtOldApplicantName.Text = ds.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? ds.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                    txtOldLoanAmt.Text = ds.Tables[0].Rows[0]["LD_LOAN_AMT"] != DBNull.Value ? ds.Tables[0].Rows[0]["LD_LOAN_AMT"].ToString() : "";
                    btnSubmit.Enabled = true;
                }
                else
                {
                    uscMsgBox1.AddMessage("You have entered old agreement no is not exist in the system.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    btnSubmit.Enabled = false;                   
                    txtOldApplicantName.Text = "";
                    txtOldLoanAmt.Text = "";
                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }


    protected void ddlst_fle_hndle_type_SelectedIndexChanged(object sender, EventArgs e)
    {

        try
        {
            if (ddlst_fle_hndle_type.SelectedItem.Text != "--Select--")
            {
                // if (!ddlProduct.SelectedItem.Text.StartsWith("G"))
                if (ddlProduct.SelectedItem.Text != "IB-G-LAP" && ddlProduct.SelectedItem.Text != "IB-G-HF")
                {
                    ddlst_fle_hndle_by.Enabled = true;
                    SqlConnection con = new SqlConnection(strcon);
                    con.Open();

                    SqlCommand cmd = new SqlCommand("RTS_SP_Fetch_Sourcetype_Values", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@EMP_BR_ID", SqlDbType.VarChar).Value = ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "";
                    cmd.Parameters.Add("@ET_DESC", SqlDbType.VarChar).Value = ddlst_fle_hndle_type.SelectedItem.Text.ToString();

                    SqlDataAdapter showdata = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    showdata.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        con.Close();
                        ddlst_fle_hndle_by.DataSource = ds;
                        ddlst_fle_hndle_by.DataTextField = "EMPNAME";
                        ddlst_fle_hndle_by.DataValueField = "VAL";
                        ddlst_fle_hndle_by.DataBind();
                        ddlst_fle_hndle_by.Items.Insert(0, new ListItem("--Select--", "0"));
                    }
                    else
                    {
                        ddlst_fle_hndle_by.Items.Clear();
                        ddlst_fle_hndle_by.Items.Insert(0, new ListItem("--Select--", "0"));
                    }
                }
                else
                {
                    ddlst_fle_hndle_by.Enabled = true;
                    SqlConnection con = new SqlConnection(strcon);
                    con.Open();

                    SqlCommand cmd = new SqlCommand("RTS_SP_Fetch_Sourcetype_Values", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (ddlst_fle_hndle_type.SelectedItem.Text == "Liability Branch Lead")
                    {
                        //  cmd.Parameters.Add("@EMP_BR_ID", SqlDbType.VarChar).Value = ddlstsourcingbrnch.SelectedItem.Text != "--Select--" ? ddlstsourcingbrnch.SelectedValue.ToString() : "";
                        cmd.Parameters.Add("@EMP_BR_ID", SqlDbType.VarChar).Value = ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "";
                    }
                    else
                    {
                        cmd.Parameters.Add("@EMP_BR_ID", SqlDbType.VarChar).Value = ddlstsourcingbrnch.SelectedItem.Text != "--Select--" ? ddlstsourcingbrnch.SelectedValue.ToString() : "";
                    }
                    cmd.Parameters.Add("@ET_DESC", SqlDbType.VarChar).Value = ddlst_fle_hndle_type.SelectedItem.Text.ToString();

                    SqlDataAdapter showdata = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    showdata.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        con.Close();
                        ddlst_fle_hndle_by.DataSource = ds;
                        ddlst_fle_hndle_by.DataTextField = "EMPNAME";
                        ddlst_fle_hndle_by.DataValueField = "VAL";
                        ddlst_fle_hndle_by.DataBind();
                        ddlst_fle_hndle_by.Items.Insert(0, new ListItem("--Select--", "0"));
                    }
                    else
                    {
                        ddlst_fle_hndle_by.Items.Clear();
                        ddlst_fle_hndle_by.Items.Insert(0, new ListItem("--Select--", "0"));
                    }
                }




            }
            else
            {

                ddlst_fle_hndle_type.SelectedIndex = 0;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }


    }

    protected void ddlst_fle_hndle_by_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlst_fle_hndle_by.SelectedIndex > 0)
        {

            try
            {

                arr_type = new string[3];

                arr_type = ddlst_fle_hndle_by.SelectedValue.Split('|');
                if (arr_type != null)
                {
                    if (arr_type.Count() > 2)
                    {


                        Session["LD_FEMP_ID"] = arr_type[0].ToString();
                        txtbx_fle_hndle_by.Text = arr_type[1].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                txtbx_fle_hndle_by.Text = "";
                ErrorLog.WriteError(ex);
            }

        }
        else
        {
            txtbx_fle_hndle_by.Text = "";


        }

    }

    protected void ddlprofilestatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        //try
        //{
        //    if (ddlloginfee.SelectedValue == "Y")
        //    {
        //        lgfee.Visible = true;
        //        lgvalfee.Visible = true;
        //        instrument.Visible = true;
        //    }
        //    else
        //    {
        //        txtloginfee.Text = "";
        //        txtinstrument.Text = "";

        //        if (ddlinstrument.Items.Count > 0)
        //            ddlinstrument.SelectedIndex = 0;

        //        lgfee.Visible = false;
        //        lgvalfee.Visible = false;
        //        instrument.Visible = false;

        //    }
        //}
        //catch (Exception ex)
        //{
        //    ErrorLog.WriteError(ex);
        //}

    }

    protected void imgPickUnoLead_Click(object sender, ImageClickEventArgs e)
    {
        //Validate Session Expiry before launching popup
        if (Session[AppConstants.ID] != null)
        {
            ScriptManager.RegisterStartupScript(
            Page,
            this.GetType(),
            "alert",
            "window.open('Branch_LeadIntegration.aspx', '_blank', 'directories=no,toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=no,width=4000,height=4000,top=0,left=0,fullscreen=yes')",
            true);
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }

    private void ClearUNOLeadParameters()
    {
        txtUnoLeadNo.Text = "";
        txtUnoLeadName.Text = "";
        txtUnoProdName.Text = "";
        txtUnoReceiptNo.Text = "";
        txtUnoReceiptType.Text = "";
        txtUnoReceiptAmt.Text = "";
        hdnUnoLeadBucketId.Value = "";
    }

    private void ClearLeadDataPostSubmit()
    {
        txtMemid.Text = "";
        txtAppname.Text = "";
        txtMobileno.Text = "";
        txtLeadno.Text = leadno;

        ClearALL();
        ClearUNOLeadParameters();
        ddlProduct.SelectedIndex = 0;

        if (ddlstsourcingbrnch.Items.Count > 0)
            ddlstsourcingbrnch.SelectedIndex = 0;
        if (ddlSourcetype.Items.Count > 0)
            ddlSourcetype.SelectedIndex = 0;
        if (ddlRocode.Items.Count > 0)
            ddlRocode.SelectedIndex = 0;
        if (ddlloginfee.Items.Count > 0)
            ddlloginfee.SelectedIndex = 0;
        if (ddlinstrument.Items.Count > 0)
            ddlinstrument.SelectedIndex = 0;

        ddlMainProduct.Items.Clear();
        ddlMainProduct.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlProduct.Items.Clear();
        ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlScheme.Items.Clear();
        ddlScheme.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlCategory.Items.Clear();
        ddlCategory.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlSourcetype.SelectedIndex = 0;
        ddlMember.SelectedIndex = 0;

        bindProductCategory();

        trTopUp.Visible = false;
        txtBTLoanNumber.Text = "";
        txtBTProduct.Text = "";
        txtBTBranch.Text = "";
        txtBTArea.Text = "";
        txtBTAprvDate.Text = "";
        txtBtCustomerName.Text = "";
        txtTopLeadNo.Text = "";
        txtOldAgreementNo.Text = "";
        txtOldApplicantName.Text = "";
        txtOldLoanAmt.Text = "";
        txtloginfee.Text = "";
        txtoldleadno.Text = "";
        txtinstrument.Text = "";
        txtEmpCode.Text = "";
        txtEMpNAme.Text = "";
        ddlRocode.Visible = true;
        lblrosocode.Visible = true;
        txtRoname.Visible = true;
        lblrosoname.Visible = true;
        lblempcode.Visible = false;
        lblempname.Visible = false;
        txtEmpCode.Visible = false;
        txtEMpNAme.Visible = false;

        Session["codeid"] = null;
    }

    private int GetProdId(string Produt)
    {
        string[] PRARR = ddlProduct.SelectedIndex > 0 ? ddlProduct.SelectedValue.ToString().Split('-') : null;
        return Convert.ToInt32(PRARR[0]);
    }

    protected void txtEmpCode_TextChanged(object sender, EventArgs e)
    {
        BindEMpDets();
    }
    protected void BindEMpDets()
    {

        if (txtEmpCode.Text.Length == 4)
        {
            txtEmpCode.Text = "0" + txtEmpCode.Text;
        }
        else if (txtEmpCode.Text.Length == 4)
        {
            txtEmpCode.Text = "00" + txtEmpCode.Text;
        }
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("SELECT EMP_ID,EMP_NAME from HR_EMP_DETS  WHERE EMP_CODE='" + txtEmpCode.Text + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {            
            txtEMpNAme.Text = dsdd.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";            
        }
        else
        {            
            txtEMpNAme.Text = "";           
        }
    }
}
