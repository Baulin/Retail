﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class Pre_Closure : System.Web.UI.Page
{
    #region Common
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter dappre = new SqlDataAdapter();
    DataSet dspre = new DataSet();
    DataTable dtpre = new DataTable();
    DataTable dtDoc_Add = new DataTable();
    DataSet ds = new DataSet();
    DateTime dt = DateTime.Now;
    DateTime dtd;    
    byte go;
    int id, count=0;
    string loanDte = string.Empty;
    string loanAmt = string.Empty;
    string fullName = string.Empty;
    string branch = string.Empty;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    CreateLogFiles Err = new CreateLogFiles();
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    bind();
                    BindCourierName();
                    //txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                }
            }
            else
                Response.Redirect("~/Default.aspx");

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }


    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        #region DocsCheck
        //If new documents added then no checkboxes checked
        if (Convert.ToString(Session["DOCNEW"]) != "YES")
        {
            CheckBox chkAll = gvMODTDDoc.HeaderRow.FindControl("chkbxAll") as CheckBox;
            if (chkAll.Checked == false)
            {
                go = 0;
                uscMsgBox1.AddMessage("Please Select all the documents...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                go = 1;
            }
        }
        else
        {
            go = 1;
        }
        #endregion

        if (go == 1)
        {
            id = Session["ID"] != null ? Convert.ToInt32(Session["ID"].ToString()) : 0;
            if (Session["ID"] != null)
            {
                id = Convert.ToInt32(Session["ID"].ToString());
            }
            else
            {
                Response.Redirect("Expire.aspx");
                return;
            }
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();
                SqlTransaction trans = null;
                trans = connection.BeginTransaction();
                int r = 0;
                if (Convert.ToString(Session["DOCNEW"]) == "YES")
                {                   
                    try
                    {
                        cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LeadId"]), connection, trans);
                        var obj = cmd.ExecuteScalar();
                        //trans = connection.BeginTransaction();
                        cmd.Transaction = trans;
                        if (obj == null)
                        {
                            cmd = new SqlCommand("Insert into LSD_MOTD (MD_LD_ID,MD_PDATE,MD_CBY,MD_CDATE,MD_PHO_SDATE,MD_PHO_CR_ID,MD_PHO_POD_NO) values( " + Convert.ToInt32(Session["LeadId"]) + ",getdate()," + id + ",getdate(),getdate()," + ddlName.SelectedValue + ",'" + txtNumber.Text.Trim() + "')", connection, trans);

                        }
                        else
                        {
                            string upQry = "update LSD_MOTD set MD_PHO_SDATE =getdate(),MD_PHO_CR_ID=" + ddlName.SelectedValue + " ,MD_PHO_POD_NO='" + txtNumber.Text.Trim() + "' where MD_LD_ID=" + Convert.ToInt32(Session["LeadId"]) + "";
                            cmd = new SqlCommand(upQry, connection, trans);
                        }
                        cmd.ExecuteNonQuery();
                        cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection, trans);
                        dtpre = new DataTable();
                        dappre = new SqlDataAdapter(cmd);
                        dappre.Fill(dtpre);
                        Session["MDID"] = dtpre.Rows[0]["MD_ID"] != DBNull.Value ? dtpre.Rows[0]["MD_ID"].ToString() : "";

                    }
                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                        trans.Rollback();
                    }
                    DataTable dtDocx = (DataTable)ViewState["DocTable"];
                    try
                    {
                        dtDocx.Columns.Remove("DT_DESC");
                        cmd = new SqlCommand("RTS_SP_PRECLOSURE_MOTD", connection,trans);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 2400000;
                        cmd.Parameters.AddWithValue("@MDX_MD_ID", Session["MDID"] != DBNull.Value ? Session["MDID"] : 0);
                        cmd.Parameters.AddWithValue("@MDX_RSTAT", "Received");
                        cmd.Parameters.AddWithValue("@UDTABLE", dtDocx);
                        SqlParameter parmOut = new SqlParameter();
                        parmOut.ParameterName = "@ID";
                        parmOut.SqlDbType = SqlDbType.Int;
                        parmOut.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(parmOut);
                        cmd.ExecuteNonQuery();
                        r = Convert.ToInt16(parmOut.Value);
                        //int r = cmd.ExecuteNonQuery();
                        if (r > 0)
                        {
                            panleDoc.Visible = true;
                            Panel3.Visible = false;
                            txtLeadno.Text = "";
                            trans.Commit();
                            BindDocGid(connection);
                            //BindHOSNDDoc();
                            gvLegalRecvPreDoc.Visible = false;                            
                            uscMsgBox1.AddMessage("Document sent successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        }
                        else
                        {
                            panleDoc.Visible = false;
                            uscMsgBox1.AddMessage("Document not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }

                    }
                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                        trans.Rollback();
                        uscMsgBox1.AddMessage("Document and Survey & Extent input fields should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    finally
                    {
                        dtDocx.Clear();
                        cmd.Dispose();
                    }
                    //trans.Commit();
                }
                else
                {
                    #region UpdateDocs
                    string upQry = "update LSD_MOTD set MD_PHO_SDATE =getdate(),MD_PHO_CR_ID=" + ddlName.SelectedValue + " ,MD_PHO_POD_NO='" + txtNumber.Text.Trim() + "' where MD_LD_ID=" + Convert.ToInt32(Session["LeadId"]) + "";
                    cmd = new SqlCommand(upQry, connection,trans);
                    r = cmd.ExecuteNonQuery();
                    if (r > 0)
                    {
                        Clear();
                        panleDoc.Visible = true;
                        Panel3.Visible = false;
                        txtLeadno.Text = "";
                        trans.Commit();
                        BindDocGid(connection);
                        //BindHOSNDDoc();
                        gvLegalRecvPreDoc.Visible = false;                        
                        uscMsgBox1.AddMessage("Document sent sucessfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else
                        uscMsgBox1.AddMessage("Document not sent", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    #endregion
                }
                //trans.Commit();
            }

        }

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Pre_Closure.aspx", false);
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            BindHOSNDDoc();
            //Panel3.Visible = true;
            //getLeadID(con);
            //if (string.IsNullOrEmpty(Convert.ToString(Session["LeadId"])))
            //{
            //    uscMsgBox1.AddMessage("No Lead Id for this loan number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            //else
            //{
                //chkExists(con);
                //if (count > 0)
                //{
                //    uscMsgBox1.AddMessage("Preclosure already done", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //    return;
                //}
                //else
                //    BindDocGid(con);
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
            SqlConnection.ClearPool(con);
        }

    }

    public void BindDocGid(SqlConnection con)
    {
        using (SqlCommand cmdGetDoc = new SqlCommand("SP_UNO_BIND_LOAN", con))
        {
            try
            {
                con.Open();
                DataTable dtDocx = new DataTable();
                cmdGetDoc.CommandType = CommandType.StoredProcedure;
                cmdGetDoc.CommandTimeout = 24000000;
                //cmdGetDoc.Parameters.AddWithValue("@LD_NO", txtLeadno.Text.Trim());
                cmdGetDoc.Parameters.AddWithValue("@LEAD_ID", Convert.ToInt32(Session["LeadId"]));
                cmdGetDoc.Parameters.AddWithValue("@PTYPE", "GETDOCUMENTS");
                dtDocx.Load(cmdGetDoc.ExecuteReader());
                if (dtDocx.Rows.Count > 0)
                {
                    Session["DOCNEW"] = "NO";
                    Panel2.Visible = true;
                    Panel3.Visible = true;
                    panelAddDoc.Visible = false;
                    gvMODTDDoc.Visible = true;
                    gvMODTDDoc.DataSource = dtDocx;
                    gvMODTDDoc.DataBind();
                    btnSubmit.Enabled = true;                    
                }
                else
                {
                    Session["DOCNEW"] = "YES";
                    Panel2.Visible = false;                    
                    panelAddDoc.Visible = true;
                    btnSubmit.Enabled = false;
                    Bind_Doc_Type();
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmdGetDoc.Dispose();
                con.Close();
                cmdGetDoc.Dispose();
                SqlConnection.ClearPool(con);

            }
        }
    }

    protected void btnadd_Click(object sender, EventArgs e)
    {
        try
        {
            //if (Session["StatusLGL"].ToString() == "New")
            //{

            if (txtbxdocdate.Text.Trim() != "" && txtbxsurvey.Text.Trim() != "--Select--" && txtbxdocs.Text.Trim() != "" && ddlstdoctype.SelectedItem.Text != "--Select--" && ddlstdocCat.SelectedItem.Text != "--Select--" && txtbxdocno.Text.Trim() != "")
            {
                try
                {

                    dtd = DateTime.ParseExact(txtbxdocdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
                }

                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    uscMsgBox1.AddMessage("Invalid Date format. Please check the date (dd/mm/yyyy)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                    return;
                }

                Bind_Doc_Dt();
                //using (SqlConnection connection = new SqlConnection(strcon))
                //{
                //    connection.Open();
                //    if (Session["MDID"] == null)
                //    {


                //        try
                //        {
                //            id = Session["ID"] != null ? Convert.ToInt32(Session["ID"].ToString()) : 0;
                //            if (Session["ID"] != null)
                //            {
                //                id = Convert.ToInt32(Session["ID"].ToString());
                //            }
                //            else
                //            {
                //                Response.Redirect("Expire.aspx");
                //                return;
                //            }
                //            cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection);
                //            var obj = cmd.ExecuteScalar();
                //            if (obj == null)
                //            {
                //                cmd = new SqlCommand("Insert into LSD_MOTD (MD_LD_ID,MD_PDATE,MD_CBY,MD_CDATE) values( " + Convert.ToInt32(Session["LEADID"].ToString()) + ",getdate()," + id + ",getdate())", connection);
                //                cmd.ExecuteNonQuery();
                //            }

                //        }
                //        catch (Exception ex)
                //        {
                //            CreateLogFiles Err = new CreateLogFiles();
                //            Err.ErrorLog(HttpContext.Current.Server.MapPath("~/Logs/ErrorLog"), ex.Message, ex.StackTrace);

                //        }


                //        cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection);
                //        dtpre = new DataTable();
                //        dappre = new SqlDataAdapter(cmd);
                //        dappre.Fill(dtpre);

                //        Session["MDID"] = dtpre.Rows[0]["MD_ID"] != DBNull.Value ? dtpre.Rows[0]["MD_ID"].ToString() : "";

                //    }

                //    if (gvdocs.Rows.Count > 0)
                //    {
                //        List<int> cnt = new List<int>();
                //        cnt.Clear();
                //        foreach (GridViewRow grow in gvdocs.Rows)
                //        {
                //            Label lblPSCH = grow.FindControl("lblslno") as Label;
                //            cnt.Add(Convert.ToInt32(lblPSCH.Text));
                //        }
                //        docscnt = cnt.Max() + 1;

                //    }
                //    else
                //        docscnt = 1;

                //    try
                //    {

                //        string sql = " INSERT INTO LSD_MOTD_DOCX (MDX_MD_ID,MDX_SLNO,MDX_DATE,MDX_DOC,MDX_DOCNO,MDX_SURVEY,MDX_DTYPE,MDX_DT_ID,MDX_RSTAT) values(" + Convert.ToInt32(Session["MDID"].ToString()) + "," + docscnt + ",'" + dtd + "','" +
                //                      txtbxdocs.Text.Replace("'", "''").ToString() + "','" + txtbxdocno.Text.Replace("'", "''").ToString() + "','" + txtbxsurvey.Text.Replace("'", "''").ToString() + "','" + ddlstdoctype.SelectedItem.Text + "'," + Convert.ToInt32(ddlstdocCat.SelectedValue.ToString()) + ",'Received')";
                //        cmd = new SqlCommand(sql, connection);

                //        int r = cmd.ExecuteNonQuery();
                //        if (r > 0)
                //        {
                //            //CLear();
                //            //BindAllGrid("D");
                //            panleDoc.Visible = true;
                //            BindDocGid(connection);
                //        }
                //        else
                //        {
                //            panleDoc.Visible = false;
                //            uscMsgBox1.AddMessage("Document not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //        }

                //    }
                //    catch (Exception ex)
                //    {
                //        CreateLogFiles Err = new CreateLogFiles();
                //        Err.ErrorLog(HttpContext.Current.Server.MapPath("~/Logs/ErrorLog"), ex.Message, ex.StackTrace);

                //        uscMsgBox1.AddMessage("Document and Survey & Extent input fields should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //    }
                //    finally
                //    {
                //        cmd.Dispose();
                //    }
                //}


            }
            else
            {
                if (txtbxdocdate.Text == "")
                {
                    txtbxdocdate.Focus();

                }
                else if (ddlstdoctype.SelectedItem.Text == "--Select--")
                {
                    ddlstdoctype.Focus();
                }
                else if (txtbxsurvey.Text == "")
                {
                    txtbxsurvey.Focus();

                }
                else if (txtbxdocs.Text == "")
                {
                    txtbxdocs.Focus();
                }
                else if (ddlstdocCat.SelectedItem.Text == "--Select--")
                {
                    ddlstdocCat.Focus();
                }
                else if (txtbxdocno.Text.Trim() == "")
                {
                    txtbxdocno.Focus();
                }
                uscMsgBox1.AddMessage("Please Give corresponding Inputs for List of Documents", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                //BindAllGrid("D");
            }
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Pre_Closure.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
    }

    public void Bind_Doc_Type()
    {


        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                cmd = new SqlCommand("RTS_SP_BIND_LGL_DOC_TYPE", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandTimeout = 120000;
                dtpre = new DataTable();
                dappre = new SqlDataAdapter(cmd);
                dappre.Fill(dtpre);

                ddlstdocCat.DataSource = dtpre;

                ddlstdocCat.DataTextField = "DT_DESC";
                ddlstdocCat.DataValueField = "DT_ID";
                ddlstdocCat.DataBind();
                ddlstdocCat.Items.Insert(0, new ListItem("--Select--", ""));
                ddlstdocCat.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                try { Response.Redirect("ErrorPage.aspx?parameter=Pre_Closure.aspx"); }
                catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
            }
            finally
            {
                cmd.Dispose();
            }
        }
    }

    public void Bind_Doc_Dt()
    {
        try
        {
            //try
            //{
            //    dtd = DateTime.ParseExact(txtbxdocdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
            //}
            //catch (Exception ex)
            //{
            //    CreateLogFiles Err = new CreateLogFiles();
            //    Err.ErrorLog(HttpContext.Current.Server.MapPath("~/Logs/ErrorLog"), ex.Message, ex.StackTrace);
            //    uscMsgBox1.AddMessage("Invalid Date format. Please check the date (dd/mm/yyyy)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //    return;
            //}
            if (ViewState["DocTable"] != null)
            {
                dtDoc_Add = (DataTable)ViewState["DocTable"];
                DataRow dtRow;
                dtRow = dtDoc_Add.NewRow();
                dtRow["MDX_DT_ID"] = ddlstdocCat.SelectedValue != "" ? Convert.ToInt32(ddlstdocCat.SelectedValue.ToString()) : 0;
                //dtRow["MDX_DATE"] = txtbxdocdate.Text;
                dtRow["MDX_DATE"] = dtd;
                dtRow["MDX_DOC"] = txtbxdocs.Text.Trim();
                dtRow["MDX_DOCNO"] = txtbxdocno.Text.Trim();
                dtRow["MDX_SURVEY"] = txtbxsurvey.Text.Trim();
                dtRow["MDX_DTYPE"] = ddlstdoctype.SelectedItem.Text.Trim();
                dtRow["MDX_SLNO"] = dtDoc_Add.Rows.Count + 1;
                dtRow["DT_DESC"] = ddlstdocCat.SelectedItem.Text.Trim();
                dtDoc_Add.Rows.Add(dtRow);
                dtDoc_Add.AcceptChanges();
            }
            else
            {
                dtDoc_Add.Columns.Add("MDX_DT_ID", typeof(int));
                dtDoc_Add.Columns.Add("MDX_DATE", typeof(string));
                dtDoc_Add.Columns.Add("MDX_DOC", typeof(string));
                dtDoc_Add.Columns.Add("MDX_DOCNO", typeof(string));
                dtDoc_Add.Columns.Add("MDX_SURVEY", typeof(string));
                dtDoc_Add.Columns.Add("MDX_DTYPE", typeof(string));
                dtDoc_Add.Columns.Add("MDX_SLNO", typeof(int));
                dtDoc_Add.Columns.Add("DT_DESC", typeof(string));
                DataRow dtRow;
                dtRow = dtDoc_Add.NewRow();
                dtRow["MDX_DT_ID"] = ddlstdocCat.SelectedValue != "" ? Convert.ToInt32(ddlstdocCat.SelectedValue.ToString()) : 0;
                //dtRow["MDX_DATE"] = txtbxdocdate.Text;
                dtRow["MDX_DATE"] = dtd;
                dtRow["MDX_DOC"] = txtbxdocs.Text.Trim();
                dtRow["MDX_DOCNO"] = txtbxdocno.Text.Trim();
                dtRow["MDX_SURVEY"] = txtbxsurvey.Text.Trim();
                dtRow["MDX_DTYPE"] = ddlstdoctype.SelectedItem.Text.Trim();
                dtRow["MDX_SLNO"] = 1;
                dtRow["DT_DESC"] = ddlstdocCat.SelectedItem.Text.Trim();
                dtDoc_Add.Rows.Add(dtRow);
                dtDoc_Add.AcceptChanges();
            }
            ViewState["DocTable"] = dtDoc_Add;
            gvdocs.DataSource = dtDoc_Add;
            gvdocs.DataBind();
            panleDoc.Visible = true;
            uscMsgBox1.AddMessage("Document added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            btnSubmit.Enabled = true;
            ClearDoc();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            panelAddDoc.Visible = false;
            uscMsgBox1.AddMessage("Document not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            btnSubmit.Enabled = false;
        }
    }

    public void ClearDoc()
    {
        txtbxdocdate.Text = "";
        ddlstdocCat.SelectedIndex = 0;
        txtbxsurvey.Text = "";
        txtbxdocs.Text = "";
        ddlstdoctype.SelectedIndex = 0;
        txtbxdocno.Text = "";
    }

    public void BindCourierName()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CourierListas", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlName.DataSource = dsdd;
        ddlName.DataTextField = "CR_NAME";
        ddlName.DataValueField = "CR_ID";
        ddlName.DataBind();
        ddlName.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        panelAddDoc.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        using (SqlCommand cmdGetLoanDet = new SqlCommand("SP_UNO_BIND_LOAN", con))
        {
            try
            {
                cmdGetLoanDet.CommandType = CommandType.StoredProcedure;
                cmdGetLoanDet.CommandTimeout = 24000000;
                //cmdGetLoanDet.Parameters.AddWithValue("@PTYPE", "UNOBIND");
                cmdGetLoanDet.Parameters.AddWithValue("@LOANNO", txtLeadno.Text.Trim());
                cmdGetLoanDet.Parameters.AddWithValue("@PTYPE", "LOABIND");
                dtpre.Load(cmdGetLoanDet.ExecuteReader());
                gvLegalRecvDoc.DataSource = dtpre;
                gvLegalRecvDoc.DataBind();
                this.mpPre.Show();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmdGetLoanDet.Dispose();
                con.Close();
                SqlConnection.ClearPool(con);
            }
        }
    }

    protected void lnkname_OnClick(object sender, EventArgs e)
    {
        string loanno = ((LinkButton)sender).Text;
        txtLeadno.Text = loanno;
        BindHOSNDDoc();
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            Panel3.Visible = true;
            //getLeadID(con);
            if (string.IsNullOrEmpty(Convert.ToString(Session["LeadId"])))
            {
                uscMsgBox1.AddMessage("No Lead Id for this loan number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                chkExists(con);
                if (count > 0)
                {
                    uscMsgBox1.AddMessage("Preclosure already done", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                else
                    BindDocGid(con);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
            SqlConnection.ClearPool(con);
        }
    }

    public void getLeadID(SqlConnection con)
    {
        using (SqlCommand cmdbr = new SqlCommand("SP_UNO_BIND_LOAN", con))
        {
            try
            {
                con.Open();
                cmdbr.CommandType = CommandType.StoredProcedure;
                cmdbr.CommandTimeout = 2400000;
                //cmdbr.Parameters.AddWithValue("@LOANNO", txtLeadno.Text.Trim());
                cmdbr.Parameters.AddWithValue("@LD_NO", Convert.ToString(Session["Leadno"]));
                cmdbr.Parameters.AddWithValue("@PTYPE", "GETLEADID");
                Session["LeadId"] = Convert.ToString(cmdbr.ExecuteScalar());
                if (string.IsNullOrEmpty(Convert.ToString(Session["LeadId"])))
                {
                    uscMsgBox1.AddMessage("No Lead Id for this loan number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else
                {
                    chkExists(con);
                    if (count > 0)
                    {
                        uscMsgBox1.AddMessage("Preclosure already done", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        return;
                    }
                    //else
                    //    BindDocGid(con);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmdbr.Dispose();
                con.Close();
                SqlConnection.ClearPool(con);
            }
        }

    }

    protected void btnSubmitPre_Click(object sender, EventArgs e)
    {
        #region DocsCheck
        //If new documents added then no checkboxes checked
        if (Convert.ToString(Session["DOCNEW"]) != "YES")
        {
            CheckBox chkAll = gvMODTDDoc.HeaderRow.FindControl("chkbxAll") as CheckBox;
            if (chkAll.Checked == false)
                go = 0;
            else
            {
                go = 1;
                uscMsgBox1.AddMessage("Please Select all the documents...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        else
        {
            go = 1;
        }
        #endregion

        if (go == 1)
        {
            if (Convert.ToString(Session["DOCNEW"]) != "YES")
            {
                using (SqlConnection connection = new SqlConnection(strcon))
                {
                    connection.Open();
                    try
                    {
                        id = Session["ID"] != null ? Convert.ToInt32(Session["ID"].ToString()) : 0;
                        if (Session["ID"] != null)
                        {
                            id = Convert.ToInt32(Session["ID"].ToString());
                        }
                        else
                        {
                            Response.Redirect("Expire.aspx");
                            return;
                        }
                        cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LeadId"]), connection);
                        var obj = cmd.ExecuteScalar();
                        if (obj == null)
                        {
                            cmd = new SqlCommand("Insert into LSD_MOTD (MD_LD_ID,MD_PDATE,MD_CBY,MD_CDATE,MD_PHO_SDATE,MD_PHO_CR_ID,MD_PHO_POD_NO) values( " + Convert.ToInt32(Session["LeadId"]) + ",getdate()," + id + ",getdate(),getdate()," + ddlName.SelectedValue + ",'" + txtNumber.Text.Trim() + "')", connection);
                            //cmd.ExecuteNonQuery();
                        }
                        else
                        {
                            string upQry = "update LSD_MOTD set MD_PHO_SDATE =getdate(),MD_PHO_CR_ID=" + ddlName.SelectedValue + " ,MD_PHO_POD_NO='" + txtNumber.Text.Trim() + "' where MD_LD_ID=" + Convert.ToInt32(Session["LeadId"]) + "";
                            //cmd = new SqlCommand("", connection);
                            cmd = new SqlCommand("upQry", connection);
                        }
                        //cmd.ExecuteNonQuery();
                        cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection);
                        dtpre = new DataTable();
                        dappre = new SqlDataAdapter(cmd);
                        dappre.Fill(dtpre);
                        Session["MDID"] = dtpre.Rows[0]["MD_ID"] != DBNull.Value ? dtpre.Rows[0]["MD_ID"].ToString() : "";

                    }
                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                    }
                    DataTable dtDocx = (DataTable)ViewState["DocTable"];
                    try
                    {
                        dtDocx.Columns.Remove("DT_DESC");
                        cmd = new SqlCommand("RTS_SP_PRECLOSURE_MOTD", connection);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 2400000;
                        cmd.Parameters.AddWithValue("@MDX_MD_ID", Session["MDID"] != DBNull.Value ? Session["MDID"] : 0);
                        cmd.Parameters.AddWithValue("@MDX_RSTAT", "Received");
                        cmd.Parameters.AddWithValue("@UDTABLE", dtDocx);
                        SqlParameter parmOut = new SqlParameter();
                        parmOut.ParameterName = "@ID";
                        parmOut.SqlDbType = SqlDbType.Int;
                        parmOut.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(parmOut);
                        //cmd.ExecuteNonQuery();
                        int r = Convert.ToInt16(parmOut.Value);
                        //int r = cmd.ExecuteNonQuery();
                        if (r > 0)
                        {
                            panleDoc.Visible = true;
                            BindDocGid(connection);
                        }
                        else
                        {
                            panleDoc.Visible = false;
                            uscMsgBox1.AddMessage("Document not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }

                    }
                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                        uscMsgBox1.AddMessage("Document and Survey & Extent input fields should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    finally
                    {
                        dtDocx.Clear();
                        cmd.Dispose();
                    }

                }
            }
            else
            {
                #region UpdateDocs
                #endregion
            }
        }
    }

    protected void chkExists(SqlConnection con)
    {
        using (SqlCommand cmdExists = new SqlCommand("SP_UNO_BIND_LOAN", con))
        {
            try
            {
                if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                    con.Open();
                cmdExists.CommandType = CommandType.StoredProcedure;
                cmdExists.CommandTimeout = 24800000;
                cmdExists.Parameters.AddWithValue("@LEAD_ID", Convert.ToInt32(Session["LeadId"]));
                cmdExists.Parameters.AddWithValue("@PTYPE", "CHECKEXISTS");
                count = Convert.ToInt16(cmdExists.ExecuteScalar());                
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmdExists.Dispose();
                con.Close();
                SqlConnection.ClearPool(con);
            }
        }

    }

    public void Clear()
    {
        txtLeadno.Text = "";
        ddlName.SelectedIndex = 0;
        txtNumber.Text = "";
        Panel2.Visible = false;
    }

    public void getUNO()
    {
        SqlConnection con = new SqlConnection(strcon);
        DataTable dtNewLead = new DataTable();
        con.Open();
        using (SqlCommand cmdGetLoanDet = new SqlCommand("SP_UNO_BIND_LOAN", con))
        {
            try
            {
                cmdGetLoanDet.CommandType = CommandType.StoredProcedure;
                cmdGetLoanDet.CommandTimeout = 24000000;
                cmdGetLoanDet.Parameters.AddWithValue("@PTYPE", "NEWLEAD");
                cmdGetLoanDet.Parameters.AddWithValue("@LOANNO", txtLeadno.Text.Trim());
                dtNewLead.Load(cmdGetLoanDet.ExecuteReader());
                if(dtNewLead.Rows.Count > 0)
                {
                    loanDte = Convert.ToString(dtNewLead.Rows[0][0]);
                    loanAmt = Convert.ToString(dtNewLead.Rows[0][1]);
                    fullName = Convert.ToString(dtNewLead.Rows[0][2]);
                    branch = Convert.ToString(dtNewLead.Rows[0][3]);
                }
                newLead();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                dtNewLead.Clear();
                dtNewLead.Dispose();
                cmdGetLoanDet.Dispose();
                con.Close();
                SqlConnection.ClearPool(con);
            }
        }
    }

    public void newLead()
    {
        //string branchId = getBrID();
        int leadId = getLdID();
        string leadno = "MIGRATE" + leadId;
    }

    public string getBrID()
    {
        SqlConnection conBrID = new SqlConnection(strcon);
        SqlCommand cmdBrid = new SqlCommand("select BR_ID from MR_BRANCH where BR_NAME ='" + branch + "'", conBrID);
        conBrID.Open();
        string brID = Convert.ToString(cmdBrid.ExecuteScalar());        
        cmdBrid.Dispose();
        conBrID.Close();
        return brID;
    }

    public int getLdID()
    {
        SqlConnection conLead = new SqlConnection(strcon);
        SqlCommand cmdLdid = new SqlCommand("select top 1 LD_ID from LSD_LEAD order by LD_ID  desc", conLead);
        conLead.Open();
        int ldID = Convert.ToInt32(cmdLdid.ExecuteScalar());
        ldID = ldID + 1;
        cmdLdid.Dispose();        
        conLead.Close();
        return ldID;
    }

    public void BindHOSNDDoc()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_LOA", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@AR_ID", ddlArea.SelectedIndex != 0 ? ddlArea.SelectedValue : "");
            cmd.Parameters.AddWithValue("@BR_ID", ddlBranch.SelectedIndex != 0 ? ddlBranch.SelectedValue : "");
            cmd.Parameters.AddWithValue("@PTYPE", "PRECLOSURE");
            cmd.Parameters.AddWithValue("@LOAN_NO", txtLeadno.Text);
            
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            
            gvLegalRecvPreDoc.DataSource = ds.Tables[0];
            gvLegalRecvPreDoc.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvLegalRecvPreDoc.HeaderRow.Font.Bold = true;
                gvLegalRecvPreDoc.HeaderRow.Cells[1].Text = "LOAN NO";
                gvLegalRecvPreDoc.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvLegalRecvPreDoc.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvLegalRecvPreDoc.HeaderRow.Cells[4].Text = "PD DATE";
                gvLegalRecvPreDoc.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvLegalRecvPreDoc.HeaderRow.Cells[6].Text = "BRANCH NAME";


                gvLegalRecvPreDoc.HeaderRow.Cells[1].Wrap = false;
                gvLegalRecvPreDoc.HeaderRow.Cells[2].Wrap = false;
                gvLegalRecvPreDoc.HeaderRow.Cells[3].Wrap = false;
                gvLegalRecvPreDoc.HeaderRow.Cells[4].Wrap = false;
                gvLegalRecvPreDoc.HeaderRow.Cells[5].Wrap = false;
                gvLegalRecvPreDoc.HeaderRow.Cells[6].Wrap = false;

                chkExists(con);
                if (count > 0)
                {
                    uscMsgBox1.AddMessage("Preclosure already done", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No record found", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
        }   
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

            return;
        }
        finally
        {
            con.Close();
        }
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        int ncount = 0;
        foreach (GridViewRow grow in gvLegalRecvPreDoc.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
            LinkButton lnbtnloan = grow.FindControl("lnkLoan") as LinkButton;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                leadno = lnbtn.Text;
                appname = gvLegalRecvPreDoc.Rows[index].Cells[3].Text;
                pddt = gvLegalRecvPreDoc.Rows[index].Cells[4].Text;
                lnamt = gvLegalRecvPreDoc.Rows[index].Cells[5].Text;
                ncount = ncount + 1;
                Session["Leadno"] = leadno;
                isClosed(con, lnbtnloan.Text.Trim());
                getLeadID(con);
                BindDocGid(con);                
            }
        }
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
        con.Close();
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //txtLeadno.Enabled = false;
        txtLeadno.Text = "";
    }

    protected void isClosed(SqlConnection con,string loanNo)
    {
        string isClosed = string.Empty;
        using (SqlCommand cmdExists = new SqlCommand("SP_UNO_BIND_LOAN", con))
        {
            try
            {
                if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                    con.Open();
                cmdExists.CommandType = CommandType.StoredProcedure;
                cmdExists.CommandTimeout = 24800000;
                cmdExists.Parameters.AddWithValue("@LOANNO", Convert.ToString(loanNo));
                cmdExists.Parameters.AddWithValue("@PTYPE", "ISCLOSED");
                isClosed = Convert.ToString(cmdExists.ExecuteScalar());
                if(Convert.ToString(isClosed) != "ClosedA")
                {
                    uscMsgBox1.AddMessage("The Loan is not yet closed.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmdExists.Dispose();
                con.Close();
                SqlConnection.ClearPool(con);
            }
        }
        //return isClosed;
    }
}