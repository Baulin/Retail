﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class HOLegalPreReceiveFile : System.Web.UI.Page
{
    #region Common
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    int ldid, s;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string loanno;
    CreateLogFiles Err = new CreateLogFiles();
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            bind();
        }
    }

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));


    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        //if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--" && txtLeadno.Text == "")
        //{
        //    gvLegalRecvPreDoc.Visible = true;
        //    Session["View"] = "All";            
        //    BindHORECDoc();
        //}

        //else
        //{
        //    gvLegalRecvPreDoc.Visible = true;
        //    Session["View"] = "F";            
        BindHOSNDDoc();

        //}
    }

    public void BindHOSNDDoc()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_ReceiveDoc", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PR_ID", "0");
            cmd.Parameters.AddWithValue("@LD_BR_ID", ddlBranch.SelectedIndex > 0 ? ddlBranch.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@LD_AR_ID", ddlArea.SelectedIndex > 0 ? ddlArea.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@ReceiveType", "PLR");
            cmd.Parameters.AddWithValue("@LoanNo", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@Type", "P");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    btnSubmit.Enabled = false;
            //    Session["Leadno"] = ds.Tables[0].Rows[0]["LD_NO"];
            //    getLeadID(con);
            //}
            //else
            //{
            //    btnSubmit.Enabled = false;
            //    gvPreMODTDDoc.DataSource = null;
            //    gvPreMODTDDoc.DataBind();
            //    txtCourier.Text = "";
            //    txtPODNo.Text = "";
            //    uscMsgBox1.AddMessage("Pre-closure document not send", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            gvLegalRecvPreDoc.DataSource = ds.Tables[0];
            gvLegalRecvPreDoc.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvLegalRecvPreDoc.HeaderRow.Font.Bold = true;
                gvLegalRecvPreDoc.HeaderRow.Cells[1].Text = "LOAN NO";
                gvLegalRecvPreDoc.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvLegalRecvPreDoc.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvLegalRecvPreDoc.HeaderRow.Cells[4].Text = "PD DATE";
                gvLegalRecvPreDoc.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvLegalRecvPreDoc.HeaderRow.Cells[6].Text = "BRANCH NAME";


                gvLegalRecvPreDoc.HeaderRow.Cells[1].Wrap = false;
                gvLegalRecvPreDoc.HeaderRow.Cells[2].Wrap = false;
                gvLegalRecvPreDoc.HeaderRow.Cells[3].Wrap = false;
                gvLegalRecvPreDoc.HeaderRow.Cells[4].Wrap = false;
                gvLegalRecvPreDoc.HeaderRow.Cells[5].Wrap = false;
                gvLegalRecvPreDoc.HeaderRow.Cells[6].Wrap = false;

            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            CheckBox chkAll = gvPreMODTDDoc.HeaderRow.FindControl("chkbxAll") as CheckBox;
            if (chkAll.Checked == false)
            {
                uscMsgBox1.AddMessage("Document/s are missing, Can't be proceed", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("RTS_SP_Update_MODT_DOc_Values", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MD_LD_ID", Session["LeadId"].ToString());
                cmd.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                cmd.Parameters.AddWithValue("@TranStatus", "PLR");
                //cmd.Parameters.AddWithValue("@SendBy", "C");
                //cmd.Parameters.AddWithValue("@CR_ID", ddlName.SelectedIndex > 0 ? ddlName.SelectedValue.ToString() : "");
                //cmd.Parameters.AddWithValue("@PODorCOntatcNo", txtNumber.Text);
                int n = cmd.ExecuteNonQuery();
                if (n > 0)
                {
                    Panel2.Visible = false;
                    trPod.Visible = false;
                    txtLeadno.Text = "";
                    uscMsgBox1.AddMessage("Documents Send Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    BindHOSNDDoc();

                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HOLegalPreReceiveFile.aspx", false);
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        int ncount = 0;
        foreach (GridViewRow grow in gvLegalRecvPreDoc.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                leadno = lnbtn.Text;
                appname = gvLegalRecvPreDoc.Rows[index].Cells[3].Text;
                pddt = gvLegalRecvPreDoc.Rows[index].Cells[4].Text;
                lnamt = gvLegalRecvPreDoc.Rows[index].Cells[5].Text;
                LinkButton lnbtnloan = grow.FindControl("lnkLoan") as LinkButton;
                loanno = lnbtnloan.Text.Trim();
                txtLeadno.Text = loanno;
                ncount = ncount + 1;
                Session["Leadno"] = leadno;
                getLeadID(con);
                BindDocGid(con);
                getPOD(con);
                break;
            }
        }
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
        con.Close();
    }

    public void getLeadID(SqlConnection con)
    {
        try
        {
            //con.Open();
            SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
            cmdbr.CommandType = CommandType.StoredProcedure;
            cmdbr.Parameters.AddWithValue("@LeadNo", Session["Leadno"].ToString());
            SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
            DataSet dsbr = new DataSet();
            dabr.Fill(dsbr);
            if (dsbr.Tables[0].Rows.Count > 0)
            {
                Session["LeadId"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
                //BindDocGid(con);
            }
            //else
            //    uscMsgBox1.AddMessage("No Documents to Receive", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    public void BindDocGid(SqlConnection con)
    {
        try
        {
            //con.Open();
            if (!string.IsNullOrEmpty(Convert.ToString(Session["LeadId"])))
            {
                SqlCommand cmd = new SqlCommand("Select MDX_DOC,MDX_DTYPE from LSD_MOTD_DOCX LMD LEFT JOIN  LSD_MOTD  LM ON LMD.MDX_MD_ID =LM.MD_ID  where MD_LD_ID =" + Session["LeadId"].ToString() + " and MD_PHO_SDATE is not null", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0 && ds.Tables[0] != null)
                {
                    //getPOD(con);
                    trPod.Visible = true;
                    Panel2.Visible = true;
                    //gvPreMODTDDoc.Visible = true;
                    gvPreMODTDDoc.DataSource = ds;
                    gvPreMODTDDoc.DataBind();
                }
                else
                {
                    uscMsgBox1.AddMessage("No Documents to Receive", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    trPod.Visible = false;
                    gvPreMODTDDoc.DataSource = null;
                    gvPreMODTDDoc.DataBind();
                   Panel2.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        //panelAddDoc.Visible = false;
        //Panel2.Visible = false;
        //Panel3.Visible = false;
        DataTable dtpre = new DataTable();
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        using (SqlCommand cmdGetLoanDet = new SqlCommand("SP_UNO_BIND_LOAN1", con))
        {
            try
            {
                cmdGetLoanDet.CommandType = CommandType.StoredProcedure;
                cmdGetLoanDet.CommandTimeout = 24000000;
                cmdGetLoanDet.Parameters.AddWithValue("@PTYPE", "LR");
                cmdGetLoanDet.Parameters.AddWithValue("@LOANNO", txtLeadno.Text.Trim());
                dtpre.Load(cmdGetLoanDet.ExecuteReader());
                gvLegalRecvDoc.DataSource = dtpre;
                gvLegalRecvDoc.DataBind();
                this.mpPre.Show();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmdGetLoanDet.Dispose();
                con.Close();
                SqlConnection.ClearPool(con);
            }
        }
    }

    protected void lnkname_OnClick(object sender, EventArgs e)
    {
        string loanno = ((LinkButton)sender).Text;
        txtLeadno.Text = loanno;
    }

    protected void getPOD(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("select MD_PHO_POD_NO,CR.CR_NAME from LSD_MOTD MD inner join MR_COURIER CR  on CR.CR_ID = MD.MD_PHO_CR_ID  where MD_LD_ID = (select LD_ID from LSD_LEAD where LD_LOAN_NO = '" + loanno + "')", con);
        DataTable dtpod = new DataTable();
        con.Open();
        dtpod.Load(cmd.ExecuteReader());
        if (dtpod.Rows.Count > 0)
        {            
            Panel2.Visible = true;
            btnSubmit.Enabled = true;
            txtCourier.Text = Convert.ToString(dtpod.Rows[0][1]);
            txtPODNo.Text = Convert.ToString(dtpod.Rows[0][0]);
        }
        else
        {
            Panel2.Visible = false;
            btnSubmit.Enabled = false;
            gvPreMODTDDoc.DataSource = null;
            gvPreMODTDDoc.DataBind();
            uscMsgBox1.AddMessage("No Documents to Receive", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }
}