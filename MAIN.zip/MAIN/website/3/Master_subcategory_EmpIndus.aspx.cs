﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_subcategory_EmpIndus : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DataSet dss = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                //"SP_MR_EMP_CATGRY";
                Bindgrid();
            }
        }
    }

    #region "Bindgrid"
    public void Bindgrid()
    {

        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmd = new SqlCommand("SP_MR_EMP_CATGRY", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@TYPE", 1);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dss);

            gvsubcat.DataSource = dss.Tables[0];
            gvsubcat.DataBind();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {

        }
    }
    #endregion

    #region "Submit"
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlsegmentstatus.SelectedIndex == 0)
            {
                uscMsgBox1.AddMessage("Please select the Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                if (btnSubmit.Text == "Submit")
                {
                    InsertUpdate("INSERT");
                }
                else
                {
                    InsertUpdate("Update");
                }
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    #endregion

    #region"InsertUpdate"
    protected void InsertUpdate(string checkactivity)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmdinsert = new SqlCommand("SP_MR_EMP_CATGRY", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@EMP_CT_DESC", txtsubcategory.Text);
            cmdinsert.Parameters.AddWithValue("@EMP_CT_IND", txtempindustry.Text);
            cmdinsert.Parameters.AddWithValue("@EMP_CT_STAT", ddlsegmentstatus.SelectedValue);

            if (checkactivity == "Update")
            {
                cmdinsert.Parameters.AddWithValue("@EMP_CT_MBY", Session["ID"]);
                cmdinsert.Parameters.AddWithValue("@EMP_CT_ID", Session["SC_ID"]);
                cmdinsert.Parameters.AddWithValue("@TYPE", 4);
            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@EMP_CT_CBY", Session["ID"]);
                cmdinsert.Parameters.AddWithValue("@TYPE", 3);
            }

            int r = cmdinsert.ExecuteNonQuery();
            Bindgrid();
            if (r > 0)
            {
                if (checkactivity == "Update")
                {
                    btnSubmit.Text = "Submit";
                }

                clear();
                uscMsgBox1.AddMessage("Records Saved Sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                return;
            }
            else
            {
                uscMsgBox1.AddMessage("Records not saved or Already Exists.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    #endregion  

    #region "Cancel"
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            clear();
            btnSubmit.Text = "Submit";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    #endregion

    #region "Selectedcheckchanged"
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            Label lblSubCategoryId = null;

            foreach (GridViewRow grwrow in gvsubcat.Rows)
            {
                RadioButton chkstat = grwrow.FindControl("rb_select") as RadioButton;
                int index = grwrow.RowIndex;

                if (chkstat.Checked)
                {
                    lblSubCategoryId = (Label)gvsubcat.Rows[index].Cells[1].FindControl("lblSUBCATEGORYID");

                    SqlCommand cmd = new SqlCommand("SP_MR_EMP_CATGRY", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EMP_CT_ID", lblSubCategoryId.Text);
                    cmd.Parameters.AddWithValue("@TYPE", 2);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    Session["SC_ID"] = lblSubCategoryId.Text;

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtsubcategory.Text = Convert.ToString(ds.Tables[0].Rows[0]["EMP_CT_DESC"]);

                        if (ddlsegmentstatus.Items.FindByValue(Convert.ToString(ds.Tables[0].Rows[0]["EMP_CT_STAT"])) != null)
                        {
                            ddlsegmentstatus.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["EMP_CT_STAT"]);
                        }
                        else
                        {
                            ddlsegmentstatus.SelectedIndex = 0;
                        }

                       txtempindustry.Text= Convert.ToString(ds.Tables[0].Rows[0]["EMP_CT_IND"]);
                    }

                    btnSubmit.Text = "Update";
                    break;

                }

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    #endregion

    #region "Clear"
    protected void clear()
    {
        txtsubcategory.Text = "";
        ddlsegmentstatus.SelectedIndex = 0;
        txtempindustry.Text = "";
    }
    #endregion
}