﻿using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using Resources;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;
using Utilities.Enums;
using Utilities.FormValidations;
using Utilities.SessionKeys;

public partial class Report_Declared_Income_Summary_Sheet : System.Web.UI.Page
{
    #region COMMON VARIABLES

    SqlConnection sqlConn;
    SqlCommand sqlCmd;
    SqlDataAdapter sqlDtAdptr;
    DataSet dtSet;

    private bool _creditConditionsVisible = false;
    private bool _deviationsVisible = false;
    private bool _saveDISSuccess = false;
    private bool _saveIncomeDetailsSuccess = false;
    private bool _saveObligationDetailsSuccess = false;
    private bool _obligationDetailsNotAvailable = false;

    private String _leadNo = null;
    private String _applName = null;
    private String _product = null;
    private String _loanAmt = null;

    private String _ConnStr
    {
        get
        {
            String connStr = String.Empty;

            try
            {
                connStr = DbConnectionManager.GetDbConnection();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }

            return connStr;
        }
    }

    public Int64 SessionEMP_ID
    {
        get
        {
            Int64 employeeId = -1;
            var empId = Convert.ToInt64(Session[SessionKeys.EMP_ID]);

            if (empId > 0)
            {
                employeeId = Convert.ToInt32(Session[SessionKeys.EMP_ID]);
            }

            return employeeId;
        }
    }

    public ClsCommon commonClsObj = new ClsCommon();

    #endregion

    #region PAGE EVENTS

    protected void Page_Load(object sender, EventArgs e)
    {
        {
            ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
            scriptManager.RegisterPostBackControl(this.btnPrint);

            if (!IsPostBack)
            {
                try
                {
                    if (Session["ID"] != null)
                    {
                        ViewState[AppConstants.CreditConditionVisible] = _creditConditionsVisible = false;
                        ViewState[AppConstants.DeviationVisible] = _deviationsVisible = false;
                        DisplayOnlySearchPanel();

                        //Reset Session key
                        if (Session[SessionKeys.DATA_MANIPULATION_MODE] != null) { Session[SessionKeys.DATA_MANIPULATION_MODE] = null; }
                    }
                    else
                    {
                        Response.Redirect("default.aspx");
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }
            }
        }
    }

    #endregion

    #region BUTTON EVENTS

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            Boolean passValidation = true;
            DataSet dsDISS = new DataSet();
            DataTable dtDeclaredIncomeSummary = new DataTable();
            DataTable dtIncomeDetails = new DataTable();
            DataTable dtObligationDetails = new DataTable();

            Reset();
            DisplayOnlySearchPanel();

            if (txtBxLeadno == null || txtBxLeadno.Text == "" || String.IsNullOrEmpty(txtBxLeadno.Text) || String.IsNullOrWhiteSpace(txtBxLeadno.Text))
            {
                passValidation = false;
                uscMsgBox1.AddMessage(Report_BusinessMessages.MSG_LEAD_NO_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }

            if (passValidation)
            {
                String leadNo = txtBxLeadno.Text;
                dsDISS = GetDeclaredIncomeSummaryForLeadNo(leadNo);

                if (dsDISS != null
                    && dsDISS.Tables.Count == 3
                    && dsDISS.Tables[0].Rows.Count > 0
                    && dsDISS.Tables[1].Rows.Count > 0)
                {
                    dtDeclaredIncomeSummary = dsDISS.Tables[0];
                    dtIncomeDetails = dsDISS.Tables[1];
                    dtObligationDetails = dsDISS.Tables[2];

                    {
                        tblApprovalSummary.Visible = true;

                        incomeDetailsPanel.Visible = true;
                        obligationDetailsPanel.Visible = true;

                        gvIncomeDetail.Visible = true;
                        gvObligationDetail.Visible = true;

                        lblDeviations.Visible = true;
                        lblCreditConditions.Visible = true;

                        tblPropertyDetails.Visible = true;
                        tblFinalRecommendation.Visible = true;

                        tblConditions.Visible = true;

                        printPanel.Visible = true;

                        Int64 prodId = Convert.ToInt64(dtDeclaredIncomeSummary.Rows[0]["LD_PR_ID"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["LD_PR_ID"].ToString() : "");

                        if ((prodId == Convert.ToInt64(Declared_Product_Program.IB_SME_Secured_D))
                            || (prodId == Convert.ToInt64(Declared_Product_Program.Salaried_LAP)))
                        {
                            tblCREClassificationSMESLAP.Visible = true;
                            SME_SLAP_Built_UpArea.Visible = true;
                            SME_SLAP_Built_UpCost.Visible = true;
                            SME_SLAP_BuildingCost.Visible = true;

                            tblCREClassificationAHF.Visible = false;
                            AHF_Built_UpArea.Visible = false;
                            AHF_Built_UpCost.Visible = false;
                            AHF_BuildingValue.Visible = false;

                            AHF_LCR.Visible = false;
                            AHF_NO_OF_PROPERTY_ALREADY_OWNED.Visible = false;
                            AHF_NO_OF_PROPERTY_TO_BE_OWNED.Visible = false;
                        }
                        else if (prodId == Convert.ToInt64(Declared_Product_Program.Housing_IB_AHF)
                            || prodId == Convert.ToInt64(Declared_Product_Program.IB_Affordable_Home))
                        {
                            tblCREClassificationSMESLAP.Visible = false;
                            SME_SLAP_Built_UpArea.Visible = false;
                            SME_SLAP_Built_UpCost.Visible = false;
                            SME_SLAP_BuildingCost.Visible = false;

                            tblCREClassificationAHF.Visible = true;
                            AHF_Built_UpArea.Visible = true;
                            AHF_Built_UpCost.Visible = true;
                            AHF_BuildingValue.Visible = true;

                            AHF_LCR.Visible = true;
                            AHF_NO_OF_PROPERTY_ALREADY_OWNED.Visible = true;
                            AHF_NO_OF_PROPERTY_TO_BE_OWNED.Visible = true;
                        }
                    }

                    if (dtDeclaredIncomeSummary != null && dtDeclaredIncomeSummary.Rows.Count > 0)
                    {
                        #region APPROVAL SUMMARY

                        lblLeadNo.Text = dtDeclaredIncomeSummary.Rows[0]["LD_NO"] != DBNull.Value ? Convert.ToString(dtDeclaredIncomeSummary.Rows[0]["LD_NO"]) : String.Empty;
                        lblProduct.Text = dtDeclaredIncomeSummary.Rows[0]["PR_CODE"] != DBNull.Value ? Convert.ToString(dtDeclaredIncomeSummary.Rows[0]["PR_CODE"]) : String.Empty;

                        if (dtDeclaredIncomeSummary.Rows[0]["AR_NAME"] != DBNull.Value && dtDeclaredIncomeSummary.Rows[0]["BR_NAME"] != DBNull.Value)
                        {
                            String areaBranch = dtDeclaredIncomeSummary.Rows[0]["AR_NAME"].ToString() + "/" + dtDeclaredIncomeSummary.Rows[0]["BR_NAME"].ToString();
                            lblAreaBranch.Text = !String.IsNullOrEmpty(areaBranch) ? areaBranch : String.Empty;
                        }

                        lblCustName.Text = dtDeclaredIncomeSummary.Rows[0]["LD_APNAME"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["LD_APNAME"].ToString() : "";
                        lblProgram.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_PROG"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_PROG"].ToString() : "";

                        #endregion

                        #region INCOME DETAILS

                        gvIncomeDetail.DataSource = dtIncomeDetails;
                        gvIncomeDetail.DataBind();

                        if (dtIncomeDetails != null && dtIncomeDetails.Rows.Count > 0)
                        {
                            gvIncomeDetail.DataSource = dtIncomeDetails;
                            gvIncomeDetail.DataBind();

                            Double currIncome = 0.0;
                            Double totIncome = 0.0;
                            foreach (DataRow drIncome in dtIncomeDetails.Rows)
                            {
                                Double.TryParse(Convert.ToString(drIncome["INCOME"]), out currIncome);
                                totIncome = currIncome + totIncome;
                            }

                            lblTotalIncome.Text = Convert.ToString(totIncome);
                        }

                        #endregion

                        #region OBLIGATION DETAILS

                        if (dtObligationDetails != null && dtObligationDetails.Rows.Count > 0)
                        {
                            gvObligationDetail.DataSource = dtObligationDetails;
                            gvObligationDetail.DataBind();

                            Double currObligation = 0.0;
                            Double totObligation = 0.0;
                            foreach (DataRow drObligation in dtObligationDetails.Rows)
                            {
                                Double.TryParse(Convert.ToString(drObligation["OBLG_AMT"]), out currObligation);
                                totObligation = currObligation + totObligation;
                            }

                            lblTotalObligation.Text = Convert.ToString(totObligation);
                        }

                        #endregion

                        #region PROPERTY DETAILS

                        lblPropertyType.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_PTYPE"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_PTYPE"].ToString() : "";
                        lblOccupancyStatus.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_OCCSTAT"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_OCCSTAT"].ToString() : "";
                        lblLandAreaInSqft.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_LAREA"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_LAREA"].ToString() : "";
                        lblLandValuePerSqft.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_LVALUE"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_LVALUE"].ToString() : "";
                        lblTotalLandValue.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_TOT_LVALUE"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_TOT_LVALUE"].ToString() : "";

                        lblBuiltUpAreaInSqft.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_BAREA"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_BAREA"].ToString() : "";
                        lblBuildUpCostPerSqft.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_BVALUE"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_BVALUE"].ToString() : "";
                        lblTotalBuildingValue.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_TOT_BVALUE"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_TOT_BVALUE"].ToString() : "";

                        lblConstructionAreaInSqft.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_BAREA"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_BAREA"].ToString() : "";
                        lblConstructionCostPerSqft.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_BVALUE"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_BVALUE"].ToString() : "";
                        lblTotalConstructionValue.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_TOT_BVALUE"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_TOT_BVALUE"].ToString() : "";

                        lblAmenities.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_AMENITIES"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_AMENITIES"].ToString() : "";
                        lblTotalPropertyValue.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_TOT_PVALUE"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_TOT_PVALUE"].ToString() : "";

                        #endregion

                        #region FINAL RECOMMENDATION

                        lblTenor.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_TENOR"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_TENOR"].ToString() : "";
                        lblROI.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_ROI"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_ROI"].ToString() : "";
                        lblFinalLoanAmount.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_FIN_LAMOUNT"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_FIN_LAMOUNT"].ToString() : "";
                        lblEMI.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_EMI"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_EMI"].ToString() : "";
                        lblApprovedIIR.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_APP_IIR"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_APP_IIR"].ToString() : "";
                        lblApprovedFOIR.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_APP_FOIR"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_APP_FOIR"].ToString() : "";
                        lblLTV.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_LTV"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_LTV"].ToString() : "";
                        lblLCR.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_LCR"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_LCR"].ToString() : "";

                        lblNoOfPropertyAlreadyOwned.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_NOP_AL_OWN"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_NOP_AL_OWN"].ToString() : "";
                        lblNoOfPropertyToBeOwned.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_NOP_TB_OWN"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_NOP_TB_OWN"].ToString() : "";

                        lblCREClassificationAHF.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_CRE"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_CRE"].ToString() : "";
                        lblDeviations.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_DEVIATION"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_DEVIATION"].ToString() : "";
                        lblCreditConditions.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_CRDT_COND"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_CRDT_COND"].ToString() : "";

                        lblFileRecommendedBy.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_FILE_RECOMD_BY"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_FILE_RECOMD_BY"].ToString() : "";
                        lblFileApprovedBy.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_FILE_APPRVD_BY"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_FILE_APPRVD_BY"].ToString() : "";
                        lblOfflineMailApprovedBy.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_FILE_OFFL_MAIL_APPRVD_BY"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_FILE_OFFL_MAIL_APPRVD_BY"].ToString() : "";
                        lblApprovedDate.Text = dtDeclaredIncomeSummary.Rows[0]["DIS_FILE_APPRVD_DT"] != DBNull.Value ? dtDeclaredIncomeSummary.Rows[0]["DIS_FILE_APPRVD_DT"].ToString() : "";

                        #endregion
                    }

                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_GENERIC, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {

    }

    protected void btnPrint_Click(object sender, EventArgs e)
    {
        try
        {
            Response.ClearHeaders();
            Response.AddHeader("content-disposition", "attachment;filename=DIS_" + txtBxLeadno.Text + ".pdf");
            Response.ContentType = "application/pdf";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            StringWriter strWrtr1 = new StringWriter();
            HtmlTextWriter htmlTxtWrtr1 = new HtmlTextWriter(strWrtr1);
            pnlApprvSummary.RenderControl(htmlTxtWrtr1);

            StringWriter strWrtr2 = new StringWriter();
            HtmlTextWriter htmlTxtWrtr2 = new HtmlTextWriter(strWrtr2);
            pnlIncomeDetails.RenderControl(htmlTxtWrtr2);

            StringWriter strWrtr3 = new StringWriter();
            HtmlTextWriter htmlTxtWrtr3 = new HtmlTextWriter(strWrtr3);
            pnlObligationDetails.RenderControl(htmlTxtWrtr3);

            StringWriter strWrtr4 = new StringWriter();
            HtmlTextWriter htmlTxtWrtr4 = new HtmlTextWriter(strWrtr4);
            pnlRestOfPage.RenderControl(htmlTxtWrtr4);

            StringReader strRdr = new StringReader(strWrtr1.ToString() + "<br/>" + strWrtr2.ToString() + "<br/>" + strWrtr3.ToString() + "<br/>" + strWrtr4.ToString());
            //Response.AddHeader("Content-Length", strRdr.ReadToEnd().Length.ToString());

            Document pdf = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            HTMLWorker htmlWrkr = new HTMLWorker(pdf);
            PdfWriter.GetInstance(pdf, Response.OutputStream);

            pdf.Open();
            pdf.NewPage();
            pdf.HtmlStyleClass = "PdfClass";
            htmlWrkr.Parse(strRdr);
            pdf.Close();

            Response.Write(pdf);
            Response.End();
        }
        catch (ThreadAbortException)
        {
            //ErrorLog.WriteError(threadAbrtEx);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_GENERIC, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }

    #endregion

    #region GRID EVENTS

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* We are overriding VerifyRenderingInServerForm here. This is to avoid gridview from Raising below exception
         * "Control 'MainContent_gvIncomeDetail' of type 'GridView' must be placed inside a form tag with runat=server."
         *  */
    }

    #endregion
    #region CRUD

    #region GET

    private DataSet GetDeclaredIncomeSummaryForLeadNo(String leadNo)
    {
        try
        {
            using (sqlConn = new SqlConnection(_ConnStr))
            {
                sqlConn.Open();
                sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_RPT_DECLARED_INCOME_SUMMARY_SHEET, sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandTimeout = 1200000;
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_Lead_No, leadNo);
                sqlDtAdptr = new SqlDataAdapter(sqlCmd);
                dtSet = new DataSet();
                sqlDtAdptr.Fill(dtSet);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return dtSet;
    }

    #endregion

    #endregion

    #region PRIVATE METHODS

    private void DisplayOnlySearchPanel()
    {
        try
        {
            srchPanel.Visible = true;
            tblApprovalSummary.Visible = false;

            incomeDetailsPanel.Visible = false;
            obligationDetailsPanel.Visible = false;

            gvIncomeDetail.Visible = false;
            tblTotalIncome.Visible = false;
            gvObligationDetail.Visible = false;
            tblTotalObligation.Visible = false;
            tblCREClassificationSMESLAP.Visible = false;
            tblPropertyDetails.Visible = false;
            tblFinalRecommendation.Visible = false;
            tblCREClassificationAHF.Visible = false;
            tblConditions.Visible = false;

            lblDeviations.Visible = false;
            lblCreditConditions.Visible = false;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void Reset()
    {
        try
        {
            //Approval Summary
            lblLeadNo.Text = String.Empty;
            lblProduct.Text = String.Empty;
            lblAreaBranch.Text = String.Empty;
            lblCustName.Text = String.Empty;

            //CRE Classification
            if (lblCREClassificationAHF != null && lblCREClassificationAHF.Visible == true)
            {
                lblCREClassificationAHF.Text = String.Empty;
            }

            if (lblCREClassificationSMESLAP != null && lblCREClassificationSMESLAP.Visible == true)
            {
                lblCREClassificationSMESLAP.Text = String.Empty;
            }

            //Income Details
            lblTotalIncome.Text = String.Empty;

            //Obligation Details
            lblTotalObligation.Text = String.Empty;

            //Property Details
            if (lblPropertyType != null && lblPropertyType.Visible == true)
            {
                lblPropertyType.Text = String.Empty;
            }

            if (lblLandAreaInSqft != null && lblLandAreaInSqft.Visible == true)
            {
                lblLandAreaInSqft.Text = String.Empty;
                lblLandValuePerSqft.Text = String.Empty;
                lblTotalLandValue.Text = String.Empty;
            }

            if (lblBuiltUpAreaInSqft != null && lblBuiltUpAreaInSqft.Visible == true)
            {
                lblBuiltUpAreaInSqft.Text = String.Empty;
                lblBuildUpCostPerSqft.Text = String.Empty;
                lblTotalBuildingValue.Text = String.Empty;
            }

            if (lblConstructionAreaInSqft != null && lblConstructionAreaInSqft.Visible == true)
            {
                lblConstructionAreaInSqft.Text = String.Empty;
                lblConstructionCostPerSqft.Text = String.Empty;
                lblTotalConstructionValue.Text = String.Empty;
            }

            lblAmenities.Text = String.Empty;
            lblTotalPropertyValue.Text = String.Empty;

            //Final Recommendation
            lblTenor.Text = String.Empty;
            lblROI.Text = String.Empty;
            lblFinalLoanAmount.Text = String.Empty;
            lblEMI.Text = String.Empty;
            lblApprovedIIR.Text = String.Empty;
            lblApprovedFOIR.Text = String.Empty;
            lblLTV.Text = String.Empty;
            lblLCR.Text = String.Empty;

            //Remarks
            lblDeviations.Text = String.Empty;
            lblCreditConditions.Text = String.Empty;

            //Approver Details
            lblFileRecommendedBy.Text = String.Empty;
            lblOfflineMailApprovedBy.Text = String.Empty;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    #endregion
}