﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Branch_DSA_ResolveQuery : System.Web.UI.Page
{
    string bcacode;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string lProduct = "";
    string lQuery = "";
    string rcvquery;
    int prid;
    string query;
    int ldid;
    int qryid;
    int qryldid;
    int selectedcnt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UNITNAME"] != null)
            {
                txtdate.Text = String.Format("{0:dd MMM yyyy}", dt);
                // txtBranch.Text = Session["UNITNAME"].ToString();
                bindArea();
                bind();
            }
            else
            {
                Response.Redirect("expire.aspx");
            }
        }
    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;


    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();
        ddlProduct.DataSource = dsdd;
        ddlProduct.DataTextField = "PR_CODE";
        ddlProduct.DataValueField = "PRD";
        ddlProduct.DataBind();
        ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            //if (ddlQuery.SelectedValue.ToString() == "QC")
            //{    
            GridView dgQuery = ddlQuery.SelectedValue.ToString() == "QC" ? gvQuerydets : gvQuerydets1;
            dgQuery.Visible = false;
            foreach (GridViewRow grow in gvResolve.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                Label lbldsaid = grow.FindControl("lbldsaid") as Label;
                //DropDownList ddrsp = grow.FindControl("Editdd") as DropDownList;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    leadno = lnbtn.Text;
                    appname = gvResolve.Rows[index].Cells[3].Text;
                    pddt = gvResolve.Rows[index].Cells[2].Text;
                    //lnamt = gvResolve.Rows[index].Cells[5].Text;
                    //lQuery = gvResolve.Rows[index].Cells[7].Text;

                    //rcvquery = gvResolve.Rows[index].Cells[6].Text;
                    Session["BCAId"] = lbldsaid.Text;
                }
            }
            Session["BCACODE"] = leadno;
            //getLeadID(con);
            qrydetsbind(lQuery);
            Panel2.Visible = true;
            Panel3.Visible = true;
            if (ddlQuery.SelectedValue.ToString() == "QC" || lQuery == "QC")
            {

            }
            else
            {

            }

            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;




            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void getLeadID(SqlConnection con)
    {
        //SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
        //cmdbr.CommandType = CommandType.StoredProcedure;
        //cmdbr.Parameters.AddWithValue("@LeadNo", Session["Leadno"].ToString());
        //SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        //DataSet dsbr = new DataSet();
        //dabr.Fill(dsbr);
        DataSet dsbr = new DataSet();
        dsbr = clscommon.GetBCApplicationForm_Details_ByBCACODE(Session["BCACODE"].ToString());
        Session["BCAId"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["BCA_ID"]);
    }
    public void qrydetsbind(string QueryVal)
    {
        try
        {
            string strQRY_RSD_BY = "";
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            //SqlCommand cmdqryid = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + Session["Leadno"].ToString() + "'", con);
            //SqlDataAdapter daqryid = new SqlDataAdapter(cmdqryid);
            //DataSet dsqryid = new DataSet();
            //daqryid.Fill(dsqryid);
            // qryldid = Convert.ToInt32(dsqryid.Tables[0].Rows[0]["LD_ID"]);

            GridView gvQuery = null;
            if (ddlQuery.SelectedValue.ToString() == "QC" || QueryVal == "QC")
            {
                strQRY_RSD_BY = "H";
                gvQuery = gvQuerydets;
            }
            else if (ddlQuery.SelectedValue.ToString() == "Credit" || QueryVal == "Credit")
            {
                strQRY_RSD_BY = "C";
                gvQuery = gvQuerydets1;
            }
            else if (ddlQuery.SelectedValue.ToString() == "Legal" || QueryVal == "Legal")
            {
                strQRY_RSD_BY = "L";
                gvQuery = gvQuerydets1;
            }

            gvQuery = gvQuerydets;
            qryldid = Session["BCAId"] != null ? Convert.ToInt32(Session["BCAId"]) : 0;

            SqlCommand cmdqry = new SqlCommand("RTS_SP_FETCH_LSD_DSA_QUERY", con);
            cmdqry.CommandType = CommandType.StoredProcedure;
            cmdqry.Parameters.AddWithValue("@QRY_DSA_ID", qryldid);
            cmdqry.Parameters.AddWithValue("@QRY_RSD_BY", ddlQuery.SelectedValue.ToString());
            SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
            DataSet dsqry = new DataSet();
            daqry.Fill(dsqry);
            if (dsqry.Tables[0].Rows.Count > 0)
            {
                gvQuery.DataSource = dsqry.Tables[0];
                gvQuery.DataBind();
                gvQuery.Visible = true;
            }
            else
            {

                uscMsgBox1.AddMessage("No Record Found !", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            con.Close();

            //if (ddlQuery.SelectedValue.ToString() == "QC")
            //{
            //    SqlCommand cmdqry = new SqlCommand("SELECT QRY_ID,QRY_SQUERY FROM LSD_QUERY where QRY_LD_ID='" + qryldid + "' and isnull(QRY_RESP_DATE,'')='' AND QRY_RSD_BY='H'", con);
            //    SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
            //    DataSet dsqry = new DataSet();
            //    daqry.Fill(dsqry);
            //    gvQuerydets.DataSource = dsqry.Tables[0];
            //    gvQuerydets.DataBind();
            //    gvQuerydets.Visible = true;
            //}
            //else if (ddlQuery.SelectedValue.ToString() == "Credit")
            //{
            //    SqlCommand cmdqry = new SqlCommand("SELECT QRY_ID,QRY_QUERY FROM LSD_QUERY where QRY_LD_ID='" + qryldid + "' and isnull(QRY_RESP_DATE,'')='' AND QRY_RSD_BY='C'", con);
            //    SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
            //    DataSet dsqry = new DataSet();
            //    daqry.Fill(dsqry);
            //    gvQuerydets1.DataSource = dsqry.Tables[0];
            //    gvQuerydets1.DataBind();
            //    gvQuerydets1.Visible = true;
            //}
            //else if (ddlQuery.SelectedValue.ToString() == "Legal")
            //{
            //    SqlCommand cmdqry = new SqlCommand("SELECT QRY_ID,QRY_QUERY FROM LSD_QUERY where QRY_LD_ID='" + qryldid + "' and isnull(QRY_RESP_DATE,'')='' AND QRY_RSD_BY='L'", con);
            //    SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
            //    DataSet dsqry = new DataSet();
            //    daqry.Fill(dsqry);
            //    gvQuerydets1.DataSource = dsqry.Tables[0];
            //    gvQuerydets1.DataBind();
            //    gvQuerydets1.Visible = true;
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    public void InsertBranchResolveQueriesVal()
    {
        GridView dgQuery = null;

        // dgQuery = ddlQuery.SelectedValue.ToString() == "QC" ? gvQuerydets : gvQuerydets1;
        dgQuery = gvQuerydets;

        DataTable dtLeadQuery = new DataTable();
        DataRow dr = null;
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        dtLeadQuery.Columns.Add("QRY_RESPONSE", typeof(string));
        dtLeadQuery.Columns.Add("QRY_MBY", typeof(string));
        dtLeadQuery.Columns.Add("QRY_DSA_ID", typeof(string));
        dtLeadQuery.Columns.Add("QRY_ID", typeof(string));
        try
        {
            selectedcnt = 0;

            foreach (GridViewRow grow in dgQuery.Rows)
            {

                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;

                if (chkStat.Checked)
                {
                    selectedcnt = selectedcnt + 1;


                    DropDownList ddrsp = grow.FindControl("Editdd") as DropDownList;
                    Label lbquery = grow.FindControl("lblname") as Label;
                    Label lbqueryid = grow.FindControl("lblqryid") as Label;
                    TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
                    string resp = ddrsp.SelectedValue.ToString();
                    string remarks = txtRemarks.Text.Replace("'", "''");
                    if (remarks != "")
                    {
                        resp = resp + "-" + remarks;
                    }
                    int qryid = Convert.ToInt32(lbqueryid.Text);

                    ldid = Convert.ToInt32(Session["BCAId"]);

                    dr = dtLeadQuery.NewRow();

                    dr["QRY_RESPONSE"] = resp;
                    dr["QRY_MBY"] = Session["ID"].ToString();
                    dr["QRY_DSA_ID"] = ldid;
                    dr["QRY_ID"] = qryid;
                    dtLeadQuery.Rows.Add(dr);

                    //if (ddlQuery.SelectedValue.ToString() != "QC")
                    //{


                    //}



                }
                //else if (!chkStat.Checked)
                //{
                //    selectedcnt--;
                //}
            }


            if (dtLeadQuery.Rows.Count > 0)
            {
                SqlCommand cmdupdate = new SqlCommand("RTS_UPDATE_LSD_DSA_QUERY", con);
                cmdupdate.CommandType = CommandType.StoredProcedure;
                cmdupdate.Parameters.AddWithValue("@tblLeadQueries", dtLeadQuery);

                int ncmdupdate = cmdupdate.ExecuteNonQuery();

                gvResolve.DataSource = null;
                gvResolve.DataBind();
                gridbind();

                Panel2.Visible = false;
                Panel3.Visible = false;
                dgQuery.Visible = false;
                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
                //txtResolve.Text = "";
                btnSubmit.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
        if (selectedcnt <= 0)
        {


            uscMsgBox1.AddMessage("Please Select Query To Response", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            uscMsgBox1.AddMessage("Query Responded Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }
        // gvResolve.Visible = false;


    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {


            InsertBranchResolveQueriesVal();
        }

        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_DSA_ResolveQuery.aspx");
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlQuery.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please select Query Option", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                Session["View"] = "All";
                gridbind();
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void gridbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmdprid = new SqlCommand("select PR_ID from MR_PRODUCT WHERE PR_CODE='" + ddlProduct.SelectedValue.ToString() + "'", con);
            //SqlDataAdapter daprid = new SqlDataAdapter(cmdprid);
            //DataSet dsprid = new DataSet();
            //daprid.Fill(dsprid);
            //prid = Convert.ToInt32(ddlProduct.SelectedValue);

            string[] PRARR = ddlProduct.SelectedIndex > 0 ? ddlProduct.SelectedValue.ToString().Split('-') : null;
            if (PRARR != null)
            {
                prid = Convert.ToInt32(PRARR[0].ToString());
            }
            else prid = 0;
            query = "";
            if (ddlQuery.SelectedValue.ToString() == "Credit")
            {
                query = "C";
            }
            else if (ddlQuery.SelectedValue.ToString() == "Legal")
            {
                query = "L";
            }
            else if (ddlQuery.SelectedValue.ToString() == "QC")
            {
                query = "H";
            }
            Session["QRYBY"] = query;

            SqlCommand cmd = new SqlCommand("RTS_SP_DSA_APPLICATION", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PTYPE", "GET_DSA_QRY_DATA");
            //cmd.Parameters.AddWithValue("@DSA_TYPE", "HO_QRY_RESOLVE");
            cmd.Parameters.AddWithValue("@DSA_CODE", txtDSACODE.Text);
            cmd.Parameters.AddWithValue("@QryType", ddlQuery.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@DSA_TYPE", "BR_RESOLVE_QRY");
            cmd.Parameters.AddWithValue("@AR_ID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_ID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "");



            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //Panel1.Visible = true;
            gvResolve.DataSource = ds.Tables[0];
            gvResolve.DataBind();
           
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                //e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[7].HorizontalAlign = HorizontalAlign.Left;
            //e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        string qryby = Session["QRYBY"].ToString();
        Session["sa2"] = qryby;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Branch_ResolveQueryPopup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    protected void ddlQuery_SelectedIndexChanged(object sender, EventArgs e)
    {
        //qrydetsbind();
        // gvResolve.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;
        gvQuerydets.Visible = false;
    }
    protected void ddlProduct_SelectedIndexChanged(object sender, EventArgs e)
    {
        // gvResolve.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;
        gvQuerydets.Visible = false;
    }
}