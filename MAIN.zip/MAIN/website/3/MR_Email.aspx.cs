﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class MR_Email : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {              
            
                bindArea();
             
            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }

    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
   
    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_EM_MASTER", con);
        cmddd.Parameters.AddWithValue("@BranchID", ddlBranch.SelectedItem.Text  != "--Select--"?ddlBranch.SelectedValue.ToString() :"");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();

        if (dsdd.Tables[0] != null)
        {
            if (dsdd.Tables[0].Rows.Count > 0)
            {
                btnSubmit.Text = "Update";
                txtBM.Text = dsdd.Tables[0].Rows[0]["EM_BM"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_BM"].ToString() : "";
                txtRPA.Text = dsdd.Tables[0].Rows[0]["EM_RPA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_RPA"].ToString() : "";
                txtAM.Text = dsdd.Tables[0].Rows[0]["EM_AM"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_AM"].ToString() : "";
                txtCMCODE.Text = dsdd.Tables[0].Rows[0]["EM_CLM_CODE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_CLM_CODE"].ToString() : "";
                txtCLMName.Text = dsdd.Tables[0].Rows[0]["EM_CLM_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_CLM_NAME"].ToString() : "";
                txtCLM.Text = dsdd.Tables[0].Rows[0]["EM_CLM"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_CLM"].ToString() : "";
                txtCM.Text = dsdd.Tables[0].Rows[0]["EM_CM"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_CM"].ToString() : "";
                txtLG.Text = dsdd.Tables[0].Rows[0]["EM_LG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_LG"].ToString() : "";
                txtHO.Text = dsdd.Tables[0].Rows[0]["EM_HO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_HO"].ToString() : "";
                txtHD.Text = dsdd.Tables[0].Rows[0]["EM_HD"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_HD"].ToString() : "";
                txtBCC.Text = dsdd.Tables[0].Rows[0]["EM_BCC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_BCC"].ToString() : "";
                txtIT.Text = dsdd.Tables[0].Rows[0]["EM_IT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EM_IT"].ToString() : "";

            }
         
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmddd = new SqlCommand("RTS_SP_Update_EM_MASTER", con);
                cmddd.Parameters.AddWithValue("@BranchID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "");
                cmddd.Parameters.AddWithValue("@EM_BM", txtBM.Text);
                cmddd.Parameters.AddWithValue("@EM_RPA", txtRPA.Text);
                cmddd.Parameters.AddWithValue("@EM_AM", txtAM.Text);
                cmddd.Parameters.AddWithValue("@EM_CLM_CODE", txtCMCODE.Text);
                cmddd.Parameters.AddWithValue("@EM_CLM_NAME", txtCLMName.Text);
                cmddd.Parameters.AddWithValue("@EM_CLM", txtCLM.Text);
                cmddd.Parameters.AddWithValue("@EM_CM", txtCM.Text);
                cmddd.Parameters.AddWithValue("@EM_LG", txtLG.Text);
                cmddd.Parameters.AddWithValue("@EM_HO", txtHO.Text);
                cmddd.Parameters.AddWithValue("@EM_HD", txtHD.Text);
                cmddd.Parameters.AddWithValue("@EM_IT", txtIT.Text);
                cmddd.Parameters.AddWithValue("@EM_BCC", txtBCC.Text);
                if (btnSubmit.Text == "Update")
                {
                    cmddd.Parameters.AddWithValue("@QType", "U");
                }
                else
                {
                    cmddd.Parameters.AddWithValue("@QType", "I");
                }

                cmddd.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                cmddd.CommandType = CommandType.StoredProcedure;
              int res= cmddd.ExecuteNonQuery();
                  
                if (btnSubmit.Text == "Update")
                {

                    if (res > 0)
                    {
                        btnSubmit.Text = "Submit";
                        uscMsgBox1.AddMessage("Email Master Updated Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Email Master Not Updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
                else
                {

                    if (res > 0)
                    {
                        uscMsgBox1.AddMessage("Email Master Inserted Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Email Master Not Inserted", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
                con.Close();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                uscMsgBox1.AddMessage("Email Master Not Inserted / Updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("MR_Email.aspx");
    }
}

 