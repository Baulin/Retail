﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Configuration;
using System.Data;
using Tracker;

public partial class Branch_RPA_Report : System.Web.UI.Page
{
    SqlConnection conObj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmdObj = new SqlCommand();
    SqlDataAdapter ap = new SqlDataAdapter();
    DataTable resdt = new DataTable();
    ReportDocument rpt = new ReportDocument();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
        }
        else Response.Redirect("~/Default.aspx");
    }
    protected void ServerDetails(out string user, out string pwd, out string ser, out string db)
    {
        string usr, pd, sr;
        SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
        usr = builder.UserID;
        pd = builder.Password;
        sr = builder.DataSource;
        db = builder.InitialCatalog;
        user = usr;
        pwd = pd;
        ser = sr;



    }
    protected void btnrpareport_Click(object sender, EventArgs e)
    {
        try
        {

            cmdObj = new SqlCommand("RTS_SP_RPA_REPORT", conObj);
            cmdObj.CommandType = CommandType.StoredProcedure;
            cmdObj.Parameters.AddWithValue("@LEADNO", txtbxrpaldno.Text);
            cmdObj.CommandTimeout = 180000;
            if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
                conObj.Open();
            ap = new SqlDataAdapter(cmdObj);
            ap.Fill(resdt);
            if (resdt.Rows.Count > 0)
            {
                rpt = new ReportDocument();

                rpt.Load(Server.MapPath("~/Reports/Risk_Property_Assessment_Report.rpt"));
                string user, pwd, ser, db;

                ServerDetails(out user, out pwd, out ser, out db);
                rpt.SetDatabaseLogon(user, pwd, @ser, db);
                //assign the values to crystal report viewer

                rpt.SetParameterValue(0, txtbxrpaldno.Text);


                rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Risk Property Assessment Report " + txtbxrpaldno.Text);
            }
            else
            {
                uscMsgBox1.AddMessage("No RPA Entries found for the Lead Number " + txtbxrpaldno.Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtbxrpaldno.Focus();
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            conObj.Close();
            rpt.Close();
            rpt.Dispose();
            rpt = null;
            GC.Collect();
 
        }

    }
}