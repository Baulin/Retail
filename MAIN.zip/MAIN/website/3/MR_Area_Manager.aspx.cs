﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;


public partial class MR_Area_Manager : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {

                bindArea();

            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        //   bindBranch();

    }

    //public void bindBranch()
    //{
    //    SqlConnection con = new SqlConnection(strcon);
    //    con.Open();
    //    SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
    //    SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
    //    DataSet dsrsn = new DataSet();
    //    darsn.Fill(dsrsn);
    //    con.Close();

    //    ddlBranch.DataSource = dsrsn;
    //    ddlBranch.DataTextField = "BR_NAME";
    //    ddlBranch.DataValueField = "BR_ID";
    //    ddlBranch.DataBind();
    //    ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
    //    if (Session["USR_ACS"].ToString() == "7")
    //    {
    //        ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
    //        ddlBranch.Enabled = false;
    //        ddlArea.Enabled = false;
    //    }
    //}
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_AR_Manager_MASTER", con);
        cmddd.Parameters.AddWithValue("@AM_AR_ID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue.ToString() : "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();

        if (dsdd.Tables[0] != null)
        {
            if (dsdd.Tables[0].Rows.Count > 0)
            {
                btnSubmit.Text = "Update";
                txtEmoID.Text = dsdd.Tables[0].Rows[0]["AM_EMPID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_EMPID"].ToString() : "";
                txtName.Text = dsdd.Tables[0].Rows[0]["AM_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_NAME"].ToString() : "";
                txtPhnO.Text = dsdd.Tables[0].Rows[0]["AM_PHNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_PHNO"].ToString() : "";
                txtEmail.Text = dsdd.Tables[0].Rows[0]["AM_EMAIL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_EMAIL"].ToString() : "";
                txtCM.Text = dsdd.Tables[0].Rows[0]["AM_CM"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_CM"].ToString() : "";
                txtSCI.Text = dsdd.Tables[0].Rows[0]["AM_SCI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_SCI"].ToString() : "";
                txtCM.Text = dsdd.Tables[0].Rows[0]["AM_CM"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_CM"].ToString() : "";
                txtLG.Text = dsdd.Tables[0].Rows[0]["AM_LEGAL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_LEGAL"].ToString() : "";
                txtDDm.Text = dsdd.Tables[0].Rows[0]["AM_DDM"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_DDM"].ToString() : "";
                txtCredit.Text = dsdd.Tables[0].Rows[0]["AM_CREDIT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_CREDIT"].ToString() : "";
                txtOCI.Text = dsdd.Tables[0].Rows[0]["AM_OCI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_OCI"].ToString() : "";
                txtTRM.Text = dsdd.Tables[0].Rows[0]["AM_TRM"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_TRM"].ToString() : "";
                txtARM.Text = dsdd.Tables[0].Rows[0]["AM_ARM"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AM_ARM"].ToString() : "";

            }

        }

    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmddd = new SqlCommand("RTS_SP_Update_AM_MANAGER_MASTER", con);
                cmddd.Parameters.AddWithValue("@AM_AR_ID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue.ToString() : "");
                cmddd.Parameters.AddWithValue("@AM_EMPID", txtEmoID.Text);
                cmddd.Parameters.AddWithValue("@AM_NAME", txtName.Text);
                cmddd.Parameters.AddWithValue("@AM_PHNO", txtPhnO.Text);
                cmddd.Parameters.AddWithValue("@AM_EMAIL", txtEmail.Text);
                cmddd.Parameters.AddWithValue("@AM_CM", txtCM.Text);
                cmddd.Parameters.AddWithValue("@AM_DDM", txtDDm.Text);
                cmddd.Parameters.AddWithValue("@AM_CREDIT", txtCredit.Text);
                cmddd.Parameters.AddWithValue("@AM_SCI", txtSCI.Text);
                cmddd.Parameters.AddWithValue("@AM_OCI", txtOCI.Text);
                cmddd.Parameters.AddWithValue("@AM_LEGAL", txtLG.Text);
                cmddd.Parameters.AddWithValue("@AM_TRM", txtTRM.Text);
                cmddd.Parameters.AddWithValue("@AM_ARM", txtARM.Text);

                if (btnSubmit.Text == "Update")
                {
                    cmddd.Parameters.AddWithValue("@QType", "U");
                }
                else
                {
                    cmddd.Parameters.AddWithValue("@QType", "I");
                }

                cmddd.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                cmddd.CommandType = CommandType.StoredProcedure;
                int res = cmddd.ExecuteNonQuery();
                  
                if (btnSubmit.Text == "Update")
                {

                    if (res > 0)
                    {
                        btnSubmit.Text = "Submit";
                        uscMsgBox1.AddMessage("Area Manager Email Master Updated Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        clear();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Area Manager Email Master Not Updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
                else
                {

                    if (res > 0)
                    {
                        uscMsgBox1.AddMessage("Area Manager Email Master Inserted Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        clear();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Area Manager Email Master Not Inserted", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
                con.Close();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                uscMsgBox1.AddMessage("Area Manager Email Master Not Inserted / Updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("MR_Area_Manager.aspx");
    }

    protected void clear()
    {
        try
        {
            txtARM.Text = "";
            txtCM.Text = "";
            txtCredit.Text = "";
            txtDDm.Text = "";
            txtEmail.Text = "";
            txtEmoID.Text = "";
            txtLG.Text = "";
            txtName.Text = "";
            txtOCI.Text = "";
            txtPhnO.Text = "";
            txtSCI.Text = "";
            txtTRM.Text = "";
            bindArea();
            
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}