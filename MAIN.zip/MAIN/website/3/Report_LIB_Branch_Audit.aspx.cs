﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Drawing;
using System.Globalization;
using Tracker;

public partial class Report_LIB_Branch_Audit : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime date;
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.bt_print);
    }
    protected void bt_print_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            DataSet ds = new DataSet();
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_LIB_BR_AUDITING", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PTYPE", "LIB_ADT_RPT");
            //cmd.CommandTimeout = 30000;
            cmd.Parameters.Add("@STDT", DateTime.ParseExact(txtFromDate.Text, "dd-MM-yyyy", CultureInfo.InvariantCulture));
            cmd.Parameters.Add("@ENDDT", DateTime.ParseExact(txtToDate.Text, "dd-MM-yyyy", CultureInfo.InvariantCulture));
            SqlDataAdapter showdata = new SqlDataAdapter(cmd);
            showdata.Fill(ds);
            con.Close();

            if (ds.Tables[0].Rows.Count > 0)
            {
                System.IO.StringWriter tw = new System.IO.StringWriter();
                GridView dgGrid = new GridView();
                dgGrid.DataSource = ds;
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=Liability Branch Audit Report FROM " + txtFromDate.Text + " TO " + txtToDate.Text + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                dgGrid.AllowPaging = false;
                dgGrid.DataBind();
                //Change the Header Row back to white color
                dgGrid.HeaderRow.Style.Add("background-color", "#FFFFFF");
                dgGrid.HeaderRow.ForeColor = Color.White;
                DataGrid dg = new DataGrid();
                dg.DataSource = ds;
                dg.DataBind();
                dgGrid.BorderColor = Color.FromArgb(211, 211, 211);
                for (int z = 0; z < dg.Items[0].Cells.Count; z++)
                {
                    //Apply style to Individual Cells
                    dgGrid.HeaderRow.Cells[z].Style.Add("background-color", "#7F7F7F");
                    dgGrid.HeaderRow.Cells[z].BorderColor = Color.FromArgb(211, 211, 211);
                    //dgGrid.HeaderRow.Cells[z].Height = 30;
                }
                for (int i = 0; i < dgGrid.Rows.Count; i++)
                {
                    GridViewRow row = dgGrid.Rows[i];

                    //Change Color back to white
                    row.BackColor = System.Drawing.Color.White;

                    //Apply text style to each Row
                    row.Attributes.Add("class", "textmode");

                    //Apply style to Individual Cells of Alternating Row
                    /* for (int s = 0; s < dg.Items[0].Cells.Count; s++)
                     {
                         if (i % 2 != 0)
                         {
                             row.Cells[s].Style.Add("background-color", "#f2f2f2");
                             row.Cells[s].BorderColor = Color.FromArgb(211, 211, 211);
                             row.Cells[s].ForeColor = Color.Black;
                             row.Cells[s].Font.Bold = true;
                             row.Cells[s].Font.Size = 10;
                         }
                         else
                         {
                             row.Cells[s].Style.Add("background-color", "#DDD9C3");
                             row.Cells[s].BorderColor = Color.FromArgb(211, 211, 211);
                             row.Cells[s].ForeColor = Color.Black;
                             row.Cells[s].Font.Bold = true;
                             row.Cells[s].Font.Size = 10;
                         }
                     }*/
                }
                dgGrid.RenderControl(hw);
                string year = DateTime.Now.AddYears(0).ToString("yyyy");
                string headerTable = @"<Table><tr><th colspan=4 align=left><font face=Calibri size=5 color=#974807>Liability Branch Audit Report From " + txtFromDate.Text + " To " + txtToDate.Text + "</font></th></tr></Table>";
                Response.Write(headerTable);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                uscMsgBox1.AddMessage("No Data Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

}