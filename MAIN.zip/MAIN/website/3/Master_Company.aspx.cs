﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_Company : System.Web.UI.Page
{
    int stid;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("SELECT ST_NAME FROM MR_STATE", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmddd);
            DataSet ds2 = new DataSet();
            da1.Fill(ds2);
            con.Close();
            ddlState.DataSource = ds2;
            ddlState.DataTextField = "ST_NAME";
            ddlState.DataValueField = "ST_NAME";
            ddlState.DataBind();
            ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmd = new SqlCommand("select CMP_CODE 'CMP. CODE',CMP_NAME 'CMP. NAME',CMP_CITY 'CITY',CMP_CTPERSON 'CONTACT PERSON',CMP_PHNO 'CONTACT NO.' from MR_COMPANY", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvcompany.DataSource = ds;
        gvcompany.DataBind();
        if (gvcompany.Rows.Count > 0)
        {
            gvcompany.HeaderRow.Font.Bold = true;
            gvcompany.HeaderRow.Cells[0].Text = "CMP. CODE";
            gvcompany.HeaderRow.Cells[1].Text = "CMP. NAME";
            gvcompany.HeaderRow.Cells[2].Text = "CITY";
            gvcompany.HeaderRow.Cells[3].Text = "CONTACT PERSON";
            gvcompany.HeaderRow.Cells[4].Text = "CONTACT NO.";
            
            gvcompany.HeaderRow.Cells[0].Wrap = false;
            gvcompany.HeaderRow.Cells[1].Wrap = false;
            gvcompany.HeaderRow.Cells[2].Wrap = false;
            gvcompany.HeaderRow.Cells[3].Wrap = false;
            gvcompany.HeaderRow.Cells[4].Wrap = false;            
        }       
    }
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Right;            
        }
    }   
  
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand stcmd = new SqlCommand("SELECT ST_ID FROM MR_STATE where ST_NAME='" + ddlState.SelectedValue.ToString() + "'", con);
            SqlDataAdapter stda = new SqlDataAdapter(stcmd);
            DataSet stds = new DataSet();
            stda.Fill(stds);

            stid = Convert.ToInt32(stds.Tables[0].Rows[0]["ST_ID"]);

            SqlCommand insertcmd = new SqlCommand("insert into MR_COMPANY values ('" + txtCmpcode.Text + "','" + txtCmpname.Text + "','" + txtAddr1.Text + "','" + txtAddr2.Text + "','" + txtCity.Text + "','" + txtPincode.Text + "','" + stid + "','" + txtContactperson.Text + "','" + txtContactno.Text + "','" + txtEmailid.Text + "','" + Session["ID"].ToString() + "',getdate(),'" + Session["ID"].ToString() + "',getdate())", con);
            insertcmd.ExecuteNonQuery();
            bind();
            txtCmpcode.Text = "";
            txtCmpname.Text = "";
            txtAddr1.Text = "";
            txtAddr2.Text = "";
            txtCity.Text = "";
            txtPincode.Text = "";
            txtContactno.Text = "";
            txtContactperson.Text = "";
            txtEmailid.Text = "";
            //ddlState.Text = "--Select--";
            uscMsgBox1.AddMessage("Company Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_Company.aspx");
    }
}