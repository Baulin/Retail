﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Legal_ReceiveFile : System.Web.UI.Page
{
    public static DataTable dtLawyerName = null;
    int ldid, s;

    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                BindLawyerName();
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bindArea();
            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }

    // Shankar_Nov_14_01 
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    // Shankar_Nov_14_01 
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    public void InsertUpdateSendAndReceivveData()
    {
        int nCheckStatus = 0;
        int nUpdateQueryError = 0;
        SqlConnection con = new SqlConnection(strcon);
        DataTable dtLawyer = new DataTable();
        DataRow dr = null;

        dtLawyer.Columns.Add("LF_LD_ID", typeof(string));
        dtLawyer.Columns.Add("LF_LR_PID", typeof(string));
        dtLawyer.Columns.Add("LF_PFEE", typeof(string));
        try
        {
            s = 0;
            con.Open();
            foreach (GridViewRow grow in gvRcvfile.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;

                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    DropDownList ddlLawyerName = (DropDownList)gvRcvfile.Rows[index].Cells[8].FindControl("ddlLawyerName");
                    DropDownList ddlLawyerType = (DropDownList)gvRcvfile.Rows[index].Cells[8].FindControl("ddlLawyerType");
                    if (ddlLawyerType.SelectedItem.Text == "External" && ddlLawyerName.SelectedItem.Text == "--Select--")
                    {
                        uscMsgBox1.AddMessage("Please Select Lawyer Name For LEAD NO: " + gvRcvfile.Rows[index].Cells[1].Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        // return false;
                        nUpdateQueryError = 1;
                    }
                }
            }
            if (nUpdateQueryError == 0)
            {
                foreach (GridViewRow grow in gvRcvfile.Rows)
                {

                    CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;

                    int index = grow.RowIndex;
                    if (chkStat.Checked)
                    {
                        s += 1;

                        Label lblLeadID = (Label)gvRcvfile.Rows[index].Cells[0].FindControl("lblLeadID");
                        DropDownList ddlLawyerName = (DropDownList)gvRcvfile.Rows[index].Cells[8].FindControl("ddlLawyerName");
                        DropDownList ddlLawyerType = (DropDownList)gvRcvfile.Rows[index].Cells[8].FindControl("ddlLawyerType");

                        nCheckStatus = 1;
                        Label txtPreFee = (Label)gvRcvfile.Rows[index].Cells[9].FindControl("txtPreFee");

                        ldid = lblLeadID.Text != "" ? Convert.ToInt32(lblLeadID.Text) : 0;

                        SqlCommand cmdupdate = new SqlCommand("RTS_SP_UpdateSendAndReceiveFIles", con);
                        cmdupdate.CommandType = CommandType.StoredProcedure;
                        cmdupdate.Parameters.AddWithValue("@process", "B");
                        cmdupdate.Parameters.AddWithValue("@FT_LD_ID", ldid);
                        cmdupdate.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                        cmdupdate.Parameters.AddWithValue("@TYPE", "L");

                        dr = dtLawyer.NewRow();

                        dr["LF_LD_ID"] = lblLeadID.Text;
                        dr["LF_LR_PID"] = ddlLawyerName.SelectedValue.ToString() != "" ? ddlLawyerName.SelectedValue.ToString() : Session["ID"].ToString();
                        dr["LF_PFEE"] = txtPreFee.Text != "" ? txtPreFee.Text : "0";
                        dtLawyer.Rows.Add(dr);

                        cmdupdate.ExecuteNonQuery();
                    }
                }
                if (nCheckStatus != 0)
                {
                    UpdateLawyerPFEE(dtLawyer, con);
                    BindSendReceiveGrid();
                    lbLeadno.Text = "";
                    lbAppname.Text = "";
                    lbPDdate.Text = "";
                    lbLoanamt.Text = "";
                    ddlArea.Enabled = true;
                    ddlBranch.Enabled = true;
                    txtLeadno.Enabled = true;
                    btnSubmit.Enabled = false;
                    uscMsgBox1.AddMessage(s + " File/s Received Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

                }
                else
                {

                    uscMsgBox1.AddMessage(s + " Please Select Atleast One Input Value to Send/Receive", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);


                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_ReceiveFile.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertUpdateSendAndReceivveData();

    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "All";
            uscMsgBox1.AddMessage("Please Select the Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            return ;
        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            ddlArea.SelectedIndex = 0;

        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";

        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";

        }
        else if (txtLeadno.Text != "")
        {
            Session["View"] = "F";

        }
        
            BindSendReceiveGrid();
            div_poslrf.Value = "0";
       
    }

    public void BindSendReceiveGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_SendReceiveFile", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@Process", "B");
            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "L");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            gvRcvfile.DataSource = ds.Tables[0];
            gvRcvfile.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvRcvfile.Visible = true;
                gvRcvfile.HeaderRow.Font.Bold = true;
                gvRcvfile.HeaderRow.Cells[1].Text = "LEAD NO";
                gvRcvfile.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvRcvfile.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvRcvfile.HeaderRow.Cells[4].Text = "PD DATE";
                gvRcvfile.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvRcvfile.HeaderRow.Cells[6].Text = "BRANCH NAME";
                gvRcvfile.HeaderRow.Cells[7].Text = "LAWYER TYPE";
                gvRcvfile.HeaderRow.Cells[8].Text = "LAWYER NAME";
                gvRcvfile.HeaderRow.Cells[9].Text = "PRE OPINION FEE";

                gvRcvfile.HeaderRow.Cells[1].Wrap = false;
                gvRcvfile.HeaderRow.Cells[2].Wrap = false;
                gvRcvfile.HeaderRow.Cells[3].Wrap = false;
                gvRcvfile.HeaderRow.Cells[4].Wrap = false;
                gvRcvfile.HeaderRow.Cells[5].Wrap = false;
                gvRcvfile.HeaderRow.Cells[6].Wrap = false;
                gvRcvfile.HeaderRow.Cells[7].Wrap = false;
                gvRcvfile.HeaderRow.Cells[8].Wrap = false;
                gvRcvfile.HeaderRow.Cells[9].Wrap = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_ReceiveFile.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }

    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {

        foreach (GridViewRow grow in gvRcvfile.Rows)
        {
            CheckBox cb_select = grow.FindControl("cb_select") as CheckBox;
            DropDownList ddlLawyerType = grow.FindControl("ddlLawyerType") as DropDownList;
            DropDownList ddlLawyerName = (DropDownList)grow.FindControl("ddlLawyerName");
            int index = grow.RowIndex;
            if (cb_select.Checked)
            {
                ddlLawyerType.Visible = true;
            }
            else
            {
                ddlLawyerType.Visible = false;
                ddlLawyerName.Visible = false;
            }
        }

        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Legal_ReceiveFile.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
    }
    protected void ddlLawyerType_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dt = null;

        foreach (GridViewRow grow in gvRcvfile.Rows)
        {
            DropDownList ddlLawyerType = (DropDownList)grow.FindControl("ddlLawyerType");
            DropDownList ddlLawyerName = (DropDownList)grow.FindControl("ddlLawyerName");
            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            Label lblAr_ID = (Label)grow.FindControl("lblARID");
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                if (ddlLawyerType.SelectedValue == "E")
                {
                    if (ddlLawyerName.Items.Count <= 0)
                    {
                        if (dtLawyerName != null)
                        {
                            if (lblAr_ID.Text != "")
                            {
                                DataRow[] dr = dtLawyerName.Select("LR_AR_ID='" + lblAr_ID.Text + "'");
                                if (dr.Length > 0)
                                {

                                    dt = dr.CopyToDataTable();
                                    ddlLawyerName.DataSource = dt;
                                }
                            }
                            else
                            {
                                dt = dtLawyerName;
                                ddlLawyerName.DataSource = dt;
                            }
                            ddlLawyerName.DataTextField = "LR_NAME";
                            ddlLawyerName.DataValueField = "LR_ID";

                            ddlLawyerName.DataBind();
                            ddlLawyerName.Visible = true;
                            ddlLawyerName.Items.Insert(0, "--Select--");
                        }

                    }
                }
                else
                {
                    ddlLawyerName.Items.Clear();
                    ddlLawyerName.Visible = false;
                }
            }
        }
    }
    protected void ddlLawyerName_SelectedIndexChanged(object sender, EventArgs e)
    {

        foreach (GridViewRow grow in gvRcvfile.Rows)
        {
            DropDownList ddlLawyerName = (DropDownList)grow.FindControl("ddlLawyerName");
            Label lblLeadID = (Label)grow.FindControl("lblLeadID");
            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            Label txtPreFee = (Label)grow.FindControl("txtPreFee");
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                if (ddlLawyerName.SelectedIndex > 0)
                {

                    txtPreFee.Text = fetchPreFee(ddlLawyerName.SelectedValue.ToString());
                    txtPreFee.Visible = true;
                }
                else
                {
                    txtPreFee.Text = "";
                    txtPreFee.Visible = false;
                }
            }
        }
    }

    protected void gvRcvfile_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int index = Convert.ToInt32(e.CommandArgument.ToString());
        DropDownList ltrlslno = (DropDownList)gvRcvfile.Rows[index].FindControl("ddlLawyerType");
        DropDownList ltrlName = (DropDownList)gvRcvfile.Rows[index].FindControl("ddlLawyerName");

    }
    public DataTable BindLawyerName()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = null;

        cmddd = new SqlCommand("SELECT LR_NAME,LR_ID,LR_PFEE,LR_AR_ID FROM MR_LAWYER ORDER BY LR_NAME ASC", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        dtLawyerName = dsdd.Tables[0];
        con.Close();
        return dtLawyerName;
    }
    public string fetchPreFee(string LR_ID)
    {
        string strFee = "";
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = null;

        cmddd = new SqlCommand("SELECT LR_PFEE FROM MR_LAWYER where LR_ID='" + LR_ID + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        strFee = dsdd.Tables[0].Rows[0][0].ToString();
        con.Close();
        return strFee;
    }
    public void UpdateLawyerPFEE(DataTable dt, SqlConnection con)
    {
        SqlCommand cmdupdate = new SqlCommand("RTS_INSERT_LAWYERFEE", con);
        cmdupdate.CommandType = CommandType.StoredProcedure;
        cmdupdate.Parameters.AddWithValue("@tblLegalQueries", dt);
        cmdupdate.ExecuteNonQuery();
    }
}