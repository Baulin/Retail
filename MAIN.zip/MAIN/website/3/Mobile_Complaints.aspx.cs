﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;
using Utilities;

public partial class Mobile_Complaints : System.Web.UI.Page
{
    #region Common
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter da = new SqlDataAdapter();
    DataSet ds = new DataSet();
    string[] a_month1;
    string[] a_month = String.Format("{0:dd MMM yyyy}", DateTime.Now).ToString().Split(' ');
    string month = string.Empty;
    string year = string.Empty;
    int monthcount;
    int totalcount;
    CreateLogFiles Err = new CreateLogFiles();
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    bindArea();
                }
            }
            else
                Response.Redirect("~/Default.aspx");

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int res = 0;
        DataTable dt = new DataTable();
        SqlConnection conSub = new SqlConnection(strcon);
        try
        {
            Session["UnitName"] = ddlBranch.SelectedItem.ToString();
            if (ddlType.SelectedValue == "C")
            {
                dt = readMcNO("C");
                if (dt.Rows.Count == 0)
                {
                    month = a_month[1].ToString().ToUpper();
                    year = a_month[2].ToString();
                    Session["comp_ref_no"] = "C" + "/" + year + "/" + month + "/" + "1".PadLeft(3, '0') + "/" + "1".PadLeft(5, '0');
                }
                else
                {
                    a_month1 = dt.Rows[0]["LMC_NO"].ToString().Split('/');

                    if (a_month[2].ToString() + a_month[1].ToString().ToUpper() == a_month1[1].ToString() + a_month1[2].ToString() && a_month1[0].ToString() == "C")
                    {
                        month = a_month1[2].ToString();
                        monthcount = Convert.ToInt16(a_month1[3].ToString()) + 1;
                        totalcount = Convert.ToInt16(a_month1[4].ToString()) + 1;
                        Session["comp_ref_no"] = a_month1[0].ToString() + "/" + year + a_month1[1].ToString() + "/" + month + "/" + monthcount.ToString().PadLeft(3, '0') + "/" + totalcount.ToString().PadLeft(5, '0');

                    }
                    else
                    {
                        month = a_month[1].ToString().ToUpper();
                        year = a_month[2].ToString();
                        monthcount = 001;
                        totalcount = Convert.ToInt16(a_month1[4].ToString()) + 1;
                        Session["comp_ref_no"] = a_month1[0].ToString() + "/" + year + "/" + month + "/" + monthcount.ToString().PadLeft(3, '0') + "/" + totalcount.ToString().PadLeft(5, '0');
                    }
                }

                con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                    con.Open();

                cmd = new SqlCommand("LSD_MOB_COMPLAINTS_INSERT", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MC_BRANCH", ddlBranch.SelectedItem.Text);
                string[] emp = ddlEmp.SelectedItem.Text.Split('-');
                cmd.Parameters.AddWithValue("@MC_EMP_NO", Convert.ToString(emp[0]));
                cmd.Parameters.AddWithValue("@MC_EMP_NAME", Convert.ToString(emp[1]));
                cmd.Parameters.AddWithValue("@MS_TYPE", "C");
                cmd.Parameters.AddWithValue("@MC_DEVICE", ddlDevice.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@MC_MI_ID", ddlIssue.SelectedValue);
                cmd.Parameters.AddWithValue("@MC_COMPLAINT", txtComplaints.Text.Replace("'", "''").ToUpper());
                cmd.Parameters.AddWithValue("@MC_REMP_NO", "");
                cmd.Parameters.AddWithValue("@MC_REMP_NAME", "");
                cmd.Parameters.AddWithValue("@MC_CBY", DBNull.Value);
                cmd.Parameters.AddWithValue("@MC_NO", Convert.ToString(Session["comp_ref_no"]));
                cmd.Parameters.AddWithValue("@MC_RDESIGN", "");
                cmd.Parameters.AddWithValue("@MC_PHNO", txtMobileNo.Text);
                res = Convert.ToInt32(cmd.ExecuteNonQuery());
                if (res > 0)
                {
                    Session["USR_EMAIL_ID"] = getBmMail();
                    if (Session["USR_EMAIL_ID"].ToString() != "")
                    {
                        email_complaint();
                        //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Reallocation Request Raised Successfully'); window.location.href('http://172.16.2.95/Mobile_BMP/complaints.aspx','_self');", true);

                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Complaint Raised Successfully'); window.location.href('http://localhost:51568/Mobile_Complaints.aspx');", true);

                        //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Reallocation Request Raised Successfully'); window.location.href('http://vfportal.equitas.in//Mobile/complaints.aspx');", true);

                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Complaint Raised Successfully and mail is not sent'); window.location.href('http://localhost:51568/Mobile_Complaints.aspx');", true);

                        //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Reallocation Request Raised and mail was not set'); window.location.href('http://vfportal.equitas.in//Mobile/complaints.aspx');", true);


                    }
                }
            }
            else
            {
                DataTable dtRealloc = new DataTable();
                dtRealloc = readMcNO("R");
                if (dtRealloc.Rows.Count == 0)
                {
                    month = a_month[1].ToString().ToUpper();
                    year = a_month[2].ToString();
                    Session["comp_ref_no"] = "R" + "/" + year + "/" + month + "/" + "1".PadLeft(3, '0') + "/" + "1".PadLeft(5, '0');
                }
                else
                {
                    a_month1 = dtRealloc.Rows[0]["LMC_NO"].ToString().Split('/');

                    if (a_month[2].ToString() + a_month[1].ToString().ToUpper() == a_month1[1].ToString() + a_month1[2].ToString() && a_month1[0].ToString() == "R")
                    {
                        month = a_month1[2].ToString();
                        monthcount = Convert.ToInt16(a_month1[3].ToString()) + 1;
                        totalcount = Convert.ToInt16(a_month1[4].ToString()) + 1;
                        Session["comp_ref_no"] = a_month1[0].ToString() + "/" + year + a_month1[1].ToString() + "/" + month + "/" + monthcount.ToString().PadLeft(3, '0') + "/" + totalcount.ToString().PadLeft(5, '0');
                    }
                    else
                    {
                        month = a_month[1].ToString().ToUpper();
                        year = a_month[2].ToString();
                        monthcount = 001;
                        totalcount = Convert.ToInt16(a_month1[4].ToString()) + 1;
                        Session["comp_ref_no"] = a_month1[0].ToString() + "/" + year + "/" + month + "/" + monthcount.ToString().PadLeft(3, '0') + "/" + totalcount.ToString().PadLeft(5, '0');
                    }
                }
                con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                    con.Open();

                cmd = new SqlCommand("LSD_MOB_COMPLAINTS_INSERT", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MC_BRANCH", ddlBranch.SelectedItem.Text);
                string[] emp = ddlEmp.SelectedItem.Text.Split('-');
                cmd.Parameters.AddWithValue("@MC_EMP_NO", Convert.ToString(emp[0]));
                cmd.Parameters.AddWithValue("@MC_EMP_NAME", Convert.ToString(emp[1]));
                cmd.Parameters.AddWithValue("@MS_TYPE", "R");
                cmd.Parameters.AddWithValue("@MC_DEVICE", "");
                cmd.Parameters.AddWithValue("@MC_MI_ID", 1);
                cmd.Parameters.AddWithValue("@MC_COMPLAINT", txtComplaints.Text.Replace("'", "''").ToUpper());
                cmd.Parameters.AddWithValue("@MC_REMP_NO", txtReallocNo.Text);
                cmd.Parameters.AddWithValue("@MC_REMP_NAME", txtReallocName.Text);
                cmd.Parameters.AddWithValue("@MC_CBY", DBNull.Value);
                cmd.Parameters.AddWithValue("@MC_NO", Convert.ToString(Session["comp_ref_no"]));
                cmd.Parameters.AddWithValue("@MC_RDESIGN", ddlDesignation.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@MC_PHNO", txtMobileNo.Text);
                res = Convert.ToInt32(cmd.ExecuteNonQuery());
                if (res > 0)
                {
                    Session["USR_EMAIL_ID"] = getBmMail();
                    if (Session["USR_EMAIL_ID"].ToString() != "")
                    {
                        email_Reallocation();
                        //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Reallocation Request Raised Successfully'); window.location.href('http://172.16.2.95/Mobile_BMP/complaints.aspx','_self');", true);

                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Reallocation Request Raised Successfully'); window.location.href('http://localhost:51568/Mobile_Complaints.aspx');", true);

                        //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Reallocation Request Raised Successfully'); window.location.href('http://vfportal.equitas.in//Mobile/complaints.aspx');", true);

                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Reallocation Request Raised and mail was not set'); window.location.href('http://localhost:51568/Mobile_Complaints.aspx');", true);

                        //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Reallocation Request Raised and mail was not set'); window.location.href('http://vfportal.equitas.in//Mobile/complaints.aspx');", true);


                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            conSub.Close();
            conSub.Dispose();
            SqlConnection.ClearPool(conSub);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Mobile_Complaints.aspx", false);
    }

    protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        clear();
        ddlEmp.SelectedIndex = 0;
        trBTname.Visible = true;
        trCompliaints.Visible = true;
        trMobile.Visible = true;
        trEmployee.Visible = true;
        if (ddlType.SelectedValue == "C")
        {
            trDevice.Visible = true;
            trIssue.Visible = true;
            spanComplaints.InnerText = "Complaints";

            trIMEI.Visible = false;
            trBTname.Visible = false;
            trDesgnation.Visible = false;
            trReallocno.Visible = false;
            trReallocName.Visible = false;

        }
        else if (ddlType.SelectedValue == "R")
        {
            trIMEI.Visible = true;
            trBTname.Visible = true;
            trDesgnation.Visible = true;
            spanComplaints.InnerText = "Remarks";
            trReallocno.Visible = true;
            trReallocName.Visible = true;

            trDevice.Visible = false;
            trIssue.Visible = false;
        }
        else
        {
            trDevice.Visible = false;
            trIssue.Visible = false;
            trIMEI.Visible = false;
            trBTname.Visible = false;
            trDesgnation.Visible = false;
            trReallocno.Visible = false;
            trReallocName.Visible = false;
            trBTname.Visible = false;
            trCompliaints.Visible = false;
            trMobile.Visible = false;
            trEmployee.Visible = false;
        }
        //bindBranch();
        bindEmpname();
    }

    protected void email_Reallocation()
    {
        try
        {
            string[] emp = ddlEmp.SelectedItem.Text.Split('-');
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{
                string bodytext = " <html><body> <basefont face='Calibri'> Dear Helpdesk,<br/><br/> Please find the details for Reallocation Request <br/><table width='50%' style='font-family: Verdana, Arial, Tahoma; font-size:12px'><tr><td>"
                  + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>"
                     + "<tr><td width='20%'>Branch Name  </td><td>" + Session["UnitName"].ToString() + "</td></tr>"
                      + "<tr><td>Request Date </td><td>" + String.Format("{0:dd MMM yyyy H:mm}", DateTime.Now).ToString() + "</td></tr>"
                     + "<tr><td>Request No  </td><td width='30%'>" + Session["comp_ref_no"].ToString() + "</td></tr>"
                    + "<tr><td width='20%'>Current Employee  </td><td>" + Convert.ToString(emp[0]) + "/" + Convert.ToString(emp[1]) + "</td></tr>"
                          + "<tr><td width='20%'>IMEI No  </td><td>" + txtIMEI.Text + "</td></tr>"
                             + "<tr><td width='20%'>Printer BT Name  </td><td>" + txtPrinterBtName.Text + "</td></tr>"
                    + "<tr><td width='20%'>Reallocate Employee  </td><td>" + txtReallocNo.Text.ToUpper() + "/" + txtReallocName.Text.ToUpper() + "</td></tr>"
                         + "<tr><td width='20%'>Designation  </td><td>" + ddlDesignation.SelectedItem.Text + "</td></tr>"
                + "<tr><td>Remarks </td><td style='white-space:normal'>" + txtComplaints.Text.Trim().ToUpper() + "</td></tr>"
                 + "<tr><td>Mobile Number </td><td style='white-space:normal'>" + txtMobileNo.Text.Trim() + "</td></tr>"
                 + "</td></tr></table><br/><br/>"
                    + "<tr> <td><strong>Note: For Queries, Please contact mobile helpdesk on 044-6640 1165/1166/1168</strong></td></tr><br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> <strong> Instructions: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> <strong> Complaints and Reallocation: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 1. Branch should raise Complaints/Reallocation request in BMP for speedy action</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 2. For non-working devices, Branch has to inform TRM/ARM and TRM/ARM should examine the device and confirm the device non-working status</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 3. Based on TRM/ARM confirmation, Branch has to send back the non-working device to HO and scanned POD copy should be mailed to mobile helpdesk (mobile-helpdesk@equitasbank.com) </td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 4. For application deletion, mobile user has to inform TRM/ARM and TRM/ARM should investigate the root cause for deletion and confirm the remittance status</td></tr>"
                + "<br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> <strong> Lost and Damage: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 1. Lost or Physical damage of Mobile/Printer, Branch has to request for new issuance to Regional HR</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 2. HR dept will deduct the Mobile/Printer cost from the concern employees’ salary and provide approval for new issuance</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 3.Based on the HR dept approval, Mobile Helpdesk will issue new Mobile/Printer to the concern employee</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> <strong> Do's: </strong> </td></tr>"
                + "<br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 1.Use mobile and printer only for receipting purpose and Keep only VTS SIM in mobile</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 2.Daily charge Mobile and Printer and  login on-line at least one time</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 3.Keep only the collection application in mobile</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> <strong> Don’ts: </strong> </td></tr>"
                + "<br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 1.Don’t use mobile for calling purpose</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 2.Don’t uninstall / reinstall the application</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 3.Don’t keep CUG SIM in mobile</td></tr>"
                + "<br/><br/>"
                  + "<tr><td width='20%'>Raised By  </td><td>" + Session["User"].ToString() + "</td></tr>"
                  + "</table></td></tr><br/><br/>"


                  + "<tr><td align='left' ><span style='font-family: Calibri; font-size:14px;color: #ff0000;font-style:italic'><br/><strong>*** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></td></tr></table></html>";
                //  sendemail("rts-helpdesk@equitasbank.com", "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "rts-helpdesk@equitasbank.com", "Reallocation : Request No : " + comp_ref_no + "", bodytext, "", true);
                //sendemail("jenom@equitasbank.com", "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "jenom@equitasbank.com", "Reallocation : Request No : " + Session["comp_ref_no"].ToString() + "", bodytext, "", true);

                EmailManager.sendemail("mobile-helpdesk@equitasbank.com;jeraldp@equitasbank.com", "Mobile-HelpDesk<mobile-helpdesk@equitasbank.com>", "", Session["USR_EMAIL_ID"].ToString(), "Reallocation : Request No : " + Session["comp_ref_no"].ToString() + "", bodytext, "", true);
                //sendemail("jeraldp@equitasbank.com", "jeraldp@equitasbank.com", "", "", "Reallocation : Request No : " + Session["comp_ref_no"].ToString() + "", bodytext, "", true);

            //});
            //threadSendMails.IsBackground = true;
            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(2000);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //result = "";
        }

    }

    protected void email_complaint()
    {
        try
        {
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{
                string bodytext = " <html><body> <basefont face='Calibri'> Dear Helpdesk,<br/><br/> Please find the details for " + ddlDevice.SelectedItem.Text + " Complaint <br/><table width='50%' style='font-family: Verdana, Arial, Tahoma; font-size:12px'><tr><td>"
                  + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>"
                     + "<tr><td width='20%'>Branch Name  </td><td>" + Session["UnitName"].ToString() + "</td></tr>"
                       + "<tr><td>Complaint Date </td><td>" + String.Format("{0:dd MMM yyyy H:mm}", DateTime.Now).ToString() + "</td></tr>"
                    + " <tr><td>Complaint No  </td><td width='30%'>" + Session["comp_ref_no"].ToString() + "</td></tr>"
                    //+ "<tr><td width='20%'>Employee </td><td>" + v.MC_EMP_NO + "/" + v.MC_EMP_NAME + "</td></tr>"
                  + "<tr><td>Device  </td><td width='30%'>" + ddlDevice.SelectedItem.Text + "</td></tr>"
                  + "<tr><td>Issue  </td><td>" + ddlIssue.SelectedItem.Text + "</td></tr>"
                + "<tr><td>Complaint </td><td style='white-space:normal'>" + txtComplaints.Text.ToUpper() + "</td></tr>"
                                 + "<tr><td>Mobile Number </td><td style='white-space:normal'>" + txtMobileNo.Text.Trim() + "</td></tr>"
                      + "<tr><td width='20%'>Raised By  </td><td>" + Session["User"].ToString() + "</td></tr>"
                  + "</td></tr></table><br/><br/>"
  + "<tr> <td><strong>Note: For Queries, Please contact mobile helpdesk on 044-6640 1165/1166/1168</strong></td></tr><br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> <strong> Instructions: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> <strong> Complaints and Reallocation: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 1. Branch should raise Complaints/Reallocation request in BMP for speedy action</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 2. For non-working devices, Branch has to inform TRM/ARM and TRM/ARM should examine the device and confirm the device non-working status</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 3. Based on TRM/ARM confirmation, Branch has to send back the non-working device to HO and scanned POD copy should be mailed to mobile helpdesk (mobile-helpdesk@equitasbank.com) </td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 4. For application deletion, mobile user has to inform TRM/ARM and TRM/ARM should investigate the root cause for deletion and confirm the remittance status</td></tr>"
                + "<br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> <strong> Lost and Damage: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 1. Lost or Physical damage of Mobile/Printer, Branch has to request for new issuance to Regional HR</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 2. HR dept will deduct the Mobile/Printer cost from the concern employees’ salary and provide approval for new issuance</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 3.Based on the HR dept approval, Mobile Helpdesk will issue new Mobile/Printer to the concern employee</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> <strong> Do's: </strong> </td></tr>"
                + "<br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 1.Use mobile and printer only for receipting purpose and Keep only VTS SIM in mobile</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 2.Daily charge Mobile and Printer and  login on-line at least one time</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 3.Keep only the collection application in mobile</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> <strong> Don’ts: </strong> </td></tr>"
                + "<br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 1.Don’t use mobile for calling purpose</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 2.Don’t uninstall / reinstall the application</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:12px'> 3.Don’t keep CUG SIM in mobile</td></tr>"
                + "<br/><br/>"

                  + "<tr><td align='left' ><span style='font-family: Calibri; font-size:14px;color: #ff0000;font-style:italic'><br/><strong>*** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></td></tr></table></html>";
                //  sendemail("jenom@equitasbank.com", "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "jenom@equitasbank.com", "" + ddl_device.SelectedItem.Text + " Complaint : Complaint No : " + Session["comp_ref_no"].ToString() + "", bodytext, "", true);

                // sendemail("rts-helpdesk@equitasbank.com", "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "rts-helpdesk@equitasbank.com", "" + ddl_device.SelectedItem.Text + " Complaint : Complaint No : " + comp_ref_no + "", bodytext, "", true);
                EmailManager.sendemail("mobile-helpdesk@equitasbank.com;jeraldp@equitasbank.com", "Mobile-HelpDesk<mobile-helpdesk@equitasbank.com>", "", Session["bm_email_id"].ToString(), "" + ddlDevice.SelectedItem.Text + " Complaint : Complaint No : " + Session["comp_ref_no"].ToString() + "", bodytext, "", true);
                //sendemail("jeraldp@equitasbank.com", "jeraldp@equitasbank.com", "", "", "" + ddlDevice.SelectedItem.Text + " Complaint : Complaint No : " + Session["comp_ref_no"].ToString() + "", bodytext, "", true);

            //});
            //threadSendMails.IsBackground = true;
            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(2000);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //result = "";
        }
    }

  
    protected void bindEmpname()
    {
        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();

            cmd = new SqlCommand("RTS_MOBILE_EMP_NAME_CODE", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@AREA", ddlst_Area.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@BRANCH_NAME", ddlBranch.SelectedItem.Text);
            //cmd.Parameters.AddWithValue("@MS_TYPE", "C");
            da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlEmp.DataSource = ds.Tables[0];
                ddlEmp.DataTextField = "EMP_NAME";
                ddlEmp.DataValueField = "EMP_NAME";
                ddlEmp.DataBind();
                ddlEmp.Items.Insert(0, "---Select---");
                ddlEmp.SelectedIndex = 0;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            ds.Clear();
            ds.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
    }

    protected void bindBranch()
    {
        DataTable dt = new DataTable();
        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();

            cmd = new SqlCommand("RTS_SP_READ_ALL_BRANCHNAME", con);
            cmd.CommandType = CommandType.StoredProcedure;

            dt.Load(cmd.ExecuteReader());

            if (dt.Rows.Count > 0)
            {
                ddlBranch.DataSource = dt;
                ddlBranch.DataTextField = "BRANCH_NAME";
                ddlBranch.DataValueField = "BRANCH_NAME";
                ddlBranch.DataBind();
                ddlBranch.Items.Insert(0, "---Select---");
                if (Session["USR_ACS"].ToString() == "7")
                {
                    ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
                    ddlBranch.Enabled = false;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            dt.Clear();
            dt.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
    }

    protected void ddlDevice_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();

            cmd = new SqlCommand("LSD_MOBILE_ISSUE", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MI_DEVICE", ddlDevice.SelectedItem.Text);

            dt.Load(cmd.ExecuteReader());

            if (dt.Rows.Count > 0)
            {
                ddlIssue.DataSource = dt;
                ddlIssue.DataTextField = "MOI_ISSUE";
                ddlIssue.DataValueField = "MOI_ID";
                ddlIssue.DataBind();
                ddlIssue.Items.Insert(0, "---Select---");
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            dt.Clear();
            dt.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
    }

    protected string getBmMail()
    {
        string bmMail = string.Empty;
        DataTable dt = new DataTable();
        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();

            cmd = new SqlCommand("RTS_SP_READ_BM_EMAIL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UNIT_NAME", ddlBranch.SelectedItem.Text);
            //bmMail = Convert.ToString(cmd.ExecuteScalar());
            dt.Load(cmd.ExecuteReader());
            if (dt.Rows.Count > 0)
            {
                bmMail = Convert.ToString((from DataRow dr in dt.Rows where (string)dr["EMP_TYPE"] == "Branch" select (string)dr["EM_BM"]).FirstOrDefault());
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            dt.Clear();
            dt.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
        return bmMail;
    }

    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        clear();
        ddlType.SelectedIndex = 0;
        ddlEmp.SelectedIndex = 0;
        bindEmpname();
        //getBmMail();
    }

    protected DataTable readMcNO(string type)
    {
        DataTable dt = new DataTable();

        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();

            cmd = new SqlCommand("RTS_SP_READ_MC_NO", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MS_TYPE", type);
            dt.Load(cmd.ExecuteReader());

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //dt.Clear();
            //dt.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
        return dt;
    }

    protected DataTable getIMEIBT(string emp)
    {
        DataTable dtIMEI = new DataTable();

        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();

            cmd = new SqlCommand("LSD_READ_IMEI_BTNAME", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@EMPLOYEE_NO", emp);
            dtIMEI.Load(cmd.ExecuteReader());

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //dt.Clear();
            //dt.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
        return dtIMEI;
    }

    protected void ddlEmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        clear();
        DataTable dtBTIMEI = new DataTable();
        try
        {
            string[] empIMEI = ddlEmp.SelectedItem.Text.Split('-');
            dtBTIMEI = getIMEIBT(Convert.ToString(empIMEI[0]));
            if (dtBTIMEI.Rows.Count > 0)
            {
                txtIMEI.Text = Convert.ToString(dtBTIMEI.Rows[0]["IMEI_NO"]);
                txtPrinterBtName.Text = Convert.ToString(dtBTIMEI.Rows[0]["PR_BT_NAME"]);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //dt.Clear();
            //dt.Dispose();
            //con.Close();
            //con.Dispose();
            //SqlConnection.ClearPool(con);
        }
    }

    public void bindArea()
    {
        try
        {
            DataTable dt = new DataTable();
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                cmd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                cmd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                cmd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
            {
                cmd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
            }
            else
            {
                cmd.Parameters.AddWithValue("@InputVal", 0);
            }
            dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            ddlst_Area.DataSource = dt;
            ddlst_Area.DataTextField = "AR_NAME";
            ddlst_Area.DataValueField = "AR_ID";
            ddlst_Area.DataBind();
            ddlst_Area.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Area.SelectedValue = Session["AREA_ID"].ToString();

            bindBranchs();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);

        }
    }

    public void bindBranchs()
    {
        try
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con);

            DataTable dt = new DataTable();

            dt.Load(cmd.ExecuteReader());



            ddlBranch.DataSource = dt;
            ddlBranch.DataTextField = "BR_NAME";
            ddlBranch.DataValueField = "BR_ID";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
            if (Session["USR_ACS"].ToString() == "7")
            {
                ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
                ddlBranch.Enabled = false;
                ddlst_Area.Enabled = false;
            }
            bindEmpname();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);

        }

    }

    protected void ddlst_Area_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            clear();
            ddlEmp.SelectedIndex = 0;
            ddlType.SelectedIndex = 0;
            ddlBranch.SelectedIndex = 0;
            ddlBranch.SelectedIndex = 0;
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con);
            DataTable dt_obj = new DataTable();

            dt_obj.Load(cmd.ExecuteReader());

            ddlBranch.DataSource = dt_obj;
            ddlBranch.DataTextField = "BR_NAME";
            ddlBranch.DataValueField = "BR_ID";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlBranch.Enabled = true;
            //ClearValues();
            //txtDate.Text = getDate();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);

        }
    }

    protected void clear()
    {
        ddlDevice.SelectedIndex = 0;
        ddlDesignation.SelectedIndex = 0;
        txtComplaints.Text = "";
        txtIMEI.Text = "";
        txtMobileNo.Text = "";
        txtPrinterBtName.Text = "";
        txtReallocName.Text = "";
        txtReallocNo.Text = "";
    }
}