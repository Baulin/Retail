﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class BusinessContinuityAudit : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    public static DataTable dtsBounce = null;
    public static int bTabIndex = 0;
    DateTime dt = DateTime.Now;
    public static DataTable dtOCI = null;
    DataTable Borrowing, Income;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
            dtOCI = GetOCIList();
            this.pnlTable.Visible = false;
        }
    }
    //protected void rb_select_CheckedChanged(object sender, EventArgs e)
    //{
    //    foreach (GridViewRow grow in gvBr_Audit.Rows)
    //    {
    //        RadioButton chkStat = grow.FindControl("Rb_select") as RadioButton;
    //        Label lnbtn = grow.FindControl("lblLeadID") as Label;
    //        int index = grow.RowIndex;
    //        if (chkStat.Checked)
    //        {
    //            lbLeadno.Text = lnbtn.Text;
    //            Session["leadno"] = grow.Cells[1].Text;
    //        }
    //    }
    //    Bind_br_Continuitydetails();
    //    Bind_Incomesource();
    //    Bind_borrowings();
    //    this.Compliant1.Visible = true;
    //    this.pnlTable.Visible = true;
    //    lbl_date.Text = String.Format("{0:dd-MMM-yyyy hh:mm tt}", dt);

    //    txt_conducted.Text = Session["User"].ToString().ToUpper();
    //    txt_EmpCode.Text = Session["EMP_CODE"].ToString();
    //    txt_contactNo.Text = Session["EMP_CONTACT"].ToString();

    //}

    protected void btnView_Click(object sender, EventArgs e)
    {

        //string query = "";

        //if (txtLoanNo.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        //{
        //    Session["View"] = "All";
        //    clear();
        //    gv_borrowings.DataSource = null;
        //    gv_borrowings.DataBind();
        //    GV_INCOMESOURCE.DataSource = null;
        //    GV_INCOMESOURCE.DataBind();

        //}
        //else if (txtLoanNo.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        //{
        //    Session["View"] = "F";
        //    ddlArea.Enabled = false;
        //    clear();
        //    gv_borrowings.DataSource = null;
        //    gv_borrowings.DataBind();
        //    GV_INCOMESOURCE.DataSource = null;
        //    GV_INCOMESOURCE.DataBind();
        //}
        //else if (txtLoanNo.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        //{
        //    Session["View"] = "F";
        //    clear();
        //    gv_borrowings.DataSource = null;
        //    gv_borrowings.DataBind();
        //    GV_INCOMESOURCE.DataSource = null;
        //    GV_INCOMESOURCE.DataBind();
        //}
        //else if (txtLoanNo.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        if (txtLoanNo.Text == "")
        {
            Session["View"] = "F";
            clear();
            gv_borrowings.DataSource = null;
            gv_borrowings.DataBind();
            GV_INCOMESOURCE.DataSource = null;
            GV_INCOMESOURCE.DataBind();
        }
        else if (txtLoanNo.Text != "")
        {
            Session["View"] = "All";
            Bind_br_Continuitydetails();
            Bind_Incomesource();
            Bind_borrowings();
            this.Compliant1.Visible = true;
            this.pnlTable.Visible = true;
            lbl_date.Text = String.Format("{0:dd-MMM-yyyy hh:mm tt}", dt);

            txt_conducted.Text = Session["User"].ToString().ToUpper();
            txt_EmpCode.Text = Session["EMP_CODE"].ToString();
            txt_contactNo.Text = Session["EMP_CONTACT"].ToString();

        }
        else { 

}
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_State", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@StateID", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();
        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
    }
    public void Bind_br_Continuitydetails()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_BUSINESS_CONTINUITY", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LNNO",txtLoanNo.Text);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
            {
                txtAppName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                Txtarea.Text = dsdd.Tables[0].Rows[0]["AREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AREA"].ToString() : "";
                txtProduct.Text = dsdd.Tables[0].Rows[0]["PRODUCT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PRODUCT"].ToString() : "";
                txt_Branch.Text = dsdd.Tables[0].Rows[0]["BRANCH"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BRANCH"].ToString() : "";
                txtLoanAgrrement.Text = dsdd.Tables[0].Rows[0]["LD_LOAN_NO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_LOAN_NO"].ToString() : "";
                txtCOntactNo.Text = dsdd.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
                txtSancAmt.Text = dsdd.Tables[0].Rows[0]["LD_LOAN_AMT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_LOAN_AMT"].ToString() : "";
                txtDOF.Text = dsdd.Tables[0].Rows[0]["LD_LOAN_DATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_LOAN_DATE"].ToString() : "";
                txtPropAddrs.Text = dsdd.Tables[0].Rows[0]["LD_ADDRESS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_ADDRESS"].ToString() : "";
                txtPropAddrs1.Text = dsdd.Tables[0].Rows[0]["LD_ADDRESS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_ADDRESS"].ToString() : "";

                string camtype = dsdd.Tables[0].Rows[0]["CAM_TYPE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TYPE"].ToString() : "";
                Session["camtype"] = camtype.ToString();

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=BusinessContinuityAudit.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    public void Bind_borrowings()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_BUSINESSICOMESOURCE", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LDID", txtLoanNo.Text);
            cmd.Parameters.AddWithValue("@process", Session["camtype"].ToString());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            if (ds1.Tables[0] != null && ds1.Tables[0].Rows.Count > 0)
            {

                txtmarketValue.Text = ds1.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? ds1.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
                txt_ovrAllpropertyvalue.Text = ds1.Tables[0].Rows[0]["PROPERTY ADDRESS"] != DBNull.Value ? ds1.Tables[0].Rows[0]["PROPERTY ADDRESS"].ToString() : "";
            }

            gv_borrowings.DataSource = ds1.Tables[0];
            gv_borrowings.DataBind();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=BusinessContinuityAudit.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    public void Bind_Incomesource()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_BUSINESSICOMESOURCE", con);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LDID", txtLoanNo.Text);
            cmd.Parameters.AddWithValue("@process", Session["camtype"].ToString());

            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            GV_INCOMESOURCE.DataSource = ds1.Tables[0];
            GV_INCOMESOURCE.DataBind();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=BusinessContinuityAudit.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    //public void BindqueryGrid()
    //{
    //    SqlConnection con = new SqlConnection(strcon);
    //    try
    //    {
    //        con.Open();
    //        SqlCommand cmd = new SqlCommand("[RTS_SP_BusinessConAuditBinddetails]", con);
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
    //        cmd.Parameters.AddWithValue("@LD_NO", txtLoanNo.Text);
    //        cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
    //        cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");

    //        SqlDataAdapter da = new SqlDataAdapter(cmd);
    //        DataSet ds1 = new DataSet();
    //        da.Fill(ds1);
    //        if (ds1.Tables[0].Rows.Count != 0)
    //        {
    //            gvBr_Audit.Visible = true;
    //            //Panel1.Visible = true;
    //            gvBr_Audit.DataSource = ds1.Tables[0];
    //            gvBr_Audit.DataBind();
    //            if (ds1.Tables[0].Rows.Count > 0)
    //            {
    //                gvBr_Audit.HeaderRow.Font.Bold = true;
    //                gvBr_Audit.HeaderRow.Cells[1].Text = "LEAD NO";
    //                gvBr_Audit.HeaderRow.Cells[2].Text = "BRANCH";
    //                gvBr_Audit.HeaderRow.Cells[3].Text = "APPLICANT NAME";
    //                gvBr_Audit.HeaderRow.Cells[4].Text = "AREA";


    //                gvBr_Audit.HeaderRow.Cells[1].Wrap = false;
    //                gvBr_Audit.HeaderRow.Cells[2].Wrap = false;
    //                gvBr_Audit.HeaderRow.Cells[3].Wrap = false;
    //                gvBr_Audit.HeaderRow.Cells[4].Wrap = false;

    //            }
    //        }
    //        else
    //        {
    //            uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
    //            gvBr_Audit.Visible = false;
    //            this.pnlTable.Visible = false;
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
    //    }
    //    finally
    //    {
    //        con.Close();
    //    }
    //}
        
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        //Assumes the Price column is at index 4
        if (e.Row.RowType == DataControlRowType.DataRow)
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLoanNo.Enabled = false;
    }
    public void GetAreaID(string strLeadID)
    {
        DataTable dt = null;
        SqlConnection con = new SqlConnection(strcon);
        try
        {

            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select MB.BR_AR_ID from LSD_LEAD  LD  left join MR_BRANCH MB ON LD.LD_BR_ID = MB.BR_ID left join MR_AREA MA ON MA.AR_ID = MB.BR_AR_ID where LD_ID ='" + strLeadID + "' ", con);

            DataSet ds = new DataSet(); da.Fill(ds);
            dt = ds.Tables[0];
            Session["AREAID"] = ds.Tables[0].Rows[0][0].ToString();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }



    }

    public DataTable GetOCIList()
    {
        DataTable dt = null;
        SqlConnection con = new SqlConnection(strcon);
        try
        {

            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select *,MB.BR_AR_ID from MR_EMPLOYEE ME left JOin MR_EMP_TYPE  MET ON MET.ET_ID  =ME.EMP_ET_ID  Left JOIN  MR_BRANCH MB ON ME.EMP_BR_ID =  MB.BR_ID  where MET.ET_DESC='OCI' and ME.EMP_STAT=1 ", con);
            //SqlDataAdapter da = new SqlDataAdapter("select * from MR_EMPLOYEE where EMP_ET_ID=14 ", con);
            DataSet ds = new DataSet(); da.Fill(ds);
            dt = ds.Tables[0];
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

        return dt;

    }
    private DataTable BorrowingTable()
    {
        Borrowing = new DataTable();
        Borrowing.Columns.Add("BCA_KYC_ID", typeof(int));
        Borrowing.Columns.Add("BCA_LOAN_SOURCE", typeof(string));
        Borrowing.Columns.Add("BCA_LOAN_AMT", typeof(string));
        Borrowing.Columns.Add("BCA_MNTLY_INSTL", typeof(string));

        foreach (GridViewRow grow1 in gv_borrowings.Rows)
        {
            string borrw, borrow1, borrow2;
            TextBox loansource = (TextBox)grow1.FindControl("txt_loansource") as TextBox;
            TextBox loanAmt = (TextBox)grow1.FindControl("txt_loanAmt") as TextBox;
            TextBox MonthlyInstal = (TextBox)grow1.FindControl("txt_MonthlyInstalment") as TextBox;
            Label LBL_LCDIRD = (Label)grow1.FindControl("lbl_kyc_id1") as Label;
            borrw = loansource.Text;
            borrow1 = loanAmt.Text;
            borrow2 = MonthlyInstal.Text;
            DataRow row2 = Borrowing.NewRow();
            row2["BCA_KYC_ID"] = Convert.ToInt32(LBL_LCDIRD.Text);
            row2["BCA_LOAN_SOURCE"] = borrw;
            row2["BCA_LOAN_AMT"] = borrow1;
            row2["BCA_MNTLY_INSTL"] = borrow2;
            Borrowing.Rows.Add(row2);

        }
        return Borrowing;
    }
    private DataTable IncomeTable()
    {
        Income = new DataTable();
        Income.Columns.Add("[ICA_KYC_ID]", typeof(int));
        Income.Columns.Add("[ICA_INCOME_SOURCE]", typeof(string));
        Income.Columns.Add("[ICA_JOB_TYPE]", typeof(string));
        foreach (GridViewRow grow in GV_INCOMESOURCE.Rows)
        {
            string loansource, loanAMT;
            Label LBL_LCDIRD = grow.FindControl("lbl_income") as Label;
            TextBox loansource1 = grow.FindControl("txt_loanAmt1") as TextBox;
            TextBox loanAmt1 = grow.FindControl("txt_naturebusjob") as TextBox;
            loansource = loansource1.Text;
            loanAMT = loanAmt1.Text;
            DataRow row1 = Income.NewRow();
            row1["[ICA_KYC_ID]"] = Convert.ToInt32(LBL_LCDIRD.Text);
            row1["[ICA_INCOME_SOURCE]"] = loansource;
            row1["[ICA_JOB_TYPE]"] = loanAMT;
            Income.Rows.Add(row1);
        }
        return Income;
    }
        
    public void btn_submit(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_INSERT_CONTINUITY", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@LCA_LD_ID", txtLoanNo.Text);//Convert.ToInt32(lbLeadno.Text)
            cmd.Parameters.AddWithValue("@LCA_LOAN_UTILTY", txt_Loan_utl.Text);
            cmd.Parameters.AddWithValue("@LCA_CONSTR_STAGE", txtCon_stage.Text);
            cmd.Parameters.AddWithValue("@LCA_FB_STATUS", ddldoubtfull.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@LCA_FB_COMMENTS", txt_doubtubtful.Text);

            cmd.Parameters.AddWithValue("@LCA_REF1_NAME", txtRef1_Name.Text);
            cmd.Parameters.AddWithValue("@LCA_REF1_ADDR", txtRef1_Addr.Text);
            cmd.Parameters.AddWithValue("@LCA_REF1_CONTACT", txtRef1_Contact.Text);
            cmd.Parameters.AddWithValue("@LCA_REF1_CMTS", txtRef1_FB.Text);

            cmd.Parameters.AddWithValue("@LCA_REF2_NAME", txtRef2_Name.Text);
            cmd.Parameters.AddWithValue("@LCA_REF2_ADDR", txtRef2_Addr.Text);
            cmd.Parameters.AddWithValue("@LCA_REF2_CONTACT", txtRef2_Contact.Text);
            cmd.Parameters.AddWithValue("@LCA_REF2_CMTS", txtRef2_FB.Text);

            cmd.Parameters.AddWithValue("@user_ID", Convert.ToInt32(Session["ID"]));
            cmd.Parameters.AddWithValue("@inscoure", IncomeTable());
            cmd.Parameters.AddWithValue("@borrow", BorrowingTable());

            cmd.ExecuteNonQuery();

          
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Business Continuity Audit for " + txtLoanNo.Text + "   Saved Successfully');window.location.reload()", true);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=BusinessContinuityAudit.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("BusinessContinuityAudit.aspx");
    }
   
   
    public void clear()
    {
        txt_Branch.Text = "";
        Txtarea.Text = "";
        txtAppName.Text = "";
        txtCOntactNo.Text = "";
        txtDOF.Text = "";
        txtLoanNo.Text = "";
        txtLoanAgrrement.Text = "";
        txtmarketValue.Text = "";
        txtProduct.Text = "";
        txtPropAddrs.Text = "";
        txtSancAmt.Text = "";
        txt_ovrAllpropertyvalue.Text = "";
        txt_EmpCode.Text = "";
        txt_doubtubtful.Text = "";
        txt_conducted.Text = "";
        if (ddldoubtfull.Items.Count > 0)
        {
            ddldoubtfull.SelectedIndex = 0;

        }
    }

}

