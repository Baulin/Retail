﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_Customer_Profile : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DataSet dss = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                BindGrid();
            }
        }
    }

    #region "BindGrid"
    public void BindGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmd = new SqlCommand("SP_MAS_CUSTOMER_PROFILE", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@TYPE", 2);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dss);

            gvcustomerprofile.DataSource = dss.Tables[0];
            gvcustomerprofile.DataBind();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    #endregion

    #region "select_CheckedChanged"
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            Label lblcusproId = null;

            foreach(GridViewRow growdoc in gvcustomerprofile.Rows)
            {
                RadioButton chkStat = growdoc.FindControl("rb_select") as RadioButton;
                int index = growdoc.RowIndex;

                if (chkStat.Checked)
                {
                    lblcusproId = (Label)gvcustomerprofile.Rows[index].Cells[1].FindControl("lblCUSPRID");

                    SqlCommand cmd = new SqlCommand("SP_MAS_CUSTOMER_PROFILE", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PRF_ID", lblcusproId.Text);
                    cmd.Parameters.AddWithValue("@TYPE", 1);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    Session["PRF_ID"] = lblcusproId.Text;
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtprofile.Text = Convert.ToString(ds.Tables[0].Rows[0]["PRF_DESC"]);

                        if (ddlprofilestatus.Items.FindByValue(Convert.ToString(ds.Tables[0].Rows[0]["PRF_STAT"])) != null)
                        {
                            ddlprofilestatus.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["PRF_STAT"]);
                        }
                        else
                        {
                            ddlprofilestatus.SelectedIndex = 0;
                        }

                    }

                    btnSubmit.Text = "Update";
                    break;

                }
                    
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    #endregion

    #region "Submit"
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if(ddlprofilestatus.SelectedIndex==0)
            {
                uscMsgBox1.AddMessage("Please select the Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            if (btnSubmit.Text == "Submit")
                InsertUpdate("INSERT");
            else
                InsertUpdate("Update");
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    #endregion

    #region "Insertupdate"
    protected void InsertUpdate(string checkactivity)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmdinsert = new SqlCommand("SP_MAS_CUSTOMER_PROFILE", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@PRF_DESC", txtprofile.Text);
            cmdinsert.Parameters.AddWithValue("@PRF_STAT", ddlprofilestatus.SelectedValue);

            if (checkactivity == "Update")
            {
                cmdinsert.Parameters.AddWithValue("@PRF_MBY", Session["ID"]);
                cmdinsert.Parameters.AddWithValue("@PRF_ID", Session["PRF_ID"]);
                cmdinsert.Parameters.AddWithValue("@TYPE", 4);
            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@PRF_CBY", Session["ID"]);
                cmdinsert.Parameters.AddWithValue("@TYPE", 3);
            }

            int r = cmdinsert.ExecuteNonQuery();
            BindGrid();
            if(r>0)
            {
                if (checkactivity == "Update")
                {
                    btnSubmit.Text = "Submit";
                }
                clear();
                uscMsgBox1.AddMessage("Records Saved Sucessfully.",YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                return;
            }
            else
            {
                uscMsgBox1.AddMessage("Records not Saved Or Already Exists.",YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }


        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    #endregion

    #region "Cancel"
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clear();
        btnSubmit.Text = "Submit";
    }
    #endregion

    #region "clear"
    protected void clear()
    {
        txtprofile.Text = "";
        ddlprofilestatus.SelectedIndex = 0;
    }
    #endregion

}