﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Tracker;
using Utilities;

public partial class HDesk_PRDD_QCQuery : System.Web.UI.Page
{
    int ldid;
    int ftid;
    public string status = "";
    string leadno = "";
    string appname;
    string pddt;
    string lnamt;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string bcc3;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    public static DataTable dtQuery = null;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    public static bool blMailStatus = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        MICR_NO.Visible = false;
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
            }
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
    }


    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        //   ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();
    }
    protected void cb_selectheader_SelectedIndexChanged(object sender, EventArgs e)
    {
        CheckBox chkheader = gvQuerydets.HeaderRow.FindControl("cb_selectheader") as CheckBox;
        if (chkheader.Checked)
        {
            foreach (GridViewRow grow in gvQuerydets.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                chkStat.Checked = true;
                TextBox txtRmrks = grow.FindControl("txtRemarks") as TextBox;
                txtRmrks.Enabled = true;
            }
        }
        else
        {
            foreach (GridViewRow grow in gvQuerydets.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                chkStat.Checked = false;
                TextBox txtRmrks = grow.FindControl("txtRemarks") as TextBox;
                txtRmrks.Enabled = false;
            }
        }
    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void cb_select_CheckedChanged(object sender, EventArgs e)
    {
        foreach (GridViewRow grow in gvQuerydets.Rows)
        {
            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                txtRemarks.Enabled = true;

            }
            else
            {
                txtRemarks.Enabled = false;
                txtRemarks.Text = "";
            }
        }
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        lbLeadno.Text = "";
        lbAppname.Text = "";
        lbPDdate.Text = "";
        lbLoanamt.Text = "";
        gvQuerydets.Visible = false;
        MICR_NO.Visible = false;
       /* if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "A";
            gridbindall();
        }
        else if (txtLeadno.Text != "")// && ddlBranch.SelectedItem.Text == "--Select--"
        {
            Session["View"] = "F";

            gridbind();
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--")//&& ddlBranch.SelectedItem.Text != "--Select--"
        {
            Session["View"] = "F";
            gridbind();
        }
        */

        gridbind();
      /*  foreach (GridViewRow grow in gvQuery.Rows)
        {
            Label lblQryResult = (Label)grow.FindControl("lblQryResult");
            int index = grow.RowIndex;
            if (lblQryResult.Text == "T")
            {
                gvQuery.Rows[index].Cells[1].ForeColor = Color.Red;
                gvQuery.Rows[index].Cells[2].ForeColor = Color.Red;
                gvQuery.Rows[index].Cells[3].ForeColor = Color.Red;
                gvQuery.Rows[index].Cells[4].ForeColor = Color.Red;
                gvQuery.Rows[index].Cells[5].ForeColor = Color.Red;
            }

        }*/
    }
    public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_PRDD_WRK", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //            cmd.Parameters.AddWithValue("@PR_ID", "0");
            cmd.Parameters.AddWithValue("@LEADNO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@LD_AR_ID", ddlArea.SelectedIndex > 0 ? ddlArea.SelectedValue : "");
            cmd.Parameters.AddWithValue("@LD_BR_ID", ddlBranch.SelectedIndex > 0 ? ddlBranch.SelectedValue : "");
            cmd.Parameters.AddWithValue("@TranStatus", "GET_DATA");

            cmd.Parameters.AddWithValue("@ReceiveType", "HD_HOVER");
           

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);             
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "SANCTION NO";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {

            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_PRDD_WRK", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //            cmd.Parameters.AddWithValue("@PR_ID", "0");
            cmd.Parameters.AddWithValue("@LEADNO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@LD_AR_ID", ddlArea.SelectedIndex > 0 ? ddlArea.SelectedValue : "");
            cmd.Parameters.AddWithValue("@LD_BR_ID", ddlBranch.SelectedIndex > 0 ? ddlBranch.SelectedValue : "");
            cmd.Parameters.AddWithValue("@TranStatus", "GET_DATA");

            cmd.Parameters.AddWithValue("@ReceiveType", "HD_HOVER");


            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "SANCTION NO";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            con.Open();
            var ddl = (CheckBoxList)e.Row.FindControl("ddlCity");
            string CountryId = e.Row.Cells[1].Text.ToString();
            SqlCommand cmd = new SqlCommand("select QY_QUERY,QY_SQUERY from MR_DISB_QUERY  where QY_QUERY='" + CountryId + "' ORDER BY QY_QUERY,QY_SQUERY ASC", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            ddl.DataSource = ds;
            ddl.DataTextField = "QY_SQUERY";
            ddl.DataValueField = "QY_QUERY";
            ddl.DataBind();
            //ddl.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }
    protected void gvUserInfo_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);

        con.Open();

        GridView dgQuery = gvQuerydets;
        dgQuery.Visible = false;
        MICR_NO.Visible = true;
        foreach (GridViewRow grow in gvQuery.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            Label lnbtn = grow.FindControl("lnkname") as Label;
            Label lblProdCode = grow.FindControl("lblProdCode") as Label;
            //DropDownList ddrsp = grow.FindControl("Editdd") as DropDownList;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                leadno = lnbtn.Text;
                appname = gvQuery.Rows[index].Cells[3].Text;
                pddt = gvQuery.Rows[index].Cells[4].Text;
                lnamt = gvQuery.Rows[index].Cells[5].Text;
                Session["PCODE"] = lblProdCode.Text;
            }
        }

        SqlCommand cmd = new SqlCommand("RTS_SP_DISB_QUERYCHECK", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@LEADNO", leadno);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);

        lblLead.Text = ds.Tables[0].Rows[0][0].ToString();

        Session["Leadno"] = leadno;

        getLeadID(con);

        gvQuerydets.Visible = true;
        qrydetsbind();
        lbLeadno.Visible = true;
        lbAppname.Visible = true;
        lbPDdate.Visible = true;
        lbLoanamt.Visible = true;
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
        MICR_NO.Visible = true;

        lbLeadno.Text = leadno;
        lbAppname.Text = appname;
        lbPDdate.Text = pddt;
        lbLoanamt.Text = lnamt;
        con.Close();
    }
    public void getLeadID(SqlConnection con)
    {
        SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
        cmdbr.CommandType = CommandType.StoredProcedure;
        cmdbr.Parameters.AddWithValue("@LeadNo", Session["Leadno"].ToString());
        SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        DataSet dsbr = new DataSet();
        dabr.Fill(dsbr);
        Session["LeadId"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
    }
    public void qrydetsbind()
    {

        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        GridView gvQuery = null;
        gvQuery = gvQuerydets;
        //  int  qryldid = Session["LeadId"] !=null? Convert.ToInt32(Session["LeadId"]):0;

        SqlCommand cmdqry = new SqlCommand("RTS_SP_FETCH_MPRDD_QUERY", con);
        cmdqry.CommandType = CommandType.StoredProcedure;
        cmdqry.Parameters.AddWithValue("@QY_QUERY", Session["PCODE"] != null ? Session["PCODE"].ToString() : "");
        cmdqry.Parameters.AddWithValue("@TYPE", Session["PCODE"] != null ? Session["PCODE"].ToString() : "");
        SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
        DataSet dsqry = new DataSet();
        daqry.Fill(dsqry);
        if (dsqry.Tables[0].Rows.Count > 0)
        {
            gvQuery.DataSource = dsqry.Tables[0];
            gvQuery.DataBind();
            gvQuery.Visible = true;
        }
        else
        {
            uscMsgBox1.AddMessage("No Record Found !", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        con.Close();



    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('HDesk_PRDD_QCQuery.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            SqlCommand cmd = new SqlCommand("RTS_SP_DISB_QUERYCHECK", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LEADNO", lbLeadno.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            InsertHORaiseQuery();

           // if (Session["View"] == "F")
            //{
                gridbind();
            //}
            //else
           // {
               // gridbindall();
            //}
           
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
            gvQuerydets.Visible = false;
            btnSubmit.Enabled = false;
            MICR_NO.Visible = false;

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //con.Close();
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HDesk_PRDD_QCQuery.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME ,BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //txtLeadno.Enabled = false;
        txtLeadno.Text = "";
    }
    protected void ddlQuery_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    public void InsertHORaiseQuery()
    {
        GridView dgQuery = null;
        int selectedcnt = 0;
        dgQuery = gvQuerydets;

        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        try
        {
            dtQuery = new DataTable();
            DataRow dr = null;
            dtQuery.Columns.Add(new DataColumn("Query Raised", typeof(string)));
            dtQuery.Columns.Add(new DataColumn("Sub Query Raised", typeof(string)));
            foreach (GridViewRow grow in dgQuery.Rows)
            {

                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                Label lblname = grow.FindControl("lblname") as Label;
                TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
                int index = grow.RowIndex;

                if (chkStat.Checked)
                {

                    SqlCommand cmdbr1 = new SqlCommand("RTS_PR_Insert_PRDD_Physical_Query", con);
                    cmdbr1.CommandType = CommandType.StoredProcedure;
                    cmdbr1.Parameters.AddWithValue("@LEAD_ID", Session["LeadId"].ToString());
                    cmdbr1.Parameters.AddWithValue("@QRY_QUERY", lblname.Text);
                    cmdbr1.Parameters.AddWithValue("@QRY_SQUERY", txtRemarks.Text);
                    cmdbr1.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                    int n = cmdbr1.ExecuteNonQuery();


                    if (n <= 0)
                    {
                        uscMsgBox1.AddMessage("Query already Raised for that Lead ID =" + Session["LeadId"].ToString() + " ( " + lblname.Text + ")", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                    else
                    {
                        dr = dtQuery.NewRow();
                        dr["Query Raised"] = lblname.Text;
                        dr["Sub Query Raised"] = txtRemarks.Text;
                        dtQuery.Rows.Add(dr);
                        selectedcnt = selectedcnt + 1;

                    }

                }

            }



        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            if (selectedcnt <= 0)
            {


                uscMsgBox1.AddMessage("Please Select Query", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                uscMsgBox1.AddMessage("Query Raised Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                sendMail(con);

                string strMailStatus = "";
                string strSuccessMsg = "";
                if (blMailStatus == true)
                {
                    strMailStatus = "Successfully";
                }
                else
                {
                    strMailStatus = "Failed";
                }
                strSuccessMsg = Session["Leadno"].ToString() + " - " + " <br/> Mail Sent " + strMailStatus + "  ";
                strSuccessMsg += "<br/> Mail To: " + toID + " ; CC To: " + ccID + " ";



                uscMsgBox1.AddMessage(strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }

            con.Close();
        }

        // gvResolve.Visible = false;
    }
    public void sendMail(SqlConnection con)
    {
        try
        {
            /////// mail ///////////
            //  strMailDetail = "";

            SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "'", con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);



            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["LD_BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["LD_BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT EM_BM,EM_AM,EM_CM,EM_BCC,EM_CLM FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
                cc = dsmailto.Tables[0].Rows[0]["EM_AM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() : "";
                bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
                bcc3 = dsmailto.Tables[0].Rows[0]["EM_CLM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_CLM"].ToString() : "";
            }

            if (cc != "")
            {
                cc = cc + ";retail-helpdesk@equitasbank.com";
            }
            else
            {
                cc = "retail-helpdesk@equitasbank.com";
            }
            if (bcc3 != "")
            {
                cc = cc + ";" + bcc3;
            }


            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            //to = "ManimaranK@equitasbank.com";
            //bcc2 = "ManimaranK@equitasbank.com";
            //cc = "PalanikumarA@equitasbank.com";
            fromID = "RTS Alerts";
            toID = to;
            //   to = "ManimaranK@equitasbank.com";
            bcc2ID = bcc2;
            ccID = cc;

            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/>Please find below details of  Pre-Disbursement queries<br/>";
                //BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td>";
                //BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + dsdet.Tables[0].Rows[0]["LD_APNAME"].ToString() + "</strong></td></tr>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + "</strong></td>";
                //BodyTxt = BodyTxt + "<td>Loan Amount</td><td><strong>" + Session["Loanamt"] + "</strong></td></tr></table><br/><br/>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Address </td><td align='center'>:</td><td><strong>" + cusaddr + "</strong></td></tr>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Mobile No.</td><td align='center'>:</td><td><strong>" + mobile + "</strong></td></tr></table><br/><br/>";
                int b = dtQuery.Rows.Count;
                if (b != 0)
                {
                    BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='center'  width='10%'>Sl. No.</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Credit Query Details</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Query Date</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Response</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Response Date</td>";

                    BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' width='40%'>Query Type</td>";
                    BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' width='40%'>Remarks</td></span></tr>";
                    for (int j = 0; j <= b - 1; j++)
                    {
                        int sno = j + 1;
                        BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td bgcolor='#FFFFFF' align='right'> " + sno + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Query Raised"].ToString() + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Date"].ToString() + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response"].ToString() + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response Date"].ToString() + "</td>";
                        BodyTxt = BodyTxt + "<td bgcolor='#FFFFFF'> " + dtQuery.Rows[j]["Query Raised"].ToString() + "</td>";
                        BodyTxt = BodyTxt + "<td bgcolor='#FFFFFF'> " + dtQuery.Rows[j]["Sub Query Raised"].ToString() + "</td></span></tr>";
                    }
                    BodyTxt = BodyTxt + "</table>";
                }

                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>Retail Ops - QC Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
                //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

                blMailStatus = EmailManager.sendemail(to, "RTS Alerts", bcc2, cc, "PRDD QUERY  " + Session["Leadno"].ToString() + " - " + dsdet.Tables[0].Rows[0]["LD_APNAME"].ToString() + " - " + dsdet.Tables[0].Rows[0]["AR_NAME"].ToString() + "- " + dsdet.Tables[0].Rows[0]["BR_NAME"].ToString() + "", BodyTxt, "", true);
                //sendemail("SurendharR@equitasbank.com;PrabhakaranA@equitasbank.com;Tamilalagand@equitasbank.com", "surendharr@equitasbank.com", "Test", BodyTxt, "", true);

                //strMailBody = BodyTxt.Replace("<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Credit " + ddlApprv.SelectedItem.ToString() + "<br/><br/>", "");
                //strMailBody = BodyTxt.Replace("</html>", " ");


            //});
            //// strMailDetail = to + "," + bcc2 + "," + cc;
            //threadSendMails.IsBackground = true;

            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(5000);

        }
        catch (Exception ex)
        {
             ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }

    }
    protected void btn_MICR_Click(object sender, EventArgs e)
    {
        MICR_NO.Visible = true;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_GET_MICR", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MICR_NO", txt_MICR.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            gv_MICR.DataSource = ds.Tables[0];
            gv_MICR.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gv_MICR.HeaderRow.Font.Bold = true;
                gv_MICR.HeaderRow.Cells[0].Text = "MICR No";
                gv_MICR.HeaderRow.Cells[1].Text = "Bank Name";
                gv_MICR.HeaderRow.Cells[2].Text = "Bank Branch";
                gv_MICR.HeaderRow.Cells[3].Text = "Location";

            }
            else
            {
                uscMsgBox1.AddMessage("Invalid MICR No", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
}