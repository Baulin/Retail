﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;
public partial class Branch_SCI_Appeal : System.Web.UI.Page
{
    int ldid, s;
    string sa;
    string sendto;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string send;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    

    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            txtBranch.Text = Session["UNITNAME"].ToString();
            bindArea();
            bind();
        }
    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        ddlProduct.SelectedIndex = 0;

    }

    protected void ddlbranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlProduct.SelectedIndex = 0;
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
        s = 0;

        foreach (GridViewRow grow in gvBranchSF.Rows)
        {

            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            TextBox txtRemark = grow.FindControl("txtRemark") as TextBox;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                txtRemark.Visible = true;

            }
            else
            {
                txtRemark.Visible = false;
                txtRemark.Text = "";
            }
        }

    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();
        ddlProduct.DataSource = dsdd;
        ddlProduct.DataTextField = "PR_CODE";
        ddlProduct.DataValueField = "PRD";
        ddlProduct.DataBind();
        ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            s = 0;
            bool rmkstatus = false;

            foreach (GridViewRow grow in gvBranchSF.Rows)
            {

                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                TextBox txtRemark = grow.FindControl("txtRemark") as TextBox;
                int index = grow.RowIndex;
                if (chkStat.Checked && txtRemark.Text.Trim() == "")
                {
                    rmkstatus = true;
                    break;
                }

            }
            if (!rmkstatus)
            {
                foreach (GridViewRow grow in gvBranchSF.Rows)
                {

                    CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                    TextBox txtRemark = grow.FindControl("txtRemark") as TextBox;
                    int index = grow.RowIndex;
                    if (chkStat.Checked)
                    {
                        s += 1;
                        Label lblLeadId = (Label)gvBranchSF.Rows[index].Cells[0].FindControl("lblLeadID");
                        SqlCommand cmdinsert = new SqlCommand("RTS_Update_Branch_Appeal_SCI", con);
                        cmdinsert.CommandType = CommandType.StoredProcedure;
                        cmdinsert.Parameters.AddWithValue("@SL_LD_ID", lblLeadId.Text);
                        cmdinsert.Parameters.AddWithValue("@Remark", txtRemark.Text);
                        cmdinsert.Parameters.AddWithValue("@AppealType", ddlAppealType.SelectedItem.Text);
                        cmdinsert.ExecuteNonQuery();

                    }

                }

                gridbind();
                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
                btnSubmit.Enabled = false;
                uscMsgBox1.AddMessage(s + " File/s Marked as Sent Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
            else
            {
                uscMsgBox1.AddMessage("please enter the remarks", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_SendFile.aspx");
    }
    public void gridbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();



            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Branch_Apeeal_TO_SCI", con);
            cmd.CommandType = CommandType.StoredProcedure;
            string[] PRARR = ddlProduct.SelectedIndex > 0 ? ddlProduct.SelectedValue.ToString().Split('-') : null;

            cmd.Parameters.Add("@LD_PR_ID", SqlDbType.VarChar).Value = PRARR[0].ToString();
            //cmd.Parameters.Add("@LD_PR_ID", SqlDbType.VarChar).Value = ddlProduct.SelectedValue.ToString();  
            //Bala changes 24/02/2016
            //cmd.Parameters.Add("@LD_BR_ID", SqlDbType.VarChar).Value = Session["BRANCHID"].ToString();
            cmd.Parameters.Add("@LD_BR_ID", SqlDbType.VarChar).Value = ddlBranch.SelectedValue;
            cmd.Parameters.Add("@AppealType", SqlDbType.VarChar).Value = ddlAppealType.SelectedItem.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //Panel1.Visible = true;
            gvBranchSF.DataSource = ds.Tables[0];
            gvBranchSF.DataBind();
            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    gvBranchSF.HeaderRow.Font.Bold = true;
            //    gvBranchSF.HeaderRow.Cells[1].Text = "LEAD NO";
            //    gvBranchSF.HeaderRow.Cells[2].Text = "LEAD DATE";
            //    gvBranchSF.HeaderRow.Cells[3].Text = "APPLICANT NAME";
            //    //gvBranchSF.HeaderRow.Cells[4].Text = "PD DATE";
            //    gvBranchSF.HeaderRow.Cells[4].Text = "LOAN AMOUNT";

            //    gvBranchSF.HeaderRow.Cells[1].Wrap = false;
            //    gvBranchSF.HeaderRow.Cells[2].Wrap = false;
            //    gvBranchSF.HeaderRow.Cells[3].Wrap = false;
            //    gvBranchSF.HeaderRow.Cells[4].Wrap = false;
            //    //gvBranchSF.HeaderRow.Cells[5].Wrap = false;
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Records not found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        gridbind();
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }
}