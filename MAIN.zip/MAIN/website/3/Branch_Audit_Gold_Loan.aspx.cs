﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Data.OleDb;
using System.IO;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using Tracker;
using System.Globalization;
using System.Threading;

public partial class Branch_Audit_Gold_Loan : System.Web.UI.Page
{

    #region Common
    SqlConnection con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_Obj = new SqlCommand();
    DataTable dt_obj = new DataTable();
    CreateLogFiles Err = new CreateLogFiles();
    ReportDocument rpt = new ReportDocument();
    string stDate = string.Empty;
    string dcsServerDate = string.Empty;

    ClsCommon clscommon = new ClsCommon();

    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    string brName = string.Empty;
    string collectionTotal = "0";
    string Adt = "";
    string Cdt = "";
    string chk = "";

    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    //getServerDate();
                    // txtBranch.Text = Convert.ToString(Session["UNITNAME"]);
                    //  txtBrCode.Text = Convert.ToString(Session["UNIT"]);
                    //if (lblSMEAmt.Text != "0" && lblMFAmt.Text != "0")
                    //    trRmrks.Visible = true;
                    //else
                    //    trRmrks.Visible = false;
                    bindArea();

                    // txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    //if (DateTime.Now.ToString("dd/MM/yyyy") != txtDate.Text)
                    //    Response.Redirect("~/RTS_Cash_Summary");

                    bindQustions("2");
                    bindRegisterChecking("3");
                    bindBRAuditObs("4");
                    bindCusKYCCheckBR("5");
                }
            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void bindArea()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();

            cmd_Obj = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
            }
            else
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", 0);
            }
            dt_obj = new DataTable();
            dt_obj.Load(cmd_Obj.ExecuteReader());
            ddlst_Area.DataSource = dt_obj;
            ddlst_Area.DataTextField = "AR_NAME";
            ddlst_Area.DataValueField = "AR_ID";
            ddlst_Area.DataBind();
            ddlst_Area.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Area.SelectedValue = Session["AREA_ID"].ToString();

            bindBranch();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }
    }
    public void bindBranch()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();

            cmd_Obj = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);

            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());
            ddlst_Branch.DataSource = dt_obj;
            ddlst_Branch.DataTextField = "BR_NAME";
            ddlst_Branch.DataValueField = "BR_ID";
            ddlst_Branch.DataBind();

            ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
            if (Session["USR_ACS"].ToString() == "7")
            {
                ddlst_Branch.SelectedValue = Session["BRANCHID"].ToString();
                ddlst_Branch.Enabled = false;
                ddlst_Area.Enabled = false;
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }

    }

    protected void ddlst_Area_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            // ddlst_Branch.SelectedIndex = 0;
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);
            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());

            ddlst_Branch.DataSource = dt_obj;
            ddlst_Branch.DataTextField = "BR_NAME";
            ddlst_Branch.DataValueField = "BR_ID";
            ddlst_Branch.DataBind();
            ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Branch.Enabled = true;
            //ClearValues();
            ddlst_Branch.SelectedIndex = 0;
            // txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            txtDate.Text = "";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }
    }

    protected void ddlst_Branch_SelectedIndexChanged(object sender, EventArgs e)
    {
        //ClearValues();
        // txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
        txtDate.Text = "";
    }

    public string chkPhysicalGold()
    {
        string strPhysicalGold = "";
        try
        {
            string desc = string.Empty;
            int index = 0;
            int count = 0;
            // string[] loanNo = ddlApplicantid.SelectedItem.Text.Split('|');
            bool chkAll = false;
            string qusChk = string.Empty;
            DateTime dtd;
            dtd = DateTime.ParseExact(txtDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            //Cash Register Check
            foreach (GridViewRow gvRow in gvQus.Rows)
            {
                // index = gvRow.RowIndex + 1;
                index = gvRow.RowIndex;
                Label lblMGA_ID = gvRow.FindControl("lblMGA_ID") as Label;
                RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                if (chkStat.SelectedIndex != -1)
                {
                    chkAll = true;


                }
                else
                {
                    count += 1;
                    chkAll = false;
                    //qusChk = index + "." + Convert.ToString(gvQus.Rows[index].Cells[1].Text.Trim());
                    qusChk =  Convert.ToString(gvQus.Rows[index].Cells[1].Text.Trim()) +" in Cash register check";
                    break;
                }

            }
            strPhysicalGold += count + "|" + qusChk;

        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        return strPhysicalGold;
    }
    public string chkRegisterChecking()
    {
        string strRegisterChecking = "";
        try
        {
            string desc = string.Empty;
            int index = 0;
            int count = 0;
            // string[] loanNo = ddlApplicantid.SelectedItem.Text.Split('|');
            bool chkAll = false;
            string qusChk = string.Empty;
            DateTime dtd;
            dtd = DateTime.ParseExact(txtDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            //Cash Register Check
            foreach (GridViewRow gvRow in gvRegChecking.Rows)
            {
                // index = gvRow.RowIndex + 1;
                index = gvRow.RowIndex;
                Label lblMGA_ID = gvRow.FindControl("lblMGA_ID") as Label;
                RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                if (chkStat.SelectedIndex != -1)
                {
                    chkAll = true;

                }
                else
                {
                    count += 1;
                    chkAll = false;
                    //qusChk = index + "." + Convert.ToString(gvQus.Rows[index].Cells[1].Text.Trim());
                    qusChk = Convert.ToString(gvRegChecking.Rows[index].Cells[1].Text.Trim()) + " in Register checking";
                    break;
                }

            }
            strRegisterChecking += count + "|" + qusChk;

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        return strRegisterChecking;
    }
    public string chkBRAuditObservation()
    {
        string strRegisterChecking = "";
        try
        {
            string desc = string.Empty;
            int index = 0;
            int count = 0;
            // string[] loanNo = ddlApplicantid.SelectedItem.Text.Split('|');
            bool chkAll = false;
            string qusChk = string.Empty;
            DateTime dtd;
            dtd = DateTime.ParseExact(txtDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            //Cash Register Check
            foreach (GridViewRow gvRow in gvBrAuditObs.Rows)
            {
                // index = gvRow.RowIndex + 1;
                index = gvRow.RowIndex;
                Label lblMGA_ID = gvRow.FindControl("lblMGA_ID") as Label;
                RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                if (chkStat.SelectedIndex != -1)
                {
                    chkAll = true;

                }
                else
                {
                    count += 1;
                    chkAll = false;
                    //qusChk = index + "." + Convert.ToString(gvQus.Rows[index].Cells[1].Text.Trim());
                    qusChk = Convert.ToString(gvBrAuditObs.Rows[index].Cells[1].Text.Trim()) + " in Branch Audit Observation";
                    break;
                }

            }
            strRegisterChecking += count + "|" + qusChk;

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        return strRegisterChecking;
    }
    public string chkKYCCheckAtBranch()
    {
        string strRegisterChecking = "";
        try
        {
            string desc = string.Empty;
            int index = 0;
            int count = 0;
            // string[] loanNo = ddlApplicantid.SelectedItem.Text.Split('|');
            bool chkAll = false;
            string qusChk = string.Empty;
            DateTime dtd;
            dtd = DateTime.ParseExact(txtDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            //Cash Register Check
            foreach (GridViewRow gvRow in gvKYCCheckBR.Rows)
            {
                // index = gvRow.RowIndex + 1;
                index = gvRow.RowIndex;
                Label lblMGA_ID = gvRow.FindControl("lblMGA_ID") as Label;
                RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                if (chkStat.SelectedIndex != -1)
                {
                    chkAll = true;

                }
                else
                {
                    count += 1;
                    chkAll = false;
                    //qusChk = index + "." + Convert.ToString(gvQus.Rows[index].Cells[1].Text.Trim());
                    qusChk = Convert.ToString(gvKYCCheckBR.Rows[index].Cells[1].Text.Trim()) + " in Customer KYC Check At Branch";
                    break;
                }

            }
            strRegisterChecking += count + "|" + qusChk;

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        return strRegisterChecking;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try{
            string desc = string.Empty;
            int index = 0;
            // string[] loanNo = ddlApplicantid.SelectedItem.Text.Split('|');
            bool chkAll = false;
            string qusChk = string.Empty;
            DateTime dtd;
            dtd = DateTime.ParseExact(txtDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            //Initialize Cash Register check
            int cntPhysical=0;
            string strPhysical="";
            strPhysical=chkPhysicalGold();
            string strPhysicalqus="";
            //Initialize Register Checking
            int cntRegCheck = 0;
            string strRegCheck = "";
            strRegCheck = chkRegisterChecking();
            string strRegCheckQus = "";
            //Initialize Branch Audit Observation
            int cntBRAuditObs = 0;
            string strBRAuditObs = "";
            strBRAuditObs = chkBRAuditObservation();
            string strBRAuditObsQus = "";
            // Initialize Customer KYC Check At Branch
            int cntCusKYCAtBR = 0;
            string strCusKYCAtBR = "";
            strCusKYCAtBR = chkKYCCheckAtBranch();
            string strCusKYCAtBRQus = "";
            //Split Cash Register check
            string[] strPlotPER = strPhysical.Split('|');
            cntPhysical = Convert.ToInt32(strPlotPER[0].ToString());
            strPhysicalqus = strPlotPER[1].ToString();
            //Split Register Checking
            string[] strRegCheckLst = strRegCheck.Split('|');
            cntRegCheck = Convert.ToInt32(strRegCheckLst[0].ToString());
            strRegCheckQus = strRegCheckLst[1].ToString();
            //Split Branch Audit Observation
            string[] strBRAuditObsLst = strBRAuditObs.Split('|');
            cntBRAuditObs = Convert.ToInt32(strBRAuditObsLst[0].ToString());
            strBRAuditObsQus = strBRAuditObsLst[1].ToString();
            //Split Customer KYC Check At Branch
            string[] strCusKYCAtBRLst = strCusKYCAtBR.Split('|');
            cntCusKYCAtBR = Convert.ToInt32(strCusKYCAtBRLst[0].ToString());
            strCusKYCAtBRQus = strCusKYCAtBRLst[1].ToString();


            #region Gold_Audit_Calculations
            if((txtNoOfPackets.Text==""))
            {
                uscMsgBox1.AddMessage("Please enter physical gold audit check", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
                if (cntPhysical > 0)
            {
                uscMsgBox1.AddMessage("Please select option of " + strPhysicalqus, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
                    if (cntRegCheck > 0)
            {
                uscMsgBox1.AddMessage("Please select option of " + strRegCheckQus, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                lnkCustomerKYC.NavigateUrl = "#CustomerKYC";
            }
            else
                        if (cntBRAuditObs > 0)
            {
                uscMsgBox1.AddMessage("Please select option of " + strBRAuditObsQus, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                lnkCustomerKYC.NavigateUrl = "#CustomerKYC";
            }
            else
                            if (cntCusKYCAtBR > 0)
            {
                uscMsgBox1.AddMessage("Please select option of " + strCusKYCAtBRQus, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                lnkCustomerKYC.NavigateUrl = "#CustomerKYC";
            }
            else
            {

                //Physical Gold Packet Check
                if (txtNoOfPackets.Text != "")
                {

                    clscommon.RTS_SP_INSERT_GOLD_AUDIT(Convert.ToInt32(ddlst_Branch.SelectedValue), dtd,clscommon.Get_MR_GoldAudit_QUS_ID(1), txtNoOfPackets.Text, txtGoldInsCmts1.Text, Convert.ToInt32(Session["EMP_ID"].ToString()));

                }

                //Cash Register Check
                foreach (GridViewRow gvRow in gvQus.Rows)
                {
                    index = gvRow.RowIndex + 1;
                    Label lblMGA_ID = gvRow.FindControl("lblMGA_ID") as Label;
                    RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                    if (chkStat.SelectedIndex != -1)
                    {
                        //chkAll = true;
                        //desc += index + "||" + chkStat.SelectedItem.Text + "$";

                        clscommon.RTS_SP_INSERT_GOLD_AUDIT(Convert.ToInt32(ddlst_Branch.SelectedValue), dtd, Convert.ToInt32(lblMGA_ID.Text), chkStat.SelectedItem.Text, txtGoldInsCmts2.Text, Convert.ToInt32(Session["EMP_ID"].ToString()));
                    }
                    else
                    {
                        chkAll = false;
                        qusChk = index + "." + Convert.ToString(gvQus.Rows[index].Cells[1].Text.Trim());
                        break;
                    }
                    //qusChk = chkStat.SelectedIndex != -1 ? chkStat.SelectedItem.Text : "No";
                    //desc += index + "||" + chkStat.SelectedItem.Text + "$";
                    //desc += index + "||" + qusChk + "$";
                }
                //Register Checking
                foreach (GridViewRow gvRow in gvRegChecking.Rows)
                {
                    index = gvRow.RowIndex + 1;
                    Label lblMGA_ID = gvRow.FindControl("lblMGA_ID") as Label;
                    RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                    if (chkStat.SelectedIndex != -1)
                    {

                        clscommon.RTS_SP_INSERT_GOLD_AUDIT(Convert.ToInt32(ddlst_Branch.SelectedValue), dtd, Convert.ToInt32(lblMGA_ID.Text), chkStat.SelectedItem.Text, txtGoldInsCmts3.Text, Convert.ToInt32(Session["EMP_ID"].ToString()));
                    }
                    else
                    {
                        chkAll = false;
                        qusChk = index + "." + Convert.ToString(gvQus.Rows[index].Cells[1].Text.Trim());
                        break;
                    }
                    //qusChk = chkStat.SelectedIndex != -1 ? chkStat.SelectedItem.Text : "No";
                    //desc += index + "||" + chkStat.SelectedItem.Text + "$";
                    //desc += index + "||" + qusChk + "$";
                }

                //Branch Audit Observation
                foreach (GridViewRow gvRow in gvBrAuditObs.Rows)
                {
                    index = gvRow.RowIndex + 1;
                    Label lblMGA_ID = gvRow.FindControl("lblMGA_ID") as Label;
                    RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                    if (chkStat.SelectedIndex != -1)
                    {

                        clscommon.RTS_SP_INSERT_GOLD_AUDIT(Convert.ToInt32(ddlst_Branch.SelectedValue), dtd, Convert.ToInt32(lblMGA_ID.Text), chkStat.SelectedItem.Text, txtGoldInsCmts4.Text, Convert.ToInt32(Session["EMP_ID"].ToString()));
                    }
                    else
                    {
                        chkAll = false;
                        qusChk = index + "." + Convert.ToString(gvQus.Rows[index].Cells[1].Text.Trim());
                        break;
                    }
                    //qusChk = chkStat.SelectedIndex != -1 ? chkStat.SelectedItem.Text : "No";
                    //desc += index + "||" + chkStat.SelectedItem.Text + "$";
                    //desc += index + "||" + qusChk + "$";
                }

                //Customer KYC check at branch
                foreach (GridViewRow gvRow in gvKYCCheckBR.Rows)
                {
                    index = gvRow.RowIndex + 1;
                    Label lblMGA_ID = gvRow.FindControl("lblMGA_ID") as Label;
                    RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                    if (chkStat.SelectedIndex != -1)
                    {

                        clscommon.RTS_SP_INSERT_GOLD_AUDIT(Convert.ToInt32(ddlst_Branch.SelectedValue), dtd, Convert.ToInt32(lblMGA_ID.Text), chkStat.SelectedItem.Text, txtGoldInsCmts5.Text, Convert.ToInt32(Session["EMP_ID"].ToString()));
                    }
                    else
                    {
                        chkAll = false;
                        qusChk = index + "." + Convert.ToString(gvQus.Rows[index].Cells[1].Text.Trim());
                        break;
                    }
                    //qusChk = chkStat.SelectedIndex != -1 ? chkStat.SelectedItem.Text : "No";
                    //desc += index + "||" + chkStat.SelectedItem.Text + "$";
                    //desc += index + "||" + qusChk + "$";
                }
                uscMsgBox1.AddMessage("Gold Loan Branch Audit Observation has been done successfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                clear();

            }
            #endregion

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void bindRegisterChecking(string pdt)
    {
        SqlConnection con = new SqlConnection(strcon);
        SqlCommand cmdQus = new SqlCommand();
        try
        {
            con.Open();
            cmdQus = new SqlCommand("RTS_SP_GOLD_AUDITING", con);
            cmdQus.CommandType = CommandType.StoredProcedure;
            cmdQus.CommandTimeout = 24000000;
            cmdQus.Parameters.AddWithValue("@MGA_TYPE", pdt);
            cmdQus.Parameters.AddWithValue("@PTYPE", "GETMASTERQUS");
            DataTable dtQus = new DataTable();
            dtQus.Load(cmdQus.ExecuteReader());
            gvRegChecking.DataSource = dtQus;
            gvRegChecking.DataBind();
            string[] Ad_Option;
            string option = string.Empty;
            DataTable dtRbtn = new DataTable();
            dtRbtn.Columns.Add("QUS", typeof(string));
            int index = 0;
            if (dtQus.Rows.Count > 0)
            {
                foreach (GridViewRow grow in gvRegChecking.Rows)
                {
                    RadioButtonList chkStat = grow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                    index = grow.RowIndex;
                    Ad_Option = Convert.ToString(dtQus.Rows[index]["MGA_OPTION"]).Split('|');
                    for (int j = 0; j <= Ad_Option.Count() - 1; j++)
                    {
                        DataRow dtRow = dtRbtn.NewRow();
                        if (Convert.ToString(Ad_Option[j]) != "")
                        {
                            dtRow["QUS"] = Convert.ToString(Ad_Option[j]);
                            dtRbtn.Rows.Add(dtRow);
                        }
                    }
                    dtRbtn.AcceptChanges();
                    chkStat.DataSource = dtRbtn;
                    chkStat.DataTextField = "QUS";
                    chkStat.DataValueField = "QUS";
                    chkStat.DataBind();
                    dtRbtn.Dispose();
                    dtRbtn.Clear();
                }

            }
        }

        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void bindBRAuditObs(string pdt)
    {
        SqlConnection con = new SqlConnection(strcon);
        SqlCommand cmdQus = new SqlCommand();
        try
        {
            con.Open();
            cmdQus = new SqlCommand("RTS_SP_GOLD_AUDITING", con);
            cmdQus.CommandType = CommandType.StoredProcedure;
            cmdQus.CommandTimeout = 24000000;
            cmdQus.Parameters.AddWithValue("@MGA_TYPE", pdt);
            cmdQus.Parameters.AddWithValue("@PTYPE", "GETMASTERQUS");
            DataTable dtQus = new DataTable();
            dtQus.Load(cmdQus.ExecuteReader());
            gvBrAuditObs.DataSource = dtQus;
            gvBrAuditObs.DataBind();
            string[] Ad_Option;
            string option = string.Empty;
            DataTable dtRbtn = new DataTable();
            dtRbtn.Columns.Add("QUS", typeof(string));
            int index = 0;
            if (dtQus.Rows.Count > 0)
            {
                foreach (GridViewRow grow in gvBrAuditObs.Rows)
                {
                    RadioButtonList chkStat = grow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                    index = grow.RowIndex;
                    Ad_Option = Convert.ToString(dtQus.Rows[index]["MGA_OPTION"]).Split('|');
                    for (int j = 0; j <= Ad_Option.Count() - 1; j++)
                    {
                        DataRow dtRow = dtRbtn.NewRow();
                        if (Convert.ToString(Ad_Option[j]) != "")
                        {
                            dtRow["QUS"] = Convert.ToString(Ad_Option[j]);
                            dtRbtn.Rows.Add(dtRow);
                        }
                    }
                    dtRbtn.AcceptChanges();
                    chkStat.DataSource = dtRbtn;
                    chkStat.DataTextField = "QUS";
                    chkStat.DataValueField = "QUS";
                    chkStat.DataBind();
                    dtRbtn.Dispose();
                    dtRbtn.Clear();
                }

            }
        }

        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void clear()
    {
        try
        {
            txtNoOfPackets.Text = "";
            txtGoldInsCmts1.Text = "";
            txtGoldInsCmts2.Text = "";
            txtGoldInsCmts3.Text = "";
            txtGoldInsCmts4.Text = "";
            txtGoldInsCmts5.Text = "";
            foreach (GridViewRow gvRow in gvQus.Rows)
            {
                RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                chkStat.SelectedIndex = -1;
            }

            foreach (GridViewRow gvRow in gvRegChecking.Rows)
            {
                RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                chkStat.SelectedIndex = -1;
            }
            foreach (GridViewRow gvRow in gvBrAuditObs.Rows)
            {
                RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                chkStat.SelectedIndex = -1;
            }

            foreach (GridViewRow gvRow in gvKYCCheckBR.Rows)
            {
                RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                chkStat.SelectedIndex = -1;
            }

            // txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");

            bindArea();

        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtCollectiondate_TextChanged(object sender, EventArgs e)
    {
        int cnt = ChkCount();
        if (cnt != 0)
        {
            txtDate.Text = "";
            uscMsgBox1.AddMessage("Audit was already done for the selected date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }
    protected int ChkCount()
    {
        SqlConnection conChk = new SqlConnection(strcon);
        int count = 0;
        try
        {
            string[] AuDte = txtDate.Text.Split('/');
            Adt = AuDte[2] + "-" + AuDte[1] + "-" + AuDte[0];
            // string[] ClDte = txtCollectiondate.Text.Split('/');
            // Cdt = ClDte[2] + "-" + ClDte[1] + "-" + ClDte[0];
            string qryChk = "select COUNT(GBA_ID) from LSD_GOLD_BR_AUDIT where GBA_BR_ID = " + ddlst_Branch.SelectedValue + " and CONVERT(date,GBA_AUDIT_DATE) = CONVERT(date,'" + Adt + "')";
            using (SqlCommand cmdChk = new SqlCommand(qryChk, conChk))
            {
                conChk.Open();
                count = Convert.ToInt32(cmdChk.ExecuteScalar());
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            conChk.Close();
            SqlConnection.ClearPool(conChk);
        }
        return count;
    }
    protected void bindCusKYCCheckBR(string pdt)
    {
        SqlConnection con = new SqlConnection(strcon);
        SqlCommand cmdQus = new SqlCommand();
        try
        {
            con.Open();
            cmdQus = new SqlCommand("RTS_SP_GOLD_AUDITING", con);
            cmdQus.CommandType = CommandType.StoredProcedure;
            cmdQus.CommandTimeout = 24000000;
            cmdQus.Parameters.AddWithValue("@MGA_TYPE", pdt);
            cmdQus.Parameters.AddWithValue("@PTYPE", "GETMASTERQUS");
            DataTable dtQus = new DataTable();
            dtQus.Load(cmdQus.ExecuteReader());
            gvKYCCheckBR.DataSource = dtQus;
            gvKYCCheckBR.DataBind();
            string[] Ad_Option;
            string option = string.Empty;
            DataTable dtRbtn = new DataTable();
            dtRbtn.Columns.Add("QUS", typeof(string));
            int index = 0;
            if (dtQus.Rows.Count > 0)
            {
                foreach (GridViewRow grow in gvKYCCheckBR.Rows)
                {
                    RadioButtonList chkStat = grow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                    index = grow.RowIndex;
                    Ad_Option = Convert.ToString(dtQus.Rows[index]["MGA_OPTION"]).Split('|');
                    for (int j = 0; j <= Ad_Option.Count() - 1; j++)
                    {
                        DataRow dtRow = dtRbtn.NewRow();
                        if (Convert.ToString(Ad_Option[j]) != "")
                        {
                            dtRow["QUS"] = Convert.ToString(Ad_Option[j]);
                            dtRbtn.Rows.Add(dtRow);
                        }
                    }
                    dtRbtn.AcceptChanges();
                    chkStat.DataSource = dtRbtn;
                    chkStat.DataTextField = "QUS";
                    chkStat.DataValueField = "QUS";
                    chkStat.DataBind();
                    dtRbtn.Dispose();
                    dtRbtn.Clear();
                }

            }
        }

        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void bindQustions(string pdt)
    {
        SqlConnection con = new SqlConnection(strcon);
        SqlCommand cmdQus = new SqlCommand();
        try
        {
            con.Open();
            cmdQus = new SqlCommand("RTS_SP_GOLD_AUDITING", con);
            cmdQus.CommandType = CommandType.StoredProcedure;
            cmdQus.CommandTimeout = 24000000;
            cmdQus.Parameters.AddWithValue("@MGA_TYPE", pdt);
            cmdQus.Parameters.AddWithValue("@PTYPE", "GETMASTERQUS");
            DataTable dtQus = new DataTable();
            dtQus.Load(cmdQus.ExecuteReader());
            gvQus.DataSource = dtQus;
            gvQus.DataBind();
            string[] Ad_Option;
            string option = string.Empty;
            DataTable dtRbtn = new DataTable();
            dtRbtn.Columns.Add("QUS", typeof(string));
            int index = 0;
            if (dtQus.Rows.Count > 0)
            {
                foreach (GridViewRow grow in gvQus.Rows)
                {
                    RadioButtonList chkStat = grow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                    index = grow.RowIndex;
                    Ad_Option = Convert.ToString(dtQus.Rows[index]["MGA_OPTION"]).Split('|');
                    for (int j = 0; j <= Ad_Option.Count() - 1; j++)
                    {
                        DataRow dtRow = dtRbtn.NewRow();
                        if (Convert.ToString(Ad_Option[j]) != "")
                        {
                            dtRow["QUS"] = Convert.ToString(Ad_Option[j]);
                            dtRbtn.Rows.Add(dtRow);
                        }
                    }
                    dtRbtn.AcceptChanges();
                    chkStat.DataSource = dtRbtn;
                    chkStat.DataTextField = "QUS";
                    chkStat.DataValueField = "QUS";
                    chkStat.DataBind();
                    dtRbtn.Dispose();
                    dtRbtn.Clear();
                }

            }
        }

        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clear();
    }
}