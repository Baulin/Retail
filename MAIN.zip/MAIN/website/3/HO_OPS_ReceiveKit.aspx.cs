﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class HO_OPS_ReceiveKit : System.Web.UI.Page
{
    int ldid, s;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            bind();
        }
    }
    //public void bind()
    //{
    //    SqlConnection con = new SqlConnection(strcon);
    //    con.Open();
    //    SqlCommand cmddd = new SqlCommand("select AR_NAME from MR_AREA", con);
    //    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //    DataSet dsdd = new DataSet();
    //    dadd.Fill(dsdd);

    //    con.Close();
    //    ddlArea.DataSource = dsdd;
    //    ddlArea.DataTextField = "AR_NAME";
    //    ddlArea.DataValueField = "AR_NAME";
    //    ddlArea.DataBind();
    //    ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

    //}

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        //ddlArea.SelectedValue = Session["AREA_ID"].ToString();
        
        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Session["View"].ToString() == "F")
        {
            SqlConnection con = new SqlConnection(strcon);
            try
            {
                con.Open();
                s = 0;
                foreach (GridViewRow grow in gvRcvfile.Rows)
                {
                    CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                    int index = grow.RowIndex;
                    if (chkStat.Checked)
                    {
                        s += 1;
                        SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + gvRcvfile.Rows[index].Cells[1].Text + "'", con);

                        SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
                        DataSet dsbr = new DataSet();
                        dabr.Fill(dsbr);
                        ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);

                        SqlCommand cmdft = new SqlCommand("SELECT FT_ID FROM LSD_DISB_FILE_TRANS where FT_LD_ID='" + ldid + "' AND ISNULL(FT_RDATE,'')=''", con);
                        //SqlCommand cmdft = new SqlCommand("SELECT FT_ID FROM LSD_FILE_TRANS where FT_LD_ID='" + ldid + "' AND ISNULL(FT_RDATE,'')=''", con);
                        SqlDataAdapter daft = new SqlDataAdapter(cmdft);
                        DataSet dsft = new DataSet();
                        daft.Fill(dsft);
                        ftid = Convert.ToInt32(dsft.Tables[0].Rows[0]["FT_ID"]);
                        //ftid = Convert.ToInt32(dsft.Tables[0].Rows[0]["FT_ID"]);

                        SqlCommand cmdupdate = new SqlCommand("update LSD_DISB_FILE_TRANS set FT_RDATE=getdate(),FT_MBY='" + Session["ID"].ToString() + "',FT_MDATE=getdate() where FT_ID='" + ftid + "'", con);
                        //SqlCommand cmdupdate = new SqlCommand("update LSD_FILE_TRANS set FT_RDATE=getdate(),FT_MBY='" + Session["ID"].ToString() + "',FT_MDATE=getdate() where FT_ID='" + ftid + "'", con);
                        cmdupdate.ExecuteNonQuery();
                    }
                }
                gridbind();
                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
                ddlArea.Enabled = true;
                ddlBranch.Enabled = true;
                txtLeadno.Enabled = true;
                btnSubmit.Enabled = false;
                uscMsgBox1.AddMessage(s + " File/s Received Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            catch (Exception ex)
            {
                uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
            }
        }
        else if (Session["View"].ToString() == "A")
        {
            SqlConnection con = new SqlConnection(strcon);
            try
            {
                con.Open();
                s = 0;
                foreach (GridViewRow grow in gvRcvfile.Rows)
                {
                    CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                    int index = grow.RowIndex;
                    if (chkStat.Checked)
                    {
                        s += 1;
                        SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + gvRcvfile.Rows[index].Cells[1].Text + "'", con);
                        SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
                        DataSet dsbr = new DataSet();
                        dabr.Fill(dsbr);
                        ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);

                        SqlCommand cmdft = new SqlCommand("SELECT FT_ID FROM LSD_DISB_FILE_TRANS where FT_LD_ID='" + ldid + "' AND ISNULL(FT_RDATE,'')=''", con);
                        //SqlCommand cmdft = new SqlCommand("SELECT FT_ID FROM LSD_FILE_TRANS where FT_LD_ID='" + ldid + "' AND ISNULL(FT_RDATE,'')=''", con);
                        SqlDataAdapter daft = new SqlDataAdapter(cmdft);
                        DataSet dsft = new DataSet();
                        daft.Fill(dsft);
                        ftid = Convert.ToInt32(dsft.Tables[0].Rows[0]["FT_ID"]);
                        //ftid = Convert.ToInt32(dsft.Tables[0].Rows[0]["FT_ID"]);

                        SqlCommand cmdupdate = new SqlCommand("update LSD_DISB_FILE_TRANS set FT_RDATE=getdate(),FT_MBY='" + Session["ID"].ToString() + "',FT_MDATE=getdate() where FT_ID='" + ftid + "'", con);
                        //SqlCommand cmdupdate = new SqlCommand("update LSD_FILE_TRANS set FT_RDATE=getdate(),FT_MBY='" + Session["ID"].ToString() + "',FT_MDATE=getdate() where FT_ID='" + ftid + "'", con);
                        cmdupdate.ExecuteNonQuery();
                    }
                }
                gridbindall();
                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
                ddlArea.Enabled = true;
                ddlBranch.Enabled = true;
                txtLeadno.Enabled = true;
                btnSubmit.Enabled = false;
                uscMsgBox1.AddMessage(s + " File/s Received Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
            catch (Exception ex)
            {
                uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
            }
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HO_Ops_ReceiveKit.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "A";
            gridbindall();
        }
        else if (txtLeadno.Text != "" )//&& ddlArea.SelectedItem.Text == "--Select--" 
        {
            Session["View"] = "F";
            //ddlArea.Enabled = false;
            gridbind();
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--")//&& ddlBranch.SelectedItem.Text != "--Select--"
        {
            Session["View"] = "F";
            gridbind();
        }
        else if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select Area and Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }      
        else if (txtLeadno.Text == "")
        {
            uscMsgBox1.AddMessage("Please Enter Lead No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }
    public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = null;
            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                //cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
                cmd = new SqlCommand("select LD_NO 'LEAD NO',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_SANTD_NO,106) 'SANCTION NO',convert(varchar(17),FT_SDATE,106) 'DISPATCH DATE',LD_CRAP_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME' from LSD_LEAD A JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='B' AND FT_SENTTO='D' AND isnull(FT_RDATE,'')='' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_DISB_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') AND AR_ST_ID='" + Session["STATEID"].ToString() + "' AND ISNULL(LD_LC_DATE,'')='' ORDER BY FT_SDATE DESC ", con);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                //cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
                cmd = new SqlCommand("select LD_NO 'LEAD NO',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_SANTD_NO,106) 'SANCTION NO',convert(varchar(17),FT_SDATE,106) 'DISPATCH DATE',LD_CRAP_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME' from LSD_LEAD A JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='B' AND FT_SENTTO='D' AND isnull(FT_RDATE,'')='' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_DISB_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') AND AR_DV_ID='" + Session["DIVID"].ToString() + "' AND ISNULL(LD_LC_DATE,'')='' ORDER BY FT_SDATE DESC ", con);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                //cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
                cmd = new SqlCommand("select LD_NO 'LEAD NO',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_SANTD_NO,106) 'SANCTION NO',convert(varchar(17),FT_SDATE,106) 'DISPATCH DATE',LD_CRAP_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME' from LSD_LEAD A JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='B' AND FT_SENTTO='D' AND isnull(FT_RDATE,'')='' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_DISB_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') AND AR_ID='" + Session["AREA_ID"].ToString() + "' AND ISNULL(LD_LC_DATE,'')='' ORDER BY FT_SDATE DESC ", con);
            }
            
            else
            {
                cmd = new SqlCommand("select LD_NO 'LEAD NO',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_SANTD_NO,106) 'SANCTION NO',convert(varchar(17),FT_SDATE,106) 'DISPATCH DATE',LD_CRAP_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME' from LSD_LEAD A JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='B' AND FT_SENTTO='D' AND isnull(FT_RDATE,'')='' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_DISB_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') AND ISNULL(LD_LC_DATE,'')='' ORDER BY FT_SDATE DESC ", con);
            }
            
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvRcvfile.DataSource = ds1.Tables[0];
            gvRcvfile.DataBind();
            if (ds1.Tables[0].Rows.Count > 0)
            {
                gvRcvfile.HeaderRow.Font.Bold = true;
                gvRcvfile.HeaderRow.Cells[1].Text = "LEAD NO";
                gvRcvfile.HeaderRow.Cells[2].Text = "APPLICANT NAME";
                gvRcvfile.HeaderRow.Cells[3].Text = "SANCTION NO";
                gvRcvfile.HeaderRow.Cells[4].Text = "DISPATCH DATE";
                gvRcvfile.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvRcvfile.HeaderRow.Cells[6].Text = "BRANCH NAME";

                gvRcvfile.HeaderRow.Cells[1].Wrap = false;
                gvRcvfile.HeaderRow.Cells[2].Wrap = false;
                gvRcvfile.HeaderRow.Cells[3].Wrap = false;
                gvRcvfile.HeaderRow.Cells[4].Wrap = false;
                gvRcvfile.HeaderRow.Cells[5].Wrap = false;
                gvRcvfile.HeaderRow.Cells[6].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = null;
            if (txtLeadno.Text != "")
            {

                cmd = new SqlCommand("select LD_NO 'LEAD NO',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_SANTD_NO,106) 'SANCTION NO',convert(varchar(17),FT_SDATE,106) 'DISPATCH DATE',LD_CRAP_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME' from LSD_LEAD A JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID  JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='B' AND FT_SENTTO='D' AND isnull(FT_RDATE,'')='' AND LD_NO='" + txtLeadno.Text + "' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_DISB_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') AND ISNULL(LD_LC_DATE,'')='' ORDER BY FT_SDATE DESC ", con);
                

                
            }
            else
            {
                if (ddlBranch.SelectedItem.Text != "--Select--")
                {
                    cmd = new SqlCommand("select LD_NO 'LEAD NO',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_SANTD_NO,106) 'SANCTION NO',convert(varchar(17),FT_SDATE,106) 'DISPATCH DATE',LD_CRAP_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME' from LSD_LEAD A JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID  JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='B' AND FT_SENTTO='D' AND isnull(FT_RDATE,'')='' AND LD_NO='" + txtLeadno.Text + "' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_DISB_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') OR FT_SENTBY='B' AND FT_SENTTO='D' AND isnull(FT_RDATE,'')='' AND AR_NAME='" + ddlArea.SelectedItem.Text + "' AND BR_NAME='" + ddlBranch.SelectedItem.Text + "' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_DISB_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') AND ISNULL(LD_LC_DATE,'')='' ORDER BY FT_SDATE DESC ", con);
                }
                else
                {
                    cmd = new SqlCommand("select LD_NO 'LEAD NO',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_SANTD_NO,106) 'SANCTION NO',convert(varchar(17),FT_SDATE,106) 'DISPATCH DATE',LD_CRAP_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME' from LSD_LEAD A JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID  JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='B' AND FT_SENTTO='D' AND isnull(FT_RDATE,'')='' AND LD_NO='" + txtLeadno.Text + "' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_DISB_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') OR FT_SENTBY='B' AND FT_SENTTO='D' AND isnull(FT_RDATE,'')='' AND AR_NAME='" + ddlArea.SelectedItem.Text + "'  AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_DISB_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') AND ISNULL(LD_LC_DATE,'')='' ORDER BY FT_SDATE DESC ", con);
                }
            }
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            gvRcvfile.DataSource = ds.Tables[0];
            gvRcvfile.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvRcvfile.HeaderRow.Font.Bold = true;
                gvRcvfile.HeaderRow.Cells[1].Text = "LEAD NO";
                gvRcvfile.HeaderRow.Cells[2].Text = "APPLICANT NAME";
                gvRcvfile.HeaderRow.Cells[3].Text = "SANCTION NO";
                gvRcvfile.HeaderRow.Cells[4].Text = "DISPATCH DATE";
                gvRcvfile.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvRcvfile.HeaderRow.Cells[6].Text = "BRANCH NAME";

                gvRcvfile.HeaderRow.Cells[1].Wrap = false;
                gvRcvfile.HeaderRow.Cells[2].Wrap = false;
                gvRcvfile.HeaderRow.Cells[3].Wrap = false;
                gvRcvfile.HeaderRow.Cells[4].Wrap = false;
                gvRcvfile.HeaderRow.Cells[5].Wrap = false;
                gvRcvfile.HeaderRow.Cells[6].Wrap = false;
            }

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {

        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;



    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME ,BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
       // txtLeadno.Enabled = false;
    }
}