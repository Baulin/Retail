﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class BRANCH_RCA_TWL : System.Web.UI.Page
{
    public static DataTable dtSourceOfIncome = null;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    lasttwomonth();
                }
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }
    }

    public void lasttwomonth()
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_lAST_TWOMONTH", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlMonth.DataSource = dsdd;
        ddlMonth.DataTextField = "MonthYear";
        ddlMonth.DataValueField = "MonthYear";
        ddlMonth.DataBind();
        ddlMonth.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void bind()
    {
        DataSet dsdd = new DataSet();
        dsdd = clscommon.GetArea();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ClearText();
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        ds = GetLoanNo("BRANCH");

        ddlBranch.DataSource = ds;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();

        ddlBranch.Items.Insert(0, "--Select--");
    }

    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        ds = GetLoanNo("LOAN NUMBER");

        ddlApplicantid.DataSource = ds;
        ddlApplicantid.DataTextField = "LD_LOAN_NO";
        ddlApplicantid.DataValueField = "LOAN_NO";
        ddlApplicantid.DataBind();

        ddlArea.Items.Insert(0, "--Select--");
        ddlBranch.Items.Insert(0, "--Select--");
        ddlApplicantid.Items.Insert(0, "--Select--");
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection conIns = new SqlConnection(strcon);
        SqlCommand cmdIns = new SqlCommand();
        try
        {
            string desc = string.Empty;
            int index = 0;
            string[] loanNo = ddlApplicantid.SelectedItem.Text.Split('|');
            bool chkAll = false;
            string qusChk = string.Empty;
            foreach (GridViewRow gvRow in gvQus.Rows)
            {
                index = gvRow.RowIndex + 1;
                RadioButtonList chkStat = gvRow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                if (chkStat.SelectedIndex != -1)
                {
                    chkAll = true;
                    desc += index + "||" + chkStat.SelectedItem.Text + "$";
                }
                else
                {
                    chkAll = false;
                    qusChk = index + "." + Convert.ToString(gvQus.Rows[index].Cells[1].Text.Trim());
                    break;
                }
                //qusChk = chkStat.SelectedIndex != -1 ? chkStat.SelectedItem.Text : "No";
                //desc += index + "||" + chkStat.SelectedItem.Text + "$";
                //desc += index + "||" + qusChk + "$";
            }
            if (desc.EndsWith("$"))
                desc = desc.Remove(desc.Length - 1, 1);
            if (chkAll == true)
            {
                conIns.Open();
                cmdIns = new SqlCommand("RTS_SP_TWL_AUDITING", conIns);
                cmdIns.CommandType = CommandType.StoredProcedure;
                cmdIns.CommandTimeout = 2400000;
                cmdIns.Parameters.AddWithValue("@LAD_RMKS", txtRmrks.Text.Trim());
                cmdIns.Parameters.AddWithValue("@LAD_LD_NO", Convert.ToString(loanNo[0]));
                cmdIns.Parameters.AddWithValue("@LAD_DESC", desc);
                cmdIns.Parameters.AddWithValue("@LAD_CBY", Convert.ToString(Session["ID"]));
                cmdIns.Parameters.AddWithValue("@PTYPE", "INSERTQUSTWLRCA");
                int res = cmdIns.ExecuteNonQuery();
                if (res > 0)
                {
                    string answer = "Retail Customer Audit Done Successfully";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('" + answer + "'); window.location.href='BRANCH_RCA_TWL.aspx';", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('Retail Customer Audit Failed'); window.location.href='BRANCH_RCA_TWL.aspx';", true);
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Please select an option for " + qusChk, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=BRANCH_RCA_TWL.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            conIns.Close();
            cmdIns.Dispose();
        }
    }

    private void ClearText()
    {
        txtApplicantname.Text = "";
        txtPhonenumber.Text = "";
        //txtLoandisburseddate.Text = "";
        txtLoanamount.Text = "";
        //txtTotalloantenor.Text = "";
        txtInterestrate.Text = "";
        txtProcessingfee.Text = "";
        //txtAdminfee.Text = "";
        //txtCreditlifeins.Text = "";
        //txtPropertyins.Text = "";
        //txtTechprocessingfee.Text = "";
        txtAddress.Text = "";
        //txtInstallmentduedate.Text = "";
        //txtResAddrs.Text = "";
    }

    protected void ddlApplicantid_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string[] ApplicantID = ddlApplicantid.SelectedItem.Text.Split('|');
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(strcon);
            SqlCommand cmd = new SqlCommand();
            if (ApplicantID[0].ToString() != "--Select--")
            {
                con.Open();
                cmd = new SqlCommand("RTS_SP_TWL_AUDITING", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 2400000;
                cmd.Parameters.AddWithValue("@PTYPE", "GETDET");
                cmd.Parameters.AddWithValue("@LAD_LD_NO", Convert.ToString(ApplicantID[0]));
                dt.Load(cmd.ExecuteReader());
                if(dt.Rows.Count > 0)
                {
                    txtApplicantname.Text = Convert.ToString(dt.Rows[0]["LD_APNAME"]);
                    txtLoanamount.Text = Convert.ToString(dt.Rows[0]["LD_LOAN_AMT"]);
                    txtInterestrate.Text = Convert.ToString(dt.Rows[0]["CAM_INR"]);
                    txtAddress.Text = Convert.ToString(dt.Rows[0]["LD_ADDRESS"].ToString());
                    txtAddrproof.Text = Convert.ToString(dt.Rows[0]["ID PROOF"].ToString());
                    txtIdProof.Text = Convert.ToString(dt.Rows[0]["ADDR PROOF"].ToString());
                    txtEmiAmt.Text = Convert.ToString(dt.Rows[0]["CAM_TOT_EMI"].ToString());
                    txtVechiMake.Text = Convert.ToString(dt.Rows[0]["LVH_NAME"].ToString());
                    txtVechiModel.Text = Convert.ToString(dt.Rows[0]["LVH_MODEL"].ToString());
                    txtVechiRegno.Text = Convert.ToString(dt.Rows[0]["LTP_REG_NO"].ToString());
                    txtVechiChasno.Text = Convert.ToString(dt.Rows[0]["LTP_CHASSIS_NO"].ToString());
                    txtVechiEngno.Text = Convert.ToString(dt.Rows[0]["LTP_ENGINE_NO"].ToString());
                    txtVechiIns.Text = Convert.ToString(dt.Rows[0]["LTP_INSURER"].ToString());
                    txtInsExpiryDate.Text = Convert.ToString(dt.Rows[0]["LTP_VALID_DATE"].ToString());
                    txtPhonenumber.Text = Convert.ToString(dt.Rows[0]["AP_PH_NO"].ToString());
                    txtCoappPhno.Text = Convert.ToString(dt.Rows[0]["CO_AP_PH_NO"].ToString());
                    txtIncome.Text = Convert.ToString(dt.Rows[0]["CAM_TOT_IN"].ToString());
                    txtCusType.Text = Convert.ToString(dt.Rows[0]["CUST_TYPE"].ToString());
                    txtDwnPay.Text = Convert.ToString(dt.Rows[0]["DWN_PAY"].ToString());
                    txtProcessingfee.Text = Convert.ToString(dt.Rows[0]["PROC_FEE"].ToString());
                    txtEmiDate.Text = Convert.ToString(dt.Rows[0]["EMI_DATE"].ToString());
                    txtDealerName.Text = Convert.ToString(dt.Rows[0]["DEALER_NAME"].ToString());
                    txtProfile.Text = Convert.ToString(dt.Rows[0]["INCOME_DET"].ToString());
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["EMP_NAME"])))
                    {
                        spConn.InnerText = " - " + Convert.ToString(dt.Rows[0]["EMP_NAME"]);
                    }
                    else
                    {
                        spConn.InnerText = "";
                    }
                }
                //dt = clscommon.RTS_SP_GETLOANNOWISE_RCA(ApplicantID[0].ToString());
                //if (dt.Rows.Count != 0)
                //{
                //    txtApplicantname.Text = Convert.ToString(dt.Rows[0]["APPLICANT_NAME"].ToString());
                //    txtPhonenumber.Text = Convert.ToString(dt.Rows[0]["MOBNO"].ToString());
                //    txtLoanamount.Text = Convert.ToString(dt.Rows[0]["DISBURSEMENT_AMOUNT"]);
                //    txtInterestrate.Text = Convert.ToString(dt.Rows[0]["INTEREST_RATE"]);
                //    txtProcessingfee.Text = Convert.ToString(dt.Rows[0]["PROCESSING_FEE"]);
                //    txtAddress.Text = Convert.ToString(dt.Rows[0]["APPLICANT_ADDRESS"].ToString());
                //    txtEmiDate.Text = Convert.ToString(dt.Rows[0]["INSTALLMENT_DUE_DATE"].ToString());                
                //}
            }
            SetFocus(txtLoanamountdisbursed);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void rbEmployedorbuisness_SelectedIndexChanged(object sender, EventArgs e)
    {
        //trSmallbuisness.Visible = false;
        //trSmalltypeofbuisness.Visible = false;
        //trSmallvintageofbuisness.Visible = false;
        //trSmalldailyincomeofbuisness.Visible = false;
        //trEmployed.Visible = false;
        //trEmployedcompany.Visible = false;
        //trEmployednoofyears.Visible = false;
        //trEmployedincomesalary.Visible = false;
        //trBuisnesstypedesc.Visible = false;

        //txtVintageofbuisness.Text = "";
        //txtIncomegrosssalary.Text = "";
        //txtIncomenameofcompanyemploy.Text = "";
        //txtIncometypeofbuisness.Text = "";
        //txtNoofyearsemployment.Text = "";
        //txtAveragedailyincome.Text = "";

        //if (rbEmployedorbuisness.SelectedItem.Text != "")
        //{
        //    string Buisnesstype = rbEmployedorbuisness.SelectedItem.Text;
        //    if (Buisnesstype != "Employed")
        //    {
        //        trSmallbuisness.Visible = true;
        //        trSmalltypeofbuisness.Visible = true;
        //        trSmallvintageofbuisness.Visible = true;
        //        trSmalldailyincomeofbuisness.Visible = true;
        //        trBuisnesstypedesc.Visible = true;
        //    }
        //    else
        //    {
        //        trEmployed.Visible = true;
        //        trEmployedcompany.Visible = true;
        //        trEmployednoofyears.Visible = true;
        //        trEmployedincomesalary.Visible = true;

        //    }
        //}

    }
    protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        ds = GetLoanNo("PRODUCT");

        ddlTypeofaudit.DataSource = ds;
        ddlTypeofaudit.DataTextField = "PR_CODE";
        ddlTypeofaudit.DataValueField = "PR_ID";
        ddlTypeofaudit.DataBind();

        ddlTypeofaudit.Items.Insert(0, "--Select--");

        ClearText();

        ddlTypeofaudit.SelectedIndex = 0;
        ddlArea.SelectedIndex = 0;
        ddlBranch.SelectedIndex = 0;
        ddlApplicantid.SelectedIndex = 0;
    }

    private DataSet GetLoanNo(string product)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("SP_RTS_FETCH_RISK_AUDIT_TWL", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;

        cmdrsn.Parameters.AddWithValue("@PTYPE", product);
        cmdrsn.Parameters.AddWithValue("@DISB_MONTH", ddlMonth.SelectedItem.Text != "--Select--" ? ddlMonth.SelectedValue : "");
        cmdrsn.Parameters.AddWithValue("@PR_ID", ddlTypeofaudit.SelectedItem.Text != "--Select--" ? ddlTypeofaudit.SelectedValue : "");
        cmdrsn.Parameters.AddWithValue("@AR_ID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue : "");
        cmdrsn.Parameters.AddWithValue("@BR_ID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue : "");
        cmdrsn.Parameters.AddWithValue("@LOAN_NO", ddlApplicantid.SelectedItem.Text != "--Select--" ? ddlApplicantid.SelectedItem.Text : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        return dsrsn;
    }
    protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        ClearText();
        ddlTypeofaudit.SelectedIndex = 0;
        ddlArea.SelectedIndex = 0;
        ddlBranch.SelectedIndex = 0;
        ddlApplicantid.SelectedIndex = 0;
    }
    protected void ddlTypeofaudit_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        ds = GetLoanNo("AREA");

        ddlArea.DataSource = ds;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();

        ddlArea.Items.Insert(0, "--Select--");

        ClearText();
        ddlArea.SelectedIndex = 0;
        ddlBranch.SelectedIndex = 0;
        ddlApplicantid.SelectedIndex = 0;
        //if (ddlTypeofaudit.SelectedIndex == 2)
        //{
        //    txtCurrentstageofconstruction.Enabled = true;
        //}
        //else
        //{
        //    txtCurrentstageofconstruction.Enabled = false;
        //}
        bindQustions(ddlTypeofaudit.SelectedItem.Text == "IB-TWL" ? "T" : "");
    }
    protected void ddlEnduseofloan_SelectedIndexChanged(object sender, EventArgs e)
    {
        //txtEnduseofloan.Visible = false;
        //txtEnduseofloan.Text = "";
        //if (ddlEnduseofloan.SelectedItem.Text == "Others")
        //{
        //    txtEnduseofloan.Visible = true;
        //}
        //else
        //{
        //    txtEnduseofloan.Visible = false;
        //}

    }
    protected void rbAnyonewithoutpay_SelectedIndexChanged(object sender, EventArgs e)
    {
        //trWithoutreceipt.Visible = false;
        //txtWithoutreceipt.Text = "";
        //if (rbAnyonewithoutpay.SelectedItem.Text == "Yes")
        //{
        //    trWithoutreceipt.Visible = true;
        //}

    }

    protected void bindQustions(string pdt)
    {
        SqlConnection con = new SqlConnection(strcon);
        SqlCommand cmdQus = new SqlCommand();
        try
        {
            con.Open();
            cmdQus = new SqlCommand("RTS_SP_TWL_AUDITING", con);
            cmdQus.CommandType = CommandType.StoredProcedure;
            cmdQus.CommandTimeout = 24000000;
            cmdQus.Parameters.AddWithValue("@PD_TYPE", pdt);
            cmdQus.Parameters.AddWithValue("@PTYPE", "GETMASTERQUS");
            DataTable dtQus = new DataTable();
            dtQus.Load(cmdQus.ExecuteReader());
            gvQus.DataSource = dtQus;
            gvQus.DataBind();
            string[] Ad_Option;
            string option = string.Empty;
            DataTable dtRbtn = new DataTable();
            dtRbtn.Columns.Add("QUS", typeof(string));
            int index = 0;
            if (dtQus.Rows.Count > 0)
            {
                foreach (GridViewRow grow in gvQus.Rows)
                {
                    RadioButtonList chkStat = grow.FindControl("rbtn_TWL_Rca") as RadioButtonList;
                    index = grow.RowIndex;
                    Ad_Option = Convert.ToString(dtQus.Rows[index]["AD_OPTION"]).Split('|');
                    for (int j = 0; j <= Ad_Option.Count() - 1; j++)
                    {
                        DataRow dtRow = dtRbtn.NewRow();
                        if (Convert.ToString(Ad_Option[j]) != "")
                        {
                            dtRow["QUS"] = Convert.ToString(Ad_Option[j]);
                            dtRbtn.Rows.Add(dtRow);
                        }
                    }
                    dtRbtn.AcceptChanges();
                    chkStat.DataSource = dtRbtn;
                    chkStat.DataTextField = "QUS";
                    chkStat.DataValueField = "QUS";
                    chkStat.DataBind();
                    dtRbtn.Dispose();
                    dtRbtn.Clear();
                }

            }
        }

        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }


}