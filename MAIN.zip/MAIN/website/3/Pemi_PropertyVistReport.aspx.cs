﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Globalization;
using Tracker;

public partial class Pemi_PropertyVistReport : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    public static DataTable dtsBounce = null;
    public static int bTabIndex = 0;
    DateTime dt = DateTime.Now;
    string StrStautscob = "Y";
    string pemiwrhst = "Y";
    DataTable PEMITABLE, PEMISTAGE;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            Pemi_Property();
            Pemi_Property_Stage();
        }
        lbl_date.Text = String.Format("{0:dd-MMM-yyyy hh:mm tt}", dt);
        txt_date.Text = String.Format("{0:dd-MMM-yyyy hh:mm tt}", dt);
        lbl_noreview.Text = Session["User"].ToString().ToUpper();
        lbl_noreview1.Text = Session["User"].ToString().ToUpper();
        LB_CONTACT1.Text = Session["EMP_CONTACT"].ToString();
        LBL_CONTACT.Text = Session["EMP_CONTACT"].ToString();
        lblEMPCODE.Text = Session["EMP_CODE"].ToString();
        lblEMPCODE1.Text = Session["EMP_CODE"].ToString();
    }
    protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
    {
        MultiView1.ActiveViewIndex = Int32.Parse(e.Item.Value);
        int i = 0;
        txtLoanNo.Text = "";
        Clear();
        //Make the selected menu item reflect the correct imageurl
        for (i = 0; i <= Menu1.Items.Count - 1; i++)
        {
            if (i.ToString() == e.Item.Value)
            {
                if (i == 0)
                {
                    bTabIndex = 0;
                    Menu1.Items[i].ImageUrl = "~/Images/JPG/selectedtab1.jpg";
                }
                else
                {
                    bTabIndex = 1;
                    Menu1.Items[i].ImageUrl = "~/Images/JPG/selectedtab2.jpg";
                }
            }
            else
            {
                if (i == 0)
                {
                    Menu1.Items[i].ImageUrl = "~/Images/JPG/unselectedtab1.jpg";
                }
                else
                {
                    Menu1.Items[i].ImageUrl = "~/Images/JPG/unselectedtab2.jpg";
                }
            }
        }


    }
    public void fetchLeadDetails(SqlConnection con)
    {
        SqlCommand cmddd = new SqlCommand("select ld_no,BR_NAME,AR_NAME,LD_ID from lsd_lead LD Left Join Mr_Branch MB on MB.BR_ID = LD.LD_BR_ID  LEFT JOIN MR_AREA MA ON MA.AR_ID=MB.BR_AR_ID where LD_LOAN_NO ='" + txtLoanNo.Text + "' ", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            if (bTabIndex == 0)
            {
                TXTArea.Text = dsdd.Tables[0].Rows[0]["AR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AR_NAME"].ToString() : "";
                txtBranch.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                string strLeadNO = dsdd.Tables[0].Rows[0]["ld_no"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ld_no"].ToString() : "";
                txtProduct.Text = "MFHF - " + strLeadNO;
                string ld_id1 = dsdd.Tables[0].Rows[0]["LD_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_ID"].ToString() : "";
                Session["PVLD_ID"] = ld_id1;

            }
            else if (bTabIndex == 1)
            {
                TXTArea1.Text = dsdd.Tables[0].Rows[0]["AR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AR_NAME"].ToString() : "";
                txtBranch1.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                string strLeadNO1 = dsdd.Tables[0].Rows[0]["ld_no"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ld_no"].ToString() : "";
                txtProduct1.Text = "MFHF - " + strLeadNO1;
                string ld_id = dsdd.Tables[0].Rows[0]["LD_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_ID"].ToString() : "";
                Session["PVLD_ID"] = ld_id;
            }
        }
    }
    protected void btnGenerate_Click(object sender, EventArgs e)
    {
        Clear();
        //if (Session["ID"] != null)
        //{
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        fetchLeadDetails(con);
        SqlCommand cmddd = new SqlCommand("RTS_PRPRTY_PEMI_RPT", con);
        cmddd.Parameters.AddWithValue("@LNNO", txtLoanNo.Text);
        if (bTabIndex == 0)
        {
            cmddd.Parameters.AddWithValue("@LNSTAT", "E");
        }
        else if (bTabIndex == 1)
        {
            cmddd.Parameters.AddWithValue("@LNSTAT", "L");
        }

        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            if (bTabIndex == 0)
            {
                txtAppName.Text = dsdd.Tables[0].Rows[0]["Applicant_Name"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Applicant_Name"].ToString() : "";
                txtLoanAgrrement.Text = dsdd.Tables[0].Rows[0]["Lnno"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Lnno"].ToString() : "";
                txtCOntactNo.Text = dsdd.Tables[0].Rows[0]["Cont_no"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Cont_no"].ToString() : "";
                txtSancAmt.Text = dsdd.Tables[0].Rows[0]["Sanc_Amt"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Sanc_Amt"].ToString() : "";
                txtDOF.Text = dsdd.Tables[0].Rows[0]["First_Payment_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["First_Payment_Date"].ToString() : "";
                txtSancDate.Text = dsdd.Tables[0].Rows[0]["Sanc_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Sanc_Date"].ToString() : "";
                txtLOF.Text = dsdd.Tables[0].Rows[0]["Last_Payment_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Last_Payment_Date"].ToString() : "";
                txtNOFirstDisb.Text = dsdd.Tables[0].Rows[0]["No_OF_days_1st_disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["No_OF_days_1st_disb"].ToString() : "";
                txtNOLastDisb.Text = dsdd.Tables[0].Rows[0]["No_OF_days_last_disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["No_OF_days_last_disb"].ToString() : "";
                txtLoanAMtDisb.Text = dsdd.Tables[0].Rows[0]["Total_Disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Total_Disb"].ToString() : "";
                txtPropAddrs.Text = dsdd.Tables[0].Rows[0]["Property address"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property address"].ToString() : "";

                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property area"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property area"].ToString() : "";
                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property city"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property city"].ToString() : "";
                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property pincode"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property pincode"].ToString() : "";

                if (dsdd.Tables[1] != null && dsdd.Tables[1].Rows.Count > 0)
                {
                    int nCount = dsdd.Tables[1].Rows.Count;
                    if (nCount == 5)
                    {
                        txtDisbDate5.Text = dsdd.Tables[1].Rows[4][0] != DBNull.Value ? dsdd.Tables[1].Rows[4][0].ToString() : "";
                        txtDisbAmt5.Text = dsdd.Tables[1].Rows[4][1] != DBNull.Value ? dsdd.Tables[1].Rows[4][1].ToString() : "";

                    }
                    if (nCount >= 4)
                    {
                        txtDisbDate4.Text = dsdd.Tables[1].Rows[3][0] != DBNull.Value ? dsdd.Tables[1].Rows[3][0].ToString() : "";
                        Session["DisbDate"] = txtDisbDate4.Text;
                        txtDisbAmt4.Text = dsdd.Tables[1].Rows[3][1] != DBNull.Value ? dsdd.Tables[1].Rows[3][1].ToString() : "";

                    }
                    if (nCount >= 3)
                    {
                        txtDisbDate3.Text = dsdd.Tables[1].Rows[2][0] != DBNull.Value ? dsdd.Tables[1].Rows[2][0].ToString() : "";
                        txtDisbAmt3.Text = dsdd.Tables[1].Rows[2][1] != DBNull.Value ? dsdd.Tables[1].Rows[2][1].ToString() : "";

                    }
                    if (nCount >= 2)
                    {
                        txtDisbDate2.Text = dsdd.Tables[1].Rows[1][0] != DBNull.Value ? dsdd.Tables[1].Rows[1][0].ToString() : "";
                        txtDisbAmt2.Text = dsdd.Tables[1].Rows[1][1] != DBNull.Value ? dsdd.Tables[1].Rows[1][1].ToString() : "";

                    }
                    if (nCount >= 1)
                    {
                        txtDisbDate1.Text = dsdd.Tables[1].Rows[0][0] != DBNull.Value ? dsdd.Tables[1].Rows[0][0].ToString() : "";
                        txtDisbAmt1.Text = dsdd.Tables[1].Rows[0][1] != DBNull.Value ? dsdd.Tables[1].Rows[0][1].ToString() : "";

                    }
                }
                if (dsdd.Tables[2] != null && dsdd.Tables[2].Rows.Count > 0)
                {
                    dtsBounce = dsdd.Tables[2];
                    int nMonth = DateTime.Now.Month;
                    for (int n = 0; n <= dsdd.Tables[2].Rows.Count - 1; n++)
                    {
                        int nBMonth = dsdd.Tables[2].Rows[n][1] != DBNull.Value ? Convert.ToInt32(dsdd.Tables[2].Rows[n][1]) : 0;

                        if (nBMonth == nMonth)
                        {
                            chkBounce1.Checked = true;
                        }
                        if (nBMonth == nMonth - 1)
                        {
                            chkBounce2.Checked = true;
                        }
                        if (nBMonth == nMonth - 2)
                        {
                            chkBounce3.Checked = true;
                        }
                        if (nBMonth == nMonth - 3)
                        {
                            chkBounce4.Checked = true;
                        }
                    }
                }
            }
            else if (bTabIndex == 1)
            {
                txtAppName1.Text = dsdd.Tables[0].Rows[0]["Applicant_Name"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Applicant_Name"].ToString() : "";
                txtLoanAgrrement1.Text = dsdd.Tables[0].Rows[0]["Lnno"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Lnno"].ToString() : "";
                txtCOntactNo1.Text = dsdd.Tables[0].Rows[0]["Cont_no"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Cont_no"].ToString() : "";
                txtSancAmt1.Text = dsdd.Tables[0].Rows[0]["Sanc_Amt"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Sanc_Amt"].ToString() : "";
                txtDOF1.Text = dsdd.Tables[0].Rows[0]["First_Payment_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["First_Payment_Date"].ToString() : "";
                txtSancDate1.Text = dsdd.Tables[0].Rows[0]["Sanc_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Sanc_Date"].ToString() : "";
                txtLOF1.Text = dsdd.Tables[0].Rows[0]["Last_Payment_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Last_Payment_Date"].ToString() : "";
                txtNOFirstDisb1.Text = dsdd.Tables[0].Rows[0]["No_OF_days_1st_disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["No_OF_days_1st_disb"].ToString() : "";
                txtNOLastDisb1.Text = dsdd.Tables[0].Rows[0]["No_OF_days_last_disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["No_OF_days_last_disb"].ToString() : "";
                txtLoanAMtDisb1.Text = dsdd.Tables[0].Rows[0]["Total_Disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Total_Disb"].ToString() : "";
                txtPropAddrs1.Text = dsdd.Tables[0].Rows[0]["Property address"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property address"].ToString() : "";
                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property area"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property area"].ToString() : "";
                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property city"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property city"].ToString() : "";
                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property pincode"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property pincode"].ToString() : "";

                if (dsdd.Tables[1] != null && dsdd.Tables[1].Rows.Count > 0)
                {
                    int nCount = dsdd.Tables[1].Rows.Count;
                    if (nCount == 5)
                    {
                        txtDisbDate51.Text = dsdd.Tables[1].Rows[4][0] != DBNull.Value ? dsdd.Tables[1].Rows[4][0].ToString() : "";
                        txtDisbAmt51.Text = dsdd.Tables[1].Rows[4][1] != DBNull.Value ? dsdd.Tables[1].Rows[4][1].ToString() : "";

                    }
                    if (nCount >= 4)
                    {
                        txtDisbDate41.Text = dsdd.Tables[1].Rows[3][0] != DBNull.Value ? dsdd.Tables[1].Rows[3][0].ToString() : "";
                        txtDisbAmt41.Text = dsdd.Tables[1].Rows[3][1] != DBNull.Value ? dsdd.Tables[1].Rows[3][1].ToString() : "";

                    }
                    if (nCount >= 3)
                    {
                        txtDisbDate31.Text = dsdd.Tables[1].Rows[2][0] != DBNull.Value ? dsdd.Tables[1].Rows[2][0].ToString() : "";
                        txtDisbAmt31.Text = dsdd.Tables[1].Rows[2][1] != DBNull.Value ? dsdd.Tables[1].Rows[2][1].ToString() : "";

                    }
                    if (nCount >= 2)
                    {
                        txtDisbDate21.Text = dsdd.Tables[1].Rows[1][0] != DBNull.Value ? dsdd.Tables[1].Rows[1][0].ToString() : "";
                        txtDisbAmt21.Text = dsdd.Tables[1].Rows[1][1] != DBNull.Value ? dsdd.Tables[1].Rows[1][1].ToString() : "";

                    }
                    if (nCount >= 1)
                    {
                        txtDisbDate11.Text = dsdd.Tables[1].Rows[0][0] != DBNull.Value ? dsdd.Tables[1].Rows[0][0].ToString() : "";
                        txtDisbAmt11.Text = dsdd.Tables[1].Rows[0][1] != DBNull.Value ? dsdd.Tables[1].Rows[0][1].ToString() : "";

                    }
                }
            }


        }

        else
        {
            if (bTabIndex == 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", "alert('Please give correct Loan No for Pemi Property Visist Report');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", "alert('Please give correct Loan No for Full Property Visit Report');", true);
            }
        }

        con.Close();
        //}
        //else
        //{
        //    Response.Redirect("Expire.aspx");
        //}
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();

        img.ImageUrl = Server.MapPath("~/Images/JPG/MIFLogo.JPG");
        tdLogo.Controls.Add(img);
        System.Web.UI.WebControls.Image img1 = new System.Web.UI.WebControls.Image();
        img.ImageUrl = Server.MapPath("~/Images/JPG/MIFLogo.JPG");
        if (bTabIndex == 0)
        {


            int nMonth = DateTime.Now.Month;
            if (dtsBounce != null)
            {
                for (int n = 0; n <= dtsBounce.Rows.Count - 1; n++)
                {
                    int nBMonth = dtsBounce.Rows[n][1] != DBNull.Value ? Convert.ToInt32(dtsBounce.Rows[n][1]) : 0;

                    if (nBMonth == nMonth)
                    {
                        chkBounce1.Checked = true;


                    }

                    if (nBMonth == nMonth - 1)
                    {
                        chkBounce2.Checked = true;


                    }

                    if (nBMonth == nMonth - 2)
                    {
                        chkBounce3.Checked = true;


                    }

                    if (nBMonth == nMonth - 3)
                    {
                        chkBounce4.Checked = true;


                    }

                }

            }

        }



        Response.ContentType = "application/pdf";

        Response.AddHeader("content-disposition", "attachment;filename=PEMI_" + txtLoanNo.Text + ".pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        StringWriter sw0 = new StringWriter();
        HtmlTextWriter hw0 = new HtmlTextWriter(sw0);

        pnlHeader.RenderControl(hw0);


        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        if (bTabIndex == 0)
        {
            pnlTable.RenderControl(hw);
        }
        else
        {
            panTable2.RenderControl(hw);
        }

        StringReader sr1 = new StringReader(sw0.ToString() + "<br/>" + sw.ToString());

        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        StyleSheet styles = new iTextSharp.text.html.simpleparser.StyleSheet();
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        pdfDoc.NewPage();
        pdfDoc.HtmlStyleClass = "PdfClass";
        htmlparser.Parse(sr1);
        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Pemi_PropertyVistReport.aspx");
    }
    protected void Clear()
    {
        // PEMI 
        TXTArea.Text = "";
        txtBranch.Text = "";
        txtProduct.Text = "";
        txtAppName.Text = "";
        txtLoanAgrrement.Text = "";
        txtCOntactNo.Text = "";
        txtSancAmt.Text = "";
        txtDOF.Text = "";
        txtSancDate.Text = "";
        txtLOF.Text = "";
        txtNOFirstDisb.Text = "";
        txtNOLastDisb.Text = "";
        txtLoanAMtDisb.Text = "";

        // color to be change
        chkBounce1.Checked = false;
        chkBounce2.Checked = false;
        chkBounce3.Checked = false;
        chkBounce4.Checked = false;
        // end of color to be change

        txtDisbDate1.Text = "";
        txtDisbDate2.Text = "";
        txtDisbDate3.Text = "";
        txtDisbDate4.Text = "";
        txtDisbDate5.Text = "";
        txtDisbAmt1.Text = "";
        txtDisbAmt2.Text = "";
        txtDisbAmt3.Text = "";
        txtDisbAmt4.Text = "";
        txtDisbAmt5.Text = "";
        txtPropAddrs.Text = "";
        // FULL 
        TXTArea1.Text = "";
        txtBranch1.Text = "";
        txtProduct1.Text = "";
        txtAppName1.Text = "";
        txtLoanAgrrement1.Text = "";
        txtCOntactNo1.Text = "";
        txtSancAmt1.Text = "";
        txtDOF1.Text = "";
        txtSancDate1.Text = "";
        txtLOF1.Text = "";
        txtNOFirstDisb1.Text = "";
        txtNOLastDisb1.Text = "";
        txtLoanAMtDisb1.Text = "";

        txtDisbDate11.Text = "";
        txtDisbDate21.Text = "";
        txtDisbDate31.Text = "";
        txtDisbDate41.Text = "";
        txtDisbDate51.Text = "";
        txtDisbAmt11.Text = "";
        txtDisbAmt21.Text = "";
        txtDisbAmt31.Text = "";
        txtDisbAmt41.Text = "";
        txtDisbAmt51.Text = "";
        txtPropAddrs1.Text = "";
    }
    public void Pemi_Property_Stage()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select CS_ID,CS_DESC from MR_CON_STAGE", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            gv_Stage.DataSource = ds1.Tables[0];
            gv_Stage.DataBind();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Pemi_PropertyVistReport.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    public void Pemi_Property()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select CNR_ID,CNR_DESC from MR_CONSTRUCTION_REASON", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            gv_Property.DataSource = ds1.Tables[0];
            gv_Property.DataBind();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Pemi_PropertyVistReport.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    protected void rb_Pemi_PropertyYes_CheckedChanged(object sender, EventArgs e)
    {
        foreach (GridViewRow grow2 in gv_Property.Rows)
        {
            RadioButton RDPEMIOK = grow2.FindControl("rb_PEMIYes") as RadioButton;
            TextBox txt_comments1 = grow2.FindControl("txtComments") as TextBox;

            if (RDPEMIOK.Checked == true)
            {
                txt_comments1.Visible = true;
                txt_comments1.Attributes.Add("onBlur", "MyAddMethod('" + txt_comments1.ClientID + "');");
            }
        }
    }
    protected void rb_Pemi_PropertyNo_CheckedChanged(object sender, EventArgs e)
    {
        foreach (GridViewRow grow2 in gv_Property.Rows)
        {
            RadioButton chkAPPNotOK = grow2.FindControl("rb_PEMINo") as RadioButton;
            TextBox txt_comments = grow2.FindControl("txtComments") as TextBox;
            if (chkAPPNotOK.Checked == true)
            {
                txt_comments.Visible = true;


            }
        }
    }
    protected void rb_PemiYesObservSelectedIndexChanged(object sender, EventArgs e)
    {

        if (rd_Yes.Checked == true)
        {

            pemiwrhst = "Y";
            Session["pemiwrhst"] = pemiwrhst;
        }
    }
    protected void rb_PemiNoObservSelectedIndexChanged(object sender, EventArgs e)
    {


        if (rd_No.Checked == true)
        {
            pemiwrhst = "N";
            Session["pemiwrhst"] = pemiwrhst;
        }
    }
    protected void rb_PemiProNoObservSelectedIndexChanged(object sender, EventArgs e)
    {

        if (rd_PemiobserNo.Checked == true)
        {

            StrStautscob = "N";
            Session["StrStautscob"] = StrStautscob;
        }
    }
    protected void rb_PemiProYesObservSelectedIndexChanged(object sender, EventArgs e)
    {
        if (rd_PemiobserYes.Checked == true)
        {
            StrStautscob = "Y";
            Session["StrStautscob"] = StrStautscob;
        }
    }
    protected void btnPemi_click(object sender, EventArgs e)
    {
        int n = 1;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            if (bTabIndex == 0)
            {
                DataTable dt1 = new DataTable();
                dt1 = Pemi_property();
                con.Open();
                SqlCommand cmd = new SqlCommand("PEMI_PROPERTY_VISITRPT", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@PV_LD_ID", Session["PVLD_ID"].ToString());
                cmd.Parameters.AddWithValue("@PV_TYPE", "P");
                cmd.Parameters.AddWithValue("@PV_ROUTE_MAP", txtRouteMap.Text);
                cmd.Parameters.AddWithValue("@PV_CURR_STAGE", txt_cur_st_constru.Text);
                cmd.Parameters.AddWithValue("@PV_WORK_STATUS", pemiwrhst.ToString());
                cmd.Parameters.AddWithValue("@PV_EMI_STATUS", StrStautscob.ToString());
                cmd.Parameters.AddWithValue("@PV_CONTACTS", txtCOntactNo.Text.ToString());
                cmd.Parameters.AddWithValue("@PV_CON", dt1);
                cmd.Parameters.AddWithValue("@PV_CONVERSION_DATE", DateTime.Parse(txDateCRlCustome.Text));

                cmd.Parameters.AddWithValue("@PV_EXPCT_DISB_DATE", DateTime.Parse(TxtExpectedDisbuDate.Text));
                cmd.ExecuteNonQuery();
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Saved Successfully');window.location.reload()", true);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Pemi_PropertyVistReport.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();

        }
    }
    protected void btnPemiFULL_click(object sender, EventArgs e)
    {
        int n = 1;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            if (bTabIndex == 1)
            {
                DataTable dt2 = new DataTable();
                dt2 = Pemi_stage();
                con.Open();
                SqlCommand cmd = new SqlCommand("[PEMI_PROPERTY_VISITRPT_FULL]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@PV_LD_ID", Session["PVLD_ID"].ToString());
                cmd.Parameters.AddWithValue("@PV_TYPE", "F");
                cmd.Parameters.AddWithValue("@PV_ROUTE_MAP", txtRoute_LM.Text);
                cmd.Parameters.AddWithValue("@PV_STAGE", dt2);
                cmd.Parameters.AddWithValue("@PV_CONTACTS", txtCOntactNo1.Text.ToString());
                cmd.Parameters.AddWithValue("@PV_RMKS", txtRemarksStage.Text);
                cmd.ExecuteNonQuery();
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Saved Successfully');window.location.reload()", true);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Pemi_PropertyVistReport.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();

        }
    }
    protected DataTable Pemi_property()
    {
        PEMITABLE = new DataTable();
        PEMITABLE.Columns.Add("CNR_ID", typeof(int));
        PEMITABLE.Columns.Add("CNR_STATUS", typeof(string));
        PEMITABLE.Columns.Add("CNR_RMKS", typeof(string));
        int n = 0;
        foreach (GridViewRow grow in gv_Property.Rows)
        {
            string StrStauts = "", strComnd1 = "";
            n = n + 1;
            Label lbl_pemicnrid = grow.FindControl("pemi_id") as Label;
            RadioButton chkOK = grow.FindControl("rb_PEMIYes") as RadioButton;
            RadioButton chkNotOK = grow.FindControl("rb_PEMINo") as RadioButton;
            TextBox txtComnds1 = grow.FindControl("txtComments") as TextBox;
            strComnd1 = txtComnds1.Text;
            if (chkOK.Checked)
            {
                StrStauts = "Y";
            }
            else if (chkNotOK.Checked)
            {
                StrStauts = "N";
            }
            if (StrStauts != "")
            {
                DataRow row1 = PEMITABLE.NewRow();
                row1["CNR_ID"] = lbl_pemicnrid.Text;
                row1["CNR_STATUS"] = StrStauts;
                row1["CNR_RMKS"] = strComnd1;
                PEMITABLE.Rows.Add(row1);
            }
        }
        return PEMITABLE;
    }
    protected DataTable Pemi_stage()
    {
        PEMISTAGE = new DataTable();
        PEMISTAGE.Columns.Add("CS_ID", typeof(int));
        PEMISTAGE.Columns.Add("CS_DESC", typeof(string));
        PEMISTAGE.Columns.Add("CS_STATUS", typeof(string));
        int n = 0;
        foreach (GridViewRow grow in gv_Stage.Rows)
        {
            string StrStauts = "";
            n = n + 1;
            Label lbl_pemicnrid = grow.FindControl("pemi_id") as Label;
            Label LBL = grow.FindControl("lblPROPERTY") as Label;
            RadioButton chkOK = grow.FindControl("rd_stage") as RadioButton;

            if (chkOK.Checked)
            {
                StrStauts = "Y";
            }

            if (StrStauts != "")
            {
                DataRow row1 = PEMISTAGE.NewRow();
                row1["CS_ID"] = lbl_pemicnrid.Text;
                row1["CS_DESC"] = LBL.Text;
                row1["CS_STATUS"] = StrStauts;
                PEMISTAGE.Rows.Add(row1);
            }
        }
        return PEMISTAGE;
    }




}