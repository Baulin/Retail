﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Drawing;
using System.Globalization;
using Tracker;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

public partial class Report_Gold_Branch_Audit : System.Web.UI.Page
{
    #region Common
    SqlConnection con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_Obj = new SqlCommand();
    DataTable dt_obj = new DataTable();
    CreateLogFiles Err = new CreateLogFiles();
    ReportDocument rpt = new ReportDocument();
    #endregion
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime date;
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.bt_print);
        scriptManager.RegisterPostBackControl(this.btnPrint);
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                bindArea();
            }
        }
        else
        { Response.Redirect("~/Default.aspx"); }
    }
    protected void bt_print_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            DataSet ds = new DataSet();
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_GOLD_AUDITING", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 30000;
            cmd.Parameters.Add("@STDT", DateTime.ParseExact(txtFromDate.Text, "dd-MM-yyyy", CultureInfo.InvariantCulture));
            cmd.Parameters.Add("@ENDDT", DateTime.ParseExact(txtToDate.Text, "dd-MM-yyyy", CultureInfo.InvariantCulture));
            cmd.Parameters.Add("@PTYPE", "BIND_RPT");
            SqlDataAdapter showdata = new SqlDataAdapter(cmd);
            showdata.Fill(ds);
            con.Close();

            if (ds.Tables[0].Rows.Count > 0)
            {
                System.IO.StringWriter tw = new System.IO.StringWriter();
                GridView dgGrid = new GridView();
                dgGrid.DataSource = ds;
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=Branch Gold Audit Report FROM " + txtFromDate.Text + " TO " + txtToDate.Text + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                dgGrid.AllowPaging = false;
                dgGrid.DataBind();
                //Change the Header Row back to white color
                dgGrid.HeaderRow.Style.Add("background-color", "#FFFFFF");
                dgGrid.HeaderRow.ForeColor = Color.White;
                DataGrid dg = new DataGrid();
                dg.DataSource = ds;
                dg.DataBind();
                dgGrid.BorderColor = Color.FromArgb(211, 211, 211);
                for (int z = 0; z < dg.Items[0].Cells.Count; z++)
                {
                    //Apply style to Individual Cells
                    dgGrid.HeaderRow.Cells[z].Style.Add("background-color", "#7F7F7F");
                    dgGrid.HeaderRow.Cells[z].BorderColor = Color.FromArgb(211, 211, 211);
                    //dgGrid.HeaderRow.Cells[z].Height = 30;
                }
                for (int i = 0; i < dgGrid.Rows.Count; i++)
                {
                    GridViewRow row = dgGrid.Rows[i];

                    //Change Color back to white
                    row.BackColor = System.Drawing.Color.White;

                    //Apply text style to each Row
                    row.Attributes.Add("class", "textmode");

                    //Apply style to Individual Cells of Alternating Row
                    /* for (int s = 0; s < dg.Items[0].Cells.Count; s++)
                     {
                         if (i % 2 != 0)
                         {
                             row.Cells[s].Style.Add("background-color", "#f2f2f2");
                             row.Cells[s].BorderColor = Color.FromArgb(211, 211, 211);
                             row.Cells[s].ForeColor = Color.Black;
                             row.Cells[s].Font.Bold = true;
                             row.Cells[s].Font.Size = 10;
                         }
                         else
                         {
                             row.Cells[s].Style.Add("background-color", "#DDD9C3");
                             row.Cells[s].BorderColor = Color.FromArgb(211, 211, 211);
                             row.Cells[s].ForeColor = Color.Black;
                             row.Cells[s].Font.Bold = true;
                             row.Cells[s].Font.Size = 10;
                         }
                     }*/
                }
                dgGrid.RenderControl(hw);
                string year = DateTime.Now.AddYears(0).ToString("yyyy");
                string headerTable = @"<Table><tr><th colspan=6 align=left><font face=Calibri size=5 color=#974807>Branch Gold Audit Report FROM " + txtFromDate.Text + " TO " + txtToDate.Text + "</font></th></tr></Table>";
                Response.Write(headerTable);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                uscMsgBox1.AddMessage("No Data Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void ddlSelection_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            bindArea();
            txtDate.Text = "";
            txtFromDate.Text = "";
            txtToDate.Text = "";

            if(ddlSelection.SelectedValue=="1")
            {
                tblExcel.Visible = true;
                tblPDF.Visible = false;

            }
            else
                if (ddlSelection.SelectedValue == "2")
            {
                tblExcel.Visible = false;
                tblPDF.Visible = true;
            }
             else
             {
                    tblExcel.Visible = false;
                    tblPDF.Visible = false;
             }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnPrint_click(object sender, EventArgs e)
    {
        try
        {
            int count = 0;
            string[] dte = txtDate.Text.Trim().ToString().Split('/');
            string lcsDate = dte[2] + "-" + dte[1] + "-" + dte[0];
            string brnach = ddlst_Branch.SelectedIndex != 0 ? ddlst_Branch.SelectedValue : "0";
            using (con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
            {
                con_Obj.Open();
                string qry = " select COUNT(GBA_ID) 'Exsists' from LSD_GOLD_BR_AUDIT where GBA_BR_ID = " + brnach + " and CONVERT(date,GBA_AUDIT_DATE ) = CONVERT(date,'" + lcsDate + "') ";
                using (cmd_Obj = new SqlCommand(qry, con_Obj))
                {
                    count = Convert.ToInt16(cmd_Obj.ExecuteScalar());
                }
            }
            if (count > 0)
            {
                rpt = new ReportDocument();
                rpt.Load(Server.MapPath("Reports/Retail_Gold_Audit_Report.rpt"));
                string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);
                rpt.SetParameterValue(0, ddlst_Branch.SelectedIndex != 0 ? ddlst_Branch.SelectedValue : "0");
                rpt.SetParameterValue(1, lcsDate);
                rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Branch Gold Audit FOR " + ddlst_Branch.SelectedItem.Text.Trim() + "_"+txtDate.Text.Trim());
            }
            else
            {
                uscMsgBox1.AddMessage("No record found", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void bindArea()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();

            cmd_Obj = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
            }
            else
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", 0);
            }
            dt_obj = new DataTable();
            dt_obj.Load(cmd_Obj.ExecuteReader());
            ddlst_Area.DataSource = dt_obj;
            ddlst_Area.DataTextField = "AR_NAME";
            ddlst_Area.DataValueField = "AR_ID";
            ddlst_Area.DataBind();
            ddlst_Area.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Area.SelectedValue = Session["AREA_ID"].ToString();

            bindBranch();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }
    }

    public void bindBranch()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);

            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());



            ddlst_Branch.DataSource = dt_obj;
            ddlst_Branch.DataTextField = "BR_NAME";
            ddlst_Branch.DataValueField = "BR_ID";
            ddlst_Branch.DataBind();
            ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
            if (Session["USR_ACS"].ToString() == "7")
            {
                ddlst_Branch.SelectedValue = Session["BRANCHID"].ToString();
                ddlst_Branch.Enabled = false;
                ddlst_Area.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }

    }

    protected void ddlst_Area_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ClearValues();
            ddlst_Branch.SelectedIndex = 0;
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);
            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());
            if (dt_obj.Rows.Count > 0)
            {
                ddlst_Branch.DataSource = dt_obj;
                ddlst_Branch.DataTextField = "BR_NAME";
                ddlst_Branch.DataValueField = "BR_ID";
                ddlst_Branch.DataBind();
                ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlst_Branch.Enabled = true;
            }
            ClearValues();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }
    }

    protected void ddlst_Branch_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtDate.Text = "";
    }

    protected void ClearValues()
    {
        txtDate.Text = "";
        ddlst_Branch.SelectedIndex = 0;
    }
}