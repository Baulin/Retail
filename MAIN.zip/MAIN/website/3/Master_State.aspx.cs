﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_State : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();            
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT ST_CODE 'STATE CODE',ST_NAME 'STATE NAME' FROM MR_STATE", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvState.DataSource = ds;
        gvState.DataBind();
        if (gvState.Rows.Count > 0)
        {
            gvState.HeaderRow.Font.Bold = true;
            gvState.HeaderRow.Cells[0].Text = "STATE CODE";
            gvState.HeaderRow.Cells[1].Text = "STATE NAME";            

            gvState.HeaderRow.Cells[0].Wrap = false;
            gvState.HeaderRow.Cells[1].Wrap = false;
            
        }
    }
   
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;            
        }
    }

   
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand insertcmd = new SqlCommand("insert into MR_STATE values ('" + txtStatecode.Text + "','" + txtStatename.Text + "','" + Session["ID"].ToString() + "',getdate(),'" + Session["ID"].ToString() + "',getdate())", con);
            insertcmd.ExecuteNonQuery();
            bind();
            txtStatecode.Text = "";
            txtStatename.Text = "";            
            uscMsgBox1.AddMessage("State Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_State.aspx");
    }
}