﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Credit_ReceiveSendFile : System.Web.UI.Page
{
    int ldid,s;
    int ftid;
    //string leadno;
    //string appname;
    //string pddt;
    //string lnamt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);            
            bind();
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        
        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

        
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        if (ddlProcess.SelectedItem.Text == "--Select--")
        {
            gvRecvsend.Visible = false;
            uscMsgBox1.AddMessage("Please select Process", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
           
        }
        else if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--" && txtLeadno.Text=="")
        {
            gvRecvsend.Visible = false;
            //Session["View"] = "All";
            //    gridbindall();
            //BindSendReceiveGrid();
            uscMsgBox1.AddMessage("Please Select the Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txtLeadno.Text == "" && ddlProcess.SelectedItem.Text == "--Select--")
        {
            gvRecvsend.Visible = false;
            uscMsgBox1.AddMessage("Please Enter Lead No. and Select Process", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            gvRecvsend.Visible = true;
            Session["View"] = "F";
         //  gridbind();
            BindSendReceiveGrid();
        }
       
    }

    public void BindSendReceiveGrid()
    {
          SqlConnection con = new SqlConnection(strcon);
          try
          {
              con.Open();
              SqlCommand cmd = new SqlCommand("RTS_SP_Bind_SendReceiveFile", con);
              cmd.CommandType = CommandType.StoredProcedure;
              cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
              cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
              cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString():"");
              cmd.Parameters.AddWithValue("@BR_NAME",ddlBranch.SelectedItem.Text != "--Select--" ?  ddlBranch.SelectedItem.ToString():"");
              cmd.Parameters.AddWithValue("@Process", Session["Process"].ToString());
              if (Session["Process"].ToString() == "B")
              {
                  cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
                  cmd.Parameters.AddWithValue("@FT_SENTTO", "C");
              }
              else
              {
                  cmd.Parameters.AddWithValue("@FT_SENTBY", "C");
                  cmd.Parameters.AddWithValue("@FT_SENTTO", "");
              }
              SqlDataAdapter da = new SqlDataAdapter(cmd);
              da.Fill(ds);
              //if (ds.Tables[0].Rows.Count != 0)
              //{
              //Panel1.Visible = true;
              gvRecvsend.DataSource = ds.Tables[0];
              gvRecvsend.DataBind();
              if (ds.Tables[0].Rows.Count > 0)
              {
                  gvRecvsend.Visible = true;
                  gvRecvsend.HeaderRow.Font.Bold = true;
                gvRecvsend.HeaderRow.Cells[1].Text = "LEAD NO";
                gvRecvsend.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvRecvsend.HeaderRow.Cells[3].Text = "APPLICATION NO";
                gvRecvsend.HeaderRow.Cells[4].Text = "APPLICANT NAME";
                gvRecvsend.HeaderRow.Cells[5].Text = "PD DATE";
                gvRecvsend.HeaderRow.Cells[6].Text = "LOAN AMOUNT";
                gvRecvsend.HeaderRow.Cells[7].Text = "BRANCH NAME";

                gvRecvsend.HeaderRow.Cells[1].Wrap = false;
                gvRecvsend.HeaderRow.Cells[2].Wrap = false;
                gvRecvsend.HeaderRow.Cells[3].Wrap = false;
                gvRecvsend.HeaderRow.Cells[4].Wrap = false;
                gvRecvsend.HeaderRow.Cells[5].Wrap = false;
                gvRecvsend.HeaderRow.Cells[6].Wrap = false;
                gvRecvsend.HeaderRow.Cells[7].Wrap = false;
            }
          }
          catch (Exception ex)
          {
              uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
          finally
          {
              con.Close();
          }
    }
    public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            if (Session["Process"].ToString() == "B")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME',LD_App_No from LSD_LEAD A JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID  JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='B' AND FT_SENTTO='C' AND isnull(FT_RDATE,'')='' AND ISNULL(LD_LC_DATE,'')=''", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds1 = new DataSet();
                da.Fill(ds1);
                //if (ds.Tables[0].Rows.Count != 0)
                //{
                //Panel1.Visible = true;
                gvRecvsend.DataSource = ds1.Tables[0];
                gvRecvsend.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvRecvsend.HeaderRow.Font.Bold = true;
                    gvRecvsend.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvRecvsend.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvRecvsend.HeaderRow.Cells[3].Text = "APPLICATION NO";
                    gvRecvsend.HeaderRow.Cells[4].Text = "APPLICANT NAME";
                    gvRecvsend.HeaderRow.Cells[5].Text = "PD DATE";
                    gvRecvsend.HeaderRow.Cells[6].Text = "LOAN AMOUNT";
                    gvRecvsend.HeaderRow.Cells[7].Text = "BRANCH NAME";

                    gvRecvsend.HeaderRow.Cells[1].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[2].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[3].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[4].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[5].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[6].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[7].Wrap = false;
                }
                //}
                //else
                //{
                //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                //}
            }
            else if (Session["Process"].ToString() == "H")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME',LD_App_No from LSD_LEAD A JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='B' AND FT_SENTTO='C' AND isnull(FT_RDATE,'')<>'' AND ISNULL(LD_CRAP_DATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' AND LD_ID NOT IN (SELECT FT_LD_ID FROM LSD_FILE_TRANS WHERE FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')='')", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds1 = new DataSet();
                da.Fill(ds1);
                //if (ds.Tables[0].Rows.Count != 0)
                //{
                //Panel1.Visible = true;
                gvRecvsend.DataSource = ds1.Tables[0];
                gvRecvsend.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvRecvsend.HeaderRow.Font.Bold = true;
                    gvRecvsend.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvRecvsend.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvRecvsend.HeaderRow.Cells[3].Text = "APPLICATION NO";
                    gvRecvsend.HeaderRow.Cells[4].Text = "APPLICANT NAME";
                    gvRecvsend.HeaderRow.Cells[5].Text = "PD DATE";
                    gvRecvsend.HeaderRow.Cells[6].Text = "LOAN AMOUNT";
                    gvRecvsend.HeaderRow.Cells[7].Text = "BRANCH NAME";

                    gvRecvsend.HeaderRow.Cells[1].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[2].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[3].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[4].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[5].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[6].Wrap = false;
                    gvRecvsend.HeaderRow.Cells[7].Wrap = false;
                }
                //}
                //else
                //{
                //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                //}
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind()
    {
        
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            if (Session["Process"].ToString() == "B")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME',LD_App_No from LSD_LEAD A JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID  JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='B' AND FT_SENTTO='C' AND isnull(FT_RDATE,'')='' AND LD_NO='" + txtLeadno.Text + "' AND ISNULL(LD_LC_DATE,'')='' OR FT_SENTBY='B' AND FT_SENTTO='C' AND isnull(FT_RDATE,'')='' AND AR_NAME='" + ddlArea.SelectedValue.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedValue.ToString() + "' AND ISNULL(LD_LC_DATE,'')=''", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);                
                da.Fill(ds);
                //if (ds.Tables[0].Rows.Count != 0)
                //{
                    //Panel1.Visible = true;
                    gvRecvsend.DataSource = ds.Tables[0];
                    gvRecvsend.DataBind();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        gvRecvsend.HeaderRow.Font.Bold = true;
                        gvRecvsend.HeaderRow.Cells[1].Text = "LEAD NO";
                        gvRecvsend.HeaderRow.Cells[2].Text = "LEAD DATE";
                        gvRecvsend.HeaderRow.Cells[3].Text = "APPLICATION NO";
                        gvRecvsend.HeaderRow.Cells[4].Text = "APPLICANT NAME";
                        gvRecvsend.HeaderRow.Cells[5].Text = "PD DATE";
                        gvRecvsend.HeaderRow.Cells[6].Text = "LOAN AMOUNT";
                        gvRecvsend.HeaderRow.Cells[7].Text = "BRANCH NAME";

                        gvRecvsend.HeaderRow.Cells[1].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[2].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[3].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[4].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[5].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[6].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[7].Wrap = false;
                }
                //}
                //else
                //{
                //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                //}
            }
            else if (Session["Process"].ToString() == "H")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME',LD_App_No from LSD_LEAD A JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='B' AND FT_SENTTO='C' AND isnull(FT_RDATE,'')<>'' AND LD_NO='" + txtLeadno.Text + "' AND ISNULL(LD_CRAP_DATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' AND LD_ID NOT IN (SELECT FT_LD_ID FROM LSD_FILE_TRANS WHERE FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')='') OR FT_SENTBY='B' AND FT_SENTTO='C' AND isnull(FT_RDATE,'')<>'' AND AR_NAME='" + ddlArea.SelectedValue.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedValue.ToString() + "' AND ISNULL(LD_CRAP_DATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' AND LD_ID NOT IN (SELECT FT_LD_ID FROM LSD_FILE_TRANS WHERE FT_SENTBY='C' AND FT_SENTTO='H'AND isnull(FT_RDATE,'')='') ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                //if (ds.Tables[0].Rows.Count != 0)
                //{
                    //Panel1.Visible = true;
                    gvRecvsend.DataSource = ds.Tables[0];
                    gvRecvsend.DataBind();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        gvRecvsend.HeaderRow.Font.Bold = true;
                        gvRecvsend.HeaderRow.Cells[1].Text = "LEAD NO";
                        gvRecvsend.HeaderRow.Cells[2].Text = "LEAD DATE";
                        gvRecvsend.HeaderRow.Cells[3].Text = "APPLICATION NO";
                        gvRecvsend.HeaderRow.Cells[4].Text = "APPLICANT NAME";
                        gvRecvsend.HeaderRow.Cells[5].Text = "PD DATE";
                        gvRecvsend.HeaderRow.Cells[6].Text = "LOAN AMOUNT";
                        gvRecvsend.HeaderRow.Cells[7].Text = "BRANCH NAME";

                        gvRecvsend.HeaderRow.Cells[1].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[2].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[3].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[4].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[5].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[6].Wrap = false;
                        gvRecvsend.HeaderRow.Cells[7].Wrap = false;
                }
                //}
                //else
                //{
                //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                //}
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Right;
        }
    }

    public void InsertUpdateSendAndReceivveData()
    {
        int nCheckStatus = 0;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            s = 0;
            con.Open();
            foreach (GridViewRow grow in gvRecvsend.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    s += 1;
                    nCheckStatus = 1;
                    Label lblLeadID = (Label)gvRecvsend.Rows[index].Cells[0].FindControl("lblLeadID");
                    TextBox TXTAPPNO = (TextBox)gvRecvsend.Rows[index].Cells[0].FindControl("txtApplicationNo");

                    ldid = lblLeadID.Text != "" ? Convert.ToInt32(lblLeadID.Text) : 0;

                    SqlCommand cmdupdate = new SqlCommand("RTS_SP_CREDIT_SEND_RECEIVE_FILES", con);
                    cmdupdate.CommandType = CommandType.StoredProcedure;
                    cmdupdate.Parameters.AddWithValue("@process", Session["Process"].ToString());
                    cmdupdate.Parameters.AddWithValue("@FT_LD_ID", ldid);
                    cmdupdate.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                    cmdupdate.Parameters.AddWithValue("@TYPE", "C");
                    cmdupdate.Parameters.AddWithValue("@LD_APP_No", TXTAPPNO.Text);
                    cmdupdate.ExecuteNonQuery();
                }
            }
            if (nCheckStatus != 0)
            {
                BindSendReceiveGrid();
                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
                ddlArea.Enabled = true;
                ddlBranch.Enabled = true;
                txtLeadno.Enabled = true;
                //   btnSubmit.Enabled = false;
                if (ddlProcess.SelectedItem.ToString() == "Receive from Branch")
                {
                    uscMsgBox1.AddMessage(s + " File/s Received Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
                else if (ddlProcess.SelectedItem.ToString() == "Send to HO-Ops-QC")
                {
                    uscMsgBox1.AddMessage(s + " File/s Send Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
            }
            else
            {
                uscMsgBox1.AddMessage(s + " Please Select Atleast One Input Value to Send/Receive", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertUpdateSendAndReceivveData();
        //if (Session["View"].ToString() == "F")
        //{
        //    SqlConnection con = new SqlConnection(strcon);
        //    try
        //    {
        //        if (Session["Process"].ToString() == "B")
        //        {
        //            con.Open();
        //            s = 0;
        //            foreach (GridViewRow grow in gvRecvsend.Rows)
        //            {
        //                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
        //                int index = grow.RowIndex;
        //                if (chkStat.Checked)
        //                {
        //                    s += 1;
        //                    SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + gvRecvsend.Rows[index].Cells[1].Text + "'", con);
        //                    SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        //                    DataSet dsbr = new DataSet();
        //                    dabr.Fill(dsbr);
        //                    ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);

        //                    SqlCommand cmdft = new SqlCommand("SELECT FT_ID FROM LSD_FILE_TRANS where FT_LD_ID='" + ldid + "' AND ISNULL(FT_RDATE,'')=''", con);
        //                    SqlDataAdapter daft = new SqlDataAdapter(cmdft);
        //                    DataSet dsft = new DataSet();
        //                    daft.Fill(dsft);
        //                    ftid = Convert.ToInt32(dsft.Tables[0].Rows[0]["FT_ID"]);

        //                    SqlCommand cmdupdate = new SqlCommand("update LSD_FILE_TRANS set FT_RDATE=getdate(),FT_MBY='" + Session["ID"].ToString() + "',FT_MDATE=getdate() where FT_ID='" + ftid + "'", con);
        //                    cmdupdate.ExecuteNonQuery();
        //                }
        //            }
        //            gridbind();
        //            lbLeadno.Text = "";
        //            lbAppname.Text = "";
        //            lbPDdate.Text = "";
        //            lbLoanamt.Text = "";
        //            ddlArea.Enabled = true;
        //            ddlBranch.Enabled = true;
        //            txtLeadno.Enabled = true;
        //            btnSubmit.Enabled = false;
        //            uscMsgBox1.AddMessage(s + " File/s Received Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        //        }

        //        else if (Session["Process"].ToString() == "H")
        //        {
        //            con.Open();
        //            s = 0;
        //            foreach (GridViewRow grow in gvRecvsend.Rows)
        //            {
        //                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
        //                int index = grow.RowIndex;
        //                if (chkStat.Checked)
        //                {
        //                    s += 1;
        //                    SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + gvRecvsend.Rows[index].Cells[1].Text + "'", con);
        //                    SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        //                    DataSet dsbr = new DataSet();
        //                    dabr.Fill(dsbr);
        //                    ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);

        //                    SqlCommand cmdupdate = new SqlCommand("insert into LSD_FILE_TRANS (FT_SENTBY,FT_LD_ID,FT_SDATE,FT_SENTTO,FT_CBY,FT_CDATE,FT_MBY,FT_MDATE) values ('C','" + ldid + "',getdate(),'H','" + Session["ID"].ToString() + "',getdate(),'" + Session["ID"].ToString() + "',getdate())", con);
        //                    cmdupdate.ExecuteNonQuery();
        //                }
        //            }
        //            gridbind();
        //            lbLeadno.Text = "";
        //            lbAppname.Text = "";
        //            lbPDdate.Text = "";
        //            lbLoanamt.Text = "";
        //            ddlArea.Enabled = true;
        //            ddlBranch.Enabled = true;
        //            txtLeadno.Enabled = true;
        //            btnSubmit.Enabled = false;
        //            uscMsgBox1.AddMessage(s + " File/s Sent Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}
        //else if (Session["View"].ToString() == "A")
        //{
        //    SqlConnection con = new SqlConnection(strcon);
        //    try
        //    {
        //        if (Session["Process"].ToString() == "B")
        //        {
        //            con.Open();
        //            s = 0;
        //            foreach (GridViewRow grow in gvRecvsend.Rows)
        //            {
        //                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
        //                int index = grow.RowIndex;
        //                if (chkStat.Checked)
        //                {
        //                    s += 1;
        //                    SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + gvRecvsend.Rows[index].Cells[1].Text + "'", con);
        //                    SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        //                    DataSet dsbr = new DataSet();
        //                    dabr.Fill(dsbr);
        //                    ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);

        //                    SqlCommand cmdft = new SqlCommand("SELECT FT_ID FROM LSD_FILE_TRANS where FT_LD_ID='" + ldid + "' AND ISNULL(FT_RDATE,'')=''", con);
        //                    SqlDataAdapter daft = new SqlDataAdapter(cmdft);
        //                    DataSet dsft = new DataSet();
        //                    daft.Fill(dsft);
        //                    ftid = Convert.ToInt32(dsft.Tables[0].Rows[0]["FT_ID"]);

        //                    SqlCommand cmdupdate = new SqlCommand("update LSD_FILE_TRANS set FT_RDATE=getdate(),FT_MBY='" + Session["ID"].ToString() + "',FT_MDATE=getdate() where FT_ID='" + ftid + "'", con);
        //                    cmdupdate.ExecuteNonQuery();
        //                }
        //            }
        //            gridbindall();
        //            lbLeadno.Text = "";
        //            lbAppname.Text = "";
        //            lbPDdate.Text = "";
        //            lbLoanamt.Text = "";
        //            ddlArea.Enabled = true;
        //            ddlBranch.Enabled = true;
        //            txtLeadno.Enabled = true;
        //            btnSubmit.Enabled = false;
        //            uscMsgBox1.AddMessage(s + " File/s Received Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        //        }

        //        else if (Session["Process"].ToString() == "H")
        //        {
        //            con.Open();
        //            s = 0;
        //            foreach (GridViewRow grow in gvRecvsend.Rows)
        //            {
        //                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
        //                int index = grow.RowIndex;
        //                if (chkStat.Checked)
        //                {
        //                    s += 1;
        //                    SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + gvRecvsend.Rows[index].Cells[1].Text + "'", con);
        //                    SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        //                    DataSet dsbr = new DataSet();
        //                    dabr.Fill(dsbr);
        //                    ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);

        //                    SqlCommand cmdupdate = new SqlCommand("insert into LSD_FILE_TRANS (FT_SENTBY,FT_LD_ID,FT_SDATE,FT_SENTTO,FT_CBY,FT_CDATE,FT_MBY,FT_MDATE) values ('C','" + ldid + "',getdate(),'H','" + Session["ID"].ToString() + "',getdate(),'" + Session["ID"].ToString() + "',getdate())", con);
        //                    cmdupdate.ExecuteNonQuery();
        //                }
        //            }
        //            gridbindall();
        //            lbLeadno.Text = "";
        //            lbAppname.Text = "";
        //            lbPDdate.Text = "";
        //            lbLoanamt.Text = "";
        //            ddlArea.Enabled = true;
        //            ddlBranch.Enabled = true;
        //            txtLeadno.Enabled = true;
        //            btnSubmit.Enabled = false;
        //            uscMsgBox1.AddMessage(s + " File/s Sent Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Credit_ReceiveSendFile.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
    //    SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.ToString() + "'", con);
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Enabled = false;
        txtLeadno.Text = "";
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;

       
    }
    protected void ddlProcess_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlProcess.SelectedValue.ToString() == "Receive from Branch")
        {
            Session["Process"] = "B";
        }
        else if (ddlProcess.SelectedValue.ToString() == "Send to HO-Ops-QC")
        {
            Session["Process"] = "H";
        }
        gvRecvsend.Visible = false;
        ddlArea.Enabled = true;
        txtLeadno.Enabled = true;
        ddlArea.SelectedIndex = 0;
        ddlBranch.SelectedIndex = 0;
        txtLeadno.Text = "";
        ddlBranch.Enabled = false;
    }
}