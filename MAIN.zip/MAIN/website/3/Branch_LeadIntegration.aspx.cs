﻿using DataAccessLayer;
using DataObjects;
using Resources;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using Tracker;
using Utilities.Enums;

public partial class Branch_LeadIntegration : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    SqlConnection _sqlConn;
    SqlCommand _sqlCmd;
    SqlDataReader _sqlDtRdr;
    SqlDataAdapter _sqlDtAdptr;
    DataSet _resultSet;
    DataTable _resultTable;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session[AppConstants.ID] != null)
            {

            }
            else
            {
                Response.Redirect("Expire.aspx");
            }
        }
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
    public static UnoLeadBucketDo GetUnoLeads()
    {
        #region VARIABLES
        Int64 _UserId = 0;
        UnoLeadBucketDo unoObj = null;
        UnoLeadBucketDo resultSet = null;
        CommonDAL obj = new CommonDAL();
        #endregion

        try
        {
            if (!ValidateUserSession(HttpContext.Current, out _UserId))
            {
                resultSet = new UnoLeadBucketDo() { Status = false, ErrorSeverity = ErrorSeverity.Fatal, Message = ErrorMessages.MSG_GENERIC_SESSION_EXPIRED };
            }
            else
            {
                unoObj = new UnoLeadBucketDo()
                {
                    UserId = _UserId,
                    PageNumber = 1,
                    RecordsPerPage = 20,
                    SortBy = AppConstants.Col_UN_APPL_NAME,
                    SortDirection = SortDirection.ASC
                };

                resultSet = obj.GetUnoLeadBucket(unoObj);

                if (resultSet == null || resultSet.UnoLeadBucket == null || resultSet.UnoLeadBucket.Count == 0)
                {
                    resultSet = new UnoLeadBucketDo()
                    {
                        Status = false,
                        UserId = _UserId,
                        RecordCount = 0,
                        Message = ErrorMessages.MSG_ERR_NO_RECORDS_AVAILABLE
                    };
                }
                else
                {
                    resultSet.Status = true;
                    resultSet.UserId = _UserId;
                    resultSet.RecordCount = resultSet.UnoLeadBucket.Count;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

        return resultSet;
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
    public static UnoLeadDo PickUnoLead(UnoLeadDo UnoLeadDo)
    {
        #region VARIABLES
        Int64 _UserId = 0;
        bool _result = false;
        UnoLeadDo _resultUnoLeadDo = null;
        BaseDo baseDo = new BaseDo();
        CommonDAL obj = new CommonDAL();
        #endregion

        try
        {
            if (!ValidateUserSession(HttpContext.Current, out _UserId))
            {
                _resultUnoLeadDo = new UnoLeadDo() { Status = false, ErrorSeverity = ErrorSeverity.Fatal, Message = ErrorMessages.MSG_GENERIC_SESSION_EXPIRED };
            }
            else
            {
                UnoLeadDo.UserId = _UserId;
                obj.CheckUnoLeadAvailableForPick(UnoLeadDo, out _result);

                if (!_result)
                {
                    if (_resultUnoLeadDo == null) { _resultUnoLeadDo = new UnoLeadDo(); }
                    _resultUnoLeadDo.Status = false;
                    _resultUnoLeadDo.ErrorSeverity = ErrorSeverity.Error;
                    _resultUnoLeadDo.Message = ErrorMessages.MSG_PICK_LEAD_UNAVAILABLE;
                }

                if (_result)
                {
                    _resultUnoLeadDo = obj.PickUnoLead(UnoLeadDo, out _result);
                    if (!_result)
                    {
                        if (_resultUnoLeadDo == null) { _resultUnoLeadDo = new UnoLeadDo(); }
                        _resultUnoLeadDo.Status = false;
                        _resultUnoLeadDo.Message = ErrorMessages.MSG_PICK_LEAD_FAIL;
                    }
                    else if (_result && _resultUnoLeadDo != null)
                    {
                        _resultUnoLeadDo.Status = true;
                        _resultUnoLeadDo.Message = ErrorMessages.MSG_PICK_LEAD_SUCCESS;
                        HttpContext.Current.Session[AppConstants.UnoLead] = _resultUnoLeadDo;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            if (_resultUnoLeadDo == null) { _resultUnoLeadDo = new UnoLeadDo(); }
            _resultUnoLeadDo.Status = false;
            _resultUnoLeadDo.Message = ErrorMessages.MSG_PICK_LEAD_FAIL;

            ErrorLog.WriteError(ex);
        }

        return _resultUnoLeadDo;
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
    public static UnoLeadDo UnlockUnoLead(UnoLeadDo UnoLeadDo)
    {
        #region VARIABLES
        Int64 _UserId = 0;
        bool _chkResult = false;
        bool _unlockResult = false;
        UnoLeadDo _resultUnoLeadDo = new UnoLeadDo();
        CommonDAL obj = new CommonDAL();
        #endregion

        try
        {
            if (!ValidateUserSession(HttpContext.Current, out _UserId))
            {
                _resultUnoLeadDo = new UnoLeadDo() { Status = false, ErrorSeverity = ErrorSeverity.Fatal, Message = ErrorMessages.MSG_GENERIC_SESSION_EXPIRED };
            }
            else
            {
                UnoLeadDo.UserId = _UserId;
                obj.CheckUnoLeadLockedByUser(UnoLeadDo, out _chkResult);

                if (!_chkResult)
                {
                    _resultUnoLeadDo.Status = false;
                    _resultUnoLeadDo.ErrorSeverity = ErrorSeverity.Error;
                    _resultUnoLeadDo.Message = ErrorMessages.MSG_UNLOCK_LEAD_UNAUTHORIZED;
                }

                if (_chkResult)
                {
                    _resultUnoLeadDo = obj.UnlockUnoLead(UnoLeadDo, out _unlockResult);

                    if (!_unlockResult)
                    {
                        _resultUnoLeadDo.Status = false;
                        _resultUnoLeadDo.ErrorSeverity = ErrorSeverity.Error;
                        _resultUnoLeadDo.Message = ErrorMessages.MSG_UNLOCK_LEAD_FAIL;
                    }

                    if (_unlockResult && _resultUnoLeadDo != null)
                    {
                        _resultUnoLeadDo.Status = true;
                        _resultUnoLeadDo.Message = ErrorMessages.MSG_UNLOCK_LEAD_SUCCESS;
                        HttpContext.Current.Session[AppConstants.UnoLead] = _resultUnoLeadDo;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _resultUnoLeadDo.Status = false;
            _resultUnoLeadDo.ErrorSeverity = ErrorSeverity.Error;
            _resultUnoLeadDo.Message = ErrorMessages.MSG_UNLOCK_LEAD_FAIL;

            ErrorLog.WriteError(ex);
        }

        return _resultUnoLeadDo;
    }

    private static Boolean ValidateUserSession(HttpContext httpContext, out Int64 _UserId)
    {
        bool isValid = false;
        _UserId = 0;

        object _userId = httpContext.Session[AppConstants.ID];
        if (_userId != null)
        {
            _UserId = Convert.ToInt64(_userId);
            if (_UserId > 0) { isValid = true; }
        }

        return isValid;
    }
}