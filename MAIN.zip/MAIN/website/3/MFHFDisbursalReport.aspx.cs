﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using System.Net.Mail;
using Tracker;
using System.Text.RegularExpressions;
using Utilities.SessionKeys;
using Resources;

public partial class MFHFDisbursalReport : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string dmmby;
    int ldid;
    //int j;
    //int b;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    DateTime dt = DateTime.Now;
    string[] stringArray = new string[100];
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnPrint);
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //base.VerifyRenderingInServerForm(control);
    }
    public void FetchDMCValues()
    {
        try
        {
            propetydetails();
            DataTable dtCam = null;
            DataTable dtSource = null;
            if (Session[SessionKeys.Leadno] != null && Session[SessionKeys.Leadno].ToString() != "")
            {
                dtCam = fetchCamDetail().Tables[0];
                dtSource = fetchCamDetail().Tables[1];
                if (dtSource != null && dtSource.Rows.Count > 0)
                {
                    gvIncomeDetail.DataSource = dtSource;
                    gvIncomeDetail.DataBind();

                }
                if (dtCam != null && dtCam.Rows.Count > 0)
                {
                    FetchCreditConditions();
                    string strSancNO = dtCam.Rows[0]["LD_SANTD_NO"] != DBNull.Value ? dtCam.Rows[0]["LD_SANTD_NO"].ToString() : "";
                    tblDMC.Visible = true;
                    txtLeadNo1.Text = Session[SessionKeys.Leadno].ToString();
                    txtAreaName.Text = dtCam.Rows[0]["AR_NAME"] != DBNull.Value ? dtCam.Rows[0]["AR_NAME"].ToString() : "";
                    txtBranchName.Text = dtCam.Rows[0]["BR_NAME"] != DBNull.Value ? dtCam.Rows[0]["BR_NAME"].ToString() : "";
                    txtMemberID.Text = dtCam.Rows[0]["LD_MID"] != DBNull.Value ? dtCam.Rows[0]["LD_MID"].ToString() : "";
                    txtAreType.Text = dtCam.Rows[0]["CAM_ATYPE"] != DBNull.Value ? dtCam.Rows[0]["CAM_ATYPE"].ToString() : "";

                    if (strSancNO != "")
                    {
                        DataTable dtSanc = null;
                        dtSanc = fetchSanction(strSancNO);

                        if (dtSanc != null && dtSanc.Rows.Count > 0)
                        {
                            //


                            txtLandSqft.Text = dtCam.Rows[0]["CAM_LAREA"] != DBNull.Value ? dtCam.Rows[0]["CAM_LAREA"].ToString() : "";
                            txtGudLine.Text = dtCam.Rows[0]["CAM_GLV"] != DBNull.Value ? dtCam.Rows[0]["CAM_GLV"].ToString() : "";
                            txtMrktVal.Text = dtCam.Rows[0]["CAM_MV"] != DBNull.Value ? dtCam.Rows[0]["CAM_MV"].ToString() : "";
                            txtLanVal.Text = dtCam.Rows[0]["CAM_CLV"] != DBNull.Value ? dtCam.Rows[0]["CAM_CLV"].ToString() : "";

                            txtConstrCost.Text = dtCam.Rows[0]["CAM_CBV"] != DBNull.Value ? dtCam.Rows[0]["CAM_CBV"].ToString() : "";

                            txtConstrType.Text = dtCam.Rows[0]["CE_DESC"] != DBNull.Value ? dtCam.Rows[0]["CE_DESC"].ToString() : "";
                            txtVal.Text = dtCam.Rows[0]["CE_RATE"] != DBNull.Value ? dtCam.Rows[0]["CE_RATE"].ToString() : "";
                            txtconstArea.Text = dtCam.Rows[0]["CAM_BAREA"] != DBNull.Value ? dtCam.Rows[0]["CAM_BAREA"].ToString() : "";
                            txtConstrCost1.Text = dtCam.Rows[0]["CAM_CBV"] != DBNull.Value ? dtCam.Rows[0]["CAM_CBV"].ToString() : "";
                            //txtLCRPer.Text = dtCam.Rows[0]["CAM_LCR_PER"] != DBNull.Value ? dtCam.Rows[0]["CAM_LCR_PER"].ToString() : "";

                            txtLCRPer.Text = dtSanc.Rows[0]["LCR"] != DBNull.Value ? dtSanc.Rows[0]["LCR"].ToString() : "";
                            txtMFHFLCR.Text = dtSanc.Rows[0]["LCR"] != DBNull.Value ? dtSanc.Rows[0]["LCR"].ToString() : "";
                            txtLCRValue.Text = dtCam.Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dtCam.Rows[0]["CAM_LTV_LCR"].ToString() : "";
                            txtProposalNo.Text = strSancNO;
                            txtTotPropVal.Text = dtCam.Rows[0]["CAM_TPV"] != DBNull.Value ? dtCam.Rows[0]["CAM_TPV"].ToString() : "";
                            //dtSanc.Rows[0]["PROPOSAL NO"] != DBNull.Value ? dtSanc.Rows[0]["PROPOSAL NO"].ToString() : "";
                            txtExtendArea.Text = dtCam.Rows[0]["MD_EXTENT"] != DBNull.Value ? dtCam.Rows[0]["MD_EXTENT"].ToString() : "";


                            txtLoanAMount.Text = dtSanc.Rows[0]["LNAMT"] != DBNull.Value ? dtSanc.Rows[0]["LNAMT"].ToString() : "";
                            txtLoanAMount1.Text = dtSanc.Rows[0]["LNAMT"] != DBNull.Value ? dtSanc.Rows[0]["LNAMT"].ToString() : "";
                            txtROI.Text = dtSanc.Rows[0]["Interest Rate During Fixed Interest Period"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["Interest Rate During Fixed Interest Period"]).ToString() : "";
                            txtEMI.Text = dtSanc.Rows[0]["EMIAMOUNT"] != DBNull.Value ? dtSanc.Rows[0]["EMIAMOUNT"].ToString() : "";
                            txtTenor.Text = dtSanc.Rows[0]["CUSTTNRMNTHS"] != DBNull.Value ? dtSanc.Rows[0]["CUSTTNRMNTHS"].ToString() : "";

                            txtKLI.Text = dtSanc.Rows[0]["CSINSPREUM"] != DBNull.Value ? dtSanc.Rows[0]["CSINSPREUM"].ToString() : "";
                            txNIA.Text = dtSanc.Rows[0]["GENINSPREUM"] != DBNull.Value ? dtSanc.Rows[0]["GENINSPREUM"].ToString() : "";


                            if (txtTotPropVal.Text != "" && txtLoanAMount.Text != "")
                            {
                                double dblLTV = (Convert.ToDouble(txtLoanAMount.Text) / Convert.ToDouble(txtTotPropVal.Text)) * 100;
                                txtMFHFLTV.Text = Math.Round(dblLTV).ToString();
                            }
                            txtMFHFLTV.Text = dtSanc.Rows[0]["LTV"] != DBNull.Value ? dtSanc.Rows[0]["LTV"].ToString() : "";
                            double processFee = dtSanc.Rows[0]["PF"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["PF"]) : 0.0;
                            //double TechCharge = dtSanc.Rows[0]["TECH_PF"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["TECH_PF"]) : 0.0;
                            double LegalCharge = dtSanc.Rows[0]["LEGAL_PF"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["LEGAL_PF"]) : 0.0;
                            double AdminCharge = dtSanc.Rows[0]["ADMIN_FEE"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["ADMIN_FEE"]) : 0.0;
                            double document_Charges = dtSanc.Rows[0]["DOCUMENT_CHARGE"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["DOCUMENT_CHARGE"]) : 0.0;
                            double Cersal = dtSanc.Rows[0]["CERSAI"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["CERSAI"]) : 0.0;
                            Session["PF"] = processFee;
                            //Session["TechCharge"] = TechCharge;
                            Session["LegalCharge"] = LegalCharge;
                            Session["AdminCharge"] = AdminCharge;
                            Session["Cersal"] = Cersal;
                            double lgnfee = dtSanc.Rows[0]["LD_LGN_FEE"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["LD_LGN_FEE"]) : 0.0;
                            double actProcessFee = Convert.ToDouble(processFee) != 0 ? Convert.ToDouble(processFee) - Convert.ToDouble(lgnfee) : 0.0;
                            txtlgnfee.Text = Convert.ToString(lgnfee);
                            //double Charge = Math.Round(processFee + TechCharge + AdminCharge + Cersal + document_Charges);
                            double Charge = Math.Round(actProcessFee + LegalCharge + AdminCharge + Cersal + document_Charges);

                            txtCharge.Text = Charge.ToString();
                            if (txtConstrCost.Text != "" && txtLoanAMount.Text != "")
                            {
                                double dblCnstrCost = Convert.ToDouble(txtConstrCost.Text) - Convert.ToDouble(txtLoanAMount.Text);
                                txtMarginAmount.Text = Convert.ToDecimal(Math.Round(dblCnstrCost)).ToString("F");
                            }

                            txtCrdAprvDate.Text = dtCam.Rows[0]["LD_CRAP_DATE"] != DBNull.Value ? Convert.ToDateTime(dtCam.Rows[0]["LD_CRAP_DATE"]).ToString("dd/MM/yyyy") : "";
                            txtSanDate.Text = dtSanc.Rows[0]["DATE"] != DBNull.Value ? Convert.ToDateTime(dtSanc.Rows[0]["DATE"]).ToString("dd/MM/yyyy") : "";

                            string strLgAprv = dtCam.Rows[0]["LD_LG_APRL"] != DBNull.Value ? dtCam.Rows[0]["LD_LG_APRL"].ToString() : "";
                            if (strLgAprv == "1")
                            {
                                txtLegalStatus.Text = "Approval";

                                // txtDmApproveDate.Enabled = true;
                                // txtDmApproveDate.Text = DateTime.Now.ToString("dd/MM/yyyy");


                                //txtRemarks.Enabled = true;
                            }
                            else
                            {
                                txtLegalStatus.Text = "Un Approval";
                                // txtDmApproveDate.Enabled = false;
                                //txtDmApproveDate.Text = "";
                                //txtRemarks.Enabled = false;
                            }
                            //if (txtLandSqft.Text != txtExtendArea.Text && Session["TYPEID"].ToString() == "3")
                            //{
                            //    uscMsgBox1.AddMessage("Legal Extent Area  is not Matching with CAM Land Area..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            //}
                            //txtDmApproveDate.Text = DateTime.Now.ToString("dd/MM/yyyy");

                            //if (Session["QryType"].ToString() == "T" || Session["TYPEID"].ToString() == "3")
                            //{
                            DataSet ds = fetchDMCDetail();
                            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                            {
                                txtDate.Text = ds.Tables[0].Rows[0]["DM_DATE"] != DBNull.Value ? Convert.ToDateTime(ds.Tables[0].Rows[0]["DM_DATE"]).ToString("dd/MM/yyyy") : "";
                                txtLoanNUmber.Text = ds.Tables[0].Rows[0]["DM_LOAN_NO"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_LOAN_NO"].ToString() : "";
                                lblBuldType.Text = ds.Tables[0].Rows[0]["DM_DISP_BUILD_TYPE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_DISP_BUILD_TYPE"].ToString() : "";
                                txtDmApproveDate.Text = ds.Tables[0].Rows[0]["DM_APRL_DATE"] != DBNull.Value ? Convert.ToDateTime(ds.Tables[0].Rows[0]["DM_APRL_DATE"].ToString()).ToString("dd/MM/yyyy") : "";

                                txtPTIFSC.Text = ds.Tables[0].Rows[0]["DM_PT_IFSC"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PT_IFSC"].ToString() : "";
                                if (ds.Tables[0].Rows[0]["DM_PAYMENT_TYPE"] != DBNull.Value)
                                {
                                    if (ds.Tables[0].Rows[0]["DM_PAYMENT_TYPE"].ToString() == "2")
                                    {

                                        lblPaymentMode.Text = "NEFT";
                                        tdlblPayment.Visible = true;
                                        tdlblPayment1.Visible = true;
                                    }
                                    else
                                    {
                                        lblPaymentMode.Text = "CHEQUE";
                                    }
                                }
                                dmmby = ds.Tables[0].Rows[0]["DM_MBY"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_MBY"].ToString() : "0";
                                DataTable dt = fetchUserDets(dmmby);
                                if (dt.Rows.Count > 0)
                                {
                                    ttxName1.Text = dt.Rows[0]["EMP_NAME"] != DBNull.Value ? dt.Rows[0]["EMP_NAME"].ToString() : "";
                                    txtCode1.Text = dt.Rows[0]["EMP_CODE"] != DBNull.Value ? dt.Rows[0]["EMP_CODE"].ToString() : "";
                                    txtDate1.Text = dt.Rows[0]["DATE"] != DBNull.Value ? dt.Rows[0]["DATE"].ToString() : "";

                                }
                                else
                                {
                                    ttxName1.Text = "";
                                    txtCode1.Text = "";
                                    txtDate1.Text = "";
                                }

                                if (lblBuldType.Text != "")
                                {
                                    if (lblBuldType.Text == "GF")
                                    {
                                        ddlBuldType0.Items.Clear();

                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("--Select--", ""));
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("Basement", "50"));
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("Lintel", "65"));
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("Roof", "85"));
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("Plastering (Internal+External) & Flooring", "100"));
                                    }

                                    if (lblBuldType.Text == "GF+1")
                                    {
                                        ddlBuldType0.Items.Clear();
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("--Select--", ""));
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("Roofing Level - GF", "60"));
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("Roofing Level - FF", "80"));
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("Plastering (Internal+External) & Flooring", "100"));
                                    }

                                    if (lblBuldType.Text == "GF+2")
                                    {
                                        ddlBuldType0.Items.Clear();
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("--Select--", ""));
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("Lintel Level - GF", "60"));
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("Roofing Level - FF", "80"));
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("Roofing Level - SF", "90"));
                                        ddlBuldType0.Items.Add(new System.Web.UI.WebControls.ListItem("Plastering (Internal+External) & Flooring(GF,FF & SF)", "100"));
                                    }
                                }
                                txtSancDate.Text = ds.Tables[0].Rows[0]["DM_DISP_DATE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_DISP_DATE"].ToString() : "";
                                ddlBuldType0.SelectedValue = ds.Tables[0].Rows[0]["DM_DISP_CNSTR_STAGE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_DISP_CNSTR_STAGE"].ToString() : "";
                                lblBuldType0.Text = ddlBuldType0.SelectedItem.Text;
                                txtCOnstCostPer.Text = ds.Tables[0].Rows[0]["DM_DISP_CNSTR_PER"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_DISP_CNSTR_PER"].ToString() : "";
                                txtDeviation.Text = ds.Tables[0].Rows[0]["DM_DISP_DEVI_PER"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_DISP_DEVI_PER"].ToString() : "";
                                txtAmount.Text = ds.Tables[0].Rows[0]["DM_NET_DISB"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_NET_DISB"].ToString() : "";

                                

                                txtPrptyOwner.Text = ds.Tables[0].Rows[0]["DM_PRPTY_OWNER"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PRPTY_OWNER"].ToString() : "";
                                txtPrptyAddr.Text = ds.Tables[0].Rows[0]["DM_PRPTY_ADDR"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PRPTY_ADDR"].ToString() : "";
                                txtSurvey.Text = ds.Tables[0].Rows[0]["DM_PRPTY_SURVEY"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PRPTY_SURVEY"].ToString() : "";
                                txtPurpose.Text = ds.Tables[0].Rows[0]["DM_PURPOSE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PURPOSE"].ToString() : "";
                                txtInsurancePer.Text = ds.Tables[0].Rows[0]["DM_INSURANCE_PERSON"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_INSURANCE_PERSON"].ToString() : "";
                                txtRemarks.Text = ds.Tables[0].Rows[0]["DM_REMARKS"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_REMARKS"].ToString() : "";
                                txtDmApproveDate.Text = ds.Tables[0].Rows[0]["DM_APRL_DATE"] != DBNull.Value ? Convert.ToDateTime(ds.Tables[0].Rows[0]["DM_APRL_DATE"]).ToString("dd/MM/yyyy") : ""; ;

                                lblAppCase.Text = ds.Tables[0].Rows[0]["DM_APRL"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_APRL"].ToString() : "";
                                if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                                {
                                    int ncount = ds.Tables[1].Rows.Count;
                                    txtFavDetail1.Text = ds.Tables[1].Rows[0]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_FAVOR"].ToString() : "";


                                    string[] dmcbnk = ds.Tables[1].Rows[0]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_BANK"].ToString().Split('|') : null;
                                    string bnkNme1 = ds.Tables[1].Rows[0]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[0]["BK_NAME"].ToString() : "";
                                    if (dmcbnk != null)
                                    {
                                        bnkNme1 = bnkNme1 + " - " + dmcbnk[1].ToString();
                                    }


                                    ttxBankName1.Text = bnkNme1;
                                    txtAccno1.Text = ds.Tables[1].Rows[0]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_AC_NO"].ToString() : "";
                                    txtTotal1.Text = ds.Tables[1].Rows[0]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_AMOUNT"].ToString() : "";
                                    
                                    if (ncount >= 2)
                                    {
                                        txtFavDetail2.Text = ds.Tables[1].Rows[1]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_FAVOR"].ToString() : "";
                                        string[] dmcbnk2 = ds.Tables[1].Rows[1]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_BANK"].ToString().Split('|') : null;
                                        string bnkNme2 = ds.Tables[1].Rows[1]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[1]["BK_NAME"].ToString() : "";
                                        if (dmcbnk2 != null)
                                        {
                                            bnkNme2 = bnkNme2 + " - " + dmcbnk2[1].ToString();
                                        }
                                        ttxBankName2.Text = bnkNme2;
                                        txtAccno2.Text = ds.Tables[1].Rows[1]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_AC_NO"].ToString() : "";
                                        txtTotal2.Text = ds.Tables[1].Rows[1]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_AMOUNT"].ToString() : "";
                                    }

                                    if (ncount >= 3)
                                    {
                                        txtFavDetail3.Text = ds.Tables[1].Rows[2]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_FAVOR"].ToString() : "";
                                        string[] dmcbnk3 = ds.Tables[1].Rows[2]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_BANK"].ToString().Split('|') : null;
                                        string bnkNme3 = ds.Tables[1].Rows[2]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[2]["BK_NAME"].ToString() : "";
                                        if (dmcbnk3 != null)
                                        {
                                            bnkNme3 = bnkNme3 + " - " + dmcbnk3[1].ToString();
                                        }
                                        ttxBankName3.Text = bnkNme3;
                                        txtAccno3.Text = ds.Tables[1].Rows[2]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_AC_NO"].ToString() : "";
                                        txtTotal3.Text = ds.Tables[1].Rows[2]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_AMOUNT"].ToString() : "";
                                    }
                                }

                            }
                            //}

                        }
                        else
                        {
                            tblDMC.Visible = false;
                            uscMsgBox1.AddMessage("Invalid Sanction NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        }
                    }
                }
                else
                {
                    tblDMC.Visible = false;
                    uscMsgBox1.AddMessage("Invalid Lead NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Please Enter the Lead NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public DataSet fetchCamDetail()
    {
        DataTable dtCam = null;
        DataSet dsdd = null;

        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_PR_Fetch_CAM", con);
            cmddd.Parameters.AddWithValue("@LD_NO", Session[SessionKeys.Leadno] != null ? Session[SessionKeys.Leadno].ToString() : "");

            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);
            // dtCam = dsdd.Tables[nIndex];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dsdd;
    }
    public DataSet fetchDMCDetail()
    {
        DataTable dtCam = null;
        DataSet dsdd = null;

        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_DMC_DETAILS_Report", con);
            cmddd.Parameters.AddWithValue("@LEADID", Session["LeadID"] != null ? Session["LeadID"].ToString() : "");
            cmddd.Parameters.AddWithValue("@Stage", ddlBuildType.SelectedValue);
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);
            // dtCam = dsdd.Tables[nIndex];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dsdd;
    }
    public DataTable fetchSanction(string strSanNO)
    {
        DataTable dtSan = null;

        try
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
           //Bala changes 03052018 SqlCommand mycomm = new SqlCommand("HF_SANC_LTR", con);
            SqlCommand mycomm = new SqlCommand("RTS_SP_MITC", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@SANCPROCNO", SqlDbType.VarChar).Value = strSanNO;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            showdata.Fill(ds);
            con.Close();
            dtSan = ds.Tables[0];
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dtSan;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        clearDatas();
        if (txtbxleadno.Text == "")
        {
        }
        else
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = null;
            if (ddlSearchBY.SelectedValue == "Lead No")
            {
                cmddd = new SqlCommand("Select LD_ID,LD_NO from lsd_lead where LD_NO='" + txtbxleadno.Text + "'", con);
            }
            else
            {
                cmddd = new SqlCommand("Select LD_ID,LD_NO from lsd_lead where LD_SANTD_NO='" + txtbxleadno.Text + "'", con);
            }
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            Session[SessionKeys.Leadno] = dsdd.Tables[0].Rows[0][1];
            Session["LeadID"] = dsdd.Tables[0].Rows[0][0];
            con.Close();
            btnGenerate.Enabled = true;
            btnPrint.Enabled = true;
            FetchDMCValues();
        }
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        String _leadNo = String.Empty;

        try
        {
            if (Session[SessionKeys.Leadno] != null) { _leadNo = Convert.ToString(Session[SessionKeys.Leadno]); }

            if (!String.IsNullOrEmpty(_leadNo) && clscommon.ValidateDMCompletedByCredit(_leadNo))
            {
                System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();
                Response.ContentType = "application/pdf";
                Response.AddHeader("content-disposition", "attachment;filename=DMC_" + txtbxleadno.Text + ".pdf");
                Response.Cache.SetCacheability(HttpCacheability.NoCache);

                StringWriter sw0 = new StringWriter();
                HtmlTextWriter hw0 = new HtmlTextWriter(sw0);
                pnlHeader.RenderControl(hw0);

                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                pnlpdf0.RenderControl(hw);

                StringReader sr1 = new StringReader(sw0.ToString() + "<br/>" + sw.ToString());

                Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
                HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                PdfWriter.GetInstance(pdfDoc, Response.OutputStream);

                pdfDoc.Open();
                pdfDoc.NewPage();
                pdfDoc.HtmlStyleClass = "PdfClass";
                htmlparser.Parse(sr1);
                pdfDoc.Close();
                Response.Write(pdfDoc);
                Response.End();
            }
            else
            {
                uscMsgBox1.AddMessage(Disbursal_Memo_BusinessMessages.MSG_ERR_CREDIT_DM_PENDING, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch(Exception ex)
        {

        }
    }

    public void propetydetails()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_RPT_LGL_PROPERTY_DETAILS", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@LDNO", ddlSearchBY.SelectedValue.ToString() == "Lead No" ? txtbxleadno.Text : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        GVPropertyDetails.DataSource = dsrsn;
        GVPropertyDetails.DataBind();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    protected void txtLeadNo_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtbxleadno_TextChanged(object sender, EventArgs e)
    {
      
        if (txtbxleadno.Text != "")
        {
            ddlBuildType.Visible = true;
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_BindBuildType", con);
            cmddd.Parameters.AddWithValue("@LD_NO", ddlSearchBY.SelectedValue == "Lead No" ? txtbxleadno.Text : "");
            cmddd.Parameters.AddWithValue("@SANC_NO", ddlSearchBY.SelectedValue == "Sanction No" ? txtbxleadno.Text : "");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            btnGenerate.Enabled = true;
            btnPrint.Enabled = true;
            con.Close();
            ddlBuildType.DataSource = dsdd;
            ddlBuildType.DataTextField = "BT_STAGE";
            ddlBuildType.DataValueField = "BT_DISB";
            ddlBuildType.DataBind();
        }
     
    }
    protected void btnCancel_Click1(object sender, EventArgs e)
    {
        Response.Redirect("MFHFDisbursalReport.aspx");
    }
    public void clearDatas()
    {
        txtLeadNo1.Text = "";
        txtProposalNo.Text = "";
        txtLoanNUmber.Text = "";
        txtAreaName.Text = "";
        txtBranchName.Text = "";

        txtDate.Text = "";
        txtCustCatgry.Text = "";
        txtMemberID.Text = "";
        txtAreType.Text = "";


        txtLandSqft.Text = "";
        txtGudLine.Text = "";
        txtMrktVal.Text = "";
        txtLanVal.Text = "";


        txtConstrType.Text = "";
        txtconstArea.Text = "";
        txtVal.Text = "";
        txtConstrCost.Text = "";
        txtLCRPer.Text = "";
        txtLCRValue.Text = "";
        txtTotPropVal.Text = "";


        txtConstrCost1.Text = "";
        txtLoanAMount.Text = "";
        txtMarginAmount.Text = "";
        txtCharge.Text = "";
        txtSancDate.Text = "";
        txtCOnstCostPer.Text = "";
        txtDeviation.Text = "";
        txtAmount.Text = "";
        txtlgnfee.Text = "";


        txtTenor.Text = "";
        txtLoanAMount1.Text = "";
        txtROI.Text = "";
        txtEMI.Text = "";

        txtMFHFLTV.Text = "";
        txtMFHFLCR.Text = "";
        txtKLI.Text = "";
        txNIA.Text = "";

        txtFavDetail1.Text = "";
        ttxBankName1.Text = "";
        txtAccno1.Text = "";
        txtTotal1.Text = "";

        txtFavDetail2.Text = "";
        ttxBankName2.Text = "";
        txtAccno2.Text = "";
        txtTotal2.Text = "";

        txtFavDetail3.Text = "";
        ttxBankName3.Text = "";
        txtAccno3.Text = "";
        txtTotal3.Text = "";

        txtCrdAprvDate.Text = "";
        txtSanDate.Text = "";
        txtExtendArea.Text = "";
        txtLegalStatus.Text = "";
        txtDmApproveDate.Text = "";
        txtRemarks.Text = "";
        lblBuldType.Text = "";
        lblBuldType0.Text = "";
        lblAppCase.Text = "";
      // / ddlBuldType.SelectedIndex = 0;
       // ddlBuldType0.SelectedIndex = 0;
       // ddlAppCase.SelectedIndex = 0;
    }
    public DataTable fetchUserDets(string userid)
    {
        DataTable dtusr = null;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            DataSet ds = new DataSet();

            con.Open();
            SqlCommand mycomm = new SqlCommand("RTS_SP_GET_USER_DETAILS", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@USRID", SqlDbType.VarChar).Value = userid;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            showdata.Fill(ds);
            dtusr = ds.Tables[0];

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
        return dtusr;
    }

    private void FetchCreditConditions()
    {
        DataTable dtCam = null;

        try
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                String command = "SELECT * FROM LSD_CAM_MEMO CM JOIN LSD_LEAD LD ON CM.CM_LD_ID = LD.LD_ID WHERE CM.CM_LD_ID = " + Convert.ToInt32(Session["LeadID"].ToString()) + "AND LD.LD_PR_ID IN (3, 4, 7, 38, 39, 40, 41) ";
                using (SqlCommand cmddd = new SqlCommand(command, con))
                {
                    cmddd.CommandType = CommandType.Text;
                    cmddd.CommandTimeout = 180000;
                    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
                    DataSet dsdd = new DataSet();
                    dadd.Fill(dsdd);

                    if (dsdd != null && dsdd.Tables.Count > 0)
                    {
                        dtCam = dsdd.Tables[0];
                        string newText = "";
                        string txtVal = "";

                        if (dtCam != null && dtCam.Rows.Count > 0)
                        {
                            //Replace </br> tags with new line
                            txtVal = dtCam.Rows[0]["CM_CREDIT"] != DBNull.Value ? dtCam.Rows[0]["CM_CREDIT"].ToString() : "";

                            //Replace </br> tags with new line
                            Regex regex = new Regex(@"(<br />|<br/>|</ br>|</br>)");
                            newText = regex.Replace(txtVal, "\r\n");

                            //Replace &amp; tags with blank space
                            regex = new Regex(@"(&amp;)");
                            newText = regex.Replace(newText, "and");

                            lblCreditConditions.Text = newText;
                        }
                    }
                    con.Close();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}