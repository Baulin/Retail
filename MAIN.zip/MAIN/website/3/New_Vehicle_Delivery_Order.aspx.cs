﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;
public partial class New_Vehicle_Delivery_Order : System.Web.UI.Page
{
    #region Common
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    CreateLogFiles Err = new CreateLogFiles();
    ReportDocument rpt = new ReportDocument();
    string amt = "";
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
            scriptManager.RegisterPostBackControl(this.btnlglrptprint);
            if (Session["ID"] != null)
            {
                //if (!IsPostBack)
                //{

                //}
            }
            else
                Response.Redirect("~/Default.aspx");

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnlglrptprint_Click(object sender, EventArgs e)
    {
        SqlConnection conVechOrd = new SqlConnection(strcon);
        DataTable dtVechOrd = new DataTable();
        try
        {
            if (txtLoanNo.Text != "")
            {
                using (SqlCommand cmdVechOrd = new SqlCommand("RTS_SP_NEW_VECH_ORD_DELIVERY", conVechOrd))
                {
                    conVechOrd.Open();
                    cmdVechOrd.CommandType = CommandType.StoredProcedure;
                    cmdVechOrd.CommandTimeout = 24000000;
                    cmdVechOrd.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text.Trim());
                    dtVechOrd.Load(cmdVechOrd.ExecuteReader());
                    if (dtVechOrd.Rows.Count > 0)
                    {
                        string TMP = dtVechOrd.Rows[0]["DISB_CHQ_AMT"] == DBNull.Value ? "" : dtVechOrd.Rows[0]["DISB_CHQ_AMT"].ToString();
                        if (TMP != "")
                        {
                            string[] tp = TMP.Split('.');
                            amt = NumberToWords(Convert.ToInt32(tp[0]));
                        }
                        Print();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Please enter the valid Two wheeler Loan no.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Please enter the Loan number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            conVechOrd.Close();
            SqlConnection.ClearPool(conVechOrd);
        }
    }

    protected void btnlglrptcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("New_Vehicle_Delivery_Order.aspx");
    }

    protected void Print()
    {
        try
        {
            rpt = new ReportDocument();
            rpt.Load(Server.MapPath("Reports/New_Veh_Delivery_Order.rpt"));
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);
            rpt.SetParameterValue(0, amt);
            rpt.SetParameterValue(1, txtLoanNo.Text.Trim().ToUpper());
            rpt.SetParameterValue(2, Convert.ToString(Session["EMPNAME"]));
            rpt.SetParameterValue(3, Convert.ToString(Session["EMP_CODE"]));
            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "New_Vehicle_Delivery_Order_for_" + txtLoanNo.Text.Trim().ToUpper());
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public static string NumberToWords(int number)
    {
        if (number == 0)
            return "zero";

        if (number < 0)
            return "minus " + NumberToWords(Math.Abs(number));

        string words = "";

        if ((number / 10000000) > 0)
        {
            words += NumberToWords(number / 10000000) + " Crore ";
            number %= 10000000;
        }

        if ((number / 100000) > 0)
        {
            words += NumberToWords(number / 100000) + " Lakh ";
            number %= 100000;
        }

        if ((number / 1000) > 0)
        {
            words += NumberToWords(number / 1000) + " Thousand ";
            number %= 1000;
        }

        if ((number / 100) > 0)
        {
            words += NumberToWords(number / 100) + " Hundred ";
            number %= 100;
        }

        if (number > 0)
        {
            if (words != "")
                words += "and ";

            var unitsMap = new[] { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
            var tensMap = new[] { "Zero", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

            if (number < 20)
                words += unitsMap[number];
            else
            {
                words += tensMap[number / 10];
                if ((number % 10) > 0)
                    words += "-" + unitsMap[number % 10];
            }
        }
        return words;
    }

}