﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using Tracker;
public partial class Credit_QueryResolvereport : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime date;
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.bt_print);
    }
    protected void lnkbtnFTD_Click(object sender, EventArgs e)
    {
        pnl1.Visible = true;
        bt_print.Visible = true;
        pnl2.Visible = false;
        txt_dt.Text = "";
        ddlMonth.SelectedIndex = 0;
        ddlYear.SelectedIndex = 0;
    }
    protected void lnkbtnMTD_Click(object sender, EventArgs e)
    {
        pnl1.Visible = false;
        bt_print.Visible = true;
        pnl2.Visible = true;
        txt_dt.Text = "";
        ddlMonth.SelectedIndex = 0;
        ddlYear.SelectedIndex = 0;
    }
    protected void bt_print_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            //if (txt_dt.Text != "")
            //{
            //    string value = txt_dt.Text;

            //    System.Globalization.DateTimeFormatInfo dateInfo = new System.Globalization.DateTimeFormatInfo();
            //    dateInfo.ShortDatePattern = "dd/MM/yyyy";

            //    date = Convert.ToDateTime(value, dateInfo);
            //}
            //value = String.Format("{0:dd MMM yyyy}", date);
            //SqlCommand cmd = new SqlCommand("select ST_NAME'STATE',AR_NAME'AREA',BR_NAME'BRANCH',PR_NAME'PRODUCT',LD_NO'LEAD NO',LD_CDATE'LEAD DATE',LD_PD_AMT'LOAN AMOUNT',QRY_QUERY'QUERY RAISED',QRY_DATE'QUERY DATE' FROM LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C  ON B.BR_AR_ID=C.AR_ID JOIN MR_STATE D ON C.AR_ST_ID=D.ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID JOIN LSD_QUERY F ON A.LD_ID=F.QRY_LD_ID where QRY_RSD_BY='C' and month(QRY_DATE)='" + ddlMonth.SelectedIndex + "' and year(QRY_DATE)='" + ddlYear.SelectedValue.ToString() + "' OR QRY_RSD_BY='C' AND REPLACE(CONVERT(VARCHAR(11),QRY_DATE,106), ' ','-')='" + txt_dt.Text + "'", con);
            SqlCommand cmd = new SqlCommand("CREDIT_RESOLVE_QUERY", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@date", SqlDbType.VarChar).Value = txt_dt.Text;
            cmd.Parameters.Add("@month", SqlDbType.VarChar).Value = ddlMonth.SelectedItem.Text != "--Select--" ? ddlMonth.SelectedIndex.ToString() : "";
            cmd.Parameters.Add("@year", SqlDbType.VarChar).Value =  ddlYear.SelectedItem.Text != "--Select--" ? ddlYear.SelectedValue.ToString() : "";
            SqlDataAdapter showdata = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            showdata.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                //string filename = "SO Produtivity.xls";
                System.IO.StringWriter tw = new System.IO.StringWriter();
                //System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
                GridView dgGrid = new GridView();
                dgGrid.DataSource = ds;
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=Credit Resolve Queries.xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                dgGrid.AllowPaging = false;
                dgGrid.DataBind();
                //Change the Header Row back to white color
                dgGrid.HeaderRow.Style.Add("background-color", "#FFFFFF");
                dgGrid.HeaderRow.ForeColor = Color.White;
                DataGrid dg = new DataGrid();
                dg.DataSource = ds;
                dg.DataBind();
                dgGrid.BorderColor = Color.FromArgb(211, 211, 211);
                for (int z = 0; z < dg.Items[0].Cells.Count; z++)
                {
                    //Apply style to Individual Cells
                    dgGrid.HeaderRow.Cells[z].Style.Add("background-color", "#7F7F7F");
                    dgGrid.HeaderRow.Cells[z].BorderColor = Color.FromArgb(211, 211, 211);
                    //dgGrid.HeaderRow.Cells[z].Height = 30;
                }
                for (int i = 0; i < dgGrid.Rows.Count; i++)
                {
                    GridViewRow row = dgGrid.Rows[i];

                    //Change Color back to white
                    row.BackColor = System.Drawing.Color.White;

                    //Apply text style to each Row
                    row.Attributes.Add("class", "textmode");

                    //Apply style to Individual Cells of Alternating Row
                    //for (int s = 0; s < dg.Items[0].Cells.Count; s++)
                    //{

                    //    if (i % 2 != 0)
                    //    {
                    //        row.Cells[s].Style.Add("background-color", "#f2f2f2");
                    //        row.Cells[s].BorderColor = Color.FromArgb(211, 211, 211);
                    //        row.Cells[s].ForeColor = Color.Black;
                    //        row.Cells[s].Font.Bold = true;
                    //        row.Cells[s].Font.Size = 10;
                    //    }
                    //    else
                    //    {
                    //        row.Cells[s].Style.Add("background-color", "#DDD9C3");
                    //        row.Cells[s].BorderColor = Color.FromArgb(211, 211, 211);
                    //        row.Cells[s].ForeColor = Color.Black;
                    //        row.Cells[s].Font.Bold = true;
                    //        row.Cells[s].Font.Size = 10;
                    //    }
                    //}
                }
                dgGrid.RenderControl(hw);
                //style to format numbers to string
                //string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                //Response.Write(style);
                string year = DateTime.Now.AddYears(0).ToString("yyyy");
                string headerTable = @"<Table><tr><th colspan=3 align=left><font face=Calibri size=5 color=#974807>Credit Resolve Queries</font></th></tr></Table>";
                Response.Write(headerTable);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                uscMsgBox1.AddMessage("No Data Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }
            con.Close();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}