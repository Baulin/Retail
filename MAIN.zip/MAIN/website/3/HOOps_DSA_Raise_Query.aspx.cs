﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Tracker;

public partial class HOOps_DSA_Raise_Query : System.Web.UI.Page
{
    int ldid;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();

   protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
            }
            else
            {
                Response.Redirect("expire.aspx");
            }
        }
    }
    //public void bind()
    //{
    //    SqlConnection con = new SqlConnection(strcon);
    //    con.Open();
    //    SqlCommand cmddd = new SqlCommand("select AR_NAME from MR_AREA", con);
    //    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //    DataSet dsdd = new DataSet();
    //    dadd.Fill(dsdd);

    //    //SqlCommand cmdquery = new SqlCommand("select QY_QUERY from MR_QUERY", con);
    //    //SqlDataAdapter daquery = new SqlDataAdapter(cmdquery);
    //    //DataSet dsquery = new DataSet();
    //    //daquery.Fill(dsquery);        
    //    //con.Close();

    //    ddlArea.DataSource = dsdd;
    //    ddlArea.DataTextField = "AR_NAME";
    //    ddlArea.DataValueField = "AR_NAME";
    //    ddlArea.DataBind();
    //    ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

    //    SqlCommand cmdquery = new SqlCommand("select DISTINCT QY_QUERY from MR_QUERY ORDER BY QY_QUERY ASC", con);
    //    SqlDataAdapter daquery = new SqlDataAdapter(cmdquery);
    //    DataSet dsquery = new DataSet();
    //    daquery.Fill(dsquery);
    //    con.Close();
    //    gvUserInfo.DataSource = dsquery;
    //    gvUserInfo.DataBind();

    //    //ddlQuery.DataSource = dsquery;
    //    //ddlQuery.DataTextField = "QY_QUERY";
    //    //ddlQuery.DataValueField = "QY_QUERY";
    //    //ddlQuery.DataBind();
    //    //ddlQuery.Items.Insert(0, new ListItem("--Select--", "0"));

    //}

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        // ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

        SqlCommand cmdquery = new SqlCommand("select DISTINCT QY_QUERY from MR_QUERY where QY_PRS_ID=23 ORDER BY QY_QUERY ASC", con);
        SqlDataAdapter daquery = new SqlDataAdapter(cmdquery);
        DataSet dsquery = new DataSet();
        daquery.Fill(dsquery);
        con.Close();
        gvUserInfo.DataSource = dsquery;
        gvUserInfo.DataBind();


    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void cb_select_CheckedChanged(object sender, EventArgs e)
    {
        foreach (GridViewRow grow in gvUserInfo.Rows)
        {
            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                chkStat1.Enabled = true;

            }
            else
            {
                CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                int index1 = grow.RowIndex;
                foreach (ListItem i in chkStat1.Items)
                {
                    i.Selected = false;
                }
                chkStat1.Enabled = false;
            }
        }
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
            gvUserInfo.Visible = false;
           /* if (txtBCACODE.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "All";
                gridbindall();
            }
            else if (txtBCACODE.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                // Session["View"] = "All";
                gridbindall();
                //gridbind();
                Session["View"] = "All";
            }
            else if (txtBCACODE.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";
                // Session["View"] = "All";
                gridbindall();
                //gridbind();
                Session["View"] = "All";
            }
            else if (txtBCACODE.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                //Session["View"] = "All";
               
                //  gridbind();
                Session["View"] = "All";
            }
            else if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please select Area and Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlBranch.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (txtBCACODE.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter Lead No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }*/
            gridbindall();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            /* SqlCommand cmd = new SqlCommand("select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE isnull(LD_SANTD_DATE,'')='' AND (FT_SENTBY='C' OR FT_SENTBY='B') AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' ORDER BY LD_NO", con);
             SqlDataAdapter da = new SqlDataAdapter(cmd);
             da.Fill(ds);
           */
           /* SqlCommand cmd = new SqlCommand("RTS_SP_Bind_BCA_CreatedQuery", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@BCA_CODE", txtBCACODE.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "C");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();*/

            SqlCommand cmd = new SqlCommand("RTS_SP_DSA_APPLICATION", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PTYPE", "GET_DSA_DATA");
            cmd.Parameters.AddWithValue("@DSA_TYPE", "HO_QRY_RAISE");
            cmd.Parameters.AddWithValue("@DSA_CODE", txtDSACODE.Text);
            cmd.Parameters.AddWithValue("@AR_ID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_ID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            /*  if (ds.Tables[0].Rows.Count > 0)
              {
                  gvQuery.HeaderRow.Font.Bold = true;
                  gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                  gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                  gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                  gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                  gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                  gvQuery.HeaderRow.Cells[1].Wrap = false;
                  gvQuery.HeaderRow.Cells[2].Wrap = false;
                  gvQuery.HeaderRow.Cells[3].Wrap = false;
                  gvQuery.HeaderRow.Cells[4].Wrap = false;
                  gvQuery.HeaderRow.Cells[5].Wrap = false;
              }*/
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(" select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE ( FT_SENTBY='C' OR FT_SENTBY='B')  AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND LD_NO='" + txtDSACODE.Text + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' OR ( FT_SENTBY='C' OR FT_SENTBY='B') AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedItem.Text.ToString() + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' ORDER BY LD_NO ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            con.Open();
            var ddl = (CheckBoxList)e.Row.FindControl("ddlCity");
            string CountryId = e.Row.Cells[1].Text.ToString();
            SqlCommand cmd = new SqlCommand("select QY_QUERY,QY_SQUERY from MR_QUERY  where QY_QUERY='" + CountryId + "' ORDER BY QY_QUERY,QY_SQUERY ASC", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            ddl.DataSource = ds;
            ddl.DataTextField = "QY_SQUERY";
            ddl.DataValueField = "QY_QUERY";
            ddl.DataBind();
            //ddl.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }
    protected void gvUserInfo_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            foreach (GridViewRow grow in gvQuery.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    leadno = lnbtn.Text;
                    appname = gvQuery.Rows[index].Cells[3].Text;
                    pddt = gvQuery.Rows[index].Cells[2].Text;
                    //lnamt = gvQuery.Rows[index].Cells[5].Text;
                    bind();
                }
            }
            gvUserInfo.Visible = true;
            lbLeadno.Visible = true;
            lbAppname.Visible = true;
            lbPDdate.Visible = true;
            lbLoanamt.Visible = true;
            //ddlQuery.Enabled = true;
            //ddlSubquery.Enabled = true;
            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;


            lbLeadno.Text = leadno;
            lbAppname.Text = appname;
            lbPDdate.Text = pddt;
            lbLoanamt.Text = lnamt;
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('HOOps_QCQuery_Popup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        //if (ddlQuery.SelectedItem.Text == "--Select--" || ddlSubquery.SelectedItem.Text == "--Select--")
        //{
        //    uscMsgBox1.AddMessage("Please Enter Query And SubQuery", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        //}
        //else
        //{

    
        // if (Session["View"].ToString() == "All")
        //{
            int i1 = 0, i3 = 0;
            int count = 0;
            SqlConnection con = new SqlConnection(strcon);
            try
            {
                con.Open();
                SqlCommand cmdbr = new SqlCommand("select DSA_ID from LSD_DSA where DSA_CODE='" + lbLeadno.Text + "'", con);
                SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
                DataSet dsbr = new DataSet();
                dabr.Fill(dsbr);
                ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["DSA_ID"]);
                string a;
                foreach (GridViewRow grow in gvUserInfo.Rows)
                {
                    CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                    int index = grow.RowIndex;
                    if (chkStat.Checked)
                    {
                        //i1++;
                        a = gvUserInfo.Rows[index].Cells[1].Text.ToString();
                        chkStat.Enabled = false;
                        CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                        int index1 = grow.RowIndex;
                        foreach (ListItem i2 in chkStat1.Items)
                        {
                            if (i2.Selected)
                            {
                                i3++;
                                string b;
                                b = i2.ToString();
                                SqlCommand cmdsqry = new SqlCommand("select QRY_SQUERY from LSD_DSA_QUERY where QRY_RSD_BY='H' and QRY_DSA_ID='" + ldid + "' and QRY_SQUERY='" + b + "'", con);
                                SqlDataAdapter dasqry = new SqlDataAdapter(cmdsqry);
                                DataSet dssqry = new DataSet();
                                dasqry.Fill(dssqry);
                                 count = dssqry.Tables[0].Rows.Count;
                                if (count == 0)
                                {
                                    SqlCommand cmdinsert = new SqlCommand("insert into LSD_DSA_QUERY(QRY_DATE,QRY_DSA_ID,QRY_RSD_BY,QRY_QUERY,QRY_SQUERY,QRY_CBY,QRY_CDATE) values (getdate(),'" + ldid + "','H','" + a + "','" + b + "','" + Session["ID"].ToString() + "',getdate())", con);
                                    cmdinsert.ExecuteNonQuery();
                                }
                                else
                                {
                                    uscMsgBox1.AddMessage("Selected Query is Already Exist", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                                }
                            }
                        }
                    }
                }

                ///////// mail ///////////
                /* Bala changes 31/12/2015
                 * SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + lbLeadno.Text + "'", con);
                 SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
                 DataSet dsdet = new DataSet();
                 dadet.Fill(dsdet);

                 SqlCommand cmdmail = new SqlCommand("select QRY_SQUERY 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + lbLeadno.Text + "' AND QRY_RSD_BY='H'", con);
                 SqlDataAdapter damail = new SqlDataAdapter(cmdmail);
                 DataSet dsmail = new DataSet();
                 damail.Fill(dsmail);*/

                // to whom//////

                //SqlCommand cmdmailto = new SqlCommand("SELECT EM_BM,EM_AM,EM_HO,EM_BCC FROM MR_EMAIL where EM_BR_ID='" + Session["BRANCHID"] + "'", con);
                //SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
                //DataSet dsmailto = new DataSet();
                //damailto.Fill(dsmailto);
                //if (dsmailto.Tables[0].Rows.Count != 0)
                //{
                //    to = dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
                //    cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                //    bcc = dsmailto.Tables[0].Rows[0]["EM_HO"].ToString();
                //    bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
                //}
                //if (bcc != "" && bcc1 != "")
                //{
                //    bcc2 = bcc + ";" + bcc1;
                //}
                //else if (bcc != "")
                //{
                //    bcc2 = bcc;
                //}
                //else if (bcc1 != "")
                //{
                //    bcc2 = bcc1;
                //}
                //// To Auto mail ///////
                //System.Threading.Thread threadSendMails;

                //threadSendMails = new System.Threading.Thread(delegate()
                //{

                //    String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of HO-Ops-QC Query this should be resolved at the earliest<br/><br/>";
                //    BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                //    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td width='5%' align='center'>:</td><td><strong>" + lbLeadno.Text + "</strong></td>";
                //    BodyTxt = BodyTxt + "<td>Applicant Name</td><td width='5%' align='center'>:</td><td><strong>" + lbAppname.Text + "</strong></td></tr>";
                //    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td align='center'>:</td><td><strong>" + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + "</strong></td>";
                //    BodyTxt = BodyTxt + "<td>Loan Amount</td><td align='center'>:</td><td><strong>" + lbLoanamt.Text + "</strong></td></tr></table><br/><br/>";
                //    //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Address </td><td align='center'>:</td><td><strong>" + cusaddr + "</strong></td></tr>";
                //    //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Mobile No.</td><td align='center'>:</td><td><strong>" + mobile + "</strong></td></tr></table><br/><br/>";
                //    int b = dsmail.Tables[0].Rows.Count;
                //    if (b != 0)
                //    {
                //        BodyTxt = BodyTxt + "<table width='100%' border='1' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                //        BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span><td align='center'>Sl. No.</td>";
                //        BodyTxt = BodyTxt + "<td  align='center'>HO-Ops-QC Query Details</td>";
                //        BodyTxt = BodyTxt + "<td  align='center'>Query Date</td>";
                //        BodyTxt = BodyTxt + "<td  align='center'>Response</td>";
                //        BodyTxt = BodyTxt + "<td  align='center'>Response Date</td>";
                //        BodyTxt = BodyTxt + "<td  align='center'>Resolve Date</td></span></tr>";
                //        for (int j = 0; j <= b - 1; j++)
                //        {
                //            int sno = j + 1;
                //            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span><td align='right'> " + sno + "</td>";
                //            BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Query Raised"].ToString() + "</td>";
                //            BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Date"].ToString() + "</td>";
                //            BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response"].ToString() + "</td>";
                //            BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response Date"].ToString() + "</td>";
                //            BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Resolve Date"].ToString() + "</td></span></tr>";
                //        }
                //        BodyTxt = BodyTxt + "</table>";
                //    }
                //    BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>HO-Ops-QC Team</td></tr>";
                //    BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
                //    //sendemail("SurendharR@equitasbank.com","VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

                //    sendemail(to, "RTS Alerts", bcc2, cc, "Lead No. : " + lbLeadno.Text + " - Applicant Name : " + lbAppname.Text + " - Product: " + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + " - HO-Ops-QC Query", BodyTxt, "", true);
                //    //sendemail("SurendharR@equitasbank.com;PrabhakaranA@equitasbank.com;Tamilalagand@equitasbank.com", "surendharr@equitasbank.com", "Test", BodyTxt, "", true);

                //});

                //threadSendMails.IsBackground = true;

                //threadSendMails.Start();

                gridbindall();
                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
                gvUserInfo.Visible = false;
                btnSubmit.Enabled = false;

                uscMsgBox1.AddMessage("Query Raised Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }

            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            finally
            {
                con.Close();
            }
       // }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HOOps_DSA_Raise_Query.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {


            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

            ddlBranch.DataSource = dsrsn;
            ddlBranch.DataTextField = "BR_NAME";
            ddlBranch.DataValueField = "BR_ID";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlBranch.Enabled = true;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void ddlQuery_SelectedIndexChanged(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(strcon);
        //con.Open();
        //ddlSubquery.Enabled = true;
        //SqlCommand cmdsquery = new SqlCommand("select QY_SQUERY from MR_QUERY where QY_QUERY='" + ddlQuery.SelectedValue.ToString() + "'", con);
        //SqlDataAdapter dasquery = new SqlDataAdapter(cmdsquery);
        //DataSet dssquery = new DataSet();
        //dasquery.Fill(dssquery);
        //con.Close();

        //ddlSubquery.DataSource = dssquery;
        //ddlSubquery.DataTextField = "QY_SQUERY";
        //ddlSubquery.DataValueField = "QY_SQUERY";
        //ddlSubquery.DataBind();
        //ddlSubquery.Items.Insert(0, new ListItem("--Select--", "0"));

    }
}