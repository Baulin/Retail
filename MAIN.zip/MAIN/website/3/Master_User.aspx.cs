﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using System.Text;
using Utilities;
using Tracker;

public partial class Master_User : System.Web.UI.Page
{
    int usrid;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    public static bool blMailStatus = false;
    public static string frmID = "", toID = "", bccID = "", ccID = "", strMailBody = "";
    public string EMPNAME, CODE, PWD, MAILID;
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();

    Thread mail;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {

                txtEndDate.Attributes.Add("readonly", "readonly"); 
                bind();
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmddd = new SqlCommand("select UTP_ID,UTP_DESC from MR_USER_TYPE", con);
                SqlDataAdapter da1 = new SqlDataAdapter(cmddd);
                DataSet ds1 = new DataSet();
                da1.Fill(ds1);
                ddlUsertype.DataSource = ds1;
                ddlUsertype.DataTextField = "UTP_DESC";
                ddlUsertype.DataValueField = "UTP_ID";
                ddlUsertype.DataBind();
                ddlUsertype.Items.Insert(0, new ListItem("--Select--", "0"));

                bindUserAcs();
            }
            Status_Access();
        }
        else
        {
            Response.Redirect("Expire.aspx",false);
        }
    }
    public void Status_Access()
    {
        try
        {
            if (Convert.ToString(Session["TYPEID"]) == "38")
            {
                ddlStatus.Enabled = true;
            }
            else
            {
                ddlStatus.Enabled = false;
            }
        }
        catch (Exception ex)
        {

            ErrorLog.WriteError(ex);

        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
       // SqlCommand cmd = new SqlCommand("SELECT EMP_CODE 'USER CODE',EMP_NAME 'USER NAME',MUT.UTP_DESC 'USER TYPE',CASE WHEN USR_STAT=1 THEN 'ACTIVE' WHEN USR_STAT=0 THEN 'INACTIVE' END 'STATUS',A.USR_ID,A.USR_PEXP,A.USR_PWD,MUT.UTP_ID , A.USR_UAL_ID , A.USR_EMP_ID , A.USR_TYPE [MODULE] FROM MR_USER A JOIN MR_EMPLOYEE B ON A.USR_EMP_ID=B.EMP_ID LEFT JOIN MR_USER_TYPE MUT ON A.USR_UTP_ID = MUT.UTP_ID", con);
        SqlCommand cmd = new SqlCommand("RTS_SP_MR_USER_DETAILS", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvUser.DataSource = ds;
        gvUser.DataBind();
        if (gvUser.Rows.Count > 0)
        {
            gvUser.HeaderRow.Font.Bold = true;
            gvUser.HeaderRow.Cells[0].Text = "EDIT";
            gvUser.HeaderRow.Cells[1].Text = "USER CODE";
            gvUser.HeaderRow.Cells[2].Text = "USER NAME";
            gvUser.HeaderRow.Cells[3].Text = "USER TYPE";
            gvUser.HeaderRow.Cells[4].Text = "STATUS";



            gvUser.HeaderRow.Cells[0].Wrap = false;
            gvUser.HeaderRow.Cells[1].Wrap = false;
            gvUser.HeaderRow.Cells[2].Wrap = false;
            gvUser.HeaderRow.Cells[3].Wrap = false;
            gvUser.HeaderRow.Cells[4].Wrap = false;
        }
    }
    public void bindUserAcs()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("select UAL_ID,UAL_DESC from MR_USER_ACS_LEVEL", con);
        SqlDataAdapter da1 = new SqlDataAdapter(cmddd);
        DataSet ds1 = new DataSet();
        da1.Fill(ds1);
        ddlstusracs.DataSource = ds1;
        ddlstusracs.DataTextField = "UAL_DESC";
        ddlstusracs.DataValueField = "UAL_ID";
        ddlstusracs.DataBind();
        ddlstusracs.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Right;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        if (btnSubmit.Text == "Update")
        {
            try
            {
                con.Open();
                if (Session["USRID"] != null)
                {
                    // SqlCommand insertcmd = new SqlCommand("Update MR_USER set USr_UTP_ID='" + ddlUsertype.SelectedValue + "' , USR_PEXP='" + txtPwddays.Text + "',USR_STAT='" + ddlStatus.SelectedValue + "',USR_MBY='" + Session["ID"].ToString() + "',USR_MDATE=GETDATE()  WHERE USR_ID =" + Session["USRID"].ToString() + "", con);
                    string Adt = "";
                    string[] AuDte = txtEndDate.Text.Split('/');
                    Adt = AuDte[2] + "-" + AuDte[1] + "-" + AuDte[0];
                    SqlCommand insertcmd = new SqlCommand("Update MR_USER set USr_UTP_ID='" + ddlUsertype.SelectedValue + "' , USR_PEXP='" + txtPwddays.Text + "',USR_STAT='" + ddlStatus.SelectedValue + "',USR_UAL_ID='" + ddlstusracs.SelectedValue + "',USR_MBY='" + Session["ID"].ToString() + "',USR_MDATE=GETDATE(), USR_TYPE='" + ddlmodule.SelectedValue + "',USR_END_DATE='" + Adt + "' WHERE USR_ID =" + Session["USRID"].ToString() + "", con);
                    insertcmd.ExecuteNonQuery();

                    insertcmd = new SqlCommand("Update MR_EMPLOYEE set EMP_STAT='" + ddlStatus.SelectedValue.ToString() + "', EMP_MBY='" + Session["ID"].ToString() + "',EMP_MDATE=GETDATE()  WHERE EMP_ID ='" + Session["MUEMPID"].ToString() + "'", con);
                    insertcmd.ExecuteNonQuery();

                    bind();
                    txtUsercode.Text = "";
                    txtUsername.Text = "";
                    txtPwd.Text = "";
                    txtPwddays.Text = "";
                    ddlStatus.SelectedIndex = 0;
                    ddlstusracs.SelectedIndex = 0;
                    ddlUsertype.SelectedIndex = 0;
                    txtEndDate.Text = "";
                    div_posusr.Value = "0";
                    btnSubmit.Text = "Submit";
                    uscMsgBox1.AddMessage("User Updated Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            finally
            {
                con.Close();
            }
        }
        else
        {

            if (ddlUsertype.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select User Type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                try
                {
                    string Adt = "";
                    string[] AuDte = txtEndDate.Text.Split('/');
                    Adt = AuDte[2] + "-" + AuDte[1] + "-" + AuDte[0];
                    con.Open();
                    SqlCommand cmdid = new SqlCommand("select UTP_ID from MR_USER_TYPE where UTP_DESC='" + ddlUsertype.SelectedItem.Text.ToString() + "'", con);
                    SqlDataAdapter daid = new SqlDataAdapter(cmdid);
                    DataSet dsid = new DataSet();
                    daid.Fill(dsid);
                    usrid = Convert.ToInt32(dsid.Tables[0].Rows[0]["UTP_ID"]);

                    SqlCommand cmdid1 = new SqlCommand("select * from MR_USER where USR_EMP_ID='" + Session["empid"].ToString() + "'", con);
                    SqlDataAdapter daid1 = new SqlDataAdapter(cmdid1);
                    DataSet dsid1 = new DataSet();
                    daid1.Fill(dsid1);
                    if (dsid1.Tables[0].Rows.Count == 0)
                    {
                        // SqlCommand insertcmd = new SqlCommand("insert into MR_USER values ('" + Session["empid"] + "','" + usrid + "','" + txtPwd.Text + "','','','" + txtPwddays.Text + "','" + ddlStatus.SelectedValue + "','" + Session["ID"].ToString() + "',getdate(),NULL,NULL)", con);
                        SqlCommand insertcmd = new SqlCommand("insert into MR_USER ( USR_TYPE, USR_EMP_ID,USR_UTP_ID,USR_UAL_ID,USR_PWD,USR_LLOGIN,USR_PWDM,USR_PEXP,USR_STAT,USR_CBY,USR_CDATE,USR_MBY,USR_MDATE,USR_END_DATE) values ('" + ddlmodule.SelectedValue + "','" + Session["empid"] + "','" + usrid + "','" + ddlstusracs.SelectedValue + "','" + txtPwd.Text + "',NULL,NULL,'" + txtPwddays.Text + "','" + ddlStatus.SelectedValue + "','" + Session["ID"].ToString() + "',getdate(),NULL,NULL,'" + Adt + "')", con);

                        insertcmd.ExecuteNonQuery();
                        bind();

                        SendMailU(con);
                      //Bala changes 18/07/2017  if (mail.IsAlive) { Thread.Sleep(1000); }


                        string strMailStatus = "";
                        string strSuccessMsg = "";

                        if (blMailStatus == true)
                        {
                            strMailStatus = "Successfully";
                        }
                        else
                        {
                            strMailStatus = "Failed";
                        }
                        strSuccessMsg = " <br/>Mail Sent " + strMailStatus + ".";
                        strSuccessMsg += "<br/>Mail To: " + toID + " ; CC To: " + ccID + " ";

                        txtUsercode.Text = "";
                        txtUsername.Text = "";
                        txtPwd.Text = "";
                        txtPwddays.Text = "";
                        ddlStatus.Text = "--Select--";
                        ddlstusracs.SelectedIndex = 0;
                        ddlUsertype.SelectedIndex = 0;
                        txtEndDate.Text="";
                        uscMsgBox1.AddMessage("User Added Successfully" + strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else
                    {
                        bind();
                        txtUsercode.Text = "";
                        txtUsername.Text = "";
                        txtPwd.Text = "";
                        txtPwddays.Text = "";
                        ddlStatus.Text = "--Select--";
                        txtEndDate.Text = "";
                        uscMsgBox1.AddMessage("User Already Exsist", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_User.aspx");
    }
    protected void txtUsercode_TextChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmduser = new SqlCommand("select EMP_NAME,EMP_ID from MR_EMPLOYEE WITH (nolock) where EMP_CODE ='" + txtUsercode.Text + "'", con);
            SqlDataAdapter dauser = new SqlDataAdapter(cmduser);
            DataSet dsuser = new DataSet();
            dauser.Fill(dsuser);
            if (dsuser.Tables[0].Rows.Count == 0)
            {
                uscMsgBox1.AddMessage("Entered User Code Is Not Added in the Employee Master", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
            {
                txtUsername.Text = dsuser.Tables[0].Rows[0]["EMP_NAME"].ToString();
                Session["empid"] = Convert.ToInt32(dsuser.Tables[0].Rows[0]["EMP_ID"]);
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }

    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow grow in gvUser.Rows)
            {
                RadioButton chkUserID = (RadioButton)grow.FindControl("rb_select");
                if (chkUserID.Checked)
                {
                    txtUsercode.Text = grow.Cells[1].Text;
                    txtUsercode.Enabled = false;
                    txtUsername.Text = grow.Cells[2].Text;
                    //  ddlUsertype.SelectedItem.Text = grow.Cells[3].Text;
                    if (grow.Cells[4].Text == "ACTIVE")
                    {
                        ddlStatus.SelectedValue = "1";
                    }
                    else
                    {

                        ddlStatus.SelectedValue = "0";
                    }
                    Label lblPwdExp = (Label)grow.FindControl("lblUsrPWEXP");
                    Label lblUSRID = (Label)grow.FindControl("lblUSRID");
                    Label lblUSRPwd = (Label)grow.FindControl("lblUSRPwd");
                    Label lblUsrTypeID = (Label)grow.FindControl("lblUsrTypeID");
                    Label lbl_usr_type = (Label)grow.FindControl("lbl_usr_type");
                    Label lbl_usr_end_date = (Label)grow.FindControl("lbl_usr_end_date");
                    ddlmodule.SelectedValue = lbl_usr_type.Text.Trim() != "" ? lbl_usr_type.Text.Trim() : "R";
                    ddlUsertype.SelectedValue = lblUsrTypeID.Text;
                    txtPwd.Enabled = false;
                    txtPwddays.Text = lblPwdExp.Text;
                    txtPwd.Text = lblUSRPwd.Text;
                    txtPwd.TextMode = TextBoxMode.Password;
                    txtEndDate.Text = lbl_usr_end_date.Text.Trim() != "" ? Convert.ToDateTime(lbl_usr_end_date.Text).ToString("dd/MM/yyyy") : "";
                    RequiredFieldValidator3.Enabled = false;
                    // txtPwddays.Enabled = false;

                    Label lblusracs = (Label)grow.FindControl("lblusrAcs");
                    ddlstusracs.SelectedValue = lblusracs.Text;

                    Label lblempid = (Label)grow.FindControl("lblusrempid");
                    Session["MUEMPID"] = lblempid.Text;

                    btnSubmit.Text = "Update";
                    Session["USRID"] = lblUSRID.Text;
                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void SendMailU(SqlConnection con)
    {
        try
        {
            StringBuilder cmdstr = new StringBuilder();

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();

            cmdstr.Append("SELECT UPPER(EMP_NAME) AS 'NAME', EMP_EMAILID, EMP_CODE, USR_PWD, (select em_bm from MR_EMAIL S where s.EM_BR_ID=A.EMP_BR_ID) 'BM', (select em_am from MR_EMAIL S where s.EM_BR_ID=A.EMP_BR_ID) 'AM' FROM MR_EMPLOYEE A ");
            cmdstr.Append(" JOIN MR_USER B ON B.USR_EMP_ID=A.EMP_ID ");
            cmdstr.Append(" WHERE EMP_CODE='" + txtUsercode.Text.Trim());
            cmdstr.Append("' AND B.USR_STAT = 1");



            cmd = new SqlCommand(cmdstr.ToString(), con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmd);
            DataTable dtdet = new DataTable();
            dadet.Fill(dtdet);


            toID = "";
            ccID = "";
            if (dtdet.Rows.Count > 0)
            {
                EMPNAME = dtdet.Rows[0]["NAME"] != DBNull.Value ? dtdet.Rows[0]["NAME"].ToString() : "";
                MAILID = dtdet.Rows[0]["EMP_EMAILID"] != DBNull.Value ? dtdet.Rows[0]["EMP_EMAILID"].ToString() : "";
                CODE = dtdet.Rows[0]["EMP_CODE"] != DBNull.Value ? dtdet.Rows[0]["EMP_CODE"].ToString() : "";
                PWD = dtdet.Rows[0]["USR_PWD"] != DBNull.Value ? dtdet.Rows[0]["USR_PWD"].ToString() : "";

                if (MAILID != "")
                {
                    toID = MAILID;
                }
                else
                {
                    toID = "RTS-HelpDesk@equitasbank.com";
                }
                //if (dtdet.Rows[0]["BM"] != DBNull.Value && dtdet.Rows[0]["BM"] != "")
                //{
                //    ccID = dtdet.Rows[0]["BM"].ToString();
                //}
                //if (dtdet.Rows[0]["AM"] != DBNull.Value && dtdet.Rows[0]["AM"] != "")
                //{
                //    if (ccID != "")
                //    {
                //        ccID = ccID + ";" + dtdet.Rows[0]["AM"].ToString();
                //    }
                //    else
                //    {
                //        ccID = dtdet.Rows[0]["AM"].ToString();
                //    }
                //}

            }



            else
            {
                blMailStatus = false;
                return;
            }



            frmID = "RTS Alerts";


            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{


                strMailBody = "<html><body><span style='font-family: Verdana, Arial, Tahoma; font-size:12px'>Dear <B>" + EMPNAME + "</B>,<br/><br/>Welcome to <strong> Retail Tracking System</strong>.<br/><br/>";
                strMailBody = strMailBody + "<table width='70%' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";

                if (ddlUsertype.SelectedValue == "2")
                {
                    strMailBody = strMailBody + "<tr bgcolor='#FFFFFF'><td >Website </td><td> <strong> http://rts.equitasbank.com/rts </strong></td></tr>";
                }
                else
                {
                    strMailBody = strMailBody + "<tr bgcolor='#FFFFFF'><td >Website </td><td> <strong> http://rts.equitasbank.com/rts </strong></td></tr>";
                }
                strMailBody = strMailBody + "<tr bgcolor='#FFFFFF'><td >User ID</td><td ><strong>" + CODE + "</strong></td></tr>";
                strMailBody = strMailBody + "<tr bgcolor='#FFFFFF'><td >Password</td><td ><strong>" + PWD + "</strong></td></tr>";
                strMailBody = strMailBody + "</table><br/>Request you to please login and change password immediately.<br/><br/>";
                strMailBody = strMailBody + "<tr><span style='color: #ff0000;font-style:italic'><br/><br/><strong>*** This is system generated mail. Please do not reply for this mail.</strong></span></tr></body></html>";


                blMailStatus = EmailManager.sendemail_User(toID, "RTS Alerts", "", ccID, "RTS - Access Info - " + EMPNAME, strMailBody, "", true);


            //});

            //threadSendMails.IsBackground = true;
            //mail = threadSendMails;
            //threadSendMails.Start();
            //Thread.Sleep(5000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
    }
}