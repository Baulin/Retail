﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.IO;
using System.Reflection;
using System.Collections;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Web.Services;
using Tracker;

public partial class Legal_MOTD2 : System.Web.UI.Page
{
    string value;
    string value1;
    int mdid;
    int id;
    DateTime validDate;
    DateTime validDate1;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DataSet dschk1 = new DataSet();
    DataSet dschk2 = new DataSet();
    DataSet dssp = new DataSet();
    DataTable dt = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //FillGridView();
            //SetInitialRow();
        }
    }
    public void FillGridView()
    {
        //if (Session["Click"].ToString() == "Add")
        //{
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        GlobalClass.adap = new SqlDataAdapter("select MDX_SLNO,MD_DATE,MDX_DOC,MDX_DTYPE from LSD_MOTD A JOIN LSD_MOTD_DOCX B ON A.MD_ID=B.MDX_MD_ID WHERE MD_SANTD_NO='" + txtSanctionno.Text + "'", con);
        SqlCommandBuilder bui = new SqlCommandBuilder(GlobalClass.adap);
        GlobalClass.dt = new DataTable();
        GlobalClass.adap.Fill(GlobalClass.dt);
        gvDoc.DataSource = GlobalClass.dt;
        //SqlCommand cmd = new SqlCommand("select A.*,B.ITEM_NAME from SJL_INWRD_ITEM_DETS A JOIN SJL_JWL_MSTR_DETS B ON A.ITEM_PKID_FK=B.PK_ID WHERE A.POUCH_ID='" + Session["PouchID"] + "'", con);
        //SqlDataAdapter da = new SqlDataAdapter(cmd);
        //da.Fill(dsfill);
        //GridView1.DataSource = dsfill;
        gvDoc.DataBind();
        gvDoc.Visible = true;
        btnAdd.Visible = true;
        con.Close();
        //}
    }
    private void SetInitialRow()
    {
        if (Session["Status"].ToString() == "Add")
        {
            DataTable dt = new DataTable();
            DataRow dr = null;
            dt.Columns.Add(new DataColumn("SLNO", typeof(string)));
            dt.Columns.Add(new DataColumn("Column1", typeof(string)));
            dt.Columns.Add(new DataColumn("Column2", typeof(string)));
            dt.Columns.Add(new DataColumn("Column3", typeof(string)));
            dt.Columns.Add(new DataColumn("Column4", typeof(string)));
            dr = dt.NewRow();
            dr["SLNO"] = 1;
            dr["Column1"] = string.Empty;
            dr["Column2"] = string.Empty;
            dr["Column3"] = string.Empty;
            dr["Column4"] = string.Empty;
            dt.Rows.Add(dr);
            //dr = dt.NewRow();

            //Store the DataTable in ViewState
            ViewState["CurrentTable"] = dt;

            gvDoc.DataSource = dt;
            gvDoc.DataBind();
        }
        else if (Session["Status"].ToString() == "Modify")
        {
            DataTable dt = new DataTable();
            DataRow dr = null;
            dt.Columns.Add(new DataColumn("SLNO", typeof(string)));
            dt.Columns.Add(new DataColumn("Column1", typeof(string)));
            dt.Columns.Add(new DataColumn("Column2", typeof(string)));
            dt.Columns.Add(new DataColumn("Column3", typeof(string)));
            dt.Columns.Add(new DataColumn("Column4", typeof(string)));
            dr = dt.NewRow();
            dr["SLNO"] = 1;
            dr["Column1"] = string.Empty;
            dr["Column2"] = string.Empty;
            dr["Column3"] = string.Empty;
            dr["Column4"] = string.Empty;
            dt.Rows.Add(dr);
            //dr = dt.NewRow();

            //Store the DataTable in ViewState
            ViewState["dt"] = dt;

            gvview.DataSource = dt;
            gvview.DataBind();
        }
    }
    private void AddNewRowToGrid()
    {
        if (Session["Status"].ToString() == "Add")
        {
            int rowIndex = 0;

            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                DataRow drCurrentRow = null;
                if (dtCurrentTable.Rows.Count > 0)
                {
                    for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                    {
                        //extract the TextBox values
                        TextBox box1 = (TextBox)gvDoc.Rows[rowIndex].Cells[1].FindControl("txtDate");
                        TextBox box2 = (TextBox)gvDoc.Rows[rowIndex].Cells[2].FindControl("txtDoc");
                        DropDownList box3 = (DropDownList)gvDoc.Rows[rowIndex].Cells[3].FindControl("Editdd");

                        drCurrentRow = dtCurrentTable.NewRow();
                        drCurrentRow["SLNO"] = i + 1;

                        dtCurrentTable.Rows[i - 1]["Column1"] = box1.Text;
                        dtCurrentTable.Rows[i - 1]["Column2"] = box2.Text;
                        dtCurrentTable.Rows[i - 1]["Column3"] = box3.SelectedItem.Text;


                        rowIndex++;
                    }
                    dtCurrentTable.Rows.Add(drCurrentRow);
                    ViewState["CurrentTable"] = dtCurrentTable;

                    gvDoc.DataSource = dtCurrentTable;
                    gvDoc.DataBind();
                }
            }
            else
            {
                SetInitialRow();
            }
        }
        else if (Session["Status"].ToString() == "Modify")
        {

            int rowIndex = 0;
            if (ViewState["dt"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["dt"];
                DataRow drCurrentRow = null;
                if (dtCurrentTable.Rows.Count > 0)
                {
                    //rowIndex = dtCurrentTable.Rows.Count + 1;
                    for (int i = dtCurrentTable.Rows.Count; i <= dtCurrentTable.Rows.Count; i++)
                    {
                        //extract the TextBox values

                        TextBox box1 = (TextBox)gvview.Rows[rowIndex].Cells[1].FindControl("txtDate");
                        TextBox box2 = (TextBox)gvview.Rows[rowIndex].Cells[2].FindControl("txtDoc");
                        DropDownList box3 = (DropDownList)gvview.Rows[rowIndex].Cells[3].FindControl("Editdd");

                        //dtCurrentTable.Columns.Add(new DataColumn("SLNO", typeof(string)));
                        //dtCurrentTable.Columns.Add(new DataColumn("Column1", typeof(string)));
                        //dtCurrentTable.Columns.Add(new DataColumn("Column2", typeof(string)));
                        //dtCurrentTable.Columns.Add(new DataColumn("Column3", typeof(string)));
                        //dtCurrentTable.Columns.Add(new DataColumn("Column4", typeof(string)));

                        drCurrentRow = dtCurrentTable.NewRow();
                        drCurrentRow["MDX_SLNO"] = i + 1;
                        drCurrentRow["MDX_DATE"] = "";
                        drCurrentRow["MDX_DOC"] = "";
                        drCurrentRow["MDX_DTYPE"] = "";
                        //dtCurrentTable.Rows[i + 1]["MDX_DATE"] = "";
                        //dtCurrentTable.Rows[i + 1]["MDX_DOC"] = string.Empty;
                        //dtCurrentTable.Rows[i + 1]["MDX_DTYPE"] = string.Empty;

                        rowIndex++;
                    }
                    dtCurrentTable.Rows.Add(drCurrentRow);
                    ViewState["dt"] = dtCurrentTable;

                    //gvview.EditIndex = e.NewEditIndex;

                    gvview.DataSource = dtCurrentTable;
                    gvview.DataBind();
                }
                else
                {
                    SetInitialRow();
                }
            }
        }
        else
        {
            Response.Write("ViewState is null");
        }

        //Set Previous Data on Postbacks
        SetPreviousData();
    }
    private void SetPreviousData()
    {
        if (Session["Status"].ToString() == "Add")
        {
            int rowIndex = 0;
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dt = (DataTable)ViewState["CurrentTable"];
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        TextBox box1 = (TextBox)gvDoc.Rows[rowIndex].Cells[1].FindControl("txtDate");
                        TextBox box2 = (TextBox)gvDoc.Rows[rowIndex].Cells[2].FindControl("txtDoc");
                        DropDownList box3 = (DropDownList)gvDoc.Rows[rowIndex].Cells[3].FindControl("Editdd");

                        box1.Text = dt.Rows[i]["Column1"].ToString();
                        box2.Text = dt.Rows[i]["Column2"].ToString();
                        box3.Text = dt.Rows[i]["Column3"].ToString();

                        rowIndex++;
                    }
                }
            }
        }
        else if (Session["Status"].ToString() == "Modify")
        {

        }
    }


    public static string NumberToWords(int number)
    {
        if (number == 0)
            return "zero";

        if (number < 0)
            return "minus " + NumberToWords(Math.Abs(number));

        string words = "";

        if ((number / 1000000) > 0)
        {
            words += NumberToWords(number / 1000000) + " million ";
            number %= 1000000;
        }

        if ((number / 100000) > 0)
        {
            words += NumberToWords(number / 100000) + " lakh ";
            number %= 100000;
        }

        if ((number / 1000) > 0)
        {
            words += NumberToWords(number / 1000) + " thousand ";
            number %= 1000;
        }

        if ((number / 100) > 0)
        {
            words += NumberToWords(number / 100) + " hundred ";
            number %= 100;
        }

        if (number > 0)
        {
            if (words != "")
                words += "and ";

            var unitsMap = new[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
            var tensMap = new[] { "zero", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

            if (number < 20)
                words += unitsMap[number];
            else
            {
                words += tensMap[number / 10];
                if ((number % 10) > 0)
                    words += "-" + unitsMap[number % 10];
            }
        }

        return words;

    }
    protected void btnRetrieve_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            if (txtSanctionno.Text != "")
            {
                SqlCommand cmdchk1 = new SqlCommand("select * from LSD_MOTD A JOIN LSD_MOTD_DOCX B ON A.MD_ID=B.MDX_MD_ID JOIN LSD_MOTD_CBRW C ON A.MD_ID=C.MCB_MD_ID where MD_SANTD_NO='" + txtSanctionno.Text + "'", con);
                SqlDataAdapter dachk1 = new SqlDataAdapter(cmdchk1);

                dachk1.Fill(dschk1);

                SqlCommand cmdsp = new SqlCommand("RTS_MOTD_SANC_MF", con);
                cmdsp.CommandType = CommandType.StoredProcedure;
                cmdsp.Parameters.Add("@Sanc", SqlDbType.VarChar).Value = txtSanctionno.Text;
                SqlDataAdapter showdatasp = new SqlDataAdapter(cmdsp);

                showdatasp.Fill(dssp);

                if (dschk1.Tables[0].Rows.Count > 0)
                {
                    Session["Status"] = "Modify";

                    int mdid = Convert.ToInt32(dschk1.Tables[0].Rows[0]["MD_ID"]);
                    if (mdid != 0)
                    {
                        SqlCommand cmdchk2 = new SqlCommand("select MDX_SLNO,MDX_MD_ID,convert(varchar(17),MDX_DATE,106) 'MDX_DATE',MDX_DOC,MDX_DTYPE from LSD_MOTD_DOCX WHERE MDX_MD_ID='" + mdid + "'", con);
                        SqlDataAdapter dachk2 = new SqlDataAdapter(cmdchk2);
                        dachk2.Fill(dt);
                    }

                    txtDate.Text = String.Format("{0:dd MMM yyyy}", dschk1.Tables[0].Rows[0]["MD_DATE"]);

                    txtname1.Text = dschk1.Tables[0].Rows[0]["MD_BR1_NAME"].ToString();
                    txtofname1.Text = dschk1.Tables[0].Rows[0]["MD_BR1_FNAME"].ToString();
                    txtage1.Text = dschk1.Tables[0].Rows[0]["MD_BR1_AGE"].ToString();

                    txtResiding1.Text = dschk1.Tables[0].Rows[0]["MD_BR_ADD1"].ToString();
                    txtResiding2.Text = dschk1.Tables[0].Rows[0]["MD_BR_ADD2"].ToString();
                    txtResiding3.Text = dschk1.Tables[0].Rows[0]["MD_BR_ADD3"].ToString();

                    txtloanamt.Text = dschk1.Tables[0].Rows[0]["MD_LOAN_AMT"].ToString();

                    txtProperty.Text = dschk1.Tables[0].Rows[0]["MD_PROP"].ToString();

                    gvCO.DataSource = dssp.Tables[1];
                    gvCO.DataBind();

                    gvview.DataSource = dt;
                    gvview.DataBind();

                    ViewState["dt"] = dt;

                    Panel3.Visible = true;

                    txtBound.Text = dschk1.Tables[0].Rows[0]["MD_BOUND"].ToString();
                    txtNorth.Text = dschk1.Tables[0].Rows[0]["MD_NORTH"].ToString();
                    txtSouth.Text = dschk1.Tables[0].Rows[0]["MD_SOUTH"].ToString();
                    txtEast.Text = dschk1.Tables[0].Rows[0]["MD_EAST"].ToString();
                    txtWest.Text = dschk1.Tables[0].Rows[0]["MD_WEST"].ToString();
                    txtReg.Text = dschk1.Tables[0].Rows[0]["MD_REGISTR"].ToString();

                    Session["COMPANY"] = dssp.Tables[0].Rows[0]["COMPANY"].ToString();

                    Session["COMPANYSHORT"] = dssp.Tables[0].Rows[0]["COMPANY CODE"].ToString();

                    btnSubmit.Enabled = false;
                    btnPrint.Enabled = true;
                    string word = NumberToWords(Convert.ToInt32(dschk1.Tables[0].Rows[0]["MD_LOAN_AMT"]));
                    Session["WORD"] = word.ToString();

                    txtDate.Enabled = false;
                    txtProperty.Enabled = false;
                    txtBound.Enabled = false;
                    txtNorth.Enabled = false;
                    txtSouth.Enabled = false;
                    txtEast.Enabled = false;
                    txtWest.Enabled = false;
                    txtReg.Enabled = false;

                    lnkModify.Enabled = true;
                }
                else
                {
                    Session["Status"] = "Add";

                    SqlCommand cmd = new SqlCommand("RTS_MOTD_SANC_MF", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Sanc", SqlDbType.VarChar).Value = txtSanctionno.Text;
                    SqlDataAdapter showdata = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    showdata.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtname1.Text = ds.Tables[0].Rows[0]["BORROWER"].ToString();
                        txtofname1.Text = ds.Tables[0].Rows[0]["S/o/ W/o /F/O"].ToString();
                        txtage1.Text = ds.Tables[0].Rows[0]["AGE"].ToString();

                        //txtname2.Text = ds.Tables[0].Rows[0]["COTITLESHORTDESC"].ToString() + ds.Tables[0].Rows[0]["CO-BORROWER"].ToString();
                        //txtofname2.Text = ds.Tables[0].Rows[0]["CO_S/o/ W/o /F/O"].ToString();
                        //txtage2.Text = ds.Tables[0].Rows[0]["COAGE"].ToString();

                        gvCO.DataSource = ds.Tables[1];
                        gvCO.DataBind();

                        Panel1.Visible = true;

                        txtResiding1.Text = ds.Tables[0].Rows[0]["ADDRESS"].ToString();
                        txtResiding2.Text = ds.Tables[0].Rows[0]["AREA"].ToString();
                        txtResiding3.Text = ds.Tables[0].Rows[0]["CITY"].ToString();

                        txtloanamt.Text = ds.Tables[0].Rows[0]["LNAMT"].ToString();

                        Session["COMPANY"] = ds.Tables[0].Rows[0]["COMPANY"].ToString();

                        Session["COMPANYSHORT"] = ds.Tables[0].Rows[0]["COMPANY CODE"].ToString();

                        btnSubmit.Enabled = true;
                        string word = NumberToWords(Convert.ToInt32(ds.Tables[0].Rows[0]["LNAMT"]));
                        Session["WORD"] = word.ToString();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Invalid Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
                    }
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Please Enter Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input.....", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void AddNewRecord(object sender, EventArgs e)
    {
        AddNewRowToGrid();
    }
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Right;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Session["Status"].ToString() == "Add")
        {
            SqlConnection con = new SqlConnection(strcon);
            try
            {
                con.Open();

                SqlCommand cmdcheck = new SqlCommand("select MD_SANTD_NO from LSD_MOTD where MD_SANTD_NO='" + txtSanctionno.Text + "'", con);
                SqlDataAdapter dacheck = new SqlDataAdapter(cmdcheck);
                DataSet dscheck = new DataSet();
                dacheck.Fill(dscheck);
                int a = dscheck.Tables[0].Rows.Count;
                if (a == 0)
                {
                    if (txtDate.Text != "")
                    {
                        value = txtDate.Text;
                        System.Globalization.DateTimeFormatInfo dateInfo = new System.Globalization.DateTimeFormatInfo();
                        dateInfo.ShortDatePattern = "yyyy/MM/dd";
                        validDate = Convert.ToDateTime(value, dateInfo);

                        SqlCommand cmdinsert = new SqlCommand("INSERT INTO LSD_MOTD(MD_SANTD_NO,MD_DATE,MD_BR1_NAME,MD_BR1_FNAME,MD_BR1_AGE,MD_BR_ADD1,MD_BR_ADD2,MD_BR_ADD3,MD_LOAN_AMT,MD_PROP,MD_BOUND,MD_NORTH,MD_SOUTH,MD_EAST,MD_WEST,MD_REGISTR,MD_CBY,MD_CDATE,MD_MBY,MD_MDATE) VALUES ('" + txtSanctionno.Text + "','" + validDate + "','" + txtname1.Text.Replace("'", "''") + "','" + txtofname1.Text.Replace("'", "''") + "','" + Convert.ToInt32(txtage1.Text) + "','" + txtResiding1.Text.Replace("'", "''") + "','" + txtResiding2.Text.Replace("'", "''") + "','" + txtResiding3.Text.Replace("'", "''") + "','" + txtloanamt.Text + "','" + txtProperty.Text.Replace("'", "''") + "','" + txtBound.Text.Replace("'", "''") + "','" + txtNorth.Text.Replace("'", "''") + "','" + txtSouth.Text.Replace("'", "''") + "','" + txtEast.Text.Replace("'", "''") + "','" + txtWest.Text.Replace("'", "''") + "','" + txtReg.Text.Replace("'", "''") + "','" + Session["ID"].ToString() + "',getdate(),'" + Session["ID"].ToString() + "',getdate())", con);
                        cmdinsert.ExecuteNonQuery();

                        SqlCommand cmdmd = new SqlCommand("select MD_ID from LSD_MOTD WHERE MD_SANTD_NO='" + txtSanctionno.Text + "'", con);
                        SqlDataAdapter damd = new SqlDataAdapter(cmdmd);
                        DataSet dsmd = new DataSet();
                        damd.Fill(dsmd);

                        mdid = Convert.ToInt32(dsmd.Tables[0].Rows[0]["MD_ID"]);

                        /////////// CO-Borrower insertion//////////////

                        int rowIndex1 = 0;
                        foreach (GridViewRow row in gvCO.Rows)
                        {
                            //string slno1 = gvCO.Rows[rowIndex1].Cells[0].Text;

                            int slno1 = rowIndex1 + 1;
                            string coname = gvCO.Rows[rowIndex1].Cells[1].Text;
                            string cofname = gvCO.Rows[rowIndex1].Cells[2].Text;
                            string coage = gvCO.Rows[rowIndex1].Cells[3].Text;


                            SqlCommand cmddocinsert = new SqlCommand("INSERT INTO LSD_MOTD_CBRW VALUES('" + mdid + "','" + slno1 + "','" + coname + "','" + cofname + "','" + coage + "')", con);
                            cmddocinsert.ExecuteNonQuery();
                            rowIndex1++;
                        }

                        /////////////// DOC insertion//////////////

                        int rowIndex = 0;
                        foreach (GridViewRow row in gvDoc.Rows)
                        {
                            int slno = Convert.ToInt32(gvDoc.Rows[rowIndex].Cells[0].Text);
                            TextBox box1 = (TextBox)gvDoc.Rows[rowIndex].Cells[1].FindControl("txtDate");
                            TextBox box2 = (TextBox)gvDoc.Rows[rowIndex].Cells[2].FindControl("txtDoc");
                            DropDownList box3 = (DropDownList)gvDoc.Rows[rowIndex].Cells[3].FindControl("Editdd");

                            value1 = box1.Text;
                            System.Globalization.DateTimeFormatInfo dateInfo1 = new System.Globalization.DateTimeFormatInfo();
                            dateInfo1.ShortDatePattern = "yyyy/MM/dd";
                            validDate1 = Convert.ToDateTime(value1, dateInfo1);

                            SqlCommand cmddocinsert = new SqlCommand("INSERT INTO LSD_MOTD_DOCX VALUES('" + mdid + "','" + slno + "','" + validDate1 + "','" + box2.Text.Replace("'", "''") + "','" + box3.SelectedValue.ToString() + "')", con);
                            cmddocinsert.ExecuteNonQuery();

                            rowIndex++;

                        }
                        btnSubmit.Enabled = false;
                        uscMsgBox1.AddMessage("MOTD Submitted Successfully For " + txtSanctionno.Text + "", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Please Select Date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
                else
                {
                    uscMsgBox1.AddMessage("MOTD Already Submitted For " + txtSanctionno.Text + "", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
            catch (Exception ex)
            {
                uscMsgBox1.AddMessage("Invalid Input.....", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
            }
        }
        else if (Session["Status"].ToString() == "Modify")
        {

            SqlConnection con = new SqlConnection(strcon);
            try
            {
                con.Open();

                SqlCommand cmdcheck = new SqlCommand("select MD_SANTD_NO from LSD_MOTD where MD_SANTD_NO='" + txtSanctionno.Text + "'", con);
                SqlDataAdapter dacheck = new SqlDataAdapter(cmdcheck);
                DataSet dscheck = new DataSet();
                dacheck.Fill(dscheck);
                int a = dscheck.Tables[0].Rows.Count;
                if (a != 0)
                {
                    if (txtDate.Text != "")
                    {
                        value = txtDate.Text;
                        System.Globalization.DateTimeFormatInfo dateInfo = new System.Globalization.DateTimeFormatInfo();
                        dateInfo.ShortDatePattern = "yyyy/MM/dd";
                        validDate = Convert.ToDateTime(value, dateInfo);

                        SqlCommand cmdupdate = new SqlCommand("UPDATE LSD_MOTD SET MD_DATE='" + validDate + "',MD_PROP='" + txtProperty.Text.Replace("'", "''") + "',MD_BOUND='" + txtBound.Text.Replace("'", "''") + "',MD_NORTH='" + txtNorth.Text.Replace("'", "''") + "',MD_SOUTH='" + txtSouth.Text.Replace("'", "''") + "',MD_EAST='" + txtEast.Text.Replace("'", "''") + "',MD_WEST='" + txtWest.Text.Replace("'", "''") + "',MD_REGISTR='" + txtReg.Text.Replace("'", "''") + "',MD_MBY='" + Session["ID"].ToString() + "',MD_MDATE=getdate() WHERE MD_SANTD_NO='" + txtSanctionno.Text + "'", con);
                        cmdupdate.ExecuteNonQuery();

                        SqlCommand cmdmd = new SqlCommand("select MD_ID from LSD_MOTD WHERE MD_SANTD_NO='" + txtSanctionno.Text + "'", con);
                        SqlDataAdapter damd = new SqlDataAdapter(cmdmd);
                        DataSet dsmd = new DataSet();
                        damd.Fill(dsmd);

                        mdid = Convert.ToInt32(dsmd.Tables[0].Rows[0]["MD_ID"]);

                        /////////// CO-Borrower insertion//////////////

                        //int rowIndex1 = 0;
                        //foreach (GridViewRow row in gvCO.Rows)
                        //{
                        //    //string slno1 = gvCO.Rows[rowIndex1].Cells[0].Text;

                        //    int slno1 = rowIndex1 + 1;
                        //    string coname = gvCO.Rows[rowIndex1].Cells[1].Text;
                        //    string cofname = gvCO.Rows[rowIndex1].Cells[2].Text;
                        //    string coage = gvCO.Rows[rowIndex1].Cells[3].Text;


                        //    SqlCommand cmddocinsert = new SqlCommand("INSERT INTO LSD_MOTD_CBRW VALUES('" + mdid + "','" + slno1 + "','" + coname + "','" + cofname + "','" + coage + "')", con);
                        //    cmddocinsert.ExecuteNonQuery();
                        //    rowIndex1++;
                        //}

                        /////////////// DOC insertion//////////////
                        SqlCommand cmddelete = new SqlCommand("Delete from LSD_MOTD_DOCX WHERE MDX_MD_ID='" + mdid + "'", con);
                        cmddelete.ExecuteNonQuery();

                        int rowIndex = 0;
                        foreach (GridViewRow row in gvview.Rows)
                        {
                            int slno = rowIndex + 1;
                            //Label lbmdid = gvview.FindControl("lblMdid") as Label;
                            //string docid = gvview.Rows[rowIndex].Cells[1].Text;
                            //int doc = Convert.ToInt32(lbmdid.Text);
                            Label box1 = (Label)gvview.Rows[rowIndex].Cells[2].FindControl("lblDocdate");
                            Label box2 = (Label)gvview.Rows[rowIndex].Cells[3].FindControl("lblDoc");
                            Label box3 = (Label)gvview.Rows[rowIndex].Cells[4].FindControl("lblDoctype");

                            value1 = box1.Text;
                            System.Globalization.DateTimeFormatInfo dateInfo1 = new System.Globalization.DateTimeFormatInfo();
                            dateInfo1.ShortDatePattern = "yyyy/MM/dd";
                            validDate1 = Convert.ToDateTime(value1, dateInfo1);

                            SqlCommand cmddocinsert = new SqlCommand("INSERT INTO LSD_MOTD_DOCX VALUES('" + mdid + "','" + slno + "','" + validDate1 + "','" + box2.Text.Replace("'", "''") + "','" + box3.Text.Replace("'", "''") + "')", con);
                            cmddocinsert.ExecuteNonQuery();

                            rowIndex++;

                        }
                        btnSubmit.Enabled = false;
                        uscMsgBox1.AddMessage("MOTD Modified Successfully For " + txtSanctionno.Text + "", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Please Select Date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
                else
                {
                    uscMsgBox1.AddMessage("MOTD Not Created For " + txtSanctionno.Text + "", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
            catch (Exception ex)
            {
                uscMsgBox1.AddMessage("Invalid Input.....", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
            }
        }
    }
    protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string item = e.Row.Cells[0].Text;
            foreach (Button button in e.Row.Cells[5].Controls.OfType<Button>())
            {
                if (button.CommandName == "Delete")
                {
                    button.Attributes["onclick"] = "if(!confirm('Do you want to delete " + item + "?')){ return false; };";
                }
                if (button.CommandName == "Edit")
                {

                }
                if (button.CommandName == "Update")
                {

                }
                if (button.CommandName == "Cancel")
                {

                }
            }
        }
    }
    protected void OnRowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int index = Convert.ToInt32(e.RowIndex);
            DataTable dt = ViewState["dt"] as DataTable;
            dt.Rows[index].Delete();
            ViewState["dt"] = dt;

            gvview.DataSource = ViewState["dt"] as DataTable;
            gvview.DataBind();
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Operation.....", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
    }

    protected void OnRowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            int index = Convert.ToInt32(e.NewEditIndex);
            DataTable dt = ViewState["dt"] as DataTable;
            dt.Rows[index].BeginEdit();
            ViewState["dt"] = dt;

            gvview.EditIndex = e.NewEditIndex;

            gvview.DataSource = ViewState["dt"] as DataTable;
            gvview.DataBind();
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Operation.....", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
    }

    protected void OnRowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            int index = Convert.ToInt32(e.RowIndex);
            if (ViewState["dt"] != null)
            {
                DataTable dt = (DataTable)ViewState["dt"];
                DataRow drRow = null;
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (i == e.RowIndex)
                        {
                            TextBox box1 = (TextBox)gvview.Rows[e.RowIndex].Cells[1].FindControl("txtDate");
                            TextBox box2 = (TextBox)gvview.Rows[e.RowIndex].Cells[2].FindControl("txtDoc");
                            DropDownList box3 = (DropDownList)gvview.Rows[e.RowIndex].Cells[3].FindControl("Editdd");

                            //drRow = dt.NewRow();
                            dt.Rows[index]["MDX_SLNO"] = dt.Rows.Count;

                            dt.Rows[index]["MDX_DATE"] = box1.Text;
                            dt.Rows[index]["MDX_DOC"] = box2.Text;
                            dt.Rows[index]["MDX_DTYPE"] = box3.SelectedItem.Text;

                            //rowIndex++;
                        }
                    }
                }
                ViewState["dt"] = dt;
            }

            gvview.EditIndex = -1;
            gvview.DataSource = ViewState["dt"] as DataTable;
            gvview.DataBind();
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Operation.....", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }

    }

    protected void OnRowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        try
        {
            gvview.EditIndex = -1;
            gvview.DataSource = ViewState["dt"] as DataTable;
            gvview.DataBind();
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Operation.....", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Legal_MOTD2.aspx");
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            id = 0;

            SqlCommand cmdmd = new SqlCommand("select MD_ID from LSD_MOTD WHERE MD_SANTD_NO='" + txtSanctionno.Text + "'", con);
            SqlDataAdapter damd = new SqlDataAdapter(cmdmd);
            DataSet dsmd = new DataSet();
            damd.Fill(dsmd);

            mdid = Convert.ToInt32(dsmd.Tables[0].Rows[0]["MD_ID"]);

            SqlCommand mycomm = new SqlCommand("select MD_ID from LSD_MOTD where MD_SANTD_NO='" + txtSanctionno.Text + "'", con);
            //mycomm.CommandType = CommandType.StoredProcedure;
            //mycomm.Parameters.Add("@LNNO", SqlDbType.VarChar).Value = txt_loan.Text;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            DataSet ds1 = new DataSet();
            showdata.Fill(ds1);
            id = ds1.Tables[0].Rows.Count;
            if (id == 0)
            {
                uscMsgBox1.AddMessage("Enter Valid Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                ReportDocument rpt = new ReportDocument();
                //ParameterValues para = new ParameterValues(); 
                //set a ReportPath and assign the dataset to reportdocument object
                rpt.Load(Server.MapPath("Reports/MOTD.rpt"));
                //ConnectionInfo connectionInfo = new ConnectionInfo();
                //connectionInfo.ServerName = "172.16.2.95";
                //connectionInfo.DatabaseName = "RTS1";
                //connectionInfo.IntegratedSecurity = true;

                rpt.SetDatabaseLogon("uno", "uno", @"172.16.2.95", "RTS1");
                //assign the values to crystal report viewer                              
                rpt.SetParameterValue(0, txtSanctionno.Text);
                rpt.SetParameterValue(1, mdid);
                rpt.SetParameterValue(2, Session["COMPANY"].ToString());
                rpt.SetParameterValue(3, Session["WORD"].ToString());
                rpt.SetParameterValue(4, Session["COMPANYSHORT"].ToString());
                rpt.SetParameterValue(5, mdid);
                rpt.ExportToHttpResponse(ExportFormatType.WordForWindows, Response, true, "MOTD For " + txtSanctionno.Text + "");
            }

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void lnkModify_Click(object sender, EventArgs e)
    {
        btnSubmit.Enabled = true;
        gvDoc.Visible = false;
        Panel1.Visible = false;
        Panel3.Visible = true;
        btnModifynewrecord.Visible = true;
        gvview.Columns[5].Visible = true;
        txtDate.Enabled = true;
        txtProperty.Enabled = true;
        txtBound.Enabled = true;
        txtNorth.Enabled = true;
        txtSouth.Enabled = true;
        txtEast.Enabled = true;
        txtWest.Enabled = true;
        txtReg.Enabled = true;
    }
    protected void btnModifynewrecord_Click(object sender, EventArgs e)
    {
        AddNewRowToGrid();
    }
}
