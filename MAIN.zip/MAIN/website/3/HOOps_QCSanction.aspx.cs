﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Utilities;
using Tracker;

public partial class HOOps_QCSanction : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string rcvquery;
    int ldid;
    int comm;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    DataSet dss = new DataSet();


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            bind();
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("select AR_NAME from MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        //LeadDataContext ldc = new LeadDataContext();
        //var abc = from leadno in ldc.LSD_LEADs select leadno;

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_NAME";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        gvQuerypop.Visible = false;
        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            //Session["View"] = "A";
            //gridbindall();
            uscMsgBox1.AddMessage("Please select Area ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            return;
        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            ddlArea.Enabled = false;
            gridbind();
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";
            gridbind();
        }
        else if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select Area and Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (ddlBranch.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please Select Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txtLeadno.Text == "")
        {
            uscMsgBox1.AddMessage("Please Enter Lead No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }
    public void gridbindall()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmd = new SqlCommand("select DISTINCT LD_NO 'LOAN NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID LEFT JOIN MR_BRANCH C ON B.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_FILE_TRANS E ON B.LD_ID=E.FT_LD_ID WHERE ISNULL(LD_SANTD_DATE,'')='' AND FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' ORDER BY LD_NO", con);
            SqlCommand cmd = new SqlCommand("select distinct LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',CASE WHEN  LD_PD_DATE IS NOT NULL THEN ISNULL(CONVERT(VARCHAR(11),LD_PD_DATE,106),'')  WHEN LD_CPD_DATE IS NOT NULL THEN ISNULL(CONVERT(VARCHAR(11),LD_CPD_DATE,106),'')  ELSE '''' END  'PD DATE',CASE WHEN  LD_PD_AMT IS NOT NULL THEN ISNULL(LD_PD_AMT,'')  WHEN LD_CPD_AMT IS NOT NULL THEN ISNULL(LD_CPD_AMT,'') ELSE 0 END 'LOAN AMOUNT',MPS.MPS_NAME 'SCHEME' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_QUERY E ON A.LD_ID=E.QRY_LD_ID LEFT JOIN MR_PROD_SCHEME MPS ON MPS.MPS_ID=A.LD_MPS_ID WHERE FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND isnull(LD_SANTD_DATE,'')='' AND ISNULL(LD_LC_DATE,'')='' ORDER BY LD_NO", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvSanc.DataSource = ds1.Tables[0];
            gvSanc.DataBind();
            if (ds1.Tables[0].Rows.Count > 0)
            {
                gvSanc.HeaderRow.Font.Bold = true;
                gvSanc.HeaderRow.Cells[1].Text = "LEAD NO";
                gvSanc.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvSanc.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvSanc.HeaderRow.Cells[4].Text = "PD DATE";
                gvSanc.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                //gvSanc.HeaderRow.Cells[6].Text = "RESOLVED";

                gvSanc.HeaderRow.Cells[1].Wrap = false;
                gvSanc.HeaderRow.Cells[2].Wrap = false;
                gvSanc.HeaderRow.Cells[3].Wrap = false;
                gvSanc.HeaderRow.Cells[4].Wrap = false;
                gvSanc.HeaderRow.Cells[5].Wrap = false;
                //gvSanc.HeaderRow.Cells[6].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmd = new SqlCommand("select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',CASE WHEN  LD_PD_DATE IS NOT NULL THEN ISNULL(CONVERT(VARCHAR(11),LD_PD_DATE,106),'')  WHEN LD_CPD_DATE IS NOT NULL THEN ISNULL(CONVERT(VARCHAR(11),LD_CPD_DATE,106),'')  ELSE '''' END  'PD DATE',CASE WHEN  LD_PD_AMT IS NOT NULL THEN ISNULL(LD_PD_AMT,'')  WHEN LD_CPD_AMT IS NOT NULL THEN ISNULL(LD_CPD_AMT,'') ELSE 0 END 'LOAN AMOUNT',MPS.MPS_NAME 'SCHEME' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN MR_PROD_SCHEME MPS ON MPS.MPS_ID=A.LD_MPS_ID WHERE FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND LD_NO='" + txtLeadno.Text + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' OR FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND AR_NAME='" + ddlArea.SelectedValue.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedValue.ToString() + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' ORDER BY LD_NO", con);
            SqlCommand cmd = new SqlCommand("RTS_SP_HO_Ops_Query", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvSanc.DataSource = ds.Tables[0];
            gvSanc.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvSanc.HeaderRow.Font.Bold = true;
                gvSanc.HeaderRow.Cells[1].Text = "LEAD NO";
                gvSanc.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvSanc.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvSanc.HeaderRow.Cells[4].Text = "PD DATE";
                gvSanc.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                //gvSanc.HeaderRow.Cells[6].Text = "RESOLVED";

                gvSanc.HeaderRow.Cells[1].Wrap = false;
                gvSanc.HeaderRow.Cells[2].Wrap = false;
                gvSanc.HeaderRow.Cells[3].Wrap = false;
                gvSanc.HeaderRow.Cells[4].Wrap = false;
                gvSanc.HeaderRow.Cells[5].Wrap = false;
                //gvSanc.HeaderRow.Cells[6].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
            //e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        foreach (GridViewRow grow in gvSanc.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
           // LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                leadno = gvSanc.Rows[index].Cells[1].Text;
                appname = gvSanc.Rows[index].Cells[3].Text;
                pddt = gvSanc.Rows[index].Cells[4].Text;
                lnamt = gvSanc.Rows[index].Cells[5].Text;
                //rcvquery = gvSanc.Rows[index].Cells[6].Text;
                Session["Leadno"] = leadno;
                Session["Loanamt"] = lnamt;
                Session["Appname"] = appname;
            }
        }
        gridbind1();
        gvQuerypop.Visible = true;
        //lbLeadno.Visible = true;
        //lbAppname.Visible = true;
        //lbPDdate.Visible = true;
        //lbLoanamt.Visible = true;
        txtComment.Enabled = true;
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;

        //lbLeadno.Text = leadno.ToString();
        //lbAppname.Text = appname;
        //lbPDdate.Text = pddt;
        //lbLoanamt.Text = lnamt;
        //Session["Rslvquery"] = rcvquery;
        con.Close();
    }
    public void gridbind1()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select QRY_SQUERY 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "' AND QRY_RSD_BY='H'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dss);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //    //Panel1.Visible = true;
            gvQuerypop.DataSource = dss.Tables[0];
            gvQuerypop.DataBind();
            if (dss.Tables[0].Rows.Count > 0)
            {
                gvQuerypop.HeaderRow.Font.Bold = true;
                gvQuerypop.HeaderRow.Cells[1].Text = "Query Raised";
                gvQuerypop.HeaderRow.Cells[2].Text = "Date";
                gvQuerypop.HeaderRow.Cells[3].Text = "Response";
                gvQuerypop.HeaderRow.Cells[4].Text = "Response Date";
                gvQuerypop.HeaderRow.Cells[5].Text = "Resolve Date";

                gvQuerypop.HeaderRow.Cells[1].Wrap = false;
                gvQuerypop.HeaderRow.Cells[2].Wrap = false;
                gvQuerypop.HeaderRow.Cells[3].Wrap = false;
                gvQuerypop.HeaderRow.Cells[4].Wrap = false;
                gvQuerypop.HeaderRow.Cells[5].Wrap = false;

            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound1(object o, GridViewRowEventArgs e)
    {
        if (dss.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Right;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('HOOps_QCQuery_Popup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //if (txtSanc.Text == "")
        //{
        //    uscMsgBox1.AddMessage("Please Enter Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        //}        
        //else
        //{
            if (Session["View"].ToString() == "F")
            {
                SqlConnection con = new SqlConnection(strcon);
                try
                {
                    con.Open();
                    SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + Session["Leadno"].ToString() + "'", con);
                    SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
                    DataSet dsbr = new DataSet();
                    dabr.Fill(dsbr);
                    ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
                    
                    SqlCommand cmdcomm = new SqlCommand("select * from LSD_QUERY where QRY_LD_ID='" + ldid + "' and QRY_RSD_BY='H' and isnull(QRY_RSL_DATE,'')=''", con);
                    SqlDataAdapter dacomm = new SqlDataAdapter(cmdcomm);
                    DataSet dscomm = new DataSet();
                    dacomm.Fill(dscomm);                    
                    comm = dscomm.Tables[0].Rows.Count;
                    if (comm != 0 && txtComment.Text.Trim() == "")
                    {
                        uscMsgBox1.AddMessage("" + comm + " Query pending, To Continue Please Enter Comments", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else
                    {
                        SqlCommand cmdupdate = new SqlCommand("update LSD_LEAD set LD_SANTD_DATE=getdate(),LD_SANTD_CMTS='" + txtComment.Text.Replace("'", "''") + "',LD_SANTD_MBY='" + Session["ID"].ToString() + "',LD_SANTD_MDATE=getdate() where LD_ID='" + ldid + "'", con);
                        cmdupdate.ExecuteNonQuery();

                        ///////// mail ///////////
                        SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "'", con);
                        SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
                        DataSet dsdet = new DataSet();
                        dadet.Fill(dsdet);

                        SqlCommand cmdmail = new SqlCommand("select QRY_SQUERY 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "' AND QRY_RSD_BY='H'", con);
                        SqlDataAdapter damail = new SqlDataAdapter(cmdmail);
                        DataSet dsmail = new DataSet();
                        damail.Fill(dsmail);

                         ///to whom//////
                        int nBranch_ID = dsdet.Tables[0].Rows[0]["LD_BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["LD_BR_ID"]) : 0;
                        SqlCommand cmdmailto = new SqlCommand("SELECT EM_BM,EM_AM,EM_HO,EM_BCC FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
                        SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
                        DataSet dsmailto = new DataSet();
                        damailto.Fill(dsmailto);
                        if (dsmailto.Tables[0].Rows.Count != 0)
                        {
                            to = dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
                            cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                            bcc = dsmailto.Tables[0].Rows[0]["EM_HO"].ToString();
                            bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
                        }
                        if (bcc != "" && bcc1 != "")
                        {
                            bcc2 = bcc + ";" + bcc1;
                        }
                        else if (bcc != "")
                        {
                            bcc2 = bcc;
                        }
                        else if (bcc1 != "")
                        {
                            bcc2 = bcc1;
                        }
                        else
                        {
                            bcc2 = "";
                        }
                      //  to = "ManimaranK@equitasbank.com";
                      //  bcc2 = "ManimaranK@equitasbank.com";
                      //  cc = "rts-helpdesk@equitasbank.com";
                        // To Auto mail ///////
                        System.Threading.Thread threadSendMails;

                        //threadSendMails = new System.Threading.Thread(delegate()
                        //{

                            String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of HO-Ops-QC Sanctioned<br/><br/>";
                            BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td>";
                            BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + Session["Appname"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + "</strong></td>";
                            BodyTxt = BodyTxt + "<td>Loan Amount</td><td><strong>" + Session["Loanamt"] + "</strong></td></tr></table><br/><br/>";
                            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Address </td><td align='center'>:</td><td><strong>" + cusaddr + "</strong></td></tr>";
                            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Mobile No.</td><td align='center'>:</td><td><strong>" + mobile + "</strong></td></tr></table><br/><br/>";
                            int b = dsmail.Tables[0].Rows.Count;
                            if (b != 0)
                            {
                                BodyTxt = BodyTxt + "<table width='100%' border='1' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span style='color: #FFFFFF'><td align='center'>Sl. No.</td>";
                                BodyTxt = BodyTxt + "<td  align='center'>HO-Ops-QC Query Details</td>";
                                BodyTxt = BodyTxt + "<td  align='center'>Query Date</td>";
                                BodyTxt = BodyTxt + "<td  align='center'>Response</td>";
                                BodyTxt = BodyTxt + "<td  align='center'>Response Date</td>";
                                BodyTxt = BodyTxt + "<td  align='center'>Resolve Date</td></span></tr>";
                                for (int j = 0; j <= b - 1; j++)
                                {
                                    int sno = j + 1;
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span style='color: #FFFFFF'><td align='right'> " + sno + "</td>";
                                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Query Raised"].ToString() + "</td>";
                                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Date"].ToString() + "</td>";
                                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response"].ToString() + "</td>";
                                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response Date"].ToString() + "</td>";
                                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Resolve Date"].ToString() + "</td></span></tr>";
                                }
                                BodyTxt = BodyTxt + "</table>";
                            }
                            BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>HO-Ops-QC Comments :" + txtComment.Text + "</td></tr>";
                            BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>HO-Ops-QC Team</td></tr>";
                            BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
                            //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

                            EmailManager.sendemail(to, "RTS Alerts", bcc2, cc, "Lead No. : " + Session["Leadno"].ToString() + " - Applicant Name : " + Session["Appname"].ToString() + " - Product: " + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + " - HO-Ops-QC Sanctioned", BodyTxt, "", true);
                            //sendemail("SurendharR@equitasbank.com;PrabhakaranA@equitasbank.com;Tamilalagand@equitasbank.com", "surendharr@equitasbank.com", "Test", BodyTxt, "", true);

                        //});

                        //threadSendMails.IsBackground = true;

                        //threadSendMails.Start();
                        //System.Threading.Thread.Sleep(5000);

                        gridbind();
                        lbLeadno.Text = "";
                        lbAppname.Text = "";
                        lbPDdate.Text = "";
                        lbLoanamt.Text = "";
                        txtComment.Text = "";
                        btnSubmit.Enabled = false;
                        btnCancel.Enabled = false;
                        gvQuerypop.Visible = false;
                        uscMsgBox1.AddMessage("Sanctioned Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
                finally
                {
                    con.Close();
                }
            }
            else if (Session["View"].ToString() == "A")
            {
                SqlConnection con = new SqlConnection(strcon);
                try
                {
                    con.Open();
                    SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + Session["Leadno"].ToString() + "'", con);
                    SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
                    DataSet dsbr = new DataSet();
                    dabr.Fill(dsbr);
                    ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);

                    SqlCommand cmdcomm = new SqlCommand("select * from LSD_QUERY where QRY_LD_ID='" + ldid + "' and QRY_RSD_BY='H' and isnull(QRY_RSL_DATE,'')=''", con);
                    SqlDataAdapter dacomm = new SqlDataAdapter(cmdcomm);
                    DataSet dscomm = new DataSet();
                    dacomm.Fill(dscomm);
                    comm = dscomm.Tables[0].Rows.Count;
                    if (comm != 0 && txtComment.Text.Trim() == "")
                    {
                        uscMsgBox1.AddMessage("" + comm + " Query pending, To Continue Please Enter Comments", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else
                    {
                        SqlCommand cmdupdate = new SqlCommand("update LSD_LEAD set LD_SANTD_DATE=getdate(),LD_SANTD_CMTS='" + txtComment.Text.Replace("'","''") + "',LD_SANTD_MBY='" + Session["ID"].ToString() + "',LD_SANTD_MDATE=getdate() where LD_ID='" + ldid + "'", con);
                        cmdupdate.ExecuteNonQuery();

                        ///////// mail ///////////
                        SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "'", con);
                        SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
                        DataSet dsdet = new DataSet();
                        dadet.Fill(dsdet);

                        SqlCommand cmdmail = new SqlCommand("select QRY_SQUERY 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "' AND QRY_RSD_BY='H'", con);
                        SqlDataAdapter damail = new SqlDataAdapter(cmdmail);
                        DataSet dsmail = new DataSet();
                        damail.Fill(dsmail);

                        // to whom//////
                        int nBranch_ID = dsdet.Tables[0].Rows[0]["LD_BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["LD_BR_ID"]) : 0;
                        SqlCommand cmdmailto = new SqlCommand("SELECT EM_BM,EM_AM,EM_HO,EM_BCC FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
                        SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
                        DataSet dsmailto = new DataSet();
                        damailto.Fill(dsmailto);
                        if (dsmailto.Tables[0].Rows.Count != 0)
                        {
                            to = dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
                            cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                            bcc = dsmailto.Tables[0].Rows[0]["EM_HO"].ToString();
                            bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
                        }
                        if (bcc != "" && bcc1 != "")
                        {
                            bcc2 = bcc + ";" + bcc1;
                        }
                        else if (bcc != "")
                        {
                            bcc2 = bcc;
                        }
                        else if (bcc1 != "")
                        {
                            bcc2 = bcc1;
                        }
                        else
                        {
                            bcc2 = "";
                        }
                     //   to = "ManimaranK@equitasbank.com";
                     //   bcc2 = "ManimaranK@equitasbank.com";
                       // cc = "rts-helpdesk@equitasbank.com";
                        // To Auto mail ///////
                        System.Threading.Thread threadSendMails;

                        //threadSendMails = new System.Threading.Thread(delegate()
                        //{

                            String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of HO-Ops-QC Sanctioned<br/><br/>";
                            BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td>";
                            BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + Session["Appname"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + "</strong></td>";
                            BodyTxt = BodyTxt + "<td>Loan Amount</td><td><strong>" + Session["Loanamt"] + "</strong></td></tr></table><br/><br/>";
                            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Address </td><td align='center'>:</td><td><strong>" + cusaddr + "</strong></td></tr>";
                            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Mobile No.</td><td align='center'>:</td><td><strong>" + mobile + "</strong></td></tr></table><br/><br/>";
                            int b = dsmail.Tables[0].Rows.Count;
                            if (b != 0)
                            {
                                BodyTxt = BodyTxt + "<table width='100%' border='1' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='center'>Sl. No.</td>";
                                BodyTxt = BodyTxt + "<td  align='center'>HO-Ops-QC Query Details</td>";
                                BodyTxt = BodyTxt + "<td  align='center'>Query Date</td>";
                                BodyTxt = BodyTxt + "<td  align='center'>Response</td>";
                                BodyTxt = BodyTxt + "<td  align='center'>Response Date</td>";
                                BodyTxt = BodyTxt + "<td  align='center'>Resolve Date</td></span></tr>";
                                for (int j = 0; j <= b - 1; j++)
                                {
                                    int sno = j + 1;
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='right'> " + sno + "</td>";
                                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Query Raised"].ToString() + "</td>";
                                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Date"].ToString() + "</td>";
                                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response"].ToString() + "</td>";
                                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response Date"].ToString() + "</td>";
                                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Resolve Date"].ToString() + "</td></span></tr>";
                                }
                                BodyTxt = BodyTxt + "</table>";
                            }
                            BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>HO-Ops-QC Comments :" + txtComment.Text + "</td></tr>";
                            BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>HO-Ops-QC Team</td></tr>";
                            BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
                            //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

                            EmailManager.sendemail(to, "RTS Alerts", bcc2, cc, "Lead No. : " + Session["Leadno"].ToString() + " - Applicant Name : " + Session["Appname"].ToString() + " - Product: " + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + " - HO-Ops-QC Sanctioned", BodyTxt, "", true);
                            //sendemail("SurendharR@equitasbank.com;PrabhakaranA@equitasbank.com;Tamilalagand@equitasbank.com", "surendharr@equitasbank.com", "Test", BodyTxt, "", true);

                        //});

                        //threadSendMails.IsBackground = true;

                        //threadSendMails.Start();
                        //System.Threading.Thread.Sleep(5000);

                        gridbindall();
                        lbLeadno.Text = "";
                        lbAppname.Text = "";
                        lbPDdate.Text = "";
                        lbLoanamt.Text = "";
                        txtComment.Text = "";
                        btnSubmit.Enabled = false;
                        btnCancel.Enabled = false;
                        gvQuerypop.Visible = false;
                        uscMsgBox1.AddMessage("Sanctioned Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
                finally
                {
                    con.Close();
                }
            }
        //}
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HOOps_QCSanction.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedValue.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_NAME";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Enabled = false;
    }
}