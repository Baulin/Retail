﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using Tracker;

public partial class NEFT_Bulk_CHQ_Print : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.bt_print);

       if(Session["ID"]!=null)
       {

       }
       else
       {
           Response.Redirect("default.aspx");
       }
    }
    protected void bt_print_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            SqlCommand cmd = new SqlCommand("NEFT_BULK_CHQ_PRINT", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 240000;
            cmd.Parameters.Add("@PDT", SqlDbType.VarChar).Value = ddlCamType.SelectedValue;
            cmd.Parameters.Add("@FRDT", SqlDbType.VarChar).Value = Convert.ToDateTime(txtFromDate.Text).ToString("yyyy-MM-dd");
            cmd.Parameters.Add("@TODT", SqlDbType.VarChar).Value = Convert.ToDateTime(txtToDate.Text).ToString("yyyy-MM-dd");
            SqlDataAdapter showdata = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            showdata.Fill(ds);
            //con.Close();
           /* if (ds.Tables[0].Rows.Count > 0)
            {
                System.IO.StringWriter tw = new System.IO.StringWriter();
                GridView dgGrid = new GridView();
                dgGrid.DataSource = ds;
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=NEFT BULK REPORT FROM " + txtFromDate.Text + " TO " + txtToDate.Text + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                dgGrid.AllowPaging = false;
                dgGrid.DataBind();
                //Change the Header Row back to white color
                dgGrid.HeaderRow.Style.Add("background-color", "#FFFFFF");
                dgGrid.HeaderRow.ForeColor = Color.White;
                DataGrid dg = new DataGrid();
                dg.DataSource = ds;
                dg.DataBind();
                dgGrid.BorderColor = Color.FromArgb(211, 211, 211);
                for (int z = 0; z < dg.Items[0].Cells.Count; z++)
                {
                    //Apply style to Individual Cells
                    dgGrid.HeaderRow.Cells[z].Style.Add("background-color", "#7F7F7F");
                    dgGrid.HeaderRow.Cells[z].BorderColor = Color.FromArgb(211, 211, 211);
                    //dgGrid.HeaderRow.Cells[z].Height = 30;
                }
                for (int i = 0; i < dgGrid.Rows.Count; i++)
                {
                    GridViewRow row = dgGrid.Rows[i];

                    //Change Color back to white
                    row.BackColor = System.Drawing.Color.White;

                    //Apply text style to each Row
                    row.Attributes.Add("class", "textmode");

                   
                }
                dgGrid.RenderControl(hw);
                string year = DateTime.Now.AddYears(0).ToString("yyyy");
                string headerTable = @"<Table><tr><th colspan=7 align=left><font face=Calibri size=5 color=#974807>NEFT BULK REPORT FROM " + txtFromDate.Text + " TO " + txtToDate.Text + "</font></th></tr></Table>";
                Response.Write(headerTable);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();


            }
            else
            {
                uscMsgBox1.AddMessage("No Data Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }
            */

            if (ds.Tables[0].Rows.Count > 0)
            {
                System.IO.StringWriter tw = new System.IO.StringWriter();

                GridView dgGrid = new GridView();
                dgGrid.DataSource = ds;
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=NEFT Bulk Report From " + txtFromDate.Text + " To " + txtToDate.Text + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                dgGrid.AllowPaging = false;
                dgGrid.DataBind();
                //Change the Header Row back to white color
                dgGrid.HeaderRow.Style.Add("background-color", "#FFFFFF");
                dgGrid.HeaderRow.ForeColor = Color.White;
                DataGrid dg = new DataGrid();
                dg.DataSource = ds;
                dg.DataBind();
                dgGrid.BorderColor = Color.Black;
                dgGrid.Font.Size = 8;
                for (int z = 0; z < dg.Items[0].Cells.Count; z++)
                {
                    dgGrid.HeaderRow.Cells[z].Style.Add("background-color", "#7F7F7F");
                    dgGrid.HeaderRow.Cells[z].BorderColor = Color.Black;

                }
                for (int i = 0; i < dgGrid.Rows.Count; i++)
                {
                    GridViewRow row = dgGrid.Rows[i];
                    //Change Color back to white
                    row.BackColor = System.Drawing.Color.White;
                    //Apply text style to each Row
                    row.Attributes.Add("class", "textmode");
                }

                dgGrid.RenderControl(hw);
                string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                string headerTable = @"<Table><tr><th colspan=8 align=left><font face=Calibri size=5 color=#974807>NEFT Bulk Report From "+txtFromDate.Text+" To "+txtToDate.Text+" </font></th></tr></Table>";

                Response.Write(headerTable);
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
                con.Close();
            }
            else
            {
                uscMsgBox1.AddMessage("No Data Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }
            con.Close();
        }
        catch(Exception ex)
        {
            
            ErrorLog.WriteError(ex);
        }
    }
}