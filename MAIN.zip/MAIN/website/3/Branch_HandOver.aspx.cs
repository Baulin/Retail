﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Branch_HandOver : System.Web.UI.Page
{
    int ldid, s;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["AREA_ID"] != null)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
                ddlArea.SelectedValue = Session["AREA_ID"].ToString();

                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmdrsn = new SqlCommand("select BR_NAME,BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.ToString() + "'", con);
                SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
                DataSet dsrsn = new DataSet();
                darsn.Fill(dsrsn);
                con.Close();

                ddlBranch.DataSource = dsrsn;
                ddlBranch.DataTextField = "BR_NAME";
                ddlBranch.DataValueField = "BR_ID";
                ddlBranch.DataBind();
                ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
                if (Session["USR_ACS"].ToString() == "7")
                {
                    ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
                    ddlBranch.Enabled = false;
                    ddlArea.Enabled = false;
                }
            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("select AR_NAME,AR_ID from MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            s = 0;
            foreach (GridViewRow grow in gvRcvfile.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    s += 1;
                    SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + gvRcvfile.Rows[index].Cells[1].Text + "'", con);
                    SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
                    DataSet dsbr = new DataSet();
                    dabr.Fill(dsbr);
                    ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);

                    SqlCommand cmdft = new SqlCommand("SELECT FT_ID FROM LSD_DISB_FILE_TRANS where FT_LD_ID='" + ldid + "' AND ISNULL(FT_RDATE,'')=''", con);
                    SqlDataAdapter daft = new SqlDataAdapter(cmdft);
                    DataSet dsft = new DataSet();
                    daft.Fill(dsft);
                    //ftid = Convert.ToInt32(dsft.Tables[0].Rows[0]["FT_ID"]);

                    SqlCommand cmdupdate = new SqlCommand("Rts_Pr_Inser_ChequeTran_Date", con);
                    cmdupdate.CommandType = CommandType.StoredProcedure;
                    cmdupdate.Parameters.AddWithValue("@leadID", ldid);
                    cmdupdate.Parameters.AddWithValue("@FT_SNEDBY", "B");
                    cmdupdate.Parameters.AddWithValue("@FT_SNEDTO", "C");
                    cmdupdate.Parameters.AddWithValue("@Type", "Insert");
                    cmdupdate.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                    cmdupdate.ExecuteNonQuery();
                }
            }
            gridbindall();
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
            ddlArea.Enabled = true;
            ddlBranch.Enabled = true;
            txtLeadno.Enabled = true;
            btnSubmit.Enabled = false;
            uscMsgBox1.AddMessage(s + " File/s Send Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }



    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("BranchHandOver.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "A";
            gridbindall();
        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            ddlArea.Enabled = false;
            gridbindall();
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";
            gridbindall();
        }
        else if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select Area and Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (ddlBranch.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please Select Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txtLeadno.Text == "")
        {
            uscMsgBox1.AddMessage("Please Enter Lead No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }
    public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Pr_Fetch_Data_Cheque_Dispose", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@leadID", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AreaID", ddlArea.SelectedIndex > 0 ? ddlArea.SelectedValue : "");
            cmd.Parameters.AddWithValue("@BranchID", ddlBranch.SelectedIndex > 0 ? ddlBranch.SelectedValue : "");
            cmd.Parameters.AddWithValue("@Type", "CBCS");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvRcvfile.DataSource = ds1.Tables[0];
            gvRcvfile.DataBind();
            if (ds1.Tables[0].Rows.Count > 0)
            {
                gvRcvfile.HeaderRow.Font.Bold = true;
                gvRcvfile.HeaderRow.Cells[1].Text = "LEAD NO";
                gvRcvfile.HeaderRow.Cells[2].Text = "APPLICANT NAME";
                gvRcvfile.HeaderRow.Cells[3].Text = "LOAN NO";
                gvRcvfile.HeaderRow.Cells[4].Text = "LOAN DATE";
                gvRcvfile.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvRcvfile.HeaderRow.Cells[6].Text = "BRANCH NAME";

                gvRcvfile.HeaderRow.Cells[1].Wrap = false;
                gvRcvfile.HeaderRow.Cells[2].Wrap = false;
                gvRcvfile.HeaderRow.Cells[3].Wrap = false;
                gvRcvfile.HeaderRow.Cells[4].Wrap = false;
                gvRcvfile.HeaderRow.Cells[5].Wrap = false;
                gvRcvfile.HeaderRow.Cells[6].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME' from LSD_LEAD A JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID  JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')='' AND LD_NO='" + txtLeadno.Text + "' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') OR FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')='' AND AR_NAME='" + ddlArea.SelectedValue.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedValue.ToString() + "' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='')", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvRcvfile.DataSource = ds.Tables[0];
            gvRcvfile.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvRcvfile.HeaderRow.Font.Bold = true;
                gvRcvfile.HeaderRow.Cells[1].Text = "LEAD NO";
                gvRcvfile.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvRcvfile.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvRcvfile.HeaderRow.Cells[4].Text = "PD DATE";
                gvRcvfile.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvRcvfile.HeaderRow.Cells[6].Text = "BRANCH NAME";

                gvRcvfile.HeaderRow.Cells[1].Wrap = false;
                gvRcvfile.HeaderRow.Cells[2].Wrap = false;
                gvRcvfile.HeaderRow.Cells[3].Wrap = false;
                gvRcvfile.HeaderRow.Cells[4].Wrap = false;
                gvRcvfile.HeaderRow.Cells[5].Wrap = false;
                gvRcvfile.HeaderRow.Cells[6].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(strcon);
        //con.Open();
        //foreach (GridViewRow grow in gvRcvfile.Rows)
        //{
        //    RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
        //    int index = grow.RowIndex;
        //    if (chkStat.Checked)
        //    {
        //        leadno = gvRcvfile.Rows[index].Cells[1].Text;
        //        appname = gvRcvfile.Rows[index].Cells[3].Text;
        //        pddt = gvRcvfile.Rows[index].Cells[4].Text;
        //        lnamt = gvRcvfile.Rows[index].Cells[5].Text;
        //    }
        //}
        //lbLeadno.Visible = true;
        //lbAppname.Visible = true;
        //lbPDdate.Visible = true;
        //lbLoanamt.Visible = true;
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;


        //lbLeadno.Text = leadno;
        //lbAppname.Text = appname;
        //lbPDdate.Text = pddt;
        //lbLoanamt.Text = lnamt;
        //con.Close();
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME,BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Enabled = false;
    }
}