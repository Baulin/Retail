﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Text.RegularExpressions;
using Tracker;

public partial class Master_Employee : System.Web.UI.Page
{
    int emptypeid;
    int brid;
    int acctype;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    Regex Rx = new Regex("^[A-Za-z0-9/-_]");
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {

                bindArea();
                BindEmpType();
                bind();
                //dvBR.Visible = true;
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmddd = new SqlCommand("select DISTINCT ET_DESC from MR_EMP_TYPE", con);
                SqlDataAdapter da1 = new SqlDataAdapter(cmddd);
                DataSet ds1 = new DataSet();
                da1.Fill(ds1);
                if (Session["TYPEID"].ToString() != "2")
                {
                    SqlCommand cmddd1 = new SqlCommand("select DISTINCT BR_NAME from MR_BRANCH", con);
                    SqlDataAdapter da2 = new SqlDataAdapter(cmddd1);
                    DataSet ds2 = new DataSet();
                    da2.Fill(ds2);

                    ddlBrname.DataSource = ds2;
                    ddlBrname.DataTextField = "BR_NAME";
                    ddlBrname.DataValueField = "BR_NAME";
                    ddlBrname.DataBind();
                    ddlBrname.Items.Insert(0, new ListItem("--Select--", "0"));



                }
                else
                {
                    ddlBrname.SelectedItem.Text = "" + Session["UNITNAME"].ToString() + "";
                    ddlBrname.Enabled = false;
                    ddlAccesstype.Text = "Branch";
                    ddlAccesstype.Enabled = false;

                }
                ddlEmptype.DataSource = ds1;
                ddlEmptype.DataTextField = "ET_DESC";
                ddlEmptype.DataValueField = "ET_DESC";
                ddlEmptype.DataBind();
                ddlEmptype.Items.Insert(0, new ListItem("--Select--", "0"));

                ddlempcontype.SelectedValue = "Employee";
                con.Close();
                SetEmploymentType();
                bind_BR();



            }
            Status_Access();
        }
        else
        {
            Response.Redirect("expire.aspx");
        }
    }
    public void Status_Access()
    {
        try
        {
            if (Convert.ToString(Session["TYPEID"]) == "38")
            {
                ddlstempstatus.Enabled = true;
            }
            else
            {
                ddlstempstatus.Enabled = false;
            }
        }
        catch (Exception ex)
        {

            ErrorLog.WriteError(ex);

        }
    }
    public void bind_BR()
    {
        try
        {

            DataSet ds_obj = new DataSet();
            ds_obj = clscommon.GetBranch();
            chkBranch.DataSource = ds_obj;
            chkBranch.DataTextField = "BR_NAME";
            chkBranch.DataValueField = "BR_ID";
            chkBranch.DataBind();
        }
        catch (Exception ex)
        {

            ErrorLog.WriteError(ex);

        }
        finally
        {

        }
    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlArea.SelectedValue = Session["AREA_ID"].ToString();
        }
        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlSearchBranch.DataSource = dsrsn;
        ddlSearchBranch.DataTextField = "BR_NAME";
        ddlSearchBranch.DataValueField = "BR_ID";
        ddlSearchBranch.DataBind();
        ddlSearchBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlSearchBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlSearchBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    public void BindEmpType()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("select DISTINCT ET_DESC from MR_EMP_TYPE", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmddd);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlSearchEmpType.DataSource = dsrsn;
        ddlSearchEmpType.DataTextField = "ET_DESC";
        ddlSearchEmpType.DataValueField = "ET_DESC";
        ddlSearchEmpType.DataBind();
        ddlSearchEmpType.Items.Insert(0, new ListItem("--Select--", "0"));
        //if (Session["USR_ACS"].ToString() == "7")
        //{
        //    ddlSearchEmpType.SelectedValue = Session["BRANCHID"].ToString();
        //    ddlSearchEmpType.Enabled = false;
        //    ddlArea.Enabled = false;
        //}
    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlSearchBranch.DataSource = dsrsn;
        ddlSearchBranch.DataTextField = "BR_NAME";
        ddlSearchBranch.DataValueField = "BR_ID";
        ddlSearchBranch.DataBind();
        ddlSearchBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlSearchBranch.Enabled = true;


    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        if (Session["TYPEID"].ToString() == "2")
        {
            /*SqlCommand cmd = new SqlCommand("SELECT EMP_ID, EMP_CODE 'EMP. CODE',EMP_NAME 'EMP. NAME',ET_DESC 'EMP. TYPE',BR_NAME 'BR. NAME',EMP_PHNO 'CONTACT NO.', EMP_EMAILID, EMP_STAT,CASE WHEN EMP_STAT='1' THEN 'WORKING' ELSE 'RESIGNED' END  AS 'EMPSTATUS',EMP_TYPE [TYPE] FROM MR_EMPLOYEE A JOIN MR_EMP_TYPE B ON A.EMP_ET_ID=B.ET_ID JOIN MR_BRANCH C ON A.EMP_BR_ID=C.BR_ID where EMP_BR_ID='" + Session["BRANCHID"] + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            gvEmp.DataSource = ds;
            gvEmp.DataBind();*/
            SqlCommand cmd = new SqlCommand("RTS_SP_BIND_MR_EMPLOYEE", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@BR_ID", Session["BRANCHID"].ToString());
            if (txtSearchEmpCode.Text != "")
            {
                cmd.Parameters.AddWithValue("@EMP_CODE", txtSearchEmpCode.Text);
            }
            if (ddlArea.SelectedValue != "0")
            {
                cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text.ToString());
            }
            if (ddlSearchBranch.SelectedValue != "0")
            {
                cmd.Parameters.AddWithValue("@BR_NAME", ddlSearchBranch.SelectedItem.Text.ToString());
            }
            if (ddlSearchEmpType.SelectedValue != "0")
            {
                cmd.Parameters.AddWithValue("@EMP_TYPE", ddlSearchEmpType.SelectedItem.Text.ToString());
            }

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            // ds = clscommon.Bind_ShortlistedBC_Application("Shortlisted", Convert.ToInt32(ddlBranch.SelectedValue));
            gvEmp.DataSource = ds;
            gvEmp.DataBind();

            if (gvEmp.Rows.Count > 0)
            {
                gvEmp.UseAccessibleHeader = true;
                gvEmp.HeaderRow.TableSection = TableRowSection.TableHeader;
                gvEmp.HeaderRow.Font.Bold = true;
                //gvEmp.HeaderRow.Cells[0].Text = "EMP. CODE";
                //gvEmp.HeaderRow.Cells[1].Text = "EMP. NAME";
                //gvEmp.HeaderRow.Cells[2].Text = "EMP. TYPE";
                //gvEmp.HeaderRow.Cells[3].Text = "BR. NAME";
                //gvEmp.HeaderRow.Cells[4].Text = "CONTACT NO.";


                gvEmp.HeaderRow.Cells[0].Wrap = false;
                gvEmp.HeaderRow.Cells[1].Wrap = false;
                gvEmp.HeaderRow.Cells[2].Wrap = false;
                gvEmp.HeaderRow.Cells[3].Wrap = false;
                gvEmp.HeaderRow.Cells[4].Wrap = false;
            }
        }
        else
        {
            /*  SqlCommand cmd = new SqlCommand("SELECT EMP_ID, EMP_CODE 'EMP. CODE',EMP_NAME 'EMP. NAME',ET_DESC 'EMP. TYPE',BR_NAME 'BR. NAME',EMP_PHNO 'CONTACT NO.', EMP_EMAILID, EMP_STAT,CASE WHEN EMP_STAT='1' THEN 'WORKING' ELSE 'RESIGNED' END  AS 'EMPSTATUS', EMP_TYPE [TYPE]  FROM MR_EMPLOYEE A JOIN MR_EMP_TYPE B ON A.EMP_ET_ID=B.ET_ID JOIN MR_BRANCH C ON A.EMP_BR_ID=C.BR_ID", con);
              SqlDataAdapter da = new SqlDataAdapter(cmd);
              DataSet ds = new DataSet();
              da.Fill(ds);
              con.Close();
              gvEmp.DataSource = ds;
              gvEmp.DataBind();
              */
            SqlCommand cmd = new SqlCommand("RTS_SP_BIND_MR_EMPLOYEE", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (txtSearchEmpCode.Text != "")
            {
                cmd.Parameters.AddWithValue("@EMP_CODE", txtSearchEmpCode.Text);
            }
            if (ddlArea.SelectedValue != "0")
            {
                cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text.ToString());
            }
            if (ddlSearchBranch.SelectedValue != "0")
            {
                cmd.Parameters.AddWithValue("@BR_NAME", ddlSearchBranch.SelectedItem.Text.ToString());
            }
            if (ddlSearchEmpType.SelectedValue != "0")
            {
                cmd.Parameters.AddWithValue("@EMP_TYPE", ddlSearchEmpType.SelectedItem.Text.ToString());
            }
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            // ds = clscommon.Bind_ShortlistedBC_Application("Shortlisted", Convert.ToInt32(ddlBranch.SelectedValue));
            gvEmp.DataSource = ds;
            gvEmp.DataBind();

            if (gvEmp.Rows.Count > 0)
            {
                gvEmp.UseAccessibleHeader = true;
                gvEmp.HeaderRow.TableSection = TableRowSection.TableHeader;

                gvEmp.HeaderRow.Font.Bold = true;
                //gvEmp.HeaderRow.Cells[0].Text = "EMP. CODE";
                //gvEmp.HeaderRow.Cells[1].Text = "EMP. NAME";
                //gvEmp.HeaderRow.Cells[2].Text = "EMP. TYPE";
                //gvEmp.HeaderRow.Cells[3].Text = "BR. NAME";
                //gvEmp.HeaderRow.Cells[4].Text = "CONTACT NO.";

                gvEmp.HeaderRow.Cells[0].Wrap = false;
                gvEmp.HeaderRow.Cells[1].Wrap = false;
                gvEmp.HeaderRow.Cells[2].Wrap = false;
                gvEmp.HeaderRow.Cells[3].Wrap = false;
                gvEmp.HeaderRow.Cells[4].Wrap = false;
            }
        }
        // ScriptManager.RegisterStartupScript(Page, this.GetType(), "Key", "<script>MakeStaticHeader('" + gvEmp.ClientID + "', 250, 1000 , 27 ,true); </script>", false);
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            bind();
            //gvEmp.DataBind();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        try
        {
            txtSearchEmpCode.Text = "";
            ddlArea.SelectedValue = "0";
            ddlSearchBranch.SelectedValue = "0";
            ddlSearchEmpType.SelectedValue = "0";
            bind();
            gvEmp.DataBind();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            //e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            //e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            //e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            //e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            //e.Row.Attributes.Add("onclick", string.Format("ChangeRowColor('{0}','{1}');", e.Row.ClientID, e.Row.RowIndex));

            // e.Row.Attributes.Add("onmouseup", string.Format("SetScrollPos();",true));
            // e.Row.Attributes["onclick"] = ClientScript.GetPostBackClientHyperlink(this.gvEmp, "Select$" + e.Row.RowIndex);
            //if (e.Row.RowIndex == 0)
            //    e.Row.Style.Add("height", "50px");
            //e.Row.VerticalAlign = VerticalAlign.Bottom;

        }
    }
    //protected void gvUserInfo_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    int index = Convert.ToInt32(e.CommandArgument);
    //    //BindData();
    //   // gvEmp.Rows[index].Attributes.Add("style", "background-color:yellow");
    //   // gvEmp.Rows[index].Attributes.Add("class", "mycustomclass");
    //   // gvEmp.Rows[e.Row.RowIndex].Selected = true; 
    //    gvEmp.Focus();
    //}
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);

        if (Rx.IsMatch(txtEmpcode.Text))
        {

            if (btnSubmit.Text == "Submit")
            {
                try
                {
                    con.Open();
                    SqlCommand stcmd = new SqlCommand("select ET_ID from MR_EMP_TYPE where ET_DESC='" + ddlEmptype.SelectedValue.ToString() + "'", con);
                    SqlDataAdapter stda = new SqlDataAdapter(stcmd);
                    DataSet stds = new DataSet();
                    stda.Fill(stds);

                    emptypeid = Convert.ToInt32(stds.Tables[0].Rows[0]["ET_ID"]);

                    SqlCommand brcmd = new SqlCommand("select BR_ID from MR_BRANCH where BR_NAME='" + ddlBrname.SelectedValue.ToString() + "'", con);
                    SqlDataAdapter brda = new SqlDataAdapter(brcmd);
                    DataSet brds = new DataSet();
                    brda.Fill(brds);

                    brid = Convert.ToInt32(brds.Tables[0].Rows[0]["BR_ID"]);

                    SqlCommand cmdid1 = new SqlCommand("select * from MR_EMPLOYEE where EMP_CODE='" + txtEmpcode.Text + "'", con);
                    SqlDataAdapter daid1 = new SqlDataAdapter(cmdid1);
                    DataSet dsid1 = new DataSet();
                    daid1.Fill(dsid1);
                    if (dsid1.Tables[0].Rows.Count == 0)
                    {
                        if (txtEmpcode.Text.Contains("ALC") == false)
                        {
                            //SqlCommand insertcmd = new SqlCommand("insert into MR_EMPLOYEE (EMP_CODE,EMP_NAME,EMP_ET_ID,EMP_BR_ID,EMP_PHNO,EMP_EMAILID,EMP_CBY,EMP_CDATE) values ('" + txtEmpcode.Text + "','" + txtEmpname.Text + "','" + ddlAccesstype.SelectedIndex + "','" + emptypeid + "','" + brid + "','" + txtContactno.Text + "','" + txtEmailid.Text + "','" + Session["ID"].ToString() + "',getdate(),'" + Session["ID"].ToString() + "',getdate())", con);

                            string strBranchIDS = "";
                            if (ddlempcontype.SelectedValue != "Connector" && ddlempcontype.SelectedValue != "DSA")
                            {
                                SqlCommand insertcmd = new SqlCommand("insert into MR_EMPLOYEE (EMP_CODE,EMP_NAME,EMP_ET_ID,EMP_BR_ID,EMP_PHNO,EMP_EMAILID,EMP_CBY,EMP_CDATE,EMP_STAT,EMP_TYPE) values ('" + txtEmpcode.Text.ToUpper() + "','" + txtEmpname.Text.ToUpper() + "','" + emptypeid + "','" + brid + "','" + txtContactno.Text + "','" + txtEmailid.Text + "','" + Session["ID"].ToString() + "',getdate(),'" + ddlstempstatus.SelectedValue.ToString() + "','" + ddlempcontype.SelectedValue + "')", con);
                                insertcmd.ExecuteNonQuery();
                            }
                            else
                            {
                                //string dsa_br_id = clscommon.Get_DSA_Branch_ID(txtEmpcode.Text);
                                /*strBranchIDS = "";

                                for (int n = 0; n < chkBranch.Items.Count; n++)
                                {

                                    if (chkBranch.Items[n].Selected)
                                    {
                                        if (strBranchIDS == "")
                                        {
                                            strBranchIDS = chkBranch.Items[n].Value;
                                        }
                                        else
                                        {
                                            strBranchIDS = strBranchIDS + "," + chkBranch.Items[n].Value;
                                        }
                                    }

                                }*/
                                strBranchIDS = ",";

                                foreach (ListItem li in chkBranch.Items)
                                {
                                    if (li.Selected)
                                    {
                                        strBranchIDS = strBranchIDS + li.Value + ",";

                                    }
                                }

                                SqlCommand insertcmd = new SqlCommand("insert into MR_EMPLOYEE (EMP_CODE,EMP_NAME,EMP_ET_ID,EMP_BR_ID,EMP_BR_ACS,EMP_PHNO,EMP_EMAILID,EMP_CBY,EMP_CDATE,EMP_STAT,EMP_TYPE) values ('" + txtEmpcode.Text.ToUpper() + "','" + txtEmpname.Text.ToUpper() + "','" + emptypeid + "','" + brid + "','" + strBranchIDS + "','" + txtContactno.Text + "','" + txtEmailid.Text + "','" + Session["ID"].ToString() + "',getdate(),'" + ddlstempstatus.SelectedValue.ToString() + "','" + ddlempcontype.SelectedValue + "')", con);
                                insertcmd.ExecuteNonQuery();
                            }

                            bind();
                            txtEmpcode.Text = "";
                            txtEmpname.Text = "";
                            txtContactno.Text = "";
                            txtEmailid.Text = "";
                            ddlAccesstype.Text = "--Select--";
                            ddlEmptype.SelectedIndex = 0;
                            ddlBrname.SelectedIndex = 0;
                            ddlstempstatus.SelectedValue = "1";
                            // ddlBCList.SelectedValue = "0";
                            ddlBCList.SelectedIndex = 0;

                            SetEmploymentType();

                            uscMsgBox1.AddMessage("Employee Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

                            txtSearchEmpCode.Text = "";
                            ddlArea.SelectedValue = "0";
                            ddlSearchBranch.SelectedValue = "0";
                            ddlSearchEmpType.SelectedValue = "0";
                            bind();
                            bind_BR();
                            chkAll.Checked = false;

                        }
                        else
                        {
                            uscMsgBox1.AddMessage("You cannot able to submit the ALC Connector Code here. Please select Connector Selection", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                        }
                    }
                    else
                    {
                        bind();
                        txtEmpcode.Text = "";
                        txtEmpname.Text = "";
                        txtContactno.Text = "";
                        txtEmailid.Text = "";
                        ddlAccesstype.Text = "--Select--";
                        SetEmploymentType();
                        uscMsgBox1.AddMessage("Employee Already Exsist", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

                        txtSearchEmpCode.Text = "";
                        ddlArea.SelectedValue = "0";
                        ddlSearchBranch.SelectedValue = "0";
                        ddlSearchEmpType.SelectedValue = "0";
                        bind();
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
                finally
                {
                    con.Close();
                }
            }
            else if (btnSubmit.Text == "Update")
            {

                try
                {
                    con.Open();

                    SqlCommand stcmd = new SqlCommand("select ET_ID from MR_EMP_TYPE where ET_DESC='" + ddlEmptype.SelectedValue.ToString() + "'", con);
                    SqlDataAdapter stda = new SqlDataAdapter(stcmd);
                    DataSet stds = new DataSet();
                    stda.Fill(stds);

                    emptypeid = Convert.ToInt32(stds.Tables[0].Rows[0]["ET_ID"]);

                    SqlCommand brcmd = new SqlCommand("select BR_ID from MR_BRANCH where BR_NAME='" + ddlBrname.SelectedValue.ToString() + "'", con);
                    SqlDataAdapter brda = new SqlDataAdapter(brcmd);
                    DataSet brds = new DataSet();
                    brda.Fill(brds);

                    brid = Convert.ToInt32(brds.Tables[0].Rows[0]["BR_ID"]);

                    if (ddlempcontype.SelectedValue != "Connector" && ddlempcontype.SelectedValue != "DSA")
                    {

                        SqlCommand insertcmd = new SqlCommand("Update MR_EMPLOYEE set EMP_NAME='" + txtEmpname.Text.ToUpper() + "'," +
                                                      " EMP_ET_ID='" + emptypeid + "'," +
                                                      " EMP_BR_ID='" + brid + "'," +
                                                      " EMP_PHNO='" + txtContactno.Text + "'," +
                                                      " EMP_EMAILID='" + txtEmailid.Text + "'," +
                                                      " EMP_MBY= '" + Session["ID"].ToString() + "'," +
                                                      " EMP_MDATE=getdate()," +
                                                      " EMP_STAT='" + ddlstempstatus.SelectedValue + "'," +
                                                      " EMP_TYPE='" + ddlempcontype.SelectedValue + "'" +
                                                      " where EMP_CODE='" + txtEmpcode.Text + "'", con);
                        insertcmd.ExecuteNonQuery();

                        /* Bala changes 05/03/2018 based on user access team requirement
                         * insertcmd = new SqlCommand("Update MR_USER set USR_STAT='" + ddlstempstatus.SelectedValue + "', USR_MBY='" + Session["ID"].ToString() + "',USR_MDATE=GETDATE()  WHERE USR_EMP_ID =" + Session["EMPID"].ToString() + "", con);
                         insertcmd.ExecuteNonQuery();*/
                    }
                    else
                    {

                        string strBranchIDS = ",";

                        foreach (ListItem li in chkBranch.Items)
                        {
                            if (li.Selected)
                            {
                                strBranchIDS = strBranchIDS + li.Value + ",";

                            }
                        }
                        SqlCommand insertcmd = new SqlCommand("Update MR_EMPLOYEE set EMP_NAME='" + txtEmpname.Text.ToUpper() + "'," +
                                                     " EMP_ET_ID='" + emptypeid + "'," +
                                                     " EMP_BR_ID='" + brid + "'," +
                                                      " EMP_BR_ACS='" + strBranchIDS + "'," +
                                                     " EMP_PHNO='" + txtContactno.Text + "'," +
                                                     " EMP_EMAILID='" + txtEmailid.Text + "'," +
                                                     " EMP_MBY= '" + Session["ID"].ToString() + "'," +
                                                     " EMP_MDATE=getdate()," +
                                                     " EMP_STAT='" + ddlstempstatus.SelectedValue + "'," +
                                                     " EMP_TYPE='" + ddlempcontype.SelectedValue + "'" +
                                                     " where EMP_CODE='" + txtEmpcode.Text + "'", con);
                        insertcmd.ExecuteNonQuery();

                        /*Bala changes 05/03/2018 based on user access team requirement
                         * insertcmd = new SqlCommand("Update MR_USER set USR_STAT='" + ddlstempstatus.SelectedValue + "', USR_MBY='" + Session["ID"].ToString() + "',USR_MDATE=GETDATE()  WHERE USR_EMP_ID =" + Session["EMPID"].ToString() + "", con);
                        insertcmd.ExecuteNonQuery();*/
                    }



                    div_posemp.Value = "0";
                    bind();
                    txtEmpcode.Text = "";
                    txtEmpname.Text = "";
                    txtContactno.Text = "";
                    txtEmailid.Text = "";
                    ddlAccesstype.Text = "--Select--";
                    ddlEmptype.SelectedIndex = 0;
                    ddlBrname.SelectedIndex = 0;
                    ddlempcontype.SelectedIndex = 0;
                    txtEmpcode.Enabled = true;
                    btnSubmit.Text = "Submit";
                    ddlstempstatus.SelectedValue = "1";
                    SetEmploymentType();
                    bind_BR();
                    chkAll.Checked = false;
                    uscMsgBox1.AddMessage("Employee Updated Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    txtSearchEmpCode.Text = "";
                    ddlArea.SelectedValue = "0";
                    ddlSearchBranch.SelectedValue = "0";
                    ddlSearchEmpType.SelectedValue = "0";
                    bind();
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }
                finally
                {
                    con.Close();
                }
            }
        }
        else
        {
            uscMsgBox1.AddMessage("Please enter the alphabets, numbers and symbols like - _ /", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            return;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_Employee.aspx");
        //pnlBranch.Visible = false;
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow grow in gvEmp.Rows)
            {
                RadioButton chkUserID = (RadioButton)grow.FindControl("rb_select");
                if (chkUserID.Checked)
                {
                    txtEmpcode.Text = grow.Cells[1].Text;
                    txtEmpcode.Enabled = false;
                    txtEmpname.Text = grow.Cells[2].Text;

                    Label lblmail = (Label)grow.FindControl("lblempmail");
                    Label lblstat = (Label)grow.FindControl("lblempstat");
                    Label lblid = (Label)grow.FindControl("lblempid");
                    Label lbl_emp_type = (Label)grow.FindControl("lbl_emp_type");
                    Label lbl_emp_br_acs = (Label)grow.FindControl("lbl_emp_br_acs");
                    bind_BR();
                    ddlEmptype.SelectedValue = grow.Cells[3].Text;
                    ddlBrname.SelectedValue = grow.Cells[5].Text;
                    ddlempcontype.SelectedValue = lbl_emp_type.Text;

                    ddlstempstatus.SelectedValue = lblstat.Text;

                    if (grow.Cells[6].Text == "&nbsp;")
                    {
                        txtContactno.Text = "";
                    }
                    else
                    {
                        txtContactno.Text = grow.Cells[6].Text;
                    }

                    if (lblmail.Text == "&nbsp;")
                    {
                        txtEmailid.Text = "";
                    }
                    else
                    {
                        txtEmailid.Text = lblmail.Text;
                    }
                    btnSubmit.Text = "Update";
                    Session["EMPID"] = lblid.Text;

                    SetEmploymentType();
                    if (lbl_emp_br_acs.Text != "" && lbl_emp_br_acs.Text != null)
                    {
                        //trReference.Visible = true;

                        //ddlReference.SelectedValue = Convert.ToInt32(qrypromotion.ReferenceId).ToString();

                        string strReferenceID = lbl_emp_br_acs.Text;
                        string[] strRefer = strReferenceID.Split(new char[] { ',' });

                        for (int i = 0; i < strRefer.Length - 1; i++)
                        {
                            ListItem li = chkBranch.Items.FindByValue(strRefer[i]);
                            if (li != null)
                            {
                                li.Selected = true;
                                //li.Attributes.CssStyle
                                li.Attributes.Add("Style", "background-color: #82E190;");
                            }

                        }

                    }
                    if (ddlempcontype.SelectedValue != "Connector" && ddlempcontype.SelectedValue != "DSA")
                    {
                        dvMultiBranch.Visible = false;
                        //pnlBranch.Visible = false;
                    }
                    else
                    {
                        dvMultiBranch.Visible = true;
                        //pnlBranch.Visible = true;

                    }
                    break;
                }
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void Employeementtype(object sender, EventArgs e)
    {

        switch (ddlempcontype.SelectedItem.Value)
        {

            case "Connector":
                lbl_emp_connectorname.Text = "Connector Name";
                lbl_emp_conCode.Text = "Connector Code";
                lbl_emptypedesign.Text = "Connector Type/Design";
                txtEmpcode.MaxLength = 10;
                //txtEmpcode.Enabled = false;
                trBCSelection.Visible = true;
                //txtEmpname.Enabled = false;
                // reqddlBCList.Enabled = true;
                lblName.Text = "Connector Selection";
                //dvBR.Visible = false;
                dvMultiBranch.Visible = true;
                bind_BR();
                break;
            case "Employee":
                lbl_emp_connectorname.Text = "Emp. Name";
                lbl_emp_conCode.Text = "Emp. Code";
                lbl_emptypedesign.Text = "Emp.Type/Design";
                txtEmpcode.MaxLength = 5;
                txtEmpcode.Enabled = true;
                trBCSelection.Visible = false;
                txtEmpname.Enabled = true;
                // reqddlBCList.Enabled = false;
                //dvBR.Visible = true;
                dvMultiBranch.Visible = false;
                break;

            case "Branch":
                lbl_emp_connectorname.Text = "Branch Name";
                lbl_emp_conCode.Text = "Branch Code";
                lbl_emptypedesign.Text = "Branch Type/Design";
                txtEmpcode.MaxLength = 9;
                txtContactno.MaxLength = 10;
                txtEmpcode.Enabled = true;
                trBCSelection.Visible = false;
                txtEmpname.Enabled = true;
                //  reqddlBCList.Enabled = false;
                //dvBR.Visible = true;
                dvMultiBranch.Visible = false;
                break;
            case "DSA":
                lbl_emp_connectorname.Text = "DSA Name";
                lbl_emp_conCode.Text = "DSA Code";
                lbl_emptypedesign.Text = "DSA Type/Design";
                txtEmpcode.MaxLength = 15;
                txtEmpcode.Enabled = true;
                trBCSelection.Visible = true;
                txtEmpname.Enabled = true;
                // reqddlBCList.Enabled = false;
                lblName.Text = "DSA Selection";
                //dvBR.Visible = false;
                dvMultiBranch.Visible = true;
                bind_BR();
                break;
            default:
                lbl_emp_connectorname.Text = "Emp. Name";
                lbl_emp_conCode.Text = "Emp. Code";
                lbl_emptypedesign.Text = "Emp.Type/Design";
                txtEmpcode.MaxLength = 5;
                txtEmpcode.Enabled = true;
                trBCSelection.Visible = false;
                txtEmpname.Enabled = true;
                //dvBR.Visible = true;
                dvMultiBranch.Visible = false;
                //  reqddlBCList.Enabled = false;
                break;
        }


        clear();
    }
    protected void MyCustomValidator_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if ((txtEmailid.Text == "") && (ddlempcontype.SelectedItem.Text == "ThirdParty"))
        {
            args.IsValid = false;
        }
        else
        {
            args.IsValid = true;
        }
        //    args.IsValid = true;
        //else
        //    args.IsValid = false;
    }
    private void clear()
    {
        if (ddlAccesstype.Items.Count > 0)
            ddlAccesstype.SelectedIndex = 0;
        if (ddlBrname.Items.Count > 0)
            ddlBrname.SelectedIndex = 0;
        if (ddlstempstatus.Items.Count > 0)
            ddlstempstatus.SelectedIndex = 0;
        if (ddlEmptype.Items.Count > 0)
            ddlEmptype.SelectedIndex = 0;
        if (ddlBCList.Items.Count > 0)
            ddlBCList.SelectedIndex = 0;
        txtEmpname.Text = "";
        txtEmpcode.Text = "";
        txtContactno.Text = "";
        txtEmailid.Text = "";
    }
    protected void SetEmploymentType()
    {
        if (Session["TYPEID"].ToString() == "2")
        {

            ddlempcontype.Enabled = false;
        }
        else
        {

            ddlempcontype.Enabled = true;
        }
    }

    protected void gvEmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        //gvEmp.Rows[gvEmp.SelectedIndex].BackColor = Color.Red;
    }
    protected void ddlBrname_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlempcontype.SelectedItem.Text == "Connector")
        {
            GetBCList();
            bind_BR();
        }

        else if (ddlempcontype.SelectedItem.Text == "DSA")
        {
            DSAList();
            bind_BR();
        }
    }
    protected void GetBCList()
    {
        try
        {
            if (btnSubmit.Text != "Update")
            {
                txtEmpcode.Text = "";
                txtEmpname.Text = "";
                txtEmpcode.Enabled = true;
                txtEmpname.Enabled = true;

            }
            DataSet dsBC = new DataSet();
            dsBC = clscommon.Bind_Business_Connector(ddlBrname.SelectedValue);
            ddlBCList.DataSource = dsBC;
            ddlBCList.DataTextField = "BCA_CODE";
            ddlBCList.DataValueField = "BCA_ID";
            ddlBCList.DataBind();
            ddlBCList.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlBCList_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlBCList.SelectedValue != "0")
        {
            txtEmpcode.Enabled = false;
            //trBCSelection.Visible = true;
            txtEmpname.Enabled = false;
            //  reqddlBCList.Enabled = true;
            string[] result = ddlBCList.SelectedItem.Text.Split('|');
            //txtEmpcode.Text = ddlBCList.SelectedItem.Text;
            txtEmpcode.Text = result[0].Trim();
            txtEmpname.Text = result[1].Trim();

            // DataSet dsBC = new DataSet();
        }
        else
        {
            txtEmpcode.Text = "";
            txtEmpname.Text = "";
            txtEmpcode.Enabled = true;
            txtEmpname.Enabled = true;

        }
    }
    protected void txtEmpcode_TextChanged(object sender, EventArgs e)
    {
        if (ddlempcontype.SelectedItem.Value == "Connector")
        {
            if (txtEmpcode.Text.Contains("ALC") == true)
            {
                uscMsgBox1.AddMessage("You cannot able to enter the ALC Connector here. Please select Connector Selection", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
        }
    }
    public static void MakeAccessible(GridView grid)
    {
        if (grid.Rows.Count <= 0) return;
        grid.UseAccessibleHeader = true;
        grid.HeaderRow.TableSection = TableRowSection.TableHeader;
        if (grid.ShowFooter)
            grid.FooterRow.TableSection = TableRowSection.TableFooter;
    }
    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);

        MakeAccessible(gvEmp);
    }
    protected void gvManageUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvEmp.PageIndex = e.NewPageIndex;
            bind();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void gvEmp_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        //gvEmp.PageIndex = e.NewPageIndex;

        //gvEmp.DataBind();
        gvEmp.PageIndex = e.NewPageIndex;
        bind();
    }

    protected void DSAList()
    {
        try
        {
            if (btnSubmit.Text != "Update")
            {
                txtEmpcode.Text = "";
                txtEmpname.Text = "";
                txtEmpcode.Enabled = true;
                txtEmpname.Enabled = true;

            }
            DataSet dsDSA = new DataSet();
            dsDSA = clscommon.Bind_DSA(ddlBrname.SelectedValue);
            ddlBCList.DataSource = dsDSA;
            ddlBCList.DataTextField = "DSA_CODE";
            ddlBCList.DataValueField = "DSA_ID";
            ddlBCList.DataBind();
            ddlBCList.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}
