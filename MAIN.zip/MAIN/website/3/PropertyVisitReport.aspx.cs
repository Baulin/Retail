﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using System.Net.Mail;
public partial class PropertyVisitReport : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    public static DataTable dtsBounce = null;
    public static int bTabIndex = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnPrint);
    }
    protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
    {
        MultiView1.ActiveViewIndex = Int32.Parse(e.Item.Value);
        int i = 0;
        txtLoanNo.Text = "";
        Clear();
        //Make the selected menu item reflect the correct imageurl
        for (i = 0; i <= Menu1.Items.Count - 1; i++)
        {
            if (i.ToString() == e.Item.Value)
            {
                if (i == 0)
                {
                    bTabIndex = 0;
                    Menu1.Items[i].ImageUrl = "~/Images/JPG/selectedtab1.jpg";
                }
                else
                {
                    bTabIndex = 1;
                    Menu1.Items[i].ImageUrl = "~/Images/JPG/selectedtab2.jpg";
                }
            }
            else
            {
                if (i == 0)
                {
                    Menu1.Items[i].ImageUrl = "~/Images/JPG/unselectedtab1.jpg";
                }
                else
                {
                    Menu1.Items[i].ImageUrl = "~/Images/JPG/unselectedtab2.jpg";
                }
            }
        }
    }

    public void fetchLeadDetails(SqlConnection con)
    {
        SqlCommand cmddd = new SqlCommand("select ld_no,BR_NAME,AR_NAME from lsd_lead LD Left Join Mr_Branch MB on MB.BR_ID = LD.LD_BR_ID  LEFT JOIN MR_AREA MA ON MA.AR_ID=MB.BR_AR_ID where LD_LOAN_NO ='" + txtLoanNo.Text + "' ", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            if (bTabIndex == 0)
            {
                lblArea.Text = dsdd.Tables[0].Rows[0]["AR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AR_NAME"].ToString() : "";
                lblBranch.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                string strLeadNO = dsdd.Tables[0].Rows[0]["ld_no"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ld_no"].ToString() : "";
                lblProduct.Text = "MFHF - " + strLeadNO;
            }
            else if (bTabIndex == 1)
            {
                lblArea1.Text = dsdd.Tables[0].Rows[0]["AR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AR_NAME"].ToString() : "";
                lblBranch1.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                string strLeadNO1 = dsdd.Tables[0].Rows[0]["ld_no"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ld_no"].ToString() : "";
                lblProduct1.Text = "MFHF - " + strLeadNO1;
            }
        }
    }
    protected void btnGenerate_Click(object sender, EventArgs e)
    {
        Clear();
        //if (Session["ID"] != null)
        //{
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        fetchLeadDetails(con);
        SqlCommand cmddd = new SqlCommand("RTS_PRPRTY_PEMI_RPT", con);
        cmddd.Parameters.AddWithValue("@LNNO", txtLoanNo.Text);
        if (bTabIndex == 0)
        {
            cmddd.Parameters.AddWithValue("@LNSTAT", "E");
        }
        else if (bTabIndex == 1)
        {
            cmddd.Parameters.AddWithValue("@LNSTAT", "L");
        }

        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            if (bTabIndex == 0)
            {
                lblAppName.Text = dsdd.Tables[0].Rows[0]["Applicant_Name"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Applicant_Name"].ToString() : "";
                lblLoanAgrrement.Text = dsdd.Tables[0].Rows[0]["Lnno"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Lnno"].ToString() : "";
                lblCOntactNo.Text = dsdd.Tables[0].Rows[0]["Cont_no"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Cont_no"].ToString() : "";
                lblSancAmt.Text = dsdd.Tables[0].Rows[0]["Sanc_Amt"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Sanc_Amt"].ToString() : "";
                lblDOF.Text = dsdd.Tables[0].Rows[0]["First_Payment_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["First_Payment_Date"].ToString() : "";
                lblSancDate.Text = dsdd.Tables[0].Rows[0]["Sanc_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Sanc_Date"].ToString() : "";
                lblLOF.Text = dsdd.Tables[0].Rows[0]["Last_Payment_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Last_Payment_Date"].ToString() : "";
                lblNOFirstDisb.Text = dsdd.Tables[0].Rows[0]["No_OF_days_1st_disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["No_OF_days_1st_disb"].ToString() : "";
                lblNOLastDisb.Text = dsdd.Tables[0].Rows[0]["No_OF_days_last_disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["No_OF_days_last_disb"].ToString() : "";
                lblLoanAMtDisb.Text = dsdd.Tables[0].Rows[0]["Total_Disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Total_Disb"].ToString() : "";
                lblPropAddrs.Text = dsdd.Tables[0].Rows[0]["Property address"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property address"].ToString() : "";
                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property area"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property area"].ToString() : "";
                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property city"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property city"].ToString() : "";
                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property pincode"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property pincode"].ToString() : "";

                if (dsdd.Tables[1] != null && dsdd.Tables[1].Rows.Count > 0)
                {
                    int nCount = dsdd.Tables[1].Rows.Count;
                    if (nCount == 5)
                    {
                        lblDisbDate5.Text = dsdd.Tables[1].Rows[4][0] != DBNull.Value ? dsdd.Tables[1].Rows[4][0].ToString() : "";
                        lblDisbAmt5.Text = dsdd.Tables[1].Rows[4][1] != DBNull.Value ? dsdd.Tables[1].Rows[4][1].ToString() : "";

                    }
                    if (nCount >= 4)
                    {
                        lblDisbDate4.Text = dsdd.Tables[1].Rows[3][0] != DBNull.Value ? dsdd.Tables[1].Rows[3][0].ToString() : "";
                        lblDisbAmt4.Text = dsdd.Tables[1].Rows[3][1] != DBNull.Value ? dsdd.Tables[1].Rows[3][1].ToString() : "";

                    }
                    if (nCount >= 3)
                    {
                        lblDisbDate3.Text = dsdd.Tables[1].Rows[2][0] != DBNull.Value ? dsdd.Tables[1].Rows[2][0].ToString() : "";
                        lblDisbAmt3.Text = dsdd.Tables[1].Rows[2][1] != DBNull.Value ? dsdd.Tables[1].Rows[2][1].ToString() : "";

                    }
                    if (nCount >= 2)
                    {
                        lblDisbDate2.Text = dsdd.Tables[1].Rows[1][0] != DBNull.Value ? dsdd.Tables[1].Rows[1][0].ToString() : "";
                        lblDisbAmt2.Text = dsdd.Tables[1].Rows[1][1] != DBNull.Value ? dsdd.Tables[1].Rows[1][1].ToString() : "";

                    }
                    if (nCount >= 1)
                    {
                        lblDisbDate1.Text = dsdd.Tables[1].Rows[0][0] != DBNull.Value ? dsdd.Tables[1].Rows[0][0].ToString() : "";
                        lblDisbAmt1.Text = dsdd.Tables[1].Rows[0][1] != DBNull.Value ? dsdd.Tables[1].Rows[0][1].ToString() : "";

                    }
                }
                if (dsdd.Tables[2] != null && dsdd.Tables[2].Rows.Count > 0)
                {
                    dtsBounce = dsdd.Tables[2];
                    int nMonth = DateTime.Now.Month;
                    for (int n = 0; n <= dsdd.Tables[2].Rows.Count - 1; n++)
                    {
                        int nBMonth = dsdd.Tables[2].Rows[n][1] != DBNull.Value ? Convert.ToInt32(dsdd.Tables[2].Rows[n][1]) : 0;

                        if (nBMonth == nMonth)
                        {
                            lblBounce1.BackColor = Color.Black;
                        }
                        if (nBMonth == nMonth - 1)
                        {
                            lblBounce2.BackColor = Color.Black;
                        }
                        if (nBMonth == nMonth - 2)
                        {
                            lblBounce3.BackColor = Color.Black;
                        }
                        if (nBMonth == nMonth - 3)
                        {
                            lblBounce4.BackColor = Color.Black;
                        }
                    }
                }
            }
            else if (bTabIndex == 1)
            {
                lblAppName1.Text = dsdd.Tables[0].Rows[0]["Applicant_Name"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Applicant_Name"].ToString() : "";
                lblLoanAgrrement1.Text = dsdd.Tables[0].Rows[0]["Lnno"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Lnno"].ToString() : "";
                lblCOntactNo1.Text = dsdd.Tables[0].Rows[0]["Cont_no"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Cont_no"].ToString() : "";
                lblSancAmt1.Text = dsdd.Tables[0].Rows[0]["Sanc_Amt"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Sanc_Amt"].ToString() : "";
                lblDOF1.Text = dsdd.Tables[0].Rows[0]["First_Payment_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["First_Payment_Date"].ToString() : "";
                lblSancDate1.Text = dsdd.Tables[0].Rows[0]["Sanc_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Sanc_Date"].ToString() : "";
                lblLOF1.Text = dsdd.Tables[0].Rows[0]["Last_Payment_Date"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Last_Payment_Date"].ToString() : "";
                lblNOFirstDisb1.Text = dsdd.Tables[0].Rows[0]["No_OF_days_1st_disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["No_OF_days_1st_disb"].ToString() : "";
                lblNOLastDisb1.Text = dsdd.Tables[0].Rows[0]["No_OF_days_last_disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["No_OF_days_last_disb"].ToString() : "";
                lblLoanAMtDisb1.Text = dsdd.Tables[0].Rows[0]["Total_Disb"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Total_Disb"].ToString() : "";
                lblPropAddrs1.Text = dsdd.Tables[0].Rows[0]["Property address"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property address"].ToString() : "";
                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property area"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property area"].ToString() : "";
                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property city"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property city"].ToString() : "";
                //txtDDm.Text = dsdd.Tables[0].Rows[0]["Property pincode"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["Property pincode"].ToString() : "";

                if (dsdd.Tables[1] != null && dsdd.Tables[1].Rows.Count > 0)
                {
                    int nCount = dsdd.Tables[1].Rows.Count;
                    if (nCount == 5)
                    {
                        lblDisbDate51.Text = dsdd.Tables[1].Rows[4][0] != DBNull.Value ? dsdd.Tables[1].Rows[4][0].ToString() : "";
                        lblDisbAmt51.Text = dsdd.Tables[1].Rows[4][1] != DBNull.Value ? dsdd.Tables[1].Rows[4][1].ToString() : "";

                    }
                    if (nCount >= 4)
                    {
                        lblDisbDate41.Text = dsdd.Tables[1].Rows[3][0] != DBNull.Value ? dsdd.Tables[1].Rows[3][0].ToString() : "";
                        lblDisbAmt41.Text = dsdd.Tables[1].Rows[3][1] != DBNull.Value ? dsdd.Tables[1].Rows[3][1].ToString() : "";

                    }
                    if (nCount >= 3)
                    {
                        lblDisbDate31.Text = dsdd.Tables[1].Rows[2][0] != DBNull.Value ? dsdd.Tables[1].Rows[2][0].ToString() : "";
                        lblDisbAmt31.Text = dsdd.Tables[1].Rows[2][1] != DBNull.Value ? dsdd.Tables[1].Rows[2][1].ToString() : "";

                    }
                    if (nCount >= 2)
                    {
                        lblDisbDate21.Text = dsdd.Tables[1].Rows[1][0] != DBNull.Value ? dsdd.Tables[1].Rows[1][0].ToString() : "";
                        lblDisbAmt21.Text = dsdd.Tables[1].Rows[1][1] != DBNull.Value ? dsdd.Tables[1].Rows[1][1].ToString() : "";

                    }
                    if (nCount >= 1)
                    {
                        lblDisbDate11.Text = dsdd.Tables[1].Rows[0][0] != DBNull.Value ? dsdd.Tables[1].Rows[0][0].ToString() : "";
                        lblDisbAmt11.Text = dsdd.Tables[1].Rows[0][1] != DBNull.Value ? dsdd.Tables[1].Rows[0][1].ToString() : "";

                    }
                }
            }


        }

        else
        {
            if (bTabIndex == 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", "alert('Please give coorect Loan no for Pemi Property Visist Report Report');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", "alert('Please give coorect Loan no for Full Property Visit Report');", true);
            }
        }

        con.Close();
        //}
        //else
        //{
        //    Response.Redirect("Expire.aspx");
        //}
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();

        img.ImageUrl = Server.MapPath("~/Images/JPG/MIFLogo.JPG");
        tdLogo.Controls.Add(img);
        System.Web.UI.WebControls.Image img1 = new System.Web.UI.WebControls.Image();
        img.ImageUrl = Server.MapPath("~/Images/JPG/MIFLogo.JPG");
        if (bTabIndex == 0)
        {

            img1.ImageUrl = Server.MapPath("~/Images/PNG/checkedcheckboxnew1.png");
            img1.Height = 2;
            img1.Width = 2;

            System.Web.UI.WebControls.Image img2 = new System.Web.UI.WebControls.Image();
            img2.ImageUrl = Server.MapPath("~/Images/PNG/checkedcheckboxnew1.png");

            System.Web.UI.WebControls.Image img3 = new System.Web.UI.WebControls.Image();
            img3.ImageUrl = Server.MapPath("~/Images/PNG/checkedcheckboxnew1.png");

            System.Web.UI.WebControls.Image img4 = new System.Web.UI.WebControls.Image();
            img4.ImageUrl = Server.MapPath("~/Images/PNG/checkedcheckboxnew1.png");

            System.Web.UI.WebControls.Image img11 = new System.Web.UI.WebControls.Image();
            img11.ImageUrl = Server.MapPath("~/Images/JPG/chkwrong.jpg");

            System.Web.UI.WebControls.Image img12 = new System.Web.UI.WebControls.Image();
            img12.ImageUrl = Server.MapPath("~/Images/JPG/chkwrong.jpg");

            System.Web.UI.WebControls.Image img13 = new System.Web.UI.WebControls.Image();
            img13.ImageUrl = Server.MapPath("~/Images/JPG/chkwrong.jpg");

            System.Web.UI.WebControls.Image img14 = new System.Web.UI.WebControls.Image();
            img14.ImageUrl = Server.MapPath("~/Images/JPG/chkwrong.jpg");
            //   tdfirstMonth.Controls.Add(img1);
            /////
            bool bMonthstatus1 = false, bMonthstatus2 = false, bMonthstatus3 = false, bMonthstatus4 = false;
            int nMonth = DateTime.Now.Month;
            if (dtsBounce != null)
            {
                for (int n = 0; n <= dtsBounce.Rows.Count - 1; n++)
                {
                    int nBMonth = dtsBounce.Rows[n][1] != DBNull.Value ? Convert.ToInt32(dtsBounce.Rows[n][1]) : 0;

                    if (nBMonth == nMonth)
                    {
                        lblBounce1.BackColor = Color.Black;
                        tdfirstMonth.Controls.Add(img1);
                        bMonthstatus1 = true;
                    }

                    if (nBMonth == nMonth - 1)
                    {
                        lblBounce2.BackColor = Color.Black;
                        tdSecMonth.Controls.Add(img2);
                        bMonthstatus2 = true;
                    }

                    if (nBMonth == nMonth - 2)
                    {
                        lblBounce3.BackColor = Color.Black;
                        tdThrdMonth.Controls.Add(img3);
                        bMonthstatus3 = true;
                    }

                    if (nBMonth == nMonth - 3)
                    {
                        lblBounce4.BackColor = Color.Black;
                        tdFourMonth.Controls.Add(img4);
                        bMonthstatus4 = true;
                    }

                }
              
            }
            if (bMonthstatus1 == false)
            {
                tdfirstMonth.Controls.Add(img11);
            }
            if (bMonthstatus2 == false)
            {
                tdSecMonth.Controls.Add(img12);
            }
            if (bMonthstatus3 == false)
            {
                tdThrdMonth.Controls.Add(img13);
            }
            if (bMonthstatus4 == false)
            {
                tdFourMonth.Controls.Add(img14);
            }
        }
        /////
        //tblImg2.Controls.Add(img1);


        Response.ContentType = "application/pdf";
        
        Response.AddHeader("content-disposition", "attachment;filename=PEMI_" + txtLoanNo.Text + ".pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        StringWriter sw0 = new StringWriter();
        HtmlTextWriter hw0 = new HtmlTextWriter(sw0);

        pnlHeader.RenderControl(hw0);


        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        if (bTabIndex == 0)
        {
            pnlTable.RenderControl(hw);
        }
        else
        {
            panTable2.RenderControl(hw);
        }

        StringReader sr1 = new StringReader(sw0.ToString() + "<br/>" + sw.ToString());

        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        StyleSheet styles = new iTextSharp.text.html.simpleparser.StyleSheet();
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        pdfDoc.NewPage();
        pdfDoc.HtmlStyleClass = "PdfClass";
        htmlparser.Parse(sr1);
        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/PropertyVisitReport.aspx");
    }

    protected void Clear()
    {


        // PEMI 
        lblArea.Text = "";
        lblBranch.Text = "";
        lblProduct.Text = "";
        lblAppName.Text = "";
        lblLoanAgrrement.Text = "";
        lblCOntactNo.Text = "";
        lblSancAmt.Text = "";
        lblDOF.Text = "";
        lblSancDate.Text = "";
        lblLOF.Text = "";
        lblNOFirstDisb.Text = "";
        lblNOLastDisb.Text = "";
        lblLoanAMtDisb.Text = "";

        // color to be change
        lblBounce1.BackColor = Color.White;
        lblBounce2.BackColor = Color.White;
        lblBounce3.BackColor = Color.White;
        lblBounce4.BackColor = Color.White;
        // end of color to be change

        lblDisbDate1.Text = "";
        lblDisbDate2.Text = "";
        lblDisbDate3.Text = "";
        lblDisbDate4.Text = "";
        lblDisbDate5.Text = "";
        lblDisbAmt1.Text = "";
        lblDisbAmt2.Text = "";
        lblDisbAmt3.Text = "";
        lblDisbAmt4.Text = "";
        lblDisbAmt5.Text = "";
        lblPropAddrs.Text = "";


        // FULL 
        lblArea1.Text = "";
        lblBranch1.Text = "";
        lblProduct1.Text = "";
        lblAppName1.Text = "";
        lblLoanAgrrement1.Text = "";
        lblCOntactNo1.Text = "";
        lblSancAmt1.Text = "";
        lblDOF1.Text = "";
        lblSancDate1.Text = "";
        lblLOF1.Text = "";
        lblNOFirstDisb1.Text = "";
        lblNOLastDisb1.Text = "";
        lblLoanAMtDisb1.Text = "";



        lblDisbDate11.Text = "";
        lblDisbDate21.Text = "";
        lblDisbDate31.Text = "";
        lblDisbDate41.Text = "";
        lblDisbDate51.Text = "";
        lblDisbAmt11.Text = "";
        lblDisbAmt21.Text = "";
        lblDisbAmt31.Text = "";
        lblDisbAmt41.Text = "";
        lblDisbAmt51.Text = "";
        lblPropAddrs1.Text = "";
    }
}