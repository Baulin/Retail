﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class HOOps_Disb_ResolveQuery : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string sa;
    int ldid;
    int qryldid;
    int j;
    int b;
    int selectedcnt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            bind();
        }
    }
    //public void bind()
    //{
    //    SqlConnection con = new SqlConnection(strcon);
    //    con.Open();
    //    SqlCommand cmddd = new SqlCommand("select AR_NAME from MR_AREA", con);
    //    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //    DataSet dsdd = new DataSet();
    //    dadd.Fill(dsdd);

    //    con.Close();
    //    ddlArea.DataSource = dsdd;
    //    ddlArea.DataTextField = "AR_NAME";
    //    ddlArea.DataValueField = "AR_NAME";
    //    ddlArea.DataBind();
    //    ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

    //    //SqlCommand cmdqry = new SqlCommand("SELECT * FROM LSD_DISB_QUERY_GRID", con);
    //    //SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
    //    //DataSet dsqry = new DataSet();
    //    //daqry.Fill(dsqry);
    //    //gvQueryEntry.DataSource = dsqry.Tables[0];
    //    //gvQueryEntry.DataBind();
    //}
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
       // ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        gvQuerydets.Visible = false;
        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "A";
            gridbindall();
        }
        else if (txtLeadno.Text != "")//&& ddlArea.SelectedItem.Text == "--Select--"
        {
            Session["View"] = "F";
            
            gridbind();
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--")//&& ddlBranch.SelectedItem.Text != "--Select--"
        {
            Session["View"] = "F";
            gridbind();
        }
        else if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select Area and Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        
        else if (txtLeadno.Text == "")
        {
            uscMsgBox1.AddMessage("Please Enter Lead No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }
    public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = null;
            //SqlCommand cmd = new SqlCommand("select DISTINCT LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_DISB_QUERY B ON A.LD_ID=B.QRY_LD_ID LEFT JOIN LSD_DISB_FILE_TRANS C ON  C.FT_LD_ID=A.LD_ID LEFT JOIN MR_BRANCH D ON A.LD_BR_ID=D.BR_ID LEFT JOIN MR_AREA E ON E.AR_ID=D.BR_AR_ID WHERE QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')='' AND ISNULL(QRY_RESPONSE,'')<>'' AND isnull(QRY_RSL_DATE,'')=''  AND LD_LOAN_DATE IS NULL ORDER BY LD_NO DESC", con);
            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
               // cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
                cmd = new SqlCommand("select DISTINCT LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_DISB_QUERY B ON A.LD_ID=B.QRY_LD_ID LEFT JOIN LSD_DISB_FILE_TRANS C ON  C.FT_LD_ID=A.LD_ID LEFT JOIN MR_BRANCH D ON A.LD_BR_ID=D.BR_ID LEFT JOIN MR_AREA E ON E.AR_ID=D.BR_AR_ID WHERE QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')=''    AND LD_LOAN_DATE IS NULL  and E.AR_ST_ID='" + Session["STATEID"].ToString() + "' ORDER BY LD_NO DESC", con);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                //cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
                cmd = new SqlCommand("select DISTINCT LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_DISB_QUERY B ON A.LD_ID=B.QRY_LD_ID LEFT JOIN LSD_DISB_FILE_TRANS C ON  C.FT_LD_ID=A.LD_ID LEFT JOIN MR_BRANCH D ON A.LD_BR_ID=D.BR_ID LEFT JOIN MR_AREA E ON E.AR_ID=D.BR_AR_ID WHERE QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')=''    AND LD_LOAN_DATE IS NULL  and E.AR_DV_ID='" + Session["DIVID"].ToString() + "' ORDER BY LD_NO DESC", con);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                //cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
                cmd = new SqlCommand("select DISTINCT LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_DISB_QUERY B ON A.LD_ID=B.QRY_LD_ID LEFT JOIN LSD_DISB_FILE_TRANS C ON  C.FT_LD_ID=A.LD_ID LEFT JOIN MR_BRANCH D ON A.LD_BR_ID=D.BR_ID LEFT JOIN MR_AREA E ON E.AR_ID=D.BR_AR_ID WHERE QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')=''    AND LD_LOAN_DATE IS NULL  and E.AR_ID='" + Session["AREA_ID"].ToString() + "' ORDER BY LD_NO DESC", con);
            }
          
            else
            {
                cmd = new SqlCommand("select DISTINCT LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_DISB_QUERY B ON A.LD_ID=B.QRY_LD_ID LEFT JOIN LSD_DISB_FILE_TRANS C ON  C.FT_LD_ID=A.LD_ID LEFT JOIN MR_BRANCH D ON A.LD_BR_ID=D.BR_ID LEFT JOIN MR_AREA E ON E.AR_ID=D.BR_AR_ID WHERE QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')=''    AND LD_LOAN_DATE IS NULL ORDER BY LD_NO DESC", con);
            }
            
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds1.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();    
        }
    }
    public void gridbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmd = new SqlCommand("select DISTINCT LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_DISB_QUERY B ON A.LD_ID=B.QRY_LD_ID LEFT JOIN LSD_DISB_FILE_TRANS C ON  C.FT_LD_ID=A.LD_ID LEFT JOIN MR_BRANCH D ON A.LD_BR_ID=D.BR_ID LEFT JOIN MR_AREA E ON E.AR_ID=D.BR_AR_ID WHERE QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')='' AND ISNULL(QRY_RESPONSE,'')<>'' AND isnull(QRY_RSL_DATE,'')='' AND LD_NO='" + txtLeadno.Text + "' OR QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')='' AND ISNULL(QRY_RESPONSE,'')<>'' AND isnull(QRY_RSL_DATE,'')='' AND AR_NAME='" + ddlArea.SelectedValue.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedValue.ToString() + "'  AND LD_LOAN_DATE IS NULL ORDER BY LD_NO DESC", con);
            SqlCommand cmd = null;

            
             if (txtLeadno.Text != "")
             {
                 cmd = new SqlCommand("select DISTINCT LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_DISB_QUERY B ON A.LD_ID=B.QRY_LD_ID LEFT JOIN LSD_DISB_FILE_TRANS C ON  C.FT_LD_ID=A.LD_ID LEFT JOIN MR_BRANCH D ON A.LD_BR_ID=D.BR_ID LEFT JOIN MR_AREA E ON E.AR_ID=D.BR_AR_ID WHERE QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')=''  AND isnull(QRY_RSL_DATE,'')='' AND LD_NO='" + txtLeadno.Text + "'  AND LD_LOAN_DATE IS NULL ORDER BY LD_NO DESC", con);


             }
             else
             {
                 if (ddlBranch.SelectedItem.Text != "--Select--")
                 {
                     cmd = new SqlCommand("select DISTINCT LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_DISB_QUERY B ON A.LD_ID=B.QRY_LD_ID LEFT JOIN LSD_DISB_FILE_TRANS C ON  C.FT_LD_ID=A.LD_ID LEFT JOIN MR_BRANCH D ON A.LD_BR_ID=D.BR_ID LEFT JOIN MR_AREA E ON E.AR_ID=D.BR_AR_ID WHERE QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')=''  AND isnull(QRY_RSL_DATE,'')='' AND LD_NO='" + txtLeadno.Text + "' OR QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')='' AND AR_NAME='" + ddlArea.SelectedItem.Text + "' AND BR_NAME='" + ddlBranch.SelectedItem.Text.ToString() + "'  AND LD_LOAN_DATE IS NULL ORDER BY LD_NO DESC", con);
                 }
                 else
                 {
                     cmd = new SqlCommand("select DISTINCT LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_DISB_QUERY B ON A.LD_ID=B.QRY_LD_ID LEFT JOIN LSD_DISB_FILE_TRANS C ON  C.FT_LD_ID=A.LD_ID LEFT JOIN MR_BRANCH D ON A.LD_BR_ID=D.BR_ID LEFT JOIN MR_AREA E ON E.AR_ID=D.BR_AR_ID WHERE QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')=''  AND isnull(QRY_RSL_DATE,'')='' AND LD_NO='" + txtLeadno.Text + "' OR QRY_RSD_BY='H' AND ISNULL(QRY_RSL_DATE,'')='' AND AR_NAME='" + ddlArea.SelectedItem.Text + "'  AND LD_LOAN_DATE IS NULL ORDER BY LD_NO DESC", con);
                 }
             }
                SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        foreach (GridViewRow grow in gvQuery.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            Label lnbtn = grow.FindControl("lnkname") as Label;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                leadno = lnbtn.Text;
                appname = gvQuery.Rows[index].Cells[3].Text;
                pddt = gvQuery.Rows[index].Cells[4].Text;
                lnamt = gvQuery.Rows[index].Cells[5].Text;
            }
        }
        Session["Leadno"] = leadno;
        qrydetsbind();

        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;

        con.Close();
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('HOOps_QCQuery_Popup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
    }
    public void qrydetsbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdqryid = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + Session["Leadno"].ToString() + "'", con);
        SqlDataAdapter daqryid = new SqlDataAdapter(cmdqryid);
        DataSet dsqryid = new DataSet();
        daqryid.Fill(dsqryid);
        qryldid = Convert.ToInt32(dsqryid.Tables[0].Rows[0]["LD_ID"]);

        //SqlCommand cmdqry = new SqlCommand("SELECT QRY_ID,QRY_QUERY,QRY_SQUERY,QRY_RESPONSE FROM LSD_DISB_QUERY where QRY_LD_ID='" + qryldid + "' and isnull(QRY_RESP_DATE,'')<>'' AND isnull(QRY_RSL_DATE,'')='' AND QRY_RSD_BY='H'", con);
        SqlCommand cmdqry = new SqlCommand("SELECT QRY_ID,QRY_QUERY,QRY_SQUERY,QRY_RESPONSE FROM LSD_DISB_QUERY where QRY_LD_ID='" + qryldid + "' and  isnull(QRY_RSL_DATE,'')='' AND QRY_RSD_BY='H'", con);
        SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
        DataSet dsqry = new DataSet();
        daqry.Fill(dsqry);
        gvQuerydets.DataSource = dsqry.Tables[0];
        gvQuerydets.DataBind();
        gvQuerydets.Visible = true;
        foreach (GridViewRow grow1 in gvQuerydets.Rows)
        {
            CheckBox chkStat1 = grow1.FindControl("cb_select") as CheckBox;
            CheckBox chkAll = gvQuerydets.HeaderRow.FindControl("chkbxDownAll") as CheckBox;
            Label lblrsp = grow1.FindControl("lblrsp") as Label;
            if (lblrsp.Text == "")
            {
                chkStat1.Enabled = false;
                chkAll.Enabled = false;
            }
            else
            {
                chkStat1.Enabled = true;               
            }
        }
        con.Close();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Session["View"].ToString() == "F")
        {
            foreach (GridViewRow grow1 in gvQuerydets.Rows)
            {
                CheckBox chkStat1 = grow1.FindControl("cb_select") as CheckBox;
                int index1 = grow1.RowIndex;
                int count = Convert.ToInt32(chkStat1.Checked);
                if (count != 0)
                {
                    foreach (GridViewRow grow in gvQuerydets.Rows)
                    {
                        selectedcnt = 0;
                        CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                        int index = grow.RowIndex;
                        //int count = Convert.ToInt32(chkStat.Checked);
                        //if (count != 0)
                        //{
                        if (chkStat.Checked)
                        {
                            selectedcnt++;
                            SqlConnection con = new SqlConnection(strcon);
                            try
                            {
                                Label lbquery = grow.FindControl("lblname") as Label;
                                Label lbrsp = grow.FindControl("lblrsp") as Label;
                                Label lbqueryid = grow.FindControl("lblqryid") as Label;
                                string resp = lbrsp.Text;
                                string qry = lbquery.Text;
                                int qryid = Convert.ToInt32(lbqueryid.Text);
                                con.Open();
                                SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + Session["Leadno"].ToString() + "'", con);
                                SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
                                DataSet dsbr = new DataSet();
                                dabr.Fill(dsbr);
                                ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);                                
                                SqlCommand cmdupdate = new SqlCommand("update LSD_DISB_QUERY set QRY_RSL_DATE=getdate(),QRY_MBY='" + Session["ID"].ToString() + "',QRY_MDATE=getdate() where QRY_LD_ID='" + ldid + "' AND QRY_ID='" + qryid + "' AND QRY_RSD_BY='H'", con);
                                cmdupdate.ExecuteNonQuery();
                                gridbind();
                                //qrydetsbind();
                                gvQuerydets.Visible = false;
                                lbLeadno.Text = "";
                                lbAppname.Text = "";
                                lbPDdate.Text = "";
                                lbLoanamt.Text = "";
                                //txtResolve.Text = "";
                                btnSubmit.Enabled = false;
                            }
                            catch (Exception ex)
                            {
                                uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                                ErrorLog.WriteError(ex);
                            }
                            finally
                            {
                                con.Close();
                            }
                        }
                        else if (!chkStat.Checked)
                        {
                            selectedcnt--;
                        }
                    }
                    //uscMsgBox1.AddMessage("Query Resolved Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
                //else
                //{
                //    uscMsgBox1.AddMessage("Please Select Any Query To Resolve", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //}
            }
            if (selectedcnt == 0)
            {
                gvQuerydets.Visible = false;
                uscMsgBox1.AddMessage("Please Select Query To Resolve", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                uscMsgBox1.AddMessage("Query Resolved Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
           // gvQuery.Visible = false;
        }
        else if (Session["View"].ToString() == "A")
        {
            foreach (GridViewRow grow1 in gvQuerydets.Rows)
            {
                CheckBox chkStat1 = grow1.FindControl("cb_select") as CheckBox;
                int index1 = grow1.RowIndex;
                int count = Convert.ToInt32(chkStat1.Checked);
                if (count != 0)
                {
                    foreach (GridViewRow grow in gvQuerydets.Rows)
                    {
                        selectedcnt = 0;
                        CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                        int index = grow.RowIndex;
                        //int count = Convert.ToInt32(chkStat.Checked);
                        //if (count != 0)
                        //{
                        if (chkStat.Checked)
                        {
                            selectedcnt++;
                            SqlConnection con = new SqlConnection(strcon);
                            try
                            {
                                Label lbquery = grow.FindControl("lblname") as Label;
                                Label lbrsp = grow.FindControl("lblrsp") as Label;
                                Label lbqueryid = grow.FindControl("lblqryid") as Label;
                                string resp = lbrsp.Text;
                                string qry = lbquery.Text;
                                int qryid = Convert.ToInt32(lbqueryid.Text);
                                con.Open();
                                SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + Session["Leadno"].ToString() + "'", con);
                                SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
                                DataSet dsbr = new DataSet();
                                dabr.Fill(dsbr);
                                ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);

                                SqlCommand cmdupdate = new SqlCommand("update LSD_DISB_QUERY set QRY_RSL_DATE=getdate(),QRY_MBY='" + Session["ID"].ToString() + "',QRY_MDATE=getdate() where QRY_LD_ID='" + ldid + "' AND QRY_ID='" + qryid + "' AND QRY_RSD_BY='H'", con);
                                cmdupdate.ExecuteNonQuery();
                                //qrydetsbind();
                                gvQuerydets.Visible = false;
                                lbLeadno.Text = "";
                                lbAppname.Text = "";
                                lbPDdate.Text = "";
                                lbLoanamt.Text = "";
                                //txtResolve.Text = "";
                                btnSubmit.Enabled = false;
                            }
                            catch (Exception ex)
                            {
                                uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                                ErrorLog.WriteError(ex);
                            }
                            finally
                            {
                                con.Close();
                            }
                        }
                        else if (!chkStat.Checked)
                        {
                            selectedcnt--;
                        }
                    }
                    //uscMsgBox1.AddMessage("Query Resolved Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
                //else
                //{
                //    uscMsgBox1.AddMessage("Please Select Query To Resolve", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //}
            }
            if (selectedcnt == 0)
            {
                gvQuerydets.Visible = false;
                uscMsgBox1.AddMessage("Please Select Query To Resolve", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                uscMsgBox1.AddMessage("Query Resolved Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
            //gvQuery.Visible = false;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HOOps_Disb_ResolveQuery.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //txtLeadno.Enabled = false;
        txtLeadno.Text = "";
    }
}