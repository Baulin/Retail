﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_Branch : System.Web.UI.Page
{
    int areaid;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                bind();
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmddd = new SqlCommand("select AR_NAME,AR_ID from MR_AREA", con);
                SqlDataAdapter da1 = new SqlDataAdapter(cmddd);
                DataSet ds2 = new DataSet();
                da1.Fill(ds2);
                con.Close();
                ddlArea.DataSource = ds2;
                ddlArea.DataTextField = "AR_NAME";
                ddlArea.DataValueField = "AR_ID";
                ddlArea.DataBind();
                ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    public void bind()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            //SqlCommand cmd = new SqlCommand("select BR_ID,BR_CODE 'BR. CODE',BR_NAME 'BR. NAME',BR_CITY 'CITY',BR_CTPERSON 'CONTACT PERSON',BR_PHNO 'CONTACT NO.' from MR_BRANCH", con);
            SqlCommand cmd = new SqlCommand("RTS_SP_BIND_MR_BRANCH", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            gvBranch.DataSource = ds;
            gvBranch.DataBind();
            //if (gvBranch.Rows.Count > 0)
            //{
            //    gvBranch.HeaderRow.Font.Bold = true;
            //    gvBranch.HeaderRow.Cells[0].Text = "BR. CODE";
            //    gvBranch.HeaderRow.Cells[1].Text = "BR. NAME";
            //    gvBranch.HeaderRow.Cells[2].Text = "CITY";
            //    gvBranch.HeaderRow.Cells[3].Text = "CONTACT PERSON";
            //    gvBranch.HeaderRow.Cells[4].Text = "CONTACT NO.";

            //    gvBranch.HeaderRow.Cells[0].Wrap = false;
            //    gvBranch.HeaderRow.Cells[1].Wrap = false;
            //    gvBranch.HeaderRow.Cells[2].Wrap = false;
            //    gvBranch.HeaderRow.Cells[3].Wrap = false;
            //    gvBranch.HeaderRow.Cells[4].Wrap = false;
            //}
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow grow in gvBranch.Rows)
            {
                RadioButton chkUserID = (RadioButton)grow.FindControl("rb_select");
                if (chkUserID.Checked)
                {
                    Label lblBR_ID = (Label)grow.FindControl("lblBR_ID");
                    DataSet ds = new DataSet();
                    ds = clscommon.Bind_FETCH_DETAILS_BRANCH(lblBR_ID.Text);
                    txtBrcode.Text = ds.Tables[0].Rows[0]["BR_CODE"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_CODE"].ToString() : "";
                    txtBrname.Text = ds.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                    txtAddr1.Text = ds.Tables[0].Rows[0]["BR_ADD1"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_ADD1"].ToString() : "";
                    txtAddr2.Text = ds.Tables[0].Rows[0]["BR_ADD2"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_ADD2"].ToString() : "";
                    txtbrVFcode.Text = ds.Tables[0].Rows[0]["BR_VFCODE"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_VFCODE"].ToString() : "";
                    txtHFbrcode.Text = ds.Tables[0].Rows[0]["BR_HFCODE"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_HFCODE"].ToString() : "";
                    txtVFbrname.Text = ds.Tables[0].Rows[0]["BR_VFBRANCH"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_VFBRANCH"].ToString() : "";
                    txtHFbrname.Text = ds.Tables[0].Rows[0]["BR_HFBRANCH"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_HFBRANCH"].ToString() : "";
                    txtCity.Text = ds.Tables[0].Rows[0]["BR_CITY"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_CITY"].ToString() : "";
                    txtPincode.Text = ds.Tables[0].Rows[0]["BR_PINCODE"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_PINCODE"].ToString() : "";
                    ddlArea.SelectedValue = ds.Tables[0].Rows[0]["BR_AR_ID"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_AR_ID"].ToString() : "0";
                    txtContactperson.Text = ds.Tables[0].Rows[0]["BR_CTPERSON"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_CTPERSON"].ToString() : "";
                    txtContactno.Text = ds.Tables[0].Rows[0]["BR_PHNO"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_PHNO"].ToString() : "";
                    txtEmailid.Text = ds.Tables[0].Rows[0]["BR_EMAILID"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_EMAILID"].ToString() : "";
                    ddlstatus.SelectedValue = ds.Tables[0].Rows[0]["BR_STATUS"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_STATUS"].ToString() : "1";
                    ddlBranchType.SelectedValue = ds.Tables[0].Rows[0]["BR_TYPE"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_TYPE"].ToString() : "1";
                    btnSubmit.Text = "Update";
                    Session["BR_ID"] = lblBR_ID.Text;
                    break;
                }
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {

            //e.Row.Cells[0].Width = new Unit("127px");

            //e.Row.Cells[1].Width = new Unit("279px");
            //e.Row.Cells[2].Width = new Unit("116px");
            //e.Row.Cells[3].Width = new Unit("59px");
            //e.Row.Cells[4].Width = new Unit("73px");

        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
           
            //e.Row.Cells[0].Width = new Unit("135px");

            //e.Row.Cells[1].Width = new Unit("298px");
            //e.Row.Cells[2].Width = new Unit("122px");
            //e.Row.Cells[3].Width = new Unit("59px");
            //e.Row.Cells[4].Width = new Unit("73px");

            //if (e.Row.RowIndex == 0)
            //    e.Row.Style.Add("height", "50px");
            //e.Row.VerticalAlign = VerticalAlign.Bottom;
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            /* SqlCommand stcmd = new SqlCommand("select AR_ID from MR_AREA where AR_NAME='" + ddlArea.SelectedValue.ToString() + "'", con);
             SqlDataAdapter stda = new SqlDataAdapter(stcmd);
             DataSet stds = new DataSet();
             stda.Fill(stds);

             areaid = Convert.ToInt32(stds.Tables[0].Rows[0]["AR_ID"]);
            
             SqlCommand insertcmd = new SqlCommand("insert into MR_BRANCH(BR_CODE,BR_NAME,BR_ADD1,BR_ADD2,BR_CITY,BR_PINCODE,BR_AR_ID,BR_CTPERSON,BR_PHNO,BR_EMAILID,BR_VFCODE,BR_VFBRANCH,BR_HFCODE,BR_HFBRANCH,BR_CBY,BR_CDATE,BR_STATUS,BR_TYPE) values ('" + txtBrcode.Text.ToUpper() + "','" + txtBrname.Text.ToUpper() + "','" + txtAddr1.Text.ToUpper() + "','" + txtAddr2.Text.ToUpper() + "','" + txtCity.Text.ToUpper() + "','" + txtPincode.Text + "','" + areaid + "','" + txtContactperson.Text.ToUpper() + "','" + txtContactno.Text + "','" + txtEmailid.Text.ToUpper() + "','" + txtbrVFcode.Text.ToUpper() + "','" + txtVFbrname.Text.ToUpper() + "','" + txtHFbrcode.Text.ToUpper() + "','" + txtHFbrname.Text.ToUpper() + "','" + Session["ID"].ToString() + "',getdate(),'" + ddlstatus.SelectedValue + "','" + ddlBranchType.SelectedValue.ToString() + "')", con);
             insertcmd.ExecuteNonQuery();*/
           string strStat="";
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_BIND_MR_BRANCH", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                if (btnSubmit.Text == "Submit")
                {
                cmdinsert.Parameters.AddWithValue("@TYPE", "INSERT");
                    strStat="Branch Added Successfully";
                }
                else
                if (btnSubmit.Text == "Update")
                {
                     cmdinsert.Parameters.AddWithValue("@TYPE", "UPDATE");
                    strStat="Branch has been updated successfully.";
                }
                cmdinsert.Parameters.AddWithValue("@BR_CODE", txtBrcode.Text);
                cmdinsert.Parameters.AddWithValue("@BR_NAME", txtBrname.Text);
                cmdinsert.Parameters.AddWithValue("@BR_ADD1", txtAddr1.Text);
                cmdinsert.Parameters.AddWithValue("@BR_ADD2", txtAddr2.Text);
                cmdinsert.Parameters.AddWithValue("@BR_CITY", txtCity.Text);
                cmdinsert.Parameters.AddWithValue("@BR_PINCODE", txtPincode.Text);
                cmdinsert.Parameters.AddWithValue("@BR_AR_ID", ddlArea.SelectedItem.Text != "--Select--" ? Convert.ToInt32(ddlArea.SelectedValue) : 0);
                cmdinsert.Parameters.AddWithValue("@BR_CTPERSON", txtContactperson.Text);
                cmdinsert.Parameters.AddWithValue("@BR_PHNO", txtContactno.Text);
                cmdinsert.Parameters.AddWithValue("@BR_EMAILID", txtEmailid.Text);
                cmdinsert.Parameters.AddWithValue("@BR_VFCODE", txtbrVFcode.Text);
                cmdinsert.Parameters.AddWithValue("@BR_VFBRANCH", txtVFbrname.Text);
                cmdinsert.Parameters.AddWithValue("@BR_HFCODE", txtHFbrcode.Text);
                cmdinsert.Parameters.AddWithValue("@BR_HFBRANCH", txtHFbrname.Text);
                cmdinsert.Parameters.AddWithValue("@BR_STATUS", ddlstatus.SelectedValue);
                cmdinsert.Parameters.AddWithValue("@BR_TYPE", ddlBranchType.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@ID", Convert.ToString(Session["ID"]));
                cmdinsert.Parameters.AddWithValue("@BR_ID", Convert.ToString(Session["BR_ID"]));
           
                cmdinsert.ExecuteNonQuery();
                bind();
                txtBrcode.Text = "";
                txtBrname.Text = "";
                txtAddr1.Text = "";
                txtAddr2.Text = "";
                txtCity.Text = "";
                txtPincode.Text = "";
                txtContactno.Text = "";
                txtContactperson.Text = "";
                txtEmailid.Text = "";
                txtbrVFcode.Text = "";
                txtVFbrname.Text = "";
                txtHFbrcode.Text = "";
                txtHFbrname.Text = "";
                ddlArea.SelectedIndex = 0;
                btnSubmit.Text = "Submit";
                uscMsgBox1.AddMessage(strStat, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_Branch.aspx");
    }
}