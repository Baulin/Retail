﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_Reason : System.Web.UI.Page
{
    int proid;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("select DISTINCT PRS_DESC from MR_PROCESS", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmddd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            con.Close();
            ddlProcessname.DataSource = ds1;
            ddlProcessname.DataTextField = "PRS_DESC";
            ddlProcessname.DataValueField = "PRS_DESC";
            ddlProcessname.DataBind();
            ddlProcessname.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT RSN_REASON 'REASON DESCRIPTION',PRS_DESC 'PROCESS NAME' FROM MR_REASON A JOIN MR_PROCESS B ON A.RSN_PRS_ID=B.PRS_ID", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvReason.DataSource = ds;
        gvReason.DataBind();
        if (gvReason.Rows.Count > 0)
        {
            gvReason.HeaderRow.Font.Bold = true;
            gvReason.HeaderRow.Cells[0].Text = "REASON DESCRIPTION";
            gvReason.HeaderRow.Cells[1].Text = "PROCESS NAME";

            gvReason.HeaderRow.Cells[0].Wrap = false;
            gvReason.HeaderRow.Cells[1].Wrap = false;
        }
    }
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand stcmd = new SqlCommand("select PRS_ID from MR_PROCESS where PRS_DESC='" + ddlProcessname.SelectedValue.ToString() + "'", con);
            SqlDataAdapter stda = new SqlDataAdapter(stcmd);
            DataSet stds = new DataSet();
            stda.Fill(stds);

            proid = Convert.ToInt32(stds.Tables[0].Rows[0]["PRS_ID"]);

            SqlCommand insertcmd = new SqlCommand("insert into MR_REASON values ('" + txtReasondesc.Text + "','" + proid + "','" + Session["ID"].ToString() + "',getdate(),'" + Session["ID"].ToString() + "',getdate())", con);
            insertcmd.ExecuteNonQuery();
            bind();
            txtReasondesc.Text = "";
            //ddlProcessname.Text = "";
            uscMsgBox1.AddMessage("Reason Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_Reason.aspx");
    }
}