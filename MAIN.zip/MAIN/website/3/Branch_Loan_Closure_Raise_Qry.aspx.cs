﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;
using Utilities;


public partial class Branch_Loan_Closure_Raise_Qry : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string bcc3;
    ClsCommon clscommon = new ClsCommon();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
   
    DataSet ds = new DataSet();
    public static DataTable dtQuery = null;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    public static bool blMailStatus = false;
   


    protected void Page_Load(object sender, EventArgs e)
    {


        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bindArea();
            }
            else
            {
                Response.Redirect("Expire.aspx");
            }
        }

    }

    // Shankar_Nov_14_01 
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    // Shankar_Nov_14_01 
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            TextBox[] TextBox = pnl.Controls.OfType<TextBox>().ToArray();

            for (int i = 0; i < TextBox.Length; i++)
            {
                TextBox[i].Text = "";
            }



            pnl.Visible = false;

            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please select Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
            else
            {
                BindqueryGrid();
                foreach (GridViewRow grow in gvQuery.Rows)
                {
                    Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                    int index = grow.RowIndex;
                    if (lblQryResult.Text == "T")
                    {
                        gvQuery.Rows[index].Cells[1].ForeColor = Color.Red;
                        gvQuery.Rows[index].Cells[2].ForeColor = Color.Red;
                        gvQuery.Rows[index].Cells[3].ForeColor = Color.Red;
                        gvQuery.Rows[index].Cells[4].ForeColor = Color.Red;
                        gvQuery.Rows[index].Cells[5].ForeColor = Color.Red;
                    }

                }
                div_poslrq.Value = "0";
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_LoanClsr_Raise_Query", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "H");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvQuery.Visible = true;

                gvQuery.DataSource = ds1.Tables[0];
                gvQuery.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvQuery.HeaderRow.Font.Bold = true;
                    gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                    gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                    gvQuery.HeaderRow.Cells[1].Wrap = false;
                    gvQuery.HeaderRow.Cells[2].Wrap = false;
                    gvQuery.HeaderRow.Cells[3].Wrap = false;
                    gvQuery.HeaderRow.Cells[4].Wrap = false;
                    gvQuery.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvQuery.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        //Assumes the Price column is at index 4
        if (e.Row.RowType == DataControlRowType.DataRow)
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        TextBox[] TextBox = pnl.Controls.OfType<TextBox>().ToArray();

        for (int i = 0; i < TextBox.Length; i++)
        {
            TextBox[i].Text = "";

        }


        foreach (GridViewRow grow in gvQuery.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                Label ld_id = grow.FindControl("lblLeadID") as Label;
                Session["LeadID"] = ld_id.Text;
                leadno = lnbtn.Text;
                Session["Leadno"] = leadno;
                appname = gvQuery.Rows[index].Cells[3].Text;
                pddt = gvQuery.Rows[index].Cells[4].Text;
                lnamt = gvQuery.Rows[index].Cells[5].Text;
            }
        }
        pnl.Visible = true;


        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;


        con.Close();
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Legal_QueryPopUp.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    public void InsertQueries()
    {
        if (TextBox1.Text.Trim() == "" && TextBox2.Text.Trim() == "" && TextBox3.Text.Trim() == ""
            && TextBox4.Text.Trim() == "" && TextBox5.Text.Trim() == "" &&
            TextBox6.Text.Trim() == "" && TextBox7.Text.Trim() == "" && TextBox8.Text.Trim() == ""
            && TextBox9.Text.Trim() == "" && TextBox10.Text.Trim() == "")
        {
            uscMsgBox1.AddMessage("Please Enter Query", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            SqlConnection con = new SqlConnection(strcon);
            try
            {
                con.Open();
                Label lblLeadID = null;
                foreach (GridViewRow grow in gvQuery.Rows)
                {
                    CheckBox chkStat = grow.FindControl("rb_select") as CheckBox;
                    int index = grow.RowIndex;
                    if (chkStat.Checked)
                    {
                        lblLeadID = (Label)gvQuery.Rows[index].Cells[0].FindControl("lblLeadID");
                    }
                }
                TextBox[] TextBox = pnl.Controls.OfType<TextBox>().ToArray();
                string query = "";
                for (int i = 0; i < TextBox.Length; i++)
                {

                    if (i == 0)
                    {
                        query = TextBox[i].Text;
                    }
                    if (i >= 1)
                    {
                        if (TextBox[i].Text.Trim() != "")
                        {
                            query += "|" + TextBox[i].Text;
                            TextBox[i].Text = "";
                        }
                    }

                }

                string strVal = query;
                if (query != "")
                {
                    SqlCommand cmdinsert = new SqlCommand("RTS_SP_Insert_Loan_CLSR_Query", con);
                    cmdinsert.CommandType = CommandType.StoredProcedure;
                    cmdinsert.Parameters.AddWithValue("@Queries", query);
                    cmdinsert.Parameters.AddWithValue("@QRY_LD_ID", lblLeadID.Text);
                    cmdinsert.Parameters.AddWithValue("@QRY_RSD_BY", "H");
                    cmdinsert.Parameters.AddWithValue("@QRY_CBY", Session["ID"].ToString());
                    cmdinsert.ExecuteNonQuery();
                    BindqueryGrid();

                    pnl.Visible = false;

                    uscMsgBox1.AddMessage("Query Raised Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    sendMail(con);
                }

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
            }
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertQueries();

    }
    public void sendMail(SqlConnection con)
    {
        try
        {
            /////// mail ///////////
            //  strMailDetail = "";

            
            DataSet dsmailto = new DataSet();
            dsmailto = clscommon.Bind_FETCH_MR_EMAIL(Session["Leadno"].ToString());
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
                //Bala changes 17/07/2017 cc = dsmailto.Tables[0].Rows[0]["EM_AM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() : "";
                cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() + ";" + dsmailto.Tables[0].Rows[0]["EM_HO_CLS"].ToString();
                cc = cc.Replace("\n", "");
                bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
                bcc3 = dsmailto.Tables[0].Rows[0]["EM_CLM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_CLM"].ToString() : "";
            }
            if (bcc3 != "")
            {
                cc = cc + ";" + bcc3;
            }


            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            //to = "ManimaranK@equitasbank.com";
            //bcc2 = "ManimaranK@equitasbank.com";
            //cc = "rts-helpdesk@equitasbank.com";
            fromID = "RTS Alerts";
            toID = to;
            //   to = "ManimaranK@equitasbank.com";
            bcc2ID = bcc2;
            ccID = cc;

            // To Auto mail ///////
            //System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{

            String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/>Please find below details of closure queries<br/>";
            DataSet dsqry = new DataSet();
            dsqry = clscommon.Bind_LSD_CLSR_QUERIES(Session["LeadID"].ToString());

            int b = dsqry.Tables[0].Rows.Count;
            if (b != 0)
            {
                BodyTxt = BodyTxt + "<table width='90%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='center'  width='10%'>Sl. No.</td>";
                //BodyTxt = BodyTxt + "<td  align='center'>Credit Query Details</td>";
                //BodyTxt = BodyTxt + "<td  align='center'>Query Date</td>";
                //BodyTxt = BodyTxt + "<td  align='center'>Response</td>";
                //BodyTxt = BodyTxt + "<td  align='center'>Response Date</td>";

                BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' width='50%'>Raised Query</td>";
                BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' width='50%'>Raised Date</td>";
                BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' width='50%'>Response By Branch</td>";
                BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' width='50%'>Response Date</td></span></tr>";

                // if (dsmailto.Tables[0].Rows.Count != 0)
                for (int j = 0; j < dsqry.Tables[0].Rows.Count; j++)
                {
                    int sno = j + 1;
                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td bgcolor='#FFFFFF' align='right'> " + sno + "</td>";
                    //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Query Raised"].ToString() + "</td>";
                    //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Date"].ToString() + "</td>";
                    //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response"].ToString() + "</td>";
                    //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response Date"].ToString() + "</td>";
                    BodyTxt = BodyTxt + "<td bgcolor='#FFFFFF'> " + dsqry.Tables[0].Rows[j]["QRY_QUERY"].ToString() + "</td>";
                    BodyTxt = BodyTxt + "<td bgcolor='#FFFFFF'> " + dsqry.Tables[0].Rows[j]["QRY_CDATE"].ToString() + "</td>";
                    BodyTxt = BodyTxt + "<td bgcolor='#FFFFFF'> " + dsqry.Tables[0].Rows[j]["QRY_RESPONSE"].ToString() + "</td>";
                    BodyTxt = BodyTxt + "<td bgcolor='#FFFFFF'> " + dsqry.Tables[0].Rows[j]["QRY_RESP_DATE"].ToString() + "</td></span></tr>";
                }
                BodyTxt = BodyTxt + "</table>";
            }

            BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>Retail Ops - QC Team</td></tr>";
            BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
            //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

            blMailStatus = EmailManager.sendemail(to, "RTS Alerts", bcc2, cc, "CLOSURE QUERY  " + Session["Leadno"].ToString() + " - " + dsmailto.Tables[0].Rows[0]["LD_APNAME"].ToString() + " - " + dsmailto.Tables[0].Rows[0]["AR_NAME"].ToString() + "- " + dsmailto.Tables[0].Rows[0]["BR_NAME"].ToString() + "", BodyTxt, "", true);
            

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_Loan_Closure_Raise_Qry.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
    }
}