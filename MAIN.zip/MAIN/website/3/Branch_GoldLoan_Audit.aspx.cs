﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Data.OleDb;
using System.IO;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using Tracker;
using System.Threading;

public partial class Branch_GoldLoan_Audit : System.Web.UI.Page
{

    #region Common
    SqlConnection con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_Obj = new SqlCommand();
    DataTable dt_obj = new DataTable();
    CreateLogFiles Err = new CreateLogFiles();
    ReportDocument rpt = new ReportDocument();
    string stDate = string.Empty;
    string dcsServerDate = string.Empty;

   
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    string brName = string.Empty;
    string collectionTotal = "0";
    string Adt = "";
    string Cdt = "";
    string chk = "";
  
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            foreach (ListItem li in ddlPettyStatus.Items)
            {
                if (li.Value == "Not Tally")
                    li.Attributes.Add("style", "background:red;font-weight: bold;color:Black;");
                else
                    li.Attributes.Add("style", "background:green;font-weight: bold;color:Black;");
            }
            foreach (ListItem li in ddlValutStatus.Items)
            {
                if (li.Value == "Not Tally")
                    li.Attributes.Add("style", "background:red;font-weight: bold;color:Black;");
                else
                    li.Attributes.Add("style", "background:green;font-weight: bold;color:Black;");
            }
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    //getServerDate();
                   // txtBranch.Text = Convert.ToString(Session["UNITNAME"]);
                  //  txtBrCode.Text = Convert.ToString(Session["UNIT"]);
                    //if (lblSMEAmt.Text != "0" && lblMFAmt.Text != "0")
                    //    trRmrks.Visible = true;
                    //else
                    //    trRmrks.Visible = false;
                    bindArea();
                 
                       // txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                        //if (DateTime.Now.ToString("dd/MM/yyyy") != txtDate.Text)
                        //    Response.Redirect("~/RTS_Cash_Summary");
                    
                }
            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void bindArea()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();

            cmd_Obj = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
            }
            else
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", 0);
            }
            dt_obj = new DataTable();
            dt_obj.Load(cmd_Obj.ExecuteReader());
            ddlst_Area.DataSource = dt_obj;
            ddlst_Area.DataTextField = "AR_NAME";
            ddlst_Area.DataValueField = "AR_ID";
            ddlst_Area.DataBind();
            ddlst_Area.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Area.SelectedValue = Session["AREA_ID"].ToString();

            bindBranch();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }
    }
    public void bindBranch()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);

            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());



            ddlst_Branch.DataSource = dt_obj;
            ddlst_Branch.DataTextField = "BR_NAME";
            ddlst_Branch.DataValueField = "BR_ID";
            ddlst_Branch.DataBind();
            ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
            if (Session["USR_ACS"].ToString() == "7")
            {
                ddlst_Branch.SelectedValue = Session["BRANCHID"].ToString();
                ddlst_Branch.Enabled = false;
                ddlst_Area.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }

    }

    protected void ddlst_Area_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
           
          //  ddlst_Branch.SelectedIndex = 0;
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);
            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());

            ddlst_Branch.DataSource = dt_obj;
            ddlst_Branch.DataTextField = "BR_NAME";
            ddlst_Branch.DataValueField = "BR_ID";
            ddlst_Branch.DataBind();
            ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Branch.Enabled = true;
            //ClearValues();
            ddlst_Branch.SelectedIndex = 0;
            //txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }
    }
    protected int ChkCount()
    {
        SqlConnection conChk = new SqlConnection(strcon);
        int count = 0;
        try
        {
            string[] AuDte = txtDate.Text.Split('/');
            Adt = AuDte[2] + "-" + AuDte[1] + "-" + AuDte[0];
           // string[] ClDte = txtCollectiondate.Text.Split('/');
           // Cdt = ClDte[2] + "-" + ClDte[1] + "-" + ClDte[0];
            string qryChk = "select COUNT(LGS_ID) from LSD_GOLD_CASH_SUMMARY where LGS_BR_ID = " + ddlst_Branch.SelectedValue + " and CONVERT(date,LGS_DATE) = CONVERT(date,'" + Adt + "')";
            using (SqlCommand cmdChk = new SqlCommand(qryChk, conChk))
            {
                conChk.Open();
                count = Convert.ToInt32(cmdChk.ExecuteScalar());
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            conChk.Close();
            SqlConnection.ClearPool(conChk);
        }
        return count;
    }
    protected void txtCollectiondate_TextChanged(object sender, EventArgs e)
    {
        int cnt = ChkCount();
        if (cnt != 0)
        {
            txtDate.Text = "";
            uscMsgBox1.AddMessage("Audit was already done for the selected date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }
    protected void ddlst_Branch_SelectedIndexChanged(object sender, EventArgs e)
    {
        //ClearValues();
       // txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection conSub = new SqlConnection(strcon);
        try
        {
           // string grndTot = hdnGrndTot.Value;
            if (txtAmount2000.Text.Trim() != "" || txtAmount1000.Text.Trim() != "" || txtAmount500.Text.Trim() != "" || txtAmount100.Text.Trim() != "" || txtAmount50.Text.Trim() != "" || txtAmount20.Text.Trim() != "" || txtAmount10.Text.Trim() != "" || txtAmount5.Text.Trim() != "" || txtAmount2.Text.Trim() != "" || txtAmount1.Text.Trim() != "" || txtPaise50.Text.Trim() != ""
               || txtValutAmount2000.Text != "" || txtValutAmount1000.Text != "" || txtValutAmount500.Text.Trim() != "" || txtValutAmount100.Text.Trim() != "" || txtValutAmount50.Text.Trim() != "" || txtValutAmount20.Text.Trim() != "" || txtValutAmount10.Text.Trim() != "" || txtValutAmount5.Text.Trim() != "" || txtValutAmount2.Text.Trim() != "" || txtValutAmount1.Text.Trim() != "" || txtValutPaise50.Text.Trim() != "")
            {
                //if (grndTot == "")
                //    chk = "Y";
                //else
                //    chk = "";

                chk = "Y";
            }

             if (chk == "Y")
            {
     
                using (SqlCommand cmdSub = new SqlCommand("RTS_SP_GOLD_CASH_AUDIT", conSub))
                {
                    conSub.Open();
                    cmdSub.CommandType = CommandType.StoredProcedure;
                    cmdSub.CommandTimeout = 24000000;
                    cmdSub.Parameters.AddWithValue("@PTYPE", "INSERT");
                    //cmdSub.Parameters.AddWithValue("@CSHA_BR_ID", Convert.ToString(Session["BRANCHID"]));
                    cmdSub.Parameters.AddWithValue("@LGS_BR_ID", ddlst_Branch.SelectedIndex != 0 ? ddlst_Branch.SelectedValue : "");
                    string[] AuDte = txtDate.Text.Split('/');
                    Adt = AuDte[2] + "-" + AuDte[1] + "-" + AuDte[0];
                    cmdSub.Parameters.AddWithValue("@LGS_DATE", Adt);

                    cmdSub.Parameters.AddWithValue("@LGS_PETY_CASH", txtPettyCashAmount.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_CASH", txtValutCashAmount.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_PETY_2000", txtAmount2000.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_2000", txtValutAmount2000.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_PETY_1000", txtAmount1000.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_1000", txtValutAmount1000.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_PETY_500", txtAmount500.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_500", txtValutAmount500.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_PETY_100", txtAmount100.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_100", txtValutAmount100.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_PETY_50", txtAmount50.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_50", txtValutAmount50.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_PETY_20", txtAmount20.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_20", txtValutAmount20.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_PETY_10", txtAmount10.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_10", txtValutAmount10.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_PETY_5", txtAmount5.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_5", txtValutAmount5.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_PETY_2", txtAmount2.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_2", txtValutAmount2.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_PETY_1", txtAmount1.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_1", txtValutAmount1.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_PETY_50PAISE", txtPaise50.Text.Trim());
                    cmdSub.Parameters.AddWithValue("@LGS_VALUT_50PAISE", txtValutPaise50.Text.Trim());
                     cmdSub.Parameters.AddWithValue("@LGS_PETTY_STAT", ddlPettyStatus.SelectedIndex != 0 && ddlPettyStatus.SelectedValue == "Tally" ? 1 : 0);
                     cmdSub.Parameters.AddWithValue("@LGS_VALUT_STAT", ddlValutStatus.SelectedIndex != 0 && ddlValutStatus.SelectedValue == "Tally" ? 1 : 0);
                     cmdSub.Parameters.AddWithValue("@LGS_CBY", Session["EMPID"].ToString());
                     cmdSub.Parameters.AddWithValue("@LGS_RMKS", txtRemarks.Text.Trim());
                  //cmdSub.Parameters.Add("@id", SqlDbType.Int).Direction = ParameterDirection.Output;                
                    int res = cmdSub.ExecuteNonQuery();
                    if (res > 0)
                    {
                        
                     //   btnPrint.Enabled = true;
                     
                        uscMsgBox1.AddMessage("Gold Audit Submitted Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        clear();
                    }
                    else
                    {
                      //  btnPrint.Enabled = false;
                        uscMsgBox1.AddMessage("Submission Failed", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
            }
             else
             {
                
                 uscMsgBox1.AddMessage("Submission Failed. Please check once you entered values.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
             }
          
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            conSub.Close();
            conSub.Dispose();
            SqlConnection.ClearPool(conSub);
        }
    }
    protected void clear()
    {
        try
        {
            bindArea();
            txtPettyCashAmount.Text = "";
            txtValutCashAmount.Text = "";
            txtDate.Text = "";
            txtAmount2000.Text = "";
            txtAmount1000.Text = "";
            txtAmount500.Text = "";
            txtAmount100.Text = "";
            txtAmount50.Text = "";
            txtAmount20.Text = "";
            txtAmount10.Text = "";
            txtAmount5.Text = "";
            txtAmount2.Text = "";
            txtAmount1.Text = "";
            txtPaise50.Text = "";
            txtValutAmount2000.Text = "";
            txtValutAmount1000.Text = "";
            txtValutAmount500.Text = "";
            txtValutAmount100.Text = "";
            txtValutAmount50.Text = "";
            txtValutAmount20.Text = "";
            txtValutAmount10.Text = "";
            txtValutAmount5.Text = "";
            txtValutAmount2.Text = "";
            txtValutAmount1.Text = "";
            txtValutPaise50.Text = "";
            ddlValutStatus.SelectedIndex = 0;
            ddlPettyStatus.SelectedIndex = 0;
            txtRemarks.Text = "";
            

        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //Response.Redirect("Branch_GoldLoan_Audit.aspx");
        clear();
    }
    protected void hdntotAmt_ValueChanged(object sender, EventArgs e)
    {

    }
}