﻿using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CrystalDecisions.Shared;
using Tracker;

public partial class DCS_Reports : System.Web.UI.Page
{
    #region
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    CreateLogFiles Err = new CreateLogFiles();
    ReportDocument rpt = new ReportDocument();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {

                }
            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnGen_Click(object sender, EventArgs e)
    {
        try
        {
            string notUpdate = "0";
            string updated = "0";
            string closingBal = "0.00";
            string totBranches = "0";
            DataTable dtDcs = new DataTable();
            string[] date = txtbx_frm_date.Text.Trim().Split('/');
            string frmDate = date[2] + "/" + date[1] + "/" + date[0];
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("RTS_SP_DCS_NOT_UPDATED_RPT", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 240000000;
                    cmd.Parameters.AddWithValue("@Date", frmDate);
                    dtDcs.Load(cmd.ExecuteReader());
                }
            }
            if (dtDcs.Rows.Count > 0)
            {
                notUpdate = Convert.ToString(dtDcs.Rows[0]["RTS NOT UPDATED"]);
                updated = Convert.ToString(dtDcs.Rows[0]["RTS UPDATED"]);
                closingBal = Convert.ToString(dtDcs.Rows[0]["CLOSING BALANCE"]);
                totBranches = Convert.ToString(dtDcs.Rows[0]["TOTAL BRANCHES"]);
            }
            rpt = new ReportDocument();
            rpt.Load(Server.MapPath("Reports/DCS_NOT_UPDATE_RPT.rpt"));
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

            //assign the values to crystal report viewer
            rpt.SetParameterValue(0, frmDate);
            rpt.SetParameterValue(4, notUpdate);
            rpt.SetParameterValue(3, updated);
            rpt.SetParameterValue(2, closingBal != "" ? closingBal : "0.00");
            rpt.SetParameterValue(1, totBranches);

            rpt.ExportToHttpResponse(ExportFormatType.Excel, Response, true, "DCS As on " + txtbx_frm_date.Text + "");
            //rpt.ExportToHttpResponse(ExportFormatType.CharacterSeparatedValues, Response, true, "DCS As on " + txtbx_frm_date.Text + "");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //cmd_Obj.Dispose();
            //con.Close();
            //con.Dispose();
            //SqlConnection.ClearPool(con);
        }
    }
}