﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using Tracker;


public partial class HOOPSReceiveDoc : System.Web.UI.Page
{
    public static DataTable dtLawyerName = null;
    int ldid, s;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    ClsCommon clscommon = new ClsCommon();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
      /*  Page.Form.Attributes.Add("enctype", "multipart/form-data");
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);

        foreach (GridViewRow grow in gvLegalRecvDoc.Rows)
        {
            LinkButton lnlLoanNo = grow.FindControl("lnlLoanNo") as LinkButton;
            scriptManager.RegisterPostBackControl(this.lnlLoanNo);
        }*/
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            bind();
        }
    }
    private void RegisterPostBackControl()
    {
        foreach (GridViewRow row in gvLegalRecvDoc.Rows)
        {
            LinkButton lnkFull = row.FindControl("lnlLoanNo") as LinkButton;
            ScriptManager.GetCurrent(this).RegisterPostBackControl(lnkFull);
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));


    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--" && txtLeadno.Text == "")
        {
            gvLegalRecvDoc.Visible = true;
            Session["View"] = "All";
            //    gridbindall();
            BindHORECDoc();
        }
        //else if (txtLeadno.Text == "" )
        //{
        //    gvLegalRecvDoc.Visible = false;
        //    uscMsgBox1.AddMessage("Please Enter Lead No. and Select Process", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        //}
        else
        {
            gvLegalRecvDoc.Visible = true;
            Session["View"] = "F";
            //  gridbind();
            BindHORECDoc();
        }

    }

    public void BindHORECDoc()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_ReceiveDoc", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PR_ID", "0");
            cmd.Parameters.AddWithValue("@LD_BR_ID", ddlBranch.SelectedIndex > 0 ? ddlBranch.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@LD_AR_ID", ddlArea.SelectedIndex > 0 ? ddlArea.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@ReceiveType", "HOR");
            cmd.Parameters.AddWithValue("@LeadNo", txtLeadno.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //Panel1.Visible = true;
            gvLegalRecvDoc.DataSource = ds.Tables[0];
            gvLegalRecvDoc.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvLegalRecvDoc.HeaderRow.Font.Bold = true;
                gvLegalRecvDoc.HeaderRow.Cells[1].Text = "LEAD NO";
                gvLegalRecvDoc.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvLegalRecvDoc.HeaderRow.Cells[3].Text = "LOAN NO";
                gvLegalRecvDoc.HeaderRow.Cells[4].Text = "APPLICANT NAME";
                gvLegalRecvDoc.HeaderRow.Cells[5].Text = "PD DATE";
                gvLegalRecvDoc.HeaderRow.Cells[6].Text = "LOAN AMOUNT";
                gvLegalRecvDoc.HeaderRow.Cells[7].Text = "BRANCH NAME";
                //gvResolve.HeaderRow.Cells[6].Text = "QUERY";

                gvLegalRecvDoc.HeaderRow.Cells[1].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[2].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[3].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[4].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[5].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[6].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[7].Wrap = false;
                //gvResolve.HeaderRow.Cells[6].Wrap = false;

                
            }
            RegisterPostBackControl();
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Right;
        }
    }

    public void HOReceiveDocDocumntUpdate()
    {
        SqlConnection con = new SqlConnection(strcon);
        int ncount = 0;
        try
        {
            foreach (GridViewRow grow in gvMODTDDoc.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    ncount = ncount + 1;
                }
                else
                {
                    ncount = 0;
                }
            }
            if (ncount == 0)
            {
                uscMsgBox1.AddMessage("Document/s are missing, Can't be proceed", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("RTS_SP_Update_MODT_DOc_Values", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MD_LD_ID", Session["LeadId"].ToString());
                cmd.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                cmd.Parameters.AddWithValue("@TranStatus", "HOR");
                //cmd.Parameters.AddWithValue("@SendBy", "C");
                //cmd.Parameters.AddWithValue("@CR_ID", ddlName.SelectedIndex > 0 ? ddlName.SelectedValue.ToString() : "");
                //cmd.Parameters.AddWithValue("@PODorCOntatcNo", txtNumber.Text);
                int n = cmd.ExecuteNonQuery();

                if (cb_select.Checked)
                {
                    SqlCommand cmdupdate = new SqlCommand("Rts_Pr_Insert_MOTDTrans", con);
                    cmdupdate.CommandType = CommandType.StoredProcedure;
                    cmdupdate.Parameters.AddWithValue("@LEADID", Session["LeadId"].ToString());
                    cmdupdate.Parameters.AddWithValue("@Type", "HO_REV_MOTD");
                    cmdupdate.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                   int m= cmdupdate.ExecuteNonQuery();
                   //if (m > 0 && n == 0)
                   //{
                   //    uscMsgBox1.AddMessage("MODTD Documents received Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                   //    fetchMOTDTD();
                   //}
                }
                
                if (n > 0)
                {

                    uscMsgBox1.AddMessage("Documents Send Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    BindHORECDoc();
                    Panel2.Visible = false;
                    Panel3.Visible = false;
                   
                   
                }
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        HOReceiveDocDocumntUpdate();

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HOOPSReceiveDoc.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //txtLeadno.Enabled = false;
        txtLeadno.Text = "";
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        //if (ddlQuery.SelectedValue.ToString() == "QC")
        //{    
        int ncount = 0;
        foreach (GridViewRow grow in gvLegalRecvDoc.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
            //DropDownList ddrsp = grow.FindControl("Editdd") as DropDownList;
            Label lblState = grow.FindControl("lblState") as Label;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                leadno = lnbtn.Text;
                Session["LOANNO"] = gvLegalRecvDoc.Rows[index].Cells[3].Text;
                appname = gvLegalRecvDoc.Rows[index].Cells[4].Text;
                pddt = gvLegalRecvDoc.Rows[index].Cells[5].Text;
                lnamt = gvLegalRecvDoc.Rows[index].Cells[6].Text;
                //lQuery = gvResolve.Rows[index].Cells[7].Text;
                ncount = ncount + 1;
                //rcvquery = gvResolve.Rows[index].Cells[6].Text;
                Session["Leadno"] = leadno;
                getLeadID(con);
                BindDocGid(con);
                fetchDocReceipt();
  //As per request except tamilnadu only you can send the MOTD report separately.
                if (lblState.Text != "1")
                {
                    fetchMOTDTD();
                }
              

              //  binDcourierDetails(con);
            }


        }


        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;

        con.Close();
    }
    protected void fetchDocReceipt()
    {
        try
        {
            DataSet dsMOTD = new DataSet();
            dsMOTD = clscommon.Bind_MODTD_Details(Session["LeadId"].ToString());
            txtMOTDRcptNo.Text = dsMOTD.Tables[0].Rows[0]["MD_RCPT_NO"] != DBNull.Value ? dsMOTD.Tables[0].Rows[0]["MD_RCPT_NO"].ToString() : "";
            txtMOTDDocNo.Text = dsMOTD.Tables[0].Rows[0]["MD_DOC_NO"] != DBNull.Value ? dsMOTD.Tables[0].Rows[0]["MD_DOC_NO"].ToString() : "";
            txtMOTDDocNo.Enabled = false;
            txtMOTDRcptNo.Enabled = false;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void fetchMOTDTD()
    {
        try
        {
            DataSet dsMOTD = new DataSet();
            dsMOTD = clscommon.Bind_MODTD_Details(Session["LeadId"].ToString());
            if (dsMOTD.Tables[0].Rows[0]["MD_MOTD_SDATE"] != DBNull.Value)
            {
                Panel3.Visible = true;
                lblPOD.Text = dsMOTD.Tables[0].Rows[0]["MD_MOTD_POD"] != DBNull.Value ? dsMOTD.Tables[0].Rows[0]["MD_MOTD_POD"].ToString() : "";
                lblCourier.Text = dsMOTD.Tables[0].Rows[0]["MD_MOTD_CR_ID"] != DBNull.Value ? clscommon.GetCourierName(dsMOTD.Tables[0].Rows[0]["MD_MOTD_CR_ID"].ToString()) : "";
                if (dsMOTD.Tables[0].Rows[0]["MD_MOTD_RDATE"] != DBNull.Value)
                {
                    tdRevDate.Visible = true;
                    thRevDate.Visible = true;
                    lblMOTDRevDate.Text = dsMOTD.Tables[0].Rows[0]["MD_MOTD_RDATE"] != DBNull.Value ? dsMOTD.Tables[0].Rows[0]["MD_MOTD_RDATE"].ToString() : "";
                    thSelect.Visible = false;
                    tdSelect.Visible = false;
                }
                else
                {
                    thSelect.Visible = true;
                    tdSelect.Visible = true;
                    tdRevDate.Visible = false;
                    thRevDate.Visible = false;
                }
            }
            else
            {
                Panel3.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    public void binDcourierDetails(SqlConnection con)
    {
        SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchMODTDetailsForDoc", con);
        cmdbr.CommandType = CommandType.StoredProcedure;
        cmdbr.Parameters.AddWithValue("@LeadID", Session["LeadId"].ToString());
        cmdbr.Parameters.AddWithValue("@Type", "HLR");
        SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        DataSet dsbr = new DataSet();
        dabr.Fill(dsbr);
        if (dsbr.Tables[0] != null && dsbr.Tables[0].Rows.Count > 0)
        {

            BindCourierName();
            //ddlName.SelectedValue = dsbr.Tables[0].Rows[0]["ID"] != DBNull.Value ? dsbr.Tables[0].Rows[0]["ID"].ToString() : "";
            //txtNumber.Text = dsbr.Tables[0].Rows[0]["MD_LG_POD"] != DBNull.Value ? dsbr.Tables[0].Rows[0]["MD_LG_POD"].ToString() : "";
        }

    }
    public void BindDocGid(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("Select MDX_DOC,MDX_DTYPE from LSD_MOTD_DOCX LMD LEFT JOIN  LSD_MOTD  LM ON LMD.MDX_MD_ID =LM.MD_ID  where MD_LD_ID =" + Session["LeadId"].ToString() + "", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0 && ds.Tables[0] != null)
        {
            Panel2.Visible = true;
            Panel3.Visible = true;
            gvMODTDDoc.Visible = true;
            gvMODTDDoc.DataSource = ds;
            gvMODTDDoc.DataBind();
        }
        else
        {
            Panel2.Visible = false;
            Panel3.Visible = false;
        }


    }
    public void getLeadID(SqlConnection con)
    {
        SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
        cmdbr.CommandType = CommandType.StoredProcedure;
        cmdbr.Parameters.AddWithValue("@LeadNo", Session["Leadno"].ToString());
        SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        DataSet dsbr = new DataSet();
        dabr.Fill(dsbr);
        Session["LeadId"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
    }
    protected void ddlSendBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (ddlSendBy.SelectedItem.Text == "Courier")
        //{
        //    lblName.Text = "Courier Name";
        //    lblNumber.Text = "POD Number:";
        //    BindCourierName();
        //}
        //else if (ddlSendBy.SelectedItem.Text == "By Hand")
        //{
        //    lblName.Text = "Person Name";
        //    lblNumber.Text = "Contact No:";
        //    BindPesonName();
        //}
    }
    public void BindPesonName()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("Select * from MR_EMPLOYEE Where EMP_ET_ID=15", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        //ddlName.DataSource = dsdd;
        //ddlName.DataTextField = "EMP_NAME";
        //ddlName.DataValueField = "EMP_ID";
        //ddlName.DataBind();
        //ddlName.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void cb_select_CheckedChanged(object sender, EventArgs e)
    {
      

      
    }
    public void BindCourierName()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CourierListas", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        //ddlName.DataSource = dsdd;
        //ddlName.DataTextField = "CR_NAME";
        //ddlName.DataValueField = "CR_ID";
        //ddlName.DataBind();
        //ddlName.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void lnlLoanNo_Click(object sender, EventArgs e)
    {
        LinkButton lnlk = (LinkButton)sender;
        //string[] fileNames = Directory.GetFiles(Server.MapPath("~\\Upload\\File\\"));
        string[] fileNames = Directory.GetFiles(Server.MapPath("~\\Upload\\"));
        foreach (var item in fileNames)
        {
            int nameIndex = item.LastIndexOf("\\") + 1;
            string f = item.Remove(0, nameIndex);
            if (f.Contains("."))
            {
                f = f.Remove(f.Length - 4);
            }

            string[] stExtension = f.Split('.');
            if (lnlk.Text == stExtension[0].ToString())
            {
                Response.ContentType = ContentType;
                Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(item));
                Response.WriteFile(item);
                Response.End();
            }
        }
    }
}