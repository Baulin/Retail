﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_UserAccess : System.Web.UI.Page
{


    SqlConnection con_obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_obj = new SqlCommand();

    DataTable dt_obj = new DataTable();
    DataSet ds_obj = new DataSet();

    SqlDataAdapter da_obj = new SqlDataAdapter();

    CreateLogFiles Err = new CreateLogFiles();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {

                Bind_MR_User_Type();
                acstree.Visible = false;
                btn_submit.Enabled = false;

            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    public void Bind_MR_User_Type()
    {
        try
        {

            
            dt_obj = new DataTable();
            if (con_obj.State == ConnectionState.Broken || con_obj.State == ConnectionState.Closed)
                con_obj.Open();
            cmd_obj = new SqlCommand("SP_RTS_BIND_MR_USER_TYPE", con_obj);
            cmd_obj.CommandType = CommandType.StoredProcedure;
            cmd_obj.CommandTimeout = 120000;
            dt_obj.Load(cmd_obj.ExecuteReader());

            ddlst_usr_type.DataSource = dt_obj;
            ddlst_usr_type.DataValueField = "UTP_ID";
            ddlst_usr_type.DataTextField = "UTP_DESC";
            ddlst_usr_type.DataBind();
            ddlst_usr_type.Items.Insert(0, "--Select--");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_obj.Dispose();
            con_obj.Close();
            con_obj.Dispose();
            da_obj.Dispose();
            SqlConnection.ClearPool(con_obj);
        }
    }
    public void bind_menu_tree()
    {
        try
        {
            ds_obj = new DataSet();

            con_obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_obj.State == ConnectionState.Broken || con_obj.State == ConnectionState.Closed)
                con_obj.Open();

            cmd_obj = new SqlCommand("SP_RTS_FETCH_MENU_TREE", con_obj);
            cmd_obj.CommandType = CommandType.StoredProcedure;
            cmd_obj.Parameters.AddWithValue("@UA_UTP_ID", ddlst_usr_type.SelectedItem.Text != "--Select" ? ddlst_usr_type.SelectedValue : "0");
            cmd_obj.Parameters.AddWithValue("@LM_TYPE", ddlst_module.SelectedItem.Text != "--Select" ? ddlst_module.SelectedValue : "0");
            cmd_obj.CommandTimeout = 240000;
            da_obj = new SqlDataAdapter(cmd_obj);
            da_obj.Fill(ds_obj);


            tvTables.Nodes.Clear();
            for (int i = 0; i < ds_obj.Tables[0].Rows.Count; i++)
            {
                TreeNode masterNode = new TreeNode(ds_obj.Tables[0].Rows[i]["LM_GM"].ToString(), ds_obj.Tables[0].Rows[i]["LM_ID"].ToString());
                tvTables.Nodes.Add(masterNode);
                for (int l = 0; l < ds_obj.Tables[3].Rows.Count; l++)
                {
                    if (masterNode.Value == ds_obj.Tables[3].Rows[l]["UA_LM_ID"].ToString())
                    {
                        masterNode.Checked = true;
                        break;
                    }

                }
                for (int j = 0; j < ds_obj.Tables[1].Rows.Count; j++)
                {
                    TreeNode childnode = new TreeNode(ds_obj.Tables[1].Rows[j]["LM_MM"].ToString(), ds_obj.Tables[1].Rows[j]["LM_ID"].ToString());
                    if (ds_obj.Tables[0].Rows[i]["LM_GM"].ToString() == ds_obj.Tables[1].Rows[j]["LM_GM"].ToString())
                    {

                        masterNode.ChildNodes.Add(childnode);
                        for (int l = 0; l < ds_obj.Tables[3].Rows.Count; l++)
                        {
                            if (childnode.Value == ds_obj.Tables[3].Rows[l]["UA_LM_ID"].ToString())
                            {
                                childnode.Checked = true;
                                break;
                            }

                        }

                        for (int k = 0; k < ds_obj.Tables[2].Rows.Count; k++)
                        {
                            TreeNode leafnode = new TreeNode(ds_obj.Tables[2].Rows[k]["LM_SM"].ToString(), ds_obj.Tables[2].Rows[k]["LM_ID"].ToString());
                            if (ds_obj.Tables[1].Rows[j]["LM_MM"].ToString() == ds_obj.Tables[2].Rows[k]["LM_MM"].ToString() && ds_obj.Tables[1].Rows[j]["LM_GM"].ToString() == ds_obj.Tables[2].Rows[k]["LM_GM"].ToString())
                            {

                                childnode.ChildNodes.Add(leafnode);
                                for (int l = 0; l < ds_obj.Tables[3].Rows.Count; l++)
                                {
                                    if (leafnode.Value == ds_obj.Tables[3].Rows[l]["UA_LM_ID"].ToString())
                                    {
                                        leafnode.Checked = true;
                                        break;
                                    }

                                }
                            }

                        }


                    }

                }

            }
            tvTables.Visible = true;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_obj.Dispose();
            con_obj.Close();
            con_obj.Dispose();
            da_obj.Dispose();
            SqlConnection.ClearPool(con_obj);
        }

    }

    protected void ddlst_usr_type_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlst_usr_type.SelectedIndex > 0)
        {
            bind_menu_tree();
            acstree.Visible = true;
            btn_submit.Enabled = true;

        }
        else
        {
            acstree.Visible = false;
            btn_submit.Enabled = false;

        }
    }
    protected void ddlst_module_SelectedIndexChanged(object sender, EventArgs e)
    {
     
            acstree.Visible = false;
            btn_submit.Enabled = false;
            ddlst_usr_type.SelectedIndex = 0;

        
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_UserAccess.aspx");
    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        try
        {
            dt_obj = new DataTable();
            dt_obj.Columns.AddRange(new DataColumn[1] { new DataColumn("UTP_ID") });

            foreach (TreeNode t in tvTables.CheckedNodes)
            {
                if (t.Checked == true)
                {
                    var text = t.Text;
                    var value = t.Value;
                    dt_obj.Rows.Add(value);

                }
            }

            con_obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_obj.State == ConnectionState.Broken || con_obj.State == ConnectionState.Closed)
                con_obj.Open();
            cmd_obj = new SqlCommand("SP_RTS_MR_USER_ACS_INSERT", con_obj);
            cmd_obj.CommandType = CommandType.StoredProcedure;
            cmd_obj.Parameters.AddWithValue("@TABLETYPE", dt_obj);
            cmd_obj.Parameters.AddWithValue("@UA_UTP_ID", ddlst_usr_type.SelectedItem.Value);
            cmd_obj.Parameters.AddWithValue("@UA_CBY", Session["ID"].ToString());
            cmd_obj.Parameters.AddWithValue("@LM_TYPE",ddlst_module.SelectedValue);
            cmd_obj.CommandTimeout = 180000;
            
           int  rs = cmd_obj.ExecuteNonQuery();
           if (rs > 0)
           {
               Bind_MR_User_Type();
               tvTables.Visible = false;
               btn_submit.Enabled = false;
               acstree.Visible = false;

               uscMsgBox1.AddMessage("User Access Rights assigned successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
               return;

           }
           else
           {
               uscMsgBox1.AddMessage("User Access Rights not assigned", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
               return;
           }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_obj.Dispose();
            con_obj.Close();
            con_obj.Dispose();
            da_obj.Dispose();
            SqlConnection.ClearPool(con_obj);
        }
    }
}