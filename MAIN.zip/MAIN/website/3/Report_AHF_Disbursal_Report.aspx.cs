﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using System.Net.Mail;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using Tracker;
using System.Text.RegularExpressions;
using Resources;
using Utilities.SessionKeys;

public partial class Report_AHF_Disbursal_Report : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    //string sa;
    int ldid;
    //int j;
    //int b;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string dmmby = "";
    DateTime dt = DateTime.Now;
    string[] stringArray = new string[100];
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.Button1);
        scriptManager.RegisterPostBackControl(this.btnPrint);
        if (Session["ID"] != null)
        {

        }
        else
        {
            Response.Redirect("default.aspx");
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //base.VerifyRenderingInServerForm(control);
    }
    public void propetydetails()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("RTS_SP_RPT_LGL_PROPERTY_DETAILS", con);
            cmdrsn.CommandType = CommandType.StoredProcedure;
            cmdrsn.Parameters.AddWithValue("@LDNO", ddlSearchBY.SelectedValue.ToString() == "Lead No" ? txtbxleadno.Text : "");
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

            //GVPropertyDetails.DataSource = dsrsn;
            //GVPropertyDetails.DataBind();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void FetchDMCValues()
    {
        try
        {
            propetydetails();
            DataTable dtCam = null;
            if (Session[SessionKeys.Leadno].ToString() != "")
            {
                dtCam = fetchCamDetail();
                if (dtCam != null && dtCam.Rows.Count > 0)
                {
                    string strSancNO = dtCam.Rows[0]["LD_SANTD_NO"] != DBNull.Value ? dtCam.Rows[0]["LD_SANTD_NO"].ToString() : "";
                    txtLeadNo1.Text = Session[SessionKeys.Leadno].ToString();
                    txtAreaName.Text = dtCam.Rows[0]["AR_NAME"] != DBNull.Value ? dtCam.Rows[0]["AR_NAME"].ToString() : "";
                    txtBranchName.Text = dtCam.Rows[0]["BR_NAME"] != DBNull.Value ? dtCam.Rows[0]["BR_NAME"].ToString() : "";
                    // txtLandarea.Text = dtCam.Rows[0]["CAM_LAREA"] != DBNull.Value ? dtCam.Rows[0]["CAM_LAREA"].ToString() : "";
                    txtExtendArea.Text = dtCam.Rows[0]["MD_EXTENT"] != DBNull.Value ? dtCam.Rows[0]["MD_EXTENT"].ToString() : "";
                    txtScheme.Text = dtCam.Rows[0]["PR_CODE"] != DBNull.Value ? dtCam.Rows[0]["PR_CODE"].ToString() : "";
                    txtPropertyAddress.Text = dtCam.Rows[0]["PROPERTY ADDRESS"] != DBNull.Value ? dtCam.Rows[0]["PROPERTY ADDRESS"].ToString() : "";                    
                    tblDMC.Visible = true;
                    if (strSancNO != "")
                    {
                        DataTable dtSanc = null;
                        dtSanc = fetchSanction(strSancNO);

                        if (dtSanc != null && dtSanc.Rows.Count > 0)
                        {
                            //
                            tblDMC.Visible = true;
                            txtProposalNo.Text = dtSanc.Rows[0]["SANCPROCNO"] != DBNull.Value ? dtSanc.Rows[0]["SANCPROCNO"].ToString() : "";
                            // txtScheme.Text = dtSanc.Rows[0]["SCHEME_DESC"] != DBNull.Value ? dtSanc.Rows[0]["SCHEME_DESC"].ToString() : "";
                            txtAppName.Text = dtSanc.Rows[0]["NAME"] != DBNull.Value ? dtSanc.Rows[0]["NAME"].ToString() : "";
                            //txtCoAppName.Text = dtSanc.Rows[0]["COAPP"] != DBNull.Value ? dtSanc.Rows[0]["COAPP"].ToString() : "";
                            txtLoanAMount.Text = dtSanc.Rows[0]["LNAMT"] != DBNull.Value ? dtSanc.Rows[0]["LNAMT"].ToString() : "";
                            txtROI.Text = dtSanc.Rows[0]["CURR_ROI"] != DBNull.Value ? dtSanc.Rows[0]["CURR_ROI"].ToString() : "";
                            txtProcessFee.Text = dtSanc.Rows[0]["PF"] != DBNull.Value ? dtSanc.Rows[0]["PF"].ToString() : "0";
                            txtEMI.Text = dtSanc.Rows[0]["EMIAMOUNT"] != DBNull.Value ? dtSanc.Rows[0]["EMIAMOUNT"].ToString() : "";
                            txtTenor.Text = dtSanc.Rows[0]["CUSTTNRMNTHS"] != DBNull.Value ? dtSanc.Rows[0]["CUSTTNRMNTHS"].ToString() : "";
                            txtCSPM.Text = dtSanc.Rows[0]["CSINSPREUM"] != DBNull.Value ? dtSanc.Rows[0]["CSINSPREUM"].ToString() : "0";
                            txtPIPM.Text = dtSanc.Rows[0]["GENINSPREUM"] != DBNull.Value ? dtSanc.Rows[0]["GENINSPREUM"].ToString() : "0";
                            txtCersai.Text = dtSanc.Rows[0]["CERSAI"] != DBNull.Value ? dtSanc.Rows[0]["CERSAI"].ToString() : "0";
                            txtAdminFee.Text = dtSanc.Rows[0]["ADMIN_FEE"] != DBNull.Value ? dtSanc.Rows[0]["ADMIN_FEE"].ToString() : "0";
                            txtDoucmentionCharges.Text = dtSanc.Rows[0]["DOCUMENT_CHARGE"] != DBNull.Value ? dtSanc.Rows[0]["DOCUMENT_CHARGE"].ToString() : "0";
                            //txtTechFee.Text = dtSanc.Rows[0]["TECH_PF"] != DBNull.Value ? dtSanc.Rows[0]["TECH_PF"].ToString() : "0";
                            lblLegalFee.Text = dtSanc.Rows[0]["LEGAL_PF"] != DBNull.Value ? dtSanc.Rows[0]["LEGAL_PF"].ToString() : "0";
                            txtCreditShieldHolder.Text = dtSanc.Rows[0]["CREDIT_SHIELD_HOLDER"] != DBNull.Value ? dtSanc.Rows[0]["CREDIT_SHIELD_HOLDER"].ToString() : "0";

                            lblloginfee.Text = dtSanc.Rows[0]["LD_LGN_FEE"] != DBNull.Value ? dtSanc.Rows[0]["LD_LGN_FEE"].ToString() : "0";
                            lblactlprocsngfee.Text = Convert.ToDouble(txtProcessFee.Text)!=0 ? Convert.ToString(Convert.ToDouble(txtProcessFee.Text) - Convert.ToDouble(lblloginfee.Text)) : "0";

                            // txtCattleIns.Text = dtSanc.Rows[0]["CATTLE INSURANCE"] != DBNull.Value ? dtSanc.Rows[0]["CATTLE INSURANCE"].ToString() : "0";
                            double dbnNetDisbursalAmt = 0;
                            // dbnNetDisbursalAmt = Convert.ToDouble(txtLoanAMount.Text) - (Convert.ToDouble(txtProcessFee.Text) + Convert.ToDouble(txtCSPM.Text) + Convert.ToDouble(txtPIPM.Text) + Convert.ToDouble(txtCersai.Text) + Convert.ToDouble(txtAdminFee.Text) + Convert.ToDouble(txtTechFee.Text) + Convert.ToDouble(txtCattleIns.Text));
                            //dbnNetDisbursalAmt = Convert.ToDouble(txtLoanAMount.Text) - (Convert.ToDouble(txtProcessFee.Text) + Convert.ToDouble(txtCSPM.Text) + Convert.ToDouble(txtPIPM.Text) + Convert.ToDouble(txtCersai.Text) + Convert.ToDouble(txtAdminFee.Text) + Convert.ToDouble(txtTechFee.Text)+ Convert.ToDouble(txtDoucmentionCharges.Text));
                            dbnNetDisbursalAmt = Convert.ToDouble(txtLoanAMount.Text) - (Convert.ToDouble(lblactlprocsngfee.Text) + Convert.ToDouble(txtCSPM.Text) + Convert.ToDouble(txtPIPM.Text) + Convert.ToDouble(txtCersai.Text) + Convert.ToDouble(txtAdminFee.Text) + Convert.ToDouble(lblLegalFee.Text) + Convert.ToDouble(txtDoucmentionCharges.Text));

                            //txtNetAmt.Text = dbnNetDisbursalAmt.ToString();

                            txtCrdAprvDate.Text = dtCam.Rows[0]["LD_CRAP_DATE"] != DBNull.Value ? Convert.ToDateTime(dtCam.Rows[0]["LD_CRAP_DATE"]).ToString("dd/MM/yyyy") : "";

                            string strDate = dtSanc.Rows[0]["DATE"] != DBNull.Value ? dtSanc.Rows[0]["DATE"].ToString() : "";
                            if (strDate != "")
                            {
                                txtSanDate.Text = Convert.ToDateTime(strDate).ToString("dd/MM/yyyy");
                            }



                            string strLgAprv = dtCam.Rows[0]["LD_LG_APRL"] != DBNull.Value ? dtCam.Rows[0]["LD_LG_APRL"].ToString() : "";
                            if (strLgAprv == "1")
                            {
                                txtLegalStatus.Text = "Approval";
                                //ddlAppCase.Enabled = true;
                                // txtDmApproveDate.Enabled = true;
                                //txtDmApproveDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                                //txtRemarks.Enabled = true;
                            }
                            else
                            {
                                txtLegalStatus.Text = "Un Approval";
                                //   ddlAppCase.Enabled = false;
                                //txtDmApproveDate.Enabled = false;
                                //txtDmApproveDate.Text = "";
                                //txtRemarks.Enabled = false;
                            }
                            string strLandVal = dtCam.Rows[0]["CAM_LAREA"] != DBNull.Value ? dtCam.Rows[0]["CAM_LAREA"].ToString() : "";
                            //if (strLandVal != txtExtendArea.Text && Session["TYPEID"].ToString() == "3")
                            //{
                            //    uscMsgBox1.AddMessage("Legal Extent Area  is not Matching with CAM Land Area..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            //}

                            String creditCond = null;
                            String filteredText = null;
                            creditCond = dtSanc.Rows[0]["CREDIT_RMKS"] != DBNull.Value ? dtSanc.Rows[0]["CREDIT_RMKS"].ToString() : "";

                            //Replace </br> tags with new line
                            Regex regex = new Regex(@"(<br />|<br/>|</ br>|</br>)");
                            filteredText = regex.Replace(creditCond, "\r\n");

                            //Replace &amp; tags with blank space
                            regex = new Regex(@"(&amp;)");
                            filteredText = regex.Replace(filteredText, "and");

                            lblCreditConditions.Text = filteredText;

                            DataSet ds = fetchDMCDetail();
                            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                            {
                                txtLoanNUmber.Text = ds.Tables[0].Rows[0]["DM_LOAN_NO"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_LOAN_NO"].ToString() : "";
                                txtDate.Text = ds.Tables[0].Rows[0]["DM_DATE"] != DBNull.Value ? Convert.ToDateTime(ds.Tables[0].Rows[0]["DM_DATE"]).ToString("dd/MM/yyyy") : "";
                                txtRemarks.Text = ds.Tables[0].Rows[0]["DM_REMARKS"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_REMARKS"].ToString() : "";
                                txtDmApproveDate.Text = ds.Tables[0].Rows[0]["DM_APRL_DATE"] != DBNull.Value ? Convert.ToDateTime(ds.Tables[0].Rows[0]["DM_APRL_DATE"].ToString()).ToString("dd/MM/yyyy") : "";
                                //txtLandarea.Text = ds.Tables[0].Rows[0]["DM_LAREA"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_LAREA"].ToString() : "";
                                if (ds.Tables[0].Rows[0]["DM_PAYMENT_TYPE"] != DBNull.Value)
                                {
                                    if (ds.Tables[0].Rows[0]["DM_PAYMENT_TYPE"].ToString() == "2")
                                    {

                                        lblPaymentMode.Text = "NEFT";
                                        tdlblPayment.Visible = true;
                                        tdlblPayment1.Visible = true;
                                        dvNEFTPrint.Visible = true;
                                        dvChequePrint.Visible = false;
                                        txtPTIFSC.Text = ds.Tables[0].Rows[0]["DM_PT_IFSC"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PT_IFSC"].ToString() : "";

                                    }
                                    else
                                    {
                                        lblPaymentMode.Text = "CHEQUE";
                                        dvNEFTPrint.Visible = false;
                                        dvChequePrint.Visible = true;
                                        lblChqRsn.Text = ds.Tables[0].Rows[0]["DM_CHQ_RSN"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CHQ_RSN"].ToString() : "";

                                    }
                                }

                                dmmby = ds.Tables[0].Rows[0]["DM_MBY"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_MBY"].ToString() : "0";
                                DataTable dt = fetchUserDets(dmmby);

                                if (dt.Rows.Count > 0)
                                {
                                    ttxName1.Text = dt.Rows[0]["EMP_NAME"] != DBNull.Value ? dt.Rows[0]["EMP_NAME"].ToString() : "";
                                    txtCode1.Text = dt.Rows[0]["EMP_CODE"] != DBNull.Value ? dt.Rows[0]["EMP_CODE"].ToString() : "";
                                    txtDate1.Text = dt.Rows[0]["DATE"] != DBNull.Value ? dt.Rows[0]["DATE"].ToString() : "";

                                }
                                else
                                {
                                    ttxName1.Text = "";
                                    txtCode1.Text = "";
                                    txtDate1.Text = "";
                                }

                                string dmmby1 = ds.Tables[0].Rows[0]["DM_CBY"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CBY"].ToString() : "0";
                                DataTable dt1 = fetchUserDets(dmmby1);
                                lblAppCase.Text = "";
                                if (dt1.Rows.Count > 0)
                                {

                                    lblAppCase.Text = dt1.Rows[0]["EMP_NAME"] != DBNull.Value ? dt1.Rows[0]["EMP_NAME"].ToString() : "";
                                }
                                //bala changes 07/07/2017
                                //lblAppCase.Text = ds.Tables[0].Rows[0]["DM_APRL"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_APRL"].ToString() : "";
                                if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                                {
                                    int ncount = ds.Tables[1].Rows.Count;
                                    txtFavDetail1.Text = ds.Tables[1].Rows[0]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_FAVOR"].ToString() : "";

                                    string[] dmcbnk = ds.Tables[1].Rows[0]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_BANK"].ToString().Split('|') : null;
                                    string bnkNme1 = ds.Tables[1].Rows[0]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[0]["BK_NAME"].ToString() : "";
                                    if (dmcbnk != null)
                                    {
                                        bnkNme1 = bnkNme1 + " - " + dmcbnk[1].ToString();
                                    }

                                    ttxBankName1.Text = bnkNme1;
                                    txtAccno1.Text = ds.Tables[1].Rows[0]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_AC_NO"].ToString() : "";
                                    txtTotal1.Text = ds.Tables[1].Rows[0]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_AMOUNT"].ToString() : "";

                                    if (ncount >= 2)
                                    {
                                        txtFavDetail2.Text = ds.Tables[1].Rows[1]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_FAVOR"].ToString() : "";

                                        string[] dmcbnk2 = ds.Tables[1].Rows[1]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_BANK"].ToString().Split('|') : null;
                                        string bnkNme2 = ds.Tables[1].Rows[1]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[1]["BK_NAME"].ToString() : "";
                                        if (dmcbnk2 != null)
                                        {
                                            bnkNme2 = bnkNme2 + " - " + dmcbnk2[1].ToString();
                                        }
                                        ttxBankName2.Text = bnkNme2;
                                        txtAccno2.Text = ds.Tables[1].Rows[1]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_AC_NO"].ToString() : "";
                                        txtTotal2.Text = ds.Tables[1].Rows[1]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_AMOUNT"].ToString() : "";
                                    }

                                    if (ncount >= 3)
                                    {
                                        txtFavDetail3.Text = ds.Tables[1].Rows[2]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_FAVOR"].ToString() : "";
                                        string[] dmcbnk3 = ds.Tables[1].Rows[2]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_BANK"].ToString().Split('|') : null;
                                        string bnkNme3 = ds.Tables[1].Rows[2]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[2]["BK_NAME"].ToString() : "";
                                        if (dmcbnk3 != null)
                                        {
                                            bnkNme3 = bnkNme3 + " - " + dmcbnk3[1].ToString();
                                        }
                                        ttxBankName3.Text = bnkNme3;
                                        txtAccno3.Text = ds.Tables[1].Rows[2]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_AC_NO"].ToString() : "";
                                        txtTotal3.Text = ds.Tables[1].Rows[2]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_AMOUNT"].ToString() : "";
                                    }

                                    if (ncount >= 4)
                                    {

                                        txtFavDetail4.Text = ds.Tables[1].Rows[3]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_FAVOR"].ToString() : "";
                                        string[] dmcbnk4 = ds.Tables[1].Rows[3]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_BANK"].ToString().Split('|') : null;
                                        string bnkNme4 = ds.Tables[1].Rows[3]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[3]["BK_NAME"].ToString() : "";
                                        if (dmcbnk4 != null)
                                        {
                                            bnkNme4 = bnkNme4 + " - " + dmcbnk4[1].ToString();
                                        }
                                        ttxBankName4.Text = bnkNme4;
                                        txtAccno4.Text = ds.Tables[1].Rows[3]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_AC_NO"].ToString() : "";
                                        txtTotal4.Text = ds.Tables[1].Rows[3]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_AMOUNT"].ToString() : "";
                                    }


                                    if (ncount >= 5)
                                    {

                                        txtFavDetail5.Text = ds.Tables[1].Rows[4]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_FAVOR"].ToString() : "";
                                        string[] dmcbnk5 = ds.Tables[1].Rows[4]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_BANK"].ToString().Split('|') : null;
                                        string bnkNme5 = ds.Tables[1].Rows[4]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[4]["BK_NAME"].ToString() : "";
                                        if (dmcbnk5 != null)
                                        {
                                            bnkNme5 = bnkNme5 + " - " + dmcbnk5[1].ToString();
                                        }
                                        ttxBankName5.Text = bnkNme5;
                                        txtAccno5.Text = ds.Tables[1].Rows[4]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_AC_NO"].ToString() : "";
                                        txtTotal5.Text = ds.Tables[1].Rows[4]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_AMOUNT"].ToString() : "";
                                    }
                                }

                                txtSchemeType.Text = ds.Tables[0].Rows[0]["MPS_NAME"] != DBNull.Value ? ds.Tables[0].Rows[0]["MPS_NAME"].ToString() : "";
                                txtAreaType.Text = ds.Tables[0].Rows[0]["AR_TYPE_DESC"] != DBNull.Value ? ds.Tables[0].Rows[0]["AR_TYPE_DESC"].ToString() : "";
                                txtLandAreaSqft.Text = ds.Tables[0].Rows[0]["DMD_LAREA_SQFT"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_LAREA_SQFT"].ToString() : "";
                                txtGuideValue.Text = ds.Tables[0].Rows[0]["DMD_GVALUE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_GVALUE"].ToString() : "";
                                txtMarketValue.Text = ds.Tables[0].Rows[0]["DMD_MVALUE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_MVALUE"].ToString() : "";
                                txtTotLandValue.Text = ds.Tables[0].Rows[0]["DMD_TOT_LVALUE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_TOT_LVALUE"].ToString() : "";
                                txtConsBuildArea.Text = ds.Tables[0].Rows[0]["DMD_BLD_AREA_SQFT"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_BLD_AREA_SQFT"].ToString() : "";
                                txtValuePerSqft.Text = ds.Tables[0].Rows[0]["DMD_VAL_PER_SQFT"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_VAL_PER_SQFT"].ToString() : "";
                                txtConsBuildCost.Text = ds.Tables[0].Rows[0]["DMD_BLD_CONS_COST"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_BLD_CONS_COST"].ToString() : "";
                                txtTotPropValue.Text = ds.Tables[0].Rows[0]["DMD_TOT_PROP_VAL"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_TOT_PROP_VAL"].ToString() : "";
                                txtRegistrationCost.Text = ds.Tables[0].Rows[0]["DMD_REG_COST"] != DBNull.Value && Convert.ToInt32(ds.Tables[0].Rows[0]["DMD_REG_COST"]) != 0 ? ds.Tables[0].Rows[0]["DMD_REG_COST"].ToString() : "";
                                txtConsideredTotPropVal.Text = ds.Tables[0].Rows[0]["DMD_CONS_TOT_PVAL"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_CONS_TOT_PVAL"].ToString() : "";

                                ddlBuildingType.Text = ds.Tables[0].Rows[0]["DM_DISP_BUILD_TYPE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_DISP_BUILD_TYPE"].ToString() : "";
                                ddlConstStage.Text = ds.Tables[0].Rows[0]["DM_DISP_CNSTR_STAGE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_DISP_CNSTR_STAGE"].ToString() : "";
                                txtStageCompPercent.Text = ds.Tables[0].Rows[0]["DM_DISP_CNSTR_PER"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_DISP_CNSTR_PER"].ToString() : "";
                                txtRecommended.Text = ds.Tables[0].Rows[0]["DM_DISP_DEVI_PER"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_DISP_DEVI_PER"].ToString() : "";

                                txtConstructCost.Text = ds.Tables[0].Rows[0]["DMD_FIRST_CONST_COST"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_FIRST_CONST_COST"].ToString() : "";
                                txtMarginMoney.Text = ds.Tables[0].Rows[0]["DMD_MAR_MNY"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_MAR_MNY"].ToString() : "";
                                txtRecommDisbAmt.Text = ds.Tables[0].Rows[0]["DMD_RDISB_AMT"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_RDISB_AMT"].ToString() : "";
                                txtPendingDisbAmt.Text = ds.Tables[0].Rows[0]["DMD_PEND_DISB_AMT"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_PEND_DISB_AMT"].ToString() : "";
                                txtNetDisbAmt.Text = ds.Tables[0].Rows[0]["DMD_NET_DISB_AMT"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_NET_DISB_AMT"].ToString() : "";
                                txtLTV.Text = ds.Tables[0].Rows[0]["DMD_LTV"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_LTV"].ToString() : "";
                                txtLCR.Text = ds.Tables[0].Rows[0]["DMD_LCR"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_LCR"].ToString() : "";
                                string dmd_scheme_id="";
                                dmd_scheme_id = ds.Tables[0].Rows[0]["DMD_SCHEME_ID"] != DBNull.Value ? ds.Tables[0].Rows[0]["DMD_SCHEME_ID"].ToString() : "";


                                if (dmd_scheme_id != "28" && dmd_scheme_id != "29" && dmd_scheme_id != "32" && dmd_scheme_id != "33")
                                {
                                    txtTotalCollection.Text = Convert.ToString(Convert.ToDouble(txtCSPM.Text) + Convert.ToDouble(txtPIPM.Text));
                                    //txtTotalDeducion.Text = Convert.ToString(Convert.ToDouble(txtProcessFee.Text) + Convert.ToDouble(txtCersai.Text) + Convert.ToDouble(txtAdminFee.Text) + Convert.ToDouble(txtTechFee.Text) + Convert.ToDouble(txtDoucmentionCharges.Text));
                                    txtTotalDeducion.Text = Convert.ToString(Convert.ToDouble(lblactlprocsngfee.Text) + Convert.ToDouble(txtCersai.Text) + Convert.ToDouble(txtAdminFee.Text) + Convert.ToDouble(lblLegalFee.Text) + Convert.ToDouble(txtDoucmentionCharges.Text));
                                    lblTotCollection.Text = "Total Collection (Rs.) (E+F)";
                                    lbltotalDeduction.Text = "Total Deduction (Rs.) (A+B+C+D+G)";
                                }
                                else
                                {
                                    txtTotalCollection.Text = Convert.ToString("0");
                                    //txtTotalDeducion.Text = Convert.ToString(Convert.ToDouble(txtProcessFee.Text) + Convert.ToDouble(txtCersai.Text) + Convert.ToDouble(txtAdminFee.Text) + Convert.ToDouble(txtTechFee.Text) + Convert.ToDouble(txtCSPM.Text) + Convert.ToDouble(txtPIPM.Text) + Convert.ToDouble(txtDoucmentionCharges.Text));
                                    txtTotalDeducion.Text = Convert.ToString(Convert.ToDouble(lblactlprocsngfee.Text) + Convert.ToDouble(txtCersai.Text) + Convert.ToDouble(txtAdminFee.Text) + Convert.ToDouble(lblLegalFee.Text) + Convert.ToDouble(txtCSPM.Text) + Convert.ToDouble(txtPIPM.Text) + Convert.ToDouble(txtDoucmentionCharges.Text));
                                    lblTotCollection.Text = "Total Collection (Rs.)";
                                    lbltotalDeduction.Text = "Total Deduction (Rs.) (A+B+C+D+E+F+G)";
                                }
                            }


                        }
                        else
                        {
                            uscMsgBox1.AddMessage("Invalid Lead NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        }
                    }
                }
                else
                {
                    uscMsgBox1.AddMessage("Invalid Lead NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Please Enter the Lead NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public DataSet fetchDMCDetail()
    {
        DataTable dtCam = null;
        DataSet dsdd = null;

        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_DMC_DETAILS_AHF", con);
            cmddd.Parameters.AddWithValue("@LEADID", Session["LeadID"] != null ? Session["LeadID"].ToString() : "");

            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);
            // dtCam = dsdd.Tables[nIndex];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dsdd;
    }
    protected void txtLeadNo_TextChanged(object sender, EventArgs e)
    {

    }
    public DataTable fetchCamDetail()
    {
        DataTable dtCam = null;

        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_PR_Fetch_CAM", con);
            cmddd.Parameters.AddWithValue("@LD_NO", Session[SessionKeys.Leadno].ToString());

            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            dtCam = dsdd.Tables[0];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dtCam;
    }
    public DataTable fetchSanction(string strSanNO)
    {
        DataTable dtSanc = null;

        try
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            //SqlCommand mycomm = new SqlCommand("SANC_LETR_SME", con);
            SqlCommand mycomm = new SqlCommand("RTS_SP_MITC", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            //mycomm.Parameters.Add("@PrpslNo", SqlDbType.VarChar).Value = strSanNO;
            mycomm.Parameters.Add("@SANCPROCNO", SqlDbType.VarChar).Value = strSanNO;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            showdata.Fill(ds);
            dtSanc = ds.Tables[0];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dtSanc;
    }

    public DataTable fetchUserDets(string userid)
    {
        DataTable dtusr = null;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            DataSet ds = new DataSet();

            con.Open();
            SqlCommand mycomm = new SqlCommand("RTS_SP_GET_USER_DETAILS", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@USRID", SqlDbType.VarChar).Value = userid;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            showdata.Fill(ds);
            dtusr = ds.Tables[0];

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
        return dtusr;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtbxleadno.Text != null && txtbxleadno.Text != "")
            {
                DataSet ds = new DataSet();


                if (ddlSearchBY.SelectedValue == "Lead No")
                {
                    //ds = clscommon.Get_Full_RFD_Hold_Remarks_Details(txtbxleadno.Text);
                    ds = clscommon.Get_RFD_Hold_Status_For_Lead_By_Lead_No(txtbxleadno.Text);
                }
                else
                {
                    ds = clscommon.Get_RFD_Hold_Status_For_Lead_By_Sanc_No(txtbxleadno.Text);
                }

                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (ds.Tables[0].Rows[0]["HLD_BR_DATE"] == DBNull.Value)
                    {
                        uscMsgBox1.AddMessage("Lead No." + txtbxleadno.Text + " is already pending in RFD Hold Branch Response.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        return;
                    }
                    else
                        if (ds.Tables[0].Rows[0]["HLD_HDK_DATE"] == DBNull.Value)
                        {
                            uscMsgBox1.AddMessage("Lead No." + txtbxleadno.Text + " is already pending in RFD Hold Helpdesk Resolve.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            return;
                        }
                        else
                            if (ds.Tables[0].Rows[0]["HLD_OPS_REV_DATE"] == DBNull.Value)
                            {
                                uscMsgBox1.AddMessage("Lead No." + txtbxleadno.Text + " is already pending in RFD Hold Remarks Ops Handover.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                                return;
                            }
                }


                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmddd = null;
                if (ddlSearchBY.SelectedValue == "Lead No")
                {
                    cmddd = new SqlCommand("Select LD_ID,LD_NO from lsd_lead where LD_NO='" + txtbxleadno.Text + "'", con);
                }
                else
                {
                    cmddd = new SqlCommand("Select LD_ID,LD_NO from lsd_lead where LD_SANTD_NO='" + txtbxleadno.Text + "'", con);
                }
                SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
                DataSet dsdd = new DataSet();
                dadd.Fill(dsdd);
                Session[SessionKeys.Leadno] = dsdd.Tables[0].Rows[0][1];
                Session["LeadID"] = dsdd.Tables[0].Rows[0][0];
                con.Close();
                FetchDMCValues();

                // else
                // {
                // uscMsgBox1.AddMessage("Please complete RFD Hold Remarks Process before generate the report.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                // }
            }
            else
            {
                uscMsgBox1.AddMessage("Please enter the Lead No /  Sanction No", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        String _leadNo = String.Empty;

        try
        {
            if(Session[SessionKeys.Leadno] != null) { _leadNo = Convert.ToString(Session[SessionKeys.Leadno]); }

            if (!String.IsNullOrEmpty(_leadNo) && clscommon.ValidateDMCompletedByCredit(_leadNo))
            {
                System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();
                Response.ContentType = "application/pdf";
                Response.AddHeader("content-disposition", "attachment;filename=DMC_" + txtbxleadno.Text + ".pdf");
                Response.Cache.SetCacheability(HttpCacheability.NoCache);

                StringWriter sw0 = new StringWriter();
                HtmlTextWriter hw0 = new HtmlTextWriter(sw0);
                pnlHeader.RenderControl(hw0);

                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                pnlpdf0.RenderControl(hw);

                StringReader sr1 = new StringReader(sw0.ToString() + "<br/>" + sw.ToString());

                Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
                HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                PdfWriter.GetInstance(pdfDoc, Response.OutputStream);

                pdfDoc.Open();
                pdfDoc.NewPage();
                pdfDoc.HtmlStyleClass = "PdfClass";
                htmlparser.Parse(sr1);
                pdfDoc.Close();
                Response.Write(pdfDoc);
                Response.End();
            }
            else
            {
                uscMsgBox1.AddMessage(Disbursal_Memo_BusinessMessages.MSG_ERR_CREDIT_DM_PENDING, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
}