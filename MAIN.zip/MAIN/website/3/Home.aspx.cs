﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using Tracker;

public partial class About : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    SqlConnection con;
    ReportDocument rpt = new ReportDocument();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
                scriptManager.RegisterPostBackControl(this.btn_Excel);

                //ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
                scriptManager.RegisterPostBackControl(this.btn_PDF);
                con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT DISTINCT CRTD_DT FROM RPT_DISB_DET", con);
                lblDateTime.Text = cmd.ExecuteScalar().ToString();
                con.Close();
            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
    }
    protected void btn_Excel_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {

            //con.Open();

            //SqlCommand cmd = new SqlCommand("RTS_PRDD_SUMMARY", con);

            //cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@UAL_ID", Session["USR_ACS"]);
            //cmd.Parameters.AddWithValue("@BR_ID", Session["BRANCHID"]);
            //cmd.Parameters.AddWithValue("@AR_ID", Session["AREA_ID"]);
            //cmd.Parameters.AddWithValue("@DV_ID", Session["DIVID"]);
            //cmd.Parameters.AddWithValue("@ST_ID", Session["STATEID"]);
            //SqlDataAdapter damd = new SqlDataAdapter(cmd);
            //DataSet ds = new DataSet();
            //damd.Fill(ds);

            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    System.IO.StringWriter tw = new System.IO.StringWriter();
            //    GridView dgGrid = new GridView();
            //    dgGrid.DataSource = ds;
            //    Response.Clear();
            //    Response.Buffer = true;
            //    Response.AddHeader("content-disposition", "attachment;filename=PRDD_Report_'" + lblDateTime.Text + "'.xls");
            //    Response.Charset = "";
            //    Response.ContentType = "application/vnd.ms-excel";
            //    StringWriter sw = new StringWriter();
            //    HtmlTextWriter hw = new HtmlTextWriter(sw);
            //    dgGrid.AllowPaging = false;
            //    dgGrid.DataBind();
            //    dgGrid.HeaderRow.Style.Add("background-color", "#FFFFFF");
            //    dgGrid.HeaderRow.ForeColor = Color.White;
            //    DataGrid dg = new DataGrid();
            //    dg.DataSource = ds;
            //    dg.DataBind();
            //    dgGrid.BorderColor = Color.FromArgb(211, 211, 211);
            //    for (int z = 0; z < dg.Items[0].Cells.Count; z++)
            //    {
            //        dgGrid.HeaderRow.Cells[z].Style.Add("background-color", "#7F7F7F");
            //        dgGrid.HeaderRow.Cells[z].BorderColor = Color.FromArgb(211, 211, 211);
            //    }
            //    for (int i = 0; i < dgGrid.Rows.Count; i++)
            //    {
            //        GridViewRow row = dgGrid.Rows[i];
            //        row.BackColor = System.Drawing.Color.White;

            //        row.Attributes.Add("class", "textmode");
            //        for (int s = 0; s < dg.Items[0].Cells.Count; s++)
            //        {
            //            if (i % 2 != 0)
            //            {
            //                row.Cells[s].Style.Add("background-color", "#f2f2f2");
            //                row.Cells[s].BorderColor = Color.FromArgb(211, 211, 211);
            //                row.Cells[s].ForeColor = Color.Black;
            //                row.Cells[s].Font.Bold = true;
            //                row.Cells[s].Font.Size = 10;
            //            }
            //            else
            //            {
            //                row.Cells[s].Style.Add("background-color", "#DDD9C3");
            //                row.Cells[s].BorderColor = Color.FromArgb(211, 211, 211);
            //                row.Cells[s].ForeColor = Color.Black;
            //                row.Cells[s].Font.Bold = true;
            //                row.Cells[s].Font.Size = 10;
            //            }
            //        }
            //    }
            //    dgGrid.RenderControl(hw);
            //    string headerTable = @"<Table><tr><th colspan=11 align=left><font face=Calibri size=5 color=#974807>PRDD_Report</font></th></tr></Table>";
            //    Response.Write(headerTable);
            //    Response.Output.Write(sw.ToString());
            //    Response.Flush();
            //    Response.End();
            //}
            //else
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "No Records Available");
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btn_PDF_Click(object sender, EventArgs e)
    {
        try
        {
            //con = new SqlConnection(strcon);
            //SqlCommand cmd = new SqlCommand("RTS_PRDD_SUMMARY", con);

            //cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@UAL_ID", Session["USR_ACS"]);
            //cmd.Parameters.AddWithValue("@BR_ID", Session["BRANCHID"]);
            //cmd.Parameters.AddWithValue("@AR_ID", Session["AREA_ID"]);
            //cmd.Parameters.AddWithValue("@DV_ID", Session["DIVID"]);
            //cmd.Parameters.AddWithValue("@ST_ID", Session["STATEID"]);
            //SqlDataAdapter damd = new SqlDataAdapter(cmd);
            //DataSet dsmd = new DataSet();
            //damd.Fill(dsmd);

            //if (dsmd.Tables[0].Rows.Count <= 0)
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "No Records Available");
            //}
            //else
            //{
            //    if (dsmd.Tables[0].Rows.Count > 0)
            //    {
            //        rpt = new ReportDocument();
            //        rpt.Load(Server.MapPath("Reports/PRDD_SUMMARY.rpt"));
            //        SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
            //        rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);
            //        rpt.SetParameterValue(0, Convert.ToInt32(Session["USR_ACS"]));
            //        rpt.SetParameterValue(1, Convert.ToInt32(Session["BRANCHID"]));
            //        rpt.SetParameterValue(2, Convert.ToInt32(Session["AREA_ID"]));
            //        rpt.SetParameterValue(3, Convert.ToInt32(Session["DIVID"]));
            //        rpt.SetParameterValue(4, Convert.ToInt32(Session["STATEID"]));

            //        rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "PRDD SUMMARY");
            //    }
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            rpt.Close();
            rpt.Dispose();
            rpt = null;
            con.Close();
            GC.Collect();
        }
    }

    protected void btn_Lead_CLICK(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("Report_Detailed_Lead_Status.aspx",false);
        
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            rpt.Close();
            rpt.Dispose();
            rpt = null;
            con.Close();
            GC.Collect();
        }
    }
    protected void btnOHD_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://ftportal.equitas.in/OHD//OHD_DCS.aspx?USR_NAME=" + Convert.ToString(Session["User"]) + "&USR_ID=" + Convert.ToString(Session["USR_ID"]) + "&USR_BR_CODE=" + Convert.ToString(Session["BR_CODE"]) + "&BR_NAME=" + Convert.ToString(Session["UNITNAME"]) + "&USR_ATYPE=RTS" + "");
    }
}
