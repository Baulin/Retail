﻿using Resources;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using Tracker;
using Utilities.Enums;
using Utilities.FormValidations;
using Utilities.SessionKeys;

public partial class Declared_Income_Summary_Sheet : System.Web.UI.Page
{
    #region COMMON VARIABLES

    SqlConnection sqlConn;
    SqlCommand sqlCmd;
    SqlDataAdapter sqlDtAdptr;
    DataSet dtSet;

    private bool _creditConditionsVisible = false;
    private bool _deviationsVisible = false;
    private bool _saveDISSuccess = false;
    private bool _saveIncomeDetailsSuccess = false;
    private bool _saveObligationDetailsSuccess = false;
    private bool _obligationDetailsNotAvailable = false;

    private String _leadNo = null;
    private String _applName = null;
    private String _product = null;
    private String _loanAmt = null;

    private String _ConnStr
    {
        get
        {
            String connStr = String.Empty;

            try
            {
                connStr = DbConnectionManager.GetDbConnection();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }

            return connStr;
        }
    }

    public Int64 SessionEMP_ID
    {
        get
        {
            Int64 employeeId = -1;
            var empId = Convert.ToInt64(Session[SessionKeys.EMP_ID]);

            if (empId > 0)
            {
                employeeId = Convert.ToInt32(Session[SessionKeys.EMP_ID]);
            }

            return employeeId;
        }
    }

    public ClsCommon commonClsObj = new ClsCommon();

    #endregion

    #region PAGE EVENTS

    protected void Page_Load(object sender, EventArgs e)
    {
        {
            if (!IsPostBack)
            {
                try
                {
                    if (Session["ID"] != null)
                    {
                        ViewState[AppConstants.CreditConditionVisible] = _creditConditionsVisible = false;
                        ViewState[AppConstants.DeviationVisible] = _deviationsVisible = false;
                        DisplayOnlySearchPanel();
                        BindSearchPanel();

                        //Reset Session key
                        if (Session[SessionKeys.DATA_MANIPULATION_MODE] != null) { Session[SessionKeys.DATA_MANIPULATION_MODE] = null; }
                    }
                    else
                    {
                        Response.Redirect("default.aspx");
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }
            }
        }
    }

    public void Page_LoadComplete(object sender, EventArgs e)
    {
        if (ViewState[AppConstants.CreditConditionVisible] != null
            && ViewState[AppConstants.DeviationVisible] != null)
        {
            _creditConditionsVisible = Convert.ToBoolean(ViewState[AppConstants.CreditConditionVisible]);
            _deviationsVisible = Convert.ToBoolean(ViewState[AppConstants.DeviationVisible]);

            if (_creditConditionsVisible) { BindCreditConditionsMaxlengthValidator(); }
            if (_deviationsVisible) { BindDeviationsMaxlengthValidator(); }
        }
    }

    #endregion

    #region GRID EVENTS

    protected void gvIncomeDetail_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (Session[SessionKeys.GV_INCOME_DETAILS] != null)
        {
            DataTable dtIncomeDetailsGrid = (DataTable)Session[SessionKeys.GV_INCOME_DETAILS];

            if (e.CommandName == "Delete")
            {
                btnSubmit.Enabled = false;
                string[] incomeParams = e.CommandArgument.ToString().Split('/');

                String filterQuery = ("NAME = '" + incomeParams[0] + "' AND ( INCOME_SOURCE = '" + incomeParams[1] + "')");

                DataRow[] filteredRow = dtIncomeDetailsGrid.Select(filterQuery);
                dtIncomeDetailsGrid.Rows.Remove(filteredRow[0]);

                if (dtIncomeDetailsGrid.Rows.Count > 0)
                {
                    Session[SessionKeys.GV_INCOME_DETAILS] = dtIncomeDetailsGrid;
                    gvIncomeDetail.DataSource = dtIncomeDetailsGrid;
                    gvIncomeDetail.DataBind();

                    Double dblTotalIncome = 0.0;
                    if (dtIncomeDetailsGrid != null && dtIncomeDetailsGrid.Rows.Count > 0)
                    {
                        foreach (var incomeDetailRow in dtIncomeDetailsGrid.AsEnumerable())
                        {
                            Double dblCurrIncome = 0.0;
                            Double.TryParse(incomeDetailRow[5].ToString(), out dblCurrIncome);
                            dblTotalIncome = dblTotalIncome + dblCurrIncome;
                        }

                        lblTotalIncome.Text = dblTotalIncome.ToString();
                    }
                }
                else
                {
                    LoadEmptyIncomeDetailsGrid();
                    lblTotalIncome.Text = String.Empty;
                }

                UpdateCREClassification();
                btnSubmit.Enabled = true;
            }
        }
    }

    protected void gvIncomeDetail_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //This empty method is created only to handle ROW_EDIT event raised during DELETE operation.
        //If this methoed is not created, then DELETE operation in GRID 'gvIncomeDetail' will not work.
    }

    protected void gvIncomeDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //This empty method is created only to handle ROW_DELETE event raised during DELETE operation.
        //If this methoed is not created, then DELETE operation in GRID 'gvIncomeDetail' will not work.
    }

    protected void gvObligationDetail_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (Session[SessionKeys.GV_OBLIGATION_DETAILS] != null)
        {
            DataTable dtObligationDetailsGrid = (DataTable)Session[SessionKeys.GV_OBLIGATION_DETAILS];

            if (e.CommandName == "Delete")
            {
                btnSubmit.Enabled = false;
                string[] incomeParams = e.CommandArgument.ToString().Split('/');

                String filterQuery = ("NAME = '" + incomeParams[0] + "' AND ( LOAN_TYPE = '" + incomeParams[1] + "' AND ( SOURCE_OF_LOAN_IDENTIFICATION = '" + incomeParams[2] + "'))");

                DataRow[] filteredRow = dtObligationDetailsGrid.Select(filterQuery);
                dtObligationDetailsGrid.Rows.Remove(filteredRow[0]);

                if (dtObligationDetailsGrid.Rows.Count > 0)
                {
                    Session[SessionKeys.GV_OBLIGATION_DETAILS] = dtObligationDetailsGrid;
                    gvObligationDetail.DataSource = dtObligationDetailsGrid;
                    gvObligationDetail.DataBind();

                    Double dblTotalObligation = 0.0;
                    if (dtObligationDetailsGrid != null && dtObligationDetailsGrid.Rows.Count > 0)
                    {
                        foreach (var obligationDetailRow in dtObligationDetailsGrid.AsEnumerable())
                        {
                            Double dblCurrObligation = 0.0;
                            Double.TryParse(obligationDetailRow[10].ToString(), out dblCurrObligation);
                            dblTotalObligation = dblTotalObligation + dblCurrObligation;
                        }

                        lblTotalObligation.Text = dblTotalObligation.ToString();
                    }
                }
                else
                {
                    LoadEmptyObligationDetailsGrid();
                    lblTotalObligation.Text = String.Empty;
                }
                btnSubmit.Enabled = true;
            }
        }
    }

    protected void gvObligationDetail_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //This empty method is created only to handle ROW_EDIT event raised during DELETE operation.
        //If this methoed is not created, then DELETE operation in GRID 'gvObligationDetail' will not work.
    }

    protected void gvObligationDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //This empty method is created only to handle ROW_DELETE event raised during DELETE operation.
        //If this methoed is not created, then DELETE operation in GRID 'gvObligationDetail' will not work.
    }

    #endregion

    #region DROPDOWN EVENTS

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            using (sqlConn = new SqlConnection(_ConnStr))
            {
                sqlConn.Open();
                sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_MR_BRANCH_BY_AREA, sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandTimeout = 1200000;
                sqlCmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != AppConstants.DropdownDefaultSelection ? ddlArea.SelectedItem.ToString() : "");
                sqlDtAdptr = new SqlDataAdapter(sqlCmd);
                dtSet = new DataSet();
                sqlDtAdptr.Fill(dtSet);
                sqlConn.Close();
            }

            ddlBranch.DataSource = dtSet;
            ddlBranch.DataTextField = AppConstants.Col_BR_NAME;
            ddlBranch.DataValueField = AppConstants.Col_BR_NAME;
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            ddlBranch.Enabled = true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void ddlApplicantName_Income_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlApplicantName_Income.SelectedItem.Text != AppConstants.DropdownDefaultSelection)
        {
            if (Session[SessionKeys.DIS_LEAD_KYC_DETAILS] != null)
            {
                DataTable leadKycDetails = (DataTable)Session[SessionKeys.DIS_LEAD_KYC_DETAILS];
                Int32 kycId = Convert.ToInt32(ddlApplicantName_Income.SelectedValue);

                if (leadKycDetails != null && leadKycDetails.Rows.Count > 0)
                {
                    DataRow drLeadKyc = leadKycDetails.AsEnumerable().Where(obj => obj.Field<Int32>(AppConstants.Col_KYC_ID) == kycId).FirstOrDefault();
                    lblApplicantType_Income.Text = Convert.ToString(drLeadKyc[AppConstants.Col_KYC_APPL_TYPE]);
                }
            }
        }
    }

    protected void ddlApplicantName_Obligation_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlApplicantName_Obligation.SelectedItem.Text != AppConstants.DropdownDefaultSelection)
        {
            if (Session[SessionKeys.DIS_LEAD_KYC_DETAILS] != null)
            {
                DataTable leadKycDetails = (DataTable)Session[SessionKeys.DIS_LEAD_KYC_DETAILS];
                Int32 kycId = Convert.ToInt32(ddlApplicantName_Obligation.SelectedValue);

                if (leadKycDetails != null && leadKycDetails.Rows.Count > 0)
                {
                    DataRow drLeadKyc = leadKycDetails.AsEnumerable().Where(obj => obj.Field<Int32>(AppConstants.Col_KYC_ID) == kycId).FirstOrDefault();
                    lblApplicantType_Obligation.Text = Convert.ToString(drLeadKyc[AppConstants.Col_KYC_APPL_TYPE]);
                }
            }
        }
    }

    #endregion

    #region BUTTON EVENTS

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            if (ValidateSearchPanelDataIntegrity())
            {
                Reset();
                DisplayOnlySearchPanel();
                BindQueryGrid();

                foreach (GridViewRow grow in gvCreditApprovalLeads.Rows)
                {
                    Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                    int index = grow.RowIndex;

                    if (lblQryResult.Text == "T")
                    {
                        gvCreditApprovalLeads.Rows[index].Cells[1].ForeColor = Color.Red;
                        gvCreditApprovalLeads.Rows[index].Cells[2].ForeColor = Color.Red;
                        gvCreditApprovalLeads.Rows[index].Cells[3].ForeColor = Color.Red;
                        gvCreditApprovalLeads.Rows[index].Cells[4].ForeColor = Color.Red;
                        gvCreditApprovalLeads.Rows[index].Cells[5].ForeColor = Color.Red;
                        gvCreditApprovalLeads.Rows[index].Cells[6].ForeColor = Color.Red;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_GENERIC, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {

    }

    protected void btnAddIncome_Click(object sender, EventArgs e)
    {
        try
        {
            if (ValidateIncomeDetailsIntegrity())
            {
                Int64 leadId = 0;
                Int64 kycId = 0;
                var applName = ddlApplicantName_Income.SelectedItem.Text;
                var applType = lblApplicantType_Income.Text;
                var natureOfIncome = ddlNatureOfIncome_Income.SelectedItem.Text;

                Double income = Convert.ToDouble(txtBxIncome_Income.Text);
                income = Math.Round(income, 2);

                if (Session[SessionKeys.DIS_LEAD_KYC_DETAILS] != null)
                {
                    DataTable leadKycDetails = (DataTable)Session[SessionKeys.DIS_LEAD_KYC_DETAILS];
                    kycId = Convert.ToInt64(ddlApplicantName_Income.SelectedValue);

                    if (leadKycDetails != null && leadKycDetails.Rows.Count > 0)
                    {
                        DataRow drLeadKyc = leadKycDetails.AsEnumerable().Where(obj => obj.Field<Int32>(AppConstants.Col_KYC_ID) == kycId).FirstOrDefault();
                        leadId = Convert.ToInt64(drLeadKyc[AppConstants.GV_COL_KYC_LEAD_ID]);
                    }
                }

                DataTable incomeDetailsGrid = (DataTable)Session[SessionKeys.GV_INCOME_DETAILS];

                if (incomeDetailsGrid.Rows.Count > 0 && incomeDetailsGrid.Rows[0][0].ToString() == "")
                {
                    incomeDetailsGrid.Rows.RemoveAt(0);
                }

                DataRow incomeDetailRow = incomeDetailsGrid.NewRow();

                incomeDetailRow[AppConstants.GV_COL_KYC_LEAD_ID] = leadId;
                incomeDetailRow[AppConstants.GV_COL_KYC_ID] = kycId;
                incomeDetailRow[AppConstants.GV_COL_NAME] = applName;
                incomeDetailRow[AppConstants.GV_COL_APPL_TYPE] = applType;
                incomeDetailRow[AppConstants.GV_COL_INCOME_SOURCE] = natureOfIncome;
                incomeDetailRow[AppConstants.GV_COL_INCOME] = income;

                String duplicateCheckQuery = "NAME = '" + applName + "' AND INCOME_SOURCE = '" + natureOfIncome + "'";
                DataRow[] duplicateRow = incomeDetailsGrid.Select(duplicateCheckQuery);

                if (duplicateRow.Length == 0)
                {
                    incomeDetailsGrid.Rows.Add(incomeDetailRow);
                    Session[SessionKeys.GV_INCOME_DETAILS] = incomeDetailsGrid;
                    gvIncomeDetail.DataSource = incomeDetailsGrid;
                    gvIncomeDetail.DataBind();

                    Double totIncome = 0;
                    Double currIncome = 0;
                    Double.TryParse(lblTotalIncome.Text, out totIncome);
                    currIncome = income;

                    if (currIncome > 0)
                    {
                        totIncome = totIncome + currIncome;
                        lblTotalIncome.Text = Convert.ToString(totIncome);
                    }
                }
                else
                {
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_ERR_DUPLICATE_APPL_NATURE_OF_INCOME, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                UpdateCREClassification();
                ResetIncomeDetailsGrid();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void btnAddObligation_Click(object sender, EventArgs e)
    {
        try
        {
            if (ValidateObligationDetailsIntegrity())
            {
                Int64 leadId = 0;
                Int64 kycId = 0;
                var applName = ddlApplicantName_Obligation.SelectedItem.Text;
                var applType = lblApplicantType_Obligation.Text;
                var financier = txtBxFinancier_Obligation.Text;
                var loanType = ddlLoanType_Obligation.SelectedItem.Value;
                var sourceOfLoan = ddlSourceOfLoanIdentification_Obligation.SelectedItem.Value;

                Int64 cibil = Convert.ToInt64(txtBxCibil_Obligation.Text);

                Double emi = Convert.ToDouble(txtBxEMIAmount_Obligation.Text);
                emi = Math.Round(emi, 2);

                Double balNoOfEmi = Convert.ToDouble(txtBxBalNoOfEMI_Obligation.Text);

                DataTable obligationDetailsGrid = (DataTable)Session[SessionKeys.GV_OBLIGATION_DETAILS];

                if (Session[SessionKeys.DIS_LEAD_KYC_DETAILS] != null)
                {
                    DataTable leadKycDetails = (DataTable)Session[SessionKeys.DIS_LEAD_KYC_DETAILS];
                    kycId = Convert.ToInt64(ddlApplicantName_Obligation.SelectedValue);

                    if (leadKycDetails != null && leadKycDetails.Rows.Count > 0)
                    {
                        DataRow drLeadKyc = leadKycDetails.AsEnumerable().Where(obj => obj.Field<Int32>(AppConstants.Col_KYC_ID) == kycId).FirstOrDefault();
                        leadId = Convert.ToInt64(drLeadKyc[AppConstants.GV_COL_KYC_LEAD_ID]);
                    }
                }

                if (obligationDetailsGrid.Rows.Count > 0 && obligationDetailsGrid.Rows[0][0].ToString() == "")
                {
                    obligationDetailsGrid.Rows.RemoveAt(0);
                }

                DataRow obligationDetailRow = obligationDetailsGrid.NewRow();

                obligationDetailRow[AppConstants.GV_COL_KYC_LEAD_ID] = leadId;
                obligationDetailRow[AppConstants.GV_COL_KYC_ID] = kycId;
                obligationDetailRow[AppConstants.GV_COL_NAME] = applName;
                obligationDetailRow[AppConstants.GV_COL_APPL_TYPE] = applType;
                obligationDetailRow[AppConstants.GV_COL_FINANCIER] = financier;
                obligationDetailRow[AppConstants.GV_COL_LOAN_TYPE] = loanType;
                obligationDetailRow[AppConstants.GV_COL_SOURCE_OF_LOAN_IDENTIFICATION] = sourceOfLoan;
                obligationDetailRow[AppConstants.GV_COL_CIBIL] = cibil;
                obligationDetailRow[AppConstants.GV_COL_EMI] = emi;
                obligationDetailRow[AppConstants.GV_COL_BALANCE_NO_OF_EMI] = balNoOfEmi;

                Double totObligation = 0;
                Double currObligation = 0;
                Double.TryParse(lblTotalObligation.Text, out totObligation);

                currObligation = emi;
                currObligation = Math.Round(currObligation, 2);
                obligationDetailRow[AppConstants.GV_COL_OBLIGATION_AMOUNT] = currObligation;

                String duplicateCheckQuery = "NAME = '" + applName + "' AND LOAN_TYPE = '" + loanType + "'  AND SOURCE_OF_LOAN_IDENTIFICATION = '" + sourceOfLoan + "'";
                DataRow[] duplicateRow = obligationDetailsGrid.Select(duplicateCheckQuery);

                if (duplicateRow.Length == 0)
                {
                    obligationDetailsGrid.Rows.Add(obligationDetailRow);
                    Session[SessionKeys.GV_OBLIGATION_DETAILS] = obligationDetailsGrid;
                    gvObligationDetail.DataSource = obligationDetailsGrid;
                    gvObligationDetail.DataBind();

                    if (currObligation > 0)
                    {
                        totObligation = totObligation + currObligation;
                        totObligation = Math.Round(totObligation, 2);
                        lblTotalObligation.Text = Convert.ToString(totObligation);
                    }
                }
                else
                {
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_ERR_DUPLICATE_APPL_NATURE_OF_OBLIGATION, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                ResetObligationDetailsGrid();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (ValidateDISMemoDataIntegrity())
            {
                SaveDeclaredIncomeSummary();
                SaveDeclaredIncomeDetails();
                SaveDeclaredObligationDetails();

                if (_saveDISSuccess && _saveIncomeDetailsSuccess && (_saveObligationDetailsSuccess || _obligationDetailsNotAvailable))
                {
                    Reset();
                    DisplayOnlySearchPanel();

                    uscMsgBox1.AddMessage(Credit_BusinessMessages.SAVE_DIS_SUCCESS, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_GENERIC, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }

    #endregion

    #region RADIO-BUTTON EVENTS

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            Reset();

            Label lblLeadID = null;
            Label lblLglAprvl = null;
            DataSet dtSetLeadDetails = new DataSet();

            foreach (GridViewRow grow in gvCreditApprovalLeads.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                int index = grow.RowIndex;

                if (chkStat.Checked)
                {
                    lblLeadID = (Label)gvCreditApprovalLeads.Rows[index].Cells[1].FindControl("lblLeadID");
                    lblLglAprvl = (Label)gvCreditApprovalLeads.Rows[index].Cells[1].FindControl("lblLgAprvl");

                    Label lblMPS_ID = grow.FindControl("lblMPSId") as Label;
                    Label lblPR_ID = grow.FindControl("lblPRId") as Label;
                    Label lblldAcNo = grow.FindControl("lblldAcNo") as Label;
                    Label lblprcde = grow.FindControl("lblprcde") as Label;

                    _leadNo = gvCreditApprovalLeads.Rows[index].Cells[1].Text;
                    _applName = gvCreditApprovalLeads.Rows[index].Cells[3].Text;
                    _product = gvCreditApprovalLeads.Rows[index].Cells[4].Text;
                    _loanAmt = gvCreditApprovalLeads.Rows[index].Cells[5].Text;

                    Session[SessionKeys.LeadId] = lblLeadID.Text;
                    Session[SessionKeys.Leadno] = _leadNo;
                    Session[SessionKeys.LoanAmt] = _loanAmt;
                    Session[SessionKeys.lblLdAcNo] = lblldAcNo.Text;
                    Session[SessionKeys.ApplName] = _applName;
                    Session[SessionKeys.MPS_ID] = lblMPS_ID.Text;
                    Session[SessionKeys.PR_ID] = lblPR_ID.Text;

                    Int64 prodId = Convert.ToInt64(lblPR_ID.Text);

                    LoadEmptyIncomeDetailsGrid();
                    LoadEmptyObligationDetailsGrid();

                    ViewState[AppConstants.CreditConditionVisible] = _creditConditionsVisible = true;
                    ViewState[AppConstants.DeviationVisible] = _deviationsVisible = true;

                    lblFileApprovedBy.Text = Session[SessionKeys.EMPNAME] != null ? Session[SessionKeys.EMPNAME].ToString() : String.Empty;
                    lblApprovedDate.Text = String.Format(AppConstants.FORMAT_DateTime_DDMMYYYY, DateTime.Now);

                    dtSetLeadDetails = GetLeadApplicantDetails();

                    if (dtSetLeadDetails != null
                        && dtSetLeadDetails.Tables.Count == 2
                        && dtSetLeadDetails.Tables[0].Rows.Count > 0
                        && dtSetLeadDetails.Tables[1].Rows.Count > 0)
                    {
                        tblApprovalSummary.Visible = true;

                        incomeDetailsPanel.Visible = true;
                        obligationDetailsPanel.Visible = true;

                        tblIncomeDetails.Visible = true;
                        gvIncomeDetail.Visible = true;
                        tblTotalIncome.Visible = true;

                        tblObligationDetails.Visible = true;
                        gvObligationDetail.Visible = true;
                        tblTotalObligation.Visible = true;

                        txtBxDeviations.Visible = true;
                        lblDeviationRemainingChars.Visible = true;

                        txtBxCreditConditions.Visible = true;
                        lblCreditConditionsRemainingChars.Visible = true;

                        tblPropertyDetails.Visible = true;
                        tblFinalRecommendation.Visible = true;

                        tblConditions.Visible = true;

                        submitPanel.Visible = true;

                        if ((prodId == Convert.ToInt64(Declared_Product_Program.IB_SME_Secured_D))
                            || (prodId == Convert.ToInt64(Declared_Product_Program.Salaried_LAP))
                            || (prodId == Convert.ToInt64(Declared_Product_Program.IB_Mainstream_LAP)))
                        {
                            tblCREClassificationSMESLAP.Visible = true;
                            SME_SLAP_Built_UpArea.Visible = true;
                            SME_SLAP_Built_UpCost.Visible = true;
                            SME_SLAP_BuildingCost.Visible = true;

                            tblCREClassificationAHF.Visible = false;
                            AHF_Built_UpArea.Visible = false;
                            AHF_Built_UpCost.Visible = false;
                            AHF_BuildingValue.Visible = false;

                            AHF_LCR.Visible = false;
                            AHF_NO_OF_PROPERTY_ALREADY_OWNED.Visible = false;
                            AHF_NO_OF_PROPERTY_TO_BE_OWNED.Visible = false;
                        }
                        else if (prodId == Convert.ToInt64(Declared_Product_Program.Housing_IB_AHF)
                            || prodId == Convert.ToInt64(Declared_Product_Program.IB_Affordable_Home))
                        {
                            tblCREClassificationSMESLAP.Visible = false;
                            SME_SLAP_Built_UpArea.Visible = false;
                            SME_SLAP_Built_UpCost.Visible = false;
                            SME_SLAP_BuildingCost.Visible = false;

                            tblCREClassificationAHF.Visible = true;
                            AHF_Built_UpArea.Visible = true;
                            AHF_Built_UpCost.Visible = true;
                            AHF_BuildingValue.Visible = true;

                            AHF_LCR.Visible = true;
                            AHF_NO_OF_PROPERTY_ALREADY_OWNED.Visible = true;
                            AHF_NO_OF_PROPERTY_TO_BE_OWNED.Visible = true;
                        }

                        LoadDropdownMasterData();

                        DataTable dtLeadDetails = dtSetLeadDetails.Tables[0];

                        if (dtLeadDetails != null && dtLeadDetails.Rows.Count > 0)
                        {
                            lblLeadNo.Text = dtLeadDetails.Rows[0]["LD_NO"] != DBNull.Value ? dtLeadDetails.Rows[0]["LD_NO"].ToString() : "";
                            lblProduct.Text = dtLeadDetails.Rows[0]["PR_CODE"] != DBNull.Value ? dtLeadDetails.Rows[0]["PR_CODE"].ToString() : "";
                            lblCustName.Text = dtLeadDetails.Rows[0]["LD_APNAME"] != DBNull.Value ? dtLeadDetails.Rows[0]["LD_APNAME"].ToString() : "";

                            if (dtLeadDetails.Rows[0]["AR_NAME"] != DBNull.Value && dtLeadDetails.Rows[0]["BR_NAME"] != DBNull.Value)
                            {
                                String areaBranch = dtLeadDetails.Rows[0]["AR_NAME"].ToString() + "/" + dtLeadDetails.Rows[0]["BR_NAME"].ToString();
                                lblAreaBranch.Text = !String.IsNullOrEmpty(areaBranch) ? areaBranch : String.Empty;
                            }

                            if (prodId == Convert.ToInt64(Declared_Product_Program.Salaried_LAP))
                            {
                                ddlProgram.Enabled = false;
                                ddlProgram.SelectedValue = "NIP";
                            }
                        }

                        DataTable dtLeadKycDetails = dtSetLeadDetails.Tables[1];
                        Int64 leadApplCount = dtLeadKycDetails.Rows.Count;

                        if (leadApplCount > 0)
                        {
                            Session[SessionKeys.DIS_LEAD_KYC_DETAILS] = dtLeadKycDetails;
                            ddlApplicantName_Income.DataSource = dtLeadKycDetails;
                            ddlApplicantName_Income.DataValueField = AppConstants.Col_KYC_ID;
                            ddlApplicantName_Income.DataTextField = AppConstants.Col_KYC_NAME;
                            ddlApplicantName_Income.DataBind();
                            ddlApplicantName_Income.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));

                            ddlApplicantName_Obligation.DataSource = dtLeadKycDetails;
                            ddlApplicantName_Obligation.DataValueField = AppConstants.Col_KYC_ID;
                            ddlApplicantName_Obligation.DataTextField = AppConstants.Col_KYC_NAME;
                            ddlApplicantName_Obligation.DataBind();
                            ddlApplicantName_Obligation.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
                        }

                        btnSubmit.Enabled = true;
                        btnCancel.Enabled = true;
                    }
                    else
                    {
                        uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_NO_KYC_AVAILABLE, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_GENERIC, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }

    #endregion

    #region TEXTBOX EVENTS
    protected void PropertyValue_OnTextChanged(object sender, EventArgs e)
    {
        bool _passValidation = true;

        //Land Area Data validity
        if (_passValidation
            && txtBxLandAreaInSqft != null
            && txtBxLandAreaInSqft.Text != String.Empty
            && !FormValidations.IsLandAreaValid(txtBxLandAreaInSqft.Text))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_LAND_AREA_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }

        //Land value Data validity
        if (_passValidation
            && txtBxLandValuePerSqft != null
            && txtBxLandValuePerSqft.Text != String.Empty
            && !FormValidations.IsLandAreaCostPerSqftValid(txtBxLandValuePerSqft.Text))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_LAND_VALUE_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }

        //Buildup Area and Cost for SME & SLAP products
        if (_passValidation
            && (SME_SLAP_Built_UpArea != null && SME_SLAP_Built_UpArea.Visible == true)
            && (SME_SLAP_Built_UpCost != null && SME_SLAP_Built_UpCost.Visible == true))
        {
            //Buildup Area Data validity
            if (_passValidation
                && txtBxBuiltUpAreaInSqft != null
                && txtBxBuiltUpAreaInSqft.Text != String.Empty
                && !FormValidations.IsLandAreaValid(txtBxBuiltUpAreaInSqft.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_BUILDUP_AREA_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            //Buildup cost Data validity
            if (_passValidation
                && txtBxBuildUpCostPerSqft != null
                && txtBxBuildUpCostPerSqft.Text != String.Empty
                && !FormValidations.IsLandAreaCostPerSqftValid(txtBxBuildUpCostPerSqft.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_BUILDUP_COST_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }

        //Constrution Area and Value for AHF products
        if (_passValidation
            && (AHF_Built_UpArea != null && AHF_Built_UpArea.Visible == true)
            && (AHF_Built_UpCost != null && AHF_Built_UpCost.Visible == true))
        {
            //Constrution Area Data validity
            if (_passValidation
                && txtBxConstructionAreaInSqft != null
                && txtBxConstructionAreaInSqft.Text != String.Empty
                && !FormValidations.IsLandAreaValid(txtBxConstructionAreaInSqft.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_CONSTRUCTION_AREA_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            //Constrution cost Data validity
            if (_passValidation
                && txtBxConstructionCostPerSqft != null
                && txtBxConstructionCostPerSqft.Text != String.Empty
                && !FormValidations.IsLandAreaCostPerSqftValid(txtBxConstructionCostPerSqft.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_CONSTRUCTION_COST_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }

        //Amenities data validity
        if (_passValidation
            && txtBxAmenities != null
            && txtBxAmenities.Text != String.Empty
            && !FormValidations.IsAmenitiesValid(txtBxAmenities.Text))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_AMENITIES_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }

        if (_passValidation) { CalculateTotalPropertyValue(); }
    }

    protected void FinalLoanAmount_OnTextChanged(object sender, EventArgs e)
    {
        //Loan Amount mandatory
        if (txtBxFinalLoanAmount != null && txtBxFinalLoanAmount.Text == String.Empty)
        {
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_FINAL_LOAN_AMOUNT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        //Loan Amount data validity
        else if (txtBxFinalLoanAmount != null && !FormValidations.AllowDecimals(txtBxFinalLoanAmount.Text))
        {
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_FINAL_LOAN_AMOUNT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            CalculateEMI();
        }
    }

    protected void Tenor_OnTextChanged(object sender, EventArgs e)
    {
        try
        {
            //Tenor
            if (txtBxTenor != null && txtBxTenor.Text == String.Empty)
            {
                uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_TENOR_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            //Tenor data validity
            if (txtBxTenor != null && txtBxTenor.Text != String.Empty && !FormValidations.IsTenorValid(txtBxTenor.Text))
            {
                uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_TENOR_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void ROI_OnTextChanged(object sender, EventArgs e)
    {
        try
        {
            //Rate Of Interest mandatory
            if (txtBxROI != null && txtBxROI.Text == String.Empty)
            {
                uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_ROI_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Rate Of Interest data validity
            else if (!FormValidations.IsROIValid(txtBxROI.Text))
            {
                StringBuilder sb = new StringBuilder();
                foreach (char c in txtBxROI.Text)
                {
                    if ((c >= '0' && c <= '9') || c == '.')
                    {
                        sb.Append(c);
                    }
                }
                txtBxROI.Text = sb.ToString();

                uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_ROI_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected bool NoOfPropertyOwned_OnTextChanged()
    {
        bool _passValidation = true;

        //AHF No Of Property Owned / to be Owned
        if ((AHF_NO_OF_PROPERTY_ALREADY_OWNED != null && AHF_NO_OF_PROPERTY_ALREADY_OWNED.Visible == true)
            && (AHF_NO_OF_PROPERTY_TO_BE_OWNED != null && AHF_NO_OF_PROPERTY_TO_BE_OWNED.Visible == true))
        {
            //AHF No Of Property Already Owned Mandatory
            //if (_passValidation && (txtBxNoOfPropertyAlreadyOwned != null && txtBxNoOfPropertyAlreadyOwned.Text == String.Empty))
            //{
            //    _passValidation = false;
            //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_NO_OF_PROPERTY_ALREADY_OWNED_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}

            //No Of Property already owned Data validity
            if (_passValidation
                && txtBxNoOfPropertyAlreadyOwned != null
                && txtBxNoOfPropertyAlreadyOwned.Text != String.Empty
                && !FormValidations.IsNoOfPropertiesValid(txtBxNoOfPropertyAlreadyOwned.Text))
            {
                _passValidation = false;
                txtBxNoOfPropertyAlreadyOwned.Text = String.Empty;
                uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_NO_OF_PROPERTY_ALREADY_OWNED_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            //AHF No Of Property to be Owned Mandatory
            //if (_passValidation && (txtBxNoOfPropertyToBeOwned != null && txtBxNoOfPropertyToBeOwned.Text == String.Empty))
            //{
            //    _passValidation = false;
            //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_NO_OF_PROPERTY_TO_BE_OWNED_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}

            //No Of Property to be owned Data validity
            if (_passValidation
                && txtBxNoOfPropertyToBeOwned != null
                && txtBxNoOfPropertyToBeOwned.Text != String.Empty
                && !FormValidations.IsNoOfPropertiesValid(txtBxNoOfPropertyToBeOwned.Text))
            {
                _passValidation = false;
                txtBxNoOfPropertyToBeOwned.Text = String.Empty;
                uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_NO_OF_PROPERTY_TO_BE_OWNED_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }

        return _passValidation;
    }

    protected void AHF_CRE_Clasification_OnTextChanged(object sender, EventArgs e)
    {
        if (NoOfPropertyOwned_OnTextChanged())
        {
            UpdateCREClassification();
        }
    }

    #endregion

    #region CRUD

    #region GET
    private void BindSearchPanel()
    {
        try
        {
            using (sqlConn = new SqlConnection(_ConnStr))
            {
                sqlConn.Open();
                sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_MR_AREA, sqlConn);
                sqlCmd.CommandTimeout = 1200000;
                sqlDtAdptr = new SqlDataAdapter(sqlCmd);
                dtSet = new DataSet();
                sqlDtAdptr.Fill(dtSet);
            }

            ddlArea.DataSource = dtSet;
            ddlArea.DataTextField = AppConstants.Col_AR_NAME;
            ddlArea.DataValueField = AppConstants.Col_AR_ID;
            ddlArea.DataBind();
            ddlArea.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindQueryGrid()
    {
        try
        {
            using (sqlConn = new SqlConnection(_ConnStr))
            {
                sqlConn.Open();
                sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_DECLARED_SME_SLAP_AHF, sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandTimeout = 1200000;

                sqlCmd.Parameters.AddWithValue(AppConstants.Param_View, Session["View"].ToString());
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_LD_NO, txtBxLeadno.Text);

                sqlCmd.Parameters.AddWithValue(AppConstants.Param_AR_NAME,
                    ddlArea.SelectedItem.Text != AppConstants.DropdownDefaultSelection ? ddlArea.SelectedItem.Text.ToString() : String.Empty);

                sqlCmd.Parameters.AddWithValue(AppConstants.Param_BR_NAME,
                    (ddlBranch.Items.Count > 0 && ddlBranch.SelectedItem.Text != AppConstants.DropdownDefaultSelection) ? ddlBranch.SelectedItem.Text.ToString() : String.Empty);

                sqlCmd.Parameters.AddWithValue(AppConstants.Param_FT_SENTBY, "B");
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_FT_SENTTO, "C");

                sqlDtAdptr = new SqlDataAdapter(sqlCmd);
                dtSet = new DataSet();
                sqlDtAdptr.Fill(dtSet);
            }

            if (dtSet.Tables[0].Rows.Count > 0)
            {
                gvCreditApprovalLeads.Visible = true;
                gvCreditApprovalLeads.DataSource = dtSet.Tables[0];
                gvCreditApprovalLeads.DataBind();

                if (dtSet.Tables[0].Rows.Count > 0)
                {
                    gvCreditApprovalLeads.HeaderRow.Font.Bold = true;
                    gvCreditApprovalLeads.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvCreditApprovalLeads.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvCreditApprovalLeads.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    gvCreditApprovalLeads.HeaderRow.Cells[4].Text = "PD DATE";
                    gvCreditApprovalLeads.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                    gvCreditApprovalLeads.HeaderRow.Cells[1].Wrap = false;
                    gvCreditApprovalLeads.HeaderRow.Cells[2].Wrap = false;
                    gvCreditApprovalLeads.HeaderRow.Cells[3].Wrap = false;
                    gvCreditApprovalLeads.HeaderRow.Cells[4].Wrap = false;
                    gvCreditApprovalLeads.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_NO_RECORDS_AVAILABLE, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvCreditApprovalLeads.Visible = false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private DataSet GetLeadApplicantDetails()
    {
        try
        {
            using (sqlConn = new SqlConnection(_ConnStr))
            {
                sqlConn.Open();
                sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_LEAD_APPLICANT_DETAILS, sqlConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandTimeout = 1200000;
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_Lead_Id, Session[SessionKeys.LeadId].ToString());
                sqlDtAdptr = new SqlDataAdapter(sqlCmd);
                dtSet = new DataSet();
                sqlDtAdptr.Fill(dtSet);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return dtSet;
    }

    private void LoadDropdownMasterData()
    {
        try
        {
            DataTable dtPrograms = commonClsObj.GetDropDownItemsByGroup(AppConstants.DdlGroup_DIS_PROGRAMS);
            if (dtPrograms != null && dtPrograms.Rows.Count > 0)
            {
                ddlProgram.DataSource = dtPrograms;
                ddlProgram.DataTextField = AppConstants.Col_ITEM_DESC;
                ddlProgram.DataValueField = AppConstants.Col_ITEM_KEY;
                ddlProgram.DataBind();
                ddlProgram.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }

            DataTable dtNatureOfIncome = commonClsObj.GetDropDownItemsByGroup(AppConstants.DdlGroup_NATURE_OF_INCOME);
            if (dtNatureOfIncome != null && dtNatureOfIncome.Rows.Count > 0)
            {
                ddlNatureOfIncome_Income.DataSource = dtNatureOfIncome;
                ddlNatureOfIncome_Income.DataTextField = AppConstants.Col_ITEM_DESC;
                ddlNatureOfIncome_Income.DataValueField = AppConstants.Col_ITEM_KEY;
                ddlNatureOfIncome_Income.DataBind();
                ddlNatureOfIncome_Income.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }

            DataTable dtLoanType = commonClsObj.GetDropDownItemsByGroup(AppConstants.DdlGroup_LOAN_TYPE);
            if (dtLoanType != null && dtLoanType.Rows.Count > 0)
            {
                ddlLoanType_Obligation.DataSource = dtLoanType;
                ddlLoanType_Obligation.DataTextField = AppConstants.Col_ITEM_DESC;
                ddlLoanType_Obligation.DataValueField = AppConstants.Col_ITEM_KEY;
                ddlLoanType_Obligation.DataBind();
                ddlLoanType_Obligation.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }

            DataTable dtSourceOfLoanIdentification = commonClsObj.GetDropDownItemsByGroup(AppConstants.DdlGroup_SOURCE_OF_LOAN_IDENTIFICATION);
            if (dtSourceOfLoanIdentification != null && dtSourceOfLoanIdentification.Rows.Count > 0)
            {
                ddlSourceOfLoanIdentification_Obligation.DataSource = dtSourceOfLoanIdentification;
                ddlSourceOfLoanIdentification_Obligation.DataTextField = AppConstants.Col_ITEM_DESC;
                ddlSourceOfLoanIdentification_Obligation.DataValueField = AppConstants.Col_ITEM_KEY;
                ddlSourceOfLoanIdentification_Obligation.DataBind();
                ddlSourceOfLoanIdentification_Obligation.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }

            DataTable dtPropertyType = commonClsObj.GetDropDownItemsByGroup(AppConstants.DdlGroup_PROPERTY_TYPE);
            if (dtPropertyType != null && dtPropertyType.Rows.Count > 0)
            {
                ddlPropertyType.DataSource = dtPropertyType;
                ddlPropertyType.DataTextField = AppConstants.Col_ITEM_DESC;
                ddlPropertyType.DataValueField = AppConstants.Col_ITEM_KEY;
                ddlPropertyType.DataBind();
                ddlPropertyType.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }

            DataTable dtOccupancyStatus = commonClsObj.GetDropDownItemsByGroup(AppConstants.DdlGroup_OCCUPANCY_STATUS);
            if (dtOccupancyStatus != null && dtOccupancyStatus.Rows.Count > 0)
            {
                ddlOccupancyStatus.DataSource = dtOccupancyStatus;
                ddlOccupancyStatus.DataTextField = AppConstants.Col_ITEM_DESC;
                ddlOccupancyStatus.DataValueField = AppConstants.Col_ITEM_KEY;
                ddlOccupancyStatus.DataBind();
                ddlOccupancyStatus.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }

            if (tblCREClassificationSMESLAP != null && tblCREClassificationSMESLAP.Visible == true)
            {
                DataTable dtCREClassificationSMESLAP = commonClsObj.GetDropDownItemsByGroupAndSubGroup(AppConstants.DdlGroup_CRE_CLASSIFICATION, AppConstants.DdlSubGroup_CRE_CLASSIFICATION_SME_SLAP);
                if (dtCREClassificationSMESLAP != null && dtCREClassificationSMESLAP.Rows.Count > 0)
                {
                    ddlCREClassificationSMESLAP.DataSource = dtCREClassificationSMESLAP;
                    ddlCREClassificationSMESLAP.DataTextField = AppConstants.Col_ITEM_DESC;
                    ddlCREClassificationSMESLAP.DataValueField = AppConstants.Col_ITEM_KEY;
                    ddlCREClassificationSMESLAP.DataBind();
                    ddlCREClassificationSMESLAP.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
                }
            }

            if (tblCREClassificationAHF != null && tblCREClassificationAHF.Visible == true)
            {
                DataTable dtCREClassificationAHF = commonClsObj.GetDropDownItemsByGroupAndSubGroup(AppConstants.DdlGroup_CRE_CLASSIFICATION, AppConstants.DdlSubGroup_CRE_CLASSIFICATION_AHF);
                if (dtCREClassificationAHF != null && dtCREClassificationAHF.Rows.Count > 0)
                {
                    ddlCREClassificationAHF.DataSource = dtCREClassificationAHF;
                    ddlCREClassificationAHF.DataTextField = AppConstants.Col_ITEM_DESC;
                    ddlCREClassificationAHF.DataValueField = AppConstants.Col_ITEM_KEY;
                    ddlCREClassificationAHF.DataBind();
                    ddlCREClassificationAHF.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion

    #region INSERT
    private void SaveDeclaredIncomeSummary()
    {
        Double lArea = 0.0;
        Double lValue = 0.0;
        Double totLValue = 0.0;

        Double bValue = 0.0;
        Double bArea = 0.0;
        Double totBValue = 0.0;

        Double amenities = 0.0;
        Double totPropValue = 0.0;

        Double totIncome = 0.0;
        Double totOblig = 0.0;

        Int32 tenor = 0;

        Double roi = 0.0;
        Double finLoanAmt = 0.0;
        Double emi = 0.0;
        Double appIIR = 0.0;
        Double appFOIR = 0.0;
        Double ltv = 0.0;
        Double lcr = 0.0;

        Int32 noOfPropAlOwned = 0;
        Int32 noOfPropToBeOwned = 0;

        try
        {
            var leadId = Convert.ToInt32(Session[SessionKeys.LeadId]);
            var prog = ddlProgram.SelectedItem.Value;
            var pType = ddlPropertyType.SelectedItem.Value;
            var OccupStatus = ddlOccupancyStatus.SelectedItem.Value;

            Double.TryParse(txtBxLandAreaInSqft.Text, out lArea);
            Double.TryParse(txtBxLandValuePerSqft.Text, out lValue);
            totLValue = lArea * lValue;

            Double.TryParse(txtBxBuiltUpAreaInSqft.Text, out bArea);
            Double.TryParse(txtBxBuildUpCostPerSqft.Text, out bValue);
            totBValue = bArea * bValue;

            Double.TryParse(txtBxAmenities.Text, out amenities);
            Double.TryParse(lblTotalPropertyValue.Text, out totPropValue);

            Double.TryParse(lblTotalIncome.Text, out totIncome);
            Double.TryParse(lblTotalObligation.Text, out totOblig);

            Int32.TryParse(txtBxTenor.Text, out tenor);
            Double.TryParse(txtBxROI.Text, out roi);
            Double.TryParse(txtBxFinalLoanAmount.Text, out finLoanAmt);
            Double.TryParse(lblEMI.Text, out emi);
            Double.TryParse(lblApprovedIIR.Text, out appIIR);
            Double.TryParse(lblApprovedFOIR.Text, out appFOIR);
            Double.TryParse(lblLTV.Text, out ltv);

            if (AHF_NO_OF_PROPERTY_ALREADY_OWNED != null && AHF_NO_OF_PROPERTY_ALREADY_OWNED.Visible == true)
            {
                Int32.TryParse(txtBxNoOfPropertyAlreadyOwned.Text, out noOfPropAlOwned);
            }

            if (AHF_NO_OF_PROPERTY_TO_BE_OWNED != null && AHF_NO_OF_PROPERTY_TO_BE_OWNED.Visible == true)
            {
                Int32.TryParse(txtBxNoOfPropertyToBeOwned.Text, out noOfPropToBeOwned);
            }

            var cre = String.Empty;
            if (tblCREClassificationSMESLAP != null && tblCREClassificationSMESLAP.Visible == true)
            {
                cre = ddlCREClassificationSMESLAP.SelectedItem.Value;
            }
            else if (tblCREClassificationAHF != null && tblCREClassificationAHF.Visible == true)
            {
                cre = ddlCREClassificationAHF.SelectedItem.Value;
                Double.TryParse(lblLCR.Text, out lcr);
            }

            var deviations = txtBxDeviations.Text.Trim();
            var credConditions = txtBxCreditConditions.Text.Replace("\n", "<br/>");
            var fileRecommBy = txtBxFileRecommendedBy.Text.Trim();
            var fileApprvdBy = SessionEMP_ID;
            var fileOfflApprvdBy = txtBxOfflineMailApprovedBy.Text.Trim();

            DataTable resultTable = new DataTable();
            using (sqlConn = new SqlConnection(_ConnStr))
            {
                using (sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_DECLARED_INCOME_SUMMARY, sqlConn))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandTimeout = 1200000;
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_LD_ID, leadId);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_PROG, prog);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_PTYPE, pType);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_OCCSTAT, OccupStatus);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_LAREA, lArea);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_LVALUE, lValue);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_TOT_LVALUE, totLValue);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_BAREA, bArea);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_BVALUE, bValue);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_TOT_BVALUE, totBValue);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_AMENITIES, amenities);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_TOT_PVALUE, totPropValue);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_TOT_INCOME, totIncome);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_TOT_OBLIG, totOblig);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_TENOR, tenor);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_ROI, roi);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_FIN_LAMOUNT, finLoanAmt);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_EMI, emi);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_APP_IIR, appIIR);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_APP_FOIR, appFOIR);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_LTV, ltv);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_LCR, lcr);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_CRE, cre);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_NOP_AL_OWN, noOfPropAlOwned);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_NOP_TB_OWN, noOfPropToBeOwned);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_DEVIATION, deviations);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_CRDT_COND, credConditions);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_FILE_RECOMD_BY, fileRecommBy);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_FILE_APPRVD_BY, fileApprvdBy);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_FILE_OFFL_MAIL_APPRVD_BY, fileOfflApprvdBy);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_CBY, fileApprvdBy);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_DIS_MBY, fileApprvdBy);

                    using (sqlDtAdptr = new SqlDataAdapter(sqlCmd))
                    {
                        sqlDtAdptr.Fill(resultTable);
                        _saveDISSuccess = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _saveDISSuccess = false;
            throw ex;
        }
    }

    private void SaveDeclaredIncomeDetails()
    {
        try
        {
            if (gvIncomeDetail != null && gvIncomeDetail.Rows.Count > 0 && _saveDISSuccess)
            {
                DataTable dtGridIncomeDetails = (DataTable)Session[SessionKeys.GV_INCOME_DETAILS];
                DataTable dtDbIncomeDetails = CreateIncomeDetailsDbDataTable();
                DataRow drIncomeDetail;

                foreach (DataRow dataRow in dtGridIncomeDetails.Rows)
                {
                    drIncomeDetail = dtDbIncomeDetails.NewRow();

                    drIncomeDetail[AppConstants.Col_DID_LD_ID] = dataRow[AppConstants.GV_COL_KYC_LEAD_ID];
                    drIncomeDetail[AppConstants.Col_DID_KYC_ID] = dataRow[AppConstants.GV_COL_KYC_ID];
                    drIncomeDetail[AppConstants.Col_DID_NAT_OF_INCOME] = dataRow[AppConstants.GV_COL_INCOME_SOURCE];
                    drIncomeDetail[AppConstants.Col_DID_INCOME] = dataRow[AppConstants.GV_COL_INCOME];

                    dtDbIncomeDetails.Rows.Add(drIncomeDetail);
                }

                DataTable resultTable = new DataTable();
                using (sqlConn = new SqlConnection(_ConnStr))
                {
                    using (sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_DECLARED_INCOME_DETAILS, sqlConn))
                    {
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandTimeout = 1200000;
                        sqlCmd.Parameters.AddWithValue(AppConstants.Param_DT_DeclaredIncomeDetails, dtDbIncomeDetails);
                        sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, SessionEMP_ID);

                        using (sqlDtAdptr = new SqlDataAdapter(sqlCmd))
                        {
                            sqlDtAdptr.Fill(resultTable);
                            _saveIncomeDetailsSuccess = true;
                            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_INCOME_DETAIL_SAVE_SUCCESS, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _saveIncomeDetailsSuccess = false;
            throw ex;
        }
    }

    private void SaveDeclaredObligationDetails()
    {
        try
        {
            if (gvObligationDetail != null && gvObligationDetail.Rows.Count > 0 && _saveDISSuccess && _saveIncomeDetailsSuccess)
            {
                DataTable dtGridObligationDetails = (DataTable)Session[SessionKeys.GV_OBLIGATION_DETAILS];

                if (dtGridObligationDetails != null && dtGridObligationDetails.Rows.Count > 0)
                {
                    DataTable dtDbObligationDetails = CreateObligationDetailsDbDataTable();
                    DataRow drObligationDetail;

                    foreach (DataRow dataRow in dtGridObligationDetails.Rows)
                    {
                        if (ValidateObligationDataRowIsNotEmpty(dataRow))
                        {
                            drObligationDetail = dtDbObligationDetails.NewRow();

                            drObligationDetail[AppConstants.Col_DOD_LD_ID] = dataRow[AppConstants.GV_COL_KYC_LEAD_ID];
                            drObligationDetail[AppConstants.Col_DOD_KYC_ID] = dataRow[AppConstants.GV_COL_KYC_ID];
                            drObligationDetail[AppConstants.Col_DOD_FIN] = dataRow[AppConstants.GV_COL_FINANCIER];
                            drObligationDetail[AppConstants.Col_DOD_LTYPE] = dataRow[AppConstants.GV_COL_LOAN_TYPE];
                            drObligationDetail[AppConstants.Col_DOD_SRC_OF_LOAN_IDENTF] = dataRow[AppConstants.GV_COL_SOURCE_OF_LOAN_IDENTIFICATION];
                            drObligationDetail[AppConstants.Col_DOD_CIBIL] = dataRow[AppConstants.GV_COL_CIBIL];
                            drObligationDetail[AppConstants.Col_DOD_EMI] = dataRow[AppConstants.GV_COL_EMI];
                            drObligationDetail[AppConstants.Col_DOD_BAL_NO_OF_EMI] = dataRow[AppConstants.GV_COL_BALANCE_NO_OF_EMI];

                            dtDbObligationDetails.Rows.Add(drObligationDetail);
                        }
                    }

                    if (dtDbObligationDetails != null && dtDbObligationDetails.Rows.Count > 0)
                    {
                        DataTable resultTable = new DataTable();
                        using (sqlConn = new SqlConnection(_ConnStr))
                        {
                            using (sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_DECLARED_OBLIGATION_DETAILS, sqlConn))
                            {
                                sqlCmd.CommandType = CommandType.StoredProcedure;
                                sqlCmd.CommandTimeout = 1200000;
                                sqlCmd.Parameters.AddWithValue(AppConstants.Param_DT_DeclaredObligationDetails, dtDbObligationDetails);
                                sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, SessionEMP_ID);

                                using (sqlDtAdptr = new SqlDataAdapter(sqlCmd))
                                {
                                    sqlDtAdptr.Fill(resultTable);
                                    _saveObligationDetailsSuccess = true;
                                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_OBLIGATION_DETAIL_SAVE_SUCCESS, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                                }
                            }
                        }
                    }
                    else
                    {
                        _obligationDetailsNotAvailable = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _saveObligationDetailsSuccess = false;
            throw ex;
        }
    }
    #endregion

    #endregion

    #region PRIVATE METHODS

    private void DisplayOnlySearchPanel()
    {
        try
        {
            srchPanel.Visible = true;
            gvCreditApprovalLeads.Visible = false;
            tblApprovalSummary.Visible = false;

            incomeDetailsPanel.Visible = false;
            obligationDetailsPanel.Visible = false;

            tblIncomeDetails.Visible = false;
            gvIncomeDetail.Visible = false;
            tblTotalIncome.Visible = false;
            tblObligationDetails.Visible = false;
            gvObligationDetail.Visible = false;
            tblTotalObligation.Visible = false;
            tblCREClassificationSMESLAP.Visible = false;
            tblPropertyDetails.Visible = false;
            tblFinalRecommendation.Visible = false;
            tblCREClassificationAHF.Visible = false;
            tblConditions.Visible = false;

            txtBxDeviations.Visible = false;
            lblDeviationRemainingChars.Visible = false;

            txtBxCreditConditions.Visible = false;
            lblCreditConditionsRemainingChars.Visible = false;

            submitPanel.Visible = false;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private bool ValidateSearchPanelDataIntegrity()
    {
        bool _passValidation = false;

        if (txtBxLeadno.Text == ""
            && (ddlArea.SelectedIndex == 0 || ddlArea.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
            && (ddlBranch.Items.Count == 0 || ddlBranch.SelectedItem.Text == AppConstants.DropdownDefaultSelection))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_ERR_AREA_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txtBxLeadno.Text == ""
            && ddlArea.SelectedItem.Text != AppConstants.DropdownDefaultSelection
            && (ddlBranch.Items.Count == 0 && ddlBranch.SelectedItem.Text == AppConstants.DropdownDefaultSelection))
        {
            Session["View"] = "F";
            _passValidation = true;
        }
        else if (txtBxLeadno.Text == ""
            && ddlArea.SelectedItem.Text != AppConstants.DropdownDefaultSelection
            && (ddlBranch.Items.Count > 0 || ddlBranch.SelectedItem.Text != AppConstants.DropdownDefaultSelection))
        {
            Session["View"] = "F";
            _passValidation = true;
        }
        else if (txtBxLeadno.Text != ""
            && ddlArea.SelectedItem.Text == AppConstants.DropdownDefaultSelection
            && (ddlBranch.Items.Count == 0 || ddlBranch.SelectedItem.Text == AppConstants.DropdownDefaultSelection))
        {
            Session["View"] = "F";
            _passValidation = true;
        }
        else if (txtBxLeadno.Text != ""
            && ddlArea.SelectedItem.Text != AppConstants.DropdownDefaultSelection
            && (ddlBranch.Items.Count == 0 || ddlBranch.SelectedItem.Text == AppConstants.DropdownDefaultSelection))
        {
            Session["View"] = "F";
            _passValidation = true;
        }
        else if (txtBxLeadno.Text != ""
            && ddlArea.SelectedItem.Text != AppConstants.DropdownDefaultSelection
            && (ddlBranch.Items.Count > 0 && ddlBranch.SelectedItem.Text != AppConstants.DropdownDefaultSelection))
        {
            Session["View"] = "F";
            _passValidation = true;
        }

        return _passValidation;
    }

    private bool ValidateIncomeDetailsIntegrity()
    {
        bool _passValidation = true;

        if (ddlApplicantName_Income == null || ddlApplicantName_Income.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_APPLICANT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && ddlNatureOfIncome_Income == null || ddlNatureOfIncome_Income.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_NATURE_OF_INCOME_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txtBxIncome_Income == null || txtBxIncome_Income.Text == String.Empty)
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_INCOME_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if ((!FormValidations.IsIncomeValid(txtBxIncome_Income.Text)))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_INCOME_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }

        return _passValidation;
    }

    private bool ValidateObligationDetailsIntegrity()
    {
        bool _passValidation = true;

        if (ddlApplicantName_Obligation == null || ddlApplicantName_Obligation.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_APPLICANT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && txtBxFinancier_Obligation == null || txtBxFinancier_Obligation.Text == String.Empty)
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_FINANCIER_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && !FormValidations.AllowStringWithSpaces(txtBxFinancier_Obligation.Text))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_FINANCIER_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && ddlLoanType_Obligation == null || ddlLoanType_Obligation.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_LOAN_TYPE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && ddlSourceOfLoanIdentification_Obligation == null || ddlSourceOfLoanIdentification_Obligation.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_LOAN_SOURCE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && txtBxCibil_Obligation == null || txtBxCibil_Obligation.Text == String.Empty)
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_CIBIL_SCORE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && !FormValidations.IsCibilValid(txtBxCibil_Obligation.Text))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_CIBIL_SCORE_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && txtBxEMIAmount_Obligation == null || txtBxEMIAmount_Obligation.Text == String.Empty)
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_EMI_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && !FormValidations.IsEMIValid(txtBxEMIAmount_Obligation.Text))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_EMI_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && txtBxBalNoOfEMI_Obligation == null || txtBxBalNoOfEMI_Obligation.Text == String.Empty)
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_BAL_NO_OF_EMI_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && !(FormValidations.IsBalanceNoOfEMIValid(txtBxBalNoOfEMI_Obligation.Text)))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_BAL_NO_OF_EMI_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }

        return _passValidation;
    }

    private bool ValidateDISMemoDataIntegrity()
    {
        bool _passValidation = true;

        try
        {

            if (lblLeadNo.Text != String.Empty && lblProduct.Text != String.Empty && lblAreaBranch.Text != String.Empty && lblCustName.Text != String.Empty)
            {
                //Program
                if (ddlProgram != null && ddlProgram.SelectedIndex == 0)
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_PROGRAM_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //Income Details
                if (_passValidation && (gvIncomeDetail == null || gvIncomeDetail.Rows.Count == 0))
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_INCOME_DETAILS_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //Obligation Details
                //if (_passValidation && (gvObligationDetail == null || gvObligationDetail.Rows.Count == 0))
                //{
                //    _passValidation = false;
                //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_OBLIGATION_DETAILS_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //}

                #region PROPERTY DETAILS

                //Property type
                if (_passValidation && ddlPropertyType != null && ddlPropertyType.SelectedIndex == 0)
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_PROPERTY_TYPE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //Ocupancy Status
                if (_passValidation && ddlOccupancyStatus != null && ddlOccupancyStatus.SelectedIndex == 0)
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_OCCUPANCY_STATUS_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //Land Area Mandatory
                //if (_passValidation && (txtBxLandAreaInSqft != null && txtBxLandAreaInSqft.Text == String.Empty))
                //{
                //    _passValidation = false;
                //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_LAND_AREA_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //}

                //Land Area Data validity
                if (_passValidation
                    && txtBxLandAreaInSqft != null
                    && txtBxLandAreaInSqft.Text != String.Empty
                    && !FormValidations.IsLandAreaValid(txtBxLandAreaInSqft.Text))
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_LAND_AREA_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //Land Value Mandatory
                //if (_passValidation && (txtBxLandValuePerSqft != null && txtBxLandValuePerSqft.Text == String.Empty))
                //{
                //    _passValidation = false;
                //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_LAND_VALUE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //}

                //Land value Data validity
                if (_passValidation
                    && txtBxLandValuePerSqft != null
                    && txtBxLandValuePerSqft.Text != String.Empty
                    && !FormValidations.IsLandAreaCostPerSqftValid(txtBxLandValuePerSqft.Text))
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_LAND_VALUE_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //Buildup Area and Cost for SME & SLAP products
                if (_passValidation
                    && (SME_SLAP_Built_UpArea != null && SME_SLAP_Built_UpArea.Visible == true)
                    && (SME_SLAP_Built_UpCost != null && SME_SLAP_Built_UpCost.Visible == true))
                {
                    //Buildup Area mandatory
                    //if (_passValidation && (txtBxBuiltUpAreaInSqft != null && txtBxBuiltUpAreaInSqft.Text == String.Empty))
                    //{
                    //    _passValidation = false;
                    //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_BUILDUP_AREA_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    //}

                    //Buildup Area Data validity
                    if (_passValidation
                        && txtBxBuiltUpAreaInSqft != null
                        && txtBxBuiltUpAreaInSqft.Text == String.Empty
                        && !FormValidations.IsLandAreaValid(txtBxBuiltUpAreaInSqft.Text))
                    {
                        _passValidation = false;
                        uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_BUILDUP_AREA_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                    //Buildup Cost mandatory
                    //if (_passValidation && (txtBxBuildUpCostPerSqft != null && txtBxBuildUpCostPerSqft.Text == String.Empty))
                    //{
                    //    _passValidation = false;
                    //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_BUILDUP_COST_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    //}

                    //Buildup cost Data validity
                    if (_passValidation
                        && txtBxBuildUpCostPerSqft != null
                        && txtBxBuildUpCostPerSqft.Text == String.Empty
                        && !FormValidations.IsLandAreaCostPerSqftValid(txtBxBuildUpCostPerSqft.Text))
                    {
                        _passValidation = false;
                        uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_BUILDUP_COST_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }

                //Constrution Area and Value for AHF products
                if (_passValidation
                    && (AHF_Built_UpArea != null && AHF_Built_UpArea.Visible == true)
                    && (AHF_Built_UpCost != null && AHF_Built_UpCost.Visible == true))
                {
                    //Constrution Area mandatoy
                    //if (_passValidation && (txtBxConstructionAreaInSqft != null && txtBxConstructionAreaInSqft.Text == String.Empty))
                    //{
                    //    _passValidation = false;
                    //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_CONSTRUCTION_AREA_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    //}

                    //Constrution Area Data validity
                    if (_passValidation
                        && txtBxConstructionAreaInSqft != null
                        && txtBxConstructionAreaInSqft.Text == String.Empty
                        && !FormValidations.IsLandAreaValid(txtBxConstructionAreaInSqft.Text))
                    {
                        _passValidation = false;
                        uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_CONSTRUCTION_AREA_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                    //Constrution Value mandatoy
                    //if (_passValidation && (txtBxConstructionCostPerSqft != null && txtBxConstructionCostPerSqft.Text == String.Empty))
                    //{
                    //    _passValidation = false;
                    //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_CONSTRUCTION_COST_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    //}

                    //Constrution cost Data validity
                    if (_passValidation
                        && txtBxConstructionCostPerSqft != null
                        && txtBxConstructionCostPerSqft.Text == String.Empty
                        && !FormValidations.IsLandAreaCostPerSqftValid(txtBxConstructionCostPerSqft.Text))
                    {
                        _passValidation = false;
                        uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_CONSTRUCTION_COST_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }

                //Amenities mandatory
                //if (_passValidation
                //    && txtBxAmenities != null
                //    && txtBxAmenities.Text == String.Empty)
                //{
                //    _passValidation = false;
                //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_AMENITIES_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //}

                //Amenities data validity
                if (_passValidation
                    && txtBxAmenities != null
                    && txtBxAmenities.Text == String.Empty
                    && !FormValidations.IsAmenitiesValid(txtBxAmenities.Text))
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_AMENITIES_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                #endregion

                #region FINAL RECOMMENDATION

                //Tenor
                if (_passValidation
                    && txtBxTenor != null
                    && txtBxTenor.Text == String.Empty)
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_TENOR_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //Tenor data validity
                if (_passValidation
                    && txtBxTenor != null
                    && txtBxTenor.Text != String.Empty
                    && !FormValidations.IsTenorValid(txtBxTenor.Text))
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_TENOR_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //Rate Of Interest mandatory
                if (_passValidation
                    && txtBxROI != null
                    && txtBxROI.Text == String.Empty)
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_ROI_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //Rate Of Interest data validity
                if (_passValidation
                    && txtBxROI != null
                    && txtBxROI.Text == String.Empty
                    && !FormValidations.IsROIValid(txtBxROI.Text))
                {
                    _passValidation = false;

                    StringBuilder sb = new StringBuilder();
                    foreach (char c in txtBxROI.Text)
                    {
                        if ((c >= '0' && c <= '9') || c == '.')
                        {
                            sb.Append(c);
                        }
                    }
                    txtBxROI.Text = sb.ToString();

                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_ROI_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //Loan Amount mandatory
                if (_passValidation
                    && txtBxFinalLoanAmount != null
                    && txtBxFinalLoanAmount.Text == String.Empty)
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_FINAL_LOAN_AMOUNT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //Loan Amount data validity
                if (_passValidation
                    && txtBxFinalLoanAmount != null
                    && !FormValidations.AllowDecimals(txtBxFinalLoanAmount.Text))
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_FINAL_LOAN_AMOUNT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //AHF No Of Property Owned / to be Owned
                if ((AHF_NO_OF_PROPERTY_ALREADY_OWNED != null && AHF_NO_OF_PROPERTY_ALREADY_OWNED.Visible == true)
                    && (AHF_NO_OF_PROPERTY_TO_BE_OWNED != null && AHF_NO_OF_PROPERTY_TO_BE_OWNED.Visible == true))
                {
                    //AHF No Of Property Already Owned Mandatory
                    if (_passValidation && (txtBxNoOfPropertyAlreadyOwned != null && txtBxNoOfPropertyAlreadyOwned.Text == String.Empty))
                    {
                        _passValidation = false;
                        uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_NO_OF_PROPERTY_ALREADY_OWNED_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                    //No Of Property already owned Data validity
                    if (_passValidation
                        && txtBxNoOfPropertyAlreadyOwned != null
                        && txtBxNoOfPropertyAlreadyOwned.Text != String.Empty
                        && !FormValidations.IsNoOfPropertiesValid(txtBxNoOfPropertyAlreadyOwned.Text))
                    {
                        _passValidation = false;
                        uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_NO_OF_PROPERTY_ALREADY_OWNED_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                    //AHF No Of Property to be Owned Mandatory
                    if (_passValidation && (txtBxNoOfPropertyToBeOwned != null && txtBxNoOfPropertyToBeOwned.Text == String.Empty))
                    {
                        _passValidation = false;
                        uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_NO_OF_PROPERTY_TO_BE_OWNED_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                    //No Of Property to be owned Data validity
                    if (_passValidation
                        && txtBxNoOfPropertyToBeOwned != null
                        && txtBxNoOfPropertyToBeOwned.Text != String.Empty
                        && !FormValidations.IsNoOfPropertiesValid(txtBxNoOfPropertyToBeOwned.Text))
                    {
                        _passValidation = false;
                        uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_NO_OF_PROPERTY_TO_BE_OWNED_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }

                #endregion

                if (_passValidation
                    && txtBxDeviations != null
                    && txtBxDeviations.Text == String.Empty)
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_DEVIATIONS_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (_passValidation
                    && txtBxDeviations != null
                    && txtBxDeviations.Text != String.Empty
                    && txtBxDeviations.Text.Replace("\n", "<br/>").Length > 2000)
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_DEVIATIONS_MAX_LENGTH, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                if (_passValidation
                    && txtBxCreditConditions != null
                    && txtBxCreditConditions.Text == String.Empty)
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_CREDIT_CONDITIONS_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (_passValidation
                    && txtBxCreditConditions != null
                    && txtBxCreditConditions.Text != String.Empty
                    && txtBxCreditConditions.Text.Replace("\n", "<br/>").Length > 2000)
                {
                    _passValidation = false;
                    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_CREDIT_CONDITIONS_MAX_LENGTH, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                //if (_passValidation
                //    && txtBxOfflineMailApprovedBy != null
                //    && txtBxOfflineMailApprovedBy.Text == String.Empty)
                //{
                //    _passValidation = false;
                //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_OFFLINE_RECOMMENDED_BY_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //}

                //if (_passValidation
                //    && txtBxOfflineMailApprovedBy != null
                //    && txtBxOfflineMailApprovedBy.Text != String.Empty
                //    && !FormValidations.AllowStringWithSpaces(txtBxOfflineMailApprovedBy.Text))
                //{
                //    _passValidation = false;
                //    uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_OFFLINE_RECOMMENDED_BY_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //}
            }
            else
            {
                uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_GENERIC, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return _passValidation;
    }

    private bool ValidateObligationDataRowIsNotEmpty(DataRow drObligationDetail)
    {
        bool _result = false;
        Int64 leadId = 0;

        if (drObligationDetail[AppConstants.GV_COL_KYC_LEAD_ID] != null)
        {
            Int64.TryParse(Convert.ToString(drObligationDetail[AppConstants.GV_COL_KYC_LEAD_ID]), out leadId);

            if (leadId > 0)
            {
                _result = true;
            }
        }

        return _result;
    }

    private void Reset()
    {
        try
        {
            //Approval Summary
            lblLeadNo.Text = String.Empty;
            lblProduct.Text = String.Empty;
            lblAreaBranch.Text = String.Empty;
            lblCustName.Text = String.Empty;

            //CRE Classification
            if (ddlCREClassificationAHF != null && ddlCREClassificationAHF.Visible == true && ddlCREClassificationAHF.SelectedIndex > 0)
            {
                ddlCREClassificationAHF.ClearSelection();
                lblCREJustificationAHF.Text = String.Empty;
            }

            if (ddlCREClassificationSMESLAP != null && ddlCREClassificationSMESLAP.Visible == true && ddlCREClassificationSMESLAP.SelectedIndex > 0)
            {
                ddlCREClassificationSMESLAP.ClearSelection();
                lblCREJustificationSMESLAP.Text = String.Empty;
            }

            //Income Details
            ResetIncomeDetailsGrid();
            lblTotalIncome.Text = String.Empty;

            //Obligation Details
            ResetObligationDetailsGrid();
            lblTotalObligation.Text = String.Empty;

            //Property Details
            if (ddlPropertyType != null && ddlPropertyType.Visible == true && ddlPropertyType.SelectedIndex > 0)
            {
                ddlPropertyType.ClearSelection();
            }

            if (txtBxLandAreaInSqft != null && txtBxLandAreaInSqft.Visible == true)
            {
                txtBxLandAreaInSqft.Text = String.Empty;
                txtBxLandValuePerSqft.Text = String.Empty;
                lblTotalLandValue.Text = String.Empty;
            }

            if (txtBxBuiltUpAreaInSqft != null && txtBxBuiltUpAreaInSqft.Visible == true)
            {
                txtBxBuiltUpAreaInSqft.Text = String.Empty;
                txtBxBuildUpCostPerSqft.Text = String.Empty;
                lblTotalBuildingValue.Text = String.Empty;
            }

            if (txtBxConstructionAreaInSqft != null && txtBxConstructionAreaInSqft.Visible == true)
            {
                txtBxConstructionAreaInSqft.Text = String.Empty;
                txtBxConstructionCostPerSqft.Text = String.Empty;
                lblTotalConstructionValue.Text = String.Empty;
            }

            txtBxAmenities.Text = String.Empty;
            lblTotalPropertyValue.Text = String.Empty;

            //Final Recommendation
            txtBxTenor.Text = String.Empty;
            txtBxROI.Text = String.Empty;
            txtBxFinalLoanAmount.Text = String.Empty;
            lblEMI.Text = String.Empty;
            lblApprovedIIR.Text = String.Empty;
            lblApprovedFOIR.Text = String.Empty;
            lblLTV.Text = String.Empty;
            lblLCR.Text = String.Empty;

            //Remarks
            txtBxDeviations.Text = String.Empty;
            txtBxCreditConditions.Text = String.Empty;

            //Approver Details
            txtBxFileRecommendedBy.Text = String.Empty;
            txtBxOfflineMailApprovedBy.Text = String.Empty;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void ResetIncomeDetailsGrid()
    {
        try
        {
            if (ddlApplicantName_Income != null && ddlApplicantName_Income.Items.Count > 0)
            { ddlApplicantName_Income.ClearSelection(); }

            if (ddlNatureOfIncome_Income != null && ddlNatureOfIncome_Income.Items.Count > 0)
            { ddlNatureOfIncome_Income.ClearSelection(); }

            lblApplicantType_Income.Text = String.Empty;
            txtBxIncome_Income.Text = String.Empty;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void ResetObligationDetailsGrid()
    {
        try
        {
            if (ddlApplicantName_Obligation != null && ddlApplicantName_Obligation.Items.Count > 0)
            { ddlApplicantName_Obligation.ClearSelection(); }

            lblApplicantType_Obligation.Text = String.Empty;
            txtBxFinancier_Obligation.Text = String.Empty;

            if (ddlLoanType_Obligation != null && ddlLoanType_Obligation.Items.Count > 0)
            { ddlLoanType_Obligation.ClearSelection(); }

            if (ddlSourceOfLoanIdentification_Obligation != null && ddlSourceOfLoanIdentification_Obligation.Items.Count > 0)
            { ddlSourceOfLoanIdentification_Obligation.ClearSelection(); }

            txtBxCibil_Obligation.Text = String.Empty;
            txtBxEMIAmount_Obligation.Text = String.Empty;
            txtBxBalNoOfEMI_Obligation.Text = String.Empty;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void ClearIncomeAndObligationSessionData()
    {
        Session[SessionKeys.GV_INCOME_DETAILS] = null;
        Session[SessionKeys.GV_OBLIGATION_DETAILS] = null;
    }

    private DataTable CreateIncomeDetailsGridDataTable()
    {
        DataTable dtIncomeDetails = new DataTable();

        dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_KYC_LEAD_ID, typeof(String)));
        dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_KYC_ID, typeof(String)));
        dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_NAME, typeof(String)));
        dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_APPL_TYPE, typeof(String)));
        dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_INCOME_SOURCE, typeof(String)));
        dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_INCOME, typeof(String)));

        return dtIncomeDetails;
    }

    private DataTable CreateIncomeDetailsDbDataTable()
    {
        DataTable dtIncomeDetails = new DataTable();

        dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_DID_LD_ID, typeof(String)));
        dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_DID_KYC_ID, typeof(String)));
        dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_DID_NAT_OF_INCOME, typeof(String)));
        dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_DID_INCOME, typeof(String)));

        return dtIncomeDetails;
    }

    private DataTable CreateObligationDetailsGridDataTable()
    {
        DataTable dtObligationDetails = new DataTable();

        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_KYC_LEAD_ID, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_KYC_ID, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_NAME, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_APPL_TYPE, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_FINANCIER, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_LOAN_TYPE, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_SOURCE_OF_LOAN_IDENTIFICATION, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_CIBIL, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_EMI, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_BALANCE_NO_OF_EMI, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_OBLIGATION_AMOUNT, typeof(String)));

        return dtObligationDetails;
    }

    private DataTable CreateObligationDetailsDbDataTable()
    {
        DataTable dtObligationDetails = new DataTable();

        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.Col_DOD_LD_ID, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.Col_DOD_KYC_ID, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.Col_DOD_FIN, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.Col_DOD_LTYPE, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.Col_DOD_SRC_OF_LOAN_IDENTF, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.Col_DOD_CIBIL, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.Col_DOD_EMI, typeof(String)));
        dtObligationDetails.Columns.Add(new DataColumn(AppConstants.Col_DOD_BAL_NO_OF_EMI, typeof(String)));

        return dtObligationDetails;
    }

    private void LoadEmptyIncomeDetailsGrid()
    {
        DataTable dtIncomeDetails = CreateIncomeDetailsGridDataTable();

        DataRow drIncomeDetailRow = dtIncomeDetails.NewRow();

        drIncomeDetailRow[AppConstants.GV_COL_KYC_LEAD_ID] = String.Empty;
        drIncomeDetailRow[AppConstants.GV_COL_KYC_ID] = String.Empty;
        drIncomeDetailRow[AppConstants.GV_COL_NAME] = String.Empty;
        drIncomeDetailRow[AppConstants.GV_COL_APPL_TYPE] = String.Empty;
        drIncomeDetailRow[AppConstants.GV_COL_INCOME_SOURCE] = String.Empty;
        drIncomeDetailRow[AppConstants.GV_COL_INCOME] = String.Empty;

        dtIncomeDetails.Rows.Add(drIncomeDetailRow);

        gvIncomeDetail.DataSource = dtIncomeDetails;
        gvIncomeDetail.DataBind();

        Session[SessionKeys.GV_INCOME_DETAILS] = dtIncomeDetails;
    }

    private void LoadEmptyObligationDetailsGrid()
    {
        DataTable dtObligationDetails = CreateObligationDetailsGridDataTable();

        DataRow drObligationDetailRow = dtObligationDetails.NewRow();
        drObligationDetailRow[AppConstants.GV_COL_NAME] = String.Empty;
        drObligationDetailRow[AppConstants.GV_COL_APPL_TYPE] = String.Empty;
        drObligationDetailRow[AppConstants.GV_COL_FINANCIER] = String.Empty;
        drObligationDetailRow[AppConstants.GV_COL_LOAN_TYPE] = String.Empty;
        drObligationDetailRow[AppConstants.GV_COL_SOURCE_OF_LOAN_IDENTIFICATION] = String.Empty;
        drObligationDetailRow[AppConstants.GV_COL_CIBIL] = String.Empty;
        drObligationDetailRow[AppConstants.GV_COL_EMI] = String.Empty;
        drObligationDetailRow[AppConstants.GV_COL_BALANCE_NO_OF_EMI] = String.Empty;
        drObligationDetailRow[AppConstants.GV_COL_OBLIGATION_AMOUNT] = String.Empty;

        dtObligationDetails.Rows.Add(drObligationDetailRow);

        gvObligationDetail.DataSource = dtObligationDetails;
        gvObligationDetail.DataBind();

        Session[SessionKeys.GV_OBLIGATION_DETAILS] = dtObligationDetails;
    }

    private void CalculateTotalPropertyValue()
    {
        Double landAreaInSqft = 0.0;
        Double landValuePerSqft = 0.0;
        Double totalLandValue = 0.0;

        Double buildingAreaInSqft = 0.0;
        Double buildUpCostPerSqft = 0.0;
        Double totalBuildingValue = 0.0;

        Double constructAreaInSqft = 0.0;
        Double constructCostPerSqft = 0.0;

        Double amenitiesCost = 0.0;

        if (txtBxLandAreaInSqft.Text != String.Empty && txtBxLandValuePerSqft.Text != String.Empty)
        {
            Double.TryParse(txtBxLandAreaInSqft.Text, out landAreaInSqft);
            Double.TryParse(txtBxLandValuePerSqft.Text, out landValuePerSqft);
            totalLandValue = Math.Round((landAreaInSqft * landValuePerSqft), 2, MidpointRounding.AwayFromZero);
            lblTotalLandValue.Text = Convert.ToString(totalLandValue);
        }

        //Total Building Value
        if ((SME_SLAP_Built_UpCost != null && SME_SLAP_Built_UpCost.Visible == true) // For SME & SLAP Products
            && (SME_SLAP_BuildingCost != null && SME_SLAP_BuildingCost.Visible == true)
            && (SME_SLAP_BuildingCost != null && SME_SLAP_BuildingCost.Visible == true))
        {
            if (txtBxBuiltUpAreaInSqft.Text != String.Empty && txtBxBuildUpCostPerSqft.Text != String.Empty)
            {
                Double.TryParse(txtBxBuiltUpAreaInSqft.Text, out buildingAreaInSqft);
                Double.TryParse(txtBxBuildUpCostPerSqft.Text, out buildUpCostPerSqft);

                totalBuildingValue = Math.Round((buildingAreaInSqft * buildUpCostPerSqft), 2, MidpointRounding.AwayFromZero);
                lblTotalBuildingValue.Text = Convert.ToString(totalBuildingValue);
            }
        }
        else if ((AHF_Built_UpArea != null && AHF_Built_UpArea.Visible == true) // For AHF Products
            && (AHF_Built_UpCost != null && AHF_Built_UpCost.Visible == true)
            && (AHF_BuildingValue != null && AHF_BuildingValue.Visible == true))
        {
            if (txtBxConstructionAreaInSqft.Text != String.Empty && txtBxConstructionCostPerSqft.Text != String.Empty)
            {
                Double.TryParse(txtBxConstructionAreaInSqft.Text, out constructAreaInSqft);
                Double.TryParse(txtBxConstructionCostPerSqft.Text, out constructCostPerSqft);

                totalBuildingValue = Math.Round((constructAreaInSqft * constructCostPerSqft), 2, MidpointRounding.AwayFromZero);
                lblTotalConstructionValue.Text = Convert.ToString(totalBuildingValue);
            }
        }

        if (txtBxAmenities.Text != String.Empty)
        {
            Double.TryParse(txtBxAmenities.Text, out amenitiesCost);
        }

        //Total Property Value
        Double totalPropertyValue = totalLandValue + totalBuildingValue + amenitiesCost;
        lblTotalPropertyValue.Text = Convert.ToString(totalPropertyValue);
    }

    private void CalculateEMI()
    {
        Int64 prodId = 0;
        Int32 tenor = 0;
        Double roi = 0;
        Double emi = 0;
        Double loanAmnt = 0;
        Double totalIncome = 0;
        Double totalObligation = 0;
        Double totalLandValue = 0;
        Double totalPropValue = 0;
        Double totalConstructionCost = 0;

        if (txtBxTenor.Text != String.Empty && txtBxROI.Text != String.Empty)
        {
            Int32.TryParse(txtBxTenor.Text, out tenor);
            Double.TryParse(txtBxROI.Text, out roi);
            Double.TryParse(txtBxFinalLoanAmount.Text, out loanAmnt);
            Double.TryParse(lblTotalIncome.Text, out totalIncome);
            Double.TryParse(lblTotalObligation.Text, out totalObligation);
            Double.TryParse(lblTotalLandValue.Text, out totalLandValue);
            Double.TryParse(lblTotalPropertyValue.Text, out totalPropValue);
            Double.TryParse(lblTotalConstructionValue.Text, out totalConstructionCost);

            if (tenor > 0 && roi > 0)
            {
                var a = 1 + (roi / 1200);
                var x = Math.Pow(a, tenor);
                x = 1 / x;
                x = 1 - x;
                emi = ((loanAmnt) * (roi / 1200) / x);
                emi = Math.Round(emi);
                var decEmi = Math.Round(Convert.ToDecimal(emi));
                lblEMI.Text = Convert.ToString(decEmi);

                var appIIR = (emi / totalIncome) * 100;
                var decAppIIR = Math.Round(Convert.ToDecimal(appIIR), 2, MidpointRounding.AwayFromZero);
                lblApprovedIIR.Text = Convert.ToString(decAppIIR);

                var appFOIR = ((emi + totalObligation) / totalIncome) * 100;
                var decAppFOIR = Math.Round(Convert.ToDecimal(appFOIR), 2, MidpointRounding.AwayFromZero);
                lblApprovedFOIR.Text = Convert.ToString(decAppFOIR);

                var ltv = (loanAmnt / totalPropValue) * 100;
                var decLTV = Math.Round(Convert.ToDecimal(ltv), 2, MidpointRounding.AwayFromZero);
                lblLTV.Text = Convert.ToString(decLTV);

                if (Session[SessionKeys.PR_ID] != null) { prodId = Convert.ToInt64(Session[SessionKeys.PR_ID]); }

                if (prodId == Convert.ToInt64(Declared_Product_Program.Housing_IB_AHF)
                    || prodId == Convert.ToInt64(Declared_Product_Program.IB_Affordable_Home))
                {
                    Double lcr = 0.0;
                    if (totalConstructionCost > 0)//Construction cost may be zero in some cases
                    {
                        lcr = (loanAmnt / totalConstructionCost) * 100;
                    }
                    var decLCR = Math.Round(Convert.ToDecimal(lcr), 2, MidpointRounding.AwayFromZero);
                    lblLCR.Text = Convert.ToString(decLCR);
                }
            }
        }
        else
        {
            uscMsgBox1.AddMessage(Credit_BusinessMessages.MSG_ROI_MANDATORY + ". " + Credit_BusinessMessages.MSG_TENOR_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }

    private void UpdateCREClassification()
    {
        if (tblCREClassificationSMESLAP != null && tblCREClassificationSMESLAP.Visible == true)
        {
            UpdateCREClassificationForSMESLAP();
        }
        else if (tblCREClassificationAHF != null && tblCREClassificationAHF.Visible == true)
        {
            UpdateCREClassificationForAHF();
        }
    }

    private void UpdateCREClassificationForSMESLAP()
    {
        if (Session[SessionKeys.GV_INCOME_DETAILS] != null)
        {
            DataTable dtIncomeDetails = (DataTable)Session[SessionKeys.GV_INCOME_DETAILS];

            if (dtIncomeDetails != null && dtIncomeDetails.Rows.Count > 0)
            {
                Double rentalIncome = 0.0;
                Double totalIncome = 0.0;
                DataRow[] drfilteredRows = dtIncomeDetails.Select("INCOME_SOURCE = 'RENTAL'");
                foreach (var dataRow in drfilteredRows)
                {
                    rentalIncome = rentalIncome + Convert.ToDouble(dataRow[5].ToString());
                }

                Double.TryParse(lblTotalIncome.Text, out totalIncome);

                if (rentalIncome > (totalIncome / 2))
                {
                    ddlCREClassificationSMESLAP.SelectedValue = "CRE";
                    lblCREJustificationSMESLAP.Text = Credit_BusinessMessages.CLASSIFICATION_CRE_SMESLAP;
                }
                else
                {
                    ddlCREClassificationSMESLAP.SelectedValue = "NCRE";
                    lblCREJustificationSMESLAP.Text = Credit_BusinessMessages.CLASSIFICATION_NON_CRE_SMESLAP;
                }
            }
            else
            {
                ddlCREClassificationSMESLAP.SelectedValue = AppConstants.DropdownDefaultSelection;
                lblCREJustificationSMESLAP.Text = String.Empty;
            }
        }
    }

    private void UpdateCREClassificationForAHF()
    {
        Int16 noOfPropertiesAlreadyOwned = 0;
        Int16 noOfPropertiesToBeOwned = 0;

        Int16.TryParse(txtBxNoOfPropertyAlreadyOwned.Text, out noOfPropertiesAlreadyOwned);
        Int16.TryParse(txtBxNoOfPropertyToBeOwned.Text, out noOfPropertiesToBeOwned);

        if ((noOfPropertiesAlreadyOwned + noOfPropertiesToBeOwned) > 2)
        {
            ddlCREClassificationAHF.SelectedValue = "CRERH";
            lblCREJustificationAHF.Text = Credit_BusinessMessages.CLASSIFICATION_CRE_RH_AHF;
        }
        else
        {
            if (Session[SessionKeys.GV_INCOME_DETAILS] != null)
            {
                DataTable dtIncomeDetails = (DataTable)Session[SessionKeys.GV_INCOME_DETAILS];

                if (dtIncomeDetails != null && dtIncomeDetails.Rows.Count > 0)
                {
                    Double rentalIncome = 0.0;
                    Double totalIncome = 0.0;
                    DataRow[] drfilteredRows = dtIncomeDetails.Select("INCOME_SOURCE = 'RENTAL'");
                    foreach (var dataRow in drfilteredRows)
                    {
                        rentalIncome = rentalIncome + Convert.ToDouble(dataRow[5].ToString());
                    }

                    Double.TryParse(lblTotalIncome.Text, out totalIncome);

                    if (rentalIncome > (totalIncome / 2))
                    {
                        ddlCREClassificationAHF.SelectedValue = "CRE";
                        lblCREJustificationAHF.Text = Credit_BusinessMessages.CLASSIFICATION_CRE_AHF;
                    }
                    else
                    {
                        ddlCREClassificationAHF.SelectedValue = "NCRE";
                        lblCREJustificationAHF.Text = Credit_BusinessMessages.CLASSIFICATION_NON_CRE_AHF;
                    }
                }
            }
            else
            {
                ddlCREClassificationAHF.SelectedValue = AppConstants.DropdownDefaultSelection;
                lblCREJustificationAHF.Text = String.Empty;
            }
        }
    }

    private void BindCreditConditionsMaxlengthValidator()
    {
        txtBxCreditConditions.Attributes.Add("onpropertychange", "return ValidateCreditConditionMaxlength(event, $(this))");
        txtBxCreditConditions.Attributes.Add("onkeyup", "return ValidateCreditConditionMaxlength(event, $(this))");
        txtBxCreditConditions.Attributes.Add("oninput", "return ValidateCreditConditionMaxlength(event, $(this))");
        txtBxCreditConditions.Attributes.Add("oncut", "return ValidateCreditConditionMaxlength(event, $(this))");
        txtBxCreditConditions.Attributes.Add("onpaste", "return ValidateCreditConditionMaxlength(event, $(this))");
    }

    private void BindDeviationsMaxlengthValidator()
    {
        txtBxDeviations.Attributes.Add("onpropertychange", "return ValidateDeviationMaxlength(event, $(this))");
        txtBxDeviations.Attributes.Add("onkeyup", "return ValidateDeviationMaxlength(event, $(this))");
        txtBxDeviations.Attributes.Add("oninput", "return ValidateDeviationMaxlength(event, $(this))");
        txtBxDeviations.Attributes.Add("oncut", "return ValidateDeviationMaxlength(event, $(this))");
        txtBxDeviations.Attributes.Add("onpaste", "return ValidateDeviationMaxlength(event, $(this))");
    }

    #endregion
}