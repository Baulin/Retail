﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using System.Text;
using Utilities;
using Tracker;

public partial class BMTWLApproval : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    //string sa;
    int ldid;
    //int j;
    //int b;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;

    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    string[] stringArray = new string[100];

   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            bindArea();
            bindRel();
        }
    }
    public void bindRel()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        SqlCommand cmdrsn = new SqlCommand("RTS_SP_Fetch_MR_REASON", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlReason.DataSource = dsrsn;
        ddlReason.DataTextField = "RSN_REASON";
        ddlReason.DataValueField = "RSN_ID";
        ddlReason.DataBind();
        ddlReason.Items.Insert(0, new ListItem("--Select--", "0"));
    }
  /*  public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

        //SqlCommand cmdqry = new SqlCommand("SELECT * FROM LSD_QUERY_GRID", con);
        //SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
        //DataSet dsqry = new DataSet();
        //daqry.Fill(dsqry);
        //gvQueryEntry.DataSource = dsqry.Tables[0];
        //gvQueryEntry.DataBind();
    }*/
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;


    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        lbLeadno.Text = "";
        lbAppname.Text = "";
        lbPDdate.Text = "";
        lbLoanamt.Text = "";


        tblVerify.Visible = false;

        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "All";

        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            ddlArea.Enabled = false;

        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";

        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";

        }

        BindqueryGrid();
    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_FETCH_TELE_VERIFICATION", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AREAID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@BRANCHID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@TYPE", "A");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0] != null)
            {
                gvQuery.Visible = true;
                //Panel1.Visible = true;
                gvQuery.DataSource = ds1.Tables[0];
                gvQuery.DataBind();
                ViewState["LeadTable"] = ds1.Tables[0];
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvQuery.HeaderRow.Font.Bold = true;
                    gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                    gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                    gvQuery.HeaderRow.Cells[1].Wrap = false;
                    gvQuery.HeaderRow.Cells[2].Wrap = false;
                    gvQuery.HeaderRow.Cells[3].Wrap = false;
                    gvQuery.HeaderRow.Cells[4].Wrap = false;
                    gvQuery.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvQuery.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }

    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        //Assumes the Price column is at index 4
        if (e.Row.RowType == DataControlRowType.DataRow)
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();


        foreach (GridViewRow grow in gvQuery.Rows)
        {
            Label lblLeadID = grow.FindControl("lblLeadID") as Label;
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                btnSubmit.Enabled = true;
                Session["LeadID"] = lblLeadID.Text;
                leadno = lnbtn.Text;
                appname = gvQuery.Rows[index].Cells[3].Text;
                pddt = gvQuery.Rows[index].Cells[4].Text;
                lnamt = gvQuery.Rows[index].Cells[5].Text;
                Session["Loanamt"] = lnamt;
                DataTable dtTemp = (DataTable)ViewState["LeadTable"];

                if (dtTemp != null && dtTemp.Rows.Count > 0)
                {
                    DataRow[] drTemp = dtTemp.Select("LD_NO='" + leadno + "'");
                    if (drTemp.Length > 0)
                    {
                        tblVerify.Visible = true;
                        dtTemp = drTemp.CopyToDataTable();
                        string strVerStatus = dtTemp.Rows[0]["KYC_TELEVER_STATUS"] != DBNull.Value ? dtTemp.Rows[0]["KYC_TELEVER_STATUS"].ToString() : "";
                        string[] strValues = strVerStatus.Split('|');
                        if (strValues.Length > 0)
                        {
                            //Loan availed
                             if(strValues[0].ToString() == "Y")
                             {
                                 rdnLoanYes.Checked = true;
                             }
                             else if (strValues[0].ToString() == "N")
                             {
                                 rdnLoanNo.Checked = true;
                             }
                            //Contact Applcnt
                             if (strValues[1].ToString() == "Y")
                             {
                                 rdnMObYes.Checked = true;
                             }
                             else if (strValues[1].ToString() == "N")
                             {
                                 rdnMObNo.Checked = true;
                             }

                             //Name Applcnt
                             if (strValues[2].ToString() == "Y")
                             {
                                 rdnAppNameYes.Checked = true;
                             }
                             else if (strValues[2].ToString() == "N")
                             {
                                 rdnAppNameNo.Checked = true;
                             }
                            //Addr

                             if (strValues[3].ToString() == "Y")
                             {
                                 rdnappRaddrYes.Checked = true;
                             }
                             else if (strValues[3].ToString() == "N")
                             {
                                 rdnappRaddrNo.Checked = true;
                             }
                            //Office Addr
                             if (strValues[4].ToString() == "Y")
                             {
                                 rdnappOaddressYes.Checked = true;
                             }
                             else if (strValues[4].ToString() == "N")
                             {
                                 rdnappOaddressNo.Checked = true;
                             }
                             //Ref1

                             if (strValues[5].ToString() == "Y")
                             {
                                 rdnRef1Yes.Checked = true;
                             }
                             else if (strValues[5].ToString() == "N")
                             {
                                 rdnRef1Bo.Checked = true;
                             }
                             //Ref2

                             if (strValues[6].ToString() == "Y")
                             {
                                 ref2Yes.Checked = true;
                             }
                             else if (strValues[6].ToString() == "N")
                             {
                                 ref2No.Checked = true;
                             }
                        }
                        lblMobileNO.Text = dtTemp.Rows[0]["LD_ACNO"] != DBNull.Value ? dtTemp.Rows[0]["LD_ACNO"].ToString() : "";
                        lblAppName.Text = dtTemp.Rows[0]["LD_APNAME"] != DBNull.Value ? dtTemp.Rows[0]["LD_APNAME"].ToString() : "";
                        lblAppRAddress.Text = dtTemp.Rows[0]["LD_RADDRESS"] != DBNull.Value ? dtTemp.Rows[0]["LD_RADDRESS"].ToString() : "";
                        lblAppOaddress.Text = dtTemp.Rows[0]["LD_ADDRESS"] != DBNull.Value ? dtTemp.Rows[0]["LD_ADDRESS"].ToString() : "";
                        txtbxref1name.Text = dtTemp.Rows[0]["KYC_REF1_NAME"] != DBNull.Value ? dtTemp.Rows[0]["KYC_REF1_NAME"].ToString() : "";
                        txtbxref1addr.Text = dtTemp.Rows[0]["KYC_REF1_ADDR"] != DBNull.Value ? dtTemp.Rows[0]["KYC_REF1_ADDR"].ToString() : "";
                        txtbxref1contactno.Text = dtTemp.Rows[0]["KYC_REF1_CONTACT"] != DBNull.Value ? dtTemp.Rows[0]["KYC_REF1_CONTACT"].ToString() : "";
                        txtbxref2name.Text = dtTemp.Rows[0]["KYC_REF2_NAME"] != DBNull.Value ? dtTemp.Rows[0]["KYC_REF2_NAME"].ToString() : "";
                        txtbxref2addr.Text = dtTemp.Rows[0]["KYC_REF2_ADDR"] != DBNull.Value ? dtTemp.Rows[0]["KYC_REF2_ADDR"].ToString() : "";
                        txtbxref2contactno.Text = dtTemp.Rows[0]["KYC_REF2_CONTACT"] != DBNull.Value ? dtTemp.Rows[0]["KYC_REF2_CONTACT"].ToString() : "";
                        
                        //   con.Open();
                        SqlCommand cmd = new SqlCommand("RTS_SP_KYC_DETAILS_FETCH", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@KYC_LD_ID", lblLeadID.Text);

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds1 = new DataSet();
                        da.Fill(ds1);
                        //   con.Close();
                        if (ds1.Tables[0] != null && ds1.Tables[0].Rows.Count > 1)
                        {
                            string[] strAppl=null;
                             if (strValues.Length >6)
                             {
                               strAppl = strValues[7].ToString().Split('&');
                             }
                            StringBuilder strBuilder = new StringBuilder();
                            for (int n = 0; n < ds1.Tables[0].Rows.Count; n++)
                            {
                                if (n != 0)
                                {
                                    string[] strinner = strAppl[n - 1].Split(',');
                                    strBuilder.AppendLine("<table id='tblver1' runat='server'  cellpadding='0' cellspacing='0' border='1'style='width: 100%;border-style:initial;border-width:thin;' align='center'>");
                                    strBuilder.AppendLine("<tr> <td colspan='4'  style='font-size:small;font-weight:bold;' align='center' >" + ds1.Tables[0].Rows[n]["KYC_APP_TYPE"].ToString() + "</td></tr> ");
                                    strBuilder.AppendLine("<tr> <td style='font-size:small;font-weight:bold;width:39%;' align='left'>&nbsp;&nbsp; Verify Mobile</td> ");
                                    strBuilder.AppendLine("<td style='font-size:small;font-weight:bold;' align='left' class='auto-style5'> ");
                                    strBuilder.AppendLine("&nbsp;&nbsp;" + ds1.Tables[0].Rows[n]["KYC_CONTACT"].ToString() + "  ");
                                    strBuilder.AppendLine("<td style='font-size:small;font-weight:bold;color:black;'>");
                                    if (strinner[0].ToString() == "Y")
                                    {
                                        strBuilder.AppendLine(" <input  id='rdnAppCont" + n.ToString() + "Yes' checked='checked'  type='radio'  disabled='disabled'  runat='server'  onclick='setRadioDats(rdnAppCont" + n.ToString() + "Yes," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",1)'  value='Yes' name='rdnAppCont" + n.ToString() + "' />Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                    }
                                    else
                                    {
                                        strBuilder.AppendLine(" <input  id='rdnAppCont" + n.ToString() + "Yes'  type='radio'  runat='server'  disabled='disabled'  onclick='setRadioDats(rdnAppCont" + n.ToString() + "Yes," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",1)'  value='Yes' name='rdnAppCont" + n.ToString() + "' />Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                    }
                                    if (strinner[0].ToString() == "N")
                                    {
                                        strBuilder.AppendLine("<input   type='radio'  id='rdnAppCont" + n.ToString() + "No' checked='checked'   runat='server'  disabled='disabled' onclick='setRadioDats(0," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",1)'  value='No'  Font-Size='Small' name='rdnAppCont" + n.ToString() + "'/>No");
                                    }
                                    else
                                    {
                                        strBuilder.AppendLine("<input   type='radio'  id='rdnAppCont" + n.ToString() + "No'  runat='server'  disabled='disabled' onclick='setRadioDats(0," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",1)'  value='No'  Font-Size='Small' name='rdnAppCont" + n.ToString() + "'/>No");
                                    }
                                 
                                    strBuilder.AppendLine("</td></tr>");
                                    strBuilder.AppendLine("<tr> <td style='font-size:small;font-weight:bold;width:39%;' align='left'>&nbsp;&nbsp; Verify Name</td> ");
                                    strBuilder.AppendLine("<td style='font-size:small;font-weight:bold;' align='left' class='auto-style5'> ");
                                    strBuilder.AppendLine("&nbsp;&nbsp;" + Convert.ToString(ds1.Tables[0].Rows[n]["KYC_NAME"]) + "  ");
                                    strBuilder.AppendLine("<td style='font-size:small;font-weight:bold;color:black;'>");
                                    if (strinner[1].ToString() == "Y")
                                    {
                                        strBuilder.AppendLine(" <input  id='rdnAppName" + n.ToString() + "Yes' checked='checked'  disabled='disabled'   type='radio'  runat='server'  onclick='setRadioDats(1," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",2)'  value='Yes' name='rdnAppName" + n.ToString() + "' />Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                    }
                                    else
                                    {
                                        strBuilder.AppendLine(" <input  id='rdnAppName" + n.ToString() + "Yes'  type='radio'  runat='server'  disabled='disabled'  onclick='setRadioDats(1," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",2)'  value='Yes' name='rdnAppName" + n.ToString() + "' />Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                    }

                                    if (strinner[1].ToString() == "N")
                                    {
                                        strBuilder.AppendLine("<input   type='radio' checked='checked'  id='rdnAppName" + n.ToString() + "No'  runat='server'  disabled='disabled'  onclick='setRadioDats(0," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",2)'   value='No'  Font-Size='Small' name='rdnAppName" + n.ToString() + "'/>No");
                                    }
                                    else
                                    {
                                        strBuilder.AppendLine("<input   type='radio'  id='rdnAppName" + n.ToString() + "No'  runat='server'  disabled='disabled'  onclick='setRadioDats(0," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",2)'   value='No'  Font-Size='Small' name='rdnAppName" + n.ToString() + "'/>No");
                                    }

                                   
                                    strBuilder.AppendLine("</td></tr>");
                                    strBuilder.AppendLine("<tr> <td style='font-size:small;font-weight:bold;width:39%;' align='left'>&nbsp;&nbsp; Verify Address</td> ");
                                    strBuilder.AppendLine("<td style='font-size:small;font-weight:bold;' align='left' class='auto-style5'> ");
                                    strBuilder.AppendLine("&nbsp;&nbsp;" + Convert.ToString(ds1.Tables[0].Rows[n]["KYC_ADDR"]) + "  ");
                                    strBuilder.AppendLine("<td style='font-size:small;font-weight:bold;color:black;'>");
                                    if (strinner[2].ToString() == "Y")
                                    {
                                        strBuilder.AppendLine(" <input  id='rdnAppAddr" + n.ToString() + "Yes'  checked='checked'  disabled='disabled' type='radio'  runat='server'  onclick='setRadioDats(1," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",3)'  value='Yes' name='rdnAppAddr" + n.ToString() + "' />Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                    }
                                    else
                                    {
                                        strBuilder.AppendLine(" <input  id='rdnAppAddr" + n.ToString() + "Yes'  type='radio'  disabled='disabled'  runat='server'  onclick='setRadioDats(1," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",3)'  value='Yes' name='rdnAppAddr" + n.ToString() + "' />Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                    }
                                    if (strinner[2].ToString() == "N")
                                    {
                                        strBuilder.AppendLine("<input   type='radio'  id='rdnAppAddr" + n.ToString() + "No'  disabled='disabled'  checked='checked'  runat='server'  onclick='setRadioDats(0," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",3)'   value='No'  Font-Size='Small' name='rdnAppAddr" + n.ToString() + "'/>No");
                                    }
                                    else
                                    {
                                        strBuilder.AppendLine("<input   type='radio'  id='rdnAppAddr" + n.ToString() + "No'   disabled='disabled' runat='server'  onclick='setRadioDats(0," + n + "," + Convert.ToString(ds1.Tables[0].Rows.Count - 1) + ",3)'   value='No'  Font-Size='Small' name='rdnAppAddr" + n.ToString() + "'/>No");
                                    }
                                    
                                    strBuilder.AppendLine("</td></tr>");
                                    strBuilder.AppendLine(" </table>");
                                }


                            }
                            tdVerify.InnerHtml = tdVerify.InnerHtml.Replace("%tempTable%", strBuilder.ToString());
                        }
                        else
                        {
                            tdVerify.InnerHtml = tdVerify.InnerHtml.Replace("%tempTable%", "");
                        }
                    }
                    else
                    {
                        tblVerify.Visible = false; ;
                    }

                }
            }
        }


        lbLeadno.Visible = true;
        lbAppname.Visible = true;
        lbPDdate.Visible = true;
        lbLoanamt.Visible = true;
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;


        lbLeadno.Text = leadno.ToString();
        lbAppname.Text = appname;
        lbPDdate.Text = pddt;
        lbLoanamt.Text = lnamt;
        con.Close();
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Credit_QueryPopUp.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
       int Apprvamt = 0;

        int n = Convert.ToInt32(txtApprvamt.Text != "" ? txtApprvamt.Text : "0");

        if (txtApprvamt.Text != "")
        {
            Apprvamt = Convert.ToInt32(txtApprvamt.Text);
        }

        if (ddlApprv.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please Select Approved/Rejected", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    
        else if (ddlApprv.SelectedValue.ToString() == "Rejected" && ddlReason.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
     
     
       
        else
        {

            SqlCommand cmdinsert = new SqlCommand("RTS_SP_Update_BM_Approval", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@LD_BR_APRL", ddlApprv.SelectedIndex.ToString());
           // cmdinsert.Parameters.AddWithValue("@LD_CRAP_AMT", txtApprvamt.Text != "" ? txtApprvamt.Text : "0");
            cmdinsert.Parameters.AddWithValue("@LD_BR_CMTS", txtComment.Text);
            cmdinsert.Parameters.AddWithValue("@LD_BR_MBY", Session["ID"].ToString());
            cmdinsert.Parameters.AddWithValue("@LD_ID", Session["LeadID"].ToString());
            cmdinsert.Parameters.AddWithValue("@LD_BR_RSN_ID", ddlReason.SelectedValue.ToString());
            cmdinsert.Parameters.AddWithValue("@LD_BR_MDATE", DateTime.Now);


         int ncou=   cmdinsert.ExecuteNonQuery();
            if(ncou >0)
            {
                BindqueryGrid();
                tblVerify.Visible = false;
                uscMsgBox1.AddMessage("Two wheeler updated ", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }


           // sendMail(con);
        }

    }

    //public void sendMail(SqlConnection con)
    //{
    //    try
    //    {
    //        /////// mail ///////////
    //        //  strMailDetail = "";

    //        SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "'", con);
    //        SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
    //        DataSet dsdet = new DataSet();
    //        dadet.Fill(dsdet);

    //        SqlCommand cmdmail = new SqlCommand("select QRY_QUERY 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "' AND QRY_RSD_BY='C'", con);
    //        SqlDataAdapter damail = new SqlDataAdapter(cmdmail);
    //        DataSet dsmail = new DataSet();
    //        damail.Fill(dsmail);

    //        /// to whom//////
    //        int nBranch_ID = dsdet.Tables[0].Rows[0]["LD_BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["LD_BR_ID"]) : 0;
    //        SqlCommand cmdmailto = new SqlCommand("SELECT EM_BM,EM_AM,EM_CM,EM_BCC ,EM_CLM FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
    //        SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
    //        DataSet dsmailto = new DataSet();
    //        damailto.Fill(dsmailto);
    //        string clmid = "";
    //        if (dsmailto.Tables[0].Rows.Count != 0)
    //        {
    //            to = dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
    //            cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
    //            bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
    //            bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
    //            clmid = dsmailto.Tables[0].Rows[0]["EM_CLM"].ToString();
    //        }

    //        if (bcc != "" && bcc1 != "")
    //        {
    //            bcc2 = bcc + ";" + bcc1;
    //        }
    //        else if (bcc != "")
    //        {
    //            bcc2 = bcc;
    //        }
    //        else if (bcc1 != "")
    //        {
    //            bcc2 = bcc1;
    //        }
    //        else
    //        {
    //            bcc2 = "";
    //        }



    //        // to = "ManimaranK@equitasbank.com";
    //        // bcc2 = "ManimaranK@equitasbank.com";
    //        // cc = "rts-helpdesk@equitasbank.com";
    //        fromID = "RTS Alerts";
    //        toID = to;
    //        bcc2ID = bcc2;
    //        if (clmid != "")
    //            cc = cc + ";" + clmid;
    //        ccID = cc;
    //        // To Auto mail ///////
    //        System.Threading.Thread threadSendMails;

    //        threadSendMails = new System.Threading.Thread(delegate()
    //        {

    //            String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Credit " + ddlApprv.SelectedItem.ToString() + "<br/><br/>";
    //            BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
    //            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td>";
    //            BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + Session["Appname"].ToString() + "</strong></td></tr>";
    //            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + "</strong></td>";
    //            BodyTxt = BodyTxt + "<td>PD Amount</td><td><strong>" + Session["Loanamt"] + "</strong></td></tr></table><br/><br/>";
    //            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Address </td><td align='center'>:</td><td><strong>" + cusaddr + "</strong></td></tr>";
    //            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Mobile No.</td><td align='center'>:</td><td><strong>" + mobile + "</strong></td></tr></table><br/><br/>";



    //            //Cash Memo Report Written by Vijayan

    //            #region CashMemo



    //            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Credit_Memo_Detail_mailer", con);
    //            cmddd.Parameters.AddWithValue("@LD_ID", Session["Leadno"].ToString() != "--Select--" ? Session["Leadno"].ToString() : "");
    //            cmddd.Parameters.AddWithValue("@Lead_Type", "");
    //            cmddd.CommandType = CommandType.StoredProcedure;
    //            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //            DataSet dsdd = new DataSet();
    //            dadd.Fill(dsdd);
    //            if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
    //            {

    //                BodyTxt = BodyTxt + "<table width='50%' border='1' cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: Verdana, Arial, Tahoma; font-size:10px'>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#2F4F4F' ><td width='100%'>CREDIT MEMO REPORT</td></tr>";
    //                BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:10px'>";

    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Product.</td><td><strong>" + dsdd.Tables[0].Rows[0]["PR_CODE"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Customer Name.</td><td><strong>" + dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Area/Branch.</td><td><strong>" + dsdd.Tables[0].Rows[0]["LOCATION"].ToString() + "</strong></td></tr></table></td></tr>";

    //                BodyTxt = BodyTxt + "<tr bgcolor='#2F4F4F'><td width='100%'>ELIGIBLITY WORKING</td></tr>";
    //                BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:10px'>";

    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Applicant.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_APL"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Co-Applicant1.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_CAPL1"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Co-Applicant2.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_CAPL2"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Co-Applicant3.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_CAPL3"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Co-Applicant4.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_CAPL4"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Co-Applicant5.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_CAPL5"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Rental Income - if any.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_RINC"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Total Clubbed Income.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_CINC"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Other Personnel Oblication in total.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_OBLIG"].ToString() + "</strong></td></tr></table></td></tr>";


    //                BodyTxt = BodyTxt + "<tr bgcolor='#2F4F4F'><td width='100%'>ELIGIBLITY DETAILS</td></tr>";
    //                BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:10px'>";

    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Insurance Property Value.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_IPV"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Building Value.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_BV"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Land Value.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_LV"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Total Property Value.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_TPV"].ToString() + "</strong></td></tr></table></td></tr>";

    //                BodyTxt = BodyTxt + "<tr bgcolor='#2F4F4F'><td width='100%'>FINAL RECOMENDATION</td></tr>";
    //                BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:10px'>";

    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Tenor in months.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_TNR"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>ROI.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_ROI"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Loan Amount.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_LMNT"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>EMI.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_EMI"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Actual IIR / FOIR.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_IIR"].ToString() + " / " + dsdd.Tables[0].Rows[0]["CM_FOIR"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>LAP Property LTV%.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_LLTV"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Credit Condition.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_CREDIT"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Remarks.</td><td><strong>" + dsdd.Tables[0].Rows[0]["CM_REMARKS"].ToString() + "</strong></td></tr>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Approved  By/ Date.</td><td><strong>" + dsdd.Tables[0].Rows[0]["EMP_NAME"].ToString() + " / " + dsdd.Tables[0].Rows[0]["APPDATE"].ToString() + "</strong></td></tr></td></tr>";


    //                BodyTxt = BodyTxt + "</table></td></tr></table>";
    //            }
    //            #endregion CashMemo

    //            //End of Cash memo report



    //            int b = dsmail.Tables[0].Rows.Count;
    //            if (b != 0)
    //            {
    //                BodyTxt = BodyTxt + "<table width='100%' border='1' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
    //                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='center'>Sl. No.</td>";
    //                BodyTxt = BodyTxt + "<td  align='center'>Credit Query Details</td>";
    //                BodyTxt = BodyTxt + "<td  align='center'>Query Date</td>";
    //                BodyTxt = BodyTxt + "<td  align='center'>Response</td>";
    //                BodyTxt = BodyTxt + "<td  align='center'>Response Date</td>";
    //                BodyTxt = BodyTxt + "<td  align='center'>Resolve Date</td></span></tr>";
    //                for (int j = 0; j <= b - 1; j++)
    //                {
    //                    int sno = j + 1;
    //                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='right'> " + sno + "</td>";
    //                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Query Raised"].ToString() + "</td>";
    //                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Date"].ToString() + "</td>";
    //                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response"].ToString() + "</td>";
    //                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response Date"].ToString() + "</td>";
    //                    BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Resolve Date"].ToString() + "</td></span></tr>";
    //                }
    //                BodyTxt = BodyTxt + "</table>";
    //            }
    //            if (ddlApprv.SelectedItem.ToString() == "Approved")
    //            {
    //                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Credit Approved Amount : " + txtApprvamt.Text + "<br/>Credit Comments :" + txtComment.Text + "</td></tr>";
    //            }
    //            else
    //            {
    //                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/>Credit Comments :" + txtComment.Text + "</td></tr>";
    //            }
    //            BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>Credit Team</td></tr>";
    //            BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
    //            //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

    //            blMailStatus = sendemail(to, "RTS Alerts", "", cc, "Lead No. : " + Session["Leadno"].ToString() + " - Applicant Name : " + Session["Appname"].ToString() + " - Product: " + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + " - Credit " + ddlApprv.SelectedItem.ToString() + "", BodyTxt, "", true);
    //            //sendemail("SurendharR@equitasbank.com;PrabhakaranA@equitasbank.com;Tamilalagand@equitasbank.com", "surendharr@equitasbank.com", "Test", BodyTxt, "", true);

    //            strMailBody = BodyTxt.Replace("<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Credit " + ddlApprv.SelectedItem.ToString() + "<br/><br/>", "");
    //            strMailBody = BodyTxt.Replace("</html>", " ");


    //        });
    //        // strMailDetail = to + "," + bcc2 + "," + cc;
    //        threadSendMails.IsBackground = true;

    //        threadSendMails.Start();
    //        System.Threading.Thread.Sleep(5000);

    //    }
    //    catch (Exception ex)
    //    {
    //        // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
    //    }

    //}
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("TeleVerification.aspx");
    }
   
    protected void ddlApprv_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlReason.SelectedIndex = 0;
        if (ddlApprv.SelectedValue.ToString() == "Rejected")
        {
            //  bind();
            ddlReason.Enabled = true;
            txtApprvamt.Text = "";
            txtApprvamt.Enabled = false;
        }
        else
        {
            //  bind();
            ddlReason.Enabled = false;
            txtApprvamt.Text = "";
            txtApprvamt.Enabled = true;
        }
    }
}