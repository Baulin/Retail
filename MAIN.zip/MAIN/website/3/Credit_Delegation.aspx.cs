﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Text.RegularExpressions;
using Tracker;

public partial class Credit_Delegation : System.Web.UI.Page
{
    ClsCommon clscommon=new ClsCommon();
    int emptypeid;
    int brid;
    int acctype;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    Regex Rx = new Regex("^[A-Za-z0-9/-_]");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            bind();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("select DISTINCT ET_DESC from MR_EMP_TYPE", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmddd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
          
          
        }

    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        if (Session["TYPEID"].ToString() == "2")
        {
            SqlCommand cmd = new SqlCommand("SELECT EMP_ID, EMP_CODE 'EMP. CODE',EMP_NAME 'EMP. NAME',ET_DESC 'EMP. TYPE',BR_NAME 'BR. NAME',EMP_PHNO 'CONTACT NO.', EMP_EMAILID, EMP_STAT,CASE WHEN EMP_STAT='1' THEN 'WORKING' ELSE 'RESIGNED' END  AS 'EMPSTATUS',EMP_TYPE [TYPE] FROM MR_EMPLOYEE A JOIN MR_EMP_TYPE B ON A.EMP_ET_ID=B.ET_ID JOIN MR_BRANCH C ON A.EMP_BR_ID=C.BR_ID JOIN MR_USER D ON D.USR_EMP_ID= A.EMP_ID where EMP_BR_ID='" + Session["BRANCHID"] + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            gvEmp.DataSource = ds;
            gvEmp.DataBind();

            if (gvEmp.Rows.Count > 0)
            {
                gvEmp.UseAccessibleHeader = true;
                gvEmp.HeaderRow.TableSection = TableRowSection.TableHeader;
                gvEmp.HeaderRow.Font.Bold = true;
                gvEmp.HeaderRow.Cells[0].Wrap = false;
                gvEmp.HeaderRow.Cells[1].Wrap = false;
                gvEmp.HeaderRow.Cells[2].Wrap = false;
                gvEmp.HeaderRow.Cells[3].Wrap = false;
                gvEmp.HeaderRow.Cells[4].Wrap = false;
            }
        }
        else
        {
           /* SqlCommand cmd = new SqlCommand("SELECT EMP_ID, EMP_CODE 'EMP. CODE',EMP_NAME 'EMP. NAME',ET_DESC 'EMP. TYPE',BR_NAME 'BR. NAME',EMP_PHNO 'CONTACT NO.', EMP_EMAILID, EMP_STAT, EMP_TYPE [TYPE],EMP_APRV_AMT FROM MR_EMPLOYEE A JOIN MR_EMP_TYPE B ON A.EMP_ET_ID=B.ET_ID JOIN MR_BRANCH C ON A.EMP_BR_ID=C.BR_ID JOIN MR_USER D ON D.USR_EMP_ID= A.EMP_ID where EMP_ET_ID in (6,7,28) and D.USR_STAT = 1 ORDER BY EMP_CODE", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            gvEmp.DataSource = ds;
            gvEmp.DataBind();
            */
            DataSet ds = new DataSet();
            ds = clscommon.BindDataForDelegation();
            gvEmp.DataSource = ds;
            gvEmp.DataBind();

            if (gvEmp.Rows.Count > 0)
            {
                gvEmp.UseAccessibleHeader = true;
                gvEmp.HeaderRow.TableSection = TableRowSection.TableHeader;
                gvEmp.HeaderRow.Font.Bold = true;
                gvEmp.HeaderRow.Cells[0].Wrap = false;
                gvEmp.HeaderRow.Cells[1].Wrap = false;
                gvEmp.HeaderRow.Cells[2].Wrap = false;
                gvEmp.HeaderRow.Cells[3].Wrap = false;
                gvEmp.HeaderRow.Cells[4].Wrap = false;
            }
        }
        // ScriptManager.RegisterStartupScript(Page, this.GetType(), "Key", "<script>MakeStaticHeader('" + gvEmp.ClientID + "', 250, 1000 , 27 ,true); </script>", false);
    }

    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            TextBox txtDeliveryDate = (TextBox)e.Row.FindControl("txtEmpAprvAmt");

            if (DataBinder.Eval(e.Row.DataItem, "EMP_APRV_AMT") != null)
            {
                txtDeliveryDate.Text = DataBinder.Eval(e.Row.DataItem, "EMP_APRV_AMT").ToString();
            }

        }
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
      
    }
   

    //protected void MyCustomValidator_ServerValidate(object source, ServerValidateEventArgs args)
    //{
    //    if ((txtEmailid.Text == "") && (ddlempcontype.SelectedItem.Text == "ThirdParty"))
    //    {
    //        args.IsValid = false;
    //    }
    //    else
    //    {
    //        args.IsValid = true;
    //    }
        
    //}



    public void gvEmp_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {


            if (e.CommandName == "NewUpdate")
            {
                int emp_id = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                TextBox txtEmpAprvAmt = (TextBox)row.FindControl("txtEmpAprvAmt");
                LinkButton lnkUpdate = (LinkButton)row.FindControl("lnkUpdate");
                string strClientID = string.Empty;
                strClientID=lnkUpdate.ClientID;
                if (txtEmpAprvAmt.Text != "")
                {

                    clscommon.UpdateCreditEmployeeApprovalAmount(emp_id, Convert.ToDecimal(txtEmpAprvAmt.Text));

                    bind();
                    uscMsgBox1.AddMessage("Credit approval amount has been updated successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                     //ScriptManager.RegisterClientScriptBlock(lnkUpdate, this.GetType(), "alert", "swal('Credit approval amount has been updated successfully','','success');", true);
                     
                }
                else
                {
                 //  uscMsgBox1.AddMessage("Please enter the approval amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    ScriptManager.RegisterClientScriptBlock(lnkUpdate, this.GetType(), "alert", "swal({title:'Heyyy!!!',text:'Please enter the approval amount',imageUrl:'Images/JPG/enter.jpg'});", true);
                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
}
