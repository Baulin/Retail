﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Credit_PD_Completion : System.Web.UI.Page
{
    int rsnid;
    string orcdt;
    string currentdt;
    string[] leadno;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
             if (Session["ID"] != null)
            {
         //   txtBranch.Text = Session["UNITNAME"].ToString();
            bind();
            End_use();
            txt_enduse1.Visible = false;
            }
             else
             {
                 Response.Redirect("expire.aspx");
             }
        }
    }

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        SqlCommand cmddd1 = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con);
        cmddd1.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da2 = new SqlDataAdapter(cmddd1);
        DataSet ds2 = new DataSet();
        da2.Fill(ds2);

        SqlCommand cmddd3 = new SqlCommand("RTS_SP_Fetch_MR_REASON", con);
        cmddd3.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da3 = new SqlDataAdapter(cmddd3);
        DataSet ds3 = new DataSet();
        da3.Fill(ds3);
      
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();



        //if (ds1.Tables[0].Rows.Count != 0)
        //{

        //}
        //if (ds2.Tables[0].Rows.Count != 0)
        //{
        //bala changes 15032017
        // DataTable dtTempprod = ds2.Tables[0].Select("PR_CODE Like '%G%' OR   PR_CODE Like '%BL%'").CopyToDataTable();
        DataTable dtTempprod = ds2.Tables[0].Select("PR_CODE Like '%G%' OR PR_ID in (9,10,11,15,16,18,19,20,21,22,23,28,31,32,36,37,38,55)").CopyToDataTable();
        ddlProduct.DataSource = dtTempprod;
        ddlProduct.DataTextField = "PR_CODE";
        ddlProduct.DataValueField = "PR_ID";
        ddlProduct.DataBind();
        ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));
        // }
        //if (ds3.Tables[0].Rows.Count != 0)
        //{
        ddlReason.DataSource = ds3;
        ddlReason.DataTextField = "RSN_REASON";
        ddlReason.DataValueField = "RSN_ID";
        ddlReason.DataBind();
        ddlReason.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        //}
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (ddlPDstatus.SelectedValue.ToString() == "Rejected")
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            if (ddlReason.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                rsnid = Convert.ToInt32(ddlReason.SelectedValue.ToString());
                Session["rsnid"] = rsnid;
                txtLoanamt.Text = "NULL";
            }
            con.Close();
        }
        if (txt_pd_dt.Text == "")
        {
            uscMsgBox1.AddMessage("Please Select Date from Picker", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            //string value = Request.Form["Datepick"];
            string value = txt_pd_dt.Text;
            //DateTime dob = DateTime.Parse(Request.Form[FindControl("txtDate").UniqueID]);
            orcdt = txtLeaddt.Text;
            System.Globalization.DateTimeFormatInfo dateInfo = new System.Globalization.DateTimeFormatInfo();
            dateInfo.ShortDatePattern = "yyyy/MM/dd";
            System.Globalization.DateTimeFormatInfo recInfo = new System.Globalization.DateTimeFormatInfo();
            dateInfo.ShortDatePattern = "yyyy/MM/dd";
            System.Globalization.DateTimeFormatInfo curdt = new System.Globalization.DateTimeFormatInfo();
            dateInfo.ShortDatePattern = "yyyy/MM/dd";

            currentdt = String.Format("{0:dd MMM yyyy}", dt);

            DateTime validDate = Convert.ToDateTime(value, dateInfo);
            DateTime receiveddt = Convert.ToDateTime(orcdt, recInfo);
            DateTime currdt = Convert.ToDateTime(currentdt, curdt);
            if (receiveddt <= validDate && validDate <= currdt)
            {
                if (ddlPDstatus.SelectedValue.ToString() == "Recommended" && txtLoanamt.Text == "")
                {
                    uscMsgBox1.AddMessage("Please Enter Loan Amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (ddlPDstatus.SelectedValue.ToString() == "Rejected" && txtRemarks.Text == "" && ddlProduct.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please Enter Remarks and Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (ddlPDstatus.SelectedValue.ToString() == "Rejected" && txtRemarks.Text == "")
                {
                    uscMsgBox1.AddMessage("Please Enter Remarks", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (ddlPDstatus.SelectedValue.ToString() == "Rejected" && ddlProduct.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (txtResidenceAddr.Text == "")
                {
                    txtResidenceAddr.Focus();
                    uscMsgBox1.AddMessage("Please Enter Resident Address", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (txtPropAddr.Text == "")
                {
                    txtPropAddr.Focus();
                    uscMsgBox1.AddMessage("Please Enter Property Address", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                //else if (txtEnduser.Text == "")
                //{
                //    txtEnduser.Focus();
                //    uscMsgBox1.AddMessage("Please Enter End Use", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //}
                else if (ddl_Enduse.SelectedValue == "0")
                {
                    ddl_Enduse.Focus();
                    uscMsgBox1.AddMessage("Please Enter End Use", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else
                {
                    SqlConnection con = new SqlConnection(strcon);
                    try
                    {
                        con.Open();

                        SqlCommand cmd = new SqlCommand("RTS_SP_Credit_Update_LSD_LEAD", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@PDstatus", SqlDbType.Int).Value = ddlPDstatus.SelectedIndex;
                        cmd.Parameters.Add("@LD_PD_DATE", SqlDbType.DateTime).Value = validDate;
                        cmd.Parameters.Add("@LD_PD_STAT", SqlDbType.Int).Value = ddlPDstatus.SelectedIndex;

                        cmd.Parameters.Add("@LD_PD_AMT", SqlDbType.VarChar).Value = txtLoanamt.Text.Trim();
                        cmd.Parameters.Add("@LD_PD_MBY", SqlDbType.VarChar).Value = Session["ID"] != null ? Session["ID"].ToString() : "";
                        cmd.Parameters.Add("@LD_NO", SqlDbType.VarChar).Value = Session["leadid"] != null ? Session["leadid"].ToString() : "";
                        if (Session["rsnid"].ToString() != "NULL")
                        {
                            cmd.Parameters.Add("@LD_PD_RSN_ID", SqlDbType.Int).Value = Convert.ToInt32(Session["rsnid"]);
                        }
                        else
                        {
                            cmd.Parameters.Add("@LD_PD_RSN_ID", SqlDbType.Int).Value = 0;
                        }
                        
                       cmd.Parameters.Add("@LD_PD_USE", SqlDbType.VarChar).Value = ddl_Enduse.SelectedItem.Text.Trim();
                        //cmd.Parameters.Add("@LD_PD_USE", SqlDbType.VarChar).Value = txtEnduser.Text.Trim();
                        cmd.Parameters.Add("@LD_PD_RMK", SqlDbType.VarChar).Value = txtRemarks.Text.Trim();
                        cmd.Parameters.Add("@LD_ADDRESS", SqlDbType.VarChar).Value = txtPropAddr.Text.Trim();
                        cmd.Parameters.Add("@LD_RADDRESS", SqlDbType.VarChar).Value = txtResidenceAddr.Text.Trim();
                        SqlDataAdapter showdata = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        showdata.Fill(ds);
                        if (ds != null)
                        {
                            bind();
                            
                            txt_pd_dt.Text = "";
                            txtLoanamt.Text = "";
                            txtRemarks.Text = "";
                            btnSubmit.Enabled = false;
                            if (ddlPDstatus.SelectedIndex == 1)
                            {
                                uscMsgBox1.AddMessage("PD Completed Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                                clear();
                            }
                            else
                            {
                                uscMsgBox1.AddMessage("PD Rejected Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                            }
                        }



                    }
                    catch (Exception ex)
                    {
                        uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        ErrorLog.WriteError(ex);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }

            else
            {
                uscMsgBox1.AddMessage("Please Select valid PD Date from Datepicker", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Credit_PD_Completion.aspx");
    }
    protected void ddlProduct_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        ddlLeadno.Enabled = true;
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Credit_Product_Details", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.Add("@BR_NAME", SqlDbType.VarChar).Value = ddlBranch.SelectedItem.Text.Trim();
        cmddd.Parameters.Add("@PR_CODE", SqlDbType.VarChar).Value = ddlProduct.SelectedItem.ToString();
        SqlDataAdapter da1 = new SqlDataAdapter(cmddd);
        DataSet ds1 = new DataSet();
        da1.Fill(ds1);
        con.Close();
        ddlLeadno.DataSource = ds1;
        ddlLeadno.DataTextField = "LEAD";
        ddlLeadno.DataValueField = "LEAD";
        ddlLeadno.DataBind();
        ddlLeadno.Items.Insert(0, new ListItem("--Select--", "0"));
        txt_pd_dt.Text = DateTime.Now.ToString("MM/dd/yyyy");
       
       
    }
    protected void ddlPDstatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlPDstatus.SelectedValue.ToString() == "Recommended")
        {
            btnSubmit.Enabled = true;
            txtLoanamt.Enabled = true;
            ddlReason.Enabled = false;
            txtRemarks.Enabled = false;
            Session["rsnid"] = "NULL";

        }
        else if (ddlPDstatus.SelectedValue.ToString() == "Rejected")
        {
            btnSubmit.Enabled = true;
            txtLoanamt.Enabled = false;
            ddlReason.Enabled = true;
            txtRemarks.Enabled = true;
        }
    }
    protected void ddlLeadno_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            leadno = ddlLeadno.SelectedValue.ToString().Split('-');
            Session["leadid"] = leadno[0].ToString();
            SqlCommand cmddt = new SqlCommand("RTS_SP_Fetch_Lead_Details", con);
            cmddt.CommandType = CommandType.StoredProcedure;
            cmddt.Parameters.Add("@LD_NO", SqlDbType.VarChar).Value = Session["leadid"] != null ? Session["leadid"].ToString() : "";
            SqlDataAdapter dadt = new SqlDataAdapter(cmddt);
            DataSet dsdt = new DataSet();
            dadt.Fill(dsdt);
            DateTime leaddt = Convert.ToDateTime(dsdt.Tables[0].Rows[0]["LD_DATE"]);
            txtLeaddt.Text = String.Format("{0:dd MMM yyyy}", leaddt);
            ddlPDstatus.Enabled = true;
            txtResidenceAddr.Focus();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_NAME";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
     
    }
    //SENTHIL

    //28-08-2015


    protected void End_use()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_MR_ENDUSE", con);

        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        
        con.Close();
        ddl_Enduse.DataSource = dsdd;
            ddl_Enduse.DataTextField = "EU_DESC";
            ddl_Enduse.DataValueField = "EU_DESC";
            ddl_Enduse.DataBind();
            ddl_Enduse.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    protected void clear()
    {
        txt_pd_dt.Text = "";
        txtLoanamt.Text = "";
        txtPropAddr.Text = "";
        txtRemarks.Text = "";
        ddl_Enduse.SelectedIndex = 0;
        ddlPDstatus.SelectedIndex = 0;
        ddlProduct.SelectedIndex = 0;
        ddlLeadno.SelectedIndex = 0;
        txtResidenceAddr.Text = "";

        ddlBranch.SelectedIndex = 0;
    }

    protected void ddl_Enduse_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddl_Enduse.SelectedItem.Text.Trim() == "Others")
        {
            txt_enduse1.Visible = true;

        }
        else
        {
            txt_enduse1.Visible = false;
        }
    }
}