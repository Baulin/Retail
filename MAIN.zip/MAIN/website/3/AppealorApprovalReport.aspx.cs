﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using System.Text.RegularExpressions;
using Tracker;


public partial class AppealorApprovalReport : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    Regex Rx = new Regex("^[0-9]+$");
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnSubmit);
        if (!IsPostBack)
        {
           // BindLeadNo();
        }
    }
    public void BindLeadNo()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_For_Apprv_Report", con);
        cmddd.Parameters.AddWithValue("@LD_NO", "");
        cmddd.Parameters.AddWithValue("@Lead_Type", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLeadNo.DataSource = dsdd;
        ddlLeadNo.DataTextField = "LD_NO";
        ddlLeadNo.DataValueField = "LD_ID";
        ddlLeadNo.DataBind();
        ddlLeadNo.Items.Insert(0, "Select");
    }
    protected void ddlLeadNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlLeadNo.SelectedIndex > 0)
        {
            GenerateReport();
        }
    }
    public void GenerateReport()
    {
          SqlConnection con = new SqlConnection(strcon);
        try
        {
          
            con.Open();
            SqlCommand cmddd11 = new SqlCommand("select LD_ID from lsd_lead where LD_NO='" + txtLeadNo.Text + "'", con);
            SqlDataAdapter dadd11 = new SqlDataAdapter(cmddd11);
            DataSet dsdd11 = new DataSet();
            dadd11.Fill(dsdd11);

            if (dsdd11.Tables[0] != null && dsdd11.Tables[0].Rows.Count > 0)
            {
                string strLeadID = dsdd11.Tables[0].Rows[0][0] != DBNull.Value ? dsdd11.Tables[0].Rows[0][0].ToString() : "0";
                SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAMSummary_Report", con);
                cmddd.Parameters.AddWithValue("@Lead_ID", strLeadID);
                cmddd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
                DataSet dsdd = new DataSet();
                dadd.Fill(dsdd);


                if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
                {
                    lblBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                    lblCustomerName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";

                    lblNetIncomeafterfactoring.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";
                    lblNetIncomeafterfactoring_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TOT_IN"].ToString() : "";
                    if (lblNetIncomeafterfactoring.Text != "" && lblNetIncomeafterfactoring_CI.Text != "")
                    {
                        lblNetIncomeafterfactoring_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblNetIncomeafterfactoring_CI.Text) * 100) / Convert.ToDouble(lblNetIncomeafterfactoring.Text)));
                    }

                    lblObligation.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";
                    lblObligation_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TOT_EMI"].ToString() : "";

                    if (lblObligation.Text != "" && lblObligation_CI.Text != "")
                    {
                        lblObligation_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblObligation_CI.Text) * 100) / Convert.ToDouble(lblObligation.Text)));
                    }

                    lblLandSQFT.Text = dsdd.Tables[0].Rows[0]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAREA"].ToString() : "";
                    lblLandSQFT_CI.Text = dsdd.Tables[0].Rows[1]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_LAREA"].ToString() : "";
                    if (lblLandSQFT.Text != "" && lblLandSQFT_CI.Text != "")
                    {
                        lblLandSQFT_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblLandSQFT_CI.Text) * 100) / Convert.ToDouble(lblLandSQFT.Text)));
                    }

                    lblReginet.Text = dsdd.Tables[0].Rows[0]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_GLV"].ToString() : "";
                    lblReginet_CI.Text = dsdd.Tables[0].Rows[1]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_GLV"].ToString() : "";

                    if (lblReginet.Text != "" && lblReginet_CI.Text != "")
                    {
                        lblReginet_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblReginet_CI.Text) * 100) / Convert.ToDouble(lblReginet.Text)));
                    }


                    lblMarketvalue.Text = dsdd.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
                    lblMarketvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_MV"].ToString() : "";
                    if (lblMarketvalue.Text != "" && lblMarketvalue_CI.Text != "")
                    {
                        lblMarketvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblMarketvalue_CI.Text) * 100) / Convert.ToDouble(lblMarketvalue.Text)));
                    }

                    lblTotalLandvalue.Text = dsdd.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CLV"].ToString() : "";
                    lblTotalLandvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_CLV"].ToString() : "";
                    if (lblTotalLandvalue.Text != "" && lblTotalLandvalue_CI.Text != "")
                    {
                        lblTotalLandvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblTotalLandvalue_CI.Text) * 100) / Convert.ToDouble(lblTotalLandvalue.Text)));
                    }

                    lblBuildingType.Text = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "";
                    lblBuildingType_CI.Text = dsdd.Tables[0].Rows[1]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["PT_DESC"].ToString() : "";


                    lblAgeofbuilding.Text = dsdd.Tables[0].Rows[0]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BA_DESC"].ToString() : "";
                    lblAgeofbuilding_CI.Text = dsdd.Tables[0].Rows[1]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["BA_DESC"].ToString() : "";
                    //if (lblAgeofbuilding.Text != "" && lblAgeofbuilding_CI.Text != "")
                    //{
                    //    lblAgeofbuilding_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblAgeofbuilding_CI.Text) * 100) / Convert.ToDouble(lblAgeofbuilding.Text)));
                    //}

                    if (Rx.IsMatch(lblAgeofbuilding.Text) && Rx.IsMatch(lblAgeofbuilding_CI.Text))
                    {
                        if (lblAgeofbuilding.Text != "" && lblAgeofbuilding_CI.Text != "")
                        {
                            lblAgeofbuilding_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblAgeofbuilding_CI.Text) * 100) / Convert.ToDouble(lblAgeofbuilding.Text)));
                        }
                    }
                    else
                    {
                    }

                    lblBuildingValue.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
                    lblBuildingValue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_CBV"].ToString() : "";
                    if (lblBuildingValue.Text != "" && lblBuildingValue_CI.Text != "")
                    {
                        lblBuildingValue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblBuildingValue_CI.Text) * 100) / Convert.ToDouble(lblBuildingValue.Text)));
                    }

                    lblTotalpropertyvalue.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
                    lblTotalpropertyvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TPV"].ToString() : "";
                    if (lblTotalpropertyvalue.Text != "" && lblTotalpropertyvalue_CI.Text != "")
                    {
                        lblTotalpropertyvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblTotalpropertyvalue_CI.Text) * 100) / Convert.ToDouble(lblTotalpropertyvalue.Text)));
                    }

                    lblLoanamountrecommeded.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
                    lblLoanamountrecommeded_CR.Text = dsdd.Tables[0].Rows[1]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_RLA"].ToString() : "";
                    if (lblLoanamountrecommeded.Text != "" && lblLoanamountrecommeded_CR.Text != "")
                    {
                        lblLoanamountrecommeded_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblLoanamountrecommeded_CR.Text) * 100) / Convert.ToDouble(lblLoanamountrecommeded.Text)));
                    }


                    SqlCommand cmddd1 = new SqlCommand("Fetch_SAM_Approval_Appeal_Details", con);
                    cmddd1.Parameters.AddWithValue("@SD_LD_ID", strLeadID);
                    cmddd1.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter dadd1 = new SqlDataAdapter(cmddd1);
                    DataSet dsdd1 = new DataSet();
                    dadd1.Fill(dsdd1);
                    if (dsdd1.Tables[0] != null && dsdd1.Tables[0].Rows.Count > 0)
                    {
                        txtNetIncomeafterfactoringRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_NETIN"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_NETIN"].ToString() : "";
                        txtObligationRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_OBLIG"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_OBLIG"].ToString() : "";
                        txtLandSQFTRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_SQFT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SQFT"].ToString() : "";
                        txtReginetRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_GV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_GV"].ToString() : "";
                        txtMarketvalueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_MV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_MV"].ToString() : "";
                        txtTotalLandvalueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_LV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_LV"].ToString() : "";
                        txtBuildingTypeRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_BTYPE"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_BTYPE"].ToString() : "";
                        txtAgeofbuildingRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_BAGE"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_BAGE"].ToString() : "";
                        txtBuildingValueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_BV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_BV"].ToString() : "";
                        txtTotalpropertyvalueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_PV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_PV"].ToString() : "";
                        txtLoanamountrecommeded.Text = dsdd1.Tables[0].Rows[0]["SL_LAMT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_LAMT"].ToString() : "";


                        txtGvalue.Text = dsdd1.Tables[0].Rows[0]["SL_RGV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RGV"].ToString() : "";
                        txtMarkVal.Text = dsdd1.Tables[0].Rows[0]["SL_RMV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RMV"].ToString() : "";
                        txtLandArea.Text = dsdd1.Tables[0].Rows[0]["SL_RSQFT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RSQFT"].ToString() : "";
                        txtBMLandValue.Text = dsdd1.Tables[0].Rows[0]["SL_RLV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RLV"].ToString() : "";

                        lblTolerance.Text = dsdd1.Tables[0].Rows[0]["SL_TOL"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_TOL"].ToString() : "";
                        lblApprveStatus.Text = dsdd1.Tables[0].Rows[0]["SL_DECSN"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_DECSN"].ToString() : "";
                        if (lblApprveStatus.Text != "Rejected")
                        {

                            trResult.Visible = false;
                            lblRcmnd.Visible = true;
                            txtFinalRcmnd.Visible = true;
                            txtFinalRcmnd.Text = dsdd1.Tables[0].Rows[0]["SL_RAMT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RAMT"].ToString() : "";
                        }
                        else
                        {
                            trResult.Visible = true;
                        }
                        string strRType = dsdd1.Tables[0].Rows[0]["SL_RTYPE"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RTYPE"].ToString() : "";
                        string strRejStatus = "";
                        //if (strRType == "SPOT")
                        //{
                        //    strRType = "SPOT";

                        //}
                        //else if (strRType == "PDD")
                        //{
                        //    strRType = "PDD";
                        //    rdnPDD.Checked = true;
                        //    trSPot.Visible = false;
                        //    trBussEmpRelt.Visible = false;
                        //    trIncomeTol.Visible = false;
                        //    trPropRel.Visible = false;
                        //    trVerRel.Visible = false;
                        //}

                        string strMRISK = dsdd1.Tables[0].Rows[0]["SL_MRISK"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_MRISK"].ToString() : "";
                        //if (strMRISK == "Business/Employee Related")
                        //{
                        //    rdnBussEmpRelated.Checked = true;
                        //    trBussEmpRelt.Visible = true;
                        //    trIncomeTol.Visible = false;
                        //    trPropRel.Visible = false;
                        //    trVerRel.Visible = false;

                        //}
                        //else if (strMRISK == "Income Related")
                        //{
                        //    rdnIncomeRelated.Checked = true;
                        //    trBussEmpRelt.Visible = false;
                        //    trIncomeTol.Visible = true;
                        //    trPropRel.Visible = false;
                        //    trVerRel.Visible = false;
                        //}
                        //else if (strMRISK == "Property Related")
                        //{
                        //    rdnPropRelated.Checked = true;
                        //    trBussEmpRelt.Visible = false;
                        //    trIncomeTol.Visible = false;
                        //    trPropRel.Visible = true;
                        //    trVerRel.Visible = false;
                        //}
                        //else if (strMRISK == "Verification Related")
                        //{
                        //    rdnVerRelated.Checked = true;
                        //    rdnVerRel.Checked = true;
                        //    trBussEmpRelt.Visible = false;
                        //    trIncomeTol.Visible = false;
                        //    trPropRel.Visible = false;
                        //    trVerRel.Visible = true;
                        //}


                        string strSRISK = dsdd1.Tables[0].Rows[0]["SL_SRISK"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SRISK"].ToString() : "";
                        //if (strSRISK == "Business/Employment Related")
                        //{
                        //    rdnBussEmpRel.Checked = true;
                        //}
                        //else if (strSRISK == "Incorrect Business/Employment Related information")
                        //{
                        //    rdnBussEmpRe2.Checked = true;
                        //}
                        //else if (strSRISK == "Income Tolerance Level")
                        //{
                        //    rdbIncomeTolerance.Checked = true;
                        //}
                        //else if (strSRISK == "Building Age")
                        //{
                        //    rdnBuildAge.Checked = true;
                        //}
                        //else if (strSRISK == "Building Area")
                        //{
                        //    rdnBuildArea.Checked = true;
                        //}
                        //else if (strSRISK == "Incorrect Property Information")
                        //{
                        //    rdnIncorrectBuildDet.Checked = true;
                        //}
                        //else if (strSRISK == "Incorrect Property Information")
                        //{
                        //    rdnIncorrectBuildDet.Checked = true;
                        //}
                        strRejStatus = strRType + " --> " + strMRISK + " --> " + strSRISK;
                        lblRejectStatus1.Text = strRejStatus;
                        txtRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_RMKS"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RMKS"].ToString() : "";

                        string strVal = dsdd1.Tables[0].Rows[0]["SL_SCI_DESCN"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SCI_DESCN"].ToString() : "";
                        if (strVal != "")
                        {
                            trSciAppeal1.Visible = true;
                            trSciAppeal2.Visible = true;
                            lblSciappel.Text = strVal;
                            if (lblSciappel.Text != "Rejected")
                            {
                                lblRcmnd.Visible = true;
                                txtFinalRcmnd0.Visible = true;
                                txtFinalRcmnd0.Text = dsdd1.Tables[0].Rows[0]["SL_RAMT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RAMT"].ToString() : "";
                            }
                            txtRmrk0.Text = dsdd1.Tables[0].Rows[0]["SL_SCI_RMKS"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SCI_RMKS"].ToString() : "";
                        }
                        else
                        {
                            trSciAppeal1.Visible = false;
                            trSciAppeal2.Visible = false;
                        }

                        string strVal1 = dsdd1.Tables[0].Rows[0]["SL_ACI_DESCN"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_ACI_DESCN"].ToString() : "";
                        if (strVal1 != "")
                        {
                            trAmciAppeal1.Visible = true;
                            trAmciAppeal2.Visible = true;
                            lblAmci.Text = strVal1;
                            if (lblAmci.Text != "Rejected")
                            {
                                lblFinalRecmnd1.Visible = true;
                                txtAMCRAMT.Visible = true;
                                txtAMCRAMT.Text = dsdd1.Tables[0].Rows[0]["SL_RAMT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RAMT"].ToString() : "";
                            }
                            txtAMCApprv.Text = dsdd1.Tables[0].Rows[0]["SL_ACI_RMKS"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_ACI_RMKS"].ToString() : "";
                        }
                        else
                        {
                            trAmciAppeal2.Visible = false;
                            trAmciAppeal1.Visible = false;
                        }


                        if (dsdd.Tables[3] != null && dsdd.Tables[3].Rows.Count > 0)
                        {
                            trRpa1.Visible = false;
                            trRpa2.Visible = true;

                            lblBMGvalue.Text = lblReginet.Text;
                            lblFROGvalue.Text = dsdd.Tables[3].Rows[0]["RPA_GV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_GV"].ToString() : "";
                            if (lblBMGvalue.Text != "" && lblFROGvalue.Text != "")
                            {
                                lblVarGvalue.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFROGvalue.Text) * 100) / Convert.ToDouble(lblBMGvalue.Text)));
                            }

                            lblBMMarkVal.Text = lblMarketvalue.Text;
                            lblFORMarkVal.Text = dsdd.Tables[3].Rows[0]["RPA_MV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_MV"].ToString() : "";
                            if (lblBMMarkVal.Text != "" && lblFORMarkVal.Text != "")
                            {
                                lblVarMarkVal.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFORMarkVal.Text) * 100) / Convert.ToDouble(lblBMMarkVal.Text)));
                            }

                            lblBMLandArea.Text = lblLandSQFT.Text;
                            lblFORLandArea.Text = dsdd.Tables[3].Rows[0]["RPA_LAREA"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_LAREA"].ToString() : "";
                            if (lblFORLandArea.Text != "" && lblBMLandArea.Text != "")
                            {
                                lblVarLandArea.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFORLandArea.Text) * 100) / Convert.ToDouble(lblBMLandArea.Text)));
                            }

                            lblBMLandValue.Text = lblTotalLandvalue.Text;
                            lblForLandValue.Text = dsdd.Tables[3].Rows[0]["RPA_LV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_LV"].ToString() : "";
                            if (lblBMLandValue.Text != "" && lblForLandValue.Text != "")
                            {
                                lblVarLandValue.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblForLandValue.Text) * 100) / Convert.ToDouble(lblBMLandValue.Text)));
                            }


                        }
                        else
                        {
                            trRpa1.Visible = true;
                            trRpa2.Visible = false;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void ddlApproove_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (lblApprveStatus.Text == "Rejected")
        {
            trResult.Visible = true;
        }
        else
        {
            trResult.Visible = false;

        }
    }
   
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //if (ddlAMCDescn.SelectedItem.Text == "--Select--")
        //{
        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Decision');", true);
        //    ddlAMCDescn.Focus();
        //}
        //else if (ddlAMCDescn.SelectedItem.Text == "Recommended" && txtAMCRAMT.Text.Trim() == "")
        //{
        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Give Final Recommended Amount');", true);
        //    txtAMCApprv.Focus();
        //}
        //else
        //{
        //    UpdateSamplingApprvlDatas();
        //}

        System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();

        img.ImageUrl = Server.MapPath("~/Images/JPG/MIFLogo.JPG");
        tdLogo.Controls.Add(img);

        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=Auto_CAM_LAP" + DateTime.Now.ToString() + ".pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        StringWriter sw0 = new StringWriter();
        HtmlTextWriter hw0 = new HtmlTextWriter(sw0);
        pnlHeader.RenderControl(hw0);

        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        pnlpdf.RenderControl(hw);

        StringReader sr1 = new StringReader(sw0.ToString() + "<br/>" + sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        pdfDoc.NewPage();
        pdfDoc.HtmlStyleClass = "PdfClass";
        htmlparser.Parse(sr1);
        pdfDoc.NewPage();

        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();  

    }

    public void UpdateSamplingApprvlDatas()
    {
        try
        {
            SqlConnection con1 = new SqlConnection(strcon);
            con1.Open();
            SqlCommand cmddd11 = new SqlCommand("select LD_ID from lsd_lead where LD_NO='" + txtLeadNo.Text + "'", con1);
            SqlDataAdapter dadd11 = new SqlDataAdapter(cmddd11);
            DataSet dsdd11 = new DataSet();
            dadd11.Fill(dsdd11);
            con1.Close();
            if (dsdd11.Tables[0] != null && dsdd11.Tables[0].Rows.Count > 0)
            {
              string strLeadID = dsdd11.Tables[0].Rows[0][0] != DBNull.Value ? dsdd11.Tables[0].Rows[0][0].ToString() : "0";
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdupdate = new SqlCommand("RTS_SP_UpdateSAApprooval", con);
            cmdupdate.CommandType = CommandType.StoredProcedure;
            cmdupdate.Parameters.AddWithValue("@SL_LD_ID", strLeadID);
            cmdupdate.Parameters.AddWithValue("@SL_RAMT", txtAMCRAMT.Text != "" ? txtAMCRAMT.Text : "0.0");
            cmdupdate.Parameters.AddWithValue("@SL_ACI_RMKS", txtAMCApprv.Text);
            cmdupdate.Parameters.AddWithValue("@SL_ACI_DECSN", lblAmci.Text);
            cmdupdate.Parameters.AddWithValue("@ID", Session["ID"].ToString());
            cmdupdate.Parameters.AddWithValue("@APPTYPE", "AMCIAPPEAL");

            int n = cmdupdate.ExecuteNonQuery();
            con.Close();
            if (n > 0)
            {

                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('SCI Appeal for " + txtLeadNo.Text + "   Saved Successfully');  window.location.assign('AMCAppeal.aspx')", true);
                //  Response.Redirect("CAM_LAP.aspx");
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('SCI Appeal for " + txtLeadNo.Text + "   Failed to Save');", true);
            }
          }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('SCI Appeal for " + txtLeadNo.Text + "   Failed to Save');", true);
        }
    }

    protected void ddlAMCDescn_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (lblAmci.Text == "Rejected")
        {

            txtAMCRAMT.Visible = false;
            lblFinalRecmnd1.Visible = false;
            txtAMCRAMT.Text = "";
        }
        else
        {

            txtAMCRAMT.Visible = true;
            lblFinalRecmnd1.Visible = true;

        }
    }
    protected void btnGenrate_Click(object sender, EventArgs e)
    {
        if (txtLeadNo.Text != "")
        {
            GenerateReport();
        }
    }
}