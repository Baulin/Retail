﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Configuration;
using Tracker;
public partial class IBSMESL_Summary : System.Web.UI.Page
{
    string ldid = "";
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);

        scriptManager.RegisterPostBackControl(this.btnSubmit);
        scriptManager.RegisterPostBackControl(this.btnPrint);

        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                ViewState["SampLDNO"] = null;
                BindCamType();
                //bala changes 29/11/2016 BindLeadNo();
            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    public void BindCamType()
    {
        string strUserType = Session["TYPEID"] != null ? Session["TYPEID"].ToString() : "";

        if (strUserType != "")
        {
            if (strUserType == "2")
            {
                ddlCamType.Items.Add("CAM Summary");
                // ddlCamType.Items.Add("CAM Sampling");
            }
            else
            {
                ddlCamType.Items.Add("CAM Summary");
                ddlCamType.Items.Add("CAM Sampling");
                ddlCamType.Items.Add("CAM Credit");
            }
        }
    }
    public void BindKYC()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_KYC_DETAILS_FETCH", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add("@KYC_LD_ID", SqlDbType.VarChar).Value = txtbxleadno.Text.Substring(txtbxleadno.Text.Length - 5);
            cmd.Parameters.AddWithValue("@KYC_LD_ID", ldid);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);

            grdKYC.DataSource = ds1.Tables[0];
            grdKYC.DataBind();
            if (ds1.Tables[0].Rows.Count > 0)
            {
                grdKYC.HeaderRow.Font.Bold = true;
                grdKYC.HeaderRow.Cells[0].Text = "NAME";
                grdKYC.HeaderRow.Cells[1].Text = "APP TYPE";
                grdKYC.HeaderRow.Cells[2].Text = "ID PROOF";
                grdKYC.HeaderRow.Cells[3].Text = "ID PROOF NO";
                grdKYC.HeaderRow.Cells[4].Text = "NAME IN ID PROOF";
                grdKYC.HeaderRow.Cells[5].Text = "ADDR. MATCH";
                grdKYC.HeaderRow.Cells[6].Text = "INCOME PROOF";
                grdKYC.HeaderRow.Cells[7].Text = "DOB";
                grdKYC.HeaderRow.Cells[8].Text = "DOB PROOF";

                grdKYC.HeaderRow.Cells[0].Wrap = false;
                grdKYC.HeaderRow.Cells[1].Wrap = false;
                grdKYC.HeaderRow.Cells[2].Wrap = false;
                grdKYC.HeaderRow.Cells[3].Wrap = false;
                grdKYC.HeaderRow.Cells[4].Wrap = false;
                grdKYC.HeaderRow.Cells[5].Wrap = false;
                grdKYC.HeaderRow.Cells[6].Wrap = false;
                grdKYC.HeaderRow.Cells[7].Wrap = false;
                grdKYC.HeaderRow.Cells[8].Wrap = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Branch_KYC.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    public void BindLeadNo()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_Lead_For_Report", con);
        //cmddd.Parameters.AddWithValue("@LD_NO", "");
        cmddd.Parameters.AddWithValue("@LD_NO", txtbxleadno.Text != "" ? txtbxleadno.Text.Trim() : "");
        cmddd.Parameters.AddWithValue("@Lead_Type", "IBSS");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ViewState["SampLDNO"] = dsdd.Tables[0];
        ddlLeadNo.DataSource = dsdd;

        ddlLeadNo.DataTextField = "LD_NO";
        ddlLeadNo.DataValueField = "LD_ID";
        ddlLeadNo.DataBind();
        ddlLeadNo.Items.Insert(0, "Select");
    }
    public void BindSampleLeadNo()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAMSAMPLING_Lead_For_Report", con);
        cmddd.Parameters.AddWithValue("@LD_NO", "");
        cmddd.Parameters.AddWithValue("@Lead_Type", "G-LAP");
        //   cmddd.Parameters.AddWithValue("@BranchName", Session["UNITNAME"].ToString());
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLeadNo.DataSource = dsdd;
        ddlLeadNo.DataTextField = "LD_NO";
        ddlLeadNo.DataValueField = "LD_ID";
        ddlLeadNo.DataBind();
        ddlLeadNo.Items.Insert(0, "Select");
    }
    public void BindDedupe()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_DE_DUPEMECHANISM", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@KYC_LD_ID", SqlDbType.VarChar).Value = txtbxleadno.Text.Substring(txtbxleadno.Text.Length - 5);

            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);

            gv_Dedupe.DataSource = ds1.Tables[0];
            gv_Dedupe.DataBind();
            /*  if (ds1.Tables[0].Rows.Count > 0)
              {
                  gv_Dedupe.HeaderRow.Font.Bold = true;


                  gv_Dedupe.HeaderRow.Cells[0].Wrap = false;
                  gv_Dedupe.HeaderRow.Cells[1].Wrap = false;
                  gv_Dedupe.HeaderRow.Cells[2].Wrap = false;
                  gv_Dedupe.HeaderRow.Cells[3].Wrap = false;
                  gv_Dedupe.HeaderRow.Cells[4].Wrap = false;



              }*/
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Branch_KYC.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtbxleadno.Text != "")
            {
                BindLeadNo();
                /*bala changes 29/11/2016 BindKYC();
                 BindDedupe();*/
                System.Data.DataTable dt = new System.Data.DataTable();

                DataTable vst = (DataTable)ViewState["SampLDNO"];

                var res = from rw in vst.AsEnumerable()
                          where rw.Field<string>("LD_NO").Equals(txtbxleadno.Text)
                          select rw;

                if (res.Count() > 0)
                {
                    dt = res.CopyToDataTable();
                    ldid = dt.Rows[0]["LD_ID"] != DBNull.Value ? dt.Rows[0]["LD_ID"].ToString() : "";
                    tblHead.Visible = true;
                    tblReport.Visible = true;
                    tblFIleCredit.Visible = true;
                    grdKYC.Visible = true;
                    BindKYC();
                    BindDedupe();
                    GenerateReport();

                }
                else
                {
                    tblHead.Visible = false;
                    tblReport.Visible = false;
                    tblFIleCredit.Visible = false;
                    grdKYC.Visible = false;
                    gv_Dedupe.Visible = false;
                    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Please enter lead number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void GenerateReport()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAMSummary_Report", con);
            cmddd.Parameters.AddWithValue("@Lead_ID", ldid);
            cmddd.Parameters.AddWithValue("@Lead_Type", "SME");
            if (ddlCamType.SelectedItem.Text == "CAM Summary")
            {
                cmddd.Parameters.AddWithValue("@CamType", "B");
            }
            else if (ddlCamType.SelectedItem.Text == "CAM Sampling")
            {
                cmddd.Parameters.AddWithValue("@CamType", "S");
            }
            else if (ddlCamType.SelectedItem.Text == "CAM Credit")
            {
                cmddd.Parameters.AddWithValue("@CamType", "C");
            }

            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);



            if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
            {
                // Search creteria
                lblHeadBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                lblHeadLeadNo.Text = dsdd.Tables[0].Rows[0]["LD_NO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_NO"].ToString() : "";
                lblHeadPDDate.Text = dsdd.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
                lblHeadCAMDate.Text = dsdd.Tables[0].Rows[0]["CAM_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["CAM_DATE"]).ToString("dd/MMM/yyyy") : "";
                lblHeadRlnWithEQ.Text = dsdd.Tables[0].Rows[0]["ER_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ER_DESC"].ToString() : "";
                lblHeadMainApplicant.Text = dsdd.Tables[0].Rows[0]["INS_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["INS_DESC"].ToString() : "";
                lblHeadVintage.Text = dsdd.Tables[0].Rows[0]["VN_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["VN_DESC"].ToString() : "";
                lblHeadNatureOfjob.Text = dsdd.Tables[0].Rows[0]["NT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["NT_DESC"].ToString() : "";
                lblHeadIncomeType.Text = dsdd.Tables[0].Rows[0]["IT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["IT_DESC"].ToString() : "";
                lblHeadCreditHistory.Text = dsdd.Tables[0].Rows[0]["CH_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_DESC"].ToString() : "";
                // lblHeadLoanPurpose.Text = dsdd.Tables[0].Rows[0]["PP_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PP_DESC"].ToString() : "";
                lblHeadApplicant.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                lblHeadAddress.Text = dsdd.Tables[0].Rows[0]["CAM_AP_ADD"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AP_ADD"].ToString() : "";
                lblHeadContact.Text = dsdd.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
                lblMemberID.Text = dsdd.Tables[0].Rows[0]["LD_MID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_MID"].ToString() : "";


                lblHeadLoanTenure.Text = dsdd.Tables[0].Rows[0]["CAM_TENURE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TENURE"].ToString() : "";
                lblHeadIntrest.Text = dsdd.Tables[0].Rows[0]["CAM_INR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_INR"].ToString() : "";
                lblHeadEMI.Text = dsdd.Tables[0].Rows[0]["CAM_EPL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EPL"].ToString() : "";
                //lblHeadEMI.Text = dsdd.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_IIR"].ToString() : "";
                //lblHeadEMI.Text = dsdd.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "";
                lblHeadLoanAmnt.Text = dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"].ToString() : "";
                lblHeadLoanEligible.Text = dsdd.Tables[0].Rows[0]["CAM_LN_ELG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LN_ELG"].ToString() : "";

                lblHeadTotalEligiblity.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";

                lblHeadPropType.Text = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "";
                lblHeadOccupancy.Text = dsdd.Tables[0].Rows[0]["OC_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["OC_DESC"].ToString() : "";
                lblHeadUsage.Text = dsdd.Tables[0].Rows[0]["UG_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["UG_DESC"].ToString() : "";
                lblHeadNoOfTeneds.Text = dsdd.Tables[0].Rows[0]["CAM_NOT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOT"].ToString() : "";
                lblHeadLandArea.Text = dsdd.Tables[0].Rows[0]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAREA"].ToString() : "";
                lblHeadGuideline.Text = dsdd.Tables[0].Rows[0]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_GLV"].ToString() : "";
                lblHeadmarketValue.Text = dsdd.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
                lblHeadConsiderValue.Text = dsdd.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CLV"].ToString() : "";
                lblHeadBuildUpArea.Text = dsdd.Tables[0].Rows[0]["CAM_BAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BAREA"].ToString() : "";
                lblHeadBuildingValue.Text = dsdd.Tables[0].Rows[0]["CAM_BV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BV"].ToString() : "";
                lblHeadAgeOfBuilding.Text = dsdd.Tables[0].Rows[0]["CAM_AMENITIES"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AMENITIES"].ToString() : "";
                //lblHeadDepreciation.Text = dsdd.Tables[0].Rows[0]["CAM_DEP"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_DEP"].ToString() : "";
                lblHeadCOndrBuildValue.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
                lblHeadTotPropValue.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
                lblHeadLTV.Text = dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
                lblHeadLoanRecommend.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
                lblHeadNameofInsuredPerson.Text = dsdd.Tables[0].Rows[0]["CAM_PCS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_PCS"].ToString() : "";

                lblHeadAgriLandArea.Text = dsdd.Tables[0].Rows[0]["CAM_AGL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGL"].ToString() : "";
                lblAgriIncome.Text = dsdd.Tables[0].Rows[0]["CAM_AGI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGI"].ToString() : "";

                lblFBI.Text = dsdd.Tables[0].Rows[0]["CAM_FBI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FBI"].ToString() : "";
                lblFacOthrIncome.Text = dsdd.Tables[0].Rows[0]["CAM_FOI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FOI"].ToString() : "";
                lblPersnlObligation.Text = dsdd.Tables[0].Rows[0]["CAM_FOI_PO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FOI_PO"].ToString() : "";
                lblNetObligation.Text = dsdd.Tables[0].Rows[0]["CAM_NOBLIG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOBLIG"].ToString() : "";

                lblTotPrimaryCOlatral.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_PCOL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_PCOL"].ToString() : "";
                lblPrmPropose.Text = dsdd.Tables[0].Rows[0]["CAM_PROP_PCOL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_PROP_PCOL"].ToString() : "";
                lblLPrimaryCOlt.Text = dsdd.Tables[0].Rows[0]["CAM_LN_COL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LN_COL"].ToString() : "";

                if (dsdd.Tables[1] != null && dsdd.Tables[1].Rows.Count > 0)
                {
                    gvIncomeDetail.DataSource = dsdd.Tables[1];
                    gvIncomeDetail.DataBind();

                }


                if (dsdd.Tables[2] != null && dsdd.Tables[2].Rows.Count > 0)
                {
                    for (int i = 0; i < dsdd.Tables[2].Rows.Count; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                lblHeadFInacier1.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                lblBorrower1.Text = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                lblEMIAmount1.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                lblLoanType1.Text = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                if (lblLoanType1.Text == "1")
                                {
                                    lblLoanType1.Text = "HOAM LOAN";
                                }
                                else if (lblLoanType1.Text == "2")
                                {
                                    lblLoanType1.Text = "PL";
                                }
                                else if (lblLoanType1.Text == "3")
                                {
                                    lblLoanType1.Text = "AUTO LOAN";
                                }
                                else if (lblLoanType1.Text == "4")
                                {
                                    lblLoanType1.Text = "TW LOAN";
                                }
                                else if (lblLoanType1.Text == "5")
                                {
                                    lblLoanType1.Text = "AGRI LOAN";
                                }
                                else if (lblLoanType1.Text == "6")
                                {
                                    lblLoanType1.Text = "GOLD LOAN";
                                }
                                else if (lblLoanType1.Text == "7")
                                {
                                    lblLoanType1.Text = "EDU LOAN";
                                }
                                else if (lblLoanType1.Text == "8")
                                {
                                    lblLoanType1.Text = "OD";
                                }
                                break;
                            case 1:
                                lblHeadFInacier2.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                lblBorrower2.Text = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                lblEMIAmount2.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                lblLoanType2.Text = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";

                                if (lblLoanType2.Text == "1")
                                {
                                    lblLoanType2.Text = "HOAM LOAN";
                                }
                                else if (lblLoanType2.Text == "2")
                                {
                                    lblLoanType2.Text = "PL";
                                }
                                else if (lblLoanType2.Text == "3")
                                {
                                    lblLoanType2.Text = "AUTO LOAN";
                                }
                                else if (lblLoanType2.Text == "4")
                                {
                                    lblLoanType2.Text = "TW LOAN";
                                }
                                else if (lblLoanType2.Text == "5")
                                {
                                    lblLoanType2.Text = "AGRI LOAN";
                                }
                                else if (lblLoanType2.Text == "6")
                                {
                                    lblLoanType2.Text = "GOLD LOAN";
                                }
                                else if (lblLoanType2.Text == "7")
                                {
                                    lblLoanType2.Text = "EDU LOAN";
                                }
                                else if (lblLoanType2.Text == "8")
                                {
                                    lblLoanType2.Text = "OD";
                                }
                                break;
                            case 2:
                                lblHeadFInacier3.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                lblBorrower3.Text = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                lblEMIAmount3.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                lblLoanType3.Text = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";

                                if (lblLoanType3.Text == "1")
                                {
                                    lblLoanType3.Text = "HOAM LOAN";
                                }
                                else if (lblLoanType3.Text == "2")
                                {
                                    lblLoanType3.Text = "PL";
                                }
                                else if (lblLoanType3.Text == "3")
                                {
                                    lblLoanType3.Text = "AUTO LOAN";
                                }
                                else if (lblLoanType3.Text == "4")
                                {
                                    lblLoanType3.Text = "TW LOAN";
                                }
                                else if (lblLoanType3.Text == "5")
                                {
                                    lblLoanType3.Text = "AGRI LOAN";
                                }
                                else if (lblLoanType3.Text == "6")
                                {
                                    lblLoanType3.Text = "GOLD LOAN";
                                }
                                else if (lblLoanType3.Text == "7")
                                {
                                    lblLoanType3.Text = "EDU LOAN";
                                }
                                else if (lblLoanType3.Text == "8")
                                {
                                    lblLoanType3.Text = "OD";
                                }
                                break;
                            case 3:
                                lblHeadFInacier4.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                lblBorrower4.Text = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                lblEMIAmount4.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                lblLoanType4.Text = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                if (lblLoanType4.Text == "1")
                                {
                                    lblLoanType4.Text = "HOAM LOAN";
                                }
                                else if (lblLoanType4.Text == "2")
                                {
                                    lblLoanType4.Text = "PL";
                                }
                                else if (lblLoanType4.Text == "3")
                                {
                                    lblLoanType4.Text = "AUTO LOAN";
                                }
                                else if (lblLoanType4.Text == "4")
                                {
                                    lblLoanType4.Text = "TW LOAN";
                                }
                                else if (lblLoanType4.Text == "5")
                                {
                                    lblLoanType4.Text = "AGRI LOAN";
                                }
                                else if (lblLoanType4.Text == "6")
                                {
                                    lblLoanType4.Text = "GOLD LOAN";
                                }
                                else if (lblLoanType4.Text == "7")
                                {
                                    lblLoanType4.Text = "EDU LOAN";
                                }
                                else if (lblLoanType4.Text == "8")
                                {
                                    lblLoanType4.Text = "OD";
                                }
                                break;
                            case 4:
                                lblHeadFInacier5.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                lblBorrower5.Text = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                lblEMIAmount5.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                lblLoanType5.Text = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                if (lblLoanType5.Text == "1")
                                {
                                    lblLoanType5.Text = "HOAM LOAN";
                                }
                                else if (lblLoanType5.Text == "2")
                                {
                                    lblLoanType5.Text = "PL";
                                }
                                else if (lblLoanType5.Text == "3")
                                {
                                    lblLoanType5.Text = "AUTO LOAN";
                                }
                                else if (lblLoanType5.Text == "4")
                                {
                                    lblLoanType5.Text = "TW LOAN";
                                }
                                else if (lblLoanType5.Text == "5")
                                {
                                    lblLoanType5.Text = "AGRI LOAN";
                                }
                                else if (lblLoanType5.Text == "6")
                                {
                                    lblLoanType5.Text = "GOLD LOAN";
                                }
                                else if (lblLoanType5.Text == "7")
                                {
                                    lblLoanType5.Text = "EDU LOAN";
                                }
                                else if (lblLoanType5.Text == "8")
                                {
                                    lblLoanType5.Text = "OD";
                                }
                                break;
                        }
                    }
                }

                if (dsdd.Tables[3] != null && dsdd.Tables[3].Rows.Count > 0)
                {
                    for (int i = 0; i < dsdd.Tables[3].Rows.Count; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                lblCOletral1.Text = dsdd.Tables[3].Rows[i]["CC_COLAT"] != DBNull.Value ? dsdd.Tables[3].Rows[i]["CC_COLAT"].ToString() : "";
                                lblCOletralVal1.Text = dsdd.Tables[3].Rows[i]["CC_AMOUNT"] != DBNull.Value ? dsdd.Tables[3].Rows[i]["CC_AMOUNT"].ToString() : "";
                                break;
                            case 1:
                                lblCOletral2.Text = dsdd.Tables[3].Rows[i]["CC_COLAT"] != DBNull.Value ? dsdd.Tables[3].Rows[i]["CC_COLAT"].ToString() : "";
                                lblCOletralVal2.Text = dsdd.Tables[3].Rows[i]["CC_AMOUNT"] != DBNull.Value ? dsdd.Tables[3].Rows[i]["CC_AMOUNT"].ToString() : "";
                                break;
                            case 2:
                                lblCOletral3.Text = dsdd.Tables[3].Rows[i]["CC_COLAT"] != DBNull.Value ? dsdd.Tables[3].Rows[i]["CC_COLAT"].ToString() : "";
                                lblCOletralVal3.Text = dsdd.Tables[3].Rows[i]["CC_AMOUNT"] != DBNull.Value ? dsdd.Tables[3].Rows[i]["CC_AMOUNT"].ToString() : "";
                                break;
                            case 3:
                                lblCOletral4.Text = dsdd.Tables[3].Rows[i]["CC_COLAT"] != DBNull.Value ? dsdd.Tables[3].Rows[i]["CC_COLAT"].ToString() : "";
                                lblCOletralVal4.Text = dsdd.Tables[3].Rows[i]["CC_AMOUNT"] != DBNull.Value ? dsdd.Tables[3].Rows[i]["CC_AMOUNT"].ToString() : "";
                                break;
                            case 4:
                                lblCOletral5.Text = dsdd.Tables[3].Rows[i]["CC_COLAT"] != DBNull.Value ? dsdd.Tables[3].Rows[i]["CC_COLAT"].ToString() : "";
                                lblCOletralVal5.Text = dsdd.Tables[3].Rows[i]["CC_AMOUNT"] != DBNull.Value ? dsdd.Tables[3].Rows[i]["CC_AMOUNT"].ToString() : "";
                                break;
                        }
                    }
                }

                lblTotalEMI.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";

                lblAssumeOblig.Text = dsdd.Tables[0].Rows[0]["CAM_HOBLIG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_HOBLIG"].ToString() : "";
                lblHeadIIREligiblity.Text = dsdd.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_IIR"].ToString() : "";
                lblHeadFOIR.Text = dsdd.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "";

                //


                lblBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                lblCustomerName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                // lblLoanPurpose.Text = dsdd.Tables[0].Rows[0]["PP_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PP_DESC"].ToString() : "";
                lblNetIncomeafterfactoring.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";
                lblObligation.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";
                lblPropertyType.Text = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "";
                lblOccupancyStatus.Text = dsdd.Tables[0].Rows[0]["OC_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["OC_DESC"].ToString() : "";
                lblLandSQFT.Text = dsdd.Tables[0].Rows[0]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAREA"].ToString() : "";
                lblReginet.Text = dsdd.Tables[0].Rows[0]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_GLV"].ToString() : "";
                lblMarketvalue.Text = dsdd.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
                lblTotalLandvalue.Text = dsdd.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CLV"].ToString() : "";
                lblAgeofbuilding.Text = dsdd.Tables[0].Rows[0]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BA_DESC"].ToString() : "";
                lblBuildingValue.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
                lblTotalpropertyvalue.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
                lblLoanamountrecommeded.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";

                string strUserID = dsdd.Tables[0].Rows[0]["LD_PD_MBY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_PD_MBY"].ToString() : "";

                // FINAL FILE CREDIT SCORE
                SqlCommand cmddd1 = new SqlCommand("select EMP_NAME,ET_DESC from MR_EMPLOYEE ME  left join MR_USER MU on  ME.EMP_ID= MU.USR_EMP_ID left join MR_EMP_TYPE MET on  ME.EMP_ET_ID= MET.ET_ID  where MU.USR_ID='" + strUserID + "'", con);

                SqlDataAdapter dadd1 = new SqlDataAdapter(cmddd1);
                DataSet dsdd1 = new DataSet();
                dadd1.Fill(dsdd1);

                lblCustomer.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                if (dsdd1.Tables[0] != null && dsdd1.Tables[0].Rows.Count > 0)
                {
                    lblUser.Text = dsdd1.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
                    lblUserRole.Text = dsdd1.Tables[0].Rows[0]["ET_DESC"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["ET_DESC"].ToString() : "";
                }

                lblVintage.Text = dsdd.Tables[0].Rows[0]["VN_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["VN_DESC"].ToString() : "";
                lblVintageScore.Text = dsdd.Tables[0].Rows[0]["VN_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["VN_SCR"].ToString() : "";

                lblNatureJob.Text = dsdd.Tables[0].Rows[0]["NT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["NT_DESC"].ToString() : "";
                lblNatureJobScr.Text = dsdd.Tables[0].Rows[0]["NT_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["NT_SCR"].ToString() : "";

                lblIncomeType.Text = dsdd.Tables[0].Rows[0]["IT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["IT_DESC"].ToString() : "";
                lblIncomeTypeScr.Text = dsdd.Tables[0].Rows[0]["IT_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["IT_SCR"].ToString() : "";

                if (lblNetIncomeafterfactoring.Text != "")
                {
                    SqlCommand cmddd2 = new SqlCommand("select dbo.RTS_Fn_FetchIncomeType_Score(" + Convert.ToDouble(lblNetIncomeafterfactoring.Text) + ")", con);

                    SqlDataAdapter dadd2 = new SqlDataAdapter(cmddd2);
                    DataSet dsdd2 = new DataSet();
                    dadd2.Fill(dsdd2);
                    if (dsdd2.Tables[0] != null && dsdd2.Tables[0].Rows.Count > 0)
                    {
                        string[] strIncomeVal = dsdd2.Tables[0].Rows[0][0] != DBNull.Value ? dsdd2.Tables[0].Rows[0][0].ToString().Split(',') : null;
                        lblMonthlyIncome.Text = strIncomeVal[0].ToString();
                        lblMonthlyIncomeScore.Text = strIncomeVal[1].ToString();

                    }
                }
                if (lblMonthlyIncomeScore.Text != "" && lblVintageScore.Text != "" && lblNatureJobScr.Text != "" && lblIncomeTypeScr.Text != "")
                {
                    int nSecATotal = Convert.ToInt32(lblMonthlyIncomeScore.Text) + Convert.ToInt32(lblVintageScore.Text) + Convert.ToInt32(lblNatureJobScr.Text) + Convert.ToInt32(lblIncomeTypeScr.Text);
                    lblSectionAScore.Text = nSecATotal.ToString();
                }

                lblCreditHistory.Text = dsdd.Tables[0].Rows[0]["CH_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_DESC"].ToString() : "";
                lblCreditHistoryScore.Text = dsdd.Tables[0].Rows[0]["CH_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_SCR"].ToString() : "";

                lblRelationEquitas.Text = dsdd.Tables[0].Rows[0]["ER_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ER_DESC"].ToString() : "";
                lblRelationEquitasScore.Text = dsdd.Tables[0].Rows[0]["ER_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ER_SCR"].ToString() : "";






                if (lblLoanamountrecommeded.Text != "" && lblNetIncomeafterfactoring.Text != "")
                {
                    //IIR PER
                    double nEMI = dsdd.Tables[0].Rows[0]["CAM_EPL"] != DBNull.Value ? Convert.ToDouble(dsdd.Tables[0].Rows[0]["CAM_EPL"]) : 0;
                    SqlCommand cmddd3 = new SqlCommand("select dbo.RTS_Fn_FetchPerIIR(" + Convert.ToDouble(lblLoanamountrecommeded.Text) + "," + Convert.ToDouble(lblNetIncomeafterfactoring.Text) + "," + nEMI + ")", con);

                    SqlDataAdapter dadd3 = new SqlDataAdapter(cmddd3);
                    DataSet dsdd3 = new DataSet();
                    dadd3.Fill(dsdd3);
                    if (dsdd3.Tables[0] != null && dsdd3.Tables[0].Rows.Count > 0)
                    {
                        string[] strIIRPER = dsdd3.Tables[0].Rows[0][0] != DBNull.Value ? dsdd3.Tables[0].Rows[0][0].ToString().Split(',') : null;
                        lblIIRPer.Text = strIIRPER[0].ToString();
                        lblIIRPerScr.Text = strIIRPER[1].ToString();
                    }


                    //FOIR
                    if (lblObligation.Text != "")
                    {
                        SqlCommand cmddd4 = new SqlCommand("select dbo.RTS_Fn_FetchPerFOIR(" + Convert.ToDouble(lblLoanamountrecommeded.Text) + "," + Convert.ToDouble(lblNetIncomeafterfactoring.Text) + "," + nEMI + "," + Convert.ToDouble(lblObligation.Text) + ")", con);

                        SqlDataAdapter dadd4 = new SqlDataAdapter(cmddd4);
                        DataSet dsdd4 = new DataSet();
                        dadd4.Fill(dsdd4);
                        if (dsdd4.Tables[0] != null && dsdd4.Tables[0].Rows.Count > 0)
                        {
                            string[] strFOIRPER = dsdd4.Tables[0].Rows[0][0] != DBNull.Value ? dsdd4.Tables[0].Rows[0][0].ToString().Split(',') : null;
                            lblFOIRPER.Text = strFOIRPER[0].ToString();
                            lblFOIRPERVal.Text = strFOIRPER[1].ToString();
                        }
                    }
                }
                if (lblIIRPerScr.Text != "" && lblFOIRPERVal.Text != "" && lblCreditHistoryScore.Text != "" && lblRelationEquitasScore.Text != "")
                {
                    int nSecBTotal = Convert.ToInt32(lblIIRPerScr.Text) + Convert.ToInt32(lblFOIRPERVal.Text) + Convert.ToInt32(lblCreditHistoryScore.Text) + Convert.ToInt32(lblRelationEquitasScore.Text);
                    lblScoreBTot.Text = nSecBTotal.ToString();
                }

                //SEC - C

                lblCollateral.Text = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "";
                lblCollateralScr.Text = dsdd.Tables[0].Rows[0]["PT_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_SCR"].ToString() : "";

                //lblPurpose.Text = dsdd.Tables[0].Rows[0]["PP_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PP_DESC"].ToString() : "";
                //  lblPurposeScore.Text = dsdd.Tables[0].Rows[0]["PP_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PP_SCR"].ToString() : "";
                if (lblReginet.Text != "" && lblMarketvalue.Text != "")
                {
                    SqlCommand cmddd5 = new SqlCommand("select dbo.RTS_Fn_FetchPerPLotValue(" + Convert.ToDouble(lblReginet.Text) + "," + Convert.ToDouble(lblMarketvalue.Text) + ")", con);

                    SqlDataAdapter dadd5 = new SqlDataAdapter(cmddd5);
                    DataSet dsdd5 = new DataSet();
                    dadd5.Fill(dsdd5);
                    if (dsdd5.Tables[0] != null && dsdd5.Tables[0].Rows.Count > 0)
                    {
                        string[] strPlotPER = dsdd5.Tables[0].Rows[0][0] != DBNull.Value ? dsdd5.Tables[0].Rows[0][0].ToString().Split(',') : null;
                        lblPlot.Text = strPlotPER[0].ToString();
                        lblPlotScr.Text = strPlotPER[1].ToString();
                    }
                }

                if (lblTotalpropertyvalue.Text != "" && lblLoanamountrecommeded.Text != "")
                {
                    SqlCommand cmddd6 = new SqlCommand("select dbo.RTS_Fn_FetchPerLTV_SME(" + Convert.ToDouble(lblTotalpropertyvalue.Text) + "," + Convert.ToDouble(lblLoanamountrecommeded.Text) + ")", con);

                    SqlDataAdapter dadd6 = new SqlDataAdapter(cmddd6);
                    DataSet dsdd6 = new DataSet();
                    dadd6.Fill(dsdd6);
                    if (dsdd6.Tables[0] != null && dsdd6.Tables[0].Rows.Count > 0)
                    {
                        string[] strPlotPER = dsdd6.Tables[0].Rows[0][0] != DBNull.Value ? dsdd6.Tables[0].Rows[0][0].ToString().Split(',') : null;
                        lblLTV.Text = strPlotPER[0].ToString();
                        lblLTVVal.Text = strPlotPER[1].ToString();
                    }
                }
                if (lblCollateralScr.Text != "" && lblLTVVal.Text != "" && lblPlotScr.Text != "")
                {
                    int nSecCTotal = Convert.ToInt32(lblCollateralScr.Text) + Convert.ToInt32(lblLTVVal.Text) + Convert.ToInt32(lblPlotScr.Text);
                    lblSecCTot.Text = nSecCTotal.ToString();
                }
                // SEC - D
                // lblSecDTot.Text = lblPurposeScore.Text;


                // Final
                if (lblSectionAScore.Text != "" && lblScoreBTot.Text != "" && lblSecCTot.Text != "")
                {
                    int nTotal = 0;
                    nTotal = Convert.ToInt32(lblSectionAScore.Text) + Convert.ToInt32(lblScoreBTot.Text) + Convert.ToInt32(lblSecCTot.Text);
                    lblFinalCreditScore.Text = nTotal.ToString();

                    if (nTotal <= 60)
                    {
                        tdRisk.BgColor = "Red";
                        lblRiskCategory.Text = "HIGH RISK";
                    }
                    else if (nTotal <= 80)
                    {
                        tdRisk.BgColor = "Yellow";
                        lblRiskCategory.Text = "MEDIUM RISK";
                    }
                    else if (nTotal > 80)
                    {
                        tdRisk.BgColor = "LightGreen";
                        lblRiskCategory.Text = "LOW RISK";
                    }
                }

            }
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnPrint_Click(object sender, EventArgs e)
    {
        try
        {

            System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();

            img.ImageUrl = Server.MapPath("~/Images/JPG/MIFLogo.JPG");
            tdLogo.Controls.Add(img);

            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=AUTO_CAM_" + txtbxleadno.Text + ".pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            StringWriter sw0 = new StringWriter();
            HtmlTextWriter hw0 = new HtmlTextWriter(sw0);
            pnlHeader.RenderControl(hw0);

            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            pnlpdf.RenderControl(hw);

            StringWriter sw1 = new StringWriter();
            HtmlTextWriter hw1 = new HtmlTextWriter(sw1);
            pnlpdf1.RenderControl(hw1);


            StringWriter sw2 = new StringWriter();
            HtmlTextWriter hw2 = new HtmlTextWriter(sw2);
            pnlpdf0.RenderControl(hw2);



            //  StringReader sr = new StringReader(sw0.ToString() + "<br/>" + sw2.ToString() + " <br/><br/><br/><br/><br/><br/><br/><br/> <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/> <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>" + sw.ToString() + "<br/><br/> <br/><br/><br/> <br/><br/> <br/> <br/><br/><br/> <br/><br/><br/> <br/><br/> <br/> <br/><br/><br/> <br/><br/><br/> <br/><br/>" + sw1.ToString());
            StringReader sr = new StringReader(sw0.ToString() + "<br/>" + sw2.ToString());
            StringReader sr1 = new StringReader(sw0.ToString() + "<br/>" + sw.ToString());
            StringReader sr2 = new StringReader(sw0.ToString() + "<br/>" + sw1.ToString());
            Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.Open();
            pdfDoc.NewPage();
            pdfDoc.HtmlStyleClass = "PdfClass";
            htmlparser.Parse(sr);
            pdfDoc.NewPage();
            pdfDoc.HtmlStyleClass = "PdfClass";
            htmlparser.Parse(sr1);
            pdfDoc.NewPage();

            pdfDoc.HtmlStyleClass = "PdfClass";
            htmlparser.Parse(sr2);
            pdfDoc.Close();
            Response.Write(pdfDoc);
            Response.End();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }


    public override void VerifyRenderingInServerForm(Control control)
    {

    }
    protected void ddlCamType_SelectedIndexChanged(object sender, EventArgs e)
    {
        tblHead.Visible = false;
        tblReport.Visible = false;
        tblFIleCredit.Visible = false;
        ddlLeadNo.Items.Clear();
        if (ddlCamType.SelectedItem.Text == "CAM Summary")
        {
            lblHeader.Text = "CAM - IB-SME-SL";
            //bala changes BindLeadNo();
        }
        else if (ddlCamType.SelectedItem.Text == "CAM Sampling")
        {
            lblHeader.Text = "CAM -  IB-SME-SL(SAMPLING)";
            // BindSampleLeadNo();
        }
        else if (ddlCamType.SelectedItem.Text == "CAM Credit")
        {
            lblHeader.Text = "CAM - IB-SME-SL(FINAL)";
        }
    }
}