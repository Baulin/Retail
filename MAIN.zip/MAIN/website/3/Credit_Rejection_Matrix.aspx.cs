﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Credit_Rejection_Matrix : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    
    DataSet dss = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                bind();
                BindGrid();
            }
        }

    }
    
    public void bind()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_USR_EMPLOYEE", con);
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            con.Close();

            ddlEmpDesignation.DataSource = dsdd.Tables[0];
            ddlEmpDesignation.DataTextField = "ET_DESC";
            ddlEmpDesignation.DataValueField = "ET_ID";
            ddlEmpDesignation.DataBind();
            ddlEmpDesignation.Items.Insert(0, new ListItem("--Select--", "0"));

            ddluseraccess.DataSource = dsdd.Tables[1];
            ddluseraccess.DataTextField = "UTP_DESC";
            ddluseraccess.DataValueField = "UTP_ID";
            ddluseraccess.DataBind();
            ddluseraccess.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (btnSubmit.Text == "Submit")
            InsertUpdate("INSERT");
        else
            InsertUpdate("UPDATE");
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            clear();
            btnSubmit.Text = "Submit";
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void clear()
    {      
        ddlEmpDesignation.SelectedIndex = 0;
        ddluseraccess.SelectedIndex = 0;
        ddlstatus.SelectedIndex = 0;
        ddluseraccess.Enabled = true;
        ddlEmpDesignation.Enabled = true;
    }

    protected void BindGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_CREDIT_REJ_MATRIX", con);
            cmd.CommandType = CommandType.StoredProcedure;        
            cmd.Parameters.AddWithValue("@TYPE",2);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dss);

            grvdoc.DataSource = dss.Tables[0];
            grvdoc.DataBind();


        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void rbc_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            Label lblCRMID = null;

            foreach (GridViewRow growdoc in grvdoc.Rows)
            {
                RadioButton chkStat = growdoc.FindControl("rbc_select") as RadioButton;

                int index = growdoc.RowIndex;
                if (chkStat.Checked)
                {
                    lblCRMID = (Label)grvdoc.Rows[index].Cells[1].FindControl("lblCRMID");

                    con.Open();

                    SqlCommand cmd = new SqlCommand("RTS_SP_CREDIT_REJ_MATRIX", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@CRM_ID", lblCRMID.Text);
                    cmd.Parameters.AddWithValue("@TYPE", 4);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    Session["CRM_ID"] = lblCRMID.Text;                                    

                    if (ds.Tables[0].Rows.Count > 0)
                    {                       
                        if (ddluseraccess.Items.FindByValue(Convert.ToString(ds.Tables[0].Rows[0]["CRM_UTP_ID"])) != null)
                        {
                            ddluseraccess.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["CRM_UTP_ID"]);                        
                        }
                        else
                        {
                            ddluseraccess.SelectedIndex = 0;
                        }
                        ddluseraccess.Enabled = false;
                        if (ddlEmpDesignation.Items.FindByValue(Convert.ToString(ds.Tables[0].Rows[0]["CRM_ET_ID"])) != null)
                        {
                            ddlEmpDesignation.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["CRM_ET_ID"]);
                        }
                        else
                        {
                            ddlEmpDesignation.SelectedIndex = 0;
                        }
                        ddlEmpDesignation.Enabled = false;
                        if (ddlstatus.Items.FindByValue(Convert.ToString(ds.Tables[0].Rows[0]["CRM_STAT"])) != null)
                        {                         
                           ddlstatus.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["CRM_STAT"]);                           
                            
                        }
                        else
                        {
                            ddlstatus.SelectedIndex = 0;
                        }

                    }
                    
                    btnSubmit.Text = "Update";
                    break;
                }


            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }

    }

    protected void InsertUpdate(string chkval)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            if (ddluseraccess.SelectedIndex == 0)
            {
                uscMsgBox1.AddMessage("Please select useraccess", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else if (ddlEmpDesignation.SelectedIndex == 0)
            {
                uscMsgBox1.AddMessage("Please select the Employee Designation", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else if (ddlstatus.SelectedIndex == 0)
            {
                uscMsgBox1.AddMessage("Please select the Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
            {
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_CREDIT_REJ_MATRIX", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;

                cmdinsert.Parameters.AddWithValue("@CRM_USR_ACS", ddluseraccess.SelectedValue);
                cmdinsert.Parameters.AddWithValue("@CRM_DESG", ddlEmpDesignation.SelectedValue);
                cmdinsert.Parameters.AddWithValue("@CRM_STS", ddlstatus.SelectedValue);

                if (chkval == "UPDATE")
                {
                    cmdinsert.Parameters.AddWithValue("@CRM_MBY", Session["ID"]);
                    cmdinsert.Parameters.AddWithValue("@CRM_ID", Session["CRM_ID"]);
                    cmdinsert.Parameters.AddWithValue("@TYPE", 3);
                }
                else
                {
                    cmdinsert.Parameters.AddWithValue("@CRM_CBY", Session["ID"]);
                    cmdinsert.Parameters.AddWithValue("@TYPE", 1);
                }


                int r = cmdinsert.ExecuteNonQuery();
                BindGrid();
                if (r > 0)
                {
                    if (chkval == "UPDATE")
                    {
                        btnSubmit.Text = "Submit";
                    }
                    clear();
                    uscMsgBox1.AddMessage("Records Saved Sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    return;
                }
                else
                {
                    uscMsgBox1.AddMessage("Records not Saved OR Already Exists.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
            }

            

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
}