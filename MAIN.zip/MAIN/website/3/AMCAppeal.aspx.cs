﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using System.Text.RegularExpressions;
using Tracker;

public partial class AMCAppeal : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    Regex Rx = new Regex("^[0-9]+$");
    ClsCommon clscommon = new ClsCommon();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
            BindLeadNo();
            if (Session["EMPTYPEID"] != null)
            {
                if (Session["EMPTYPEID"].ToString() == "18")
                {
                    ddlArea.Enabled = false;
                }
                else
                {
                    ddlArea.Enabled = true;
                }
            }
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_State", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        if (Session["TYPEID"].ToString() == "1")
        {
            cmddd.Parameters.AddWithValue("@StateID", 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@StateID", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }       
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, "--Select--");
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();
        //  SqlConnection con = new SqlConnection(strcon);
        con.Open();

        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, "--Select--");
        ddlBranch.Enabled = true;
    }
    public void BindLeadNo()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_Lead_For_AMC_Apprv_Report1", con);
        cmddd.Parameters.AddWithValue("@LD_NO", "");
        cmddd.Parameters.AddWithValue("@Lead_Type", "");
        cmddd.Parameters.AddWithValue("@Area", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue : "");
        cmddd.Parameters.AddWithValue("@Branch", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue : "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLeadNo.DataSource = dsdd;
        ddlLeadNo.DataTextField = "LD_NO";
        ddlLeadNo.DataValueField = "LD_ID";
        ddlLeadNo.DataBind();
        ddlLeadNo.Items.Insert(0, "Select");
    }
    protected void ddlLeadNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlLeadNo.SelectedIndex > 0)
        {
            if (!ddlLeadNo.SelectedItem.Text.Contains("TWL"))
            {
                trOther.Visible = true;
                trTWL.Visible = false;

                GenerateReport();
            }
            else
            {
                trOther.Visible = false;
                trTWL.Visible = true;
                trRpa1.Visible = false;
                trRpaHeader.Visible = false;
                GenerateReport_TWL();
            }
        }
    }
    public void GenerateReport_TWL()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAMSummary_Report", con);
        cmddd.Parameters.AddWithValue("@Lead_ID", ddlLeadNo.SelectedValue.ToString());
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);


        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            lblBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
            lblCustomerName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";

            lblBMResidenceOwnership.Text = dsdd.Tables[0].Rows[0]["RO_SCORE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["RO_SCORE"].ToString() : "";
            lblOCIResidenceOwnership.Text = dsdd.Tables[0].Rows[1]["RO_SCORE"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["RO_SCORE"].ToString() : "";
            if (lblBMResidenceOwnership.Text != "" && lblOCIResidenceOwnership.Text != "")
            {
                lblVarianceResidenceOwnership.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblOCIResidenceOwnership.Text) * 100) / Convert.ToDouble(lblBMResidenceOwnership.Text)));
            }
            /*lblNetIncomeafterfactoring.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";
            lblNetIncomeafterfactoring_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TOT_IN"].ToString() : "";
            if (lblNetIncomeafterfactoring.Text != "" && lblNetIncomeafterfactoring_CI.Text != "")
            {
                lblNetIncomeafterfactoring_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblNetIncomeafterfactoring_CI.Text) * 100) / Convert.ToDouble(lblNetIncomeafterfactoring.Text)));
            }
            */
            lblBMIncomeType.Text = dsdd.Tables[0].Rows[0]["IT_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["IT_SCR"].ToString() : "";
            lblOCIIncomeType.Text = dsdd.Tables[0].Rows[1]["IT_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["IT_SCR"].ToString() : "";
            if (lblBMIncomeType.Text != "" && lblOCIIncomeType.Text != "")
            {
                lblVarianceIncomeType.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblOCIIncomeType.Text) * 100) / Convert.ToDouble(lblBMIncomeType.Text)));
            }

            lblBMCreditHistory.Text = dsdd.Tables[0].Rows[0]["CH_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_SCR"].ToString() : "";
            lblOCICreditHistory.Text = dsdd.Tables[0].Rows[1]["CH_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CH_SCR"].ToString() : "";
            if (lblBMCreditHistory.Text != "" && lblOCICreditHistory.Text != "")
            {
                lblVarianceCreditHistory.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblOCICreditHistory.Text) * 100) / Convert.ToDouble(lblBMCreditHistory.Text)));
            }


            lblBMGrandTotal.Text = (Convert.ToInt32(lblBMResidenceOwnership.Text) + Convert.ToInt32(lblBMIncomeType.Text) + Convert.ToInt32(lblBMCreditHistory.Text)).ToString();

            lblOCIGrandTotal.Text = (Convert.ToInt32(lblOCIResidenceOwnership.Text) + Convert.ToInt32(lblOCIIncomeType.Text) + Convert.ToInt32(lblOCICreditHistory.Text)).ToString();

            lblVarianceGrandTotal.Text = (Convert.ToInt32(lblVarianceResidenceOwnership.Text) + Convert.ToInt32(lblVarianceIncomeType.Text) + Convert.ToInt32(lblVarianceCreditHistory.Text)).ToString();


            

            lblObligation.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";
            lblObligation_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TOT_EMI"].ToString() : "";

            if (lblObligation.Text != "" && lblObligation_CI.Text != "")
            {
                lblObligation_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblObligation_CI.Text) * 100) / Convert.ToDouble(lblObligation.Text)));
            }

            lblLandSQFT.Text = dsdd.Tables[0].Rows[0]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAREA"].ToString() : "";
            lblLandSQFT_CI.Text = dsdd.Tables[0].Rows[1]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_LAREA"].ToString() : "";
            if (lblLandSQFT.Text != "" && lblLandSQFT_CI.Text != "")
            {
                lblLandSQFT_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblLandSQFT_CI.Text) * 100) / Convert.ToDouble(lblLandSQFT.Text)));
            }

            lblReginet.Text = dsdd.Tables[0].Rows[0]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_GLV"].ToString() : "";
            lblReginet_CI.Text = dsdd.Tables[0].Rows[1]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_GLV"].ToString() : "";

            if (lblReginet.Text != "" && lblReginet_CI.Text != "")
            {
                lblReginet_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblReginet_CI.Text) * 100) / Convert.ToDouble(lblReginet.Text)));
            }


            lblMarketvalue.Text = dsdd.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
            lblMarketvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_MV"].ToString() : "";
            if (lblMarketvalue.Text != "" && lblMarketvalue_CI.Text != "")
            {
                lblMarketvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblMarketvalue_CI.Text) * 100) / Convert.ToDouble(lblMarketvalue.Text)));
            }

            lblTotalLandvalue.Text = dsdd.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CLV"].ToString() : "";
            lblTotalLandvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_CLV"].ToString() : "";
            if (lblTotalLandvalue.Text != "" && lblTotalLandvalue_CI.Text != "")
            {
                lblTotalLandvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblTotalLandvalue_CI.Text) * 100) / Convert.ToDouble(lblTotalLandvalue.Text)));
            }

            lblBuildingType.Text = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "";
            lblBuildingType_CI.Text = dsdd.Tables[0].Rows[1]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["PT_DESC"].ToString() : "";


            lblAgeofbuilding.Text = dsdd.Tables[0].Rows[0]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BA_DESC"].ToString() : "";
            lblAgeofbuilding_CI.Text = dsdd.Tables[0].Rows[1]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["BA_DESC"].ToString() : "";

            //if (lblAgeofbuilding.Text != "" && lblAgeofbuilding_CI.Text != "")
            //{
            //    lblAgeofbuilding_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblAgeofbuilding_CI.Text) * 100) / Convert.ToDouble(lblAgeofbuilding.Text)));
            //}

            if (Rx.IsMatch(lblAgeofbuilding.Text) && Rx.IsMatch(lblAgeofbuilding_CI.Text))
            {
                if (lblAgeofbuilding.Text != "" && lblAgeofbuilding_CI.Text != "")
                {
                    lblAgeofbuilding_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblAgeofbuilding_CI.Text) * 100) / Convert.ToDouble(lblAgeofbuilding.Text)));
                }
            }
            else
            {
            }

            lblBuildingValue.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
            lblBuildingValue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_CBV"].ToString() : "";
            if (lblBuildingValue.Text != "" && lblBuildingValue_CI.Text != "")
            {
                lblBuildingValue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblBuildingValue_CI.Text) * 100) / Convert.ToDouble(lblBuildingValue.Text)));
            }

            lblTotalpropertyvalue.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
            lblTotalpropertyvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TPV"].ToString() : "";
            if (lblTotalpropertyvalue.Text != "" && lblTotalpropertyvalue_CI.Text != "")
            {
                lblTotalpropertyvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblTotalpropertyvalue_CI.Text) * 100) / Convert.ToDouble(lblTotalpropertyvalue.Text)));
            }

            lblLoanamountrecommeded.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
            lblLoanamountrecommeded_CR.Text = dsdd.Tables[0].Rows[1]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_RLA"].ToString() : "";
            if (lblLoanamountrecommeded.Text != "" && lblLoanamountrecommeded_CR.Text != "")
            {
                lblLoanamountrecommeded_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblLoanamountrecommeded_CR.Text) * 100) / Convert.ToDouble(lblLoanamountrecommeded.Text)));
            }


            SqlCommand cmddd1 = new SqlCommand("Fetch_SAM_Approval_Appeal_Details", con);
            cmddd1.Parameters.AddWithValue("@SD_LD_ID", ddlLeadNo.SelectedValue.ToString());
            cmddd1.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd1 = new SqlDataAdapter(cmddd1);
            DataSet dsdd1 = new DataSet();
            dadd1.Fill(dsdd1);
            if (dsdd1.Tables[0] != null && dsdd1.Tables[0].Rows.Count > 0)
            {
                lblResidenceOwnershipRemarks.Text = dsdd1.Tables[0].Rows[0]["SL_RO"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RO"].ToString() : "";
                lblIncomeTypeRemarks.Text = dsdd1.Tables[0].Rows[0]["SL_EBP"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_EBP"].ToString() : "";
                lblCreditHistoryRemarks.Text = dsdd1.Tables[0].Rows[0]["SL_CH"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_CH"].ToString() : "";
                txtNetIncomeafterfactoringRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_NETIN"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_NETIN"].ToString() : "";
                txtObligationRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_OBLIG"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_OBLIG"].ToString() : "";
                txtLandSQFTRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_SQFT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SQFT"].ToString() : "";
                txtReginetRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_GV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_GV"].ToString() : "";
                txtMarketvalueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_MV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_MV"].ToString() : "";
                txtTotalLandvalueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_LV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_LV"].ToString() : "";
                txtBuildingTypeRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_BTYPE"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_BTYPE"].ToString() : "";
                txtAgeofbuildingRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_BAGE"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_BAGE"].ToString() : "";
                txtBuildingValueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_BV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_BV"].ToString() : "";
                txtTotalpropertyvalueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_PV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_PV"].ToString() : "";
                txtLoanamountrecommeded.Text = dsdd1.Tables[0].Rows[0]["SL_LAMT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_LAMT"].ToString() : "";


                txtGvalue.Text = dsdd1.Tables[0].Rows[0]["SL_RGV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RGV"].ToString() : "";
                txtMarkVal.Text = dsdd1.Tables[0].Rows[0]["SL_RMV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RMV"].ToString() : "";
                txtLandArea.Text = dsdd1.Tables[0].Rows[0]["SL_RSQFT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RSQFT"].ToString() : "";
                txtBMLandValue.Text = dsdd1.Tables[0].Rows[0]["SL_RLV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RLV"].ToString() : "";

                ddlTolerance.SelectedValue = dsdd1.Tables[0].Rows[0]["SL_TOL"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_TOL"].ToString() : "";
                ddlApproove.SelectedValue = dsdd1.Tables[0].Rows[0]["SL_DECSN"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_DECSN"].ToString() : "";
                if (ddlApproove.SelectedValue != "Rejected")
                {
                    lblRcmnd.Visible = true;
                    txtFinalRcmnd.Visible = true;
                    txtFinalRcmnd.Text = dsdd1.Tables[0].Rows[0]["SL_RAMT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RAMT"].ToString() : "";
                }
                string strRType = dsdd1.Tables[0].Rows[0]["SL_RTYPE"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RTYPE"].ToString() : "";
                if (strRType == "SPOT")
                {

                    trResult.Visible = true;
                    rdnSpot.Checked = true;
                    trSPot.Visible = true;
                    trPDDComplete1.Visible = false;
                }
                else if (strRType == "PDD")
                {
                    trResult.Visible = true;
                    rdnPDD.Checked = true;
                    trPDDComplete1.Visible = true;
                    trSPot.Visible = false;
                    trBussEmpRelt.Visible = false;
                    trIncomeTol.Visible = false;
                    trPropRel.Visible = false;
                    trVerRel.Visible = false;
                }

                string strMRISK = dsdd1.Tables[0].Rows[0]["SL_MRISK"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_MRISK"].ToString() : "";
                if (strMRISK.Contains("Business/Employee Related"))
                {
                    rdnBussEmpRelated.Checked = true;
                    trBussEmpRelt.Visible = true;
                    trIncomeTol.Visible = false;
                    trPropRel.Visible = false;
                    trVerRel.Visible = false;

                }
                if (strMRISK.Contains("Income Related"))
                {
                    rdnIncomeRelated.Checked = true;
                    trBussEmpRelt.Visible = false;
                    trIncomeTol.Visible = true;
                    trPropRel.Visible = false;
                    trVerRel.Visible = false;
                }
                if (strMRISK.Contains("Property Related"))
                {
                    rdnPropRelated.Checked = true;
                    trBussEmpRelt.Visible = false;
                    trIncomeTol.Visible = false;
                    trPropRel.Visible = true;
                    trVerRel.Visible = false;
                }
                if (strMRISK.Contains("Verification Related"))
                {
                    rdnVerRelated.Checked = true;
                    rdnVerRel.Checked = true;
                    trBussEmpRelt.Visible = false;
                    trIncomeTol.Visible = false;
                    trPropRel.Visible = false;
                    trVerRel.Visible = true;
                }
                if (strMRISK.Contains("PDD Income Related"))
                {
                    trPDDComplete2.Visible = true;
                }
                if (strMRISK.Contains("PDD Verification Related"))
                {
                    trPDDComplete3.Visible = true;
                }

                string strSRISK = dsdd1.Tables[0].Rows[0]["SL_SRISK"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SRISK"].ToString() : "";
                if (strSRISK.Contains("Business/Employment Related"))
                {
                    rdnBussEmpRel.Checked = true;
                }
                if (strSRISK == "Incorrect Business/Employment Related information")
                {
                    rdnBussEmpRe2.Checked = true;
                }
                if (strSRISK.Contains("Income Tolerance Level"))
                {
                    rdbIncomeTolerance.Checked = true;
                }
                if (strSRISK.Contains("Building Age"))
                {
                    rdnBuildAge.Checked = true;
                }
                if (strSRISK.Contains("Building Area"))
                {
                    rdnBuildArea.Checked = true;
                }
                if (strSRISK.Contains("Incorrect Property Information"))
                {
                    rdnIncorrectBuildDet.Checked = true;
                }
                if (strSRISK.Contains("Verification Related"))
                {
                    rdnVerRel.Checked = true;
                }
                if (strSRISK.Contains("PDD Income Assessment"))
                {
                    chkPDDIncomeRelated.Checked = true;
                }
                if (strSRISK.Contains("PDD Verification Related"))
                {
                    chkPDDVerficationRel.Checked = true;
                }

                txtRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_RMKS"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RMKS"].ToString() : "";
                txtbmrmk.Text = dsdd1.Tables[0].Rows[0]["SL_AAPLRMKS"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_AAPLRMKS"].ToString() : "";
                txtBMRemarksForSCI.Text = dsdd1.Tables[0].Rows[0]["SL_SAPLRMKS"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SAPLRMKS"].ToString() : "";

                ddlSCIAppeal.SelectedValue = dsdd1.Tables[0].Rows[0]["SL_SCI_DESCN"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SCI_DESCN"].ToString() : "";
                if (ddlSCIAppeal.SelectedValue != "Rejected")
                {
                    lblRcmnd.Visible = true;
                    txtFinalRcmnd0.Visible = true;
                    txtFinalRcmnd0.Text = dsdd1.Tables[0].Rows[0]["SL_RAMT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RAMT"].ToString() : "";
                }
                txtRmrk0.Text = dsdd1.Tables[0].Rows[0]["SL_SCI_RMKS"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SCI_RMKS"].ToString() : "";
                if (dsdd.Tables[3] != null && dsdd.Tables[3].Rows.Count > 0)
                {
                    trRpa1.Visible = false;
                    trRpa2.Visible = true;

                    lblBMGvalue.Text = lblReginet.Text;
                    lblFROGvalue.Text = dsdd.Tables[3].Rows[0]["RPA_GV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_GV"].ToString() : "";
                    if (lblBMGvalue.Text != "" && lblFROGvalue.Text != "")
                    {
                        lblVarGvalue.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFROGvalue.Text) * 100) / Convert.ToDouble(lblBMGvalue.Text)));
                    }

                    lblBMMarkVal.Text = lblMarketvalue.Text;
                    lblFORMarkVal.Text = dsdd.Tables[3].Rows[0]["RPA_MV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_MV"].ToString() : "";
                    if (lblBMMarkVal.Text != "" && lblFORMarkVal.Text != "")
                    {
                        lblVarMarkVal.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFORMarkVal.Text) * 100) / Convert.ToDouble(lblBMMarkVal.Text)));
                    }

                    lblBMLandArea.Text = lblLandSQFT.Text;
                    lblFORLandArea.Text = dsdd.Tables[3].Rows[0]["RPA_LAREA"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_LAREA"].ToString() : "";
                    if (lblFORLandArea.Text != "" && lblBMLandArea.Text != "")
                    {
                        lblVarLandArea.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFORLandArea.Text) * 100) / Convert.ToDouble(lblBMLandArea.Text)));
                    }

                    lblBMLandValue.Text = lblTotalLandvalue.Text;
                    lblForLandValue.Text = dsdd.Tables[3].Rows[0]["RPA_LV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_LV"].ToString() : "";
                    if (lblBMLandValue.Text != "" && lblForLandValue.Text != "")
                    {
                        lblVarLandValue.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblForLandValue.Text) * 100) / Convert.ToDouble(lblBMLandValue.Text)));
                    }


                }
                else
                {
                    trRpa1.Visible = false;
                    trRpa2.Visible = false;
                    trRpaHeader.Visible = false;
                }
            }
        }
    }
    public void GenerateReport()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAMSummary_Report", con);
        cmddd.Parameters.AddWithValue("@Lead_ID", ddlLeadNo.SelectedValue.ToString());
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);


        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            lblBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
            lblCustomerName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";

            lblNetIncomeafterfactoring.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";
            lblNetIncomeafterfactoring_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TOT_IN"].ToString() : "";
            if (lblNetIncomeafterfactoring.Text != "" && lblNetIncomeafterfactoring_CI.Text != "")
            {
                lblNetIncomeafterfactoring_Var.Text = Convert.ToString(100- Math.Round((Convert.ToDouble(lblNetIncomeafterfactoring_CI.Text) * 100) / Convert.ToDouble(lblNetIncomeafterfactoring.Text)));
            }

            lblObligation.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";
            lblObligation_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TOT_EMI"].ToString() : "";

            if (lblObligation.Text != "" && lblObligation_CI.Text != "")
            {
                lblObligation_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblObligation_CI.Text) * 100) / Convert.ToDouble(lblObligation.Text)));
            }

            lblLandSQFT.Text = dsdd.Tables[0].Rows[0]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAREA"].ToString() : "";
            lblLandSQFT_CI.Text = dsdd.Tables[0].Rows[1]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_LAREA"].ToString() : "";
            if (lblLandSQFT.Text != "" && lblLandSQFT_CI.Text != "")
            {
                lblLandSQFT_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblLandSQFT_CI.Text) * 100) / Convert.ToDouble(lblLandSQFT.Text)));
            }

            lblReginet.Text = dsdd.Tables[0].Rows[0]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_GLV"].ToString() : "";
            lblReginet_CI.Text = dsdd.Tables[0].Rows[1]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_GLV"].ToString() : "";

            if (lblReginet.Text != "" && lblReginet_CI.Text != "")
            {
                lblReginet_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblReginet_CI.Text) * 100) / Convert.ToDouble(lblReginet.Text)));
            }


            lblMarketvalue.Text = dsdd.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
            lblMarketvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_MV"].ToString() : "";
            if (lblMarketvalue.Text != "" && lblMarketvalue_CI.Text != "")
            {
                lblMarketvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblMarketvalue_CI.Text) * 100) / Convert.ToDouble(lblMarketvalue.Text)));
            }

            lblTotalLandvalue.Text = dsdd.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CLV"].ToString() : "";
            lblTotalLandvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_CLV"].ToString() : "";
            if (lblTotalLandvalue.Text != "" && lblTotalLandvalue_CI.Text != "")
            {
                lblTotalLandvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblTotalLandvalue_CI.Text) * 100) / Convert.ToDouble(lblTotalLandvalue.Text)));
            }

            lblBuildingType.Text = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "";
            lblBuildingType_CI.Text = dsdd.Tables[0].Rows[1]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["PT_DESC"].ToString() : "";


            lblAgeofbuilding.Text = dsdd.Tables[0].Rows[0]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BA_DESC"].ToString() : "";
            lblAgeofbuilding_CI.Text = dsdd.Tables[0].Rows[1]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["BA_DESC"].ToString() : "";
            
            //if (lblAgeofbuilding.Text != "" && lblAgeofbuilding_CI.Text != "")
            //{
            //    lblAgeofbuilding_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblAgeofbuilding_CI.Text) * 100) / Convert.ToDouble(lblAgeofbuilding.Text)));
            //}

            if (Rx.IsMatch(lblAgeofbuilding.Text) && Rx.IsMatch(lblAgeofbuilding_CI.Text))
            {
                if (lblAgeofbuilding.Text != "" && lblAgeofbuilding_CI.Text != "")
                {
                    lblAgeofbuilding_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblAgeofbuilding_CI.Text) * 100) / Convert.ToDouble(lblAgeofbuilding.Text)));
                }
            }
            else
            {
            }  

            lblBuildingValue.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
            lblBuildingValue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_CBV"].ToString() : "";
            if (lblBuildingValue.Text != "" && lblBuildingValue_CI.Text != "")
            {
                lblBuildingValue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblBuildingValue_CI.Text) * 100) / Convert.ToDouble(lblBuildingValue.Text)));
            }

            lblTotalpropertyvalue.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
            lblTotalpropertyvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TPV"].ToString() : "";
            if (lblTotalpropertyvalue.Text != "" && lblTotalpropertyvalue_CI.Text != "")
            {
                lblTotalpropertyvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblTotalpropertyvalue_CI.Text) * 100) / Convert.ToDouble(lblTotalpropertyvalue.Text)));
            }

            lblLoanamountrecommeded.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
            lblLoanamountrecommeded_CR.Text = dsdd.Tables[0].Rows[1]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_RLA"].ToString() : "";
           // if (ddlLeadNo.SelectedItem.ToString().Contains("MSE"))
            if (ddlLeadNo.SelectedItem.ToString().Contains("MSE"))
            {
                lblBMEndUse.Text = dsdd.Tables[0].Rows[0]["PP_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PP_DESC"].ToString() : "";
                lblOCIEndUse.Text = dsdd.Tables[0].Rows[1]["PP_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["PP_DESC"].ToString() : "";
                trEndUse.Visible = true;
            }
            else
                if (ddlLeadNo.SelectedItem.ToString().Contains("ASL") || ddlLeadNo.SelectedItem.ToString().Contains("SMFL"))
                {
                    lblBMEndUse.Text = clscommon.GetFormerActivity(ddlLeadNo.SelectedValue.ToString(), "B");
                    lblOCIEndUse.Text = clscommon.GetSubFormerActivity(ddlLeadNo.SelectedValue.ToString(), "S");
                    trEndUse.Visible = true;
                }
                else
                {
                    trEndUse.Visible = false;
                }
            if (lblLoanamountrecommeded.Text != "" && lblLoanamountrecommeded_CR.Text != "")
            {
                lblLoanamountrecommeded_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblLoanamountrecommeded_CR.Text) * 100) / Convert.ToDouble(lblLoanamountrecommeded.Text)));
            }


            SqlCommand cmddd1 = new SqlCommand("Fetch_SAM_Approval_Appeal_Details", con);
            cmddd1.Parameters.AddWithValue("@SD_LD_ID", ddlLeadNo.SelectedValue.ToString());
            cmddd1.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd1 = new SqlDataAdapter(cmddd1);
            DataSet dsdd1 = new DataSet();
            dadd1.Fill(dsdd1);
            if (dsdd1.Tables[0] != null && dsdd1.Tables[0].Rows.Count > 0)
            {
                txtNetIncomeafterfactoringRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_NETIN"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_NETIN"].ToString() : "";
                txtObligationRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_OBLIG"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_OBLIG"].ToString() : "";
                txtLandSQFTRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_SQFT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SQFT"].ToString() : "";
                txtReginetRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_GV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_GV"].ToString() : "";
                txtMarketvalueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_MV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_MV"].ToString() : "";
                txtTotalLandvalueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_LV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_LV"].ToString() : "";
                txtBuildingTypeRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_BTYPE"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_BTYPE"].ToString() : "";
                txtAgeofbuildingRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_BAGE"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_BAGE"].ToString() : "";
                txtBuildingValueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_BV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_BV"].ToString() : "";
                txtTotalpropertyvalueRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_PV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_PV"].ToString() : "";
                txtLoanamountrecommeded.Text = dsdd1.Tables[0].Rows[0]["SL_LAMT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_LAMT"].ToString() : "";


                txtGvalue.Text = dsdd1.Tables[0].Rows[0]["SL_RGV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RGV"].ToString() : "";
                txtMarkVal.Text = dsdd1.Tables[0].Rows[0]["SL_RMV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RMV"].ToString() : "";
                txtLandArea.Text = dsdd1.Tables[0].Rows[0]["SL_RSQFT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RSQFT"].ToString() : "";
                txtBMLandValue.Text = dsdd1.Tables[0].Rows[0]["SL_RLV"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RLV"].ToString() : "";

                ddlTolerance.SelectedValue = dsdd1.Tables[0].Rows[0]["SL_TOL"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_TOL"].ToString() : "";
                ddlApproove.SelectedValue = dsdd1.Tables[0].Rows[0]["SL_DECSN"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_DECSN"].ToString() : "";
                if (ddlApproove.SelectedValue != "Rejected")
                {
                    lblRcmnd.Visible=true;
                    txtFinalRcmnd.Visible = true;
                    txtFinalRcmnd.Text = dsdd1.Tables[0].Rows[0]["SL_RAMT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RAMT"].ToString() : "";
                }
                string strRType = dsdd1.Tables[0].Rows[0]["SL_RTYPE"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RTYPE"].ToString() : "";
                if (strRType == "SPOT")
                {

                    trResult.Visible = true;
                    rdnSpot.Checked = true;
                    trSPot.Visible = true;
                    trPDDComplete1.Visible = false;
                }
                else if (strRType == "PDD")
                {
                    trResult.Visible = true;
                    rdnPDD.Checked = true;
                    trPDDComplete1.Visible = true;
                    trSPot.Visible = false;
                    trBussEmpRelt.Visible = false;
                    trIncomeTol.Visible = false;
                    trPropRel.Visible = false;
                    trVerRel.Visible = false;
                }

                string strMRISK = dsdd1.Tables[0].Rows[0]["SL_MRISK"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_MRISK"].ToString() : "";
                if (strMRISK.Contains("Business/Employee Related"))
                {
                    rdnBussEmpRelated.Checked = true;
                    trBussEmpRelt.Visible = true;
                    trIncomeTol.Visible = false;
                    trPropRel.Visible = false;
                    trVerRel.Visible = false;

                }
                if (strMRISK.Contains("Income Related"))
                {
                    rdnIncomeRelated.Checked = true;
                    trBussEmpRelt.Visible = false;
                    trIncomeTol.Visible = true;
                    trPropRel.Visible = false;
                    trVerRel.Visible = false;
                }
                if (strMRISK.Contains("Property Related"))
                {
                    rdnPropRelated.Checked = true;
                    trBussEmpRelt.Visible = false;
                    trIncomeTol.Visible = false;
                    trPropRel.Visible = true;
                    trVerRel.Visible = false;
                }
                if (strMRISK.Contains("Verification Related"))
                {
                    rdnVerRelated.Checked = true;
                    rdnVerRel.Checked = true;
                    trBussEmpRelt.Visible = false;
                    trIncomeTol.Visible = false;
                    trPropRel.Visible = false;
                    trVerRel.Visible = true;
                }
                if (strMRISK.Contains("PDD Income Related"))
                {
                    trPDDComplete2.Visible = true;
                }
                if (strMRISK.Contains("PDD Verification Related"))
                {
                    trPDDComplete3.Visible = true;
                }

                string strSRISK = dsdd1.Tables[0].Rows[0]["SL_SRISK"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SRISK"].ToString() : "";
                if (strSRISK.Contains("Business/Employment Related"))
                {
                    rdnBussEmpRel.Checked = true;
                }
                if (strSRISK == "Incorrect Business/Employment Related information")
                {
                    rdnBussEmpRe2.Checked = true;
                }
                if (strSRISK.Contains("Income Tolerance Level"))
                {
                    rdbIncomeTolerance.Checked = true;
                }
                if (strSRISK.Contains("Building Age"))
                {
                    rdnBuildAge.Checked = true;
                }
                if (strSRISK.Contains("Building Area"))
                {
                    rdnBuildArea.Checked = true;
                }
                if (strSRISK.Contains("Incorrect Property Information"))
                {
                    rdnIncorrectBuildDet.Checked = true;
                }
                if (strSRISK.Contains("Verification Related"))
                {
                    rdnVerRel.Checked = true;
                }
                if (strSRISK.Contains("PDD Income Assessment"))
                {
                    chkPDDIncomeRelated.Checked = true;
                }
                if (strSRISK.Contains("PDD Verification Related"))
                {
                    chkPDDVerficationRel.Checked = true;
                }

                txtRmrk.Text = dsdd1.Tables[0].Rows[0]["SL_RMKS"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RMKS"].ToString() : "";
                txtbmrmk.Text = dsdd1.Tables[0].Rows[0]["SL_AAPLRMKS"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_AAPLRMKS"].ToString() : "";
                txtBMRemarksForSCI.Text = dsdd1.Tables[0].Rows[0]["SL_SAPLRMKS"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SAPLRMKS"].ToString() : "";
               

                    
                ddlSCIAppeal.SelectedValue = dsdd1.Tables[0].Rows[0]["SL_SCI_DESCN"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SCI_DESCN"].ToString() : "";
                if (ddlSCIAppeal.SelectedValue != "Rejected")
                {
                    lblRcmnd.Visible=true;
                    txtFinalRcmnd0.Visible = true;
                    txtFinalRcmnd0.Text = dsdd1.Tables[0].Rows[0]["SL_RAMT"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_RAMT"].ToString() : "";
                }
                  txtRmrk0.Text = dsdd1.Tables[0].Rows[0]["SL_SCI_RMKS"] != DBNull.Value ? dsdd1.Tables[0].Rows[0]["SL_SCI_RMKS"].ToString() : "";
                  if (dsdd.Tables[3] != null && dsdd.Tables[3].Rows.Count > 0)
                  {
                      trRpa1.Visible = false;
                      trRpa2.Visible = true;

                      lblBMGvalue.Text = lblReginet.Text;
                      lblFROGvalue.Text = dsdd.Tables[3].Rows[0]["RPA_GV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_GV"].ToString() : "";
                      if (lblBMGvalue.Text != "" && lblFROGvalue.Text != "")
                      {
                          lblVarGvalue.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFROGvalue.Text) * 100) / Convert.ToDouble(lblBMGvalue.Text)));
                      }

                      lblBMMarkVal.Text = lblMarketvalue.Text;
                      lblFORMarkVal.Text = dsdd.Tables[3].Rows[0]["RPA_MV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_MV"].ToString() : "";
                      if (lblBMMarkVal.Text != "" && lblFORMarkVal.Text != "")
                      {
                          lblVarMarkVal.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFORMarkVal.Text) * 100) / Convert.ToDouble(lblBMMarkVal.Text)));
                      }

                      lblBMLandArea.Text = lblLandSQFT.Text;
                      lblFORLandArea.Text = dsdd.Tables[3].Rows[0]["RPA_LAREA"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_LAREA"].ToString() : "";
                      if (lblFORLandArea.Text != "" && lblBMLandArea.Text != "")
                      {
                          lblVarLandArea.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFORLandArea.Text) * 100) / Convert.ToDouble(lblBMLandArea.Text)));
                      }

                      lblBMLandValue.Text = lblTotalLandvalue.Text;
                      lblForLandValue.Text = dsdd.Tables[3].Rows[0]["RPA_LV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_LV"].ToString() : "";
                      if (lblBMLandValue.Text != "" && lblForLandValue.Text != "")
                      {
                          lblVarLandValue.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblForLandValue.Text) * 100) / Convert.ToDouble(lblBMLandValue.Text)));
                      }


                  }
                  else
                  {
                      trRpa1.Visible = true;
                      trRpa2.Visible = false;
                  }
            }
        }
    }
    protected void ddlApproove_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlApproove.SelectedValue == "Rejected")
        {
            trResult.Visible = true;
        }
        else
        {
            trResult.Visible = false;

        }
    }
    protected void rdnSpot_CheckedChanged(object sender, EventArgs e)
    {
        trSPot.Visible = true;
    }
    protected void rdnPDD_CheckedChanged(object sender, EventArgs e)
    {
        trSPot.Visible = false;
        trBussEmpRelt.Visible = false;
        trIncomeTol.Visible = false;
        trPropRel.Visible = false;
        trVerRel.Visible = false;
    }
    protected void rdnBussEmpRelated_CheckedChanged(object sender, EventArgs e)
    {
        trBussEmpRelt.Visible = true;
        trIncomeTol.Visible = false;
        trPropRel.Visible = false;
        trVerRel.Visible = false;
    }
    protected void rdnIncomeRelated_CheckedChanged(object sender, EventArgs e)
    {
        trBussEmpRelt.Visible = false;
        trIncomeTol.Visible = true;
        trPropRel.Visible = false;
        trVerRel.Visible = false;
    }
    protected void rdnPropRelated_CheckedChanged(object sender, EventArgs e)
    {
        trBussEmpRelt.Visible = false;
        trIncomeTol.Visible = false;
        trPropRel.Visible = true;
        trVerRel.Visible = false;
    }
    protected void rdnVerRelated_CheckedChanged(object sender, EventArgs e)
    {
        trBussEmpRelt.Visible = false;
        trIncomeTol.Visible = false;
        trPropRel.Visible = false;
        trVerRel.Visible = true;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (ddlAMCDescn.SelectedItem.Text == "--Select--")
        {
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Decision');", true);
            ddlAMCDescn.Focus();
        }
        else if (ddlAMCDescn.SelectedItem.Text == "Recommended" && txtAMCRAMT.Text.Trim() == "")
        {
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Give Final Recommended Amount');", true);
            txtAMCApprv.Focus();
        }
        else
        {
            UpdateSamplingApprvlDatas();
        }
    }

    public void UpdateSamplingApprvlDatas()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdupdate = new SqlCommand("RTS_SP_UpdateSAApprooval", con);
            cmdupdate.CommandType = CommandType.StoredProcedure;
            cmdupdate.Parameters.AddWithValue("@SL_LD_ID", ddlLeadNo.SelectedValue.ToString());
            cmdupdate.Parameters.AddWithValue("@SL_RAMT", txtAMCRAMT.Text != "" ?txtAMCRAMT.Text :"0.0");
            cmdupdate.Parameters.AddWithValue("@SL_ACI_RMKS", txtAMCApprv.Text);
            cmdupdate.Parameters.AddWithValue("@SL_ACI_DECSN", ddlAMCDescn.SelectedItem.Text != "" ?ddlAMCDescn.SelectedItem.Text:"");          
            cmdupdate.Parameters.AddWithValue("@ID", Session["ID"].ToString());
            cmdupdate.Parameters.AddWithValue("@APPTYPE", "AMCIAPPEAL");
            cmdupdate.Parameters.AddWithValue("@SL_ACI_TOL", ddlTolerance.SelectedItem.Text != "" ? ddlTolerance.SelectedItem.Text : "");

            int n = cmdupdate.ExecuteNonQuery();
            con.Close();
            if (n > 0)
            {

                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('AM-CI Approval for " + ddlLeadNo.SelectedItem.Text + "   done Successfully');  window.location.assign('AMCAppeal.aspx')", true);
                //  Response.Redirect("CAM_LAP.aspx");
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('AM-CI Approval for " + ddlLeadNo.SelectedItem.Text + "   Failed ');", true);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('AM-CI Approval for " + ddlLeadNo.SelectedItem.Text + "   Failed ');", true);
        }
    }

    protected void ddlAMCDescn_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlAMCDescn.SelectedValue == "Rejected")
        {

            txtAMCRAMT.Visible = false;
            lblFinalRecmnd1.Visible = false;
            txtAMCRAMT.Text = "";
        }
        else
        {

            txtAMCRAMT.Visible = true;
            lblFinalRecmnd1.Visible = true;

        }
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, "--Select--");
        ddlBranch.Enabled = true;
        BindLeadNo();
    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindLeadNo();
    }
}