﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using System.Text;
using System.Threading;
using System.Text.RegularExpressions;
using System.Globalization;
using CrystalDecisions.Shared;
using Tracker;

public partial class Legal_Modify : System.Web.UI.Page
{

    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter dappre = new SqlDataAdapter();

    DataSet dspre = new DataSet();

    DataTable dtpre = new DataTable();

    DataSet ds = new DataSet();
    DataSet dss = new DataSet();

    DataTable dtcbrw = new DataTable();

    ReportDocument rpt = new ReportDocument();

    DateTime dtd;
    int cbrwcnt, docscnt, propcnt, id;
    string strValb, strValp, strVald;
    int eccnt;
    string strVale;

    ClsCommon clscommon = new ClsCommon();
    Regex Rx = new Regex("^[0-9]+$");

    static bool lstdoc = false;
    static bool NOTDISBURSED = false;

    StringBuilder cusnames = new StringBuilder();
    public static string docxrstat = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    SqlConnection con = new SqlConnection(strcon);
                    Session["MODStatusLGL"] = "New";
                    Session["MODStatusLGLCBRW"] = "New";
                    Session["MODStatusLGLSCHEDULE"] = "New";

                    Session["MODStatusLGLEC"] = "New";
                    Bind_Stage();
                    BindPropType();
                    Bind_Doc_Type();
                    //Bind_Proof();

                    this.cusdets.Visible = false;
                    this.cusdetsh.Visible = false;

                    this.propschdetsh.Visible = false;
                    this.propschdets.Visible = false;

                    this.docsdetsh.Visible = false;
                    this.docsdets.Visible = false;

                    this.titleopiniondetsh.Visible = false;
                    this.titleopiniondets.Visible = false;


                    this.propdetsmodtd.Visible = false;
                    this.propdetsmodtdh.Visible = false;

                    this.ecdetsh.Visible = false;
                    this.ecdets.Visible = false;

                    this.notedets.Visible = false;
                    this.notedetsh.Visible = false;

                    this.concldets.Visible = false;
                    this.concldetsh.Visible = false;

                    this.rmksh.Visible = false;
                    this.rmks.Visible = false;


                    this.MODTDH.Visible = false;
                    this.MODTDDETS.Visible = false;

                    this.ownersame.Visible = false;
                    this.ownersamedetails.Visible = false;

                    this.Township.Visible = false;
                    this.Townshipdetails.Visible = false;

                }
            }
            else Response.Redirect("Expire.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnview_Click(object sender, EventArgs e)
    {

        if (ddlststage.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select the stage." + txtbxleadno.Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (ddlstitms.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select the items." + txtbxleadno.Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txtbxleadno.Text.Trim() == "")
        {
            uscMsgBox1.AddMessage("Please enter the lead number." + txtbxleadno.Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(strcon))
                {
                    connection.Open();

                    cmd = new SqlCommand("SELECT * FROM LSD_LEAD WHERE  LD_NO='" + txtbxleadno.Text.Trim() + "'", connection);

                    cmd.CommandTimeout = 120000;
                    dspre = new DataSet();
                    dappre = new SqlDataAdapter(cmd);
                    dappre.Fill(dspre);

                    if (dspre.Tables[0].Rows.Count > 0)
                    {
                        cmd = new SqlCommand("SELECT * FROM LSD_LEAD WHERE LD_LOAN_NO IS NULL AND LD_NO='" + txtbxleadno.Text.Trim() + "'", connection);
                        if (dspre.Tables[0].Rows.Count > 0)
                        {
                            NOTDISBURSED = false;
                            Session["NOTDISB"] = "FALSE";

                        }
                        else
                        {
                            NOTDISBURSED = true;
                            Session["NOTDISB"] = "TRUE";
                        }

                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Invalid lead no " + txtbxleadno.Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        return;
                    }


                    if (Session["NOTDISB"].ToString() == "FALSE")
                    {
                        #region view process
                        if (ddlststage.SelectedItem.Text == "Preliminary Opinion")
                        {
                            cmd = new SqlCommand("RTS_SP_RPT_PRELIMINARY_UI", connection);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@LDNO", txtbxleadno.Text.Trim());
                            cmd.CommandTimeout = 120000;
                            dspre = new DataSet();
                            dappre = new SqlDataAdapter(cmd);
                            dappre.Fill(dspre);
                        }
                        else if (ddlststage.SelectedItem.Text == "Final Opinion")
                        {
                            cmd = new SqlCommand("RTS_SP_RPT_FINAL_UI", connection);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@LDNO", txtbxleadno.Text.Trim());
                            cmd.CommandTimeout = 120000;
                            dspre = new DataSet();
                            dappre = new SqlDataAdapter(cmd);
                            dappre.Fill(dspre);
                        }

                        else if (ddlststage.SelectedItem.Text == "MODTD")
                        {
                            cmd = new SqlCommand("RTS_SP_RPT_MODTD", connection);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@LDNO", txtbxleadno.Text.Trim());
                            cmd.CommandTimeout = 120000;
                            dspre = new DataSet();
                            dappre = new SqlDataAdapter(cmd);
                            dappre.Fill(dspre);
                        }
                        if (dspre.Tables[0].Rows.Count > 0)
                        {

                            Session["MODLEADID"] = dspre.Tables[0].Rows[0]["LD_ID"] != DBNull.Value ? dspre.Tables[0].Rows[0]["LD_ID"].ToString() : null;
                            if (ddlstitms.SelectedItem.Text == "Applicant Details")
                            {


                                if (txtbxleadno.Text.StartsWith("LAP"))
                                {
                                    Bind_Proof("1");
                                }
                                else if (txtbxleadno.Text.StartsWith("SME"))
                                {
                                    Bind_Proof("2");
                                }
                                else if (txtbxleadno.Text.StartsWith("MHF"))
                                {
                                    Bind_Proof("3");
                                }
                                else if (txtbxleadno.Text.StartsWith("GHF"))
                                {
                                    Bind_Proof("4");
                                }
                                else if (txtbxleadno.Text.StartsWith("GLP"))
                                {
                                    Bind_Proof("5");
                                }
                                else if (txtbxleadno.Text.StartsWith("MSE"))
                                {
                                    Bind_Proof("12");
                                }
                                else if (txtbxleadno.Text.StartsWith("ASL"))
                                {
                                    Bind_Proof("13");
                                }
                                else if (txtbxleadno.Text.StartsWith("ADL"))
                                {
                                    Bind_Proof("14");
                                }
                                else if (txtbxleadno.Text.StartsWith("SLAP"))
                                {
                                    Bind_Proof("24");
                                }
                                else if (txtbxleadno.Text.StartsWith("IBSL"))
                                {
                                    Bind_Proof("17");
                                }
                                else if (txtbxleadno.Text.StartsWith("IBSS"))
                                {
                                    Bind_Proof("18");
                                }
                                else if (txtbxleadno.Text.StartsWith("IBSD"))
                                {
                                    Bind_Proof("19");
                                }
                                else if (txtbxleadno.Text.StartsWith("SMFL"))
                                {
                                    Bind_Proof("29");
                                }
                                else if (txtbxleadno.Text.StartsWith("IBAH"))
                                {
                                    Bind_Proof("21");
                                }

                                BindAllGrid("All");
                                
                                this.cusdets.Visible = true;
                                this.cusdetsh.Visible = true;

                                this.propschdetsh.Visible = false;
                                this.propschdets.Visible = false;

                                this.docsdetsh.Visible = false;
                                this.docsdets.Visible = false;
                                this.titleopiniondetsh.Visible = false;
                                this.titleopiniondets.Visible = false;


                                this.propdetsmodtd.Visible = false;
                                this.propdetsmodtdh.Visible = false;

                                this.ecdetsh.Visible = false;
                                this.ecdets.Visible = false;

                                this.notedets.Visible = false;
                                this.notedetsh.Visible = false;

                                this.concldets.Visible = false;
                                this.concldetsh.Visible = false;

                                this.rmksh.Visible = false;
                                this.rmks.Visible = false;


                                this.MODTDH.Visible = false;
                                this.MODTDDETS.Visible = false;

                                this.ownersame.Visible = false;
                                this.ownersamedetails.Visible = false;

                                this.Township.Visible = false;
                                this.Townshipdetails.Visible = false;

                            }
                            else if (ddlstitms.SelectedItem.Text == "Property Schedule Details")
                            {
                               
                                BindAllGrid("All");
                                KYC_details();
                                this.propschdetsh.Visible = true;
                                this.propschdets.Visible = true;

                                this.cusdets.Visible = false;
                                this.cusdetsh.Visible = false;

                                this.docsdetsh.Visible = false;
                                this.docsdets.Visible = false;
                                this.titleopiniondetsh.Visible = false;
                                this.titleopiniondets.Visible = false;


                                this.propdetsmodtd.Visible = false;
                                this.propdetsmodtdh.Visible = false;

                                this.ecdetsh.Visible = false;
                                this.ecdets.Visible = false;

                                this.notedets.Visible = false;
                                this.notedetsh.Visible = false;

                                this.concldets.Visible = false;
                                this.concldetsh.Visible = false;

                                this.rmksh.Visible = false;
                                this.rmks.Visible = false;


                                this.MODTDH.Visible = false;
                                this.MODTDDETS.Visible = false;

                                this.ownersame.Visible = false;
                                this.ownersamedetails.Visible = false;

                                this.Township.Visible = false;
                                this.Townshipdetails.Visible = false;
                            }
                            else if (ddlstitms.SelectedItem.Text == "List of Documents")
                            {
                                BindAllGrid("All");
                                if (Session["LSTDOC"] == "TRUE")
                                {
                                    this.propschdetsh.Visible = false;
                                    this.propschdets.Visible = false;

                                    this.cusdets.Visible = false;
                                    this.cusdetsh.Visible = false;

                                    this.docsdetsh.Visible = true;
                                    this.docsdets.Visible = true;

                                    this.titleopiniondetsh.Visible = false;
                                    this.titleopiniondets.Visible = false;


                                    this.propdetsmodtd.Visible = false;
                                    this.propdetsmodtdh.Visible = false;

                                    this.ecdetsh.Visible = false;
                                    this.ecdets.Visible = false;

                                    this.notedets.Visible = false;
                                    this.notedetsh.Visible = false;

                                    this.concldets.Visible = false;
                                    this.concldetsh.Visible = false;

                                    this.rmksh.Visible = false;
                                    this.rmks.Visible = false;

                                    this.MODTDH.Visible = false;
                                    this.MODTDDETS.Visible = false;

                                    this.ownersame.Visible = false;
                                    this.ownersamedetails.Visible = false;

                                    this.Township.Visible = false;
                                    this.Townshipdetails.Visible = false;
                                }
                                else
                                {

                                }
                            }



                            else if (ddlstitms.SelectedItem.Text == "Title of Opinion")
                            {
                                BindAllGrid("All");
                                this.propschdetsh.Visible = false;
                                this.propschdets.Visible = false;

                                this.cusdets.Visible = false;
                                this.cusdetsh.Visible = false;

                                this.docsdetsh.Visible = false;
                                this.docsdets.Visible = false;

                                this.titleopiniondetsh.Visible = true;
                                this.titleopiniondets.Visible = true;


                                this.propdetsmodtd.Visible = false;
                                this.propdetsmodtdh.Visible = false;

                                this.ecdetsh.Visible = false;
                                this.ecdets.Visible = false;

                                this.notedets.Visible = false;
                                this.notedetsh.Visible = false;

                                this.concldets.Visible = false;
                                this.concldetsh.Visible = false;

                                this.rmksh.Visible = false;
                                this.rmks.Visible = false;


                                this.MODTDH.Visible = false;
                                this.MODTDDETS.Visible = false;

                                this.ownersame.Visible = false;
                                this.ownersamedetails.Visible = false;

                                this.Township.Visible = false;
                                this.Townshipdetails.Visible = false;
                            }
                            else if (ddlstitms.SelectedItem.Text == "MODTD Property Details")
                            {
                                BindAllGrid("All");
                                this.propschdetsh.Visible = false;
                                this.propschdets.Visible = false;

                                this.cusdets.Visible = false;
                                this.cusdetsh.Visible = false;

                                this.docsdetsh.Visible = false;
                                this.docsdets.Visible = false;

                                this.titleopiniondetsh.Visible = false;
                                this.titleopiniondets.Visible = false;


                                this.propdetsmodtd.Visible = true;
                                this.propdetsmodtdh.Visible = true;

                                this.ecdetsh.Visible = false;
                                this.ecdets.Visible = false;

                                this.notedets.Visible = false;
                                this.notedetsh.Visible = false;

                                this.concldets.Visible = false;
                                this.concldetsh.Visible = false;

                                this.rmksh.Visible = false;
                                this.rmks.Visible = false;


                                this.MODTDH.Visible = false;
                                this.MODTDDETS.Visible = false;

                                this.ownersame.Visible = false;
                                this.ownersamedetails.Visible = false;

                                this.Township.Visible = false;
                                this.Townshipdetails.Visible = false;
                            }
                            else if (ddlstitms.SelectedItem.Text == "EC / Search Report")
                            {
                                BindAllGrid("All");
                                this.propschdetsh.Visible = false;
                                this.propschdets.Visible = false;

                                this.cusdets.Visible = false;
                                this.cusdetsh.Visible = false;

                                this.docsdetsh.Visible = false;
                                this.docsdets.Visible = false;

                                this.titleopiniondetsh.Visible = false;
                                this.titleopiniondets.Visible = false;


                                this.propdetsmodtd.Visible = false;
                                this.propdetsmodtdh.Visible = false;

                                this.ecdetsh.Visible = true;
                                this.ecdets.Visible = true;

                                this.notedets.Visible = false;
                                this.notedetsh.Visible = false;

                                this.concldets.Visible = false;
                                this.concldetsh.Visible = false;

                                this.rmksh.Visible = false;
                                this.rmks.Visible = false;


                                this.MODTDH.Visible = false;
                                this.MODTDDETS.Visible = false;

                                this.ownersame.Visible = false;
                                this.ownersamedetails.Visible = false;

                                this.Township.Visible = false;
                                this.Townshipdetails.Visible = false;
                            }
                            else if (ddlstitms.SelectedItem.Text == "Note")
                            {
                                BindAllGrid("All");
                                this.propschdetsh.Visible = false;
                                this.propschdets.Visible = false;

                                this.cusdets.Visible = false;
                                this.cusdetsh.Visible = false;

                                this.docsdetsh.Visible = false;
                                this.docsdets.Visible = false;

                                this.titleopiniondetsh.Visible = false;
                                this.titleopiniondets.Visible = false;


                                this.propdetsmodtd.Visible = false;
                                this.propdetsmodtdh.Visible = false;

                                this.ecdetsh.Visible = false;
                                this.ecdets.Visible = false;

                                this.notedets.Visible = true;
                                this.notedetsh.Visible = true;

                                this.concldets.Visible = false;
                                this.concldetsh.Visible = false;

                                this.rmksh.Visible = false;
                                this.rmks.Visible = false;

                                this.MODTDH.Visible = false;
                                this.MODTDDETS.Visible = false;

                                this.ownersame.Visible = false;
                                this.ownersamedetails.Visible = false;

                                this.Township.Visible = false;
                                this.Townshipdetails.Visible = false;
                            }
                            else if (ddlstitms.SelectedItem.Text == "Conclusion")
                            {
                                BindAllGrid("All");
                                this.propschdetsh.Visible = false;
                                this.propschdets.Visible = false;

                                this.cusdets.Visible = false;
                                this.cusdetsh.Visible = false;

                                this.docsdetsh.Visible = false;
                                this.docsdets.Visible = false;

                                this.titleopiniondetsh.Visible = false;
                                this.titleopiniondets.Visible = false;


                                this.propdetsmodtd.Visible = false;
                                this.propdetsmodtdh.Visible = false;

                                this.ecdetsh.Visible = false;
                                this.ecdets.Visible = false;

                                this.notedets.Visible = false;
                                this.notedetsh.Visible = false;

                                this.concldets.Visible = true;
                                this.concldetsh.Visible = true;

                                this.rmksh.Visible = false;
                                this.rmks.Visible = false;

                                this.MODTDH.Visible = false;
                                this.MODTDDETS.Visible = false;

                                this.ownersame.Visible = false;
                                this.ownersamedetails.Visible = false;

                                this.Township.Visible = false;
                                this.Townshipdetails.Visible = false;
                            }
                            else if (ddlstitms.SelectedItem.Text == "Remarks")
                            {
                                BindAllGrid("All");
                                this.propschdetsh.Visible = false;
                                this.propschdets.Visible = false;

                                this.cusdets.Visible = false;
                                this.cusdetsh.Visible = false;

                                this.docsdetsh.Visible = false;
                                this.docsdets.Visible = false;

                                this.titleopiniondetsh.Visible = false;
                                this.titleopiniondets.Visible = false;


                                this.propdetsmodtd.Visible = false;
                                this.propdetsmodtdh.Visible = false;

                                this.ecdetsh.Visible = false;
                                this.ecdets.Visible = false;

                                this.notedets.Visible = false;
                                this.notedetsh.Visible = false;

                                this.concldets.Visible = false;
                                this.concldetsh.Visible = false;

                                this.rmksh.Visible = true;
                                this.rmks.Visible = true;

                                this.MODTDH.Visible = false;
                                this.MODTDDETS.Visible = false;

                                this.ownersame.Visible = false;
                                this.ownersamedetails.Visible = false;

                                this.Township.Visible = false;
                                this.Townshipdetails.Visible = false;

                            }

                            else if (ddlstitms.SelectedItem.Text == "MODTD Applicant Details")
                            {
                                BindAllGrid("All");


                                this.propschdetsh.Visible = false;
                                this.propschdets.Visible = false;

                                this.cusdets.Visible = false;
                                this.cusdetsh.Visible = false;

                                this.docsdetsh.Visible = false;
                                this.docsdets.Visible = false;

                                this.titleopiniondetsh.Visible = false;
                                this.titleopiniondets.Visible = false;


                                this.propdetsmodtd.Visible = false;
                                this.propdetsmodtdh.Visible = false;

                                this.ecdetsh.Visible = false;
                                this.ecdets.Visible = false;

                                this.notedets.Visible = false;
                                this.notedetsh.Visible = false;

                                this.concldets.Visible = false;
                                this.concldetsh.Visible = false;

                                this.rmksh.Visible = false;
                                this.rmks.Visible = false;

                                this.MODTDH.Visible = true;
                                this.MODTDDETS.Visible = true;

                                this.ownersame.Visible = false;
                                this.ownersamedetails.Visible = false;

                                this.Township.Visible = false;
                                this.Townshipdetails.Visible = false;

                            }
                            else if (ddlstitms.SelectedItem.Text == "Property Owner same as Applicant")
                            {
                                BindAllGrid("All");


                                this.propschdetsh.Visible = false;
                                this.propschdets.Visible = false;

                                this.cusdets.Visible = false;
                                this.cusdetsh.Visible = false;

                                this.docsdetsh.Visible = false;
                                this.docsdets.Visible = false;

                                this.titleopiniondetsh.Visible = false;
                                this.titleopiniondets.Visible = false;


                                this.propdetsmodtd.Visible = false;
                                this.propdetsmodtdh.Visible = false;

                                this.ecdetsh.Visible = false;
                                this.ecdets.Visible = false;

                                this.notedets.Visible = false;
                                this.notedetsh.Visible = false;

                                this.concldets.Visible = false;
                                this.concldetsh.Visible = false;

                                this.rmksh.Visible = false;
                                this.rmks.Visible = false;

                                this.MODTDH.Visible = false;
                                this.MODTDDETS.Visible = false;

                                this.ownersame.Visible = true;
                                this.ownersamedetails.Visible = true;

                                this.Township.Visible = false;
                                this.Townshipdetails.Visible = false;
                            }
                            else if (ddlstitms.SelectedItem.Text == "Township Field")
                            {
                                BindAllGrid("All");


                                this.propschdetsh.Visible = false;
                                this.propschdets.Visible = false;

                                this.cusdets.Visible = false;
                                this.cusdetsh.Visible = false;

                                this.docsdetsh.Visible = false;
                                this.docsdets.Visible = false;

                                this.titleopiniondetsh.Visible = false;
                                this.titleopiniondets.Visible = false;


                                this.propdetsmodtd.Visible = false;
                                this.propdetsmodtdh.Visible = false;

                                this.ecdetsh.Visible = false;
                                this.ecdets.Visible = false;

                                this.notedets.Visible = false;
                                this.notedetsh.Visible = false;

                                this.concldets.Visible = false;
                                this.concldetsh.Visible = false;

                                this.rmksh.Visible = false;
                                this.rmks.Visible = false;

                                this.MODTDH.Visible = false;
                                this.MODTDDETS.Visible = false;

                                this.ownersame.Visible = false;
                                this.ownersamedetails.Visible = false;

                                this.Township.Visible = true;
                                this.Townshipdetails.Visible = true;
                            }
                        }
                        else
                        {
                            if (ddlststage.SelectedItem.Text == "Preliminary Opinion" && dspre.Tables[0].Rows.Count <= 0)
                            {
                                txtbxleadno.Focus();
                                uscMsgBox1.AddMessage("Preliminary opinion not done for the lead no " + txtbxleadno.Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }

                            else if (ddlststage.SelectedItem.Text == "Preliminary Opinion" && dspre.Tables[0].Rows.Count <= 0)
                            {
                                txtbxleadno.Focus();
                                uscMsgBox1.AddMessage("Final opinion not done for the lead no " + txtbxleadno.Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }
                            else if (ddlststage.SelectedItem.Text == "MODTD" && dspre.Tables[0].Rows.Count <= 0)
                            {
                                txtbxleadno.Focus();
                                uscMsgBox1.AddMessage("MODTD not done for the lead no " + txtbxleadno.Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }
                            this.cusdets.Visible = false;
                            this.cusdetsh.Visible = false;

                            this.propschdetsh.Visible = false;
                            this.propschdets.Visible = false;

                            this.docsdetsh.Visible = false;
                            this.docsdets.Visible = false;

                            this.titleopiniondetsh.Visible = false;
                            this.titleopiniondets.Visible = false;


                            this.propdetsmodtd.Visible = false;
                            this.propdetsmodtdh.Visible = false;

                            this.ecdetsh.Visible = false;
                            this.ecdets.Visible = false;

                            this.notedets.Visible = false;
                            this.notedetsh.Visible = false;

                            this.concldets.Visible = false;
                            this.concldetsh.Visible = false;

                            this.rmksh.Visible = false;
                            this.rmks.Visible = false;


                            this.MODTDH.Visible = false;
                            this.MODTDDETS.Visible = false;

                            this.ownersame.Visible = false;
                            this.ownersamedetails.Visible = false;

                            this.Township.Visible = false;
                            this.Townshipdetails.Visible = false;
                        }

                        #endregion
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("The lead no " + txtbxleadno.Text + " is disbursed ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
        }
    }
    public void KYC_details()
    {
        try
        {
            Session["LEADID"] = clscommon.GetLeadId(txtbxleadno.Text);

            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_KYC", con);
            cmddd.Parameters.AddWithValue("@LD_ID", Session["LEADID"].ToString().Trim());
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            lstPropOwner.DataSource = dsdd;
            lstPropOwner.DataTextField = "KYC_NAME";
            lstPropOwner.DataValueField = "KYC_ID";
            lstPropOwner.DataBind();
            lstPropOwner.Items.Insert(0, new ListItem("--Select--", "0"));
            // TBAppType.Text = "";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void BindAllGrid(string Type)
    {
        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                cmd = new SqlCommand("RTS_SP_BIND_LGL_PREOPINION", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@LDID", Convert.ToInt32(Session["MODLEADID"].ToString()));
                cmd.CommandTimeout = 120000;
                dspre = new DataSet();
                dappre = new SqlDataAdapter(cmd);
                dappre.Fill(dspre);

                if (ddlststage.SelectedItem.Text == "Preliminary Opinion" && ddlstitms.SelectedItem.Text == "List of Documents")
                {
                    if (dspre.Tables[3].Rows[0]["MDX_OVSTAT"] != DBNull.Value)
                    {
                        lstdoc = true;
                        Session["LSTDOC"] = "TRUE";
                    }
                    else
                    {
                        lstdoc = false;
                        Session["LSTDOC"] = "FALSE";
                    }

                }

                if (Type == "All")
                {

                    if (dspre.Tables.Count > 0)
                    {

                        if (dspre.Tables[0].Rows.Count > 0)
                        {
                            Session["MODMDID"] = dspre.Tables[0].Rows[0]["MD_ID"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_ID"].ToString() : null;
                            txtbxaddr1.Text = dspre.Tables[0].Rows[0]["MD_BR_ADD1"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_BR_ADD1"].ToString() : "";
                            txtbxaddr2.Text = dspre.Tables[0].Rows[0]["MD_BR_ADD2"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_BR_ADD2"].ToString() : "";
                            string[] addrarr = dspre.Tables[0].Rows[0]["MD_BR_ADD3"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_BR_ADD3"].ToString().Split('-') : null;
                            if (addrarr != null && addrarr.Length > 1)
                            {
                                txtbxcity.Text = addrarr[0].ToString().Trim();
                                txtbxpincode.Text = addrarr[1].ToString().Trim();
                            }
                            else
                            {
                                txtbxcity.Text = "";
                                txtbxpincode.Text = "";
                            }


                            txtbxtitleofopinion.Text = dspre.Tables[0].Rows[0]["MD_TITLE"] == DBNull.Value ? "" : dspre.Tables[0].Rows[0]["MD_TITLE"].ToString();
                            txtbxtitleofopinion1.Text = dspre.Tables[0].Rows[0]["MD_TITLE2"] == DBNull.Value ? "" : dspre.Tables[0].Rows[0]["MD_TITLE2"].ToString();




                            txtbxrmks.Text = dspre.Tables[0].Rows[0]["MD_RMKS"] == DBNull.Value ? "" : dspre.Tables[0].Rows[0]["MD_RMKS"].ToString();
                            txtbxpropdetails.Text = dspre.Tables[0].Rows[0]["MD_PROP_DET"] == DBNull.Value ? "" : dspre.Tables[0].Rows[0]["MD_PROP_DET"].ToString();


                            txtbxconcl.Text = dspre.Tables[0].Rows[0]["MR_CONCL"] == DBNull.Value ? "" : dspre.Tables[0].Rows[0]["MR_CONCL"].ToString();


                            txtbxnote.Text = dspre.Tables[0].Rows[0]["MR_NOTE"] == DBNull.Value ? "" : dspre.Tables[0].Rows[0]["MR_NOTE"].ToString();

                            txtbxextent.Text = dspre.Tables[0].Rows[0]["MD_EXTENT"] == DBNull.Value ? "" : dspre.Tables[0].Rows[0]["MD_EXTENT"].ToString();
                        }
                        else Session["MODMDID"] = null;

                        gvcbrw.DataSource = dspre.Tables[1];
                        gvcbrw.DataBind();

                        gvschedule.DataSource = dspre.Tables[2];
                        gvschedule.DataBind();

                        gvdocs.DataSource = dspre.Tables[3];
                        gvdocs.DataBind();

                        gvencum.DataSource = dspre.Tables[4];
                        gvencum.DataBind();                        

                        /* MODTD Applicant modification binding */

                    }
                    else Session["MODMDID"] = null;
                }
                else
                {
                    if (Type == "C")
                    {

                        if (dspre.Tables.Count > 0)
                        {
                            gvcbrw.DataSource = dspre.Tables[1];
                            gvcbrw.DataBind();

                        }
                    }
                    else if (Type == "P")
                    {

                        gvschedule.DataSource = dspre.Tables[2];
                        gvschedule.DataBind();

                    }
                    else if (Type == "D")
                    {
                        gvdocs.DataSource = dspre.Tables[3];
                        gvdocs.DataBind();

                    }
                    else if (Type == "E")
                    {
                        gvencum.DataSource = dspre.Tables[4];
                        gvencum.DataBind();
                    }
                    else
                    {
                        if (dspre.Tables[0] != null)
                        {
                            if (dspre.Tables[0].Rows.Count > 0)
                            {
                                Session["MODMDID"] = dspre.Tables[0].Rows[0]["MD_ID"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_ID"].ToString() : null;
                            }
                        }
                    }
                }
                string cbrw = "";
                if (dspre.Tables[1].Rows.Count > 0)
                {
                    if (dspre.Tables[1].Rows[0]["MCB_TITLE"] != DBNull.Value && dspre.Tables[1].Rows[0]["MCB_TITLE"] != "" && dspre.Tables[1].Rows[0]["MCB_TITLE"].ToString() != "")
                    {
                        cbrw = "N";
                    }
                    else { cbrw = "Y"; }

                }
                Session["OLDDATA"] = cbrw;
                if (cbrw == "Y") // for old cases NULL Casess
                {
                    dtcbrw = new DataTable();
                    DataRow dr = null;

                    dtcbrw.Columns.Add(new DataColumn("MCB_NAME", typeof(string)));
                    dtcbrw.Columns.Add(new DataColumn("MCB_FNAME", typeof(string)));
                    dtcbrw.Columns.Add(new DataColumn("MCB_AGE", typeof(string)));
                    dtcbrw.Columns.Add(new DataColumn("MCB_MOTD", typeof(string)));
                    dtcbrw.Columns.Add(new DataColumn("MCB_SLNO", typeof(string)));

                    dr = dtcbrw.NewRow();

                    dr["MCB_NAME"] = string.Empty;
                    dr["MCB_FNAME"] = string.Empty;
                    dr["MCB_AGE"] = string.Empty;
                    dr["MCB_MOTD"] = string.Empty;
                    dr["MCB_SLNO"] = string.Empty;

                    dtcbrw.Rows.Add(dr);

                    dtcbrw.Clear();

                    dr = dtcbrw.NewRow();

                    dr["MCB_NAME"] = dspre.Tables[0].Rows[0]["MD_BR1_NAME"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_BR1_NAME"].ToString() : "";
                    dr["MCB_FNAME"] = dspre.Tables[0].Rows[0]["MD_BR1_FNAME"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_BR1_FNAME"].ToString() : "";
                    dr["MCB_AGE"] = dspre.Tables[0].Rows[0]["MD_BR1_AGE"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_BR1_AGE"].ToString() : "";
                    dr["MCB_MOTD"] = "Y";
                    dr["MCB_SLNO"] = "0";

                    dtcbrw.Rows.Add(dr);
                    for (int br = 0; br < dspre.Tables[1].Rows.Count; br++)
                    {
                        dr = dtcbrw.NewRow();

                        dr["MCB_NAME"] = dspre.Tables[1].Rows[br]["MCB_NAME"] != DBNull.Value ? dspre.Tables[1].Rows[0]["MCB_NAME"].ToString() : "";
                        dr["MCB_FNAME"] = dspre.Tables[1].Rows[br]["MCB_FNAME"] != DBNull.Value ? dspre.Tables[1].Rows[br]["MCB_FNAME"].ToString() : "";
                        dr["MCB_AGE"] = dspre.Tables[1].Rows[br]["MCB_AGE"] != DBNull.Value ? dspre.Tables[1].Rows[br]["MCB_AGE"].ToString() : "";
                        dr["MCB_MOTD"] = dspre.Tables[1].Rows[br]["MCB_MOTD"] != DBNull.Value ? dspre.Tables[1].Rows[br]["MCB_MOTD"].ToString() : "";
                        dr["MCB_SLNO"] = dspre.Tables[1].Rows[br]["MCB_SLNO"] != DBNull.Value ? dspre.Tables[1].Rows[br]["MCB_SLNO"].ToString() : "";

                        dtcbrw.Rows.Add(dr);

                    }

                    gvCO.DataSource = dtcbrw;
                    gvCO.DataBind();
                    if (gvCO.Rows.Count > 0)
                    {
                        foreach (GridViewRow grow in gvCO.Rows)
                        {
                            Label lblcbrwincl = (Label)grow.FindControl("lblcbrwinclude");
                            int index = grow.RowIndex;
                            if (lblcbrwincl.Text == "Y")
                            {
                                (grow.FindControl("chkbxcbrwinclude") as CheckBox).Checked = true;
                            }
                        }
                    }



                }
                else if (cbrw == "N") // for new cases after Applicant Details changes NOT NULL cases
                {
                    gvCO.DataSource = dspre.Tables[1];
                    gvCO.DataBind();

                    if (gvCO.Rows.Count > 0)
                    {
                        foreach (GridViewRow grow in gvCO.Rows)
                        {
                            Label lblcbrwincl = (Label)grow.FindControl("lblcbrwinclude");
                            int index = grow.RowIndex;
                            if (lblcbrwincl.Text == "Y")
                            {
                                (grow.FindControl("chkbxcbrwinclude") as CheckBox).Checked = true;
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
        }
    }
    protected void ddlststage_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlststage.SelectedItem.Text == "Preliminary Opinion")
            {
                Bind_Items("PreOpinion");
            }
            else if (ddlststage.SelectedItem.Text == "Final Opinion")
            {
                Bind_Items("FinalOpinion");
            }
            else if (ddlststage.SelectedItem.Text == "MODTD")
            {
                Bind_Items("MODTD");
            }
            else
            {
                ddlstitms.Items.Clear();
                ddlstitms.Items.Insert(0, new ListItem("--Select--", "--Select--"));
            }
            txtbxleadno.Text = "";

            this.cusdets.Visible = false;
            this.cusdetsh.Visible = false;

            this.propschdetsh.Visible = false;
            this.propschdets.Visible = false;

            this.docsdetsh.Visible = false;
            this.docsdets.Visible = false;

            this.titleopiniondetsh.Visible = false;
            this.titleopiniondets.Visible = false;


            this.propdetsmodtd.Visible = false;
            this.propdetsmodtdh.Visible = false;

            this.ecdetsh.Visible = false;
            this.ecdets.Visible = false;

            this.notedets.Visible = false;
            this.notedetsh.Visible = false;

            this.concldets.Visible = false;
            this.concldetsh.Visible = false;

            this.rmksh.Visible = false;
            this.rmks.Visible = false;


            this.MODTDH.Visible = false;
            this.MODTDDETS.Visible = false;

            this.ownersame.Visible = false;
            this.ownersamedetails.Visible = false;

            this.Township.Visible = false;
            this.Townshipdetails.Visible = false;

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void ddlstitms_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtbxleadno.Text = "";

        this.cusdets.Visible = false;
        this.cusdetsh.Visible = false;

        this.propschdetsh.Visible = false;
        this.propschdets.Visible = false;

        this.docsdetsh.Visible = false;
        this.docsdets.Visible = false;

        this.titleopiniondetsh.Visible = false;
        this.titleopiniondets.Visible = false;


        this.propdetsmodtd.Visible = false;
        this.propdetsmodtdh.Visible = false;

        this.ecdetsh.Visible = false;
        this.ecdets.Visible = false;

        this.notedets.Visible = false;
        this.notedetsh.Visible = false;

        this.concldets.Visible = false;
        this.concldetsh.Visible = false;

        this.rmksh.Visible = false;
        this.rmks.Visible = false;

        this.MODTDH.Visible = false;
        this.MODTDDETS.Visible = false;

        this.ownersame.Visible = false;
        this.ownersamedetails.Visible = false;

        this.Township.Visible = false;
        this.Townshipdetails.Visible = false;
    }

    protected void Bind_Stage()
    {
        string filePath = Server.MapPath("~/XML/Stage.xml");
        using (DataSet ds = new DataSet())
        {
            ds.ReadXml(filePath);
            ddlststage.DataSource = ds;
            ddlststage.DataTextField = "Value";
            ddlststage.DataValueField = "Value";
            ddlststage.DataBind();
            ddlststage.Items.Insert(0, new ListItem("--Select--", "--Select--"));
        }
    }
    protected void Bind_Items(string val)
    {
        string filePath = Server.MapPath("~/XML/" + val + ".xml");
        using (DataSet ds = new DataSet())
        {
            ds.ReadXml(filePath);
            ddlstitms.DataSource = ds;
            ddlstitms.DataTextField = "Value";
            ddlstitms.DataValueField = "Value";
            ddlstitms.DataBind();
            ddlstitms.Items.Insert(0, new ListItem("--Select--", "--Select--"));
        }
    }

    protected void btnaddcbrw_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["MODStatusLGLCBRW"].ToString() == "New")
            {
                if (ddlstcustype.SelectedValue == "A")
                {
                    if (ddlsttitle1.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle1.Focus();
                        uscMsgBox1.AddMessage("please select the applicant title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxname.Text.Trim() == "")
                    {
                        txtbxname.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxage.Text.Trim() == "")
                    {
                        txtbxage.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant age.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstsdf.SelectedItem.Text == "--Select--")
                    {
                        ddlstsdf.Focus();
                        uscMsgBox1.AddMessage("please select the relation type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlsttitle2.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle2.Focus();
                        uscMsgBox1.AddMessage("please select the applicant's relation's title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxSWFof.Text.Trim() == "")
                    {
                        txtbxSWFof.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's relation name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstidtype.SelectedItem.Text == "--Select--")
                    {
                        ddlstidtype.Focus();
                        uscMsgBox1.AddMessage("please select the id type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxidtype.Text.Trim() == "")
                    {
                        txtbxidtype.Focus();
                        uscMsgBox1.AddMessage("please enter the ID number.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxaddr1.Text.Trim() == "")
                    {
                        txtbxaddr1.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's address 1.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxaddr2.Text.Trim() == "")
                    {
                        txtbxaddr2.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's address 2.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxcity.Text.Trim() == "")
                    {
                        txtbxcity.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's city.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxpincode.Text.Trim() == "")
                    {
                        txtbxpincode.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's pincode.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else
                    {
                        Insert_Borrower_Dets();
                    }


                }
                else if (ddlstcustype.SelectedValue == "C")
                {
                    if (ddlsttitle1.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle1.Focus();
                        uscMsgBox1.AddMessage("please select the co-applicant title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxname.Text.Trim() == "")
                    {
                        txtbxname.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxage.Text.Trim() == "")
                    {
                        txtbxage.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant age.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstsdf.SelectedItem.Text == "--Select--")
                    {
                        ddlstsdf.Focus();
                        uscMsgBox1.AddMessage("please select the relation type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlsttitle2.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle2.Focus();
                        uscMsgBox1.AddMessage("please select the co-applicant's relation's title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxSWFof.Text.Trim() == "")
                    {
                        txtbxSWFof.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant's relation name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstidtype.SelectedItem.Text == "--Select--")
                    {
                        ddlstidtype.Focus();
                        uscMsgBox1.AddMessage("please select the id type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxidtype.Text.Trim() == "")
                    {
                        txtbxidtype.Focus();
                        uscMsgBox1.AddMessage("please enter the ID number.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                    else
                    {
                        Insert_Borrower_Dets();
                    }
                }
                else
                {
                    ddlstcustype.Focus();
                    uscMsgBox1.AddMessage("please select the applicant type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

            }
            else if (Session["MODStatusLGLCBRW"].ToString() == "Edit")
            {
                if (ddlstcustype.SelectedValue == "A")
                {
                    if (ddlsttitle1.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle1.Focus();
                        uscMsgBox1.AddMessage("please select the applicant title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxname.Text.Trim() == "")
                    {
                        txtbxname.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxage.Text.Trim() == "")
                    {
                        txtbxage.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant age.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstsdf.SelectedItem.Text == "--Select--")
                    {
                        ddlstsdf.Focus();
                        uscMsgBox1.AddMessage("please select the relation type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlsttitle2.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle2.Focus();
                        uscMsgBox1.AddMessage("please select the applicant's relation's title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxSWFof.Text.Trim() == "")
                    {
                        txtbxSWFof.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's relation name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstidtype.SelectedItem.Text == "--Select--")
                    {
                        ddlstidtype.Focus();
                        uscMsgBox1.AddMessage("please select the id type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxidtype.Text.Trim() == "")
                    {
                        txtbxidtype.Focus();
                        uscMsgBox1.AddMessage("please enter the ID number.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxaddr1.Text.Trim() == "")
                    {
                        txtbxaddr1.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's address 1.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxaddr2.Text.Trim() == "")
                    {
                        txtbxaddr2.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's address 2.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxcity.Text.Trim() == "")
                    {
                        txtbxcity.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's city.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxpincode.Text.Trim() == "")
                    {
                        txtbxpincode.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's pincode.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else
                    {
                        Update_Borrower_Dets();
                    }


                }
                else if (ddlstcustype.SelectedValue == "C")
                {
                    if (ddlsttitle1.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle1.Focus();
                        uscMsgBox1.AddMessage("please select the co-applicant title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxname.Text.Trim() == "")
                    {
                        txtbxname.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxage.Text.Trim() == "")
                    {
                        txtbxage.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant age.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstsdf.SelectedItem.Text == "--Select--")
                    {
                        ddlstsdf.Focus();
                        uscMsgBox1.AddMessage("please select the relation type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlsttitle2.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle2.Focus();
                        uscMsgBox1.AddMessage("please select the co-applicant's relation's title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxSWFof.Text.Trim() == "")
                    {
                        txtbxSWFof.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant's relation name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstidtype.SelectedItem.Text == "--Select--")
                    {
                        ddlstidtype.Focus();
                        uscMsgBox1.AddMessage("please select the id type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxidtype.Text.Trim() == "")
                    {
                        txtbxidtype.Focus();
                        uscMsgBox1.AddMessage("please enter the ID number.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                    else
                    {
                        Update_Borrower_Dets();
                    }
                }

            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

        BindAllGrid("C");



    }
    protected void Insert_Borrower_Dets()
    {

        // process starts
        // NEED TO CHECK THE BORROWER DETAIS HAS MAIN APPLICANT
        if (gvcbrw.Rows.Count <= 0 && ddlstcustype.SelectedValue == "C")
        {
            uscMsgBox1.AddMessage("Please first add main applicant", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

        }
        else if (gvcbrw.Rows.Count > 0 && ddlstcustype.SelectedValue == "A")
        {
            int cnt = 0;
            foreach (GridViewRow rw in gvcbrw.Rows)
            {
                if ((rw.FindControl("lblatpe") as Label).Text == "A")
                {
                    cnt++;
                    break;
                }
            }
            if (cnt > 0)
            {
                uscMsgBox1.AddMessage("You can add only one main applicant...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }

        }
        else if (gvcbrw.Rows.Count > 0)
        {
            int cnt = 0;
            foreach (GridViewRow rw in gvcbrw.Rows)
            {
                if ((rw.FindControl("lblatpe") as Label).Text == "A")
                {
                    cnt++;
                    break;
                }
            }
            if (cnt == 0)
            {
                uscMsgBox1.AddMessage("Please add main applicant...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
            {


                if (Rx.IsMatch(txtbxage.Text.Trim()))
                {

                    if (ddlstcustype.SelectedValue == "A")
                    {
                        if (Rx.IsMatch(txtbxpincode.Text.Trim()))
                        {
                            Insert_Brw_Qry();
                        }
                        else
                        {
                            uscMsgBox1.AddMessage("Please check the pincode, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }
                    }
                    else
                    {
                        Insert_Brw_Qry();
                    }
                    this.adr1.Visible = false;
                    this.adr2.Visible = false;
                }
                else
                {
                    if (!Rx.IsMatch(txtbxage.Text.Trim()))
                    {
                        uscMsgBox1.AddMessage("Please check the age, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (!Rx.IsMatch(txtbxpincode.Text.Trim()))
                    {
                        uscMsgBox1.AddMessage("Please check the pincode, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
                // process ends
            }
        }
    }

    protected void Insert_Brw_Qry()
    {
        //S2
        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {

                if (Session["ID"] != null)
                {
                    id = Convert.ToInt32(Session["ID"].ToString());
                }
                else
                {
                    Response.Redirect("Expire.aspx");
                    return;
                }


            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }


            cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["MODLEADID"].ToString()), connection);
            dtpre = new DataTable();
            dappre = new SqlDataAdapter(cmd);
            dappre.Fill(dtpre);

            Session["MODMDID"] = dtpre.Rows[0]["MD_ID"] != DBNull.Value ? dtpre.Rows[0]["MD_ID"].ToString() : "";



            if (gvcbrw.Rows.Count > 0)
            {
                List<int> cnt = new List<int>();
                cnt.Clear();
                foreach (GridViewRow grow in gvcbrw.Rows)
                {
                    Label lblPSCH = grow.FindControl("lblcbrwslno") as Label;


                    cnt.Add(Convert.ToInt32(lblPSCH.Text));
                }
                cbrwcnt = cnt.Max() + 1;
            }
            else
                cbrwcnt = 1;

            try
            {
                string sql = "INSERT INTO LSD_MOTD_CBRW (MCB_MD_ID,MCB_TYPE,MCB_SLNO,MCB_TITLE,MCB_NAME,MCB_RELATION,MCB_FTITLE,MCB_FNAME,MCB_PF_ID,MCB_PF_NO,MCB_AGE) values" +
                             "(" + Convert.ToInt32(Session["MODMDID"].ToString()) + ",'" + ddlstcustype.SelectedValue.ToString() + "'," + cbrwcnt + ",'" + ddlsttitle1.SelectedValue.ToString() + "','" + txtbxname.Text.Trim().ToUpper() + "','" +
                              ddlstsdf.SelectedValue.ToString() + "','" + ddlsttitle2.SelectedValue.ToString() + "','" + txtbxSWFof.Text.Trim().ToUpper() + "','" + ddlstidtype.SelectedValue + "','" + txtbxidtype.Text.Trim().ToUpper() + "'," + Convert.ToInt32(txtbxage.Text.Trim()) + ")";


                cmd = new SqlCommand(sql, connection);

                int r = cmd.ExecuteNonQuery();

                // NEED TO UPDATE ADDRESS IF MAIN APPLICANT
                if (ddlstcustype.SelectedValue == "A")
                {

                    sql = "UPDATE LSD_MOTD SET MD_BR1_NAME='" + txtbxname.Text.Trim().ToUpper() + "', " +
                        " MD_BR1_FNAME='" + txtbxSWFof.Text.Trim().ToUpper() + "', " +
                        " MD_BR1_AGE='" + txtbxage.Text.Trim() + "', " +
                        " MD_BR_ADD1='" + txtbxaddr1.Text.ToUpper() + "', " +
                        " MD_BR_ADD2='" + txtbxaddr2.Text.ToUpper() + "', " +
                        " MD_BR_ADD3='" + txtbxcity.Text.Trim().ToUpper() + " - " + txtbxpincode.Text.Trim().ToUpper() + "' " +
                        " WHERE MD_LD_ID='" + Convert.ToInt32(Session["MODLEADID"].ToString()) + "' ";

                    cmd = new SqlCommand(sql, connection);
                    r = r + cmd.ExecuteNonQuery();


                }

                if (r > 0)
                {

                    cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Preliminary Opinion','Applicant Details Inserted','" + Session["ID"].ToString() + "',getdate(),null,null)", connection);

                    cmd.ExecuteNonQuery();
                    CLearCBRW();
                    //uscMsgBox1.AddMessage("Please check the age", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else
                {
                    uscMsgBox1.AddMessage("Applicant is  not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmd.Dispose();
            }
        }
        //ends s2
    }
    protected void Update_Borrower_Dets()
    {
        if (Rx.IsMatch(txtbxage.Text.Trim()))
        {

            if (ddlstcustype.SelectedValue == "A")
            {
                if (Rx.IsMatch(txtbxpincode.Text.Trim()))
                {
                    Update_Brw_Qry();
                }
                else
                {
                    uscMsgBox1.AddMessage("Please check the pincode, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
            else
            {
                Update_Brw_Qry();
            }

            this.adr1.Visible = false;
            this.adr2.Visible = false;

        }
        else
        {
            if (!Rx.IsMatch(txtbxage.Text.Trim()))
            {
                uscMsgBox1.AddMessage("Please check the age, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (!Rx.IsMatch(txtbxpincode.Text.Trim()))
            {
                uscMsgBox1.AddMessage("Please check the pincode, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
    }
    protected void Update_Brw_Qry()
    {
        //S1
        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                string sql = "Update  LSD_MOTD_CBRW set MCB_NAME='" + txtbxname.Text.Trim().ToUpper() + "'," +
                                " MCB_FNAME='" + txtbxSWFof.Text.Trim().ToUpper() + "'," +
                                " MCB_AGE=" + Convert.ToInt32(txtbxage.Text.Trim()) + ", " +
                                " MCB_TITLE='" + ddlsttitle1.SelectedValue + "', " +
                                " MCB_FTITLE='" + ddlsttitle2.SelectedValue + "', " +
                                " MCB_RELATION='" + ddlstsdf.SelectedValue + "', " + //MCB_PF_ID MCB_PF_NO
                                " MCB_PF_ID='" + ddlstidtype.SelectedValue + "', " +
                                " MCB_PF_NO='" + txtbxidtype.Text.Trim().ToUpper() + "' " +
                                " Where MCB_SLNO=" + Convert.ToInt32(Session["MODSLNOCBRW"].ToString()) +
                                " and MCB_MD_ID=" + Convert.ToInt32(Session["MODMDID"].ToString());



                cmd = new SqlCommand(sql, connection);

                int r = cmd.ExecuteNonQuery();

                // NEED TO UPDATE ADDRESS IF MAIN APPLICANT
                if (ddlstcustype.SelectedValue == "A")
                {

                    sql = "UPDATE LSD_MOTD SET MD_BR1_NAME='" + txtbxname.Text.Trim().ToUpper() + "', " +
                        " MD_BR1_FNAME='" + txtbxSWFof.Text.Trim().ToUpper() + "', " +
                        " MD_BR1_AGE='" + txtbxage.Text.Trim() + "', " +
                        " MD_BR_ADD1='" + txtbxaddr1.Text.ToUpper() + "', " +
                        " MD_BR_ADD2='" + txtbxaddr2.Text.ToUpper() + "', " +
                        " MD_BR_ADD3='" + txtbxcity.Text.Trim().ToUpper() + " - " + txtbxpincode.Text.Trim() + "' " +
                        " WHERE MD_LD_ID='" + Convert.ToInt32(Session["MODLEADID"].ToString()) + "' ";

                    cmd = new SqlCommand(sql, connection);
                    r = r + cmd.ExecuteNonQuery();


                }
                if (r > 0)
                {
                    cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Preliminary Opinion','Applicant Details Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", connection);

                    cmd.ExecuteNonQuery();
                    CLearCBRW();
                    Session["MODStatusLGLCBRW"] = "New";
                    ddlstcustype.Enabled = true;
                    //uscMsgBox1.AddMessage("Please check the age", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else
                {
                    uscMsgBox1.AddMessage("Applicant not updated...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmd.Dispose();
            }
        }

        //END S1
    }

    protected void gvcbrw_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Delete")
        {

            strValb = e.CommandArgument.ToString();
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();


                try
                {
                    int cnt = 0;
                    string sql = "";
                    string slns = "";
                    if (gvcbrw.Rows.Count > 0)
                    {
                        cnt = 0;
                        foreach (GridViewRow rw in gvcbrw.Rows)
                        {
                            if ((rw.FindControl("lblatpe") as Label).Text == "A")
                            {
                                //cnt++;
                                slns = (rw.FindControl("lblcbrwslno") as Label).Text;

                                break;
                            }
                        }
                        //if (cnt == 0)
                        //{
                        //    uscMsgBox1.AddMessage("Please add main applicant...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        //    return;
                        //}

                    }
                    int r = 0;
                    if (slns != strValb)
                    {
                        sql = "DELETE FROM  LSD_MOTD_CBRW WHERE MCB_MD_ID=" + Convert.ToInt32(Session["MODMDID"].ToString()) + " and MCB_SLNO=" + Convert.ToInt32(strValb);
                        cmd = new SqlCommand(sql, connection);

                        r = cmd.ExecuteNonQuery();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("You can not delete the Main Applicant but you can modify", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        return;
                    }



                    //// NEED TO UPDATE ADDRESS IF MAIN APPLICANT
                    //if (ddlstcustype.SelectedValue == "A")
                    //{

                    //    sql = "UPDATE LSD_MOTD SET MD_BR1_NAME='" + DBNull.Value + "', " +
                    //        " MD_BR1_FNAME='" + DBNull.Value + "', " +
                    //        " MD_BR1_AGE='" + DBNull.Value + "', " +
                    //        " MD_BR_ADD1='" + DBNull.Value + "', " +
                    //        " MD_BR_ADD2='" + DBNull.Value + "', " +
                    //        " MD_BR_ADD3='" + DBNull.Value + "' " +
                    //        " WHERE MD_LD_ID='" + Convert.ToInt32(Session["MODLEADID"].ToString()) + "' ";

                    //    cmd = new SqlCommand(sql, connection);
                    //    r = r + cmd.ExecuteNonQuery();
                    //}



                    if (r > 0)
                    {
                        cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Preliminary Opinion','Applicant Details Deleted','" + Session["ID"].ToString() + "',getdate(),null,null)", connection);

                        cmd.ExecuteNonQuery();

                        BindAllGrid("C");
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Applicant not deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    uscMsgBox1.AddMessage("Please check the entered data", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                finally
                {
                    cmd.Dispose();
                }
            }


        }
        if (e.CommandName == "Edit")
        {
            strValb = e.CommandArgument.ToString();

            Session["MODStatusLGLCBRW"] = "Edit";
            Session["MODSLNOCBRW"] = strValb;
            foreach (GridViewRow grow in gvcbrw.Rows)
            {
                Label lblcbrwsno = grow.FindControl("lblcbrwslno") as Label;
                if (strValb == lblcbrwsno.Text)
                {
                    string[] arrname = (grow.FindControl("lblcbrwname") as Label).Text.Split('.');
                    ddlsttitle1.SelectedValue = arrname[0].ToString() + ". ";
                    txtbxname.Text = arrname[1].ToString().Trim();

                    string[] arrname1 = (grow.FindControl("lblcbrwswf") as Label).Text.Split('.');
                    ddlsttitle2.SelectedValue = arrname1[0].ToString() + ". ";
                    txtbxSWFof.Text = arrname1[1].ToString().Trim();

                    ddlstsdf.SelectedValue = (grow.FindControl("lblrel") as Label).Text;
                    txtbxage.Text = (grow.FindControl("lblcbrwage") as Label).Text;
                    ddlstcustype.SelectedValue = (grow.FindControl("lblatpe") as Label).Text;
                    ddlstcustype.Enabled = false;

                    if (ddlstcustype.SelectedValue == "A")
                    {
                        BindAllGrid("All");
                        this.adr1.Visible = true;
                        this.adr2.Visible = true;
                    }
                    else
                    {
                        txtbxaddr1.Text = "";
                        txtbxaddr2.Text = "";
                        txtbxcity.Text = "";
                        txtbxpincode.Text = "";


                        this.adr1.Visible = false;
                        this.adr2.Visible = false;

                    }

                    ddlstidtype.SelectedValue = (grow.FindControl("lblidtype") as Label).Text;
                    txtbxidtype.Text = (grow.FindControl("lblIDNO") as Label).Text;

                    break;
                }
            }

            btnaddcbrw.Text = "Update";
            BindAllGrid("C");
        }

    }
    protected void gvcbrw_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void gvcbrw_RowEditing(object sender, GridViewEditEventArgs e)
    {
        BindAllGrid("C");
    }
    protected void gvcbrw_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        BindAllGrid("C");
    }
    protected void gvcbrw_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindAllGrid("C");
    }
    protected void Bind_Proof(string PF_PR_ID)
    {


        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                cmd = new SqlCommand("RTS_SP_BIND_MR_PROOF", connection);

                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@TYPE", "ID");

                cmd.Parameters.AddWithValue("@PF_PR_ID", PF_PR_ID);
                cmd.CommandTimeout = 120000;

                dtpre = new DataTable();
                dappre = new SqlDataAdapter(cmd);
                dappre.Fill(dtpre);



                ddlstidtype.Items.Clear();
                ddlstidtype.DataSource = dtpre;
                ddlstidtype.DataTextField = "PF_DESC";
                ddlstidtype.DataValueField = "PF_ID";
                ddlstidtype.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlstidtype.SelectedIndex = 0;
                ddlstidtype.DataBind();

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmd.Dispose();
            }
        }

    }

    //protected void Bind_Proof()
    //{


    //    using (SqlConnection connection = new SqlConnection(strcon))
    //    {
    //        connection.Open();

    //        try
    //        {
    //            cmd = new SqlCommand("RTS_SP_BIND_MR_PROOF", connection);

    //            cmd.CommandType = CommandType.StoredProcedure;


    //            cmd.Parameters.AddWithValue("@TYPE", "ID");
    //            cmd.CommandTimeout = 120000;

    //            dtpre = new DataTable();
    //            dappre = new SqlDataAdapter(cmd);
    //            dappre.Fill(dtpre);

    //            ddlstidtype.DataSource = dtpre;

    //            ddlstidtype.DataTextField = "PF_DESC";
    //            ddlstidtype.DataValueField = "PF_ID";
    //            ddlstidtype.DataBind();
    //            ddlstidtype.Items.Insert(0, new ListItem("--Select--", "0"));
    //            ddlstidtype.SelectedIndex = 0;
    //        }
    //        catch (Exception ex)
    //        {
    //            CreateLogFiles Err = new CreateLogFiles();
    //            Err.ErrorLog(HttpContext.Current.Server.MapPath("~/Logs/ErrorLog"), ex.Message, ex.StackTrace);
    //            Response.Redirect("ErrorPage.aspx?parameter=Legal_Modify.aspx");
    //        }
    //        finally
    //        {
    //            cmd.Dispose();
    //        }
    //    }

    //}

    private void CLearCBRW()
    {
        ddlsttitle1.SelectedValue = "--Select--";
        txtbxname.Text = "";
        txtbxage.Text = "";
        ddlstsdf.SelectedValue = "--Select--";
        ddlstcustype.SelectedValue = "--Select--";


        ddlsttitle2.SelectedValue = "--Select--";
        txtbxSWFof.Text = "";
        if (ddlstidtype.Items.Count > 0)
            ddlstidtype.SelectedIndex = 0;

        txtbxidtype.Text = "";

        txtbxaddr1.Text = "";
        txtbxaddr2.Text = "";
        txtbxcity.Text = "";
        txtbxpincode.Text = "";
        lblrelationname.Text = "Name";
        btnaddcbrw.Text = "Add";

    }

    protected void ddlstsdf_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlstsdf.SelectedItem.Text != "--Select")
        {

            lblrelationname.Text = ddlstsdf.SelectedItem.Text.ToString();
        }
        else

        { lblrelationname.Text = "Name"; }


    }
    protected void ddlstcustype_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlstcustype.SelectedValue == "A")
        {

            if (txtbxaddr1.Text.Trim() != "")
            {
                uscMsgBox1.AddMessage("You can add only one main applicant...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
            else
            {
                this.adr1.Visible = true;
                this.adr2.Visible = true;
            }


        }
        else
        {
            this.adr1.Visible = false;
            this.adr2.Visible = false;
        }

    }

    protected void gvcbrw_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            string name = DataBinder.Eval(e.Row.DataItem, "MCB_TITLE").ToString() + DataBinder.Eval(e.Row.DataItem, "MCB_NAME").ToString();

            (e.Row.FindControl("lblcbrwname") as Label).Text = name;

            string fname = DataBinder.Eval(e.Row.DataItem, "MCB_FTITLE").ToString() + DataBinder.Eval(e.Row.DataItem, "MCB_FNAME").ToString();

            (e.Row.FindControl("lblcbrwswf") as Label).Text = fname;

            string apptype = DataBinder.Eval(e.Row.DataItem, "MCB_TYPE").ToString();
            if (apptype == "A")
            {
                (e.Row.FindControl("lblapptype") as Label).Text = "Main Applicant";
            }
            else
            {
                (e.Row.FindControl("lblapptype") as Label).Text = "Co-Applicant";
            }

        }
    }

    protected void BindPropType()
    {
        string filePath = Server.MapPath("~/XML/PropertyTypeLGLPre.xml");
        using (DataSet ds = new DataSet())
        {
            ds.ReadXml(filePath);
            ddlstproptype.DataSource = ds;
            ddlstproptype.DataTextField = "Property";
            ddlstproptype.DataValueField = "Property";
            ddlstproptype.DataBind();
            ddlstproptype.Items.Insert(0, new ListItem("--Select--", "--Select--"));
        }

    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["MODStatusLGL"].ToString() == "New")
            {

                if (txtbxdocdate.Text.Trim() != "" && txtbxsurvey.Text.Trim() != "--Select--" && txtbxdocs.Text.Trim() != "" && ddlstdoctype.SelectedItem.Text != "--Select--" && ddlstdocCat.SelectedItem.Text != "--Select--" && txtbxdocno.Text.Trim() != "")
                {
                    try
                    {

                        dtd = DateTime.ParseExact(txtbxdocdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
                    }

                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                        uscMsgBox1.AddMessage("Invalid Date format. Please check the date (dd/mm/yyyy)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                        return;
                    }


                    using (SqlConnection connection = new SqlConnection(strcon))
                    {
                        connection.Open();


                        cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["MODLEADID"].ToString()), connection);
                        dtpre = new DataTable();
                        dappre = new SqlDataAdapter(cmd);
                        dappre.Fill(dtpre);

                        Session["MODMDID"] = dtpre.Rows[0]["MD_ID"] != DBNull.Value ? dtpre.Rows[0]["MD_ID"].ToString() : "";



                        if (gvdocs.Rows.Count > 0)
                        {
                            List<int> cnt = new List<int>();
                            cnt.Clear();
                            foreach (GridViewRow grow in gvdocs.Rows)
                            {
                                Label lblPSCH = grow.FindControl("lblslno") as Label;
                                cnt.Add(Convert.ToInt32(lblPSCH.Text));
                            }
                            docscnt = cnt.Max() + 1;

                        }
                        else
                            docscnt = 1;

                        try
                        {

                            string sql = " INSERT INTO LSD_MOTD_DOCX (MDX_MD_ID,MDX_SLNO,MDX_DATE,MDX_DOC,MDX_DOCNO,MDX_SURVEY,MDX_DTYPE,MDX_DT_ID,MDX_RSTAT,MDX_OVSTAT,MDX_BSTAT) values(" + Convert.ToInt32(Session["MODMDID"].ToString()) + "," + docscnt + ",'" + dtd + "','" +
                                          txtbxdocs.Text.Replace("'", "''").ToString() + "','" + txtbxdocno.Text.Replace("'", "''").ToString() + "','" + txtbxsurvey.Text.Replace("'", "''").ToString() + "','" + ddlstdoctype.SelectedItem.Text + "'," + Convert.ToInt32(ddlstdocCat.SelectedValue.ToString()) + ",'Required','" + ddlstdoctype.SelectedItem.Text + "','" + ddlstdoctype.SelectedItem.Text + "')";
                            cmd = new SqlCommand(sql, connection);

                            int r = cmd.ExecuteNonQuery();
                            if (r > 0)
                            {

                                cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Preliminary Opinion','List of Documents Inserted','" + Session["ID"].ToString() + "',getdate(),null,null)", connection);

                                cmd.ExecuteNonQuery();
                                CLear();
                                BindAllGrid("D");

                            }
                            else
                            {
                                uscMsgBox1.AddMessage("Document not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            uscMsgBox1.AddMessage("Document and Survey & Extent input fields should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }
                        finally
                        {
                            cmd.Dispose();
                        }
                    }


                }
                else
                {
                    if (txtbxdocdate.Text == "")
                    {
                        txtbxdocdate.Focus();

                    }
                    else if (ddlstdoctype.SelectedItem.Text == "--Select--")
                    {
                        ddlstdoctype.Focus();
                    }
                    else if (txtbxsurvey.Text == "")
                    {
                        txtbxsurvey.Focus();

                    }
                    else if (txtbxdocs.Text == "")
                    {
                        txtbxdocs.Focus();
                    }
                    else if (ddlstdocCat.SelectedItem.Text == "--Select--")
                    {
                        ddlstdocCat.Focus();
                    }
                    else if (txtbxdocno.Text.Trim() == "")
                    {
                        txtbxdocno.Focus();
                    }
                    uscMsgBox1.AddMessage("Please Give corresponding Inputs for List of Documents", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    BindAllGrid("D");
                }
            }
            else if (Session["MODStatusLGL"].ToString() == "Edit")
            {
                if (txtbxdocdate.Text.Trim() != "" && txtbxsurvey.Text.Trim() != "--Select--" && txtbxdocs.Text.Trim() != "" && ddlstdoctype.SelectedItem.Text != "--Select--" && ddlstdocCat.SelectedItem.Text != "--Select--" && txtbxdocno.Text.Trim() != "")
                {

                    using (SqlConnection connection = new SqlConnection(strcon))
                    {
                        connection.Open();
                        try
                        {

                            dtd = DateTime.ParseExact(txtbxdocdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
                        }

                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            uscMsgBox1.AddMessage("Invalid Date format. Please check the date", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                            return;
                        }


                        try
                        {
                            string sql = "Update  LSD_MOTD_DOCX set " +

                                           " MDX_DATE='" + dtd + "'," +
                                           " MDX_DOC='" + txtbxdocs.Text.Replace("'", "''").ToString() + "'," +
                                           " MDX_DOCNO='" + txtbxdocno.Text.Replace("'", "''").ToString() + "'," +
                                           " MDX_SURVEY='" + txtbxsurvey.Text.Replace("'", "''").ToString() + "'," +
                                           " MDX_DTYPE='" + ddlstdoctype.SelectedItem.Text + "'," +
                                           " MDX_DT_ID=" + Convert.ToInt32(ddlstdocCat.SelectedValue.ToString()) + "," +
                                           " MDX_OVSTAT='" + ddlstdoctype.SelectedItem.Text + "'," +
                                           " MDX_BSTAT='" + ddlstdoctype.SelectedItem.Text + "' " +
                                //   " MDX_RSTAT='" + docxrstat + "'" +
                                            " Where MDX_SLNO =" + Convert.ToInt32(Session["MODSLNO"].ToString()) +
                                            " and MDX_MD_ID=" + Convert.ToInt32(Session["MODMDID"].ToString());



                            cmd = new SqlCommand(sql, connection);

                            int r = cmd.ExecuteNonQuery();
                            if (r > 0)
                            {
                                cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Preliminary Opinion','List of Documents Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", connection);

                                cmd.ExecuteNonQuery();
                                CLear();
                                BindAllGrid("D");
                                Session["MODStatusLGL"] = "New";

                            }
                            else
                            {
                                uscMsgBox1.AddMessage("Document not updated...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            uscMsgBox1.AddMessage("Document and Survey & Extent input fields should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }
                        finally
                        {
                            cmd.Dispose();
                        }
                    }
                }
                else
                {
                    if (txtbxdocdate.Text == "")
                    {
                        txtbxdocdate.Focus();

                    }
                    else if (ddlstdoctype.SelectedItem.Text == "--Select--")
                    {
                        ddlstdoctype.Focus();
                    }
                    else if (txtbxsurvey.Text == "")
                    {
                        txtbxsurvey.Focus();

                    }
                    else if (txtbxdocs.Text == "")
                    {
                        txtbxdocs.Focus();
                    }
                    else if (ddlstdocCat.SelectedItem.Text == "--Select--")
                    {
                        ddlstdocCat.Focus();
                    }
                    else if (txtbxdocno.Text.Trim() == "")
                    {
                        txtbxdocno.Focus();
                    }
                    uscMsgBox1.AddMessage("Please Give corresponding Inputs for List of Documents", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    BindAllGrid("D");
                }

            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    private void CLear()
    {
        txtbxdocdate.Text = "";
        txtbxdocs.Text = "";
        txtbxsurvey.Text = "";
        ddlstdoctype.SelectedIndex = 0;
        ddlstdocCat.SelectedIndex = 0;
        txtbxdocno.Text = "";
        btnadd.Text = "Add";

    }
    protected void gvdocs_RowCommand(object sender, GridViewCommandEventArgs e)
    {



        if (e.CommandName == "Delete")
        {

            strVald = e.CommandArgument.ToString();
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();

                try
                {
                    string sql = "DELETE FROM  LSD_MOTD_DOCX WHERE MDX_MD_ID=" + Convert.ToInt32(Session["MODMDID"].ToString()) + " and MDX_SLNO=" + Convert.ToInt32(strVald);


                    cmd = new SqlCommand(sql, connection);

                    int r = cmd.ExecuteNonQuery();
                    if (r > 0)
                    {
                        cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Preliminary Opinion','List of Documents Deleted','" + Session["ID"].ToString() + "',getdate(),null,null)", connection);

                        cmd.ExecuteNonQuery();
                        BindAllGrid("D");
                        CLear();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Document not deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);

                    return;
                }
                finally
                {
                    cmd.Dispose();
                }
            }


        }
        if (e.CommandName == "Edit")
        {
            strVald = e.CommandArgument.ToString();

            Session["MODStatusLGL"] = "Edit";
            Session["MODSLNO"] = strVald;


            foreach (GridViewRow grow in gvdocs.Rows)
            {
                Label lblPSCH = grow.FindControl("lblslno") as Label;
                if (strVald == lblPSCH.Text)
                {
                    string[] dbarr = (grow.FindControl("lbldate") as Label).Text.Split('-');

                    txtbxdocdate.Text = dbarr[0].ToString() + "/" + dbarr[1].ToString() + "/" + dbarr[2].ToString();
                    txtbxdocs.Text = (grow.FindControl("lbldocs") as Label).Text;
                    txtbxsurvey.Text = (grow.FindControl("lblsurvey") as Label).Text;
                    ddlstdoctype.SelectedValue = (grow.FindControl("lbldoctype") as Label).Text;
                    ddlstdocCat.SelectedValue = (grow.FindControl("lbldoccat") as Label).Text;
                    txtbxdocno.Text = (grow.FindControl("lbldocno") as Label).Text;
                    //

                    docxrstat = (grow.FindControl("lblrstat") as Label).Text;
                    break;
                }
            }

            btnadd.Text = "Update";
            BindAllGrid("D");

        }
    }

    protected void gvdocs_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void ClearALL()
    {


        txtbxleadno.Text = "";

        CLear();
        CLearCBRW();
        ClearSch();


        txtbxextent.Text = "";

        this.leadsel.Visible = false;

        this.leadsel2.Visible = false;


    }
    protected void gvdocs_RowEditing(object sender, GridViewEditEventArgs e)
    {
        BindAllGrid("D");
    }


    protected void gvdocs_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        BindAllGrid("D");
    }
    protected void gvdocs_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindAllGrid("D");
    }

    private void ClearSch()
    {
        txtbxpropschedule.Text = "";
        txtbxnorthby.Text = "";
        txtbxsouthby.Text = "";
        txtbxeastby.Text = "";
        txtbxwestby.Text = "";
        txtbxregoffice.Text = "";
        txtbxregdistrict.Text = "";
        ddlstproptype.SelectedIndex = 0;
        btnscheduleadd.Text = "Add Schedule";
        txtMeasurement.Text = "";
        lstPropOwner.SelectedIndex = -1;
    }
    protected void btnscheduleadd_Click(object sender, EventArgs e)
    {

        try
        {
            if (lstPropOwner.SelectedIndex != -1)
            {
                if (Session["MODStatusLGLSCHEDULE"].ToString() == "New")
                {

                    if (txtbxpropschedule.Text != "" && txtbxnorthby.Text != "" && txtbxsouthby.Text != "" && txtbxwestby.Text != "" && txtbxeastby.Text != "" && ddlstproptype.SelectedItem.Text != "--Select--" && txtbxregoffice.Text != "" && txtbxregdistrict.Text != "" && txtbxextent.Text.Trim() != "")//&& ddlstdocstatus.SelectedItem.Text != "--Select--")
                    {
                        using (SqlConnection connection = new SqlConnection(strcon))
                        {
                            connection.Open();



                            cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["MODLEADID"].ToString()), connection);
                            dtpre = new DataTable();
                            dappre = new SqlDataAdapter(cmd);
                            dappre.Fill(dtpre);

                            Session["MODMDID"] = dtpre.Rows[0]["MD_ID"] != DBNull.Value ? dtpre.Rows[0]["MD_ID"].ToString() : "";



                            if (gvschedule.Rows.Count > 0)
                            {
                                List<int> cnt = new List<int>();
                                cnt.Clear();
                                foreach (GridViewRow grow in gvschedule.Rows)
                                {
                                    Label lblPSCH = grow.FindControl("LBLSNO") as Label;


                                    cnt.Add(Convert.ToInt32(lblPSCH.Text));
                                }
                                propcnt = cnt.Max() + 1;
                            }
                            else
                                propcnt = 1;

                            try
                            {

                                string selectedReference = ",";

                                foreach (ListItem li in lstPropOwner.Items)
                                {
                                    if (li.Selected)
                                    {
                                        selectedReference = selectedReference + li.Value + ",";

                                    }
                                }
                                string regstr = "Situated at within the Sub-Registration District of " + txtbxregoffice.Text.Trim() + " and Registration District of " + txtbxregdistrict.Text.Trim();
                                string sql = "INSERT INTO LSD_MOTD_PROPERTY (MP_MD_ID,MP_SLNO,MP_PTYPE,MP_PROP,MP_NORTH,MP_SOUTH,MP_EAST,MP_WEST,MP_REGISTR,MP_MEASURE,MP_PROP_OWNER) values(" + Convert.ToInt32(Session["MODMDID"].ToString()) + "," + propcnt + ",'" + ddlstproptype.SelectedItem.Text + "','" +
                                              txtbxpropschedule.Text.Replace("'", "''").ToString() + "','" + txtbxnorthby.Text.Trim().Replace("'", "''").ToString() + "','" + txtbxsouthby.Text.Trim().Replace("'", "''").ToString() + "','" + txtbxeastby.Text.Trim().Replace("'", "''").ToString() + "','" + txtbxwestby.Text.Trim().Replace("'", "''").ToString() + "','" + regstr + "','" + txtMeasurement.Text + "','" + selectedReference.Trim().ToString() + "')";


                                cmd = new SqlCommand(sql, connection);
                                int r = cmd.ExecuteNonQuery();

                                cmd = new SqlCommand("Update LSD_MOTD set MD_EXTENT='" + txtbxextent.Text.Trim() + "' where MD_ID='" + Convert.ToInt32(Session["MODMDID"].ToString()) + "'", connection);
                                r = r + cmd.ExecuteNonQuery();
                                if (r > 0)
                                {
                                    cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Preliminary Opinion','Property Schedule Details Inserted','" + Session["ID"].ToString() + "',getdate(),null,null)", connection);

                                    cmd.ExecuteNonQuery();
                                    ClearSch();
                                    BindAllGrid("P");
                                    //uscMsgBox1.AddMessage("Please check the age", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                                }
                                else
                                {
                                    uscMsgBox1.AddMessage("Property Schedule not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                                }

                            }
                            catch (Exception ex)
                            {
                                ErrorLog.WriteError(ex);
                                uscMsgBox1.AddMessage("Properthy Schedule input field should be less than 2000 characters... & Boundary Details and Reg.Office, District input field should be less than 50 characters each...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }
                            finally
                            {
                                cmd.Dispose();
                            }
                        }
                    }
                    else
                    {
                        if (txtbxpropschedule.Text == "")
                        {
                            txtbxpropschedule.Focus();

                        }
                        else if (ddlstproptype.SelectedItem.Text == "--Select--")
                        {
                            ddlstproptype.Focus();
                        }
                        else if (txtbxnorthby.Text == "")
                        {
                            txtbxnorthby.Focus();

                        }
                        else if (txtbxsouthby.Text == "")
                        {
                            txtbxsouthby.Focus();
                        }
                        else if (txtbxeastby.Text == "")
                        {
                            txtbxeastby.Focus();

                        }
                        else if (txtbxwestby.Text == "")
                        {
                            txtbxwestby.Focus();
                        }
                        else if (txtbxregoffice.Text == "")
                        {
                            txtbxregoffice.Focus();
                        }
                        else if (txtbxregdistrict.Text == "")
                        {
                            txtbxregdistrict.Focus();
                        }

                        else if (txtbxextent.Text == "")
                        {
                            txtbxextent.Focus();
                        }
                        uscMsgBox1.AddMessage("Please Give corresponding Inputs for Schedule List", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                    }
                }
                else if (Session["MODStatusLGLSCHEDULE"].ToString() == "Edit")
                {

                    if (txtbxpropschedule.Text != "" && txtbxnorthby.Text != "" && txtbxsouthby.Text != "" && txtbxwestby.Text != "" && txtbxeastby.Text != "" && ddlstproptype.SelectedItem.Text != "--Select--" && txtbxregoffice.Text != "" && txtbxregdistrict.Text != "" && txtbxextent.Text.Trim() != "")//&& ddlstdocstatus.SelectedItem.Text != "--Select--")
                    {
                        using (SqlConnection connection = new SqlConnection(strcon))
                        {
                            connection.Open();


                            try
                            {
                                string selectedReference = ",";

                                foreach (ListItem li in lstPropOwner.Items)
                                {
                                    if (li.Selected)
                                    {
                                        selectedReference = selectedReference + li.Value + ",";

                                    }
                                }
                                string regstr = "Situated at within the Sub-Registration District of " + txtbxregoffice.Text.Trim() + " and Registration District of " + txtbxregdistrict.Text.Trim();


                                string sql = "Update  LSD_MOTD_PROPERTY set " +
                                                        " MP_PTYPE='" + ddlstproptype.SelectedItem.Text + "'," +
                                                        " MP_PROP='" + txtbxpropschedule.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                        " MP_NORTH='" + txtbxnorthby.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                        " MP_SOUTH='" + txtbxsouthby.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                        " MP_EAST='" + txtbxeastby.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                        " MP_WEST='" + txtbxwestby.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                        " MP_REGISTR='" + regstr + "'," +
                                                        "MP_MEASURE='" + txtMeasurement.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                        "MP_PROP_OWNER='" + selectedReference.Trim().ToString() + "'" +
                                               " Where MP_SLNO=" + Convert.ToInt32(Session["MODSLNOSCH"].ToString()) +
                                               " and MP_MD_ID=" + Convert.ToInt32(Session["MODMDID"].ToString());



                                cmd = new SqlCommand(sql, connection);



                                int r = cmd.ExecuteNonQuery();

                                cmd = new SqlCommand("Update LSD_MOTD set MD_EXTENT='" + txtbxextent.Text.Trim() + "' where MD_ID='" + Convert.ToInt32(Session["MODMDID"].ToString()) + "'", connection);
                                r = r + cmd.ExecuteNonQuery();
                                if (r > 0)
                                {

                                    cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Preliminary Opinion','Property Schedule Details Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", connection);

                                    cmd.ExecuteNonQuery();
                                    ClearSch();

                                    BindAllGrid("P");
                                    Session["MODStatusLGLSCHEDULE"] = "New";

                                }
                                else
                                {
                                    uscMsgBox1.AddMessage("Property Details not updated...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                                }

                            }
                            catch (Exception ex)
                            {
                                ErrorLog.WriteError(ex);
                                uscMsgBox1.AddMessage("Properthy Schedule input field should be less than 2000 characters... & Boundary Details and Reg.Office, District input field should be less than 50 characters each...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }
                            finally
                            {
                                cmd.Dispose();
                            }
                        }


                    }
                    else
                    {
                        if (txtbxpropschedule.Text == "")
                        {
                            txtbxpropschedule.Focus();

                        }
                        else if (ddlstproptype.SelectedItem.Text == "--Select--")
                        {
                            ddlstproptype.Focus();
                        }
                        else if (txtbxnorthby.Text == "")
                        {
                            txtbxnorthby.Focus();

                        }
                        else if (txtbxsouthby.Text == "")
                        {
                            txtbxsouthby.Focus();
                        }
                        else if (txtbxeastby.Text == "")
                        {
                            txtbxeastby.Focus();

                        }
                        else if (txtbxwestby.Text == "")
                        {
                            txtbxwestby.Focus();
                        }
                        else if (txtbxregoffice.Text == "")
                        {
                            txtbxregoffice.Focus();
                        }
                        else if (txtbxregdistrict.Text == "")
                        {
                            txtbxregdistrict.Focus();
                        }
                        else if (txtbxextent.Text == "")
                        {
                            txtbxextent.Focus();
                        }
                        uscMsgBox1.AddMessage("Please Give corresponding Inputs for Schedule List", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                    }
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Please Select Property Owner(s)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);


            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void gvschedule_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "Delete")
        {

            strValp = e.CommandArgument.ToString();
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();


                try
                {
                    string sql = "DELETE FROM  LSD_MOTD_PROPERTY WHERE MP_MD_ID=" + Convert.ToInt32(Session["MODMDID"].ToString()) + " and MP_SLNO=" + strValp + "";


                    cmd = new SqlCommand(sql, connection);

                    int r = cmd.ExecuteNonQuery();
                    if (r > 0)
                    {
                        cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Preliminary Opinion','Property Schedule Details Deleted','" + Session["ID"].ToString() + "',getdate(),null,null)", connection);

                        cmd.ExecuteNonQuery();
                        BindAllGrid("P");
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Property Detail not deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);

                    return;
                }
                finally
                {
                    cmd.Dispose();
                }
            }


            ClearSch();

        }
        if (e.CommandName == "Edit")
        {
            strValp = e.CommandArgument.ToString();

            Session["MODStatusLGLSCHEDULE"] = "Edit";
            Session["MODSLNOSCH"] = strValp;
            foreach (GridViewRow grow in gvschedule.Rows)
            {
                Label lblPSCH = grow.FindControl("LBLSNO") as Label;
                Label lblPropOwner = grow.FindControl("lblPropOwner") as Label;
                if (strValp == lblPSCH.Text)
                {

                    txtbxpropschedule.Text = (grow.FindControl("lblsch") as Label).Text;
                    ddlstproptype.SelectedValue = (grow.FindControl("lblptype") as Label).Text;
                    txtbxnorthby.Text = (grow.FindControl("lblnrthby") as Label).Text;
                    txtbxsouthby.Text = (grow.FindControl("lblsthby") as Label).Text;
                    txtbxeastby.Text = (grow.FindControl("lblestby") as Label).Text;
                    txtbxwestby.Text = (grow.FindControl("lblwstby") as Label).Text;
                    txtbxregoffice.Text = (grow.FindControl("lblregoff") as Label).Text;
                    txtbxregdistrict.Text = (grow.FindControl("lblregDST") as Label).Text;
                    txtMeasurement.Text = (grow.FindControl("lblMeasurement") as Label).Text;
                    lblPropOwner.Text = (grow.FindControl("lblPropOwner") as Label).Text;
                    if (lblPropOwner.Text != "" && lblPropOwner.Text!=null)
                    {
                        //trReference.Visible = true;

                        //ddlReference.SelectedValue = Convert.ToInt32(qrypromotion.ReferenceId).ToString();

                        string strReferenceID = lblPropOwner.Text;
                        string[] strRefer = strReferenceID.Split(new char[] { ',' });

                        for (int i = 0; i < strRefer.Length - 1; i++)
                        {
                            ListItem li = lstPropOwner.Items.FindByValue(strRefer[i]);
                            if (li != null)
                            {
                                li.Selected = true;
                            }

                        }

                    }
                    break;
                }
            }

            btnscheduleadd.Text = "Update Schedule";
            BindAllGrid("P");
        }

    }
    protected void gvschedule_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void gvschedule_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindAllGrid("P");
    }
    protected void gvschedule_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        BindAllGrid("P");
    }
    protected void gvschedule_RowEditing(object sender, GridViewEditEventArgs e)
    {
        BindAllGrid("P");
    }
    protected void gvdocs_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string tempdate = DataBinder.Eval(e.Row.DataItem, "MDX_DATE").ToString();
            Label lbdate = (Label)e.Row.FindControl("lbldate");
            string[] dbarr = tempdate.Split('/');
            (e.Row.FindControl("lbldate") as Label).Text = dbarr[1].ToString() + "-" + dbarr[0].ToString() + "-" + dbarr[2].ToString();
        }
    }


    protected void gvschedule_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string tempdate = DataBinder.Eval(e.Row.DataItem, "MP_REGISTR").ToString();
            Label lblrego = (Label)e.Row.FindControl("lblregoff");
            Label lblregd = (Label)e.Row.FindControl("lblregDST");
            Label lblPropertyOwner = (Label)e.Row.FindControl("lblPropOwner");
            Label lblOwnerName = (Label)e.Row.FindControl("lblOwnerName");



            int districtend = Convert.ToInt32(tempdate.IndexOf("and Registration"));
            int len = districtend - 52;
            string district = tempdate.Substring(52, len);



            (e.Row.FindControl("lblregoff") as Label).Text = district;
            (e.Row.FindControl("lblregDST") as Label).Text = tempdate.Substring(districtend + 29);


            e.Row.Cells[0].Attributes.Add("style", "word-break:break-all;word-wrap:break-word;");

            if (lblPropertyOwner.Text != null && lblPropertyOwner.Text != "")
{ 
            string propOwner = "";
            //lblPropertyOwner.Text = ((lblPropertyOwner.Text).TrimEnd(',')).TrimStart(',');

            // string strReferenceID = lblPropertyOwner.Text;
            //string[] strRefer = strReferenceID.Split(new char[] { ',' });

            //foreach (string word in strRefer)
            //{
            //    string powner="";
            //   // Console.WriteLine(word);
            //    if (word!="")
            //    { 
            //    powner = clscommon.GetPropertyOwner(word);
            //      propOwner+=powner;
            //    }
            //}
            propOwner = clscommon.GetPropOwner(lblPropertyOwner.Text);
            // lblOwnerName.Text = propOwner.Replace(',', '\n');


            // string str = "The quick brown fox     jumps over the lazy dog";
            string[] ab = propOwner.Split(' ');
            if (ab != null && ab.Length > 0)
            {
                string de = ab[0].Trim();
                for (int i = 1; i < ab.Length; i++)
                {
                    de += ab[i] + "\n";
                }

                propOwner = de;
            }
            //propOwner = Regex.Replace(propOwner, @"\s+", Environment.NewLine);

            lblOwnerName.Text = propOwner;
            //for (int i = 0; i < strRefer.Length - 1; i++)
            //{
            //    ListItem li = lstPropOwner.Items.FindByValue(strRefer[i]);
            //    if (li != null)
            //    {
            //       // li.Selected = true;
            //        propOwner = clscommon.GetPropertyOwner(strRefer[i]);
            //    }
            //    lblOwnerName.Text = propOwner;
            //}
}
        }
    }
    public void Bind_Doc_Type()
    {


        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                cmd = new SqlCommand("RTS_SP_BIND_LGL_DOC_TYPE", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandTimeout = 120000;
                dtpre = new DataTable();
                dappre = new SqlDataAdapter(cmd);
                dappre.Fill(dtpre);

                ddlstdocCat.DataSource = dtpre;

                ddlstdocCat.DataTextField = "DT_DESC";
                ddlstdocCat.DataValueField = "DT_ID";
                ddlstdocCat.DataBind();
                ddlstdocCat.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlstdocCat.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmd.Dispose();
            }
        }
    }

    protected void btnaddT_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (txtbxtitleofopinion.Text.Length > 2000)
            {
                uscMsgBox1.AddMessage("Title of Opinion should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxtitleofopinion.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the title of opinion", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_TITLE='" + txtbxtitleofopinion.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["MODLEADID"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Final Opinion','Title of Opinion Inserted','" + Session["ID"].ToString() + "',getdate(),null,null)", con);

                cmd.ExecuteNonQuery();
                uscMsgBox1.AddMessage("Title of Opinion updated sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            else
            {
                uscMsgBox1.AddMessage("Title of Opinion not updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }

    }
    protected void btnaddT1_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (txtbxtitleofopinion1.Text.Length > 2000)
            {
                uscMsgBox1.AddMessage("Title of Opinion 2 should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxtitleofopinion1.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the title of opinion 2", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_TITLE2='" + txtbxtitleofopinion1.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["MODLEADID"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Final Opinion','Title of Opinion 2 Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", con);

                cmd.ExecuteNonQuery();
                uscMsgBox1.AddMessage("Title of Opinion 2 updated sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            else
            {
                uscMsgBox1.AddMessage("Title of Opinion 2 not updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }


    }
    protected void btnaddPD_Click(object sender, EventArgs e)
    {


        con = new SqlConnection(strcon);
        try
        {
            if (txtbxpropdetails.Text.Length > 500)
            {
                uscMsgBox1.AddMessage("Property Details should be less than 500 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxpropdetails.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the property details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_PROP_DET='" + txtbxpropdetails.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["MODLEADID"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Final Opinion','Property Details for MODTD Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", con);

                cmd.ExecuteNonQuery();
                uscMsgBox1.AddMessage("Property Details updated sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            else
            {
                uscMsgBox1.AddMessage("Property Details not updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);


            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }


    }

    protected void btnaddec_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["MODStatusLGLEC"].ToString() == "New")
            {

                if (txtbxecdate.Text != "" && txtbxecdocs.Text != "")
                {
                    try
                    {

                        dtd = DateTime.ParseExact(txtbxecdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
                    }

                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                        uscMsgBox1.AddMessage("Invalid Date format. Please check the date (dd/mm/yyyy)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                        return;
                    }


                    using (SqlConnection connection = new SqlConnection(strcon))
                    {
                        connection.Open();

                        if (gvencum.Rows.Count > 0)
                        {
                            List<int> cnt = new List<int>();
                            cnt.Clear();
                            foreach (GridViewRow grow in gvencum.Rows)
                            {
                                Label lblPSCH = grow.FindControl("lblecslno") as Label;
                                cnt.Add(Convert.ToInt32(lblPSCH.Text));
                            }
                            eccnt = cnt.Max() + 1;

                        }
                        else
                            eccnt = 1;

                        try
                        {
                            string sql = "INSERT INTO LSD_MOTD_EC (MEC_MD_ID,MEC_SLNO,MEC_DATE,MEC_DOC) values(" + Convert.ToInt32(Session["MODMDID"].ToString()) + "," + eccnt + ",'" + dtd + "','" +
                                          txtbxecdocs.Text + "')";


                            cmd = new SqlCommand(sql, connection);

                            int r = cmd.ExecuteNonQuery();
                            if (r > 0)
                            {
                                cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Final Opinion','EC Details Inserted','" + Session["ID"].ToString() + "',getdate(),null,null)", connection);

                                cmd.ExecuteNonQuery();
                                Clear();
                                BindAllGrid("E");
                                //uscMsgBox1.AddMessage("Please check the age", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);


                            }
                            else
                            {
                                uscMsgBox1.AddMessage("EC not updated...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            uscMsgBox1.AddMessage("EC Document input field should be less than 200 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }
                        finally
                        {
                            cmd.Dispose();
                        }
                    }


                }
                else
                {
                    if (txtbxecdate.Text == "")
                    {
                        txtbxecdate.Focus();

                    }

                    else if (txtbxecdocs.Text == "")
                    {
                        txtbxecdocs.Focus();
                    }

                    uscMsgBox1.AddMessage("Please Give corresponding Inputs for Encumbrance Certificate / Search Report", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                }
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }


    }

    public void Clear()
    {
        txtbxecdocs.Text = "";
        txtbxecdate.Text = "";
    }


    protected void gvencum_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void gvencum_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "Delete")
        {

            strVale = e.CommandArgument.ToString();
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();

                try
                {
                    string sql = "DELETE FROM  LSD_MOTD_EC WHERE MEC_MD_ID=" + Convert.ToInt32(Session["MODMDID"].ToString()) + " and MEC_SLNO=" + Convert.ToInt32(strVale);


                    cmd = new SqlCommand(sql, connection);

                    int r = cmd.ExecuteNonQuery();
                    if (r > 0)
                    {
                        cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Final Opinion','EC Details Deleted','" + Session["ID"].ToString() + "',getdate(),null,null)", connection);

                        cmd.ExecuteNonQuery();
                        BindAllGrid("E");
                        Clear();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("EC not deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }
                finally
                {
                    cmd.Dispose();
                }
            }

        }


    }
    private void BindListofDocuments()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("RTS_SP_FetchMODTDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LD_ID", Convert.ToInt32(Session["MODLEADID"].ToString()));
            cmd.CommandTimeout = 60000;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);

            txtbxtitleofopinion.Text = ds.Tables[0].Rows[0]["MD_TITLE"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_TITLE"].ToString();
            txtbxtitleofopinion1.Text = ds.Tables[0].Rows[0]["MD_TITLE2"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_TITLE2"].ToString();




            txtbxrmks.Text = ds.Tables[0].Rows[0]["MD_RMKS"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_RMKS"].ToString();
            txtbxpropdetails.Text = ds.Tables[0].Rows[0]["MD_PROP_DET"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_PROP_DET"].ToString();


            txtbxconcl.Text = ds.Tables[0].Rows[0]["MR_CONCL"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MR_CONCL"].ToString();


            txtbxnote.Text = ds.Tables[0].Rows[0]["MR_NOTE"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MR_NOTE"].ToString();


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }

    }
    protected void gvencum_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string tempdate = DataBinder.Eval(e.Row.DataItem, "MEC_DATE").ToString();
            Label lbdate = (Label)e.Row.FindControl("lblmecdt");
            string[] dbarr = tempdate.Split('/');
            (e.Row.FindControl("lblmecdt") as Label).Text = dbarr[1].ToString() + "-" + dbarr[0].ToString() + "-" + dbarr[2].ToString();
        }
    }
    protected void gvencum_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnaddrmks_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (txtbxrmks.Text.Length > 500)
            {
                uscMsgBox1.AddMessage("Remarks should be less than 500 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxrmks.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the Remarks", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_RMKS='" + txtbxrmks.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["MODLEADID"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Final Opinion','Remarks Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", con);

                cmd.ExecuteNonQuery();
                uscMsgBox1.AddMessage("Remarks updated sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            else
            {
                uscMsgBox1.AddMessage("Remarks not updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);


            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }

    }
    protected void btnaddnote_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (txtbxnote.Text.Length > 500)
            {
                uscMsgBox1.AddMessage("Note should be less than 500 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxnote.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the Note", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MR_NOTE='" + txtbxnote.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["MODLEADID"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Final Opinion','Note Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", con);

                cmd.ExecuteNonQuery();
                uscMsgBox1.AddMessage("Note updated sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            else
            {
                uscMsgBox1.AddMessage("Note not updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);


            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }

    }
    protected void btnaddconcl_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (txtbxconcl.Text.Length > 1000)
            {
                uscMsgBox1.AddMessage("Conclusion should be less than 1000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxconcl.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the conclusion", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MR_CONCL='" + txtbxconcl.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["MODLEADID"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Final Opinion','Conclusion Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", con);

                cmd.ExecuteNonQuery();
                uscMsgBox1.AddMessage("Conclusion updated sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            else
            {
                uscMsgBox1.AddMessage("Conclusion not updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);


            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }
    }
    protected void btnmodtdupdate_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            int rs = 0;
            foreach (GridViewRow gr in gvCO.Rows)
            {

                CheckBox chkStat = gr.FindControl("chkbxcbrwinclude") as CheckBox;
                Label SNO = gr.FindControl("lblsno") as Label;
                if (chkStat.Checked)
                {
                    if (SNO.Text != "0")
                    {
                        cmd = new SqlCommand("UPDATE LSD_MOTD_CBRW SET MCB_MOTD ='Y' WHERE MCB_SLNO='" + SNO.Text + "' AND MCB_MD_ID=" + Session["MODMDID"].ToString(), con);
                        cmd.CommandTimeout = 12000;
                        rs = rs + cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    if (SNO.Text != "0")
                    {
                        cmd = new SqlCommand("UPDATE LSD_MOTD_CBRW SET MCB_MOTD ='N' WHERE MCB_SLNO='" + SNO.Text + "' AND MCB_MD_ID=" + Session["MODMDID"].ToString(), con);
                        cmd.CommandTimeout = 12000;
                        rs = rs + cmd.ExecuteNonQuery();
                    }

                }

            }


            /* MODTD Table Loan Amount Updation */
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_LOAN_AMT=A.LD_SANTD_AMT FROM LSD_LEAD A WHERE A.LD_ID='" + Session["MODLEADID"].ToString() + "' AND MD_LD_ID='" + Session["MODLEADID"].ToString() + "'", con);
            cmd.CommandTimeout = 12000;
            cmd.ExecuteNonQuery();

            cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','MODTD Loan Amount','Loan Amount Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", con);
            cmd.CommandTimeout = 12000;
            cmd.ExecuteNonQuery();

            if (rs == gvCO.Rows.Count - 1 && Session["OLDDATA"].ToString() == "Y")
            {
                cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','MODTD Application Details','Applicants Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", con);
                cmd.CommandTimeout = 12000;
                cmd.ExecuteNonQuery();
                uscMsgBox1.AddMessage("MODTD Application details updated sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            else if (rs == gvCO.Rows.Count && Session["OLDDATA"].ToString() == "N")
            {
                cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','MODTD Application Details','Applicants Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", con);
                cmd.CommandTimeout = 12000;
                cmd.ExecuteNonQuery();
                uscMsgBox1.AddMessage("MODTD Application details updated sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            else
            {
                uscMsgBox1.AddMessage("MODTD Application details not updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);


            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }
    }

    protected void ddlapplicantsame_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlapplicantsame.SelectedItem.Text == "No")
            {
                this.appladd.Visible = true;
            }
            else
            {
                this.appladd.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnownerupdate_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (ddlapplicantsame.SelectedIndex == 0)
            {
                uscMsgBox1.AddMessage("Please Select Property Owner is same as Applicant", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            if (ddlapplicantsame.SelectedItem.Text == "No" && txtapladdress.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter Applicant Details with Address", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
            {
                con.Open();
                cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_SM_APPLCNT='" + ddlapplicantsame.SelectedItem.Value + "',MD_APPL_ADDRS='" + txtapladdress.Text + "' WHERE MD_LD_ID='" + Session["MODLEADID"].ToString() + "' ", con);
                cmd.CommandTimeout = 12000;
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Final Opinion','Property Owner is same as Applicant Updated','" + Session["ID"].ToString() + "',getdate(),null,null)", con);

                    cmd.ExecuteNonQuery();
                    uscMsgBox1.AddMessage("Property Owner is same as Applicant updated sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
                else
                {
                    uscMsgBox1.AddMessage("Property Owner is same as Applicant not updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }
    }

    protected void btntownship_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (txtTownship.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter The Township.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
            {
                con.Open();
                cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_TOWN_SHP='" + txtTownship.Text + "' WHERE MD_LD_ID='" + Session["MODLEADID"].ToString() + "' ", con);
                cmd.CommandTimeout = 12000;
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    cmd = new SqlCommand("insert into LSD_LOG VALUES('" + Session["MODLEADID"].ToString() + "','Legal Final Opinion','Township','" + Session["ID"].ToString() + "',getdate(),null,null)", con);

                    cmd.ExecuteNonQuery();
                    uscMsgBox1.AddMessage("Township updated sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
                else
                {
                    uscMsgBox1.AddMessage("Township not updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }
    }
}