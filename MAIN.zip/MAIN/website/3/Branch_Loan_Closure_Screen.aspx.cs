﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Utilities;
using Tracker;

public partial class Branch_Loan_Closure_Screen : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    int ldid;
    double Apprvamt;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string bcc3;
    ClsCommon clscommon = new ClsCommon();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    DataSet dss = new DataSet();
    DataSet dsDisb = new DataSet();
    public static bool blMailStatus = false;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    string fileName = string.Empty;
    string fileExt = string.Empty;
    string fileUploadPath = string.Empty;
    public int SessionEMP_ID
    {
        get
        {
            int employee_id = -1;

            if (Session["EMP_ID"] != null)
            {
                if (Session["EMP_ID"] != "")
                {
                    employee_id = Convert.ToInt32(Session["EMP_ID"]);

                }
            }

            return employee_id;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnSubmit);

        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {

                txtdate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
                bindClosure();

            }
            else
            {
                Response.Redirect("expire.aspx");
            }
        }
    }

    public void bind()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            SqlCommand cmdrsn = new SqlCommand("RTS_SP_Fetch_MR_REASON", con);
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);

            con.Close();
            ddlArea.DataSource = dsdd;
            ddlArea.DataTextField = "AR_NAME";
            ddlArea.DataValueField = "AR_ID";
            ddlArea.DataBind();
            ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    public void bindClosure()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_CLOSURE_TYPE", con);
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            con.Close();
            ddlClosureType.DataSource = dsdd;
            ddlClosureType.DataTextField = "CLS_TYPE_DESC";
            ddlClosureType.DataValueField = "CLS_TYPE_ID";
            ddlClosureType.DataBind();
            ddlClosureType.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_ReceiveDoc", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LeadNo", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@ReceiveType", "CLR_BR");
            if (ddlArea.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@LD_AR_ID", ddlArea.SelectedValue.ToString());
            }

            if (ddlBranch.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@LD_BR_ID", ddlBranch.SelectedValue.ToString());
            }



            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvApprv.Visible = true;
                gvApprv.DataSource = ds1.Tables[0];
                gvApprv.DataBind();
                /* if (ds1.Tables[0].Rows.Count > 0)
                 {
                     gvApprv.HeaderRow.Font.Bold = true;
                     gvApprv.HeaderRow.Cells[1].Text = "LEAD NO";
                     gvApprv.HeaderRow.Cells[2].Text = "LEAD DATE";
                     gvApprv.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                     gvApprv.HeaderRow.Cells[4].Text = "PD DATE";
                     gvApprv.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                     gvApprv.HeaderRow.Cells[1].Wrap = false;
                     gvApprv.HeaderRow.Cells[2].Wrap = false;
                     gvApprv.HeaderRow.Cells[3].Wrap = false;
                     gvApprv.HeaderRow.Cells[4].Wrap = false;
                     gvApprv.HeaderRow.Cells[5].Wrap = false;
                 }*/
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvApprv.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            clearCreditMemoDatas();

            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "All";
                // gridbindall();
            }
            else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                ddlArea.Enabled = false;
                //   gridbind();
            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";
                // gridbind();
            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                // gridbind();
            }
            BindqueryGrid();
            foreach (GridViewRow grow in gvApprv.Rows)
            {
                Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                int index = grow.RowIndex;
                if (lblQryResult.Text == "T")
                {
                    gvApprv.Rows[index].Cells[1].ForeColor = Color.Red;
                    gvApprv.Rows[index].Cells[2].ForeColor = Color.Red;
                    gvApprv.Rows[index].Cells[3].ForeColor = Color.Red;
                    gvApprv.Rows[index].Cells[4].ForeColor = Color.Red;
                    gvApprv.Rows[index].Cells[5].ForeColor = Color.Red;
                }

            }
            //tbSubmit.Visible = false;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }


    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            clearCreditMemoDatas();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            Label lblLeadID = null;
            //Label lblLglAprvl = null;

            foreach (GridViewRow grow in gvApprv.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                bool blStatus = true;
                //LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                int index = grow.RowIndex;
                if (chkStat.Checked==true)
                {

                    lblLeadID = (Label)gvApprv.Rows[index].Cells[1].FindControl("lblLeadID");
                    //lblLglAprvl = (Label)gvApprv.Rows[index].Cells[1].FindControl("lblLgAprvl");
                    leadno = gvApprv.Rows[index].Cells[1].Text;
                    appname = gvApprv.Rows[index].Cells[3].Text;
                    pddt = gvApprv.Rows[index].Cells[4].Text;
                    // lnamt = gvApprv.Rows[index].Cells[5].Text;
                    //rcvquery = gvApprv.Rows[index].Cells[6].Text;
                    Session["LeadId"] = lblLeadID.Text;
                    Session["Leadno"] = leadno;
                    Session["Loanamt"] = pddt;
                    Session["Appname"] = appname;

                    // fillCreditApprvMemo(lblLeadID.Text, con);
                    //if (blStatus)
                    //{




                    trClosureType.Visible = true;

                    lbLeadno.Visible = true;
                    lbAppname.Visible = true;
                    lbPDdate.Visible = true;
                    lbLoanamt.Visible = true;

                    //txtQuery.Enabled = true;
                    btnSubmit.Enabled = true;
                    btnCancel.Enabled = true;


                    lbLeadno.Text = leadno.ToString();
                    lbAppname.Text = appname;
                    lbPDdate.Text = pddt;
                    // lbLoanamt.Text = lnamt;
                    //}
                    if (blStatus == false)
                    {
                        //btnSubmit.Enabled = true;
                        uscMsgBox1.AddMessage("Legal Approval pending", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }


                }





            }

            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }



    public void clearCreditMemoDatas()
    {


        clearTWLCreditMemoDatas();

    }
    public void clearTWLCreditMemoDatas()
    {


    }


    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Credit_ApprovalPopup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
    }

    protected void clear()
    {
        BindqueryGrid();
        lbLeadno.Text = "";
        lbAppname.Text = "";
        lbPDdate.Text = "";
        lbLoanamt.Text = "";

        btnSubmit.Enabled = false;
        btnCancel.Enabled = false;

        clearCreditMemoDatas();
    }








    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlClosureType.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please select the closure type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
                if (fup_Challon.HasFile == false && ddlClosureType.SelectedValue=="1")
            {
                uscMsgBox1.AddMessage("Please select any one of the file to upload in bank challan", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
                    if (fup_Challon.HasFile == true && fup_Challon.PostedFile.ContentLength > 512000 && ddlClosureType.SelectedValue == "1")
            {
                uscMsgBox1.AddMessage("The file size should be 500kb or less", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
                if (fup_MblRecpt.HasFile == false && ddlClosureType.SelectedValue=="1")
            {
                uscMsgBox1.AddMessage("Please select any one of the file to upload in mobile receipt", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
                    if (fup_MblRecpt.HasFile == true && fup_MblRecpt.PostedFile.ContentLength > 512000 && ddlClosureType.SelectedValue == "1")
            {
                uscMsgBox1.AddMessage("The file size should be 500kb or less", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
                if (fup_DeathCert.HasFile == false && ddlClosureType.SelectedValue=="2")
            {
                uscMsgBox1.AddMessage("Please select any one of the file to upload in death certificate", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
                    if (fup_DeathCert.HasFile == true &&  fup_DeathCert.PostedFile.ContentLength > 512000 && ddlClosureType.SelectedValue == "2")
            {
                uscMsgBox1.AddMessage("The file size should be 500kb or less", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
            if (fup_SOA.HasFile == false)
            {
                uscMsgBox1.AddMessage("Please select any one of the file to upload in SOA", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
                if (fup_SOA.HasFile == true && fup_SOA.PostedFile.ContentLength > 512000)
            {
                uscMsgBox1.AddMessage("The SOA file size should be 500kb or less", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
            if (string.IsNullOrWhiteSpace(txtClsrAmount.Text))
            {
                uscMsgBox1.AddMessage("Please enter the closure amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }
            else
            {
                if (ddlClosureType.SelectedValue == "1")
                {
                    //Bank Challan
                    fileExt = Path.GetExtension(fup_Challon.PostedFile.FileName);
                    fileName = AppConstants.FileNamePrefix_BankChallan + Session["leadno"].ToString() + fileExt;
                    fileUploadPath = ConfigurationManager.AppSettings[AppConstants.FileUploadPath] + AppConstants.Directory_Closure + fileName;
                    fup_Challon.SaveAs(Server.MapPath(fileUploadPath));

                    //Mbl Receipt
                    fileExt = Path.GetExtension(fup_MblRecpt.PostedFile.FileName);
                    fileName = AppConstants.FileNamePrefix_MBL_Receipt + Session["leadno"].ToString() + fileExt;
                    fileUploadPath = ConfigurationManager.AppSettings[AppConstants.FileUploadPath] + AppConstants.Directory_Closure + fileName;
                    fup_MblRecpt.SaveAs(Server.MapPath(fileUploadPath));
                }

                if (ddlClosureType.SelectedValue == "2")
                {
                    //Death Certificate
                    fileExt = Path.GetExtension(fup_DeathCert.PostedFile.FileName);
                    fileName = AppConstants.FileNamePrefix_Death_Certificate + Session["leadno"].ToString() + fileExt;
                    fileUploadPath = ConfigurationManager.AppSettings[AppConstants.FileUploadPath] + AppConstants.Directory_Closure + fileName;
                    fup_DeathCert.SaveAs(Server.MapPath(fileUploadPath));
                }

                //SOA
                fileExt = Path.GetExtension(fup_SOA.PostedFile.FileName);
                fileName = AppConstants.FileNamePreficx_SOA + Session["leadno"].ToString() + fileExt;
                fileUploadPath = ConfigurationManager.AppSettings[AppConstants.FileUploadPath] + AppConstants.Directory_Closure + fileName;
                fup_SOA.SaveAs(Server.MapPath(fileUploadPath));

                using (SqlConnection conSub = new SqlConnection(strcon))
                {
                    using (SqlCommand command = new SqlCommand("RTS_SP_Update_MODT_DOc_Values", conSub))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        conSub.Open();
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@TranStatus", "CLS_BR");
                        command.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                        command.Parameters.AddWithValue("@MD_LD_ID", Session["LeadId"].ToString());
                        command.Parameters.AddWithValue("@MD_CLSR_TYPE_ID", ddlClosureType.SelectedIndex > 0 ? ddlClosureType.SelectedValue.ToString() : "");
                        command.Parameters.AddWithValue("@MD_CLSR_POD_NO", txtPODNumber.Text);
                        command.Parameters.AddWithValue("@MD_CLSR_AMT", txtClsrAmount.Text);
                        command.ExecuteNonQuery();
                        sendMail(conSub);
                        //  sendFIRCUMail(Convert.ToInt32(Convert.ToInt32(Session["DSA_FIRCU_ID"].ToString())),Convert.ToInt32( Session["DSA_ID"].ToString()));
                        uscMsgBox1.AddMessage("Closure data has been updated successfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

                        BindqueryGrid();
                        // trInitiation.Visible = false;
                        lbLeadno.Visible = false;
                        lbAppname.Visible = false;
                        lbPDdate.Visible = false;
                        lbLoanamt.Visible = false;
                        trClosureType.Visible = false;
                        trDeathCert.Visible = false;
                        trPreclosure.Visible = false;
                        trSOA.Visible = false;
                        txtClsrAmount.Text = "";
                    }
                }



            }





        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }


    }
    public void sendMail(SqlConnection con)
    {
        try
        {
            /////// mail ///////////
            //  strMailDetail = "";


            DataSet dsmailto = new DataSet();
            dsmailto = clscommon.Bind_FETCH_MR_EMAIL(Session["leadno"].ToString());
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_HO_CLS"].ToString();
                //Bala changes 17/07/2017 cc = dsmailto.Tables[0].Rows[0]["EM_AM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() : "";
                cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() + ";" + dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
                cc = cc.Replace("\n", "");
                bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
                bcc3 = dsmailto.Tables[0].Rows[0]["EM_CLM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_CLM"].ToString() : "";
            }
            if (bcc3 != "")
            {
                cc = cc + ";" + bcc3;
            }


            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }



            fromID = "RTS Alerts";
            toID = to;

            bcc2ID = bcc2;
            ccID = cc;

            // To Auto mail ///////
            //System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{

            String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/>" + ddlClosureType.SelectedItem.Text + " request for captioned file <br/><br/>";
            BodyTxt = BodyTxt + "<table width='90%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='center' >Branch</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center'>Area</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center'>Division</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center'>Loan Number</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center'>Customer Name</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' >Loan Date</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' >Loan Amount</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center'>Closure Type</td></span></tr>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='center'>" + dsmailto.Tables[0].Rows[0]["BR_NAME"].ToString() + "</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' >" + dsmailto.Tables[0].Rows[0]["AR_NAME"].ToString() + "</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' >" + dsmailto.Tables[0].Rows[0]["DV_NAME"].ToString() + "</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' >"+ dsmailto.Tables[0].Rows[0]["LD_LOAN_NO"].ToString() +"</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center'>" + dsmailto.Tables[0].Rows[0]["LD_APNAME"].ToString() + "</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' >" + dsmailto.Tables[0].Rows[0]["LD_LOAN_DATE"].ToString() + "</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' >" + dsmailto.Tables[0].Rows[0]["LD_LOAN_AMT"].ToString() + "</td>";
            BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' >"+ddlClosureType.SelectedItem.Text+"</td></span></tr></table><br/>";

            BodyTxt = BodyTxt + "<table><tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>" + dsmailto.Tables[0].Rows[0]["BR_NAME"].ToString() + " Branch</td></tr>";
            BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
            //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

            blMailStatus = EmailManager.sendemail(to, "RTS Alerts", bcc2, cc, "Request for "+ ddlClosureType.SelectedItem.Text +" - " + Session["leadno"].ToString() + " - " + dsmailto.Tables[0].Rows[0]["LD_APNAME"].ToString() + " - " + dsmailto.Tables[0].Rows[0]["AR_NAME"].ToString() + "- " + dsmailto.Tables[0].Rows[0]["BR_NAME"].ToString() + "", BodyTxt, "", true);


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_Loan_Closure_Screen.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //txtLeadno.Enabled = false;
    }
    protected void ddlApprv_SelectedIndexChanged(object sender, EventArgs e)
    {

    }


    protected void gvApprv_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    RadioButton rb_select = gvApprv.FindControl("rb_select") as RadioButton;
        //    if (rb_select.Checked==true)
        //    {
        //       e.Row.BackColor = System.Drawing.Color.Red;
        //        //e.Row.Attributes["style"] = "background-color: #28b779";
        //    }
        //}

    }
    protected void ddlClosureType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if(ddlClosureType.SelectedValue=="1")
            {
                trPreclosure.Visible = true;
                trDeathCert.Visible = false;
                trSOA.Visible = true;
            }
            else
                if (ddlClosureType.SelectedValue == "2")
            {
                trPreclosure.Visible = false;
                trDeathCert.Visible = true;
                trSOA.Visible = true;
            }
            else
            {

                trPreclosure.Visible = false;
                trDeathCert.Visible = false;
                trSOA.Visible = false;

            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}