﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Change_Password : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {  
            string strPreviousPage = "";
            if (Request.UrlReferrer != null)
            {
                strPreviousPage = Request.UrlReferrer.Segments[Request.UrlReferrer.Segments.Length - 1];
            }
            if (strPreviousPage == "")
            {
                Response.Redirect("~/Default.aspx");
            }
        }
    }
    protected void bt_change_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        DataSet ds = new DataSet();
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT A.EMP_CODE,B.USR_PWD,A.EMP_NAME,C.ET_DESC,B.USR_LLOGIN,B.USR_EMP_ID,B.USR_UTP_ID FROM MR_EMPLOYEE A JOIN MR_USER B ON A.EMP_ID=B.USR_EMP_ID JOIN MR_EMP_TYPE C ON A.EMP_ET_ID=C.ET_ID WHERE EMP_CODE='" + Session["USR_ID"] + "' AND USR_PWD='" + txt_old_pwd.Text + "'", con);
        SqlDataAdapter showdata = new SqlDataAdapter(cmd);
        showdata.Fill(ds);
        con.Close();
        
        if (ds.Tables[0].Rows.Count != 0)
        {
            //Session["ID"] = ds.Tables[0].Rows[0]["USR_EMP_ID"];

            if (txt_new_pwd.Text != "" && txt_con_pwd.Text != "")
            {

                if (txt_old_pwd.Text == ds.Tables[0].Rows[0]["USR_PWD"].ToString() || txt_new_pwd.Text != "" || txt_con_pwd.Text != "")
                {

                    
                    con.Open();
                    //cmd = new SqlCommand("UPDATE MR_USER SET USR_PWDM = GETDATE() ,USR_MBY = '" + ds.Tables[0].Rows[0]["USR_EMP_ID"].ToString() + "' ,USR_MDATE=GETDATE() , USR_PWD = '" + txt_new_pwd.Text + "' where USR_EMP_ID = '" + Session["ID"].ToString() + "' and USR_PWD = '" + txt_old_pwd.Text + "' ", con);
                    //Bala changes 05/03/2018 cmd = new SqlCommand("UPDATE MR_USER SET USR_PWDM = GETDATE() ,USR_MBY = '" + Session["ID"].ToString() + "' ,USR_MDATE=GETDATE() , USR_PWD = '" + txt_new_pwd.Text + "' where USR_ID = '" + Session["ID"].ToString() + "' and USR_PWD = '" + txt_old_pwd.Text + "' ", con);
                    cmd = new SqlCommand("UPDATE MR_USER SET USR_PWDM = GETDATE() , USR_PWD = '" + txt_new_pwd.Text + "' where USR_ID = '" + Session["ID"].ToString() + "' and USR_PWD = '" + txt_old_pwd.Text + "' ", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    
                    Session["USR_ID"] = ds.Tables[0].Rows[0]["EMP_CODE"];
                    Session["User"] = ds.Tables[0].Rows[0]["EMP_NAME"].ToString();
                    Session["Lastlogin"] = ds.Tables[0].Rows[0]["USR_LLOGIN"];
                    Session["USR_DESG"] = ds.Tables[0].Rows[0]["ET_DESC"].ToString();
                    Session["CP_USR_UTP_ID"] = ds.Tables[0].Rows[0]["USR_UTP_ID"].ToString();

                    //Session["Pro"] = ds.Tables[0].Rows[0]["PRDT_ACCS"].ToString();
                    //Response.Redirect("Default.aspx");
                    string[] strDatasourceArr = strcon.Split(';');
                    string strDSource = strDatasourceArr[0].ToString();

                    if (strDSource.Contains("172.16.2.95"))
                    {
                        //lblServeryType.Text = " - UAT";
                        ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('Password Changed Successfully, You will be redirect to RTS login');window.location.href('http://172.16.2.95/rts/Default.aspx')", true);
                    }
                    else if (strDSource.Contains("172.18.3.192"))
                    {
                        //lblServeryType.Text = " - DEV";
                        ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('Password Changed Successfully, You will be redirect to RTS login');window.location.href('http://172.18.3.192/rts/Default.aspx')", true);
                    }
                    else
                    {
                        if (Session["CP_USR_UTP_ID"].ToString() == "2")
                        {
                            ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('Password Changed Successfully, You will be redirect to RTS login');window.location.href('http://rts.equitasbank.com/rts/Default.aspx')", true);
                        }
                        else
                        {
                            ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('Password Changed Successfully, You will be redirect to RTS login');window.location.href('http://rts.equitasbank.com/rts/Default.aspx')", true);
                        }
                    }
                }
            }
        }
        else
        {
            ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('Enter the Correct old Password');", true);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txt_old_pwd.Text = "";
        txt_new_pwd.Text = "";
        txt_con_pwd.Text = "";
            
    }
}