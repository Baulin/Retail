﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Drawing;
using Tracker;

public partial class DM_Query_MIS_Report : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnSubmit);
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string Ld_No = "";
            string Sanc_No = "";
            if (ddlDM_query.SelectedValue == "0")
            {
                Sanc_No = txtbxleadno.Text;
            }
            else
            {
                Ld_No = txtbxleadno.Text;
            }

            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_DMCApprvList_Report", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", "");
            cmd.Parameters.AddWithValue("@LD_NO", Ld_No);
            cmd.Parameters.AddWithValue("@AR_NAME", "");
            cmd.Parameters.AddWithValue("@BR_NAME", "");
            cmd.Parameters.AddWithValue("@USERTYPE", "");
            cmd.Parameters.AddWithValue("@PRODUCT", "");
            cmd.Parameters.AddWithValue("@SANC_NO", Sanc_No);
            SqlDataAdapter showdata = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            showdata.Fill(ds);
            if (ds.Tables[0] != null)
            {
                StringWriter tw = new StringWriter();
                GridView dgGrid = new GridView();
                dgGrid.DataSource = ds;
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=DM_Query_MIS_Report.xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                dgGrid.AllowPaging = false;
                dgGrid.DataBind();

                DataGrid dg = new DataGrid();
                dg.DataSource = ds;
                dg.DataBind();
                dgGrid.BorderColor = Color.FromArgb(211, 211, 211);

                dgGrid.RenderControl(hw);
                string year = DateTime.Now.AddYears(0).ToString("yyyy");
                string headerTable = @"<Table><tr><th colspan=3 align=left><font face=Calibri size=13 color=#974807>DM Query MIS Report </font></th></tr></Table>";
                Response.Write(headerTable);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            con.Close();
        }
         catch(Exception ex)
{
    ErrorLog.WriteError(ex);
}
    }
   
}