﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class HOOPs_BC_Receive_Application : System.Web.UI.Page
{
    int ldid, s;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    ClsCommon clscommon = new ClsCommon();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            bind();
            gridbindall();

        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("select AR_NAME from MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_NAME";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      /*  if (Session["View"].ToString() == "F")
        {
            SqlConnection con = new SqlConnection(strcon);
            try
            {
                con.Open();
                s = 0;
                foreach (GridViewRow grow in gvRcvfile.Rows)
                {
                    CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                    int index = grow.RowIndex;
                    if (chkStat.Checked)
                    {
                        s += 1;
                        SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + gvRcvfile.Rows[index].Cells[1].Text + "'", con);
                        SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
                        DataSet dsbr = new DataSet();
                        dabr.Fill(dsbr);
                        ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);

                        SqlCommand cmdft = new SqlCommand("SELECT FT_ID FROM LSD_FILE_TRANS where FT_LD_ID='" + ldid + "' AND ISNULL(FT_RDATE,'')='' AND FT_SENTTO='H' AND (FT_SENTBY='C' OR FT_SENTBY='B') ", con);
                        SqlDataAdapter daft = new SqlDataAdapter(cmdft);
                        DataSet dsft = new DataSet();
                        daft.Fill(dsft);
                        ftid = Convert.ToInt32(dsft.Tables[0].Rows[0]["FT_ID"]);

                        SqlCommand cmdupdate = new SqlCommand("update LSD_FILE_TRANS set FT_RDATE=getdate(),FT_MBY='" + Session["ID"].ToString() + "',FT_MDATE=getdate() where FT_ID='" + ftid + "'", con);
                        cmdupdate.ExecuteNonQuery();
                        if (gvRcvfile.Rows[index].Cells[1].Text.Contains("TWL"))
                        {
                            SqlCommand cmdInsert = new SqlCommand("INSERT INTO LSD_DISB_FILE_TRANS   (FT_SENTBY,FT_LD_ID,FT_SDATE,FT_RDATE,FT_SENTTO,FT_CBY,FT_CDATE,FT_MBY,FT_MDATE)    VALUES( 'D'," + ldid + ",GETDATE(),GETDATE(),'H'," + Session["ID"].ToString() + ",GETDATE()," + Session["ID"].ToString() + ",GETDATE())", con);

                            cmdInsert.ExecuteNonQuery();
                        }

                    }
                }
                gridbind();
                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
                ddlArea.Enabled = true;
                ddlBranch.Enabled = true;
                txtLeadno.Enabled = true;
                btnSubmit.Enabled = false;
                uscMsgBox1.AddMessage(s + " File/s Received Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            catch (Exception ex)
            {
                uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            finally
            {
                con.Close();
            }
        }
        else if (Session["View"].ToString() == "A")
        {
            SqlConnection con = new SqlConnection(strcon);
            try
            {
                con.Open();
                s = 0;
                foreach (GridViewRow grow in gvRcvfile.Rows)
                {
                    CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                    int index = grow.RowIndex;
                    if (chkStat.Checked)
                    {
                        s += 1;
                        SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + gvRcvfile.Rows[index].Cells[1].Text + "'", con);
                        SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
                        DataSet dsbr = new DataSet();
                        dabr.Fill(dsbr);
                        ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);

                        SqlCommand cmdft = new SqlCommand("SELECT FT_ID FROM LSD_FILE_TRANS where FT_LD_ID='" + ldid + "' AND ISNULL(FT_RDATE,'')='' AND FT_SENTTO='H' AND FT_SENTBY='C'", con);
                        SqlDataAdapter daft = new SqlDataAdapter(cmdft);
                        DataSet dsft = new DataSet();
                        daft.Fill(dsft);
                        ftid = Convert.ToInt32(dsft.Tables[0].Rows[0]["FT_ID"]);

                        SqlCommand cmdupdate = new SqlCommand("update LSD_FILE_TRANS set FT_RDATE=getdate(),FT_MBY='" + Session["ID"].ToString() + "',FT_MDATE=getdate() where FT_ID='" + ftid + "'", con);
                        cmdupdate.ExecuteNonQuery();
                    }
                }
                gridbindall();
                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
                ddlArea.Enabled = true;
                ddlBranch.Enabled = true;
                txtLeadno.Enabled = true;
                btnSubmit.Enabled = false;
                uscMsgBox1.AddMessage(s + " File/s Received Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
            catch (Exception ex)
            {
                uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            finally
            {
                con.Close();
            }
        }*/
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HOOps_ReceiveFile.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
       /* if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "A";
            gridbindall();
        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";

            gridbind();
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";
            gridbind();
        }
        else if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select Area and Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (ddlBranch.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please Select Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txtLeadno.Text == "")
        {
            uscMsgBox1.AddMessage("Please Enter Lead No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }*/
    }
    public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            //con.Open();
            //SqlCommand cmd = new SqlCommand("select LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME' from LSD_LEAD A JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE (FT_SENTBY='C'  OR FT_SENTBY='B') AND FT_SENTTO='H' AND isnull(FT_RDATE,'')='' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') AND ISNULL(LD_LC_DATE,'')=''", con);
            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //DataSet ds1 = new DataSet();
            //da.Fill(ds1);
            DataSet ds1 = new DataSet();
            ds1 = clscommon.Get_BC_Form_Details_BY_Application_Status("Shortlisted");
            gvRcvfile.DataSource = ds1;
            gvRcvfile.DataBind();
           
          
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind()
    {

       /* SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT',BR_NAME 'BRANCH NAME' from LSD_LEAD A JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID  JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE (FT_SENTBY='C'  OR FT_SENTBY='B') AND FT_SENTTO='H' AND isnull(FT_RDATE,'')='' AND LD_NO='" + txtLeadno.Text + "' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') OR (FT_SENTBY='C'  OR FT_SENTBY='B' ) AND FT_SENTTO='H' AND isnull(FT_RDATE,'')='' AND AR_NAME='" + ddlArea.SelectedValue.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedValue.ToString() + "' AND FT_LD_ID IN (SELECT FT_LD_ID FROM LSD_FILE_TRANS WHERE ISNULL(FT_RDATE,'')='') and isnull(LD_LC_DATE,'')=''", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvRcvfile.DataSource = ds.Tables[0];
            gvRcvfile.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvRcvfile.HeaderRow.Font.Bold = true;
                gvRcvfile.HeaderRow.Cells[1].Text = "LEAD NO";
                gvRcvfile.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvRcvfile.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvRcvfile.HeaderRow.Cells[4].Text = "PD DATE";
                gvRcvfile.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvRcvfile.HeaderRow.Cells[6].Text = "BRANCH NAME";

                gvRcvfile.HeaderRow.Cells[1].Wrap = false;
                gvRcvfile.HeaderRow.Cells[2].Wrap = false;
                gvRcvfile.HeaderRow.Cells[3].Wrap = false;
                gvRcvfile.HeaderRow.Cells[4].Wrap = false;
                gvRcvfile.HeaderRow.Cells[5].Wrap = false;
                gvRcvfile.HeaderRow.Cells[6].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
        * */
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        //if (ds.Tables[0].Rows.Count > 0)
        //{
        //    //Assumes the Price column is at index 4
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //        e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
        //    e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
        //    e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
        //    e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
        //    e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
        //    e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        //}
    }
    
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedValue.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_NAME";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;

    }
}