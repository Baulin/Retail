﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using Tracker;
using Utilities.Enums;

public partial class HFSanctionLetter : System.Web.UI.Page
{
    #region VARIABLES

    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    SqlCommand cmd = new SqlCommand();
    DataSet ds = new DataSet();
    ReportDocument rpt = new ReportDocument();
    int mdid;
    int id;
    string sancno;
    string leadno;
    string appname;
    string product;
    string lnamt;
    string brnch;
    string mps_id = "";
    string sa;
    int ldid;
    DateTime dt = DateTime.Now;

    #endregion VARIABLES

    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnPrint);

        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                bind();
                this.sanc.Visible = false;
                this.sanc1.Visible = false;
                this.tr_lang.Visible = false;
            }
            else
            {
                Response.Redirect("Expire.aspx");
            }
        }
    }

    protected void gvlead_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvlead.PageIndex = e.NewPageIndex;
        BindqueryGrid();
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("select BR_NAME,BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_ID='" + ddlArea.SelectedValue.ToString() + "'", con);
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

            ddlBranch.DataSource = dsrsn;
            ddlBranch.DataTextField = "BR_NAME";
            ddlBranch.DataValueField = "BR_ID";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlBranch.Enabled = true;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void GenerateBLSMESanctionLetter()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            ds = new DataSet();

            SqlCommand mycomm = new SqlCommand("SANC_LETR_SME", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@PrpslNo", SqlDbType.VarChar).Value = txtSanctionno.Text;
            mycomm.CommandTimeout = 180000;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            showdata.Fill(ds);

            if (ds.Tables[0].Rows.Count == 0)
            {
                uscMsgBox1.AddMessage("Invalid Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
            {
                #region ENGLISH

                if (ddlst_language.SelectedItem.Text == "English")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_EN_BL.rpt"));
                    SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                    rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());
                    rpt.SetParameterValue(5, txtSanctionno.Text);
                    rpt.SetParameterValue(6, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(7, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(8, Session["User"].ToString());
                    rpt.SetParameterValue(9, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region TAMIL

                else if (ddlst_language.SelectedItem.Text == "Tamil")
                {
                    rpt = new ReportDocument();
                    SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                    rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Tamil_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region HINDI

                else if (ddlst_language.SelectedItem.Text == "Hindi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Hindi.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Hindi_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region GUJARATHI

                else if (ddlst_language.SelectedItem.Text == "Gujarathi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Gujarathi.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Gujarathi_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region MARATHI

                else if (ddlst_language.SelectedItem.Text == "Marathi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Marathi.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Marathi_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            rpt.Close();
            rpt.Dispose();
            rpt = null;
            GC.Collect();
        }
    }

    public void bind()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            con.Close();

            ddlArea.DataSource = dsdd;
            ddlArea.DataTextField = "AR_NAME";
            ddlArea.DataValueField = "AR_ID";
            ddlArea.DataBind();
            ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

            if (Session["USR_ACS"].ToString() == "7")
            {
                ddlArea.SelectedValue = Session["AREA_ID"].ToString();
            }

            bindBranch();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));

        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }

    protected void btnPrint_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["Product"].ToString() == "IB-MFHF"
                || Session["Product"].ToString() == "Housing - IB - MFHF")
            {
                GenerateHFSanctionLetter();
            }
            else if (Session["Product"].ToString() == "IB-M-LAP"
                    || Session["Product"].ToString() == "SME"
                    || Session["Product"].ToString() == "IB-SME-RETAIL"
                    || Session["Product"].ToString() == "IB-ASL"
                    || Session["Product"].ToString() == "IB-ADFL"
                    || Session["Product"].ToString() == "Pre Topup"
                    || Session["Product"].ToString() == "Pre Topup-AL"
                    || Session["Product"].ToString() == EnumUtils.GetEnumValue(Assessed_Product_Program.ATMA_VISHWAS_2020_MLAP_Pre_Topup)
                    || Session["Product"].ToString() == EnumUtils.GetEnumValue(Assessed_Product_Program.ATMA_VISHWAS_2020_ASL_Pre_Topup)
                    || Session["Product"].ToString() == EnumUtils.GetEnumValue(Assessed_Product_Program.ATMA_VISHWAS_2020_BL_Assessed_Pre_Topup)
                    || Session["Product"].ToString() == EnumUtils.GetEnumValue(Assessed_Product_Program.ATMA_VISHWAS_2020_GLAP_Pre_Topup)
                    || Session["Product"].ToString() == EnumUtils.GetEnumValue(Declared_Product_Program.ATMA_VISHWAS_2020_BL_Declared_Pre_Topup))
            {
                GenerateSMESanctionLetter();
            }
            else if (Session["Product"].ToString() == "EMP-LAP"
                    || Session["Product"].ToString() == "IB-SME-Secured-R"
                    || Session["Product"].ToString() == "IB-SME-Secured-D"
                    || Session["Product"].ToString() == "IB-SME-UnSecured"
                    || Session["Product"].ToString() == "Pre Topup-SME Secured R")
            {
                GenerateSMESanctionLetter();
            }
            else if (Session["Product"].ToString() == "IB-LiveStock")
            {
                GenerateLiveStockSanctionLetter();
            }
            else if (Session["Product"].ToString() == "IB-G-LAP")
            {
                GenerateGLAPSanctionLetter();
            }
            else if (Session["Product"].ToString() == "IB-G-HF"
                || Session["Product"].ToString() == "IB-Affordable Home"
                || Session["Product"].ToString() == EnumUtils.GetEnumValue(Declared_Product_Program.IB_Mainstream_LAP)
                || Session["Product"].ToString() == "Salaried LAP"
                || Session["Product"].ToString() == "Housing-IB-AHF"
                || Session["Product"].ToString() == "Housing-IB-G-HF"
                || Session["Product"].ToString() == "CP Purchase-Declared"
                || Session["Product"].ToString() == EnumUtils.GetEnumValue(Declared_Product_Program.ATMA_VISHWAS_2020_Salaried_LAP_Pre_Topup))
            {
                GenerateGHFSanctionLetter();
            }
            else if (Session["Product"].ToString() == "EMP-HF"
                    || Session["Product"].ToString() == "Housing-IB-EMP-HF")
            {
                GenerateHFSanctionLetter();
            }
            else if (Session["Product"].ToString() == "BB Housing"
                    || Session["Product"].ToString() == "BB LAP")
            {
                GenerateBBSanctionLetter();
            }
            else
            {
                GenerateBLSMESanctionLetter();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void Page_UnLoad(object sender, EventArgs e)
    {
        if (rpt != null)
        {
            rpt.Close();
            rpt.Dispose();
            rpt = null;
        }

        GC.Collect();
    }

    public void GenerateHFSanctionLetter()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            ds = new DataSet();
            SqlCommand mycomm = new SqlCommand("RTS_SP_MITC", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@SANCPROCNO", SqlDbType.VarChar).Value = txtSanctionno.Text;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            mycomm.CommandTimeout = 180000;
            showdata.Fill(ds);

            if (ds.Tables[0].Rows.Count == 0)
            {
                uscMsgBox1.AddMessage("Invalid Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
            {
                try
                {
                    DataView dtview = ds.Tables[0].AsDataView();
                    dtview.RowFilter = "PRODUCT='MF'";

                    #region ENGLISH

                    if (ddlst_language.SelectedItem.Text == "English")
                    {
                        if (dtview.ToTable().Rows.Count > 0)
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_MF_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text + "");
                        }
                        else
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_For_" + txtSanctionno.Text + "");
                        }
                    }

                    #endregion

                    #region TAMIL

                    else if (ddlst_language.SelectedItem.Text == "Tamil")
                    {
                        if (dtview.ToTable().Rows.Count > 0)
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_Tamil_MF_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Tamil_For_" + txtSanctionno.Text + "");
                        }
                        else
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction Letter For " + txtSanctionno.Text + "");
                        }
                    }

                    #endregion

                    #region HINDI

                    else if (ddlst_language.SelectedItem.Text == "Hindi")
                    {
                        if (dtview.ToTable().Rows.Count > 0)
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_Hindi_MF_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Hindi_For_" + txtSanctionno.Text + "");
                        }
                        else
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction Letter For " + txtSanctionno.Text + "");
                        }
                    }

                    #endregion

                    #region GUJARATHI

                    else if (ddlst_language.SelectedItem.Text == "Gujarathi")
                    {
                        if (dtview.ToTable().Rows.Count > 0)
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_Gujarathi_MF_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Gujarathi_For_" + txtSanctionno.Text + "");
                        }
                        else
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction Letter For " + txtSanctionno.Text + "");
                        }
                    }

                    #endregion

                    #region MARATHI

                    else if (ddlst_language.SelectedItem.Text == "Marathi")
                    {
                        if (dtview.ToTable().Rows.Count > 0)
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_Marathi_MF_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Marathi_For_" + txtSanctionno.Text + "");
                        }
                        else
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction Letter For " + txtSanctionno.Text + "");
                        }
                    }

                    #endregion
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }
                finally
                {

                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void GenerateSMESanctionLetter()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            ds = new DataSet();
            SqlCommand mycomm = new SqlCommand("SANC_LETR_SME", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@PrpslNo", SqlDbType.VarChar).Value = txtSanctionno.Text;
            mycomm.CommandTimeout = 180000;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            showdata.Fill(ds);

            if (ds.Tables[0].Rows.Count == 0)
            {
                uscMsgBox1.AddMessage("Invalid Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else if (ds.Tables[0].Rows[0]["PRIMARY COLLATERAL"].ToString() == ""
                && Session["Product"].ToString() != "IB-SME-RETAIL"
                && Session["Product"].ToString() == "IB-SME-Secured-D"
                && Session["Product"].ToString() == "IB-SME-UnSecured")
            {
                uscMsgBox1.AddMessage("Please Enter PRIMARY COLLATERAL in UNO for this Proposal", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }
            else
            {
                #region ENGLISH

                if (ddlst_language.SelectedItem.Text == "English")
                {
                    rpt = new ReportDocument();

                    if (Session["MPS_ID"].ToString() == "35"
                        || Session["Product"].ToString() == "Pre Topup"
                        || Session["Product"].ToString() == "Pre Topup-AL"
                        || Session["Product"].ToString() == "Pre Topup-SME Secured R")
                    {
                        rpt.Load(Server.MapPath("Reports/SMESL_EN_PR_APL.rpt"));
                    }
                    else if (Session["Product"].ToString() == EnumUtils.GetEnumValue(Assessed_Product_Program.ATMA_VISHWAS_2020_MLAP_Pre_Topup)
                            || Session["Product"].ToString() == EnumUtils.GetEnumValue(Assessed_Product_Program.ATMA_VISHWAS_2020_ASL_Pre_Topup)
                            || Session["Product"].ToString() == EnumUtils.GetEnumValue(Assessed_Product_Program.ATMA_VISHWAS_2020_BL_Assessed_Pre_Topup)
                            || Session["Product"].ToString() == EnumUtils.GetEnumValue(Assessed_Product_Program.ATMA_VISHWAS_2020_GLAP_Pre_Topup)
                            || Session["Product"].ToString() == EnumUtils.GetEnumValue(Declared_Product_Program.ATMA_VISHWAS_2020_BL_Declared_Pre_Topup))
                    {
                        rpt.Load(Server.MapPath("Reports/SMESL_ATMA_VISHWAS_EN_PR_APL.rpt"));
                    }
                    else
                    {
                        rpt.Load(Server.MapPath("Reports/SMESL_EN.rpt"));
                    }

                    SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                    rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());
                    rpt.SetParameterValue(5, txtSanctionno.Text);
                    rpt.SetParameterValue(6, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(7, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(8, Session["User"].ToString());
                    rpt.SetParameterValue(9, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region TAMIL

                else if (ddlst_language.SelectedItem.Text == "Tamil")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Tamil.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Tamil_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region HINDI

                else if (ddlst_language.SelectedItem.Text == "Hindi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Hindi.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Hindi_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region GUJARATHI

                else if (ddlst_language.SelectedItem.Text == "Gujarathi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Gujarathi.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Gujarathi_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region MARATHI

                else if (ddlst_language.SelectedItem.Text == "Marathi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Marathi.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Marathi_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            rpt.Close();
            rpt.Dispose();
            rpt = null;
            GC.Collect();
        }
    }

    public void GenerateLiveStockSanctionLetter()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            ds = new DataSet();

            SqlCommand mycomm = new SqlCommand("SANC_LETR_SME", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@PrpslNo", SqlDbType.VarChar).Value = txtSanctionno.Text;
            mycomm.CommandTimeout = 180000;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);

            showdata.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                uscMsgBox1.AddMessage("Invalid Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else if (ds.Tables[0].Rows[0]["PRIMARY COLLATERAL"].ToString() == "" && Session["Product"].ToString() != "IB-SME-RETAIL")
            {
                uscMsgBox1.AddMessage("Please Enter PRIMARY COLLATERAL in UNO for this Proposal", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }
            else
            {
                #region ENGLISH

                if (ddlst_language.SelectedItem.Text == "English")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_EN_LStock.rpt"));
                    SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                    rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());
                    rpt.SetParameterValue(5, txtSanctionno.Text);
                    rpt.SetParameterValue(6, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(7, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(8, Session["User"].ToString());
                    rpt.SetParameterValue(9, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region TAMIL

                else if (ddlst_language.SelectedItem.Text == "Tamil")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Tamil.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Tamil_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region HINDI

                else if (ddlst_language.SelectedItem.Text == "Hindi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Hindi.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Hindi_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region GUJARATHI

                else if (ddlst_language.SelectedItem.Text == "Gujarathi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Gujarathi.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Gujarathi_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion

                #region MARATHI

                else if (ddlst_language.SelectedItem.Text == "Marathi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Marathi.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Marathi_For_" + txtSanctionno.Text.Trim().ToUpper());
                }

                #endregion
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            rpt.Close();
            rpt.Dispose();
            rpt = null;
            GC.Collect();
        }
    }

    protected void rdnHF_CheckedChanged(object sender, EventArgs e)
    {
        if (rdnHF.Checked == true)
        {
            tblCondition.Visible = false;
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
        }
    }

    protected void rdnSME_CheckedChanged(object sender, EventArgs e)
    {
        if (rdnSME.Checked == true)
        {
            tblCondition.Visible = true;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HFSanctionLetter.aspx");
    }

    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);

        try
        {
            string strBranchID = "";

            if (Session["TYPEID"].ToString() == "2")
            {
                strBranchID = Session["BRANCHID"] != null ? Session["BRANCHID"].ToString() : "";
            }
            else
            {
                strBranchID = ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "";
            }

            gvlead.Visible = true;

            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_FetchSanction_Datas", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@BranchID", strBranchID);
            cmd.Parameters.AddWithValue("@LEAD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_ID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@SANCNO", txtSancNo.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);

            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvlead.DataSource = ds1.Tables[0];
                gvlead.DataBind();

                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvlead.HeaderRow.Font.Bold = true;
                    gvlead.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvlead.HeaderRow.Cells[2].Text = "APPLICANT NAME";
                    gvlead.HeaderRow.Cells[3].Text = "PRODUCT";
                    gvlead.HeaderRow.Cells[4].Text = "BRANCH";
                    gvlead.HeaderRow.Cells[5].Text = "SANCTION NO";

                    gvlead.HeaderRow.Cells[1].Wrap = false;
                    gvlead.HeaderRow.Cells[2].Wrap = false;
                    gvlead.HeaderRow.Cells[3].Wrap = false;
                    gvlead.HeaderRow.Cells[4].Wrap = false;
                    gvlead.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            foreach (GridViewRow grow in gvlead.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                Label lblldid = grow.FindControl("lblLeadID") as Label;
                sancno = (grow.FindControl("lblsanc") as Label).Text;
                ldid = Convert.ToInt32(lblldid.Text);

                int index = grow.RowIndex;

                if (chkStat.Checked)
                {
                    Session["LD_ID"] = ldid;

                    leadno = gvlead.Rows[index].Cells[1].Text;
                    appname = gvlead.Rows[index].Cells[2].Text;
                    product = gvlead.Rows[index].Cells[3].Text;
                    brnch = gvlead.Rows[index].Cells[4].Text;
                    Label lbl_MPS_ID = (Label)grow.FindControl("lbl_MPS_ID");
                    txtSanctionno.Text = sancno;
                    this.sanc.Visible = false;
                    this.sanc1.Visible = false;
                    Session["Product"] = product;
                    Session["LD_NO"] = leadno;
                    Session["MPS_ID"] = lbl_MPS_ID.Text.Trim();

                    cmd = new SqlCommand("SELECT * FROM LSD_CAM_MEMO  where CM_LD_ID=" + Convert.ToInt32(Session["LD_ID"].ToString()), con);
                    cmd.CommandTimeout = 180000;

                    SqlDataAdapter dadd = new SqlDataAdapter(cmd);
                    ds = new DataSet();
                    dadd.Fill(ds);

                    if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    {
                        Session["CreditCondition"] = ds.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? ds.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "";
                    }
                    else
                    {
                        Session["CreditCondition"] = "";
                    }

                    if (Session["Product"].ToString() == "IB-MFHF")
                    {
                        tblCondition.Visible = false;
                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        TextBox3.Text = "";
                        TextBox4.Text = "";
                        TextBox5.Text = "";
                    }
                    else
                    {
                        tblCondition.Visible = false;
                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        TextBox3.Text = "";
                        TextBox4.Text = "";
                        TextBox5.Text = "";
                    }

                    this.tr_lang.Visible = true;
                    btnPrint.Enabled = true;
                    break;
                }
            }

            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void BindAllFields()
    {
        SqlConnection con = new SqlConnection(strcon);

        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_FETCH_MOTD", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LD_ID", Session["LD_ID"].ToString());

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);

            if (ds1.Tables[0].Rows[0][0].ToString() == "1")
            {
                txtSanctionno.Text = ds1.Tables[1].Rows[0]["MD_SANTD_NO"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_SANTD_NO"].ToString();
            }
            else if (ds1.Tables[0].Rows[0][0].ToString() == "2")
            {
                txtSanctionno.Text = ds1.Tables[2].Rows[0]["PRPSLNO"] == DBNull.Value ? "" : ds1.Tables[2].Rows[0]["PRPSLNO"].ToString();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    public void GenerateGLAPSanctionLetter()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            ds = new DataSet();

            SqlCommand mycomm = new SqlCommand("SANC_LETR_SME", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@PrpslNo", SqlDbType.VarChar).Value = txtSanctionno.Text;
            mycomm.CommandTimeout = 180000;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);

            showdata.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                uscMsgBox1.AddMessage("Invalid Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else if (ds.Tables[0].Rows[0]["PRIMARY COLLATERAL"].ToString() == "")
            {
                uscMsgBox1.AddMessage("Please Enter PRIMARY COLLATERAL in UNO for this Proposal", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }
            else
            {
                #region ENGLISH

                if (ddlst_language.SelectedItem.Text == "English")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_EN_GLP.rpt"));
                    SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                    rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());
                    rpt.SetParameterValue(5, txtSanctionno.Text);
                    rpt.SetParameterValue(6, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(7, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(8, Session["User"].ToString());
                    rpt.SetParameterValue(9, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text);
                }

                #endregion

                #region TAMIL

                else if (ddlst_language.SelectedItem.Text == "Tamil")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Tamil_GLP.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Tamil_For_" + txtSanctionno.Text);
                }

                #endregion

                #region HINDI

                else if (ddlst_language.SelectedItem.Text == "Hindi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Hindi_GLP.rpt"));
                    SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                    rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Hindi_For_" + txtSanctionno.Text);
                }

                #endregion

                #region GUJARATHI

                else if (ddlst_language.SelectedItem.Text == "Gujarathi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Gujarathi_GLP.rpt"));
                    SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                    rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Gujarathi_For_" + txtSanctionno.Text);
                }

                #endregion

                #region MARATHI

                else if (ddlst_language.SelectedItem.Text == "Marathi")
                {
                    rpt = new ReportDocument();
                    rpt.Load(Server.MapPath("Reports/SMESL_Marathi_GLP.rpt"));
                    rpt.SetDatabaseLogon("MISUSER", "User@123", @"RTSDBSRV", "HF_MISDB");

                    rpt.SetParameterValue(0, txtSanctionno.Text);
                    rpt.SetParameterValue(1, Session["CreditCondition"].ToString());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["User"].ToString());
                    rpt.SetParameterValue(4, Session["LD_NO"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Marathi_For_" + txtSanctionno.Text);
                }

                #endregion
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally { }
    }

    public void GenerateGHFSanctionLetter()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            ds = new DataSet();
            SqlCommand mycomm = new SqlCommand("RTS_SP_MITC", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@SANCPROCNO", SqlDbType.VarChar).Value = txtSanctionno.Text;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            mycomm.CommandTimeout = 180000;
            showdata.Fill(ds);

            if (ds.Tables[0].Rows.Count == 0)
            {
                uscMsgBox1.AddMessage("Invalid Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
            {
                try
                {
                    DataView dtview = ds.Tables[0].AsDataView();
                    dtview.RowFilter = "PRODUCT='MF' OR PRODUCT='LP' OR PRODUCT='HL'";

                    #region ENGLISH

                    if (ddlst_language.SelectedValue == "English")
                    {
                        if (dtview.ToTable().Rows.Count > 0
                            && (Convert.ToString(Session["MPS_ID"].ToString()) == "27"
                                || Convert.ToString(Session["MPS_ID"].ToString()) == "80"
                                || Convert.ToString(Session["MPS_ID"].ToString()) == "55"))
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_AHF_BT_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text + "");
                        }
                        else if (dtview.ToTable().Rows.Count > 0
                            && (Convert.ToString(Session["MPS_ID"].ToString()) == "28"
                                || Convert.ToString(Session["MPS_ID"].ToString()) == "29"
                                || Convert.ToString(Session["MPS_ID"].ToString()) == "56"
                                || Convert.ToString(Session["MPS_ID"].ToString()) == "57"
                                || Convert.ToString(Session["MPS_ID"].ToString()) == "85"))
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_AHF_TUP_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text + "");
                        }
                        else if (dtview.ToTable().Rows.Count > 0
                            && ((Convert.ToString(Session["MPS_ID"].ToString()) == "36")
                                || (Convert.ToInt64(Session["MPS_ID"].ToString()) == Convert.ToInt64(Declared_Product_Scheme.ATMA_VISHWAS_2020_Salaried_LAP_Pre_Topup))))
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_SALARIED_LAP.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text + "");
                        }
                        else if (dtview.ToTable().Rows.Count > 0
                            && Convert.ToString(Session["MPS_ID"].ToString()) != "27"
                            && Convert.ToString(Session["MPS_ID"].ToString()) != "80"
                            && Convert.ToString(Session["MPS_ID"].ToString()) != "28"
                            && Convert.ToString(Session["MPS_ID"].ToString()) != "85"
                            && Convert.ToString(Session["MPS_ID"].ToString()) != "29"
                            && Convert.ToString(Session["MPS_ID"].ToString()) != "32"
                            && Convert.ToString(Session["MPS_ID"].ToString()) != "84"
                            && Convert.ToString(Session["MPS_ID"].ToString()) != "55"
                            && Convert.ToString(Session["MPS_ID"].ToString()) != "56"
                            && Convert.ToString(Session["MPS_ID"].ToString()) != "57"
                            && Convert.ToString(Session["MPS_ID"].ToString()) != "58"
                            || Session["Product"].ToString() == EnumUtils.GetEnumValue(Declared_Product_Program.IB_Mainstream_LAP))
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_GHF_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);
                            rpt.SetParameterValue(5, Convert.ToString(Session["MPS_ID"].ToString()));

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text + "");
                        }
                        else if (dtview.ToTable().Rows.Count > 0
                            && (Convert.ToString(Session["MPS_ID"].ToString()) == "32"
                                || Convert.ToString(Session["MPS_ID"].ToString()) == "84"
                                || Convert.ToString(Session["MPS_ID"].ToString()) == "58"))
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_AHF_INSUR.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text + "");
                        }
                        else
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction Letter For " + txtSanctionno.Text + "");
                        }
                    }

                    #endregion

                    #region TAMIL

                    else if (ddlst_language.SelectedValue == "Tamil")
                    {
                        if (dtview.ToTable().Rows.Count > 0)
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_Tamil_GHF_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Tamil_For_" + txtSanctionno.Text + "");
                        }
                        else
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction Letter For " + txtSanctionno.Text + "");
                        }
                    }

                    #endregion

                    #region HINDI

                    else if (ddlst_language.SelectedValue == "Hindi")
                    {
                        if (dtview.ToTable().Rows.Count > 0)
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_Hindi_GHF_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Hindi_For_" + txtSanctionno.Text + "");
                        }
                        else
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction Letter For " + txtSanctionno.Text + "");
                        }
                    }

                    #endregion

                    #region GUJARATHI

                    else if (ddlst_language.SelectedValue == "Gujarathi")
                    {
                        if (dtview.ToTable().Rows.Count > 0)
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_Gujarathi_GHF_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Gujarathi_For_" + txtSanctionno.Text + "");
                        }
                        else
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction Letter For " + txtSanctionno.Text + "");
                        }
                    }

                    #endregion

                    #region MARATHI

                    else if (ddlst_language.SelectedValue == "Marathi")
                    {
                        if (dtview.ToTable().Rows.Count > 0)
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_Marathi_GHF_MITC.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_Marathi_For_" + txtSanctionno.Text + "");
                        }
                        else
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction Letter For " + txtSanctionno.Text + "");
                        }
                    }

                    #endregion
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }
                finally
                {
                    rpt.Close();
                    rpt.Dispose();
                    rpt = null;
                    GC.Collect();
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void GenerateBBSanctionLetter()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            ds = new DataSet();

            SqlCommand mycomm = new SqlCommand("RTS_SP_MITC", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@SANCPROCNO", SqlDbType.VarChar).Value = txtSanctionno.Text;

            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            mycomm.CommandTimeout = 180000;
            showdata.Fill(ds);
            if (ds.Tables[0].Rows.Count == 0)
            {
                uscMsgBox1.AddMessage("Invalid Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
            {
                try
                {
                    DataView dtview = ds.Tables[0].AsDataView();
                    dtview.RowFilter = "PRODUCT='MF' OR PRODUCT='LP'";

                    #region ENGLISH

                    if (ddlst_language.SelectedValue == "English")
                    {
                        if (dtview.ToTable().Rows.Count > 0 && (Convert.ToString(Session["MPS_ID"].ToString()) == "64"))
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_BB.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);
                            rpt.SetParameterValue(5, Convert.ToString(Session["MPS_ID"].ToString()));

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text + "");
                        }
                        else if (dtview.ToTable().Rows.Count > 0 && (Convert.ToString(Session["MPS_ID"].ToString()) == "65"))
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter_BB_INSUR.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(1, Session["User"].ToString());
                            rpt.SetParameterValue(2, Session["CreditCondition"].ToString());
                            rpt.SetParameterValue(3, Session["LD_NO"].ToString());
                            rpt.SetParameterValue(4, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction_Letter_English_For_" + txtSanctionno.Text + "");
                        }
                        else
                        {
                            rpt = new ReportDocument();
                            rpt.Load(Server.MapPath("Reports/Sanction_Letter.rpt"));
                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            rpt.SetParameterValue(0, txtSanctionno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Sanction Letter For " + txtSanctionno.Text + "");
                        }
                    }

                    #endregion                   
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }
                finally { }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            BindqueryGrid();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        try
        {
            ddlArea.SelectedValue = "0";
            ddlBranch.SelectedValue = "0";
            txtLeadno.Text = "";
            txtSancNo.Text = "";
            BindqueryGrid();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}