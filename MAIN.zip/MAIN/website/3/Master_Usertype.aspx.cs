﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_Usertype : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmd = new SqlCommand("select UTP_DESC 'USER TYPE' from MR_USER_TYPE", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvUsertype.DataSource = ds;
        gvUsertype.DataBind();
        if (gvUsertype.Rows.Count > 0)
        {
            gvUsertype.HeaderRow.Font.Bold = true;
            gvUsertype.HeaderRow.Cells[0].Text = "USER TYPE";            

            gvUsertype.HeaderRow.Cells[0].Wrap = false;  
        }
    }
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;           
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand insertcmd = new SqlCommand("insert into MR_USER_TYPE (UTP_DESC,UTP_CBY,UTP_CDATE,UTP_MBY,UTP_MDATE) values ('" + txtUsercode.Text + "','" + Session["ID"].ToString() + "',getdate(),'" + Session["ID"].ToString() + "',getdate())", con);
            insertcmd.ExecuteNonQuery();
            bind();
            txtUsercode.Text = "";            
            uscMsgBox1.AddMessage("UserType Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_Usertype.aspx");
    }
}