﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Tracker;

public partial class Master_Menu_Items_Order : System.Web.UI.Page
{
    DataView dv = new DataView();

    int res = 0;

    SqlConnection con_obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_obj = new SqlCommand();

    

    DataTable dt_obj = new DataTable();

    CreateLogFiles Err = new CreateLogFiles();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                Bind_MR_Menu("", "All");
                this.itms.Visible = false;
            }
        }
        else
        {
            Response.Redirect("Expire.aspx");

        }

    }
    protected void Bind_MR_Menu(string val, string type)
    {
        try
        {



            dt_obj = new DataTable();
            con_obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_obj.State == ConnectionState.Broken || con_obj.State == ConnectionState.Closed)
                con_obj.Open();
            cmd_obj = new SqlCommand("SP_RTS_BIND_MR_MENU", con_obj);

            cmd_obj.CommandType = CommandType.StoredProcedure;
            cmd_obj.Parameters.AddWithValue("@LM_TYPE", ddlst_module.SelectedValue);

            cmd_obj.CommandTimeout = 120000;
            dt_obj.Load(cmd_obj.ExecuteReader());


            if (type == "All")
            {


                /* GROUP MENU BINDING */

                var query = (from gm in dt_obj.AsEnumerable()
                             select new
                             {
                                 LM_GM = gm.Field<string>("LM_GM"),
                                 LM_GM_ID = gm.Field<string>("LM_GM_ID"),

                             }
                            ).Distinct();



                ddlst_grpname.DataSource = query.ToList();
                ddlst_grpname.DataValueField = "LM_GM_ID";
                ddlst_grpname.DataTextField = "LM_GM";
                ddlst_grpname.DataBind();
                ddlst_grpname.Items.Insert(0, new ListItem("--Select--", "0"));


            }


            if (type == "P")
            {
                var grysm = from sm in dt_obj.AsEnumerable()
                            where sm.Field<string>("LM_GM") == val
                            select sm;


                gv_menu_order.DataSource = grysm.CopyToDataTable();
                gv_menu_order.DataBind();

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {

            cmd_obj.Dispose();
            con_obj.Close();
            con_obj.Dispose();
            
            SqlConnection.ClearPool(con_obj);
        }


    }
    protected DataTable Menu_Items_Order(GridView itm)
    {

        DataTable passdt = new DataTable();
        try
        {

            DataRow dr = null;
            passdt.Columns.Add(new DataColumn("LMID", typeof(string)));
            passdt.Columns.Add(new DataColumn("SLNO", typeof(string)));


            foreach (GridViewRow pdr in itm.Rows)
            {

                dr = passdt.NewRow();


                dr["LMID"] = (pdr.FindControl("lbl_lmid") as Label).Text;
                dr["SLNO"] = (pdr.FindControl("txtbxlmslno") as TextBox).Text.Trim();



                passdt.Rows.Add(dr);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

        return passdt;
    }
    protected void ddlst_module_SelectedIndexChanged(object sender, EventArgs e)
    {
        Bind_MR_Menu("", "All");
        this.itms.Visible = false;
    }
    protected void ddlst_grpname_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlst_grpname.SelectedIndex > 0)
        {
            Bind_MR_Menu(ddlst_grpname.SelectedItem.Text, "P");
            this.itms.Visible = true;
        }
        else
        {
            this.itms.Visible = false;
        }
    }
    protected void btnorderslno_Click(object sender, EventArgs e)
    {
        try
        {
            

            con_obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_obj.State == ConnectionState.Broken || con_obj.State == ConnectionState.Closed)
                con_obj.Open();

            cmd_obj = new SqlCommand("SP_RTS_MENU_ITEM_ORDER", con_obj);
            cmd_obj.CommandType = CommandType.StoredProcedure;

            cmd_obj.Parameters.AddWithValue("@ITEM", Menu_Items_Order(gv_menu_order));
            cmd_obj.Parameters.AddWithValue("@ID", Session["ID"].ToString());
            cmd_obj.CommandTimeout = 120000;
            res = cmd_obj.ExecuteNonQuery();
            
            
            if (res > 0)
            {

                uscMsgBox1.AddMessage("Menu Items Display Order updated successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                
            }
            else
            {

                uscMsgBox1.AddMessage("Menu Items Display Order  not updated", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_obj.Dispose();
            con_obj.Close();
            con_obj.Dispose();

            SqlConnection.ClearPool(con_obj);
            
        }
    }
}