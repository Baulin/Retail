﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using Tracker;
using Utilities;

public partial class Legal_Approval : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;


    int ldid;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    DataSet dss = new DataSet();
    DataSet dsd = new DataSet();

    public static DataTable dtLawyerName = null;


    string[] concl = new string[3];
    string[] notearr = new string[10];
    StringBuilder rmks = new StringBuilder();
    StringBuilder conclusion = new StringBuilder();
    StringBuilder note = new StringBuilder();

    DateTime dtd;
    int eccnt, id;
    string strVale;

    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter dappre = new SqlDataAdapter();
    DataSet dspre = new DataSet();
    DataTable dtpre = new DataTable();

    Regex Rx = new Regex("^[0-9]+$");


    /*Mailing variables*/
    public static bool blMailStatus = false;
    public static string frmID = "", toID = "", bccID = "", ccID = "", strMailBody = "";
    public string area = "", bnch = "", ldno = "", prod = "", aname = "", apamt = "";
    public int arid, brid, dvid;
    Thread mail;


    /*Preview variables*/
    SqlCommand cmdp = new SqlCommand();
    // DataSet ds = new DataSet();

    string title, cmmts, appro;

    ReportDocument rpt = new ReportDocument();
    SqlConnection con = new SqlConnection();
    SqlDataAdapter dap = new SqlDataAdapter();

    string empname = "";
    string empid = "";
    string empdesgn = "";
    string oldleadno = "";
    string schemename = "";
    StringBuilder cusnames = new StringBuilder();


    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                try
                {
                    Session["AreaID"] = "";
                    BindLawyerName();
                    txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                    bindArea();
                    bindReason();

                    this.lead.Visible = false;
                    this.tmp.Visible = false;
                    this.kyc.Visible = false;
                    this.approve.Visible = false;
                    this.leadsel1.Visible = false;

                    this.raisedquery.Visible = false;
                    this.lgllnamt.Visible = false;
                    this.lawyer.Visible = false;
                    btnSubmit.Enabled = false;
                    btnCancel.Enabled = false;
                    btndraft.Enabled = false;
                    btnPreview.Enabled = false;
                    this.lglmngrdocs.Visible = false;

                    this.leadsel1.Visible = false;
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }

            }
            else
            {
                Response.Redirect("Expire.aspx");
            }
        }
    }
    // Shankar_Nov_14_01 
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    // Shankar_Nov_14_01 
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    public void bindReason()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_Fetch_MR_REASON", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);

        con.Close();
        ddlReason.DataSource = dsrsn;
        ddlReason.DataTextField = "RSN_REASON";
        ddlReason.DataValueField = "RSN_ID";
        ddlReason.DataBind();
        ddlReason.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Legal_Query", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            if (ddlArea.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@AR_NAME", "");
            }
            if (ddlBranch.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@BR_NAME", "");
            }

            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "L");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables.Count > 0)
            {
                if (ds1.Tables[0].Rows.Count != 0)
                {
                    this.lead.Visible = true;
                    this.kyc.Visible = false;
                    this.approve.Visible = false;
                    this.lawyer.Visible = false;
                    gvApproval.Visible = true;

                    //Panel1.Visible = true;
                    gvApproval.DataSource = ds1.Tables[0];
                    gvApproval.DataBind();
                    if (ds1.Tables[0].Rows.Count > 0)
                    {
                        gvApproval.HeaderRow.Font.Bold = true;
                        gvApproval.HeaderRow.Cells[1].Text = "LEAD NO";
                        gvApproval.HeaderRow.Cells[2].Text = "LEAD DATE";
                        gvApproval.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                        gvApproval.HeaderRow.Cells[4].Text = "PD DATE";
                        gvApproval.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                        gvApproval.HeaderRow.Cells[1].Wrap = false;
                        gvApproval.HeaderRow.Cells[2].Wrap = false;
                        gvApproval.HeaderRow.Cells[3].Wrap = false;
                        gvApproval.HeaderRow.Cells[4].Wrap = false;
                        gvApproval.HeaderRow.Cells[5].Wrap = false;
                    }
                }
                else
                {
                    this.lead.Visible = false;
                    this.kyc.Visible = false;
                    this.approve.Visible = false;
                    this.lawyer.Visible = false;
                    btnSubmit.Enabled = false;
                    btnCancel.Enabled = false;
                    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    // gvApproval.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    public void BindqueryGrid(string AreaName)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Legal_Query", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            if (ddlArea.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@AR_NAME", !string.IsNullOrEmpty(AreaName) ? AreaName : string.Empty);
            }
            if (ddlBranch.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@BR_NAME", "");
            }

            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "L");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables.Count > 0)
            {
                if (ds1.Tables[0].Rows.Count != 0)
                {
                    this.lead.Visible = true;
                    this.kyc.Visible = false;
                    this.approve.Visible = false;
                    this.lawyer.Visible = false;
                    gvApproval.Visible = true;

                    //Panel1.Visible = true;
                    gvApproval.DataSource = ds1.Tables[0];
                    gvApproval.DataBind();
                    if (ds1.Tables[0].Rows.Count > 0)
                    {
                        gvApproval.HeaderRow.Font.Bold = true;
                        gvApproval.HeaderRow.Cells[1].Text = "LEAD NO";
                        gvApproval.HeaderRow.Cells[2].Text = "LEAD DATE";
                        gvApproval.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                        gvApproval.HeaderRow.Cells[4].Text = "PD DATE";
                        gvApproval.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                        gvApproval.HeaderRow.Cells[1].Wrap = false;
                        gvApproval.HeaderRow.Cells[2].Wrap = false;
                        gvApproval.HeaderRow.Cells[3].Wrap = false;
                        gvApproval.HeaderRow.Cells[4].Wrap = false;
                        gvApproval.HeaderRow.Cells[5].Wrap = false;
                    }
                }
                else
                {
                    this.lead.Visible = false;
                    this.kyc.Visible = false;
                    this.approve.Visible = false;
                    this.lawyer.Visible = false;
                    btnSubmit.Enabled = false;
                    btnCancel.Enabled = false;
                    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    // gvApproval.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    protected void BindGVForClear()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Legal_Query", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            if (ddlArea.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@AR_NAME", "");
            }
            if (ddlBranch.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@BR_NAME", "");
            }

            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "L");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables.Count > 0)
            {
                if (ds1.Tables[0].Rows.Count != 0)
                {
                    this.lead.Visible = true;
                    this.kyc.Visible = false;
                    this.approve.Visible = false;
                    this.lawyer.Visible = false;
                    gvApproval.Visible = true;


                    gvApproval.DataSource = ds1.Tables[0];
                    gvApproval.DataBind();
                    if (ds1.Tables[0].Rows.Count > 0)
                    {
                        gvApproval.HeaderRow.Font.Bold = true;
                        gvApproval.HeaderRow.Cells[1].Text = "LEAD NO";
                        gvApproval.HeaderRow.Cells[2].Text = "LEAD DATE";
                        gvApproval.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                        gvApproval.HeaderRow.Cells[4].Text = "PD DATE";
                        gvApproval.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                        gvApproval.HeaderRow.Cells[1].Wrap = false;
                        gvApproval.HeaderRow.Cells[2].Wrap = false;
                        gvApproval.HeaderRow.Cells[3].Wrap = false;
                        gvApproval.HeaderRow.Cells[4].Wrap = false;
                        gvApproval.HeaderRow.Cells[5].Wrap = false;
                    }
                }
                else
                {
                    this.lead.Visible = false;
                    this.kyc.Visible = false;
                    this.approve.Visible = false;
                    this.lawyer.Visible = false;
                    btnSubmit.Enabled = false;
                    btnCancel.Enabled = false;

                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        bool _passValidation = false;

        lblLawterName.Visible = false;
        drpLawyerName.Visible = false;
        lblFFEE.Visible = false;
        lblFFEEVal.Text = "";
        lblFFEEVal.Visible = false;
        ddlLawyerType.SelectedIndex = 0;
        ddlLawyerType.Enabled = false;
        ddlApprv.SelectedIndex = 0;
        ddlApprv.Enabled = false;
        ddlReason.SelectedIndex = 0;
        ddlReason.Enabled = false;
        gvQuerypop.Visible = false;

        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "All";
            _passValidation = false;
            uscMsgBox1.AddMessage("Please Select Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            _passValidation = true;
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";
            _passValidation = true;
        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            _passValidation = true;
        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            _passValidation = true;
        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";
            _passValidation = true;
        }

        if (_passValidation)
        {
            BindqueryGrid();

            foreach (GridViewRow grow in gvApproval.Rows)
            {
                Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                int index = grow.RowIndex;
                if (lblQryResult.Text == "T")
                {
                    gvApproval.Rows[index].Cells[1].ForeColor = Color.Red;
                    gvApproval.Rows[index].Cells[2].ForeColor = Color.Red;
                    gvApproval.Rows[index].Cells[3].ForeColor = Color.Red;
                    gvApproval.Rows[index].Cells[4].ForeColor = Color.Red;
                    gvApproval.Rows[index].Cells[5].ForeColor = Color.Red;
                }

            }

            btnSubmit.Enabled = false;
            btnCancel.Enabled = false;
            btndraft.Enabled = false;
        }
    }
    public void gridbindall()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select distinct LD_NO 'LOAN NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_QUERY E ON A.LD_ID=E.QRY_LD_ID WHERE FT_SENTBY<>'L' AND FT_SENTBY='B' AND FT_SENTTO='L' AND isnull(FT_RDATE,'')<>'' AND isnull(LD_LG_MBY,'')='' AND ISNULL(LD_LC_DATE,'')=''", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);

            gvApproval.DataSource = ds1.Tables[0];
            gvApproval.DataBind();
            if (ds1.Tables[0].Rows.Count > 0)
            {
                gvApproval.HeaderRow.Font.Bold = true;
                gvApproval.HeaderRow.Cells[1].Text = "LEAD NO";
                gvApproval.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvApproval.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvApproval.HeaderRow.Cells[4].Text = "PD DATE";
                gvApproval.HeaderRow.Cells[5].Text = "LOAN AMOUNT";


                gvApproval.HeaderRow.Cells[1].Wrap = false;
                gvApproval.HeaderRow.Cells[2].Wrap = false;
                gvApproval.HeaderRow.Cells[3].Wrap = false;
                gvApproval.HeaderRow.Cells[4].Wrap = false;
                gvApproval.HeaderRow.Cells[5].Wrap = false;
                //gvApproval.HeaderRow.Cells[6].Wrap = false;
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select distinct LD_NO 'LOAN NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_QUERY E ON A.LD_ID=E.QRY_LD_ID WHERE FT_SENTBY<>'L' AND FT_SENTBY='B' AND FT_SENTTO='L' AND isnull(FT_RDATE,'')<>'' AND LD_NO='" + txtLeadno.Text + "' AND isnull(LD_LG_MBY,'')='' AND ISNULL(LD_LC_DATE,'')='' OR FT_SENTBY<>'L' AND FT_SENTBY='B' AND FT_SENTTO='L' AND isnull(FT_RDATE,'')<>'' AND AR_NAME='" + ddlArea.SelectedValue.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedValue.ToString() + "' AND isnull(LD_LG_MBY,'')='' AND ISNULL(LD_LC_DATE,'')=''", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            gvApproval.DataSource = ds.Tables[0];
            gvApproval.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvApproval.HeaderRow.Font.Bold = true;
                gvApproval.HeaderRow.Cells[1].Text = "LEAD NO";
                gvApproval.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvApproval.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvApproval.HeaderRow.Cells[4].Text = "PD DATE";
                gvApproval.HeaderRow.Cells[5].Text = "LOAN AMOUNT";


                gvApproval.HeaderRow.Cells[1].Wrap = false;
                gvApproval.HeaderRow.Cells[2].Wrap = false;
                gvApproval.HeaderRow.Cells[3].Wrap = false;
                gvApproval.HeaderRow.Cells[4].Wrap = false;
                gvApproval.HeaderRow.Cells[5].Wrap = false;

            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Left;
            }
        }
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Legal_ApprovalPopup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        int nVal = 0;
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        ddlLawyerType.Enabled = true;
        ddlLawyerType.SelectedIndex = 0;
        drpLawyerName.Items.Clear();
        drpLawyerName.Visible = false;
        lblLawterName.Visible = false;
        foreach (GridViewRow grow in gvApproval.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;

            Label lblARID = (Label)grow.FindControl("lblARID");
            Label lblLeadID = (Label)grow.FindControl("lblLeadID");
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {

                nVal = 1;
                leadno = gvApproval.Rows[index].Cells[1].Text;
                appname = gvApproval.Rows[index].Cells[3].Text;
                pddt = gvApproval.Rows[index].Cells[4].Text;
                lnamt = gvApproval.Rows[index].Cells[5].Text;
                ClearForDraft();


                Session["AreaID"] = lblARID.Text;
                Session["LeadId"] = lblLeadID.Text;
                Session["Leadno"] = leadno;
                Session["Loanamt"] = lnamt;
                Session["Appname"] = appname;
                Session["StatusLGLEC"] = "New";


                BindAllGrid("All");
                gridbind(Convert.ToString(Session["LeadId"]));
                btnaddT.Enabled = false;
                btnaddT1.Enabled = false;
                btnaddPD.Enabled = false;
                break;

            }
        }
        if (nVal == 0)
        {
            Session["AreaID"] = "";
        }
        fetchLeadID(leadno);
        gridbind1();
        gvQuerypop.Visible = true;
        gridbindkyc();

        ddlApprv.Enabled = true;

        btnSubmit.Enabled = false;
        btnCancel.Enabled = false;
        btndraft.Enabled = false;
        btnPreview.Enabled = false;


        BindListofDocuments();

        this.approve.Visible = true;
        this.leadsel1.Visible = false;

        this.lglmngrdocs.Visible = true;

        this.raisedquery.Visible = true;
        this.lawyer.Visible = true;
        CheckQueryResolve();


        con.Close();
    }
    public void gridbind1()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_BindQueryRaised", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LD_NO", Session["Leadno"].ToString());
            cmd.Parameters.AddWithValue("@QRY_RSD_BY", "L");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dss);

            gvQuerypop.DataSource = dss.Tables[0];
            gvQuerypop.DataBind();

            if (dss.Tables[0].Rows.Count > 0)
            {
                gvQuerypop.HeaderRow.Font.Bold = true;
                gvQuerypop.HeaderRow.Cells[1].Text = "QUERY RAISED";
                gvQuerypop.HeaderRow.Cells[2].Text = "DATE";
                gvQuerypop.HeaderRow.Cells[3].Text = "RESPONSE";
                gvQuerypop.HeaderRow.Cells[4].Text = "RESPONSE DATE";
                gvQuerypop.HeaderRow.Cells[5].Text = "RESOLVE DATE";

                gvQuerypop.HeaderRow.Cells[1].Wrap = false;
                gvQuerypop.HeaderRow.Cells[2].Wrap = false;
                gvQuerypop.HeaderRow.Cells[3].Wrap = false;
                gvQuerypop.HeaderRow.Cells[4].Wrap = false;
                gvQuerypop.HeaderRow.Cells[5].Wrap = false;


            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    public void CheckQueryResolve()
    {
        int tmpcnt = 0;
        for (int w = 0; w < gvQuerypop.Rows.Count; w++)
        {
            if (gvQuerypop.Rows[w].Cells[5].Text != "" && gvQuerypop.Rows[w].Cells[5].Text != " " && !gvQuerypop.Rows[w].Cells[5].Text.Contains("&nbsp"))
            {
                tmpcnt++;
            }
        }

        if (tmpcnt == gvQuerypop.Rows.Count)
        {

            this.lawyer.Visible = true;
            btnSubmit.Enabled = true;
            btndraft.Enabled = true;
            btnCancel.Enabled = true;
            btnPreview.Enabled = true;
        }
        else
        {

            this.lawyer.Visible = false;
            btnSubmit.Enabled = false;
            btndraft.Enabled = true;
            btnCancel.Enabled = false;
            btnPreview.Enabled = false;
        }
    }
    protected void gvUserInfo_RowDataBound1(object o, GridViewRowEventArgs e)
    {
        if (dss.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Right;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
            }
        }
    }
    public void InsertUpdateLegalApproved()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {


            if (ddlLawyerType.Text == "--Select--" && drpLawyerName.SelectedIndex > 0)
            {
                uscMsgBox1.AddMessage("Please Select Lawyer Name", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            if (ddlApprv.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Approved/Rejected", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            if (ddlApprv.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Approved/Rejected", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlApprv.SelectedValue.ToString() == "Rejected" && ddlReason.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {


                ldid = Convert.ToInt32(Session["LeadId"]);

                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = "select count(*) as count from LSD_QUERY where QRY_LD_ID='" + ldid + "' and QRY_RSD_BY='L' and isnull(QRY_RSL_DATE,'')=''";

                int nCount = ((int)cmd.ExecuteScalar());

                //   con.Close();

                if (nCount != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComments.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage("" + nCount + " Query pending, To Continue Please Enter Comments...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else
                {

                    SqlCommand cmdinsert = new SqlCommand("RTS_SP_Update_Legal_Approval", con);
                    cmdinsert.CommandType = CommandType.StoredProcedure;
                    cmdinsert.Parameters.AddWithValue("@LD_CRAP_APRL", ddlApprv.SelectedIndex.ToString());
                    cmdinsert.Parameters.AddWithValue("@LD_CRAP_AMT", "0");
                    cmdinsert.Parameters.AddWithValue("@LD_CRAP_CMTS", txtComments.Text);
                    cmdinsert.Parameters.AddWithValue("@LD_CRAP_MBY", Session["ID"].ToString());
                    cmdinsert.Parameters.AddWithValue("@LD_ID", ldid);
                    cmdinsert.Parameters.AddWithValue("@LD_CRAP_RSN_ID", ddlReason.SelectedValue.ToString());
                    cmdinsert.ExecuteNonQuery();

                    UpdateFinalOpinionFee();


                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }

    public void sendMail(SqlConnection con)
    {
        try
        {
            StringBuilder cmd = new StringBuilder();


            cmd.Append("SELECT 	LD_NO 'LEADNO', LD_APNAME 'APPLICANT',(SELECT PR_NAME FROM MR_PRODUCT WHERE PR_ID=A.LD_PR_ID) 'PRODUCT',C.AR_ID 'AID',C.AR_NAME 'AREA',C.AR_DV_ID 'DID', B.BR_ID 'BID',B.BR_NAME 'BRANCH' FROM	LSD_LEAD A ");
            cmd.Append(" JOIN MR_BRANCH B ON B.BR_ID=A.LD_BR_ID ");
            cmd.Append(" JOIN MR_AREA  C ON C.AR_ID= B.BR_AR_ID ");
            cmd.Append(" WHERE A.LD_ID=");
            cmd.Append(Session["LEADID"].ToString());


            SqlCommand cmddet = new SqlCommand(cmd.ToString(), con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataTable dtdet = new DataTable();
            dadet.Fill(dtdet);

            Session["LNO"] = "";
            Session["APNME"] = "";
            Session["PRDT"] = "";
            Session["ANME"] = "";
            Session["BNME"] = "";
            Session["ARID"] = "";
            Session["BRID"] = "";
            Session["DVID"] = "";


            if (dtdet.Rows.Count > 0)
            {
                Session["LNO"] = dtdet.Rows[0]["LEADNO"] != DBNull.Value ? dtdet.Rows[0]["LEADNO"].ToString() : "";
                Session["APNME"] = dtdet.Rows[0]["APPLICANT"] != DBNull.Value ? dtdet.Rows[0]["APPLICANT"].ToString() : "";

                Session["PRDT"] = dtdet.Rows[0]["PRODUCT"] != DBNull.Value ? dtdet.Rows[0]["PRODUCT"].ToString() : "";
                Session["ANME"] = dtdet.Rows[0]["AREA"] != DBNull.Value ? dtdet.Rows[0]["AREA"].ToString() : "";
                Session["BNME"] = dtdet.Rows[0]["BRANCH"] != DBNull.Value ? dtdet.Rows[0]["BRANCH"].ToString() : "";
                Session["ARID"] = dtdet.Rows[0]["AID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["AID"].ToString()) : 0;
                Session["BRID"] = dtdet.Rows[0]["BID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["BID"].ToString()) : 0;
                Session["DVID"] = dtdet.Rows[0]["DID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["DID"].ToString()) : 0;
            }
            else
            {
                blMailStatus = false;
                return;
            }

            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_EMAIL WHERE EM_BR_ID=");
            cmd.Append(Session["BRID"].ToString());

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtbrnch = new DataTable();
            dadet.Fill(dtbrnch);


            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_AREA_MANAGER WHERE AM_AR_ID=");
            cmd.Append(Session["ARID"].ToString());

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtarm = new DataTable();
            dadet.Fill(dtarm);


            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_EMPLOYEE JOIN MR_USER ON USR_EMP_ID=EMP_ID WHERE USR_ID='" + Session["ID"].ToString() + "'");


            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            dtarm = new DataTable();
            dadet.Fill(dtarm);

            Session["FTOID"] = "";
            Session["FCCID"] = "";

            toID = "";
            ccID = "";

            if (dtbrnch.Rows.Count > 0)
            {

                if (dtbrnch.Rows[0]["EM_BM"] != "" && dtbrnch.Rows[0]["EM_BM"] != DBNull.Value && dtbrnch.Rows[0]["EM_BM"].ToString() != "")
                {
                    //  toID = dtbrnch.Rows[0]["EM_BM"].ToString();
                    Session["FTOID"] = dtbrnch.Rows[0]["EM_BM"].ToString();
                }
                else
                {
                    // toID = "rts-helpdesk@equitasbank.com";
                    Session["FTOID"] = "rts-helpdesk@equitasbank.com";
                }

                if (dtbrnch.Rows[0]["EM_AM"] != "" && dtbrnch.Rows[0]["EM_AM"] != DBNull.Value && dtbrnch.Rows[0]["EM_AM"].ToString() != "")
                {
                    // ccID = dtbrnch.Rows[0]["EM_AM"].ToString();
                    Session["FCCID"] = dtbrnch.Rows[0]["EM_AM"].ToString();
                }

                if (dtbrnch.Rows[0]["EM_CLM"] != "" && dtbrnch.Rows[0]["EM_CLM"] != DBNull.Value && dtbrnch.Rows[0]["EM_CLM"].ToString() != "")
                {
                    // ccID = dtbrnch.Rows[0]["EM_AM"].ToString();
                    if (Session["FCCID"].ToString() != "")
                    {
                        Session["FCCID"] = Session["FCCID"].ToString() + ";" + dtbrnch.Rows[0]["EM_CLM"].ToString();
                    }
                    else
                    {
                        Session["FCCID"] = dtbrnch.Rows[0]["EM_CLM"].ToString();
                    }
                }
                if (dtarm.Rows[0]["EMP_EMAILID"] != "" && dtarm.Rows[0]["EMP_EMAILID"] != DBNull.Value && dtarm.Rows[0]["EMP_EMAILID"].ToString() != "")
                {
                    // ccID = dtbrnch.Rows[0]["EM_AM"].ToString();

                    if (Session["FCCID"].ToString() != "")
                    {
                        Session["FCCID"] = Session["FCCID"].ToString() + ";" + dtarm.Rows[0]["EMP_EMAILID"].ToString();
                    }
                    else
                    {
                        Session["FCCID"] = dtarm.Rows[0]["EMP_EMAILID"].ToString();
                    }
                }

                //if (toID.ToString().StartsWith(";"))
                //{
                //    toID = toID.Substring(1, toID.Length - 1);
                //}
                //if (toID.EndsWith(";"))
                //{
                //    toID = toID.Remove(toID.ToString().Length - 1, 1);
                //}

                //if (ccID.ToString().StartsWith(";"))
                //{
                //    ccID = ccID.Substring(1, ccID.Length - 1);
                //}
                //if (ccID.EndsWith(";"))
                //{
                //    ccID = ccID.Remove(ccID.ToString().Length - 1, 1);
                //}

                if (Session["FTOID"].ToString().StartsWith(";"))
                {
                    Session["FTOID"] = Session["FTOID"].ToString().Substring(1, Session["FTOID"].ToString().Length - 1);
                }
                if (Session["FTOID"].ToString().EndsWith(";"))
                {
                    Session["FTOID"] = Session["FTOID"].ToString().Remove(Session["FTOID"].ToString().Length - 1, 1);
                }

                if (Session["FCCID"].ToString().StartsWith(";"))
                {
                    Session["FCCID"] = Session["FCCID"].ToString().Substring(1, Session["FCCID"].ToString().Length - 1);
                }
                if (Session["FCCID"].ToString().EndsWith(";"))
                {
                    Session["FCCID"] = Session["FCCID"].ToString().Remove(Session["FCCID"].ToString().Length - 1, 1);
                }

            }
            else
            {
                blMailStatus = false;
                return;
            }



            frmID = "RTS Alerts";


            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{

            String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Legal Final Opinion. <br/><br/>";
            BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["LNO"].ToString() + "</strong></td>";
            BodyTxt = BodyTxt + "<td>Area Name</td><td><strong>" + Session["ANME"].ToString() + "</strong></td>";
            BodyTxt = BodyTxt + "<td>Branch Name</td><td><strong>" + Session["BNME"].ToString() + "</strong></td></tr>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + Session["PRDT"].ToString() + "</strong></td>";
            if (ddlApprv.SelectedItem.Text == "Approved")
            {
                BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + Session["APNME"].ToString() + "</strong></td><td>Legal Status</td><td><strong> " + Session["STAT"].ToString() + " / Rs." + Session["AMT"].ToString() + " </strong></td></tr>";
            }
            else
            {
                BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + Session["APNME"].ToString() + "</strong></td><td>Legal Status</td><td><strong> " + Session["STAT"].ToString() + " </strong></td></tr>";
            }
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Legal Comments</td><td colspan='5'><strong>" + Session["CMTS"].ToString() + "</strong></td></table><br/>";

            BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/>Thanks and Regards,<br/>Legal Team</td></tr>";
            BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is an auto-generated e-mail. Please Do not reply to this e-mail.</strong></span></td></tr></table></tr></table></html>";


            blMailStatus = EmailManager.sendemail(Session["FTOID"].ToString(), "RTS Alerts", "", Session["FCCID"].ToString(), "Lead No. : " + Session["LNO"].ToString() + " - Applicant Name : " + Session["APNME"].ToString() + " - Product : " + Session["PRDT"].ToString() + " - Legal Final Opinion", BodyTxt, "", true);


            //});

            //threadSendMails.IsBackground = true;
            //mail = threadSendMails;
            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(5000);


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        if (txtbxtitleofopinion.Text == "")
        {
            txtbxtitleofopinion.Focus();
            uscMsgBox1.AddMessage("Please enter the title of opinion", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

        }
        else if (gvencum.Rows.Count <= 0)
        {
            this.draft1.Focus();
            uscMsgBox1.AddMessage("Please enter the Encumbrance Certificate / Search Report", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        //else if (txtbxpropdetails.Text == "")
        //{
        //    txtbxpropdetails.Focus();
        //    uscMsgBox1.AddMessage("Please enter the property details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        //}
        else if (txtbxecdate.Text == "")
        {
            txtbxecdate.Focus();
            uscMsgBox1.AddMessage("Please enter the EC date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txtbxname.Text == "")
        {
            txtbxname.Focus();
            uscMsgBox1.AddMessage("Please enter the name", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }

        else if (ddlsttype.SelectedItem.Text == "--Select--" || ddlsttype.SelectedIndex == 0)
        {
            ddlsttype.Focus();
            uscMsgBox1.AddMessage("Please select the type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }


        else if (ddlLawyerType.Text == "--Select--" && drpLawyerName.SelectedIndex > 0)
        {
            uscMsgBox1.AddMessage("Please Select Lawyer Name", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (ddlApprv.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please Select Approved/Rejected", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (ddlApprv.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please Select Approved/Rejected", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (ddlApprv.SelectedValue.ToString() == "Rejected" && ddlReason.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

        }
        else if (ddlApprv.SelectedValue.ToString() == "Approved" && txtbxlnamtlgl.Text.Trim() == "")
        {
            uscMsgBox1.AddMessage("Please enter the recommended loan amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

        }
        else if (ddlapplicantsame.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please Select Property Owner is same as Applicant", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txttownship.Text == "")
        {
            uscMsgBox1.AddMessage("Please Enter The TownShip", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (ddlapplicantsame.SelectedItem.Text == "No" && txtapladdress.Text == "")
        {
            uscMsgBox1.AddMessage("Please Enter The Applicant Address", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (grvdoc.Rows.Count <= 0 && ddlApprv.SelectedValue.ToString() == "Approved")
        {
            uscMsgBox1.AddMessage("Property Document Details Not Updated By Credit", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }



        else
        {
            if (btnaddT.Enabled != true && btnaddT1.Enabled != true && btnaddPD.Enabled != true && gvencum.Rows.Count > 0 && txtbxname.Text.Trim() != "" && ddlsttype.SelectedItem.Text != "--Select--"
             && txtbxecdate.Text.Trim() != "")
            {


                try
                {

                    dtd = DateTime.ParseExact(txtbxecdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
                }

                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    uscMsgBox1.AddMessage("Invalid Date format. Please check the EC date (dd/mm/yyyy)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                    return;
                }

                if (txtbxtitleofopinion.Text.Length > 2000)
                {
                    uscMsgBox1.AddMessage("Title of Opinion input field should be less than 2000  characters... ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                if (txtbxtitleofopinion1.Text.Length > 2000)
                {
                    uscMsgBox1.AddMessage("Title of Opinion 2 input field should be less than 2000  characters... ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                if (txtbxtitleofopinion3.Text.Length > 2000)
                {
                    uscMsgBox1.AddMessage("Title of Opinion 3 input field should be less than 2000  characters... ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                if (txtbxtitleofopinion4.Text.Length > 2000)
                {
                    uscMsgBox1.AddMessage("Title of Opinion 4 input field should be less than 2000  characters... ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                if (txtbxtitleofopinion5.Text.Length > 2000)
                {
                    uscMsgBox1.AddMessage("Title of Opinion 5 input field should be less than 2000  characters... ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                if (txtbxnt1.Text != "" && txtbxnt1.Text.Length > 200)
                {
                    uscMsgBox1.AddMessage("Note 3 input field should be less than 200  characters... ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                if (txtbxnt2.Text != "" && txtbxnt2.Text.Length > 200)
                {
                    uscMsgBox1.AddMessage("Note 4 input field should be less than 200  characters... ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                if (txtbxnt3.Text != "" && txtbxnt3.Text.Length > 200)
                {
                    uscMsgBox1.AddMessage("Note 5 input field should be less than 200  characters... ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                //else if (txtbxpropdetails.Text.Length > 500)
                //{
                //    uscMsgBox1.AddMessage("Property Details input field should be less than 500 character...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //    return;
                //}

                InsertUpdateLegalApproved();
                string slnos = "";
                SqlConnection con = new SqlConnection(strcon);
                try
                {

                    string n = SLNOS();
                    /* Remarks Details */
                    rmks.Append("The above said Encumbrance does not disclose any subsisting encumbrance over the Schedule Property.");

                    rmks.AppendLine();
                    rmks.AppendLine();
                    rmks.Append("The Nil Encumbrance Certificate for the period from ");
                    rmks.Append(txtbxecdate.Text.Replace('/', '.').ToString());
                    rmks.Append(" to till date is required to be furnished.");

                    rmks.AppendLine();
                    rmks.AppendLine();
                    rmks.Append("The veracity of the original documents and photocopies of the documents also verified for the Scheduled mentioned property.");

                    /* Conclusion Details */
                    conclusion.Append("From the records and documents produced before us and information furnished to us, ");
                    conclusion.Append("we are of the opinion that ");
                    conclusion.Append(txtbxname.Text + " ");
                    conclusion.Append("the present owner of the Schedule Property has ");
                    if (txtLeadno.Text.Trim().Contains("MSE") || Convert.ToString(Session["Leadno"]).Contains("MSE"))
                    {
                        conclusion.Append("got a good, valid and marketable title for above said property");
                    }
                    else
                    {
                        conclusion.Append("got a good, valid and marketable title over it and ");
                        conclusion.Append(ddlsttype.SelectedItem.Text + " ");
                        conclusion.Append("competent to deal with the Schedule Property thereof the documents mentioned above same may be considered ");
                        conclusion.Append("and taken as a security for the purpose of grant of loan and production and deposit of the documents to this Opinion.");
                    }

                    /* Note details */
                    note.Append("1. MODTD to be executed by ");
                    note.Append(txtbxname.Text);
                    note.Append(" to in favour of the ");

                    if (Session["Leadno"].ToString().StartsWith("SME") || Session["Leadno"].ToString().StartsWith("LAP") || Session["Leadno"].ToString().StartsWith("GLP"))
                        note.Append("EQUITAS SMALL FINANCE BANK.");
                    else if (Session["Leadno"].ToString().StartsWith("MHF") || Session["Leadno"].ToString().StartsWith("GHF"))
                        note.Append("EQUITAS SMALL FINANCE BANK.");

                    note.AppendLine();
                    note.AppendLine();
                    note.Append("2. The Nil Encumbrance Certificate for the period from ");
                    note.Append(txtbxecdate.Text.Replace('/', '.').ToString());
                    note.Append(" to till date.");

                    //note.AppendLine();
                    //note.AppendLine();
                    //note.Append("3. Building Plan and Approval order for the said property.");

                    if (txtbxnt1.Text != "")
                    {
                        note.AppendLine();
                        note.AppendLine();
                        note.Append("3. " + txtbxnt1.Text.Trim() + ".");
                    }

                    if (txtbxnt2.Text != "")
                    {
                        note.AppendLine();
                        note.AppendLine();
                        note.Append("4. " + txtbxnt2.Text.Trim() + ".");
                    }


                    if (txtbxnt2.Text != "")
                    {
                        note.AppendLine();
                        note.AppendLine();
                        note.Append("5. " + txtbxnt3.Text.Trim() + ".");
                    }

                    if (ddlApprv.SelectedItem.Text == "Approved")
                    {
                        appro = "Approved";
                        Session["STAT"] = "Approved";
                        apamt = txtbxlnamtlgl.Text;
                        Session["AMT"] = txtbxlnamtlgl.Text;
                    }
                    else if (ddlApprv.SelectedItem.Text == "Rejected")
                    {
                        appro = "Rejected";
                        Session["STAT"] = "Rejected";
                    }


                    if (txtComments.Text.Trim() == "")
                    {
                        cmmts = "NIL";
                        Session["CMTS"] = "NIL";
                    }
                    else
                    {
                        cmmts = txtComments.Text;
                        Session["CMTS"] = txtComments.Text;
                    }

                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();
                    SqlCommand cmd = new SqlCommand("RTS_SP_Update_LGL_Approval", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 120000;

                    cmd.Parameters.AddWithValue("@TYPE", "ALL");
                    cmd.Parameters.AddWithValue("@MD_TITLE", txtbxtitleofopinion.Text);
                    cmd.Parameters.AddWithValue("@MD_PROP_DET", txtbxpropdetails.Text);
                    cmd.Parameters.AddWithValue("@MD_RMKS", rmks.ToString());
                    cmd.Parameters.AddWithValue("@MR_CONCL", conclusion.ToString());
                    cmd.Parameters.AddWithValue("@MR_NOTE", note.ToString());
                    cmd.Parameters.AddWithValue("@MD_LD_ID", Convert.ToInt32(Session["LeadId"].ToString()));
                    cmd.Parameters.AddWithValue("@LD_LG_AMT", ddlApprv.SelectedItem.Text == "Approved" ? Convert.ToDouble(txtbxlnamtlgl.Text) : 0.0);
                    cmd.Parameters.AddWithValue("@MDX_SLNO", n);
                    cmd.Parameters.AddWithValue("@MD_MBY", Convert.ToInt32(Session["ID"].ToString()));

                    cmd.Parameters.AddWithValue("@Tbl_MOTD_EC", Docx(gvlmdocs));
                    cmd.Parameters.AddWithValue("@MD_SM_APPLCNT", ddlapplicantsame.SelectedItem.Text);
                    cmd.Parameters.AddWithValue("@MD_TOWN_SHP", txttownship.Text.Trim());
                    cmd.Parameters.AddWithValue("@MD_APPL_ADDRS", txtapladdress.Text);


                    int all = cmd.ExecuteNonQuery();

                    int tmp = gvencum.Rows.Count + 3;

                    sendMail(con);
                    // if (mail.IsAlive) { Thread.Sleep(5000); }


                    string strMailStatus = "";
                    string strSuccessMsg = "";

                    if (blMailStatus == true)
                    {
                        strMailStatus = "Successfully";
                    }
                    else
                    {
                        strMailStatus = "Failed";
                    }
                    strSuccessMsg = " <br/> Mail Sent " + strMailStatus + "  ";
                    strSuccessMsg += "<br/> Mail To: " + Session["FTOID"].ToString() + " ; CC To: " + Session["FCCID"].ToString() + " ";


                    txtComments.Text = "";
                    uscMsgBox1.AddMessage(ddlApprv.SelectedItem.ToString() + " Successfully" + strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    CLRSCR();


                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }
                finally
                {
                    con.Close();
                    this.kyc.Visible = false;
                    this.approve.Visible = false;
                    this.lawyer.Visible = false;
                }


            }



            else
            {

                if (btnaddT.Enabled == true)
                {
                    uscMsgBox1.AddMessage("Please add the title of opinion", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxtitleofopinion.Focus();
                    return;
                }
                else if (btnaddT1.Enabled == true)
                {
                    uscMsgBox1.AddMessage("Please add the title of opinion 2", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxtitleofopinion1.Focus();
                    return;
                }
                //else if (btnaddPD.Enabled == true)
                //{
                //    uscMsgBox1.AddMessage("Please add the property details for MODTD", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //    txtbxpropdetails.Focus();
                //    return;
                //}
                else if (gvencum.Rows.Count <= 0)
                {
                    uscMsgBox1.AddMessage("Please add the EC details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxdocdate.Focus();
                    return;
                }
                else if (txtbxecdate.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage("Please select the EC date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxecdate.Focus();
                    return;
                }
                else if (txtbxname.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage("Please enter the name ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxname.Focus();
                    return;
                }
                else if (ddlsttype.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please select the type ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    ddlsttype.Focus();
                    return;
                }

            }
        }


    }


    protected void btnCancel_Click(object sender, EventArgs e)
    {
        // ClearALL();
        Response.Redirect("Legal_Approval.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
    }
    protected void ddlApprv_SelectedIndexChanged(object sender, EventArgs e)
    {


        int CNTSEL = 0;

        foreach (GridViewRow grow in gvlmdocs.Rows)
        {
            CheckBox chkStat = grow.FindControl("chkbxaccept") as CheckBox;
            //     string accp = DataBinder.Eval(e.Row.DataItem, "MDX_LSTAT").ToString();
            string accp;

            int index = grow.RowIndex;
            int index1 = grow.RowIndex - 1;

            if (chkStat.Checked)
            {
                CNTSEL++;
            }


            else
            {
                if (ddlApprv.SelectedItem.Text != "--Select--" && ddlApprv.SelectedValue == "Approved")
                {
                    ddlApprv.SelectedValue = "Rejected";
                    ddlApprv.Focus();
                    uscMsgBox1.AddMessage("All the Documents are not accepted, can't be approved", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    break;
                }
            }
        }


        if (ddlApprv.SelectedValue.ToString() == "Rejected")
        {
            ddlReason.Enabled = true;
            this.lgllnamt.Visible = false;
        }
        else if (ddlApprv.SelectedValue.ToString() == "Approved")
        {
            ddlReason.Enabled = false;

            bindReason();
            this.lgllnamt.Visible = true;
        }
        else
        {
            ddlReason.Enabled = false;

            bindReason();
            this.lgllnamt.Visible = false;
        }

    }
    protected void ddlLawyerType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlLawyerType.SelectedItem.Text == "External")
            {

                if (dtLawyerName != null && dtLawyerName.Rows.Count > 0)
                {
                    if (Session["AreaID"].ToString() != "")
                    {
                        DataRow[] dr = dtLawyerName.Select("LR_AR_ID='" + Session["AreaID"].ToString() + "'");
                        if (dr.Length > 0)
                        {
                            DataTable dtTemp = dr.CopyToDataTable();
                            drpLawyerName.DataSource = dtTemp;
                        }
                        //else
                        //{
                        //    drpLawyerName.DataSource = dtLawyerName;
                        //}
                    }
                    else
                    {
                        drpLawyerName.DataSource = dtLawyerName;
                    }
                    drpLawyerName.DataTextField = "LR_NAME";
                    drpLawyerName.DataValueField = "LR_ID";

                    drpLawyerName.DataBind();
                    drpLawyerName.Items.Insert(0, "--Select--");
                    drpLawyerName.Visible = true;
                    lblLawterName.Visible = true;

                    if (SetLwyerName(Session["LeadId"].ToString()) != "0")
                    {
                        try
                        {
                            drpLawyerName.SelectedValue = SetLwyerName(Session["LeadId"].ToString());
                            lblFFEEVal.Text = fetchPreFee(drpLawyerName.SelectedValue.ToString());
                            lblFFEEVal.Visible = true;
                            lblFFEE.Visible = true;
                        }
                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            drpLawyerName.SelectedIndex = 0;
                        }
                    }
                    else { drpLawyerName.SelectedIndex = 0; }
                }
                else
                {
                    drpLawyerName.Items.Insert(0, "--Select--");
                    drpLawyerName.Visible = true;
                    lblLawterName.Visible = true;
                }



            }
            else
            {
                drpLawyerName.Items.Clear();
                drpLawyerName.Visible = false;
                lblLawterName.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
    }
    protected void drpLawyerName_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpLawyerName.SelectedIndex > 0)
        {

            lblFFEEVal.Text = fetchPreFee(drpLawyerName.SelectedValue.ToString());
            lblFFEEVal.Visible = true;
            lblFFEE.Visible = true;
        }
        else
        {
            lblFFEEVal.Text = "";
            lblFFEEVal.Visible = false;
            lblFFEE.Visible = false;
        }
    }
    public DataTable BindLawyerName()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = null;
        if (Session["AreaID"].ToString() == "")
        {
            cmddd = new SqlCommand("SELECT LR_NAME,LR_ID,LR_PFEE,LR_AR_ID,LR_FFEE FROM MR_LAWYER ORDER BY LR_NAME ASC", con);
        }
        else
        {
            cmddd = new SqlCommand("SELECT LR_NAME,LR_ID,LR_PFEE,LR_AR_ID,LR_FFEE FROM MR_LAWYER Where LR_AR_ID='" + Session["AreaID"].ToString() + "'  ORDER BY LR_NAME ASC", con);
        }

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        dtLawyerName = dsdd.Tables[0];
        con.Close();
        return dtLawyerName;
    }
    public string fetchPreFee(string LR_ID)
    {
        string strFee = "";
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = null;

        cmddd = new SqlCommand("SELECT LR_FFEE FROM MR_LAWYER where LR_ID='" + LR_ID + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        if (dsdd.Tables[0].Rows.Count > 0)
        {
            strFee = dsdd.Tables[0].Rows[0][0].ToString();
        }
        else
        {

        }
        con.Close();
        return strFee;
    }
    public string SetLwyerName(string LF_LD_ID)
    {
        string strlawyer = "";
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = null;

        cmddd = new SqlCommand("SELECT LF_LR_PID FROM LSD_LAWYER_FEE where LF_LD_ID='" + LF_LD_ID + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        if (dsdd.Tables[0].Rows.Count > 0)
        {
            strlawyer = dsdd.Tables[0].Rows[0][0].ToString();
        }
        else
        {
            strlawyer = "0";
        }
        con.Close();
        return strlawyer;
    }
    public void fetchLeadID(string LD_No)
    {
        string strFee = "";
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = null;

        cmddd = new SqlCommand("SELECT LD_ID FROM LSD_LEAD where LD_NO='" + LD_No + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        Session["LeadId"] = dsdd.Tables[0].Rows[0][0].ToString();
        con.Close();

    }
    public void UpdateFinalOpinionFee()
    {
        string strFee = "";
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = null;
        ldid = Convert.ToInt32(Session["LeadId"]);
        string strLawyerID = drpLawyerName.SelectedValue.ToString() != "" ? drpLawyerName.SelectedValue.ToString() : Session["ID"].ToString();
        if (lblFFEEVal.Text == "")
        {
            lblFFEEVal.Text = "0";
        }
        cmddd = new SqlCommand("Update LSD_LAWYER_FEE set LF_LR_FID='" + strLawyerID + "',LF_FDATE=GETDATE(),LF_FFEE='" + lblFFEEVal.Text + "'  where LF_LD_ID='" + ldid.ToString() + "'", con);
        cmddd.ExecuteNonQuery();
        con.Close();
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["StatusLGLEC"].ToString() == "New")
            {

                if (txtbxdocdate.Text != "" && txtbxdocs.Text != "")
                {
                    try
                    {

                        dtd = DateTime.ParseExact(txtbxdocdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
                    }

                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                        uscMsgBox1.AddMessage("Invalid Date format. Please check the date (dd/mm/yyyy)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                        return;
                    }


                    using (SqlConnection connection = new SqlConnection(strcon))
                    {
                        connection.Open();

                        if (gvencum.Rows.Count > 0)
                        {
                            List<int> cnt = new List<int>();
                            cnt.Clear();
                            foreach (GridViewRow grow in gvencum.Rows)
                            {
                                Label lblPSCH = grow.FindControl("lblecslno") as Label;
                                cnt.Add(Convert.ToInt32(lblPSCH.Text));
                            }
                            eccnt = cnt.Max() + 1;

                        }
                        else
                            eccnt = 1;

                        try
                        {
                            string sql = "INSERT INTO LSD_MOTD_EC (MEC_MD_ID,MEC_SLNO,MEC_DATE,MEC_DOC) values(" + Convert.ToInt32(Session["MDIDA"].ToString()) + "," + eccnt + ",'" + dtd + "','" +
                                          txtbxdocs.Text + "')";


                            cmd = new SqlCommand(sql, connection);

                            int r = cmd.ExecuteNonQuery();
                            if (r > 0)
                            {
                                Clear();
                                BindAllGrid("E");
                                //uscMsgBox1.AddMessage("Please check the age", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);


                            }
                            else
                            {
                                uscMsgBox1.AddMessage("EC not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            uscMsgBox1.AddMessage("EC Document input field should be less than 200 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }
                        finally
                        {
                            cmd.Dispose();
                        }
                    }


                }
                else
                {
                    if (txtbxdocdate.Text == "")
                    {
                        txtbxdocdate.Focus();

                    }

                    else if (txtbxdocs.Text == "")
                    {
                        txtbxdocs.Focus();
                    }

                    uscMsgBox1.AddMessage("Please Give corresponding Inputs for Encumbrance Certificate / Search Report", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                }
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }


    }

    public void Clear()
    {
        txtbxdocdate.Text = "";
        txtbxdocs.Text = "";
    }
    protected void gvencum_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void gvencum_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "Delete")
        {

            strVale = e.CommandArgument.ToString();
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();

                try
                {
                    string sql = "DELETE FROM  LSD_MOTD_EC WHERE MEC_MD_ID=" + Convert.ToInt32(Session["MDIDA"].ToString()) + " and MEC_SLNO=" + Convert.ToInt32(strVale);


                    cmd = new SqlCommand(sql, connection);

                    int r = cmd.ExecuteNonQuery();
                    if (r > 0)
                    {
                        BindAllGrid("E");
                        Clear();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("EC not deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
                    catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
                }
                finally
                {
                    cmd.Dispose();
                }
            }

        }



    }
    private void BindListofDocuments()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("RTS_SP_FetchMODTDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LD_ID", Convert.ToInt32(Session["LeadId"].ToString()));
            cmd.CommandTimeout = 60000;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);

            txtbxtitleofopinion.Text = ds.Tables[0].Rows[0]["MD_TITLE"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_TITLE"].ToString();
            txtbxtitleofopinion1.Text = ds.Tables[0].Rows[0]["MD_TITLE2"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_TITLE2"].ToString();
            txtbxtitleofopinion3.Text = ds.Tables[0].Rows[0]["MD_TITLE3"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_TITLE3"].ToString();
            txtbxtitleofopinion4.Text = ds.Tables[0].Rows[0]["MD_TITLE4"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_TITLE4"].ToString();
            txtbxtitleofopinion5.Text = ds.Tables[0].Rows[0]["MD_TITLE5"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_TITLE5"].ToString();
            txtbxecdate.Text = ds.Tables[0].Rows[0]["MD_RMKS"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_RMKS"].ToString();
            txtbxpropdetails.Text = ds.Tables[0].Rows[0]["MD_PROP_DET"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_PROP_DET"].ToString();
            if (ds.Tables[0].Rows[0]["MD_SM_APPLCNT"] != DBNull.Value)
            {
                ddlapplicantsame.SelectedValue = ds.Tables[0].Rows[0]["MD_SM_APPLCNT"].ToString();
            }
            else
            {
                ddlapplicantsame.SelectedIndex = 0;
            }

            txttownship.Text = ds.Tables[0].Rows[0]["MD_TOWN_SHP"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_TOWN_SHP"].ToString();
            txtapladdress.Text = ds.Tables[0].Rows[0]["MD_APPL_ADDRS"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["MD_APPL_ADDRS"].ToString();

            if (ds.Tables[0].Rows[0]["MD_SM_APPLCNT"].ToString() == "No")
            {
                this.appladd.Visible = true;
            }
            else
            {
                this.appladd.Visible = false;
            }
            #region Preview Add
            hdnPreview.Value = txtbxtitleofopinion.Text;
            hdnPreview1.Value = txtbxtitleofopinion1.Text;
            hdnPreview3.Value = txtbxtitleofopinion3.Text;
            hdnPreview4.Value = txtbxtitleofopinion4.Text;
            hdnPreview5.Value = txtbxtitleofopinion5.Text;
            hdnPreviewP.Value = txtbxpropdetails.Text;
            #endregion

            concl = ds.Tables[0].Rows[0]["MR_CONCL"] == DBNull.Value ? null : ds.Tables[0].Rows[0]["MR_CONCL"].ToString().Split('|');

            if (concl != null)
            {
                txtbxname.Text = concl[0].ToString();
                ddlsttype.SelectedValue = concl[1].ToString().Trim();
            }

            notearr = ds.Tables[0].Rows[0]["MR_NOTE"] == DBNull.Value ? null : ds.Tables[0].Rows[0]["MR_NOTE"].ToString().Split('|');
            if (notearr != null)
            {
                for (int nt = 1; nt <= notearr.Length; nt++)
                {
                    switch (nt)
                    {
                        case 1:
                            txtbxnt1.Text = notearr[0].ToString();
                            break;

                        case 2:
                            txtbxnt2.Text = notearr[1].ToString();
                            break;
                        case 3:
                            txtbxnt3.Text = notearr[2].ToString();
                            break;
                    }
                }

            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }

    }
    protected void btndraft_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            try
            {

                dtd = DateTime.ParseExact(txtbxecdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
            }

            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                uscMsgBox1.AddMessage("Invalid Date format. Please check the EC date (dd/mm/yyyy)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                return;
            }


            if (txtbxtitleofopinion.Text.Length > 2000)
            {
                uscMsgBox1.AddMessage("Title of Opinion input field should be less than 2000  characters... ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            //else if (txtbxpropdetails.Text.Length > 500)
            //{
            //    uscMsgBox1.AddMessage("Property Details input field should be less than 500 character...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //    return;
            //}

            if (btnaddT.Enabled != true && btnaddT1.Enabled != true && btnaddPD.Enabled != true && gvencum.Rows.Count > 0 && txtbxname.Text.Trim() != "" && ddlsttype.SelectedItem.Text != "--Select--"
              && txtbxecdate.Text.Trim() != "" && ddlapplicantsame.SelectedItem.Text != "--Select--" && txttownship.Text != "")
            {


                string ns = SLNOS();
                string nos = SLNOS();
                string amt = "";
                if (txtbxlnamtlgl.Text.Trim() != "")
                {
                    amt = txtbxlnamtlgl.Text.Trim();
                }
                if (ddlApprv.SelectedItem.Text == "Approved")
                {
                    if (amt == "")
                    {
                        amt = "0";

                    }
                }
                else
                {
                    amt = "0";


                }


                if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                    con.Open();

                cmd = new SqlCommand("RTS_SP_Update_LGL_Approval", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 120000;

                cmd.Parameters.AddWithValue("@TYPE", "DRAFT");
                cmd.Parameters.AddWithValue("@MD_TITLE", "");
                cmd.Parameters.AddWithValue("@MD_PROP_DET", "");
                cmd.Parameters.AddWithValue("@MD_RMKS", txtbxecdate.Text);
                cmd.Parameters.AddWithValue("@MR_CONCL", txtbxname.Text + "|" + ddlsttype.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@MR_NOTE", txtbxnt1.Text.Trim() + "|" + txtbxnt2.Text.Trim() + "|" + txtbxnt3.Text.Trim());
                cmd.Parameters.AddWithValue("@MD_LD_ID", Convert.ToInt32(Session["LeadId"].ToString()));
                cmd.Parameters.AddWithValue("@MDX_SLNO", ns);
                cmd.Parameters.AddWithValue("@LD_LG_AMT", Convert.ToDouble(amt));
                cmd.Parameters.AddWithValue("@MD_MBY", Convert.ToInt32(Session["ID"].ToString()));

                cmd.Parameters.AddWithValue("@Tbl_MOTD_EC", Docx(gvlmdocs));
                cmd.Parameters.AddWithValue("@MD_SM_APPLCNT", ddlapplicantsame.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@MD_TOWN_SHP", txttownship.Text.Trim());
                cmd.Parameters.AddWithValue("@MD_APPL_ADDRS", txtapladdress.Text);

                int dft = cmd.ExecuteNonQuery();
                if (dft > 0)
                {

                    uscMsgBox1.AddMessage("Drafted successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

                }
                else
                    uscMsgBox1.AddMessage("Not drafted", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

            }
            else
            {

                if (btnaddT.Enabled == true)
                {
                    uscMsgBox1.AddMessage("Please add the title of opinion", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxtitleofopinion.Focus();
                    return;
                }
                else if (btnaddT1.Enabled == true)
                {
                    uscMsgBox1.AddMessage("Please add the title of opinion 2", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxtitleofopinion1.Focus();
                    return;
                }
                //else if (btnaddPD.Enabled == true)
                //{
                //    uscMsgBox1.AddMessage("Please add the property details for MODTD", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //    txtbxpropdetails.Focus();
                //    return;
                //}
                else if (gvencum.Rows.Count <= 0)
                {
                    uscMsgBox1.AddMessage("Please add the EC details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxdocdate.Focus();
                    return;
                }
                else if (txtbxecdate.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage("Please select the EC date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxecdate.Focus();
                    return;
                }
                else if (txtbxname.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage("Please enter the name ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxname.Focus();
                    return;
                }
                else if (ddlsttype.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please select the type ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    ddlsttype.Focus();
                    return;
                }
                else if (ddlapplicantsame.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please Select Property Owner is same as Applicant", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (txttownship.Text == "")
                {
                    uscMsgBox1.AddMessage("Please Enter The TownShip", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (ddlapplicantsame.SelectedItem.Text == "No" && txtapladdress.Text == "")
                {
                    uscMsgBox1.AddMessage("Please Enter The Applicant Address", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally { con.Close(); }
    }
    private void ClearALL()
    {
        Session["AreaID"] = "";
        BindLawyerName();
        txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
        bindArea();
        bindReason();



        gvApproval.DataSource = null;
        gvApproval.DataBind();

        txtbxtitleofopinion.Text = "";
        txtbxtitleofopinion1.Text = "";
        txtbxtitleofopinion3.Text = "";
        txtbxtitleofopinion4.Text = "";
        txtbxtitleofopinion5.Text = "";
        txttownship.Text = "";
        txtapladdress.Text = "";
        Clear();

        txtbxpropdetails.Text = "";
        txtbxecdate.Text = "";

        txtbxname.Text = "";
        ddlsttype.SelectedIndex = 0;

        ddlArea.SelectedIndex = 0;
        ddlBranch.SelectedIndex = 0;
        txtLeadno.Text = "";

        gvdocs.DataSource = null;
        gvdocs.DataBind();

        gvencum.DataSource = null;
        gvencum.DataBind();
        ddlApprv.SelectedIndex = 0;
        ddlLawyerType.SelectedIndex = 0;
        ddlReason.SelectedIndex = 0;
        drpLawyerName.SelectedIndex = 0;
        ddlapplicantsame.SelectedIndex = 0;

        this.lead.Visible = false;
        this.kyc.Visible = false;
        this.leadsel1.Visible = false;

        this.raisedquery.Visible = false;
        this.lawyer.Visible = false;
        this.approve.Visible = false;
        btnaddPD.Enabled = false;
        btnaddEC.Enabled = false;
    }

    protected void ClearForDraft()
    {
        BindLawyerName();
        txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
        //bind();
        // bindArea();
        bindReason();

        txtbxtitleofopinion.Text = "";
        txtbxtitleofopinion1.Text = "";
        txtbxtitleofopinion3.Text = "";
        txtbxtitleofopinion4.Text = "";
        txtbxtitleofopinion5.Text = "";
        Clear();

        txtbxpropdetails.Text = "";
        txtbxecdate.Text = "";

        txtbxname.Text = "";
        ddlsttype.SelectedIndex = 0;
        ddlapplicantsame.SelectedIndex = 0;
        txttownship.Text = "";
        txtapladdress.Text = "";
        txtbxnt1.Text = "";
        txtbxnt2.Text = "";
        txtbxnt3.Text = "";



    }

    protected void gvdocs_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlsttype_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (txtbxname.Text.Contains(',') || txtbxname.Text.Contains(" and ") || txtbxname.Text.Contains(" AND "))
        {
            ddlsttype.SelectedIndex = 3;
        }
        else
        {
            if (ddlsttype.SelectedValue == "They are")
            {

                this.draft4.Focus();
                ddlsttype.Focus();
                uscMsgBox1.AddMessage("Please select the correct type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

        }

    }
    protected void BindAllGrid(string Type)
    {
        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                cmd = new SqlCommand("RTS_SP_BIND_LGL_PREOPINION", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@LDID", Convert.ToInt32(Session["LeadId"].ToString()));
                cmd.CommandTimeout = 120000;
                dspre = new DataSet();
                dappre = new SqlDataAdapter(cmd);
                dappre.Fill(dspre);
                if (Type == "All")
                {

                    if (dspre.Tables.Count > 0)
                    {

                        if (dspre.Tables[0].Rows.Count > 0)
                        {
                            Session["MDIDA"] = dspre.Tables[0].Rows[0]["MD_ID"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_ID"].ToString() : null;
                        }
                        else Session["MDIDA"] = null;



                        gvlmdocs.DataSource = dspre.Tables[3];
                        gvlmdocs.DataBind();


                        gvencum.DataSource = dspre.Tables[4];
                        gvencum.DataBind();

                    }
                }
                else
                {
                    if (Type == "D")
                    {

                        gvlmdocs.DataSource = dspre.Tables[3];
                        gvlmdocs.DataBind();


                    }
                    else if (Type == "E")
                    {
                        gvencum.DataSource = dspre.Tables[4];
                        gvencum.DataBind();
                    }
                    else
                    {
                        if (dspre.Tables[0] != null)
                        {
                            if (dspre.Tables[0].Rows.Count > 0)
                            {
                                Session["MDIDA"] = dspre.Tables[0].Rows[0]["MD_ID"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_ID"].ToString() : null;
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
                catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
            }
        }
    }
    protected void gvencum_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string tempdate = DataBinder.Eval(e.Row.DataItem, "MEC_DATE").ToString();
            Label lbdate = (Label)e.Row.FindControl("lblmecdt");
            string[] dbarr = tempdate.Split('/');
            (e.Row.FindControl("lblmecdt") as Label).Text = dbarr[1].ToString() + "-" + dbarr[0].ToString() + "-" + dbarr[2].ToString();
        }
    }
    protected void gvQuerypop_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnPreview_Click(object sender, EventArgs e)
    {
        try
        {

            if (btnaddT.Enabled != true && btnaddPD.Enabled != true && btnaddT1.Enabled != true && gvencum.Rows.Count > 0 && txtbxname.Text.Trim() != "" && ddlsttype.SelectedItem.Text != "--Select--"
                && txtbxecdate.Text.Trim() != "" && ddlapplicantsame.SelectedItem.Text != "--Select--" && txttownship.Text != "")
            {
                try
                {

                    dtd = DateTime.ParseExact(txtbxecdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
                }

                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    uscMsgBox1.AddMessage("Invalid Date format. Please check the EC date (dd/mm/yyyy)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                    return;
                }




                if (txtbxtitleofopinion.Text.Trim() == "")
                    title = "NIL";
                else title = txtbxtitleofopinion.Text;

                if (txtbxtitleofopinion1.Text.Trim() != "")
                    title = title + "\r\n" + txtbxtitleofopinion1.Text;

                if (txtbxtitleofopinion3.Text.Trim() != "")
                {
                    title = title + "\r\n" + txtbxtitleofopinion3.Text;
                }
                if (txtbxtitleofopinion4.Text.Trim() != "")
                {
                    title = title + "\r\n" + txtbxtitleofopinion4.Text;
                }
                if (txtbxtitleofopinion5.Text.Trim() != "")
                {
                    title = title + "\r\n" + txtbxtitleofopinion5.Text;
                }

                if (txtComments.Text.Trim() == "")
                    cmmts = "NIL";
                else cmmts = txtComments.Text;


                /* Remarks Details */
                rmks.Append("The above said Encumbrance does not disclose any subsisting encumbrance over the Schedule Property.");

                rmks.AppendLine();
                rmks.AppendLine();
                rmks.Append("The Nil Encumbrance Certificate for the period from ");
                rmks.Append(txtbxecdate.Text.Replace('/', '.').ToString());
                rmks.Append(" to till date is required to be furnished.");

                rmks.AppendLine();
                rmks.AppendLine();
                rmks.Append("The veracity of the original documents and photocopies of the documents also verified for the Scheduled mentioned property.");

                /* Conclusion Details */
                conclusion.Append("From the records and documents produced before us and information funished to us, ");
                conclusion.Append("we are of the opinion that ");
                conclusion.Append(txtbxname.Text + " ");
                conclusion.Append("the present owner of the Schedule Property has ");
                if (txtLeadno.Text.Trim().Contains("MSE") || Convert.ToString(Session["Leadno"]).Contains("MSE"))
                {
                    conclusion.Append("got a good, valid and marketable title for above said property");
                }
                else
                {
                    conclusion.Append("got a good, valid and marketable title over it and ");
                    conclusion.Append(ddlsttype.SelectedItem.Text + " ");
                    conclusion.Append("competent to deal with the Schedule Property thereof the documents mentioned above same may be considered ");
                    conclusion.Append("and taken as a security for the purpose of grant of loan and production and deposit of the documents to this Opinion.");
                }

                /* Note details */
                note.Append("1. MODTD to be executed by ");
                note.Append(txtbxname.Text);
                note.Append(" to in favour of the ");
                //if (Session["Leadno"].ToString().StartsWith("MHF") || Session["Leadno"].ToString().StartsWith("GHF"))
                note.Append("EQUITAS SMALL FINANCE BANK LIMITED.");
                //else
                //{
                //    note.Append("EFL.");
                //}


                note.AppendLine();
                note.AppendLine();
                note.Append("2. The Nil Encumbrance Certificate for the period from ");
                note.Append(txtbxecdate.Text.Replace('/', '.').ToString());
                note.Append(" to till date.");

                note.AppendLine();
                note.AppendLine();
                note.Append("3. Building Plan and Approval order for the said property.");

                if (txtbxnt1.Text != "")
                {
                    note.AppendLine();
                    note.AppendLine();
                    note.Append("4. " + txtbxnt1.Text.Trim() + ".");
                }

                if (txtbxnt2.Text != "")
                {
                    note.AppendLine();
                    note.AppendLine();
                    note.Append("5. " + txtbxnt2.Text.Trim() + ".");
                }


                if (txtbxnt2.Text != "")
                {
                    note.AppendLine();
                    note.AppendLine();
                    note.Append("6. " + txtbxnt3.Text.Trim() + ".");
                }

                con = new SqlConnection(strcon);


                if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                    con.Open();
                cmd = new SqlCommand("RTS_SP_FINAL", con);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@LDNO", Session["Leadno"].ToString());

                cmd.CommandTimeout = 12000;
                dap = new SqlDataAdapter(cmd);
                dspre = new DataSet();
                dap.Fill(dspre);

                cusnames = new StringBuilder();
                if (dspre.Tables[1].Rows.Count > 0)
                {
                    if (dspre.Tables[1].Rows[0]["MCB_TITLE"] == DBNull.Value)
                    {


                        cusnames.Append("Mr/Ms. ");
                        cusnames.Append(dspre.Tables[0].Rows[0]["LD_APNAME"].ToString());
                        if (dspre.Tables[1].Rows.Count > 0)
                        {
                            for (int k = 0; k < dspre.Tables[1].Rows.Count; k++)
                            {
                                cusnames.Append(", ");
                                cusnames.Append(dspre.Tables[1].Rows[k]["MCB_NAME"].ToString().TrimEnd());
                            }
                        }
                    }
                    else
                    {
                        for (int i = 0; i < dspre.Tables[1].Rows.Count; i++)
                        {
                            if (i != dspre.Tables[1].Rows.Count - 1)
                            {
                                cusnames.Append(dspre.Tables[1].Rows[i]["MCB_TITLE"].ToString().TrimEnd() + dspre.Tables[1].Rows[i]["MCB_NAME"].ToString().TrimEnd());
                                cusnames.Append(", ");
                            }
                            else
                            {
                                cusnames.Append(dspre.Tables[1].Rows[i]["MCB_TITLE"].ToString().TrimEnd() + dspre.Tables[1].Rows[i]["MCB_NAME"].ToString().TrimEnd());
                            }


                        }

                    }
                }
                else
                {

                    cusnames.Append("Mr/Ms. ");
                    cusnames.Append(dspre.Tables[0].Rows[0]["LD_APNAME"].ToString());
                }

                empname = dspre.Tables[2].Rows[0]["EMP_NAME"] != DBNull.Value ? dspre.Tables[2].Rows[0]["EMP_NAME"].ToString().ToUpper() : "";
                empid = dspre.Tables[2].Rows[0]["EMP_CODE"] != DBNull.Value ? dspre.Tables[2].Rows[0]["EMP_CODE"].ToString().ToUpper() : "";
                empdesgn = dspre.Tables[2].Rows[0]["ET_DESC"] != DBNull.Value ? dspre.Tables[2].Rows[0]["ET_DESC"].ToString().ToUpper() : "";
                oldleadno = dspre.Tables[3].Rows[0]["LD_NO"] != DBNull.Value ? dspre.Tables[3].Rows[0]["LD_NO"].ToString() : "";
                schemename = dspre.Tables[0].Rows[0]["MPS_NAME"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MPS_NAME"].ToString() : "";
                string nos = SLNOS();
                string amt = "";
                if (txtbxlnamtlgl.Text.Trim() != "")
                {
                    amt = txtbxlnamtlgl.Text.Trim();
                }
                if (ddlApprv.SelectedItem.Text == "Approved")
                {
                    if (amt == "")
                    {
                        amt = "0";

                    }
                }
                else
                {
                    amt = "0";


                }

                cmd = new SqlCommand("RTS_SP_Update_LGL_Approval", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 120000;

                cmd.Parameters.AddWithValue("@TYPE", "PREVIEW");
                cmd.Parameters.AddWithValue("@MD_TITLE", "");
                cmd.Parameters.AddWithValue("@MD_PROP_DET", "");
                cmd.Parameters.AddWithValue("@MD_RMKS", "");
                cmd.Parameters.AddWithValue("@MR_CONCL", "");
                cmd.Parameters.AddWithValue("@MR_NOTE", "");
                cmd.Parameters.AddWithValue("@MD_LD_ID", Convert.ToInt32(Session["LeadId"].ToString()));
                cmd.Parameters.AddWithValue("@MDX_SLNO", nos);
                cmd.Parameters.AddWithValue("@LD_LG_AMT", Convert.ToDouble(amt));
                cmd.Parameters.AddWithValue("@MD_MBY", DBNull.Value);


                cmd.Parameters.AddWithValue("@Tbl_MOTD_EC", Docx(gvlmdocs));
                cmd.Parameters.AddWithValue("@MD_SM_APPLCNT", ddlapplicantsame.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@MD_TOWN_SHP", txttownship.Text.Trim());
                cmd.Parameters.AddWithValue("@MD_APPL_ADDRS", txtapladdress.Text);

                cmd.ExecuteNonQuery();

                rpt = new ReportDocument();

                if (txtLeadno.Text.Trim().Contains("MSE") || Convert.ToString(Session["Leadno"]).Contains("MSE"))
                {
                    rpt.Load(Server.MapPath("Reports/FinalOpinionD_MSE.rpt"));
                }
                else
                {
                    rpt.Load(Server.MapPath("Reports/FinalOpinionD.rpt"));
                }

                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                //assign the values to crystal report viewer
                rpt.SetParameterValue(0, Session["Leadno"].ToString());
                rpt.SetParameterValue(1, Session["EMPNAME"].ToString().ToUpper());
                rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                rpt.SetParameterValue(3, Session["UNITNAME"].ToString());
                rpt.SetParameterValue(4, cusnames.ToString());
                rpt.SetParameterValue(5, empname);
                rpt.SetParameterValue(6, empdesgn);
                rpt.SetParameterValue(7, empid);
                rpt.SetParameterValue(8, title);
                rpt.SetParameterValue(9, rmks.ToString());
                rpt.SetParameterValue(10, conclusion.ToString());
                rpt.SetParameterValue(11, note.ToString());
                rpt.SetParameterValue(12, cmmts);
                rpt.SetParameterValue(13, txtbxlnamtlgl.Text != "" ? txtbxlnamtlgl.Text : "");
                rpt.SetParameterValue(14, oldleadno);
                rpt.SetParameterValue(15, schemename);
                rpt.SetParameterValue(16, Session["Leadno"].ToString());
                rpt.SetParameterValue(17, Session["Leadno"].ToString());
                rpt.SetParameterValue(18, Session["Leadno"].ToString());
                rpt.SetParameterValue(19, Session["Leadno"].ToString());

                rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Final Opinion Draft For " + Session["Leadno"].ToString() + "");

            }
            else
            {
                if (btnaddT.Enabled == true)
                {
                    uscMsgBox1.AddMessage("Please add the title of opinion", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxtitleofopinion.Focus();
                    return;
                }
                else if (btnaddT1.Enabled == true)
                {
                    uscMsgBox1.AddMessage("Please add the title of opinion 2", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxtitleofopinion1.Focus();
                    return;
                }
                //else if (btnaddPD.Enabled == true)
                //{
                //    uscMsgBox1.AddMessage("Please add the property details for MODTD", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //    txtbxpropdetails.Focus();
                //    return;
                //}
                else if (gvencum.Rows.Count <= 0)
                {
                    uscMsgBox1.AddMessage("Please add the EC details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxdocdate.Focus();
                    return;
                }
                else if (txtbxecdate.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage("Please select the EC date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxecdate.Focus();
                    return;
                }
                else if (txtbxname.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage("Please enter the name ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtbxname.Focus();
                    return;
                }
                else if (ddlsttype.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please select the type ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    ddlsttype.Focus();
                    return;
                }
                else if (ddlapplicantsame.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please Select Property Owner is same as Applicant", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (txttownship.Text == "")
                {
                    uscMsgBox1.AddMessage("Please Enter The TownShip", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (ddlapplicantsame.SelectedItem.Text == "No" && txtapladdress.Text == "")
                {
                    uscMsgBox1.AddMessage("Please Enter The Applicant Address", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            rpt.Close();
            rpt.Dispose();
            rpt = null;
            con.Close();
            GC.Collect();
        }

    }
    public void CLRSCR()
    {

        lbAppname.Text = "";
        lbPDdate.Text = "";
        lbLoanamt.Text = "";

        ddlApprv.Enabled = false;
        ddlReason.Enabled = false;
        btnSubmit.Enabled = false;
        btndraft.Enabled = false;
        btnCancel.Enabled = false;
        gvQuerypop.Visible = false;
        btnPreview.Enabled = false;

        ddlApprv.SelectedIndex = 0;
        ddlReason.SelectedIndex = 0;
        drpLawyerName.Items.Clear();
        drpLawyerName.Visible = false;
        lblLawterName.Visible = false;
        drpLawyerName.Items.Clear();
        drpLawyerName.Visible = false;
        lblLawterName.Visible = false;
        ddlLawyerType.SelectedIndex = 0;
        ddlLawyerType.Enabled = false;

        //BindqueryGrid();
        string _areaName = Convert.ToString(Session["AREANAME"]);
        BindqueryGrid(_areaName);
    }


    protected void gvlmdocs_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string tempdate = DataBinder.Eval(e.Row.DataItem, "MDX_OVSTAT").ToString();

            (e.Row.FindControl("ddlstlgldoctype") as DropDownList).SelectedValue = tempdate;

            string accp = DataBinder.Eval(e.Row.DataItem, "MDX_LSTAT").ToString();

            //if (accp == "N")
            //{
            //        e.Row.Visible = false;

            //}
            if (accp == "Y")
            {
                (e.Row.FindControl("chkbxaccept") as CheckBox).Checked = true;
                (e.Row.FindControl("chkbxaccept") as CheckBox).Enabled = true;
            }
            else if (accp == "N")
            {
                (e.Row.FindControl("chkbxaccept") as CheckBox).Checked = false;
                (e.Row.FindControl("chkbxaccept") as CheckBox).Enabled = true;
            }

            Char dateSplitter = new Char();
            string tempMdxdate = DataBinder.Eval(e.Row.DataItem, "MDX_DATE").ToString();
            Label lbdate = (Label)e.Row.FindControl("lbldate");

            if (tempMdxdate.Contains(".")) { dateSplitter = '.'; }
            else if (tempMdxdate.Contains("/")) { dateSplitter = '/'; }
            else if (tempMdxdate.Contains("-")) { dateSplitter = '-'; }

            //string[] dbarr = tempdate.Split('/');
            string[] dbarr = tempMdxdate.Split(dateSplitter);
            (e.Row.FindControl("lbldate") as Label).Text = dbarr[1].ToString() + "-" + dbarr[0].ToString() + "-" + dbarr[2].ToString();
        }
    }
    protected void btnaddT_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (txtbxtitleofopinion.Text.Length > 2000)
            {
                uscMsgBox1.AddMessage("Title of Opinion should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxtitleofopinion.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the title of opinion", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_TITLE='" + txtbxtitleofopinion.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["LeadId"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                uscMsgBox1.AddMessage("Title of Opinion added sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                #region Preview
                hdnPreview.Value = txtbxtitleofopinion.Text;
                #endregion
                btnaddT.Enabled = false;
            }
            else
            {
                uscMsgBox1.AddMessage("Title of Opinion not added", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                btnaddT.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }





    }
    protected void btnaddPD_Click(object sender, EventArgs e)
    {


        con = new SqlConnection(strcon);
        try
        {
            if (txtbxpropdetails.Text.Length > 500)
            {
                uscMsgBox1.AddMessage("Property Details should be less than 500 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxpropdetails.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the property details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_PROP_DET='" + txtbxpropdetails.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["LeadId"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                uscMsgBox1.AddMessage("Property Details added sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                #region Preview PD
                hdnPreviewP.Value = txtbxpropdetails.Text;
                #endregion
                btnaddPD.Enabled = false;
            }
            else
            {
                uscMsgBox1.AddMessage("Property Details not added", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

                btnaddPD.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }


    }
    protected void gvdocs_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string accp = DataBinder.Eval(e.Row.DataItem, "MDX_LSTAT").ToString();
            if (accp == "Y")
            {
                (e.Row.FindControl("chkbxaccept") as CheckBox).Checked = true;
                (e.Row.FindControl("chkbxaccept") as CheckBox).Enabled = true;
            }

            else if (accp == "N")
            {
                (e.Row.FindControl("chkbxaccept") as CheckBox).Checked = false;
                (e.Row.FindControl("chkbxaccept") as CheckBox).Enabled = false;
            }


            Char dateSplitter = new Char();
            string tempdate = DataBinder.Eval(e.Row.DataItem, "MDX_DATE").ToString();
            Label lbdate = (Label)e.Row.FindControl("lbldate");

            if (tempdate.Contains(".")) { dateSplitter = '.'; }
            else if (tempdate.Contains("/")) { dateSplitter = '/'; }
            else if (tempdate.Contains("-")) { dateSplitter = '-'; }

            //string[] dbarr = tempdate.Split('/');
            string[] dbarr = tempdate.Split(dateSplitter);
            (e.Row.FindControl("lbldate") as Label).Text = dbarr[1].ToString() + "-" + dbarr[0].ToString() + "-" + dbarr[2].ToString();
        }
    }

    public DataTable Docx(GridView gvlm)
    {
        DataTable passdt = new DataTable();
        try
        {

            DataRow dr = null;
            passdt.Columns.Add(new DataColumn("SLNO", typeof(int)));

            passdt.Columns.Add(new DataColumn("RSTAT", typeof(string)));

            foreach (GridViewRow grow in gvlmdocs.Rows)
            {

                Label sn = (Label)grow.FindControl("lblslno");

                string rst = (grow.FindControl("ddlstlgldoctype") as DropDownList).SelectedItem.Text;


                dr = passdt.NewRow();


                dr["SLNO"] = Convert.ToInt32(sn.Text);


                dr["RSTAT"] = rst;


                passdt.Rows.Add(dr);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }

        return passdt;
    }

    public string SLNOS()
    {
        Label lbl_slno = null;
        string slnos = "";
        foreach (GridViewRow grow in gvlmdocs.Rows)
        {
            CheckBox chkStat = grow.FindControl("chkbxaccept") as CheckBox;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {

                lbl_slno = (Label)gvlmdocs.Rows[index].Cells[0].FindControl("lblslno");
                if (slnos == "")
                    slnos = lbl_slno.Text + "|";
                else
                    slnos = slnos + "|" + lbl_slno.Text;
            }
        }


        return slnos;
    }
    protected void txtbxtitleofopinion_TextChanged(object sender, EventArgs e)
    {
        #region Preview
        if (txtbxtitleofopinion.Text != hdnPreview.Value)
            btnaddT.Enabled = true;
        #endregion
    }
    protected void txtbxpropdetails_TextChanged(object sender, EventArgs e)
    {
        #region Preview Property
        if (txtbxpropdetails.Text != hdnPreviewP.Value)
            btnaddPD.Enabled = true;
        #endregion
    }
    protected void btnaddT1_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (txtbxtitleofopinion1.Text.Length > 2000)
            {
                uscMsgBox1.AddMessage("Title of Opinion 2 should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxtitleofopinion1.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the title of opinion 2", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_TITLE2='" + txtbxtitleofopinion1.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["LeadId"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                uscMsgBox1.AddMessage("Title of Opinion 2 added sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                #region Preview
                hdnPreview1.Value = txtbxtitleofopinion1.Text;
                #endregion
                btnaddT1.Enabled = false;
            }
            else
            {
                uscMsgBox1.AddMessage("Title of Opinion 2 not added", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                btnaddT1.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }


    }
    protected void txtbxtitleofopinion1_TextChanged(object sender, EventArgs e)
    {
        #region Preview
        if (txtbxtitleofopinion1.Text != hdnPreview1.Value)
            btnaddT1.Enabled = true;
        #endregion
    }
    protected void gvencum_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    #region finalov delete
    protected void gvlmdocs_command(object sender, GridViewCommandEventArgs e)
    {
        string strVald;
        //string[] delete =(SLNOS()).Split("|");
        if (e.CommandName == "Delete")
        {

            strVald = e.CommandArgument.ToString();
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();

                try
                {
                    string sql = "Update LSD_MOTD_DOCX set MDX_DSTAT='N'  WHERE MDX_MD_ID=" + Convert.ToInt32(Session["MDIDA"].ToString()) + " and MDX_SLNO=" + Convert.ToInt32(strVald);


                    cmd = new SqlCommand(sql, con);

                    int r = cmd.ExecuteNonQuery();
                    if (r > 0)
                    {
                        BindAllGrid("D");
                        uscMsgBox1.AddMessage("Document  deleted successfully...", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Document not deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);

                    return;
                }
                finally
                {
                    cmd.Dispose();
                }
            }
        }
    }

    protected void gvlmdocs_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    #endregion




    protected void btnaddT3_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (txtbxtitleofopinion3.Text.Length > 2000)
            {
                uscMsgBox1.AddMessage("Title of Opinion 3 should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxtitleofopinion3.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the title of opinion 3", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_TITLE3='" + txtbxtitleofopinion3.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["LeadId"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                uscMsgBox1.AddMessage("Title of Opinion 3 added sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                #region Preview
                hdnPreview3.Value = txtbxtitleofopinion3.Text;
                #endregion
                btnaddT3.Enabled = false;
            }
            else
            {
                uscMsgBox1.AddMessage("Title of Opinion 3 not added", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                btnaddT3.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }

    }
    protected void btnaddT4_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (txtbxtitleofopinion4.Text.Length > 2000)
            {
                uscMsgBox1.AddMessage("Title of Opinion 4 should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxtitleofopinion4.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the title of opinion 4", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_TITLE4='" + txtbxtitleofopinion4.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["LeadId"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                uscMsgBox1.AddMessage("Title of Opinion 4 added sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                #region Preview
                hdnPreview4.Value = txtbxtitleofopinion4.Text;
                #endregion
                btnaddT4.Enabled = false;
            }
            else
            {
                uscMsgBox1.AddMessage("Title of Opinion 4 not added", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                btnaddT4.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }
    }
    protected void btnaddT5_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(strcon);
        try
        {
            if (txtbxtitleofopinion5.Text.Length > 2000)
            {
                uscMsgBox1.AddMessage("Title of Opinion 5 should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }
            if (txtbxtitleofopinion5.Text.Trim() == "")
            {
                uscMsgBox1.AddMessage("Please enter the title of opinion 5", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;

            }

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("UPDATE LSD_MOTD SET MD_TITLE5='" + txtbxtitleofopinion5.Text.Replace("'", "''").ToString() + "' WHERE MD_LD_ID=" + Session["LeadId"].ToString(), con);

            cmd.CommandTimeout = 12000;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                uscMsgBox1.AddMessage("Title of Opinion 5 added sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                #region Preview
                hdnPreview5.Value = txtbxtitleofopinion4.Text;
                #endregion
                btnaddT5.Enabled = false;
            }
            else
            {
                uscMsgBox1.AddMessage("Title of Opinion 5 not added", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                btnaddT5.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            cmd.Dispose();
            con.Close();
        }
    }
    protected void txtbxtitleofopinion3_TextChanged(object sender, EventArgs e)
    {
        #region Preview
        if (txtbxtitleofopinion3.Text != hdnPreview3.Value)
            btnaddT3.Enabled = true;
        #endregion
    }
    protected void txtbxtitleofopinion4_TextChanged(object sender, EventArgs e)
    {
        #region Preview
        if (txtbxtitleofopinion4.Text != hdnPreview4.Value)
            btnaddT4.Enabled = true;
        #endregion
    }
    protected void txtbxtitleofopinion5_TextChanged(object sender, EventArgs e)
    {
        #region Preview
        if (txtbxtitleofopinion5.Text != hdnPreview5.Value)
            btnaddT5.Enabled = true;
        #endregion
    }

    public void gridbind(string leadid)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_CREDIT_DOC", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CDX_LD_ID", leadid);
            cmd.Parameters.AddWithValue("@TYPE", "BIND");
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dsd);

            grvdoc.DataSource = dsd.Tables[0];
            grvdoc.DataBind();



        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }

    public void gridbindkyc()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            this.kyc.Visible = true;
            SqlCommand cmd = new SqlCommand("RTS_SP_KYC_DETAILS_FETCH", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add("@KYC_LD_ID", SqlDbType.VarChar).Value = lbLeadno.Text;
            cmd.Parameters.AddWithValue("@KYC_LD_ID", Session["LeadId"].ToString());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);

            GridView1.DataSource = ds1.Tables[0];
            GridView1.DataBind();
            if (ds1.Tables[0].Rows.Count > 0)
            {
                GridView1.HeaderRow.Font.Bold = true;
                GridView1.HeaderRow.Cells[0].Text = "NAME";
                GridView1.HeaderRow.Cells[1].Text = "APP TYPE";
                GridView1.HeaderRow.Cells[2].Text = "ID PROOF";
                GridView1.HeaderRow.Cells[3].Text = "ID PROOF NO";
                GridView1.HeaderRow.Cells[4].Text = "NAME IN ID PROOF";
                GridView1.HeaderRow.Cells[5].Text = "ADDR. MATCH";
                GridView1.HeaderRow.Cells[6].Text = "INCOME PROOF";
                GridView1.HeaderRow.Cells[7].Text = "DOB";
                GridView1.HeaderRow.Cells[8].Text = "DOB PROOF";

                GridView1.HeaderRow.Cells[0].Wrap = false;
                GridView1.HeaderRow.Cells[1].Wrap = false;
                GridView1.HeaderRow.Cells[2].Wrap = false;
                GridView1.HeaderRow.Cells[3].Wrap = false;
                GridView1.HeaderRow.Cells[4].Wrap = false;
                GridView1.HeaderRow.Cells[5].Wrap = false;
                GridView1.HeaderRow.Cells[6].Wrap = false;
                GridView1.HeaderRow.Cells[7].Wrap = false;
                GridView1.HeaderRow.Cells[8].Wrap = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Approval.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }

    protected void grvdoc_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void ddlapplicantsame_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlapplicantsame.SelectedItem.Text == "No")
            {
                this.appladd.Visible = true;
            }
            else
            {
                txtapladdress.Text = "";
                this.appladd.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }


}