﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Text.RegularExpressions;
using System.IO;
using Tracker;
using System.Threading;
public partial class Branch_KYC : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    DataSet dsrsn = new DataSet();
    SqlCommand cmd;
    ClsCommon clscommon = new ClsCommon();

    string fileName = string.Empty;
    string fileExt = string.Empty;
    string fileUploadPath = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnSubmit);


        if (!IsPostBack)
        {
            try
            {
                if (Session["ID"] != null)
                {
                    if (Session["USR_ACS"].ToString() == "7")
                    {
                        lblFileUpload.Visible = false;
                        fup_Challon.Visible = false;

                    }
                    else
                    {
                        lblFileUpload.Visible = true;
                        fup_Challon.Visible = true;
                    }
                    Session["update"] = Server.UrlEncode(System.DateTime.Now.ToString());
                    txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                    bindArea();
                    bind();
                    remarks.Visible = false;
                }
                else
                {
                    Response.Redirect("Expire.aspx");
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
        }

    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();
        //DataTable dtProduct = new DataTable();

        //dtProduct = dsdd.Tables[0];
        //  if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        //  {
        //      dtProduct = dsdd.Tables[0].Select("PR_CODE not like '%BL%'").CopyToDataTable();
        //  }
        //  else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "1")
        //  {
        //      dtProduct = dsdd.Tables[0];
        //  }
        //  else
        //  {
        //      dtProduct = dsdd.Tables[0].Select("PR_CODE  like '%BL%'").CopyToDataTable();
        //  }
        DataTable dtProduct = dsdd.Tables[0];
        if (Session["BRTYPE"].ToString() == "V" && Session["USR_ACS"].ToString() == "7")
        {
            // dtProduct = dsdd.Tables[0].Select("PR_CODE  LIKE  '%BL%'").CopyToDataTable();
            dtProduct = dsdd.Tables[0].Select("PR_ID IN (9,10,11,15,16,22,23,28,31)").CopyToDataTable();

        }
        else if (Session["BRTYPE"].ToString() == "R" && Session["USR_ACS"].ToString() == "7")
        {
            // dtProduct = dsdd.Tables[0].Select("PR_CODE NOT LIKE  '%BL%'").CopyToDataTable();
            dtProduct = dsdd.Tables[0].Select("PR_ID NOT IN (9,10,11,15,16,22,23,28,31)").CopyToDataTable();
        }

        ddlProduct.DataSource = dtProduct;
        ddlProduct.DataTextField = "PR_CODE";
        ddlProduct.DataValueField = "PR_ID";
        ddlProduct.DataBind();
        ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow grow in gvBranchSF.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                Label lnbtn = grow.FindControl("lblLeadID") as Label;

                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    lbLeadno.Text = lnbtn.Text;
                    Session["leadno"] = grow.Cells[1].Text;
                    Session["LoanAmount"] = grow.Cells[5].Text;
                    if (grow.Cells[1].Text.Contains("TWL"))
                    {
                        trTWL2.Visible = true;
                        trTWL1.Visible = true;
                    }
                    else
                    {
                        trTWL2.Visible = false;
                        trTWL1.Visible = false;
                        txtbxref1name.Text = "";
                        txtbxref1contactno.Text = "";
                        txtbxref1addr.Text = "";

                        txtbxref2name.Text = "";
                        txtbxref2contactno.Text = "";
                        txtbxref2addr.Text = "";

                        rdnCibilYes.Checked = false;
                        rdnCibilNo.Checked = false;

                        rdnHMYes.Checked = false;
                        rdnHMNo.Checked = false;

                        rdnDDYes.Checked = false;
                        rdnDDNo.Checked = false;
                        txtAddrProofNo.Text = "";
                        txtDOBProofNo.Text = "";
                    }

                    /*  if (Session["leadno"] != null)
                      {
                          if (Session["leadno"].ToString().Contains("BL"))
                          {
                              dvfileUpld.Visible = true;
                          }
                          else
                          {
                              dvfileUpld.Visible = false;
                          }
                      }*/
                }
            }
            ProofID();
            BindApplicants();
            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;
            remarks.Visible = true;
            gridbind1();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindApplicants()
    {
        string strProd = "R";
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        if (Session["leadno"] != null)
        {
            if (Session["leadno"].ToString().Contains("TWL"))
            {
                strProd = "T";
            }
        }
        SqlCommand cmdrsn = new SqlCommand("select APP_ID,APP_DESC from MR_APPLICANT WHERE APP_TYPE='" + strProd + "' ORDER BY APP_DESC", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        DDLType.DataSource = dsrsn;
        DDLType.DataTextField = "APP_DESC";
        DDLType.DataValueField = "APP_ID";
        DDLType.DataBind();
        DDLType.Items.Insert(0, new ListItem("--Select--", ""));





    }

    protected void rb_select_CheckedChanged1(object sender, EventArgs e)
    {
        if (DDLType.SelectedItem.Text == "Applicant")
        {
            txt_RatonCard.Enabled = true;
            //reqtxtSameAdAadharCardNumber.Enabled=true;
            //regexSameAdAadharcardnumber.Enabled = true;
        }
        else
        {
            txt_RatonCard.Enabled = false;
            txt_RatonCard.Text = "";
            //reqtxtSameAdAadharCardNumber.Enabled = false;
            //regexSameAdAadharcardnumber.Enabled = false;
        }
    }
    public void ProofID()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select (convert(varchar(50),PF_ID) +'-'+ PF_FLG) PF_ID ,PF_DESC,PF_PR_ID,PF_TYPE,PF_FLG from MR_PROOF", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();
        string strProdID = "";
        if (Session["leadno"].ToString().Contains("LAP"))
        {
            strProdID = "1";
        }
        else if (Session["leadno"].ToString().Contains("SME"))
        {
            strProdID = "2";
        }
        else if (Session["leadno"].ToString().Contains("MHF"))
        {
            strProdID = "3";
        }
        else if (Session["leadno"].ToString().Contains("GLP"))
        {
            strProdID = "5";
        }
        else if (Session["leadno"].ToString().Contains("GHF"))
        {
            strProdID = "4";
        }
        else if (Session["leadno"].ToString().Contains("EHF"))
        {
            if (Session["LoanAmount"] != null)
            {
                if (Convert.ToInt32(Session["LoanAmount"]) <= 500000)
                {
                    strProdID = "3";
                }
                else
                {
                    strProdID = "4";

                }
            }

        }
        else if (Session["leadno"].ToString().Contains("ELP"))
        {
            if (Session["LoanAmount"] != null)
            {
                if (Convert.ToInt32(Session["LoanAmount"]) <= 500000)
                {
                    strProdID = "1";
                }
                else
                {
                    strProdID = "5";

                }
            }

        }
        else
        {
            strProdID = "1";
        }
        DataTable dtIdproof;
        DataRow[] drIdproof = dsrsn.Tables[0].Select("PF_PR_ID=" + strProdID + " AND PF_TYPE ='ID'");
        dtIdproof = drIdproof.CopyToDataTable();


        DDLIdProof.DataSource = dtIdproof;

        DataTable dtBithproof;
        DataRow[] drBithproof = dsrsn.Tables[0].Select("PF_PR_ID=" + strProdID + " AND PF_TYPE ='AGE'");
        dtBithproof = drBithproof.CopyToDataTable();

        DDLbirthidproof.DataSource = dtBithproof;

        DataTable dtAdressproof;
        DataRow[] drAdressproof = dsrsn.Tables[0].Select("PF_PR_ID=" + strProdID + " AND PF_TYPE ='ADDRESS'");
        dtAdressproof = drAdressproof.CopyToDataTable();
        DDLAddrProof.DataSource = dtAdressproof;

        DataTable dtIncomeproof;
        DataRow[] drIncomeproof = dsrsn.Tables[0].Select("PF_PR_ID=" + strProdID + " AND PF_TYPE ='INCOME'");
        dtIncomeproof = drIncomeproof.CopyToDataTable();
        DDLIncomeProof.DataSource = dtIncomeproof;
        DDLbirthidproof.DataTextField = "PF_DESC";
        DDLbirthidproof.DataValueField = "PF_ID";
        DDLbirthidproof.DataBind();
        DDLbirthidproof.Items.Insert(0, new ListItem("--Select--", ""));
        DDLIdProof.DataTextField = "PF_DESC";
        DDLIdProof.DataValueField = "PF_ID";
        DDLIdProof.DataBind();
        DDLIdProof.Items.Insert(0, new ListItem("--Select--", ""));
        DDLAddrProof.DataTextField = "PF_DESC";
        DDLAddrProof.DataValueField = "PF_ID";
        DDLAddrProof.DataBind();
        DDLAddrProof.Items.Insert(0, new ListItem("--Select--", ""));
        DDLIncomeProof.DataTextField = "PF_DESC";
        DDLIncomeProof.DataValueField = "PF_ID";
        DDLIncomeProof.DataBind();
        DDLIncomeProof.Items.Insert(0, new ListItem("--Select--", ""));

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_kyc.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        if (ddlArea.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("please select area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            gridbind();
        }
    }
    public void gridbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_KYC_FETCH", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@LD_PR_ID", SqlDbType.VarChar).Value = ddlProduct.SelectedItem.Text != "--Select--" ? ddlProduct.SelectedValue.ToString() : "";
            cmd.Parameters.Add("@LD_BR_ID", SqlDbType.VarChar).Value = ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue : "";
            cmd.Parameters.Add("@LD_AR_ID", SqlDbType.VarChar).Value = ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue : "";
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            DataTable dtGrid = ds.Tables[0];
            if (dtGrid.Rows.Count > 0)
            {

                if (Session["BRTYPE"].ToString() == "R" && Session["USR_ACS"].ToString() == "7")
                {
                    //dtGrid = ds.Tables[0].Select("PR_CODE NOT  LIKE  '%BL%'").CopyToDataTable();
                    dtGrid = dtGrid.Select("PR_ID NOT IN (9,10,11,15,16,22,23,28,31)").CopyToDataTable();
                }
                else if (Session["USR_ACS"].ToString() == "1")
                {
                    dtGrid = ds.Tables[0];
                }
                else
                    if (Session["BRTYPE"].ToString() == "V" && Session["USR_ACS"].ToString() == "7")
                {
                    //dtGrid = ds.Tables[0].Select("PR_CODE   LIKE  '%BL%'").CopyToDataTable();
                    dtGrid = dtGrid.Select("PR_ID IN (9,10,11,15,16,22,23,28,31)").CopyToDataTable();
                }
            }

            gvBranchSF.DataSource = dtGrid;
            gvBranchSF.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvBranchSF.HeaderRow.Font.Bold = true;
                //gvBranchSF.HeaderRow.Cells[1].Text = "LEAD NO";
                //gvBranchSF.HeaderRow.Cells[2].Text = "LEAD DATE";
                //gvBranchSF.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                //gvBranchSF.HeaderRow.Cells[4].Text = "PD DATE";
                //gvBranchSF.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvBranchSF.HeaderRow.Cells[1].Wrap = false;
                gvBranchSF.HeaderRow.Cells[2].Wrap = false;
                gvBranchSF.HeaderRow.Cells[3].Wrap = false;
                gvBranchSF.HeaderRow.Cells[4].Wrap = false;
                gvBranchSF.HeaderRow.Cells[5].Wrap = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind1()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_KYC_DETAILS_FETCH", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@KYC_LD_ID", SqlDbType.VarChar).Value = lbLeadno.Text;
            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);

            GridView1.DataSource = ds1.Tables[0];
            GridView1.DataBind();
            if (ds1.Tables[0].Rows.Count > 0)
            {
                GridView1.HeaderRow.Font.Bold = true;
                GridView1.HeaderRow.Cells[0].Text = "NAME";
                GridView1.HeaderRow.Cells[1].Text = "APP TYPE";
                GridView1.HeaderRow.Cells[2].Text = "ID PROOF";
                GridView1.HeaderRow.Cells[3].Text = "ID PROOF NO";
                GridView1.HeaderRow.Cells[4].Text = "NAME IN ID PROOF";
                GridView1.HeaderRow.Cells[5].Text = "ADDR. MATCH";
                GridView1.HeaderRow.Cells[6].Text = "INCOME PROOF";
                GridView1.HeaderRow.Cells[7].Text = "DOB";
                GridView1.HeaderRow.Cells[8].Text = "DOB PROOF";

                GridView1.HeaderRow.Cells[0].Wrap = false;
                GridView1.HeaderRow.Cells[1].Wrap = false;
                GridView1.HeaderRow.Cells[2].Wrap = false;
                GridView1.HeaderRow.Cells[3].Wrap = false;
                GridView1.HeaderRow.Cells[4].Wrap = false;
                GridView1.HeaderRow.Cells[5].Wrap = false;
                GridView1.HeaderRow.Cells[6].Wrap = false;
                GridView1.HeaderRow.Cells[7].Wrap = false;
                GridView1.HeaderRow.Cells[8].Wrap = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Branch_KYC.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        DateTime dtd;
        string[] IdProof = null;
        string[] AddrProof = null;
        string[] IncomeProof = null;
        string[] birthidproof = null;

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            Page.Validate();
            if (Page.IsValid)
            {
                try
                {

                    dtd = DateTime.ParseExact(TxtDOB.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                    int app_type_cnt = clscommon.Is_Applicant_Already_KYC(DDLType.SelectedItem.Text, lbLeadno.Text);

                    if (DDLType.SelectedItem.Text == "Applicant" && txt_RatonCard.Text == "")
                    {
                        uscMsgBox1.AddMessage("Please Enter Ration Card No", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                    else if (Session["leadno"].ToString().Contains("TWL") && (txtAddr.Text == "" || txtCont.Text == ""))
                    {
                        uscMsgBox1.AddMessage("Address and Contact  are mandatory !", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                    else if (Session["leadno"].ToString().Contains("TWL") && DDLType.SelectedItem.Text == "Applicant" && rdnCibilYes.Checked == false && rdnCibilNo.Checked == false)
                    {
                        uscMsgBox1.AddMessage("CIBIL is mandatory !", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                    else if (Session["leadno"].ToString().Contains("TWL") && DDLType.SelectedItem.Text == "Applicant" && rdnHMYes.Checked == false && rdnHMNo.Checked == false)
                    {
                        uscMsgBox1.AddMessage("High mark is mandatory !", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                    else if (Session["leadno"].ToString().Contains("TWL") && DDLType.SelectedItem.Text == "Applicant" && rdnDDYes.Checked == false && rdnDDNo.Checked == false)
                    {
                        uscMsgBox1.AddMessage("DEDUP is mandatory !", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }

                    else if (Session["leadno"].ToString().Contains("TWL") && DDLType.SelectedItem.Text == "Applicant" && (txtbxref1name.Text == "" || txtbxref1contactno.Text == "" || txtbxref1addr.Text == "" || txtbxref2name.Text == "" || txtbxref2contactno.Text == "" || txtbxref2addr.Text == ""))
                    {
                        uscMsgBox1.AddMessage("Reference 1 and Reference 2 are mandatory !", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                    else if (app_type_cnt > 0)
                    {
                        uscMsgBox1.AddMessage("You are selected " + DDLType.SelectedItem.Text + " type already added in the applicant details.Please select some other applicant type to add the details", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                    else if (ddlKYCSex.SelectedItem.Text == "--Select--")
                    {
                        uscMsgBox1.AddMessage("Please select the sex", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                    else if (fup_Challon.HasFile)
                    {
                        fileName = fup_Challon.PostedFile.FileName;
                        fileExt = Path.GetExtension(fileName);

                        //restrict user to upload only Excel files
                        if (fileExt != AppConstants.FileType_Excel_Old && fileExt != AppConstants.FileType_Excel_New)
                        {
                            uscMsgBox1.AddMessage("Please Upload Only Excel Files", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        }
                    }
                    else
                    {
                        if (Session["USR_ACS"].ToString() != "7")
                        {
                            if (fup_Challon.HasFile)
                            {
                                fileExt = Path.GetExtension(fup_Challon.PostedFile.FileName);
                                fileName = AppConstants.FileNamePrefix_CAM + Session["leadno"].ToString() + fileExt;
                                fileUploadPath = ConfigurationManager.AppSettings[AppConstants.FileUploadPath] + "\\" + fileName;
                                fup_Challon.SaveAs(Server.MapPath(fileUploadPath));
                            }
                        }

                        if (DDLIdProof.SelectedItem.Text != "--Select--")
                        {
                            IdProof = DDLIdProof.SelectedItem.Value.Split('-');
                        }
                        if (DDLAddrProof.SelectedItem.Text != "--Select--")
                        {
                            AddrProof = DDLAddrProof.SelectedItem.Value.Split('-');
                        }
                        if (DDLIncomeProof.SelectedItem.Text != "--Select--")
                        {
                            IncomeProof = DDLIncomeProof.SelectedItem.Value.Split('-');
                        }
                        if (DDLbirthidproof.SelectedItem.Text != "--Select--")
                        {
                            birthidproof = DDLbirthidproof.SelectedItem.Value.Split('-');
                        }

                        con.Open();
                        SqlCommand cmd = new SqlCommand("RTS_SP_KYC_DETAILS", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@KYC_LD_ID", SqlDbType.VarChar).Value = lbLeadno.Text;
                        cmd.Parameters.Add("@KYC_ID_NO", SqlDbType.VarChar).Value = TxtIDproof.Text.Replace(" ", "").ToUpper();
                        cmd.Parameters.Add("@KYC_NAME", SqlDbType.VarChar).Value = TxtName.Text.ToUpper();
                        cmd.Parameters.Add("@KYC_APPTYPE", SqlDbType.VarChar).Value = DDLType.SelectedValue.ToString();
                        cmd.Parameters.Add("@KYC_ID_PF_ID", SqlDbType.VarChar).Value = DDLIdProof.SelectedItem.Text != "--Select--" ? Convert.ToInt32(IdProof[0]) : (object)DBNull.Value;
                        cmd.Parameters.Add("@KYC_ID_NAME", SqlDbType.VarChar).Value = Txt.Text.ToUpper();
                        cmd.Parameters.Add("@KYC_ADD_MATCH", SqlDbType.VarChar).Value = DDLAddMatch.SelectedItem.Text != "--Select--" ? DDLAddMatch.SelectedValue : "";
                        cmd.Parameters.Add("@KYC_INC_PF_ID", SqlDbType.VarChar).Value = DDLIncomeProof.SelectedItem.Text != "--Select--" ? Convert.ToInt32(IncomeProof[0]) : (object)DBNull.Value;
                        cmd.Parameters.Add("@KYC_DOB", SqlDbType.VarChar).Value = dtd;
                        cmd.Parameters.Add("@KYC_DOB_PF_ID", SqlDbType.VarChar).Value = DDLbirthidproof.SelectedItem.Text != "--Select--" ? Convert.ToInt32(birthidproof[0]) : (object)DBNull.Value;
                        cmd.Parameters.Add("@KYC_RC_NO", SqlDbType.VarChar).Value = txt_RatonCard.Text.ToString();
                        cmd.Parameters.Add("@KYC_ADDR_PF_ID", SqlDbType.VarChar).Value = DDLAddrProof.SelectedItem.Text != "--Select--" ? Convert.ToInt32(AddrProof[0]) : (object)DBNull.Value;
                        cmd.Parameters.Add("@KYC_CBY", SqlDbType.VarChar).Value = Session["ID"] != null ? Session["ID"].ToString() : "";
                        cmd.Parameters.Add("@KYC_ADDR", SqlDbType.VarChar).Value = txtAddr.Text;
                        cmd.Parameters.Add("@KYC_CONTACT", SqlDbType.VarChar).Value = txtCont.Text;

                        string strCIBIL = "";
                        if (rdnCibilYes.Checked)
                        {
                            strCIBIL = "Y";
                        }
                        else if (rdnCibilNo.Checked)
                        {
                            strCIBIL = "N";
                        }
                        cmd.Parameters.Add("@KYC_CIBIL", SqlDbType.VarChar).Value = strCIBIL;

                        string strHmark = "";
                        if (rdnHMYes.Checked)
                        {
                            strHmark = "Y";
                        }
                        else if (rdnHMNo.Checked)
                        {
                            strHmark = "N";
                        }
                        cmd.Parameters.Add("@KYC_HMARK", SqlDbType.VarChar).Value = strHmark;
                        string strDEDUP = "";
                        if (rdnDDYes.Checked)
                        {
                            strDEDUP = "Y";
                        }
                        else if (rdnDDNo.Checked)
                        {
                            strDEDUP = "N";
                        }
                        cmd.Parameters.Add("@KYC_DEDUP", SqlDbType.VarChar).Value = strDEDUP;
                        cmd.Parameters.Add("@KYC_REF1_NAME", SqlDbType.VarChar).Value = txtbxref1name.Text;
                        cmd.Parameters.Add("@KYC_REF1_ADDR", SqlDbType.VarChar).Value = txtbxref1addr.Text;
                        cmd.Parameters.Add("@KYC_REF1_CONTACT", SqlDbType.VarChar).Value = txtbxref1contactno.Text;
                        cmd.Parameters.Add("@KYC_REF2_NAME", SqlDbType.VarChar).Value = txtbxref2name.Text;
                        cmd.Parameters.Add("@KYC_REF2_ADDR", SqlDbType.VarChar).Value = txtbxref2addr.Text;
                        cmd.Parameters.Add("@KYC_REF2_CONTACT", SqlDbType.VarChar).Value = txtbxref2contactno.Text;
                        cmd.Parameters.Add("@KYC_ADD_PF_NO", SqlDbType.NVarChar).Value = txtAddrProofNo.Text;
                        cmd.Parameters.Add("@KYC_DOB_PF_NO", SqlDbType.NVarChar).Value = txtDOBProofNo.Text;
                        cmd.Parameters.Add("@KYC_AADHAR_ID", SqlDbType.NVarChar).Value = txtAadhaarCard.Text;
                        cmd.Parameters.Add("@KYC_SEX", SqlDbType.NVarChar).Value = ddlKYCSex.SelectedValue;

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(ds);

                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    uscMsgBox1.AddMessage("Invalid Date format. Please check the date (dd/mm/yyyy)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    btnSubmit.Enabled = true;
                    btnCancel.Enabled = true;
                    remarks.Visible = true;

                    return;
                }


                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (ds.Tables[0].Rows[0][0].ToString().Contains("Added Successfully"))
                    {
                        uscMsgBox1.AddMessage("KYC Details added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        TxtName.Text = "";
                        TxtIDproof.Text = "";
                        Txt.Text = "";
                        TxtDOB.Text = "";
                        txt_RatonCard.Text = "";
                        gridbind1();
                        btnSubmit.Enabled = true;
                        btnCancel.Enabled = true;
                        remarks.Visible = true;
                        DDLIdProof.SelectedIndex = 0;
                        DDLType.SelectedIndex = 0;
                        DDLAddMatch.SelectedIndex = 0;
                        DDLbirthidproof.SelectedIndex = 0;
                        DDLIncomeProof.SelectedIndex = 0;
                        DDLAddrProof.SelectedIndex = 0;
                        txtbxref1name.Text = "";
                        txtbxref1contactno.Text = "";
                        txtbxref1addr.Text = "";
                        txtAddr.Text = "";
                        txtCont.Text = "";
                        txtbxref2name.Text = "";
                        txtbxref2contactno.Text = "";
                        txtbxref2addr.Text = "";
                        txtDOBProofNo.Text = "";
                        txtAddrProofNo.Text = "";
                        txtAadhaarCard.Text = "";
                        rdnCibilYes.Checked = false;
                        rdnCibilNo.Checked = false;
                        ddlKYCSex.SelectedIndex = 0;
                        rdnHMYes.Checked = false;
                        rdnHMNo.Checked = false;

                        rdnDDYes.Checked = false;
                        rdnDDNo.Checked = false;
                        TxtIDproof.Enabled = true;
                        txtAddrProofNo.Enabled = true;
                        txtDOBProofNo.Enabled = true;
                    }
                    if (ds.Tables[0].Rows[0][0].ToString().Contains("Same ID,Proof Name Already Existing"))
                    {
                        uscMsgBox1.AddMessage(ds.Tables[0].Rows[0][0].ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        btnSubmit.Enabled = true;
                        btnCancel.Enabled = true;
                        remarks.Visible = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;
            remarks.Visible = true;
        }
        finally
        {
            con.Close();
        }
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        ddlProduct.SelectedIndex = 0;

    }

    protected void ddlbranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlProduct.SelectedIndex = 0;
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Delete")
        {
            string strVald = e.CommandArgument.ToString();
            //ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('" + strVald + "');", true);

            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();
                try
                {
                    string sql = "DELETE FROM LSD_KYC WHERE KYC_ID=" + Convert.ToInt32(strVald);

                    cmd = new SqlCommand(sql, connection);

                    int r = cmd.ExecuteNonQuery();
                    if (r > 0)
                    {
                        uscMsgBox1.AddMessage("KYC Name deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        gridbind1();
                        remarks.Visible = true;
                        // CLear();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Document not deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    return;
                }
                finally
                {
                    cmd.Dispose();
                }
            }
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void DDLIdProof_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string[] IdProof = DDLIdProof.SelectedItem.Value.Split('-');
            TxtIDproof.Text = "";
            if (Convert.ToString(IdProof[1]) == "N")
            {
                TxtIDproof.Enabled = false;
            }
            else
            {
                TxtIDproof.Enabled = true;
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);

            return;
        }
    }

    protected void DDLAddrProof_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string[] AddrProof = DDLAddrProof.SelectedItem.Value.Split('-');
            txtAddrProofNo.Text = "";
            if (Convert.ToString(AddrProof[1]) == "N")
            {
                txtAddrProofNo.Enabled = false;
            }
            else
            {
                txtAddrProofNo.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);

            return;
        }
    }

    protected void DDLbirthidproof_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string[] birthidproof = DDLbirthidproof.SelectedItem.Value.Split('-');
            txtDOBProofNo.Text = "";
            if (Convert.ToString(birthidproof[1]) == "N")
            {
                txtDOBProofNo.Enabled = false;
            }
            else
            {
                txtDOBProofNo.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);

            return;
        }
    }

}