﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class Credit_Compliance_Review : System.Web.UI.Page
{


    DataTable dtKYC, CreditApparaisal;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    string StrStautscob = "Y";
    bool blStatus = false;
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                bindArea();
                this.Compliant.Visible = false;
                this.Compliant1.Visible = false;
                this.compliant2.Visible = false;
                this.compliant4.Visible = false;
                this.compliant6.Visible = false;
                this.compliant7.Visible = false;
                this.compliant8.Visible = false;
                this.compliant9.Visible = false;
                this.compliant10.Visible = false;
                //this.btnSubmit.Visible = false;
                //this.btnCancel.Visible = false;



            }
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--" && txtLeadno.Text == "")
        {
            gvRecvsend.Visible = true;
            Session["View"] = "All";
            //    gridbindall();
            BindSendReceiveGrid();

            if (gvRecvsend.Rows.Count > 0)
                this.Compliant.Visible = true;
            else
                this.Compliant.Visible = false;

        }
        //else if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--" && txtLeadno.Text != "")
        //{
        //    gvRecvsend.Visible = true;
        //    Session["View"] = "All";
        //    //    gridbindall();
        //    BindSendReceiveGrid();

        //    if (gvRecvsend.Rows.Count > 0)
        //        this.Compliant.Visible = true;
        //    else
        //        this.Compliant.Visible = false;
        //}



        else
        {
            gvRecvsend.Visible = true;
            Session["View"] = "F";
            //  gridbind();
            BindSendReceiveGrid();

            if (gvRecvsend.Rows.Count > 0)
                this.Compliant.Visible = true;
            else
                this.Compliant.Visible = false;
            this.Compliant1.Visible = false;
            this.compliant2.Visible = false;
            this.compliant4.Visible = false;
            this.compliant6.Visible = false;
            this.compliant7.Visible = false;
            this.compliant8.Visible = false;
            this.compliant9.Visible = false;
            this.compliant10.Visible = false;
            //this.btnCancel.Visible = false;
            //this.btnSubmit.Visible = false;
        }


    }
    public void BindSendReceiveGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_CR_ComplianceReview_NEW18", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@Process", "C");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            gvRecvsend.DataSource = ds.Tables[0];
            gvRecvsend.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvRecvsend.Visible = true;
                gvRecvsend.HeaderRow.Font.Bold = true;
                gvRecvsend.HeaderRow.Cells[1].Text = "STATE";
                gvRecvsend.HeaderRow.Cells[2].Text = "AREA";
                gvRecvsend.HeaderRow.Cells[3].Text = "BRANCH NAME";
                gvRecvsend.HeaderRow.Cells[4].Text = "PRODUCT";
                gvRecvsend.HeaderRow.Cells[5].Text = "LEAD NO";
                gvRecvsend.HeaderRow.Cells[6].Text = "APPLICANT NAME";


                gvRecvsend.HeaderRow.Cells[1].Wrap = false;
                gvRecvsend.HeaderRow.Cells[2].Wrap = false;
                gvRecvsend.HeaderRow.Cells[3].Wrap = false;
                gvRecvsend.HeaderRow.Cells[4].Wrap = false;
                gvRecvsend.HeaderRow.Cells[5].Wrap = false;
                gvRecvsend.HeaderRow.Cells[6].Wrap = false;
            }


        }

        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);

        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        // ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlBranch.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        //if (Session["USR_ACS"].ToString() == "7")
        //{
        ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
        ddlBranch.Enabled = true;
        ddlArea.Enabled = true;
        //}
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));


    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {

        foreach (GridViewRow grow in gvRecvsend.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            Label lnbtn = grow.FindControl("lblLeadID") as Label;
            Label lblEMPName = grow.FindControl("lblEMPName") as Label;
            Label lblEMPName1 = grow.FindControl("lbl_amt") as Label;
            Label lblEMPName2 = grow.FindControl("lbl_date") as Label;

            int index = grow.RowIndex;
            if (chkStat.Checked)
            {


                approvedby.Text = lblEMPName.Text + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Rs." + lblEMPName1.Text + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + lblEMPName2.Text;
                lbLeadno.Text = lnbtn.Text;
                Session["leadno"] = grow.Cells[1].Text;
            }
        }
        this.Compliant1.Visible = true;
        this.compliant2.Visible = true;
        this.compliant4.Visible = true;
        this.compliant6.Visible = true;
        this.compliant7.Visible = true;
        this.compliant8.Visible = true;
        this.compliant9.Visible = true;
        this.compliant10.Visible = true;
        //this.btnCancel.Visible = true;
        //this.btnSubmit.Visible = true;

        lbl_date.Text = String.Format("{0:dd-MMM-yyyy hh:mm tt}", dt);


        lbl_noreview.Text = Session["User"].ToString().ToUpper();
        Panel2.Visible = true;
        gridbind1();
        Panel3.Visible = true;
        Credit_AppraisalConduct();

    }
    protected void checkStatus_selectedChanged()
    {
        foreach (GridViewRow grow1 in GridView1.Rows)
        {
            RadioButton chkNotOK = grow1.FindControl("rb_NotOK") as RadioButton;
            RadioButton chkOK = grow1.FindControl("rb_OK") as RadioButton;

            if (chkNotOK.Checked == true)
            {
                blStatus = true;
                break;
            }
        }
        foreach (GridViewRow grow2 in Credit_Appraisal.Rows)
        {
            RadioButton chkappNotOK = grow2.FindControl("rb_APPNotOK") as RadioButton;
            RadioButton chkaappOK = grow2.FindControl("rb_APPNotOK") as RadioButton;

            if (chkappNotOK.Checked == true)
            {
                if (chkappNotOK.Text != "Non Member")
                {
                    blStatus = true;
                    break;
                }
            }
        }
        if (blStatus == true)
        {
            lblresultstatus.Text = "NOT OK";
        }
        else
        {
            lblresultstatus.Text = "OK";
        }

    }
    public void gridbind1()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_KYC_DETAILS_FETCH", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@KYC_LD_ID", SqlDbType.VarChar).Value = lbLeadno.Text;
            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);

            GridView1.DataSource = ds1.Tables[0];
            GridView1.DataBind();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Credit_Compliance_Review.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    private DataTable BindKycTable()
    {
        dtKYC = new DataTable();
        dtKYC.Columns.Add("KYC_ID", typeof(int));
        dtKYC.Columns.Add("KYC_STATUS", typeof(string));
        dtKYC.Columns.Add("CMND", typeof(string));
        int n = 0;
        foreach (GridViewRow grow in GridView1.Rows)
        {
            string StrStauts = "", strComnd1 = "";
            n = n + 1;
            Label lbl_kycid = grow.FindControl("kyc_id") as Label;
            RadioButton chkOK = grow.FindControl("rb_OK") as RadioButton;
            RadioButton chkNotOK = grow.FindControl("rb_NotOK") as RadioButton;
            TextBox txtComnds = grow.FindControl("txt_comments") as TextBox;
            strComnd1 = txtComnds.Text;
            if (chkNotOK.Checked)
            {
                StrStauts = "N";
            }
            else if (chkOK.Checked)
            {
                StrStauts = "Y";
            }
            if (StrStauts != "")
            {
                DataRow row1 = dtKYC.NewRow();
                row1["KYC_ID"] = lbl_kycid.Text;
                row1["KYC_STATUS"] = StrStauts;
                row1["CMND"] = strComnd1;
                dtKYC.Rows.Add(row1);
            }
        }
        return dtKYC;
    }
    private DataTable BindCR_Apparaisal()
    {
        CreditApparaisal = new DataTable();
        CreditApparaisal.Columns.Add("CAP_CC_ID", typeof(int));
        CreditApparaisal.Columns.Add("CAP_STATUS", typeof(string));
        CreditApparaisal.Columns.Add("CAP_CMTS", typeof(string));
        int n = 0;
        foreach (GridViewRow grow1 in Credit_Appraisal.Rows)
        {
            string StrStauts1 = "", strComnd = "";
            n = n + 1;
            Label lblcrd = grow1.FindControl("lbl_cred") as Label;
            RadioButton chkOK = grow1.FindControl("rb_APPOK") as RadioButton;
            RadioButton chkNotOK = grow1.FindControl("rb_APPNotOK") as RadioButton;
            TextBox txtAppComnds = grow1.FindControl("txt_APPcomments") as TextBox;
            strComnd = txtAppComnds.Text;
            if (chkNotOK.Checked)
            {
                StrStauts1 = "N";
            }
            else if (chkOK.Checked)
            {
                StrStauts1 = "Y";
            }
            if (StrStauts1 != "")
            {
                DataRow row1 = CreditApparaisal.NewRow();
                row1["CAP_CC_ID"] = lblcrd.Text;
                row1["CAP_STATUS"] = StrStauts1;
                row1["CAP_CMTS"] = strComnd;
                CreditApparaisal.Rows.Add(row1);
            }
        }
        return CreditApparaisal;
    }
    public void Credit_AppraisalConduct()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();


            SqlCommand cmd = new SqlCommand("select * from MR_CR_APPRAISAL", con);

            SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);

            Credit_Appraisal.DataSource = ds1.Tables[0];
            Credit_Appraisal.DataBind();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Credit_Compliance_Review.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    protected void rb_CR_AppraisalOK_CheckedChanged(object sender, EventArgs e)
    {
        foreach (GridViewRow grow2 in Credit_Appraisal.Rows)
        {
            RadioButton chkAPPOK = grow2.FindControl("rb_APPOK") as RadioButton;
            TextBox txt_Appcments = grow2.FindControl("txt_APPcomments") as TextBox;
            RadioButton chkAPPNotOK = grow2.FindControl("rb_APPNotOK") as RadioButton;
            Label lbleq = grow2.FindControl("lblCCDesc") as Label;
            
          
            
            if (chkAPPOK.Checked == true && lbleq.Text.Trim() == "Relationship with Equitas")
            {
                txt_Appcments.Visible = false;
                

            }
            else if (chkAPPOK.Checked == true && lbleq.Text.Trim() != "Relationship with Equitas") { txt_Appcments.Visible = true; txt_Appcments.Text = ""; }

        }

        checkStatus_selectedChanged();
    }
    protected void rbCR_AppraisalNotOK_CheckedChanged(object sender, EventArgs e)
    {

        lblresultstatus.Text = "";

        foreach (GridViewRow grow2 in Credit_Appraisal.Rows)
        {
            Label lbleq = grow2.FindControl("lblCCDesc") as Label;
            RadioButton chkAPPNotOK = grow2.FindControl("rb_APPNotOK") as RadioButton;
            RadioButton chkAPPOK = grow2.FindControl("rb_APPOK") as RadioButton;
            TextBox txt_Appcments = grow2.FindControl("txt_APPcomments") as TextBox;
            //txt_Appcments.Visible = true;
            if (chkAPPNotOK.Checked == true && lbleq.Text.Trim() == "Relationship with Equitas")
            {
                txt_Appcments.Visible = false;
            }
           else if (chkAPPNotOK.Checked == true && lbleq.Text.Trim() != "Relationship with Equitas") { txt_Appcments.Visible = true;  }
            checkStatus_selectedChanged();
        }


    }
    protected bool filestatus()
    {
        bool blCondition = false;
        //lblresultstatus.Text = "";
        foreach (GridViewRow gvKYC in GridView1.Rows)
        {
            RadioButton chkNotOK = gvKYC.FindControl("rb_NotOK") as RadioButton;
            RadioButton chkOK = gvKYC.FindControl("rb_OK") as RadioButton;
            TextBox txt_cments = gvKYC.FindControl("txt_comments") as TextBox;

            if (chkNotOK.Checked == true && txt_cments.Text.Trim() == "" )
            {

             
                blCondition = true;
                break;
            }
            if (chkNotOK.Checked == false && chkOK.Checked == false)
            {
                blCondition = true;
                break;
            }


        }
       

        foreach (GridViewRow grow2 in Credit_Appraisal.Rows)
        {
            RadioButton chkAPPNotOK = grow2.FindControl("rb_APPNotOK") as RadioButton;
            RadioButton chkAPPOK = grow2.FindControl("rb_APPOK") as RadioButton;
            TextBox txt_Appcments = grow2.FindControl("txt_APPcomments") as TextBox;
            Label lbleq = grow2.FindControl("lblCCDesc") as Label;
            if (chkAPPNotOK.Checked == true && txt_Appcments.Text.Trim() == "" && lbleq.Text.Trim() != "Relationship with Equitas")
            {
                blCondition = true;
                break;

            }
            if (chkAPPNotOK.Checked == false && chkAPPOK.Checked == false)
            {
                blCondition = true;
                break;
            }
        }



        //if (rd_obserOK.Checked == true && txt_obsercvcmmentys.Text.Trim() == "")
        //{
        //    blCondition = true;

        //}
        //else if (rd_obserNotOK.Checked == true && rd_obserOK.Checked == false)
        //{
        //    blCondition = true;
        //}
        return blCondition;
    }
    protected void rb_OKObservSelectedIndexChanged(object sender, EventArgs e)
    {

        if (rd_obserOK.Checked == true && txt_obsercvcmmentys.Text.Trim() == "")
        {
            txt_obsercvcmmentys.Visible = true;
            
            blStatus = true;
            StrStautscob = "Y";
            Session["StrStautscob"] = StrStautscob;
        }
    }
    protected void rb_NotOKObservSelectedIndexChanged(object sender, EventArgs e)
    {
        if (rd_obserNotOK.Checked == true)
        {
            txt_obsercvcmmentys.Visible = false;
            txt_obsercvcmmentys.Text = "";
            StrStautscob = "N";
            Session["StrStautscob"] = StrStautscob;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Credit_Compliance_Review.aspx");
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        bool bcOndtn = filestatus();

        // checkStatus_selectedChanged();


        if (bcOndtn == false)
        {
            SqlConnection con = new SqlConnection(strcon);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("[RTS_SP_INSERT_CR_CMPLT_REVIEW]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CCR_TYPE", "C");
                cmd.Parameters.AddWithValue("@CCR_LD_ID", lbLeadno.Text);


                cmd.Parameters.AddWithValue("@CCR_COB", Session["StrStautscob"].ToString());
                cmd.Parameters.AddWithValue("@CCR_COB_CMTS", txt_obsercvcmmentys.Text);
                cmd.Parameters.AddWithValue("@CCR_RMKS",txt_Coursecorrection.Text);
                cmd.Parameters.AddWithValue("@TBL_KYC", BindKycTable());
                cmd.Parameters.AddWithValue("@TBL_CREDIT", BindCR_Apparaisal());
                cmd.Parameters.AddWithValue("@CCR_REVIEW", lbl_noreview.Text);
                cmd.Parameters.AddWithValue("@USER_ID", Session["ID"].ToString());

                cmd.ExecuteNonQuery();

                //clear();.
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Peer Process Review for " + lbLeadno.Text + "   Saved Successfully');window.location.reload()", true);
            }
            catch (Exception ex)
            {
                uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();

            }
        }

        else
        {
            uscMsgBox1.AddMessage("Please give corresponding input for KYC and CREDIT Apraisal , comments  mandatory if select 'NOT OK and Any other Critical Observations , comments comments  mandatory if select 'Yes'", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }


    }
    private void clear()
    {
        RadioButton rd1 = gvRecvsend.FindControl("rb_OK") as RadioButton;
        RadioButton rd2 = gvRecvsend.FindControl("rb_NotOK") as RadioButton;
        TextBox txt1 = gvRecvsend.FindControl("txt_comments") as TextBox;
        RadioButton rd3 = gvRecvsend.FindControl("rb_APPOK") as RadioButton;
        RadioButton rd4 = gvRecvsend.FindControl("rb_APPNotOK") as RadioButton;
        RadioButton rd5 = gvRecvsend.FindControl("rd_obserNotOK") as RadioButton;
        RadioButton rd6 = gvRecvsend.FindControl("rd_obserOK") as RadioButton;
        TextBox txt2 = gvRecvsend.FindControl("txt_APPcomments") as TextBox;
        TextBox txt3 = (TextBox)FindControl("txt_obsercvcmmentys") as TextBox;
        TextBox txtcob = (TextBox)FindControl("txt_Coursecorrection") as TextBox;
        if ((rd1.Checked) && (rd2.Checked) && (rd3.Checked) && (rd4.Checked) && (rd5.Checked) && (rd6.Checked))
        {
            rd1.Checked = false;
        }
        txt1.Text = "";
        txt2.Text = "";
        txt3.Text = "";
        txtcob.Text = "";
    }

    protected void Credit_Appraisal_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lbleq = e.Row.FindControl("lblCCDesc") as Label;
            if (lbleq.Text == "Relationship with Equitas")
            {
                RadioButton rdOK = e.Row.FindControl("rb_APPOK") as RadioButton;
                RadioButton rdNotOK = e.Row.FindControl("rb_APPNotOK") as RadioButton;
                TextBox rdtxtAppComnds = e.Row.FindControl("txt_APPcomments") as TextBox;

                rdOK.Text = "Member";
                rdNotOK.Text = "Non Member";
                rdtxtAppComnds.Visible = false;
            }
        }
    }

    protected void rb_selectedOK_CheckedChanged(object sender, EventArgs e)
    {
        lblresultstatus.Text = "";
        foreach (GridViewRow grow1 in GridView1.Rows)
        {
            RadioButton chkOK = grow1.FindControl("rb_OK") as RadioButton;
            TextBox txt_cments = grow1.FindControl("txt_comments") as TextBox;
            if (chkOK.Checked == true)
            {
                txt_cments.Visible = true;
                txt_cments.Text = "";


            }
        }

        checkStatus_selectedChanged();
    }
    protected void rb_selectedNotOK_CheckedChanged(object sender, EventArgs e)
    {
        lblresultstatus.Text = "";
        foreach (GridViewRow grow1 in GridView1.Rows)
        {
            RadioButton chkNotOK = grow1.FindControl("rb_NotOK") as RadioButton;
            TextBox txt_cments = grow1.FindControl("txt_comments") as TextBox;

            txt_cments.Visible = true;
            if (chkNotOK.Checked == true)
            {
                txt_cments.Visible = true;

                blStatus = true;
            }
        }
        checkStatus_selectedChanged();
    }


    

}
