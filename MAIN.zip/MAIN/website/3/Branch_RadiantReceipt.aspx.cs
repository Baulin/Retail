﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Configuration;
using System.Globalization;
using System.Web.Services;
using Tracker;
using System.Threading;

public partial class Branch_RadiantReceipt : System.Web.UI.Page
{
    #region SQL FIELDS

    SqlConnection con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_Obj = new SqlCommand();
    DataTable dt_obj = new DataTable();
    CreateLogFiles Err = new CreateLogFiles();
    ClsCommon clscommon = new ClsCommon();


    int sum = 0;
    string fileName = string.Empty;
    string fileExt = string.Empty;
    string fileUploadPath = string.Empty;
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            // Saravanan 18/08/2015
            Page.Form.Attributes.Add("enctype", "multipart/form-data");
            // Saravanan 18/08/2015
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    Session["RFRSH_DUP"] = "";
                    bindArea();
                    Radiant_Receipt_Process("FETCH TODAY RECEIPT");
                    Bind_Master("CD");
                    btnrsumbit.Enabled = false;
                    txtbx_rcno.Enabled = false;
                    bindProduct();
                }
            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void ClearValues()
    {
        try
        {


            //if (ddlst_collection_type.Items.Count > 0)
            //    ddlst_collection_type.SelectedIndex = 0;

            txtbx_ln_no.Text = "";
            txtbx_ln_sanc_no.Text = "";
            txtbx_brnch_Name.Text = "";
            txtbx_product.Text = "";
            txtbx_cus_name.Text = "";
            if (ddlst_coll_type.Items.Count > 0)
                ddlst_coll_type.SelectedIndex = 0;

            if (ddlst_deposit_type.Items.Count > 0)
                ddlst_deposit_type.SelectedIndex = 0;


            txtbx_rcno.Text = "";
            txtbx_rcamt.Text = "";
            txtbx_rcno.Enabled = false;

            //trFupload.Visible = false;
            trGridCollection.Visible = false;
            txtMbl_Recipt_Total.Text = "";
            //ddlst_collection_type.SelectedIndex = 0;
            txtDepositedBank.Text = "";
            tdBank.Visible = false;
            tdBank1.Visible = false;
            ddlProduct.SelectedIndex = 0;
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {

        Response.Redirect("Branch_RadiantReceipt.aspx");

    }

    protected void btnsumbit_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlst_collection_type.SelectedValue == "C")
            {
                //if (ddlst_deposit_type.SelectedValue == "1|Y")
                //{
                if (Convert.ToString(Session["RFRSH_DUP"]) != "YES")
                {
                    if (fup_Challon.HasFile)
                    {
                        if (fup_Challon.PostedFile.ContentLength > 512000)
                        {
                            uscMsgBox1.AddMessage("The file size should be 500kb or less", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            return;
                        }
                        else
                        {
                            fileExt = Path.GetExtension(fup_Challon.FileName);
                            fileName = ddlst_Area.SelectedItem.Text + "_" + ddlst_Branch.SelectedItem.Text + "_" + hdnServerTime.Value + "_" + txtbx_rcno.Text.Trim() + "_" + txtbx_rcamt.Text.Trim() + fileExt;
                            fileUploadPath = ConfigurationManager.AppSettings[AppConstants.FileUploadPath] + AppConstants.Directory_File + fileName;
                            fup_Challon.SaveAs(Server.MapPath(fileUploadPath));
                        }
                    }
                    //}
                    Radiant_Receipt_Process("INSERT");
                }
            }
            else
            {
                Radiant_Receipt_Process("INSERT");
            }
            if (Session["RRCPT_RES"].ToString() == "YES")
            {
                ClearValues();
                ddlst_collection_type.SelectedIndex = 0;
                switch (ddlst_collection_type.SelectedValue)
                {
                    case "C":
                        lbl_display.Text = "Enter the Agreement Number";
                        lbl_ln_sanc_no.Text = "Agreement Number";
                        break;
                    case "I":
                        lbl_display.Text = "Enter the Sanction Number";
                        lbl_ln_sanc_no.Text = "Sanction Number";
                        break;
                }
                btnrsumbit.Enabled = false;
                ClearValues();
                uscMsgBox1.AddMessage("Collection added successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
            else
            {
                uscMsgBox1.AddMessage("Collection not added.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally { Radiant_Receipt_Process("FETCH TODAY RECEIPT"); }


    }

    protected void gvradiantreceipt_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            int temp = DataBinder.Eval(e.Row.DataItem, "RC_AMT") == DBNull.Value ? 0 : Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "RC_AMT"));
            sum += temp;
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lblamount = (Label)e.Row.FindControl("lblamt");
            if (sum.Equals(0))
                lblamount.Text = "0.00";
            else
                lblamount.Text = sum.ToString("########.00");
        }
    }

    protected void Radiant_Receipt_Process(string PType)
    {
        int rs = 0;
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();

            cmd_Obj = new SqlCommand("RTS_SP_FETCH_INSERT_RADIANT_RECEIPT", con_Obj);
            cmd_Obj.CommandTimeout = 240000;
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@PTYPE", PType);
            switch (PType)
            {

                case "SERVDATE":

                    dt_obj = new DataTable();
                    dt_obj.Load(cmd_Obj.ExecuteReader());
                    // Saravanan 18/08/2015
                    hdnServerTime.Value = Convert.ToString(dt_obj.Rows[0][0]);
                    // Saravanan 18/08/2015
                    break;
                case "FETCH TODAY RECEIPT":

                    cmd_Obj.Parameters.AddWithValue("@RC_BR_ID", ddlst_Branch.SelectedItem.Text != "--Select--" ? ddlst_Branch.SelectedValue.ToString() : Session["BRANCHID"].ToString());

                    dt_obj = new DataTable();
                    dt_obj.Load(cmd_Obj.ExecuteReader());
                    gvradiantreceipt.DataSource = dt_obj;
                    gvradiantreceipt.DataBind();

                    break;

                case "INSERT":
                    //Saravanan 20-08-2015

                    if (ddlst_collection_type.SelectedValue == "C")
                    {
                        rs = SelectedInsert();
                    }
                    else
                    {
                        cmd_Obj.Parameters.AddWithValue("@RC_BR_ID", ddlst_Branch.SelectedItem.Text != "--Select--" ? ddlst_Branch.SelectedValue.ToString() : Session["BRANCHID"].ToString());
                        cmd_Obj.Parameters.AddWithValue("@RC_TYPE", ddlst_collection_type.SelectedValue);
                        cmd_Obj.Parameters.AddWithValue("@RC_REF_NO", txtbx_ln_sanc_no.Text.ToUpper().Trim());
                        cmd_Obj.Parameters.AddWithValue("@RC_DISB_BRNAME", txtbx_brnch_Name.Text.Trim().ToUpper());
                        cmd_Obj.Parameters.AddWithValue("@RC_CNAME", txtbx_cus_name.Text.Trim().ToUpper());
                        cmd_Obj.Parameters.AddWithValue("@RC_PRODUCT", txtbx_product.Text.Trim().ToUpper());
                        cmd_Obj.Parameters.AddWithValue("@RC_CT_ID", ddlst_coll_type.SelectedValue);
                        cmd_Obj.Parameters.AddWithValue("@RC_DT_ID", Session["RRCPT_DT_ID"].ToString());
                        if (txtbx_rcno.Text.Trim() != "")
                        {
                            cmd_Obj.Parameters.AddWithValue("@RC_RNO", txtbx_rcno.Text.Trim().ToUpper());
                        }
                        cmd_Obj.Parameters.AddWithValue("@RC_AMT", txtbx_rcamt.Text);
                        cmd_Obj.Parameters.AddWithValue("@RC_CBY", Session["ID"].ToString());
                        rs = cmd_Obj.ExecuteNonQuery();
                    }
                    //Saravanan 20-08-2015

                    if (rs > 0)
                    {
                        //Response.Redirect("~/Branch_RadiantReceipt.aspx");
                        Session["RRCPT_RES"] = "YES";
                        Session["RFRSH_DUP"] = "YES";
                    }
                    else
                    {
                        Session["RRCPT_RES"] = "NO";
                        Session["RFRSH_DUP"] = "NO";
                    }

                    break;

                case "FETCH":

                    cmd_Obj.Parameters.AddWithValue("@RC_REF_NO", txtbx_ln_no.Text.ToUpper().Trim());
                    dt_obj = new DataTable();
                    dt_obj.Load(cmd_Obj.ExecuteReader());
                    //PrpslNo  LnNo PRODUCT NAME BRANCH

                    if (dt_obj.Rows.Count > 0)
                    {
                        if (ddlst_collection_type.SelectedValue == "C")
                        {
                            txtbx_ln_sanc_no.Text = dt_obj.Rows[0]["LnNo"] != DBNull.Value ? dt_obj.Rows[0]["LnNo"].ToString() : "";
                        }
                        else if (ddlst_collection_type.SelectedValue == "I")
                        {
                            txtbx_ln_sanc_no.Text = dt_obj.Rows[0]["PrpslNo"] != DBNull.Value ? dt_obj.Rows[0]["PrpslNo"].ToString() : "";
                        }

                        txtbx_brnch_Name.Text = dt_obj.Rows[0]["BRANCH"] != DBNull.Value ? dt_obj.Rows[0]["BRANCH"].ToString() : "";
                        txtbx_product.Text = dt_obj.Rows[0]["PRODUCT"] != DBNull.Value ? dt_obj.Rows[0]["PRODUCT"].ToString() : "";
                        txtbx_cus_name.Text = dt_obj.Rows[0]["NAME"] != DBNull.Value ? dt_obj.Rows[0]["NAME"].ToString() : "";

                    }
                    else
                    {
                        if (ddlst_collection_type.SelectedValue == "C")
                        {
                            uscMsgBox1.AddMessage("No records found. Please check the agreement number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            return;
                        }
                        else if (ddlst_collection_type.SelectedValue == "I")
                        {
                            uscMsgBox1.AddMessage("No records found. Please check the sanction number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            return;
                        }
                    }

                    break;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }


    }

    protected void ddlst_collection_type_SelectedIndexChanged(object sender, EventArgs e)
    {
        switch (ddlst_collection_type.SelectedValue)
        {
            case "C":
                lbl_display.Text = "Enter the Agreement Number";
                lbl_ln_sanc_no.Text = "Agreement Number";
                // Saravanan 18/08/2015
                trTypeInsurance.Visible = false;
                trAgrmntNumber.Visible = false;
                //divCollection.Visible = true;
                divinsurance.Visible = false;
                trGridCollection.Visible = true;
                Radiant_Receipt_Process("SERVDATE");
                btnViewCollection.Visible = true;
                Bind_Master("C");
                divTypeCollection.Visible = false;
                divProd.Visible = true;
                btnrsumbit.Enabled = false;
                // Saravanan 18/08/2015
                break;
            case "I":
                lbl_display.Text = "Enter the Sanction Number";
                lbl_ln_sanc_no.Text = "Sanction Number";
                // Saravanan 18/08/2015
                trTypeInsurance.Visible = true;
                trAgrmntNumber.Visible = true;
                divCollection.Visible = false;
                divinsurance.Visible = true;
                trGridCollection.Visible = false;
                btnViewCollection.Visible = false;
                divTypeCollection.Visible = true;
                trFupload.Visible = false;
                divProd.Visible = false;
                btnrsumbit.Enabled = false;
                // Saravanan 18/08/2015
                break;
        }
        ClearValues();
    }

    protected void btn_View_Click(object sender, EventArgs e)
    {

        try
        {

            Radiant_Receipt_Process("FETCH");
            Bind_Master("CD");


            // Saravanan 18/08/2015
            if (ddlst_collection_type.SelectedValue != "C")
                btnrsumbit.Enabled = true;
            else
                btnrsumbit.Enabled = false;
            // Saravanan 18/08/2015
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }
    }

    // Shankar_Nov_14_01 
    public void bindArea()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();

            cmd_Obj = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
            }
            else
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", 0);
            }
            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());




            ddlst_Area.DataSource = dt_obj;
            ddlst_Area.DataTextField = "AR_NAME";
            ddlst_Area.DataValueField = "AR_ID";
            ddlst_Area.DataBind();

            ddlst_Area.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Area.SelectedValue = Session["AREA_ID"].ToString();

            bindBranch();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }


    }
    // Shankar_Nov_14_01 
    public void bindBranch()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);

            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());



            ddlst_Branch.DataSource = dt_obj;
            ddlst_Branch.DataTextField = "BR_NAME";
            ddlst_Branch.DataValueField = "BR_ID";
            ddlst_Branch.DataBind();
            ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
            if (Session["USR_ACS"].ToString() == "7")
            {
                ddlst_Branch.SelectedValue = Session["BRANCHID"].ToString();
                ddlst_Branch.Enabled = false;
                ddlst_Area.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }

    }

    protected void ddlst_Area_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            trGridCollection.Visible = false;
            ddlst_collection_type.SelectedIndex = 0;
            btnViewCollection.Visible = false;
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);
            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());

            ddlst_Branch.DataSource = dt_obj;
            ddlst_Branch.DataTextField = "BR_NAME";
            ddlst_Branch.DataValueField = "BR_ID";
            ddlst_Branch.DataBind();
            ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Branch.Enabled = true;
            ClearValues();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }
    }

    protected void ddlst_Branch_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtbx_ln_no.Text = "";
            ddlst_collection_type.SelectedIndex = 0;
            btnViewCollection.Visible = false;
            ClearValues();
            Radiant_Receipt_Process("FETCH TODAY RECEIPT");
            trGridCollection.Visible = false;
            bindDepositType();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    /* bind collection and deposit master */

    protected void Bind_Master(string Ptype)
    {
        try
        {

            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();



            switch (Ptype)
            {

                case "C":

                    cmd_Obj = new SqlCommand("SP_RTS_MR_BIND_COLLECTION_TYPE", con_Obj);
                    cmd_Obj.CommandTimeout = 240000;
                    cmd_Obj.CommandType = CommandType.StoredProcedure;
                    cmd_Obj.Parameters.AddWithValue("@CT_TYPE", ddlst_collection_type.SelectedValue);
                    dt_obj = new DataTable();
                    dt_obj.Load(cmd_Obj.ExecuteReader());

                    ddlst_coll_type.DataSource = dt_obj;
                    ddlst_coll_type.DataTextField = "CT_DESC";
                    ddlst_coll_type.DataValueField = "CT_ID";
                    ddlst_coll_type.DataBind();

                    ddlst_coll_type.Items.Insert(0, new ListItem("--Select--", "0"));
                    ddlst_coll_type.SelectedIndex = 0;

                    break;

                case "D":
                    cmd_Obj = new SqlCommand("SP_RTS_MR_BIND_DEPOSIT_TYPE", con_Obj);

                    cmd_Obj.CommandTimeout = 240000;
                    cmd_Obj.CommandType = CommandType.StoredProcedure;
                    cmd_Obj.Parameters.AddWithValue("@DT_TYPE", ddlst_collection_type.SelectedValue);
                    dt_obj = new DataTable();
                    dt_obj.Load(cmd_Obj.ExecuteReader());
                    var resultD = from r in dt_obj.AsEnumerable()
                                  where r.Field<string>("DT_DESC") != "CASH IN HAND"
                                  select r;
                    DataTable dtDepositeD = resultD.CopyToDataTable();

                    ddlst_deposit_type.DataSource = dt_obj;
                    ddlst_deposit_type.DataTextField = "DT_DESC";
                    ddlst_deposit_type.DataValueField = "DTID";

                    ddlst_deposit_type.DataBind();

                    ddlst_deposit_type.Items.Insert(0, new ListItem("--Select--", "0"));
                    ddlst_deposit_type.SelectedIndex = 0;


                    break;

                case "CD":
                    cmd_Obj = new SqlCommand("SP_RTS_MR_BIND_COLLECTION_TYPE", con_Obj);
                    cmd_Obj.CommandTimeout = 240000;
                    cmd_Obj.CommandType = CommandType.StoredProcedure;
                    cmd_Obj.Parameters.AddWithValue("@CT_TYPE", ddlst_collection_type.SelectedValue);
                    dt_obj = new DataTable();
                    dt_obj.Load(cmd_Obj.ExecuteReader());

                    ddlst_coll_type.DataSource = dt_obj;
                    ddlst_coll_type.DataTextField = "CT_DESC";
                    ddlst_coll_type.DataValueField = "CT_ID";
                    ddlst_coll_type.DataBind();

                    ddlst_coll_type.Items.Insert(0, new ListItem("--Select--", "0"));
                    ddlst_coll_type.SelectedIndex = 0;

                    /*   cmd_Obj = new SqlCommand("SP_RTS_MR_BIND_DEPOSIT_TYPE", con_Obj);
                       cmd_Obj.CommandTimeout = 240000;
                       cmd_Obj.CommandType = CommandType.StoredProcedure;
                       cmd_Obj.Parameters.AddWithValue("@DT_TYPE", ddlst_collection_type.SelectedValue);
                       //Bala changes starts 24032017
                       cmd_Obj.Parameters.AddWithValue("@DT_BR_ID", ddlst_Branch.SelectedValue);
                       //bala changes ends
                       dt_obj = new DataTable();
                       dt_obj.Load(cmd_Obj.ExecuteReader());
                       var result = from r in dt_obj.AsEnumerable()
                                    where r.Field<string>("DT_DESC") != "CASH IN HAND"
                                    select r;
                       DataTable dtDeposite = result.CopyToDataTable();

                       ddlst_deposit_type.DataSource = dtDeposite;
                       ddlst_deposit_type.DataTextField = "DT_DESC";
                       ddlst_deposit_type.DataValueField = "DTID";
                       ddlst_deposit_type.DataBind();

                       ddlst_deposit_type.Items.Insert(0, new ListItem("--Select--", "0"));
                       ddlst_deposit_type.SelectedIndex = 0;

                       */

                    if (Session["USR_ACS"].ToString() == "7")
                    {
                        bindDepositType();
                    }

                    break;
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }


    }
    public void bindDepositType()
    {
        try
        {



            //ddlArea.Items.Add(new ListItem(Session["AREANAME"].ToString(), Session["AREA_ID"].ToString()));

            //ddlArea.DataBind();
            SqlConnection con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            con_Obj.Open();

            SqlCommand cmd_Obj = new SqlCommand("SP_RTS_MR_BIND_DEPOSIT_TYPE", con_Obj);
            cmd_Obj.CommandTimeout = 240000;
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@DT_TYPE", ddlst_collection_type.SelectedValue);
            //Bala changes starts 24032017
            if (Session["USR_ACS"].ToString() != "7")
            {
                cmd_Obj.Parameters.AddWithValue("@DT_BR_ID", ddlst_Branch.SelectedValue);
            }
            else
            {
                cmd_Obj.Parameters.AddWithValue("@DT_BR_ID", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"].ToString()) : 0);
            }

            //bala changes ends
            dt_obj = new DataTable();
            dt_obj.Load(cmd_Obj.ExecuteReader());
            var result = from r in dt_obj.AsEnumerable()
                         where r.Field<string>("DT_DESC") != "CASH IN HAND"
                         select r;
            DataTable dtDeposite = result.CopyToDataTable();

            ddlst_deposit_type.DataSource = dtDeposite;
            ddlst_deposit_type.DataTextField = "DT_DESC";
            ddlst_deposit_type.DataValueField = "DTID";
            ddlst_deposit_type.DataBind();

            ddlst_deposit_type.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_deposit_type.SelectedIndex = 0;


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }


    protected void ddlst_deposit_type_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlst_deposit_type.SelectedItem.Text != "--Select--")
        {
            string[] arr = new string[2];

            arr = ddlst_deposit_type.SelectedValue.Split('|');
            txtDepositedBank.Text = "";
            txtDepositedBank.Enabled = true;
            if (arr != null)
            {
                if (arr[1].ToString().Trim() != "" && arr[1].ToString() == "Y")
                {
                    txtbx_rcno.Text = "";
                    txtbx_rcno.Enabled = true;
                    //// Saravanan 18/08/2015                    
                    ////btnrsumbit.Enabled = false;
                    ////if (ddlst_deposit_type.SelectedValue == "1|Y")
                    //if (ddlst_collection_type.SelectedValue == "C")
                    //    trFupload.Visible = true;
                    ////btnrsumbit.Enabled = false;
                    //if ddlst_deposit_type.SelectedValue == "")

                    //// Saravanan 18/08/2015
                }
                else
                {
                    txtbx_rcno.Text = "";
                    txtbx_rcno.Enabled = true;
                    //btnrsumbit.Enabled = true;
                    //txtbx_rcno.Text = "";
                    //txtbx_rcno.Enabled = false;
                    //trFupload.Visible = false;
                }
                Session["RRCPT_DT_ID"] = arr[0].ToString();
            }
            if (ddlst_deposit_type.SelectedItem.Text == "DIRECT")
            {
                if (ddlst_collection_type.SelectedValue == "C")
                {
                    tdBank.Visible = true;
                    tdBank1.Visible = true;
                    txtDepositedBank.Text = "";
                }
                else
                {
                    tdBank.Visible = false;
                    tdBank1.Visible = false;
                }
            }
            else
                if (ddlst_deposit_type.SelectedItem.Text == "ESFB")
            {
                if (ddlst_collection_type.SelectedValue == "C")
                {
                    tdBank.Visible = true;
                    tdBank1.Visible = true;
                }
                else
                {
                    tdBank.Visible = false;
                    tdBank1.Visible = false;
                    txtDepositedBank.Text = "";
                }

                txtDepositedBank.Text = clscommon.GetDepositBankDetails(ddlProduct.SelectedValue.ToString());
                txtDepositedBank.Enabled = false;
            }
            else
            {
                tdBank.Visible = false;
                tdBank1.Visible = false;
                txtDepositedBank.Text = "";
            }
        }
        else
        {
            txtbx_rcno.Text = "";
            txtbx_rcno.Enabled = false;
            //trFupload.Visible = false;
            txtDepositedBank.Text = "";
            tdBank.Visible = false;
            tdBank1.Visible = false;
        }
    }

    // Saravanan 18/08/2015    

    protected void total()
    {
        Session["RFRSH_DUP"] = "";
        double tot = 0;
        foreach (GridViewRow gvRow in gridCollection.Rows)
        {
            CheckBox chkbox = (CheckBox)gvRow.FindControl("chkbxCollection");
            Label lblAmount = (Label)gvRow.FindControl("lbl_rc_amt_col");
            if (chkbox.Checked)
            {
                double amt = Convert.ToDouble(lblAmount.Text);
                tot += amt;
            }
        }
        txtMbl_Recipt_Total.Text = Convert.ToString(tot);
        //txtMbl_Recipt_Total.Text = Convert.ToString(tot) + ".00";
    }

    protected void collection_Proccess(string branchId, string product, string stDate, string endDate)
    {
        try
        {
            //stDate = Convert.ToString(Convert.ToDateTime(stDate).ToString("yyyy-MM-dd"));
            endDate = Convert.ToString(Convert.ToDateTime(endDate).ToString("yyyy-MM-dd"));
            //stDate = "2015-09-08";
            //stDate = "2015-10-01"; //After DCS Changes to SYNC Tym issue date changed from '2015-09-08' to '2015-10-01'
            stDate = "2015-10-01";
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("RTS_MBL_RCPT_DET", con_Obj);
            cmd_Obj.CommandTimeout = 240000;
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@BR", branchId);
            cmd_Obj.Parameters.AddWithValue("@STDT", stDate);
            cmd_Obj.Parameters.AddWithValue("@ENDDT", endDate);
            //if (!string.IsNullOrEmpty(product) && product != "0")
            //{
            //    char c = product.FirstOrDefault();
            //    cmd_Obj.Parameters.AddWithValue("@PRODUCT", c);
            //}
            //else
            cmd_Obj.Parameters.AddWithValue("@PRODUCT", DBNull.Value);
            dt_obj = new DataTable();
            dt_obj.Load(cmd_Obj.ExecuteReader());
            DataTable dtTempCollection = new DataTable();
            DataRow[] drTempProd = null;
            if (dt_obj.Rows.Count > 0)
            {

                if (!string.IsNullOrEmpty(product) && product == "SME")
                {
                    //drTempProd = dt_obj.Select("PRODUCT = 'LAP' or PRODUCT ='SME' or PRODUCT ='G-LAP'");
                    //drTempProd = dt_obj.Select("(PRODUCT = 'LAP' or PRODUCT ='SME' or PRODUCT ='G-LAP' or PRODUCT ='EMP-LAP') and RECEIPT_MODE ='Cash'");
                    drTempProd = dt_obj.Select("(PRODUCT <> 'IB-MFHF' and PRODUCT <> 'IB-G-HF' and PRODUCT <> 'EMP-HF' and PRODUCT <> 'IB-Affordable Home' and PRODUCT <> 'IB-TWL') and RECEIPT_MODE ='Cash'");
                }
                else if (product == "IB-MFHF")
                {
                    //drTempProd = dt_obj.Select("PRODUCT = 'MF-HF' or PRODUCT ='G-HF'");
                    drTempProd = dt_obj.Select("(PRODUCT = 'IB-MFHF' or PRODUCT ='IB-G-HF' or PRODUCT ='EMP-HF' or PRODUCT='IB-Affordable Home') and RECEIPT_MODE ='Cash'");
                }
                else if (product == "IB-TWL")
                {
                    drTempProd = dt_obj.Select("(PRODUCT = 'IB-TWL') and RECEIPT_MODE ='Cash'");
                }

                if (drTempProd.Length > 0)
                {
                    dtTempCollection = drTempProd.CopyToDataTable();
                }

            }
            gridCollection.DataSource = dtTempCollection;
            gridCollection.DataBind();
            dtTempCollection.Dispose();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    protected void chkbxCollection_CheckedChanged(object sender, EventArgs e)
    {
        total();
    }

    protected void chkboxSelectAll_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox chkAll = (CheckBox)gridCollection.HeaderRow.FindControl("chkbxAll");
        if (chkAll.Checked)
            total();
    }
    //Saravanan 18/08/2015

    protected void btnViewCollection_Click(object sender, EventArgs e)
    {
        if (ddlst_collection_type.SelectedIndex != 0)
        {

            tdBank.Visible = false;
            tdBank1.Visible = false;
            txtDepositedBank.Text = "";
            txtDepositedBank.Enabled = true;
            ddlst_deposit_type.SelectedValue = "0";

            divCollection.Visible = true;
            trFupload.Visible = true;
            btnrsumbit.Enabled = true;
            trGridCollection.Visible = true;
            collection_Proccess(ddlst_Branch.SelectedValue.ToString(), ddlProduct.SelectedItem.Text.Trim(), Convert.ToString(hdnServerTime.Value), Convert.ToString(hdnServerTime.Value));
        }
        else
        {
            uscMsgBox1.AddMessage("Please select the Collection Type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            return;
        }
    }

    protected int SelectedInsert()
    {
        int rs = 0;
        DataTable dtBulkInsert = new DataTable();
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            dtBulkInsert.Columns.Add("RC_REF_NO", typeof(string));
            dtBulkInsert.Columns.Add("RC_DISB_BRNAME", typeof(string));
            dtBulkInsert.Columns.Add("RC_CNAME", typeof(string));
            dtBulkInsert.Columns.Add("RC_PRODUCT", typeof(string));
            dtBulkInsert.Columns.Add("RC_AMT", typeof(double));
            dtBulkInsert.Columns.Add("RC_MBL_RNO", typeof(string));
            dtBulkInsert.Columns.Add("RC_EMP_NO", typeof(string));
            dtBulkInsert.Columns.Add("RC_EMP_NAME", typeof(string));
            dtBulkInsert.Columns.Add("RC_RDATE", typeof(string));
            dtBulkInsert.Columns.Add("RC_SYN_DATE", typeof(string));
            dtBulkInsert.Columns.Add("RC_BOOK_NO", typeof(string));
            foreach (GridViewRow gvRowChecked in gridCollection.Rows)
            {
                CheckBox chkbxIns = (CheckBox)gvRowChecked.FindControl("chkbxCollection");
                if (chkbxIns.Checked)
                {

                    DataRow dtRow = dtBulkInsert.NewRow();
                    Label lbl_ln_san_no = (Label)gvRowChecked.FindControl("lbl_loan_no");
                    Label lbl_brnh_Name = (Label)gvRowChecked.FindControl("lbl_branch");
                    Label lbl_cust_name = (Label)gvRowChecked.FindControl("lbl_cust_name");
                    Label lbl_product = (Label)gvRowChecked.FindControl("lbl_product");
                    Label lbl_rcno = (Label)gvRowChecked.FindControl("lbl_rc_number");
                    Label lbl_rcamt = (Label)gvRowChecked.FindControl("lbl_rc_amt_col");
                    Label lbl_ro_name = (Label)gvRowChecked.FindControl("lbl_ro_name");
                    Label lbl_ro_code = (Label)gvRowChecked.FindControl("lbl_ro_code");
                    Label lbl_rc_rdate = (Label)gvRowChecked.FindControl("lbl_rc_date");
                    Label lbl_rc_syn_amt = (Label)gvRowChecked.FindControl("lbl_rc_syn_amt");
                    Label lbl_Book_NO = (Label)gvRowChecked.FindControl("lbl_Book_NO");
                    //string[] rc_date = lbl_rc_rdate.Text.Trim().Substring(0, 10).Split('/');
                    //string rc_rdate = rc_date[1] + "/" + rc_date[0] + "/" + rc_date[2];
                    dtRow["RC_REF_NO"] = lbl_ln_san_no.Text.ToUpper().Trim();
                    dtRow["RC_DISB_BRNAME"] = lbl_brnh_Name.Text.Trim().ToUpper();
                    dtRow["RC_CNAME"] = lbl_cust_name.Text.Trim().ToUpper();
                    dtRow["RC_PRODUCT"] = lbl_product.Text.Trim();
                    dtRow["RC_AMT"] = lbl_rcamt.Text;
                    dtRow["RC_MBL_RNO"] = lbl_rcno.Text.ToUpper().Trim();
                    dtRow["RC_EMP_NO"] = lbl_ro_code.Text.Trim().ToUpper();
                    dtRow["RC_EMP_NAME"] = lbl_ro_name.Text.Trim().ToUpper();
                    dtRow["RC_RDATE"] = lbl_rc_syn_amt.Text.Trim();
                    dtRow["RC_SYN_DATE"] = lbl_rc_syn_amt.Text.Trim();
                    dtRow["RC_BOOK_NO"] = lbl_Book_NO.Text.Trim();
                    dtBulkInsert.Rows.Add(dtRow);
                }
            }
            cmd_Obj = new SqlCommand("RTS_SP_FETCH_INSERT_RADIANT_RECEIPT", con_Obj);
            cmd_Obj.CommandTimeout = 240000;
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@PTYPE", "BULKINSERT");
            cmd_Obj.Parameters.AddWithValue("@RCINSERT", dtBulkInsert);
            cmd_Obj.Parameters.AddWithValue("@RC_BR_ID", ddlst_Branch.SelectedItem.Text != "--Select--" ? ddlst_Branch.SelectedValue.ToString() : Session["BRANCHID"].ToString());
            cmd_Obj.Parameters.AddWithValue("@RC_TYPE", ddlst_collection_type.SelectedValue);
            cmd_Obj.Parameters.AddWithValue("@RC_CT_ID", ddlst_coll_type.SelectedValue);
            cmd_Obj.Parameters.AddWithValue("@RC_DT_ID", Session["RRCPT_DT_ID"].ToString());
            cmd_Obj.Parameters.AddWithValue("@RC_BANK_NAME", txtDepositedBank.Text.Trim());
            if (txtbx_rcno.Text.Trim() != "")
            {
                cmd_Obj.Parameters.AddWithValue("@RC_RNO", txtbx_rcno.Text.Trim().ToUpper());
            }
            cmd_Obj.Parameters.AddWithValue("@RC_CBY", Session["ID"].ToString());
            //cmd_Obj.Parameters.AddWithValue("@RC_FILE", fileName);
            rs = cmd_Obj.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
        return rs;
    }

    protected void bindProduct()
    {
        DataTable dtTempproduct = new DataTable();
        con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
        if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
            con_Obj.Open();
        cmd_Obj = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con_Obj);
        cmd_Obj.CommandType = CommandType.StoredProcedure;
        cmd_Obj.Parameters.AddWithValue("@COLLECTION", 1);
        //SqlDataAdapter da2 = new SqlDataAdapter(cmd_Obj);
        //DataSet ds2 = new DataSet();
        //da2.Fill(ds2);
        //con_Obj.Close();
        //DataTable dtTempproduct = ds2.Tables[0].Select("PR_ID in (2,3)").CopyToDataTable();
        //ddlProduct.DataSource = dtTempproduct;
        dtTempproduct.Load(cmd_Obj.ExecuteReader());
        ddlProduct.DataSource = dtTempproduct;
        ddlProduct.DataTextField = "PR_CODE";
        ddlProduct.DataValueField = "PR_ID";
        ddlProduct.DataBind();
        ddlProduct.Items.Insert(0, new ListItem("Select", "0"));
    }

}