﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;
using Utilities;

public partial class Mobile_Resolve : System.Web.UI.Page
{
    #region Common
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter da = new SqlDataAdapter();
    DataSet ds = new DataSet();
    //string[] a_month1;
    //string[] a_month = String.Format("{0:dd MMM yyyy}", DateTime.Now).ToString().Split(' ');
    //string month = string.Empty;
    //string year = string.Empty;
    //int monthcount;
    //int totalcount;
    CreateLogFiles Err = new CreateLogFiles();
    string to = string.Empty;
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    //bindBranch();
                    bindArea();
                }
            }
            else
                Response.Redirect("~/Default.aspx");

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string result = string.Empty;
        if (ddlType.SelectedItem.Value == "C")
        {
            if (ddlAction.SelectedValue == "F")
            {
                result = insertFollowup();
                if (result == "s")
                {
                    email_complaint_followup();
                    result = "";
                    clear();
                    ddlBranch.SelectedIndex = 0;
                    ddlType.SelectedIndex = 0;
                    ddlComplaintNo.SelectedIndex = 0;
                    ddlBranch.SelectedIndex = 0;
                    ddlst_Area.SelectedIndex = 0;
                    //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Complaint follow up Successfully');window.location.href('http://localhost:51568/Mobile_Resolve.aspx');", true);

                    //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Complaint Resolved Successfully');window.location.href('http://172.16.2.95/Mobile/Resolve.aspx','_self');", true);
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Complaint Follow up  Successfully');", true);
                }
            }
            else if (ddlAction.SelectedValue == "R")
            {
                result = Update();
                if (result == "s")
                {
                    email_complaint_resolved();
                    result = "";
                    clear();
                    ddlBranch.SelectedIndex = 0;
                    ddlType.SelectedIndex = 0;
                    ddlComplaintNo.SelectedIndex = 0;
                    ddlBranch.SelectedIndex = 0;
                    ddlst_Area.SelectedIndex = 0;
                    //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Complaint Resolved Successfully');window.location.href('http://172.16.2.95/Mobile/Resolve.aspx','_self');", true);
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Complaint Resolved Successfully');", true);
                    //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Complaint Resolved Successfully');window.location.href('http://localhost:51568/Mobile_Resolve.aspx');", true);

                }
            }
        }
        else
        {
            if (ddlAction.SelectedValue == "F")
            {
                result = insertFollowup();
                if (result == "s")
                {
                    email_Reallocation_followup();
                    clear();
                    ddlBranch.SelectedIndex = 0;
                    ddlType.SelectedIndex = 0;
                    ddlComplaintNo.SelectedIndex = 0;
                    ddlBranch.SelectedIndex = 0;
                    ddlst_Area.SelectedIndex = 0;
                    //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Complaint Follow up  Successfully');window.location.href('http://localhost:51568/Mobile_Resolve.aspx');", true);
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Complaint Follow up  Successfully');", true);
                    result = "";
                }
            }
            else if (ddlAction.SelectedValue == "R")
            {
                result = Update();
                if (result == "s")
                {
                    email_Reallocation_resolved();
                    result = "";
                    clear();
                    ddlBranch.SelectedIndex = 0;
                    ddlType.SelectedIndex = 0;
                    ddlComplaintNo.SelectedIndex = 0;
                    ddlBranch.SelectedIndex = 0;
                    ddlst_Area.SelectedIndex = 0;
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Reallocated Successfully');", true);
                    // ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Reallocated Successfully');window.location.href('http://localhost:51568/Mobile_Resolve.aspx');", true);

                    //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Reallocated Successfully');window.location.href('http://172.16.2.95/Mobile/Resolve.aspx','_self');", true);

                }
            }

        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Mobile_Resolve.aspx", false);
    }

    protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        clear();
        ddlComplaintNo.SelectedIndex = 0;
        DataTable dt = new DataTable();
        try
        {
            if (ddlType.SelectedValue == "C")
            {
                spanReqComaplaint.InnerText = "Complaint No.";
                spanDate.InnerText = "Complaint Date";
                trDevice.Visible = true;
                trIssue.Visible = true;
                spanComplaints.InnerText = "Complaint";

                trReallocEmp.Visible = false;
                dt = reqComplaintNo("C");
            }
            else if (ddlType.SelectedValue == "R")
            {
                spanReqComaplaint.InnerText = "Request No";
                spanDate.InnerText = "Request Date";
                trReallocEmp.Visible = true;
                spanComplaints.InnerText = "Remarks";

                trDevice.Visible = false;
                trIssue.Visible = false;
                dt = reqComplaintNo("R");
            }
            if (dt.Rows.Count > 0)
            {
                ddlComplaintNo.DataSource = dt;
                ddlComplaintNo.DataTextField = "LMC_NO";
                ddlComplaintNo.DataValueField = "LMC_ID";
                ddlComplaintNo.DataBind();
                ddlComplaintNo.Items.Insert(0, "--Select");
                ddlComplaintNo.SelectedIndex = 0;
            }
            else
            {
                ddlComplaintNo.Items.Clear();
                ddlComplaintNo.Items.Insert(0, "--Select");
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            dt.Clear();
            dt.Dispose();
            //con.Close();
            //con.Dispose();
            //SqlConnection.ClearPool(con);
        }
    }

    protected void email_Reallocation_resolved()
    {

        try
        {
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{
                string bodytext = " <html><body> <basefont face='Calibri'> Dear " + Convert.ToString(Session["bm_name"]) + ",<br/><br/> Please find the Resolved details for following  Reallocation Request <br/><table width='50%' style='font-family: Verdana, Arial, Tahoma; font-size:12px'><tr><td>"
                  + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>"
                     + "<tr><td width='20%'>Branch Name  </td><td>" + ddlBranch.SelectedItem.Text + "</td></tr>"
                      + "<tr><td>Request Date </td><td>" + txtDate.Text.Trim() + "</td></tr>"
                     + "<tr><td>Request No  </td><td width='30%'>" + ddlComplaintNo.SelectedItem.Text + "</td></tr>"
                       + "<tr><td width='20%'>Current Employee  </td><td>" + txtIssue.Text.Trim() + "</td></tr>"
                    //+ "<tr><td width='20%'>Reallocate Employee  </td><td>" + txtbx_device_reallo_emp.Text + "</td></tr>"

                   //    + "<tr><td width='20%'>User Id </td><td>" + txtbx_usrid.Text + "</td></tr>"
                        + "<tr><td width='20%'>Password  </td><td> 1234  </td></tr>"
                    + "<tr><td width='20%'>TPIN  </td><td>7890 </td></tr>"

                    //+ "<tr><td width='20%'>Book No </td><td>" + txtbx_bookno.Text + "</td></tr>"

                + "<tr><td>Remarks </td><td style='white-space:normal'>" + txtComplaints.Text + "</td></tr>"
                 + "<tr><td>Mobile Number </td><td style='white-space:normal'>" + txtMobileNo.Text + "</td></tr>"
                 + "<tr><td>Resolved Date </td><td style='white-space:normal'>" + String.Format("{0:dd MMM yyyy H:mm}", DateTime.Now).ToString() + "</td></tr>"
                   + "<tr><td>Remarks </td><td style='white-space:normal'>" + txtRemarks.Text.Trim().ToUpper() + "</td></tr>"
                  + "</table></td></tr><br/><br/>"
       + "<tr> <td><strong>Note: For Queries, Please contact mobile helpdesk on 044-6640 1165/1166/1168</strong></td></tr><br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Instructions: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Complaints and Reallocation: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Branch should raise Complaints/Reallocation request in BMP for speedy action</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.For non-working devices, Branch has to inform TRM/ARM and TRM/ARM should examine the device and confirm the device non-working status</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Based on TRM/ARM confirmation, Branch has to send back the non-working device to HO and scanned POD copy should be mailed to mobile helpdesk (mobile-helpdesk@equitasbank.com) </td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 4.For application deletion, mobile user has to inform TRM/ARM and TRM/ARM should investigate the root cause for deletion and confirm the remittance status</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Lost and Damage: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Lost or Physical damage of Mobile/Printer, Branch has to request for new issuance to Regional HR</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.HR dept will deduct the Mobile/Printer cost from the concern employees’ salary and provide approval for new issuance</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Based on the HR dept approval, Mobile Helpdesk will issue new Mobile/Printer to the concern employee</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Do's: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Use mobile and printer only for receipting purpose and Keep only VTS SIM in mobile</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.Daily charge Mobile and Printer and  login on-line at least one time</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Keep only the collection application in mobile</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Don’ts: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Don’t use mobile for calling purpose</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.Don’t uninstall / reinstall the application</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Don’t keep CUG SIM in mobile</td></tr>"
                + "<br/><br/>"

                  + "<tr><td><table width='100%' style='font-family: Calibri;'><tr><td align='left' ><br/><br/><span style='font-family: Verdana, Arial, Tahoma; font-size:12px'>Regards,<br/>Mobile Helpdesk</span></td></tr>"
                  + "<tr><td align='left' ><span style='font-family: Calibri; font-size:14px;color: #ff0000;font-style:italic'><br/><strong>*** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></td></tr></table></html>";
                //sendemail("rts-helpdesk@equitasbank.com", "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "rts-helpdesk@equitasbank.com", "Reallocation : Request No : " + ddl_comp_reqno.SelectedItem.Text + "", bodytext, "", true);
                // sendemail("jenom@equitasbank.com", "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "jenom@equitasbank.com", "Reallocation : Request No : " + ddl_comp_reqno.SelectedItem.Text + "", bodytext, "", true);

                EmailManager.sendemail(Session["bm_email_id"].ToString() + ";jeraldp@equitasbank.com", "Mobile-HelpDesk<mobile-helpdesk@equitasbank.com>", "", "mobile-helpdesk@equitasbank.com;VinothRB@equitasbank.com;prathapg@equitasbank.com", "Reallocation : Request No : " + ddlComplaintNo.SelectedItem.Text + "", bodytext, "", true);
                //sendemail("jeraldp@equitasbank.com", "jeraldp@equitasbank.com", "", "", "Reallocation : Request No : " + ddlComplaintNo.SelectedItem.Text + "", bodytext, "", true);
                //sendemail("jeraldp@equitasbank.com", "jeraldp@equitasbank.com", "", "", "Reallocation : Request No : " + ddlComplaintNo.SelectedItem.Text + "", bodytext, "", true);


            //});
            //threadSendMails.IsBackground = true;
            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(2000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }

    protected void email_Reallocation_followup()
    {
        try
        {
            to = Session["bm_email_id"].ToString();
            //to = "jeraldp@equitasbank.com";
            if (txtRHRmail.Text != "")
            {
                to = to + ";" + txtRHRmail.Text;
            }
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{
                string bodytext = " <html><body> <basefont face='Calibri'> Dear " + Convert.ToString(Session["bm_name"]) + ",<br/><br/> Resolution for your Reallocation request is pending for the following queries <br/><table width='50%' style='font-family: Verdana, Arial, Tahoma; font-size:12px'><tr><td>"
                  + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>"
                     + "<tr><td width='20%'>Branch Name  </td><td>" + ddlBranch.SelectedItem.Text + "</td></tr>"
                      + "<tr><td>Request Date </td><td>" + txtDate.Text + "</td></tr>"
                     + "<tr><td>Request No  </td><td width='30%'>" + ddlComplaintNo.SelectedItem.Text + "</td></tr>"
                       + "<tr><td width='20%'>Current Employee  </td><td>" + txtEmployee.Text + "</td></tr>"
                   + "<tr><td width='20%'>Reallocate Employee  </td><td>" + txtReallocEmp.Text + "</td></tr>"


                + "<tr><td>Remarks </td><td style='white-space:normal'>" + txtComplaints.Text + "</td></tr>"
                 + "<tr><td>Mobile Number </td><td style='white-space:normal'>" + txtMobileNo.Text + "</td></tr>"
                 + "<tr><td>Follow Up Date </td><td style='white-space:normal'>" + String.Format("{0:dd MMM yyyy H:mm}", DateTime.Now).ToString() + "</td></tr>"
                   + "<tr><td>Remarks </td><td style='white-space:normal'>" + txtRemarks.Text.Trim().ToUpper() + "</td></tr>"
                  + "</table></td></tr><br/><br/>"
    + "<tr> <td><strong>Note: For Queries, Please contact mobile helpdesk on 044-6640 1165/1166/1168</strong></td></tr><br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Instructions: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Complaints and Reallocation: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Branch should raise Complaints/Reallocation request in BMP for speedy action</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.For non-working devices, Branch has to inform TRM/ARM and TRM/ARM should examine the device and confirm the device non-working status</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Based on TRM/ARM confirmation, Branch has to send back the non-working device to HO and scanned POD copy should be mailed to mobile helpdesk (mobile-helpdesk@equitasbank.com) </td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 4.For application deletion, mobile user has to inform TRM/ARM and TRM/ARM should investigate the root cause for deletion and confirm the remittance status</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Lost and Damage: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Lost or Physical damage of Mobile/Printer, Branch has to request for new issuance to Regional HR</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.HR dept will deduct the Mobile/Printer cost from the concern employees’ salary and provide approval for new issuance</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Based on the HR dept approval, Mobile Helpdesk will issue new Mobile/Printer to the concern employee</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Do's: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Use mobile and printer only for receipting purpose and Keep only VTS SIM in mobile</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.Daily charge Mobile and Printer and  login on-line at least one time</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Keep only the collection application in mobile</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Don’ts: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Don’t use mobile for calling purpose</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.Don’t uninstall / reinstall the application</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Don’t keep CUG SIM in mobile</td></tr>"
                + "<br/><br/>"
                  + "<tr><td><table width='100%' style='font-family: Calibri;'><tr><td align='left' ><br/><br/><span style='font-family: Verdana, Arial, Tahoma; font-size:12px'>Regards,<br/>Mobile Helpdesk</span></td></tr>"
                  + "<tr><td align='left' ><span style='font-family: Calibri; font-size:14px;color: #ff0000;font-style:italic'><br/><strong>*** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></td></tr></table></html>";
                //sendemail("rts-helpdesk@equitasbank.com", "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "rts-helpdesk@equitasbank.com", "Reallocation : Request No : " + ddl_comp_reqno.SelectedItem.Text + "", bodytext, "", true);
                // sendemail(to, "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "jenom@equitasbank.com", "Reallocation : Request No : " + ddl_comp_reqno.SelectedItem.Text + " (Hold)", bodytext, "", true);

                EmailManager.sendemail(to + ";jeraldp@equitasbank.com", "Mobile-HelpDesk<mobile-helpdesk@equitasbank.com>", "", "mobile-helpdesk@equitasbank.com;", "Reallocation : Request No : " + ddlComplaintNo.SelectedItem.Text + " (Hold)", bodytext, "", true);
                //sendemail("jeraldp@equitasbank.com", "jeraldp@equitasbank.com", "", "", "Reallocation : Request No : " + ddlComplaintNo.SelectedItem.Text + " (Hold)", bodytext, "", true);


            //});
            //threadSendMails.IsBackground = true;
            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(2000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //to = "";
        }

    }

    protected void email_complaint_resolved()
    {
        try
        {
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{
                string bodytext = " <html><body> <basefont face='Calibri'> Dear " + Convert.ToString(Session["bm_name"]) + ",<br/><br/> Please find the Resolved details for following Complaint <br/><table width='50%' style='font-family: Verdana, Arial, Tahoma; font-size:12px'><tr><td>"
                  + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>"
                     + "<tr><td width='20%'>Branch Name  </td><td>" + ddlBranch.SelectedItem.Text + "</td></tr>"
                       + "<tr><td>Complaint Date </td><td>" + txtDate.Text + "</td></tr>"
                    + " <tr><td>Complaint No  </td><td width='30%'>" + ddlComplaintNo.SelectedItem.Text + "</td></tr>"
                       + "<tr><td width='20%'>Employee </td><td>" + txtEmployee.Text + "</td></tr>"
                  + "<tr><td>Device  </td><td width='30%'>" + txtDevice.Text + "</td></tr>"
                  + "<tr><td>Issue  </td><td>" + txtIssue.Text + "</td></tr>"
                + "<tr><td>Complaint </td><td style='white-space:normal'>" + txtComplaints.Text + "</td></tr>"
                     + "<tr><td>Mobile Number </td><td style='white-space:normal'>" + txtMobileNo.Text + "</td></tr>"
                  + "<tr><td>Resolved Date </td><td style='white-space:normal'>" + String.Format("{0:dd MMM yyyy H:mm}", DateTime.Now).ToString() + "</td></tr>"
                   + "<tr><td>Remarks </td><td style='white-space:normal'>" + txtRemarks.Text.ToUpper() + "</td></tr>"
                  + "</table></td></tr><br/><br/>"
              + "<tr> <td><strong>Note: For Queries, Please contact mobile helpdesk on 044-6640 1165/1166/1168</strong></td></tr><br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Instructions: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Complaints and Reallocation: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Branch should raise Complaints/Reallocation request in BMP for speedy action</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.For non-working devices, Branch has to inform TRM/ARM and TRM/ARM should examine the device and confirm the device non-working status</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Based on TRM/ARM confirmation, Branch has to send back the non-working device to HO and scanned POD copy should be mailed to mobile helpdesk (mobile-helpdesk@equitasbank.com) </td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 4.For application deletion, mobile user has to inform TRM/ARM and TRM/ARM should investigate the root cause for deletion and confirm the remittance status</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Lost and Damage: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Lost or Physical damage of Mobile/Printer, Branch has to request for new issuance to Regional HR</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.HR dept will deduct the Mobile/Printer cost from the concern employees’ salary and provide approval for new issuance</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Based on the HR dept approval, Mobile Helpdesk will issue new Mobile/Printer to the concern employee</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Do's: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Use mobile and printer only for receipting purpose and Keep only VTS SIM in mobile</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.Daily charge Mobile and Printer and  login on-line at least one time</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Keep only the collection application in mobile</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Don’ts: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Don’t use mobile for calling purpose</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.Don’t uninstall / reinstall the application</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Don’t keep CUG SIM in mobile</td></tr>"
                + "<br/><br/>"

                  + "<tr><td align='left' ><span style='font-family: Calibri; font-size:14px;color: #ff0000;font-style:italic'><br/><strong>*** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></td></tr></table></html>";
                //sendemail("rts-helpdesk@equitasbank.com", "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "rts-helpdesk@equitasbank.com", "" + txtbx_device_reallo_emp.Text + " Complaint : Complaint No : " + ddl_comp_reqno.SelectedItem.Text + "", bodytext, "", true);

                // sendemail("jenom@equitasbank.com", "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "jenom@equitasbank.com", "" + txtbx_device_reallo_emp.Text + " Complaint : Complaint No : " + ddl_comp_reqno.SelectedItem.Text + "", bodytext, "", true);

                EmailManager.sendemail(Session["bm_email_id"].ToString() + ";jeraldp@equitasbank.com", "Mobile-HelpDesk<mobile-helpdesk@equitasbank.com>", "TamilalaganD@equitasbank.com", "mobile-helpdesk@equitasbank.com", "" + txtReallocEmp.Text + " Complaint : Complaint No : " + ddlComplaintNo.SelectedItem.Text + "", bodytext, "", true);
                //sendemail("jeraldp@equitasbank.com", "jeraldp@equitasbank.com", "", "", "" + txtReallocEmp.Text + " Complaint : Complaint No : " + ddlComplaintNo.SelectedItem.Text + "", bodytext, "", true);




            //});
            //threadSendMails.IsBackground = true;
            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(2000);

        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }

    protected void email_complaint_followup()
    {

        try
        {
            to = Session["bm_email_id"].ToString();
            //to = "jenom@equitasbank.com";
            //to = "jeraldp@equitasbank.com";
            if (txtRHRmail.Text != "")
            {
                to = to + ";" + txtRHRmail.Text;
            }


            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{
                string bodytext = " <html><body> <basefont face='Calibri'> Dear " + Convert.ToString(Session["bm_name"]) + ",<br/><br/> Resolution for your complaint is pending for the following queries <br/><table width='50%' style='font-family: Verdana, Arial, Tahoma; font-size:12px'><tr><td>"
                  + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>"
                     + "<tr><td width='20%'>Branch Name  </td><td>" + ddlBranch.SelectedItem.Text + "</td></tr>"
                       + "<tr><td>Complaint Date </td><td>" + txtDate.Text + "</td></tr>"
                    + " <tr><td>Complaint No  </td><td width='30%'>" + ddlComplaintNo.SelectedItem.Text + "</td></tr>"
                       + "<tr><td width='20%'>Employee </td><td>" + txtEmployee.Text + "</td></tr>"
                  + "<tr><td>Device  </td><td width='30%'>" + txtDevice.Text + "</td></tr>"
                  + "<tr><td>Issue  </td><td>" + txtIssue.Text + "</td></tr>"
                + "<tr><td>Complaint </td><td style='white-space:normal'>" + txtComplaints.Text + "</td></tr>"
                     + "<tr><td>Mobile Number </td><td style='white-space:normal'>" + txtMobileNo.Text + "</td></tr>"
                  + "<tr><td>Follow Up Date </td><td style='white-space:normal'>" + String.Format("{0:dd MMM yyyy H:mm}", DateTime.Now).ToString() + "</td></tr>"
                   + "<tr><td>Remarks </td><td style='white-space:normal'>" + txtRemarks.Text.Trim().ToUpper() + "</td></tr>"
                  + "</table></td></tr><br/><br/>"
    + "<tr> <td><strong>Note: For Queries, Please contact mobile helpdesk on 044-6640 1165/1166/1168</strong></td></tr><br/><br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Instructions: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Complaints and Reallocation: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Branch should raise Complaints/Reallocation request in BMP for speedy action</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.For non-working devices, Branch has to inform TRM/ARM and TRM/ARM should examine the device and confirm the device non-working status</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Based on TRM/ARM confirmation, Branch has to send back the non-working device to HO and scanned POD copy should be mailed to mobile helpdesk (mobile-helpdesk@equitasbank.com) </td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 4.For application deletion, mobile user has to inform TRM/ARM and TRM/ARM should investigate the root cause for deletion and confirm the remittance status</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Lost and Damage: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Lost or Physical damage of Mobile/Printer, Branch has to request for new issuance to Regional HR</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.HR dept will deduct the Mobile/Printer cost from the concern employees’ salary and provide approval for new issuance</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Based on the HR dept approval, Mobile Helpdesk will issue new Mobile/Printer to the concern employee</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Do's: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Use mobile and printer only for receipting purpose and Keep only VTS SIM in mobile</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.Daily charge Mobile and Printer and  login on-line at least one time</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Keep only the collection application in mobile</td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px; text-decoration: underline;'> <strong> Don’ts: </strong> </td></tr>"
                + "<br/>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 1.Don’t use mobile for calling purpose</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 2.Don’t uninstall / reinstall the application</td></tr>"
                + "<tr><td  style='font-family: Verdana, Arial, Tahoma; font-size:10px'> 3.Don’t keep CUG SIM in mobile</td></tr>"
                + "<br/><br/>"

                  + "<tr><td align='left' ><span style='font-family: Calibri; font-size:14px;color: #ff0000;font-style:italic'><br/><strong>*** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></td></tr></table></html>";
                //sendemail("rts-helpdesk@equitasbank.com", "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "rts-helpdesk@equitasbank.com", "" + txtbx_device_reallo_emp.Text + " Complaint : Complaint No : " + ddl_comp_reqno.SelectedItem.Text + "", bodytext, "", true);

                EmailManager.sendemail(to + ";jeraldp@equitasbank.com", "VF-ITSupport<vf-itsupport@equitasbank.com>", "jenom@equitasbank.com", "", "" + txtReallocEmp.Text + " Complaint : Complaint No : " + ddlComplaintNo.SelectedItem.Text + " (Hold)", bodytext, "", true);

                //sendemail("jeraldp@equitasbank.com", "jeraldp@equitasbank.com", "", "", "" + txtReallocEmp.Text + " Complaint : Complaint No : " + ddlComplaintNo.Text + " (Hold)", bodytext, "", true);




            //});
            //threadSendMails.IsBackground = true;
            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(2000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            // to = "";
        }
    }

  
    protected void bindBranch()
    {
        DataTable dt = new DataTable();
        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();

            cmd = new SqlCommand("RTS_SP_READ_ALL_BRANCHNAME", con);
            cmd.CommandType = CommandType.StoredProcedure;

            dt.Load(cmd.ExecuteReader());

            if (dt.Rows.Count > 0)
            {
                ddlBranch.DataSource = dt;
                ddlBranch.DataTextField = "BRANCH_NAME";
                ddlBranch.DataValueField = "BRANCH_NAME";
                ddlBranch.DataBind();
                ddlBranch.Items.Insert(0, "---Select---");
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            dt.Clear();
            dt.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
    }

    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        clear();
        ddlType.SelectedIndex = 0;
        ddlComplaintNo.SelectedIndex = 0;
        getBmMail();
    }

    protected void getBmMail()
    {
        string bmMail = string.Empty;
        DataTable dt = new DataTable();
        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();

            cmd = new SqlCommand("RTS_SP_READ_BM_EMAIL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UNIT_NAME", ddlBranch.SelectedItem.Text);
            dt.Load(cmd.ExecuteReader());
            if (dt.Rows.Count > 0)
            {
                Session["bm_email_id"] = Convert.ToString(dt.Rows[0]["EM_BM"]);
                string bmName = Convert.ToString((from DataRow dr in dt.Rows where (string)dr["EMP_TYPE"] == "Employee" select (string)dr["EM_BM"]).FirstOrDefault());
                if (!string.IsNullOrEmpty(bmName))
                    Session["bm_name"] = bmName;
                else
                    Session["bm_name"] = Convert.ToString(Session["UNITNAME"]);
                //Session["bm_name"] = Convert.ToString(dt.Rows[0]["EMP_NAME"]);
            }
            if (string.IsNullOrEmpty(Convert.ToString(Session["bm_name"])))
                Session["bm_name"] = Convert.ToString(Session["UNITNAME"]);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //dt.Clear();
            //dt.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
        //return bmMail;
    }

    protected DataTable reqComplaintNo(string type)
    {
        DataTable dt = new DataTable();

        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();

            cmd = new SqlCommand("LSD_MOB_COMPLAINTS_NO_READ", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MS_TYPE", type);
            cmd.Parameters.AddWithValue("@MC_BRANCH", ddlBranch.SelectedItem.Text);
            dt.Load(cmd.ExecuteReader());

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //dt.Clear();
            //dt.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
        return dt;
    }

    protected void ddlComplaintNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        clear();
        DataTable dtComp = new DataTable();

        try
        {

            if (ddlType.SelectedItem.Value == "C")
            {
                con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                    con.Open();
                cmd = new SqlCommand("LSD_MOB_COMPLAINTS_READ_DETAILS", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MC_NO", ddlComplaintNo.SelectedItem.Text);
                dtComp.Load(cmd.ExecuteReader());
                if (dtComp.Rows.Count > 0)
                {
                    txtEmployee.Text = dtComp.Rows[0]["LMC_EMP_NO"].ToString() + "-" + dtComp.Rows[0]["LMC_EMP_NAME"].ToString();
                    txtDate.Text = dtComp.Rows[0]["LMC_DATE"].ToString();
                    txtComplaints.Text = dtComp.Rows[0]["LMC_COMPLAINT"].ToString();
                    txtReallocEmp.Text = dtComp.Rows[0]["LMC_REMP_NO"].ToString() + "-" + dtComp.Rows[0]["LMC_REMP_NAME"].ToString();
                    txtDevice.Text = dtComp.Rows[0]["LMC_DEVICE"].ToString();
                    txtIssue.Text = dtComp.Rows[0]["MOI_ISSUE"].ToString();
                    txtMobileNo.Text = dtComp.Rows[0]["LMC_PHNO"].ToString();
                }
            }
            else
            {
                int count = getcount();
                if (count > 0)
                {
                    con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                        con.Open();
                    cmd = new SqlCommand("LSD_MOB_COMPLAINTS_READ_DETAILS", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MC_NO", ddlComplaintNo.SelectedItem.Text);
                    dtComp.Load(cmd.ExecuteReader());
                    if (dtComp.Rows.Count > 0)
                    {
                        txtEmployee.Text = dtComp.Rows[0]["LMC_EMP_NO"].ToString() + "-" + dtComp.Rows[0]["LMC_EMP_NAME"].ToString();
                        txtDate.Text = dtComp.Rows[0]["LMC_DATE"].ToString();
                        txtComplaints.Text = dtComp.Rows[0]["LMC_COMPLAINT"].ToString();
                        txtReallocEmp.Text = dtComp.Rows[0]["LMC_REMP_NO"].ToString() + "-" + dtComp.Rows[0]["LMC_REMP_NAME"].ToString();
                        txtDevice.Text = dtComp.Rows[0]["LMC_DEVICE"].ToString();
                        txtIssue.Text = dtComp.Rows[0]["MOI_ISSUE"].ToString();
                        txtMobileNo.Text = dtComp.Rows[0]["LMC_PHNO"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            dtComp.Clear();
            dtComp.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
    }

    protected int getcount()
    {
        int count = 0;
        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();
            cmd = new SqlCommand("RTS_SP_REALLOC_CHECK", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MC_NO", ddlComplaintNo.SelectedItem.Text);
            count = Convert.ToInt16(cmd.ExecuteScalar());
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
        return count;
    }

    protected string insertFollowup()
    {
        string result = "";
        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();

            cmd = new SqlCommand("RTS_SP_MOB_FOLLOWUP_INSERT", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MF_MC_ID", Convert.ToInt32(ddlComplaintNo.SelectedValue));
            cmd.Parameters.AddWithValue("@MF_RMKS", txtRemarks.Text);
            cmd.Parameters.AddWithValue("@MF_EMAIL", txtRHRmail.Text);
            cmd.ExecuteNonQuery();
            return result = "s";
        }
        catch
        {
            return result = "F";

        }
        finally
        {
            cmd.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
    }

    protected string Update()
    {
        string resultupdate = "";
        try
        {
            con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
                con.Open();

            cmd = new SqlCommand("LSD_MOB_COMPLAINTS_UPDATE", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MC_ID", Convert.ToInt32(ddlComplaintNo.SelectedValue));
            cmd.Parameters.AddWithValue("@MC_RESOLVE", txtRemarks.Text);
            cmd.Parameters.AddWithValue("@MC_RBY", Convert.ToString(Session["EMPID"]));
            cmd.ExecuteNonQuery();
            return resultupdate = "s";
        }
        catch
        {
            return resultupdate = "F";

        }
        finally
        {
            cmd.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);
        }
    }

    public void bindArea()
    {
        try
        {
            DataTable dt = new DataTable();
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                cmd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                cmd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                cmd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
            {
                cmd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
            }
            else
            {
                cmd.Parameters.AddWithValue("@InputVal", 0);
            }
            dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            ddlst_Area.DataSource = dt;
            ddlst_Area.DataTextField = "AR_NAME";
            ddlst_Area.DataValueField = "AR_ID";
            ddlst_Area.DataBind();
            ddlst_Area.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Area.SelectedValue = Session["AREA_ID"].ToString();

            bindBranchs();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);

        }
    }

    public void bindBranchs()
    {
        try
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con);

            DataTable dt = new DataTable();

            dt.Load(cmd.ExecuteReader());



            ddlBranch.DataSource = dt;
            ddlBranch.DataTextField = "BR_NAME";
            ddlBranch.DataValueField = "BR_ID";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
            if (Session["USR_ACS"].ToString() == "7")
            {
                ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
                ddlBranch.Enabled = false;
                ddlst_Area.Enabled = false;
            }
            //bindEmpname();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);

        }

    }

    protected void ddlst_Area_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            clear();
            ddlBranch.SelectedIndex = 0;
            ddlType.SelectedIndex = 0;
            ddlComplaintNo.SelectedIndex = 0;
            ddlBranch.SelectedIndex = 0;
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            cmd = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con);
            DataTable dt_obj = new DataTable();

            dt_obj.Load(cmd.ExecuteReader());

            ddlBranch.DataSource = dt_obj;
            ddlBranch.DataTextField = "BR_NAME";
            ddlBranch.DataValueField = "BR_ID";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlBranch.Enabled = true;
            //ClearValues();
            //txtDate.Text = getDate();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            con.Close();
            con.Dispose();
            SqlConnection.ClearPool(con);

        }
    }

    protected void clear()
    {
        txtDevice.Text = "";
        txtComplaints.Text = "";
        txtDate.Text = "";
        txtDevice.Text = "";
        txtEmployee.Text = "";
        txtIMEI.Text = "";
        txtIssue.Text = "";
        txtMobileNo.Text = "";
        txtPrinterBtName.Text = "";
        txtReallocEmp.Text = "";
        txtRemarks.Text = "";
        txtRHRmail.Text = "";
    }
}