﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Text;
using Tracker;

public partial class Legal_Reports : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    SqlCommand cmd = new SqlCommand();
    DataSet ds = new DataSet();
    ClsCommon clscommon = new ClsCommon();
    ReportDocument rpt = new ReportDocument();
    SqlConnection con = new SqlConnection();
    SqlDataAdapter dap = new SqlDataAdapter();
    int mdid = 0;
    int MD_LD_ID = 0;
    string sancno = "";
    string empname = "";
    string empid = "";
    string empdesgn = "";

    /*legal pretopup display changes*/
    string oldleadno = "";
    string schemename = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnlglrptprint);

        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {

            }
            else
            {
                Response.Redirect("Expire.aspx");
            }
        }


    }
    protected void btnlglrptprint_Click(object sender, EventArgs e)
    {
        try
        {
            StringBuilder cusnames = new StringBuilder();
            if (ddlstlglrptdoctype.SelectedItem.Text == "--Select--")
            {
                ddlstlglrptdoctype.Focus();
                uscMsgBox1.AddMessage("Please select the document type", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else if (txtbxlglrptleadno.Text.Trim() == "")
            {
                txtbxlglrptleadno.Focus();
                uscMsgBox1.AddMessage("Pleae enter the lead no", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
            {

                /* Report for the Documents to be Collected */
                if (ddlstlglrptdoctype.SelectedItem.Text == "Documents to be Collected")
                {
                    con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();
                    cmd = new SqlCommand("RTS_SP_RPT_DOCS_TOBE_COLLECT_CHECK", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);

                    cmd.CommandTimeout = 12000;
                    dap = new SqlDataAdapter(cmd);
                    ds = new DataSet();
                    dap.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0 && ds.Tables[1].Rows.Count > 0)
                    {
                        //LEGAL EMPLOYEE  CODE , NAME DESIGNATION BRANCH

                        empname = ds.Tables[2].Rows[0]["EMP_NAME"] != DBNull.Value ? ds.Tables[2].Rows[0]["EMP_NAME"].ToString().ToUpper() : "";
                        empid = ds.Tables[2].Rows[0]["EMP_CODE"] != DBNull.Value ? ds.Tables[2].Rows[0]["EMP_CODE"].ToString().ToUpper() : "";
                        empdesgn = ds.Tables[2].Rows[0]["ET_DESC"] != DBNull.Value ? ds.Tables[2].Rows[0]["ET_DESC"].ToString() : "";


                        rpt = new ReportDocument();
                        //set a ReportPath and assign the dataset to reportdocument object
                        rpt.Load(Server.MapPath("Reports/DocumentstobeCollected.rpt"));

                        SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                        rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                        //assign the values to crystal report viewer
                        rpt.SetParameterValue(0, txtbxlglrptleadno.Text);
                        rpt.SetParameterValue(1, Session["EMPNAME"].ToString().ToUpper());
                        rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                        rpt.SetParameterValue(3, empname);
                        rpt.SetParameterValue(4, empid);
                        rpt.SetParameterValue(5, empdesgn);
                        //rpt.SetParameterValue(6, Session["UNITNAME"].ToString());

                        rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Documents to be Colleected For " + txtbxlglrptleadno.Text + "");
                    }
                    else
                    {
                        if (ds.Tables[0].Rows.Count == 0)
                        {
                            txtbxlglrptleadno.Focus();
                            uscMsgBox1.AddMessage("Legal approval not found...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }
                        else if (ds.Tables[0].Rows[0]["MD_SANTD_NO"] == DBNull.Value)
                        {
                            txtbxlglrptleadno.Focus();
                            uscMsgBox1.AddMessage("MODTD not done...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }
                        else if (ds.Tables[1].Rows.Count == 0)
                        {
                            txtbxlglrptleadno.Focus();
                            uscMsgBox1.AddMessage("No Documents found...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

                        }
                    }
                }
                /* Report for the Preliminary */
                else if (ddlstlglrptdoctype.SelectedItem.Text == "Preliminary Opinion")
                {
                    con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();
                    cmd = new SqlCommand("RTS_SP_RPT_PRELIMINARY_UI", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);
                    cmd.CommandTimeout = 12000;
                    dap = new SqlDataAdapter(cmd);
                    ds = new DataSet();
                    dap.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {

                        cusnames = new StringBuilder();

                        if (ds.Tables[1].Rows.Count > 0)
                        {

                            if (ds.Tables[1].Rows[0]["MCB_TITLE"] == DBNull.Value)
                            {
                                cusnames.Append("Mr/Ms. ");
                                cusnames.Append(ds.Tables[0].Rows[0]["LD_APNAME"].ToString());
                                for (int k = 0; k < ds.Tables[1].Rows.Count; k++)
                                {
                                    cusnames.Append(", ");
                                    cusnames.Append(ds.Tables[1].Rows[k]["MCB_NAME"].ToString().TrimEnd());
                                }

                            }
                            else
                            {
                                for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                                {
                                    if (i != ds.Tables[1].Rows.Count - 1)
                                    {
                                        cusnames.Append(ds.Tables[1].Rows[i]["MCB_TITLE"].ToString().TrimEnd() + ds.Tables[1].Rows[i]["MCB_NAME"].ToString().TrimEnd());
                                        cusnames.Append(", ");
                                    }
                                    else
                                    {
                                        cusnames.Append(ds.Tables[1].Rows[i]["MCB_TITLE"].ToString().TrimEnd() + ds.Tables[1].Rows[i]["MCB_NAME"].ToString().TrimEnd());
                                    }


                                }

                            }
                        }
                        else
                        {
                            cusnames.Append("Mr/Ms. ");
                            cusnames.Append(ds.Tables[0].Rows[0]["LD_APNAME"].ToString());
                        }
                        //LEGAL EMPLOYEE  CODE , NAME DESIGNATION BRANCH

                        empname = ds.Tables[2].Rows[0]["EMP_NAME"] != DBNull.Value ? ds.Tables[2].Rows[0]["EMP_NAME"].ToString().ToUpper() : "";
                        empid = ds.Tables[2].Rows[0]["EMP_CODE"] != DBNull.Value ? ds.Tables[2].Rows[0]["EMP_CODE"].ToString().ToUpper() : "";
                        empdesgn = ds.Tables[2].Rows[0]["ET_DESC"] != DBNull.Value ? ds.Tables[2].Rows[0]["ET_DESC"].ToString() : "";

                       // string queries = "1. MODT Doc No. 257/2011 should be produce along with Cancellation Deed with Reflection.\n 2. EC from 01/01/1972 to till date., along with confirmation In Will Deed, it mentioned total extent acre 0.51 cents in that extent Sold some of the Sq.Ft., to some other person need that documents. \n 3. 2nd Floor Building Plan Approval. \n 4. As per Building plan approval for Ground floor 2969 Sq Ft but actual building Constructed area 3341 SQ Ft. \n 5. As per Building plan approval for Fist floor 2969 Sq Ft but actual building Constructed area 3921 Sq Ft. \n 6. Required LOD. \n 7. Pre-Closure Statement required. \n 8. Sq Ft Mismatch in the Current Document, as per will Deed, Remaining extent only 111/2 Cents. (i.e 5009 Sq ft) \n 9. Clear copy of Death Certificate in the name of Mr. Krishnasamy for confirmation of Seal. \n 10.  FMB Sketch to be provided \n 11. TSLR  Back side Sketch to be provided";

                        string queries = clscommon.Bind_Legal_Queries(txtbxlglrptleadno.Text);
                        rpt = new ReportDocument();
                        //set a ReportPath and assign the dataset to reportdocument object
                        rpt.Load(Server.MapPath("Reports/PreliminaryOpinion.rpt"));

                        SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                        rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                        //assign the values to crystal report viewer
                        //rpt.SetParameterValue(0, txtbxlglrptleadno.Text);
                        //rpt.SetParameterValue(1, Session["EMPNAME"].ToString().ToUpper());
                        //rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                        //rpt.SetParameterValue(3, Session["UNITNAME"].ToString());
                        //rpt.SetParameterValue(4, cusnames.ToString());
                        //rpt.SetParameterValue(5, empname);
                        //rpt.SetParameterValue(6, empid);
                        //rpt.SetParameterValue(7, empdesgn);
                        //rpt.SetParameterValue(8, queries);
                        //rpt.SetParameterValue(9, txtbxlglrptleadno.Text);
                        //rpt.SetParameterValue(10, txtbxlglrptleadno.Text);
                        //rpt.SetParameterValue(11, txtbxlglrptleadno.Text);
                        //rpt.SetParameterValue(1, queries);


                        rpt.SetParameterValue(0, txtbxlglrptleadno.Text);
                        rpt.SetParameterValue(1, Session["EMPNAME"].ToString().ToUpper());
                        rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                        rpt.SetParameterValue(3, Session["UNITNAME"].ToString());
                        rpt.SetParameterValue(4, cusnames.ToString());
                        rpt.SetParameterValue(5, empname);
                        rpt.SetParameterValue(6, empid);
                        rpt.SetParameterValue(7, empdesgn);
                        rpt.SetParameterValue(8, queries);
                        rpt.SetParameterValue(9, txtbxlglrptleadno.Text);
                        rpt.SetParameterValue(10, txtbxlglrptleadno.Text);
                       // rpt.SetParameterValue(11, txtbxlglrptleadno.Text);
                        //rpt.SetParameterValue(9, queries);
                        



                        rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Preliminary Opinion For " + txtbxlglrptleadno.Text + "");
                    }
                    else
                    {
                        txtbxlglrptleadno.Focus();
                        uscMsgBox1.AddMessage("Preliminary opinion not done...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }

                 /* Report for the Final Opinion */
                else if (ddlstlglrptdoctype.SelectedItem.Text == "Final Opinion")
                {
                    con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();
                    cmd = new SqlCommand("RTS_SP_RPT_Final_UI", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);
                    cmd.CommandTimeout = 12000;
                    dap = new SqlDataAdapter(cmd);
                    ds = new DataSet();
                    dap.Fill(ds);

                    cusnames = new StringBuilder();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        cusnames = new StringBuilder();

                        if (ds.Tables[1].Rows.Count > 0)
                        {
                            if (ds.Tables[1].Rows[0]["MCB_TITLE"] == DBNull.Value)
                            {
                                cusnames.Append("Mr/Ms. ");
                                cusnames.Append(ds.Tables[0].Rows[0]["LD_APNAME"].ToString());
                                for (int k = 0; k < ds.Tables[1].Rows.Count; k++)
                                {
                                    cusnames.Append(", ");
                                    cusnames.Append(ds.Tables[1].Rows[k]["MCB_NAME"].ToString().TrimEnd());
                                }
                            }
                            else
                            {
                                for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                                {
                                    if (i != ds.Tables[1].Rows.Count - 1)
                                    {
                                        cusnames.Append(ds.Tables[1].Rows[i]["MCB_TITLE"].ToString().TrimEnd() + ds.Tables[1].Rows[i]["MCB_NAME"].ToString().TrimEnd());
                                        cusnames.Append(", ");
                                    }
                                    else
                                    {
                                        cusnames.Append(ds.Tables[1].Rows[i]["MCB_TITLE"].ToString().TrimEnd() + ds.Tables[1].Rows[i]["MCB_NAME"].ToString().TrimEnd());
                                    }
                                }

                            }
                        }
                        else
                        {
                            cusnames.Append("Mr/Ms. ");
                            cusnames.Append(ds.Tables[0].Rows[0]["LD_APNAME"].ToString());
                        }
                        //LEGAL EMPLOYEE  CODE , NAME DESIGNATION BRANCH
                        //                         ds.Tables[2].Rows.Count

                        empname = ds.Tables[2].Rows[0]["EMP_NAME"] != DBNull.Value ? ds.Tables[2].Rows[0]["EMP_NAME"].ToString().ToUpper() : "";
                        empid = ds.Tables[2].Rows[0]["EMP_CODE"] != DBNull.Value ? ds.Tables[2].Rows[0]["EMP_CODE"].ToString().ToUpper() : "";
                        empdesgn = ds.Tables[2].Rows[0]["ET_DESC"] != DBNull.Value ? ds.Tables[2].Rows[0]["ET_DESC"].ToString() : "";

                        oldleadno = ds.Tables[3].Rows[0]["LD_NO"] != DBNull.Value ? ds.Tables[3].Rows[0]["LD_NO"].ToString() : "";
                        schemename = ds.Tables[0].Rows[0]["MPS_NAME"] != DBNull.Value ? ds.Tables[0].Rows[0]["MPS_NAME"].ToString() : "";
                        rpt = new ReportDocument();

                        #region MSE
                        //set a ReportPath and assign the dataset to reportdocument object
                        if (txtbxlglrptleadno.Text.Trim().Contains("MSE"))
                            rpt.Load(Server.MapPath("Reports/FinalOpinion_MSE.rpt"));
                        else
                            rpt.Load(Server.MapPath("Reports/FinalOpinion.rpt"));
                        #endregion

                        SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                        rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                        //assign the values to crystal report viewer
                        rpt.SetParameterValue(0, txtbxlglrptleadno.Text);
                        rpt.SetParameterValue(1, Session["EMPNAME"].ToString().ToUpper());
                        rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                        //rpt.SetParameterValue(3, Session["UNITNAME"].ToString());
                        rpt.SetParameterValue(3, cusnames.ToString());
                        rpt.SetParameterValue(4, empname);
                        rpt.SetParameterValue(5, empdesgn);
                        rpt.SetParameterValue(6, empid);

                        /*legal change pretopup display*/
                        rpt.SetParameterValue(7, oldleadno);
                        rpt.SetParameterValue(8, schemename);

                        rpt.SetParameterValue(9, txtbxlglrptleadno.Text);
                        rpt.SetParameterValue(10, txtbxlglrptleadno.Text);
                        rpt.SetParameterValue(11, txtbxlglrptleadno.Text);
                        rpt.SetParameterValue(12, txtbxlglrptleadno.Text);

                        rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Final Opinion For " + txtbxlglrptleadno.Text + "");
                    }
                    else
                    {
                        txtbxlglrptleadno.Focus();
                        uscMsgBox1.AddMessage("Final Opinion not done...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }

                /* Report for the MODTD*/
                else if (ddlstlglrptdoctype.SelectedItem.Text == "MODTD")
                {
                    SqlCommand cmdmd = new SqlCommand();
                    SqlDataAdapter damd = new SqlDataAdapter();
                    DataSet dsmd = new DataSet();
                    SqlCommand chkcmd = new SqlCommand();

                    try
                    {
                        con = new SqlConnection(strcon);
                        if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                            con.Open();


                        chkcmd = new SqlCommand("RTS_SP_RPT_MODTD", con);
                        chkcmd.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);
                        chkcmd.CommandType = CommandType.StoredProcedure;
                        chkcmd.CommandTimeout = 60000;
                        SqlDataAdapter CHKDAP = new SqlDataAdapter(chkcmd);
                        DataSet CHKDS = new DataSet();
                        CHKDAP.Fill(CHKDS);

                        if (CHKDS.Tables[0].Rows.Count == 0)
                        {
                            uscMsgBox1.AddMessage("MODTD not done...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }
                        else
                        {                           
                                Print();                            
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                    }

                }
                /* Report for the Document Acknowledgement */
                else if (ddlstlglrptdoctype.SelectedItem.Text == "Document Acknowledgement")
                {
                    SqlCommand cmdsub2 = new SqlCommand();

                    SqlDataAdapter dapsub2 = new SqlDataAdapter();


                    SqlCommand cmdsub3 = new SqlCommand();

                    SqlDataAdapter dapsub3 = new SqlDataAdapter();

                    DataTable dtsub3 = new DataTable();


                    DataSet dssub = new DataSet();

                    con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();

                    //MAIN SP
                    cmd = new SqlCommand("RTS_SP_RPT_DOC_ACKNOWLEDGE", con);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);
                    cmd.CommandTimeout = 12000;
                    dap = new SqlDataAdapter(cmd);
                    ds = new DataSet();
                    dap.Fill(ds);

                    cmd = new SqlCommand("RTS_SP_RPT_DOC_ACK_CBRW", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);
                    cmd.CommandTimeout = 12000;
                    dap = new SqlDataAdapter(cmd);
                    DataSet cbrw = new DataSet();
                    dap.Fill(cbrw);
                    if (cbrw.Tables[0].Rows.Count > 0)
                    {

                        cusnames = new StringBuilder();

                        for (int k = 0; k < cbrw.Tables[0].Rows.Count; k++)
                        {

                            if (k != cbrw.Tables[0].Rows.Count - 1)
                            {
                                cusnames.Append(cbrw.Tables[0].Rows[k]["MCB_NAME"].ToString().TrimEnd());
                                cusnames.Append(" / ");
                            }
                            else { cusnames.Append(cbrw.Tables[0].Rows[k]["MCB_NAME"].ToString().TrimEnd()); }
                        }
                    }

                    if (ds.Tables[0].Rows.Count > 0 && ds.Tables[0].Rows[0]["LD_LOAN_NO"] != DBNull.Value && ds.Tables[0].Rows[0]["LD_LOAN_NO"] != "")
                    {

                        /*new legal pretopup display changes*/
                        oldleadno = ds.Tables[1].Rows[0]["LD_NO"] != DBNull.Value ? ds.Tables[1].Rows[0]["LD_NO"].ToString() : "";
                        schemename = ds.Tables[0].Rows[0]["MPS_NAME"] != DBNull.Value ? ds.Tables[0].Rows[0]["MPS_NAME"].ToString() : "";


                        //SUB SP DOCX COUNT
                        cmdsub2 = new SqlCommand("RTS_SP_RPT_DOC_ACK_COUNT", con);

                        cmdsub2.CommandType = CommandType.StoredProcedure;

                        cmdsub2.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);
                        cmdsub2.CommandTimeout = 12000;
                        dapsub2 = new SqlDataAdapter(cmdsub2);
                        dssub = new DataSet();
                        dapsub2.Fill(dssub);

                        string original = "";
                        string photocpy = "";
                        string ccpy = "";
                        string tcpy = "";
                        string tot = "";

                        original = dssub.Tables[0].Rows[0][0] == DBNull.Value ? "" : dssub.Tables[0].Rows[0][0].ToString();
                        photocpy = dssub.Tables[1].Rows[0][0] == DBNull.Value ? "" : dssub.Tables[1].Rows[0][0].ToString();
                        ccpy = dssub.Tables[2].Rows[0][0] == DBNull.Value ? "" : dssub.Tables[2].Rows[0][0].ToString();
                        tcpy = dssub.Tables[3].Rows[0][0] == DBNull.Value ? "" : dssub.Tables[3].Rows[0][0].ToString();
                        tot = dssub.Tables[4].Rows[0][0] == DBNull.Value ? "" : dssub.Tables[4].Rows[0][0].ToString();

                        string PRODUCT = "";
                        PRODUCT = ds.Tables[0].Rows[0]["PR_CODE"] == DBNull.Value ? "" : ds.Tables[0].Rows[0]["PR_CODE"].ToString();
                        if (PRODUCT == "IB-MFHF" || PRODUCT == "IB-G-HF")
                        {
                            cmdsub3 = new SqlCommand("RTS_SP_RPT_LGL_DETS", con);

                            cmdsub3.CommandType = CommandType.StoredProcedure;

                            cmdsub3.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);
                            cmdsub3.CommandTimeout = 12000;
                            dapsub3 = new SqlDataAdapter(cmdsub3);

                            dapsub3.Fill(dtsub3);

                            empname = dtsub3.Rows[0]["EMP_NAME"] != DBNull.Value ? dtsub3.Rows[0]["EMP_NAME"].ToString().ToUpper() : "";
                            empid = dtsub3.Rows[0]["EMP_CODE"] != DBNull.Value ? dtsub3.Rows[0]["EMP_CODE"].ToString().ToUpper() : "";
                            empdesgn = dtsub3.Rows[0]["ET_DESC"] != DBNull.Value ? dtsub3.Rows[0]["ET_DESC"].ToString() : "";

                            cmdsub3 = new SqlCommand("RTS_SP_RPT_DOC_ACK_DOCS", con);

                            cmdsub3.CommandType = CommandType.StoredProcedure;

                            cmdsub3.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);
                            cmdsub3.CommandTimeout = 12000;
                            dtsub3 = new DataTable();
                            dapsub3 = new SqlDataAdapter(cmdsub3);
                            dapsub3.Fill(dtsub3);


                            //if (dtsub3.Rows[0]["DNO"].ToString() == "OLD")
                            //{
                            //    rpt = new ReportDocument();
                            //    //set a ReportPath and assign the dataset to reportdocument object
                            //    rpt.Load(Server.MapPath("Reports/Doc_ack_MFHF_O.rpt"));
                            //}
                            //else
                            //{
                            rpt = new ReportDocument();
                            //set a ReportPath and assign the dataset to reportdocument object
                            // rpt.Load(Server.MapPath("Reports/Doc_ack_MFHF.rpt"));
                            rpt.Load(Server.MapPath("Reports/Doc_ack_MFHF_O.rpt"));

                            //}

                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            //assign the values to crystal report viewer
                            rpt.SetParameterValue(0, txtbxlglrptleadno.Text);
                            rpt.SetParameterValue(1, PRODUCT);
                            rpt.SetParameterValue(2, empname);
                            rpt.SetParameterValue(3, empid);
                            rpt.SetParameterValue(4, original);
                            rpt.SetParameterValue(5, photocpy);
                            rpt.SetParameterValue(6, ccpy);
                            rpt.SetParameterValue(7, tot);

                            rpt.SetParameterValue(8, cusnames.ToString());
                            rpt.SetParameterValue(9, Session["EMPNAME"].ToString());
                            rpt.SetParameterValue(10, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(11, tcpy);
                            rpt.SetParameterValue(12, empdesgn);
                            rpt.SetParameterValue(13, oldleadno);
                            rpt.SetParameterValue(14, schemename);
                            rpt.SetParameterValue(15, txtbxlglrptleadno.Text);

                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Document Acknowledgement Letter For " + txtbxlglrptleadno.Text + "");
                        }
                        else
                        {

                            cmdsub3 = new SqlCommand("RTS_SP_RPT_LGL_DETS", con);

                            cmdsub3.CommandType = CommandType.StoredProcedure;

                            cmdsub3.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);
                            cmdsub3.CommandTimeout = 12000;
                            dapsub3 = new SqlDataAdapter(cmdsub3);

                            dapsub3.Fill(dtsub3);

                            empname = dtsub3.Rows[0]["EMP_NAME"] != DBNull.Value ? dtsub3.Rows[0]["EMP_NAME"].ToString().ToUpper() : "";
                            empid = dtsub3.Rows[0]["EMP_CODE"] != DBNull.Value ? dtsub3.Rows[0]["EMP_CODE"].ToString().ToUpper() : "";
                            empdesgn = dtsub3.Rows[0]["ET_DESC"] != DBNull.Value ? dtsub3.Rows[0]["ET_DESC"].ToString() : "";


                            cmdsub3 = new SqlCommand("RTS_SP_RPT_DOC_ACK_DOCS", con);

                            cmdsub3.CommandType = CommandType.StoredProcedure;

                            cmdsub3.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);
                            cmdsub3.CommandTimeout = 12000;
                            dtsub3 = new DataTable();
                            dapsub3 = new SqlDataAdapter(cmdsub3);
                            dapsub3.Fill(dtsub3);


                            //if (dtsub3.Rows[0]["DNO"].ToString() == "OLD")
                            //{
                            //    rpt = new ReportDocument();
                            //    //set a ReportPath and assign the dataset to reportdocument object
                            //    rpt.Load(Server.MapPath("Reports/DocAck_SME_O.rpt"));
                            //}
                            //else
                            //{

                            rpt = new ReportDocument();
                            //set a ReportPath and assign the dataset to reportdocument object
                            //rpt.Load(Server.MapPath("Reports/DocAck_SME.rpt"));
                            rpt.Load(Server.MapPath("Reports/DocAck_SME_O.rpt"));
                            //}



                            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                            //assign the values to crystal report viewer
                            //assign the values to crystal report viewer
                            rpt.SetParameterValue(0, txtbxlglrptleadno.Text);

                            rpt.SetParameterValue(1, PRODUCT);
                            rpt.SetParameterValue(2, empname);
                            rpt.SetParameterValue(3, empid);
                            rpt.SetParameterValue(4, original);
                            rpt.SetParameterValue(5, photocpy);
                            rpt.SetParameterValue(6, ccpy);
                            rpt.SetParameterValue(7, tot);
                            rpt.SetParameterValue(8, cusnames.ToString());
                            rpt.SetParameterValue(9, Session["EMPNAME"].ToString());
                            rpt.SetParameterValue(10, Session["USR_ID"].ToString());
                            rpt.SetParameterValue(11, tcpy);
                            rpt.SetParameterValue(12, empdesgn);
                            rpt.SetParameterValue(13, oldleadno);
                            rpt.SetParameterValue(14, schemename);
                            rpt.SetParameterValue(15, txtbxlglrptleadno.Text);



                            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Document Acknowledgement Letter For " + txtbxlglrptleadno.Text + "");

                        }
                    }
                    else
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            if (ds.Tables[0].Rows[0]["LD_LOAN_NO"] == DBNull.Value || ds.Tables[0].Rows[0]["LD_LOAN_NO"] == "")
                            {
                                txtbxlglrptleadno.Focus();

                                uscMsgBox1.AddMessage("Loan not yet disbursed...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }
                        }
                        else
                        {
                            txtbxlglrptleadno.Focus();
                            uscMsgBox1.AddMessage("MODTD not done...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

                        }
                    }
                }
                #region LOA
                else if (ddlstlglrptdoctype.SelectedValue == "LOA")
                {
                    string isExists = string.Empty;
                    string ldNum = string.Empty;
                    con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();
                    cmd = new SqlCommand("RTS_SP_LOA", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 2400000;
                    cmd.Parameters.AddWithValue("@LOAN_NO", txtbxlglrptleadno.Text.Trim());
                    cmd.Parameters.AddWithValue("@PTYPE", "CHKEXISTS");
                    isExists = Convert.ToString(cmd.ExecuteScalar());
                    if (!string.IsNullOrEmpty(isExists))
                    {
                        ldNum = getLeadNo();
                        rpt = new ReportDocument();
                        rpt.Load(Server.MapPath("Reports/LOA.rpt"));
                        SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                        rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                        //assign the values to crystal report viewer
                        rpt.SetParameterValue(0, txtbxlglrptleadno.Text);
                        //rpt.SetParameterValue(1, ldNum, rpt.Subreports[0].Name.ToString());                    
                        rpt.SetParameterValue("@LDNO", ldNum, "PropertyDetailsLegalLOA.rpt");
                        //rpt.SetParameterValue(9, Session["EMPNAME"].ToString());
                        //rpt.SetParameterValue(10, Session["USR_ID"].ToString());

                        rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Letter of Authority For " + txtbxlglrptleadno.Text + "");
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("No record found", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        return;
                    }
                }
                #endregion
            }//else validation loop ending


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            rpt.Close();
            rpt.Dispose();
            rpt = null;
            con.Close();
            GC.Collect();

        }

    }
    protected void btnlglrptcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Legal_Reports.aspx");
    }
    public static string NumberToWords(int number)
    {
        if (number == 0)
            return "zero";

        if (number < 0)
            return "minus " + NumberToWords(Math.Abs(number));

        string words = "";

        if ((number / 10000000) > 0)
        {
            words += NumberToWords(number / 10000000) + " Crore ";
            number %= 10000000;
        }

        if ((number / 100000) > 0)
        {
            words += NumberToWords(number / 100000) + " Lakh ";
            number %= 100000;
        }

        if ((number / 1000) > 0)
        {
            words += NumberToWords(number / 1000) + " Thousand ";
            number %= 1000;
        }

        if ((number / 100) > 0)
        {
            words += NumberToWords(number / 100) + " Hundred ";
            number %= 100;
        }

        if (number > 0)
        {
            if (words != "")
                words += "and ";

            var unitsMap = new[] { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
            var tensMap = new[] { "Zero", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

            if (number < 20)
                words += unitsMap[number];
            else
            {
                words += tensMap[number / 10];
                if ((number % 10) > 0)
                    words += "-" + unitsMap[number % 10];
            }
        }
        return words;
    }
    protected void Print()
    {
        try
        {
            SqlCommand cmdmd = new SqlCommand("RTS_SP_RPT_MODTD_BRW_CBRW", con);
            cmdmd.Parameters.AddWithValue("@LDNO", txtbxlglrptleadno.Text);
            cmdmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter damd = new SqlDataAdapter(cmdmd);
            DataSet dsmd = new DataSet();
            damd.Fill(dsmd);

            if (dsmd.Tables[0].Rows.Count <= 0)
            {
                uscMsgBox1.AddMessage("Please check the lead number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                sancno = dsmd.Tables[0].Rows[0]["MD_SANTD_NO"] == DBNull.Value ? "" : dsmd.Tables[0].Rows[0]["MD_SANTD_NO"].ToString();
                string amt = "";
                string TMP = dsmd.Tables[0].Rows[0]["MD_LOAN_AMT"] == DBNull.Value ? "" : dsmd.Tables[0].Rows[0]["MD_LOAN_AMT"].ToString();
                if (TMP != "")
                {
                    string[] tp = TMP.Split('.');
                    amt = NumberToWords(Convert.ToInt32(tp[0]));
                }

                StringBuilder brw_cbrw = new StringBuilder();
                int cnt = 0;

                if (dsmd.Tables[1].Rows.Count > 0)
                {
                    if (dsmd.Tables[1].Rows[0]["MCB_TITLE"] == DBNull.Value)
                    {
                        if (dsmd.Tables[0].Rows[0]["MD_BR1_NAME"] != DBNull.Value)
                        {
                            brw_cbrw.Append("1) ");
                            brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_NAME"].ToString().TrimEnd());
                            brw_cbrw.Append(",");

                        }

                        if (dsmd.Tables[0].Rows[0]["MD_BR1_AGE"] != DBNull.Value)
                        {
                            brw_cbrw.Append(" aged about ");
                            brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_AGE"].ToString().TrimEnd());
                            brw_cbrw.Append(" years,");
                        }

                        if (dsmd.Tables[0].Rows[0]["MCB_PF_NO"] != DBNull.Value)
                        {
                            brw_cbrw.Append("( PAN : ");
                            brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MCB_PF_NO"].ToString().TrimEnd());
                            brw_cbrw.Append("),");
                        }
                        else
                        {
                            brw_cbrw.Append("( PAN : ");
                            brw_cbrw.Append("              ");
                            brw_cbrw.Append("),");
                        }

                        /* Borrower Details*/
                        if (dsmd.Tables[0].Rows[0]["MD_BR1_FNAME"] != DBNull.Value)
                        {
                            brw_cbrw.Append(" S/D/W/F of ");
                            brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_FNAME"].ToString());
                            brw_cbrw.Append(",");
                        }


                       

                        /*Co - Borrower Details*/

                        for (int i = 0; i <= dsmd.Tables[1].Rows.Count - 1; i++)
                        {

                            brw_cbrw.AppendLine();
                            brw_cbrw.Append((i + 2).ToString() + ") ");
                            brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_NAME"].ToString().TrimEnd());
                            brw_cbrw.Append(",");
                            brw_cbrw.Append(" S/D/W/F of ");
                            brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_FNAME"].ToString().TrimEnd());
                            brw_cbrw.Append(",");
                            brw_cbrw.Append(" aged about ");
                            brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_AGE"].ToString().TrimEnd());
                            brw_cbrw.Append(" years,");
                        }

                        cnt = 1 + dsmd.Tables[1].Rows.Count;
                    }
                    else
                    {
                        /*Co - Borrower Details*/

                        for (int i = 0; i <= dsmd.Tables[1].Rows.Count - 1; i++)
                        {

                            brw_cbrw.AppendLine();
                            brw_cbrw.Append((i + 1).ToString() + ") ");
                            brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_TITLE"].ToString().TrimEnd());
                            brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_NAME"].ToString().TrimEnd());
                            brw_cbrw.Append(",");
                            brw_cbrw.Append(" aged about ");
                            brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_AGE"].ToString().TrimEnd());
                            brw_cbrw.Append(" years");
                            brw_cbrw.Append(", ");
                            brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_RELATION"].ToString().TrimEnd() + " ");
                            brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_FTITLE"].ToString().TrimEnd());
                            brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_FNAME"].ToString().TrimEnd());
                            brw_cbrw.Append(" ( ");
                            brw_cbrw.Append(dsmd.Tables[1].Rows[i]["PF_DESC"].ToString().TrimEnd());
                            brw_cbrw.Append(" - ");
                            brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_PF_NO"].ToString().TrimEnd());
                            brw_cbrw.Append(" ) ");
                            
                        }

                        cnt = dsmd.Tables[1].Rows.Count;
                    }
                }
                else
                {
                    if (dsmd.Tables[0].Rows[0]["MD_BR1_NAME"] != DBNull.Value)
                    {
                        brw_cbrw.Append("1) ");
                        brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_NAME"].ToString().TrimEnd());
                        brw_cbrw.Append(",");

                    }

                    if (dsmd.Tables[0].Rows[0]["MCB_PF_NO"] != DBNull.Value)
                    {
                        brw_cbrw.Append("( PAN : ");
                        brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MCB_PF_NO"].ToString().TrimEnd());
                        brw_cbrw.Append("),");
                    }
                    else
                    {
                        brw_cbrw.Append("( PAN : ");
                        brw_cbrw.Append("              ");
                        brw_cbrw.Append("),");
                    }


                    if (dsmd.Tables[0].Rows[0]["MD_BR1_AGE"] != DBNull.Value)
                    {
                        brw_cbrw.Append(" aged about ");
                        brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_AGE"].ToString().TrimEnd());
                        brw_cbrw.Append(" years, ");
                    }

                    /* Borrower Details*/
                    if (dsmd.Tables[0].Rows[0]["MD_BR1_FNAME"] != DBNull.Value)
                    {
                        brw_cbrw.Append(" S/D/W/F of ");
                        brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_FNAME"].ToString());
                        brw_cbrw.Append(",");
                    }


                   

                    /*Co - Borrower Details*/

                    for (int i = 0; i <= dsmd.Tables[1].Rows.Count - 1; i++)
                    {

                        brw_cbrw.AppendLine();
                        brw_cbrw.Append((i + 2).ToString() + ") ");
                        brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_NAME"].ToString().TrimEnd());
                        brw_cbrw.Append(",");
                        brw_cbrw.Append(" S/D/W/F of ");
                        brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_FNAME"].ToString().TrimEnd());
                        brw_cbrw.Append(",");
                        brw_cbrw.Append(" aged about ");
                        brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_AGE"].ToString().TrimEnd());
                        brw_cbrw.Append(" years,");
                    }

                    cnt = 1 + dsmd.Tables[1].Rows.Count;
                }
                rpt = new ReportDocument();
                //ParameterValues para = new ParameterValues(); 
                //set a ReportPath and assign the dataset to reportdocument object
                if (dsmd.Tables[0].Rows[0]["MD_SM_APPLCNT"].ToString() == "Yes")
                {
                    rpt.Load(Server.MapPath("Reports/MODTDF1.rpt"));
                }
                else if (dsmd.Tables[0].Rows[0]["MD_SM_APPLCNT"].ToString() == "No")
                {
                    rpt.Load(Server.MapPath("Reports/MODTDF2.rpt"));
                }
                else
                {
                    rpt.Load(Server.MapPath("Reports/MODTD.rpt"));
                }
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);
                //  rpt.SetDatabaseLogon("uno", "uno", @"172.16.2.95", "RTS1");
                //assign the values to crystal report viewer                              
                rpt.SetParameterValue(0, txtbxlglrptleadno.Text);
                rpt.SetParameterValue(1, amt);
                rpt.SetParameterValue(2, brw_cbrw.ToString());
                rpt.SetParameterValue(3, cnt);
                rpt.SetParameterValue(4, txtbxlglrptleadno.Text);
                rpt.SetParameterValue(5, txtbxlglrptleadno.Text);
                rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "MODTD For " + txtbxlglrptleadno.Text);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //con.Close();
            //rpt.Close();
            //rpt.Dispose();
            //rpt = null;
            //GC.Collect();
        }
    }
    #region LOA
    protected string getLeadNo()
    {
        string ldNo = string.Empty;
        SqlConnection conLoa = new SqlConnection(strcon);
        SqlCommand cmdLoa = new SqlCommand();
        try
        {

            if (conLoa.State == ConnectionState.Broken || conLoa.State == ConnectionState.Closed)
                conLoa.Open();
            cmdLoa = new SqlCommand("RTS_SP_LOA", conLoa);
            cmdLoa.CommandType = CommandType.StoredProcedure;
            cmdLoa.CommandTimeout = 24000000;
            cmdLoa.Parameters.AddWithValue("@LOAN_NO", txtbxlglrptleadno.Text.Trim());
            cmdLoa.Parameters.AddWithValue("@PTYPE", "GETLDNOLOA");
            ldNo = Convert.ToString(cmdLoa.ExecuteScalar());
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmdLoa.Dispose();
            conLoa.Close();
            GC.Collect();
        }
        return ldNo;
    }

    protected void ddlstlglrptdoctype_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlstlglrptdoctype.SelectedItem.Text == "LOA")
            spnLNo.InnerText = "Loan No";
        else
            spnLNo.InnerText = "Lead No";
    }
    #endregion
}