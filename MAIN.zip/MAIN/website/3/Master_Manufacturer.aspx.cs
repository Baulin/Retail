﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_Manufacturer : System.Web.UI.Page
{
    ClsCommon clscommon = new ClsCommon();
    int areaid;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                BindManufacturer();
            }
            else
            {
                Response.Redirect("default.aspx");
            }
          
           
        }
    }
   
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      
    }
    protected void gvEmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        //gvEmp.Rows[gvEmp.SelectedIndex].BackColor = Color.Red;
    }
    protected void BindManufacturer()
    {
        try
        {
            DataSet dsdd = new DataSet();
            dsdd = clscommon.Bind_Manufacturer_Details("","");
            gvManufacturer.DataSource = dsdd;
            gvManufacturer.DataBind();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow grow in gvManufacturer.Rows)
            {
                RadioButton chkUserID = (RadioButton)grow.FindControl("rb_select");
                if (chkUserID.Checked)
                {



                    Label lblstat = (Label)grow.FindControl("lblmfcstat");
                    Label lblid = (Label)grow.FindControl("lblmfcid");
                    txtMFCCode.Text = grow.Cells[1].Text;
                    txtMFCName.Text = grow.Cells[2].Text;

                    txtMFCModel.Text = grow.Cells[3].Text;
                    txtMRPCost.Text = grow.Cells[4].Text;
                    txtMinAmount.Text = grow.Cells[5].Text;
                    txtMaxAmount.Text = grow.Cells[6].Text;
                    Session["MFC_ID"] = lblid.Text.ToString();
                    ddlstatus.SelectedValue = lblstat.Text;
                    btnSubmit.Text = "Update";
                    /*ddlBrname.SelectedValue = grow.Cells[4].Text;
                    ddlempcontype.SelectedValue = lbl_emp_type.Text;

                    ddlstempstatus.SelectedValue = lblstat.Text;

                    if (grow.Cells[5].Text == "&nbsp;")
                    {
                        txtContactno.Text = "";
                    }
                    else
                    {
                        txtContactno.Text = grow.Cells[5].Text;
                    }

                    if (lblmail.Text == "&nbsp;")
                    {
                        txtEmailid.Text = "";
                    }
                    else
                    {
                        txtEmailid.Text = lblmail.Text;
                    }
                    btnSubmit.Text = "Update";
                    Session["EMPID"] = lblid.Text;

                    SetEmploymentType();
                    break;*/
                    break;
                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
           
            con.Open();
            if (btnSubmit.Text == "Submit")
            {
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_MR_MANUFACTURER", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;

                cmdinsert.Parameters.AddWithValue("@MFC_CODE", txtMFCCode.Text);
                cmdinsert.Parameters.AddWithValue("@MFC_NAME", txtMFCName.Text);
                cmdinsert.Parameters.AddWithValue("@MFC_MODEL", txtMFCModel.Text);
                cmdinsert.Parameters.AddWithValue("@MFC_MRP", Convert.ToDouble(txtMRPCost.Text));
                cmdinsert.Parameters.AddWithValue("@MFC_MAX_AMNT", Convert.ToDouble(txtMaxAmount.Text));
                cmdinsert.Parameters.AddWithValue("@MFC_MIN_AMNT", Convert.ToDouble(txtMinAmount.Text));
                cmdinsert.Parameters.AddWithValue("@MFC_STAT", ddlstatus.SelectedValue);
                cmdinsert.Parameters.AddWithValue("@MFC_CBY", Convert.ToInt32(Session["ID"]));
                cmdinsert.Parameters.AddWithValue("@MFC_CDATE", DateTime.Now);
                cmdinsert.Parameters.AddWithValue("@TYPE", "MR_INSERT");
                cmdinsert.Parameters.AddWithValue("@MFC_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmdinsert.ExecuteNonQuery();
                int MFC_ID = Convert.ToInt32(cmdinsert.Parameters["@MFC_ID"].Value);

                // uscMsgBox1.AddMessage("Branch Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('" + txtMFCCode.Text.ToString() + "-" + txtMFCName.Text + "-" + txtMFCModel.Text + " Details has been Saved Successfully.');window.location.reload()", true);

            }
            else
                if(btnSubmit.Text == "Update")
                {
                    int mfc_id=Convert.ToInt32(Session["MFC_ID"]);
                    SqlCommand cmdinsert = new SqlCommand("RTS_SP_MR_MANUFACTURER", con);
                    cmdinsert.CommandType = CommandType.StoredProcedure;

                    cmdinsert.Parameters.AddWithValue("@MFC_CODE", txtMFCCode.Text);
                    cmdinsert.Parameters.AddWithValue("@MFC_NAME", txtMFCName.Text);
                    cmdinsert.Parameters.AddWithValue("@MFC_MODEL", txtMFCModel.Text);
                    cmdinsert.Parameters.AddWithValue("@MFC_MRP", Convert.ToDouble(txtMRPCost.Text));
                    cmdinsert.Parameters.AddWithValue("@MFC_MAX_AMNT", Convert.ToDouble(txtMaxAmount.Text));
                    cmdinsert.Parameters.AddWithValue("@MFC_MIN_AMNT", Convert.ToDouble(txtMinAmount.Text));
                    cmdinsert.Parameters.AddWithValue("@MFC_STAT", Convert.ToInt32(ddlstatus.SelectedValue));
                    cmdinsert.Parameters.AddWithValue("@MFC_MBY", Convert.ToInt32(Session["ID"]));
                    cmdinsert.Parameters.AddWithValue("@MFC_MDATE", DateTime.Now);
                    cmdinsert.Parameters.AddWithValue("@TYPE", "MR_UPDATE");
                    cmdinsert.Parameters.AddWithValue("@MR_ID", mfc_id);
                    //cmdinsert.Parameters.AddWithValue("@MFC_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
                    cmdinsert.ExecuteNonQuery();
                   // int MFC_ID = Convert.ToInt32(cmdinsert.Parameters["@MFC_ID"].Value);

                    // uscMsgBox1.AddMessage("Branch Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('" + txtMFCCode.Text.ToString() + "-" + txtMFCName.Text + "-" + txtMFCModel.Text + " Details has been updated successfully.');window.location.reload()", true);

                }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_Branch.aspx");
    }
}