﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using System.Net.Mail;
using Tracker;
using Utilities;


public partial class CAM_SMAL_Sampling : System.Web.UI.Page
{
    public static DataTable dtSourceOfIncome = null;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    public static bool blMailStatus = false;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";

    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;

    /*Mail id variables*/
    string ldno, area, brnch, apname, apmobile, propaddr, gv, landarea;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                VisibleFalse();
                clear();
                ddlTenure.SelectedValue = "5";
                txtBranchName.Text = Session["UNITNAME"].ToString();
                BindDropdownList();
                FirstGridViewRow();
                bindCustProfile();
                bindFarmerActivity();
            }
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
    }

    private void VisibleFalse()
    {
        row1.Visible = false;
        row2.Visible = false;
        row3.Visible = false;
        row4.Visible = false;
        row5.Visible = false;
        row6.Visible = false;
        row7.Visible = false;
        // row8.Visible = false;
    }

    protected void BindDropdownList()
    {
        BindLeadNo();
        BindRelationship();
        BindIncomeSource();
        BindVintage();
        BindLoanPurpose();
        BindCreditHistory();
        BindCustRelation();
        BindProperty();
        BindOccupancy();
        BindUsage();
        BindBDAge();
        BindCategory();
        //  BindTenor();
        BindIntrest();
        // BindLawyerName();
        bindCloseReason();
    }

    // __________BIND DROP DOWN LIST START_____________//


    public void BindLeadNo()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_Lead_Sampling_Details", con);
        cmddd.Parameters.AddWithValue("@LD_NO", "");
        cmddd.Parameters.AddWithValue("@Lead_Type", "SMFL");
        cmddd.Parameters.AddWithValue("@EMP_ID", Session["EMPID"] != null ? Session["EMPID"].ToString() : "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLeadNo.DataSource = dsdd;
        ddlLeadNo.DataTextField = "LD_NO";
        ddlLeadNo.DataValueField = "LD_ID";
        ddlLeadNo.DataBind();
        ddlLeadNo.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindBankStmt()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("SP_RTS_Fetch_BankSTmt", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlBnkSTmt.DataSource = dsdd;
        ddlBnkSTmt.DataTextField = "DS_DESC";
        ddlBnkSTmt.DataValueField = "DS_ID";
        ddlBnkSTmt.DataBind();
        ddlBnkSTmt.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindRelationship()
    {
        //SqlConnection con = new SqlConnection(strcon);
        //con.Open();
        //SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Relation", con);
        //cmddd.Parameters.AddWithValue("@ER_ID", "");
        //cmddd.CommandType = CommandType.StoredProcedure;
        //SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        //DataSet dsdd = new DataSet();
        //dadd.Fill(dsdd);

        //con.Close();
        //ddlRelationShip.DataSource = dsdd;
        //ddlRelationShip.DataTextField = "ER_DESC";
        //ddlRelationShip.DataValueField = "ER_ID";
        //ddlRelationShip.DataBind();
        //ddlRelationShip.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindIncomeSource()
    {
        //SqlConnection con = new SqlConnection(strcon);
        //con.Open();
        //SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_IN_SOURCE", con);
        //cmddd.Parameters.AddWithValue("@INS_ID", "");
        //cmddd.CommandType = CommandType.StoredProcedure;
        //SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        //DataSet dsdd = new DataSet();
        //dadd.Fill(dsdd);

        //con.Close();
        //ddlMainApplicant.DataSource = dsdd;
        //ddlMainApplicant.DataTextField = "INS_DESC";
        //ddlMainApplicant.DataValueField = "INS_ID";
        //ddlMainApplicant.DataBind();
        //ddlMainApplicant.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindVintage()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);
        cmddd.Parameters.AddWithValue("@VN_ID", "");
        cmddd.Parameters.AddWithValue("@VN_INS_ID", "3");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlVintage.DataSource = dsdd;
        ddlVintage.DataTextField = "VN_DESC";
        ddlVintage.DataValueField = "VN_ID";
        ddlVintage.DataBind();
        ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindLoanPurpose()
    {
        //SqlConnection con = new SqlConnection(strcon);
        //con.Open();
        //SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PURPOSE", con);
        //cmddd.Parameters.AddWithValue("@PP_ID", "");
        //cmddd.Parameters.AddWithValue("@ISACTIVE", "2");
        //cmddd.CommandType = CommandType.StoredProcedure;
        //SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        //DataSet dsdd = new DataSet();
        //dadd.Fill(dsdd);

        //con.Close();
        //ddlLoanPurpose.DataSource = dsdd;
        //ddlLoanPurpose.DataTextField = "PP_DESC";
        //ddlLoanPurpose.DataValueField = "PP_ID";
        //ddlLoanPurpose.DataBind();
    }
    public void BindCreditHistory()
    {
        //SqlConnection con = new SqlConnection(strcon);
        //con.Open();
        //SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CR_HISTORY", con);
        //cmddd.Parameters.AddWithValue("@CH_ID", "");
        //cmddd.CommandType = CommandType.StoredProcedure;
        //SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        //DataSet dsdd = new DataSet();
        //dadd.Fill(dsdd);

        //con.Close();
        //ddlCreditHistory.DataSource = dsdd;
        //ddlCreditHistory.DataTextField = "CH_DESC";
        //ddlCreditHistory.DataValueField = "CH_ID";
        //ddlCreditHistory.DataBind();
        //ddlCreditHistory.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindCustRelation()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_RELATION", con);
        cmddd.Parameters.AddWithValue("@RL_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        DataRow[] drRel = dsdd.Tables[0].Select("RL_DESC <> 'Others'");
        con.Close();
        ddlCustRelation.DataSource = drRel.CopyToDataTable();
        ddlCustRelation.DataTextField = "RL_DESC";
        ddlCustRelation.DataValueField = "Rl_ID";
        ddlCustRelation.DataBind();
        ddlCustRelation.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindProperty()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY", con);
        cmddd.Parameters.AddWithValue("@PT_ID", "");
        cmddd.Parameters.AddWithValue("@PT_TYPE", "A");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlPropType.DataSource = dsdd;
        /*if (txtRelWithEquitas.Text != "Member")
        {
            DataRow[] drTempPrp = dsdd.Tables[0].Select("PT_DESC not like '%Vacant%'");
            ddlPropType.DataSource = drTempPrp.CopyToDataTable();
        }*/
        ddlPropType.DataTextField = "PT_DESC";
        ddlPropType.DataValueField = "PT_DESC";
        //ddlPropType.DataValueField = "PT_RSQRT";
        ddlPropType.DataBind();
        ddlPropType.Items.Insert(0, new ListItem("--Select--", ""));
    }
    public void BindOccupancy()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_OCCUPANCY", con);
        cmddd.Parameters.AddWithValue("@OC_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        DataRow[] drOccData = dsdd.Tables[0].Select("OC_DESC <> 'NA'");



        con.Close();
        ddlOccupancyStatus.DataSource = drOccData.CopyToDataTable();
        ddlOccupancyStatus.DataTextField = "OC_DESC";
        ddlOccupancyStatus.DataValueField = "OC_ID";
        ddlOccupancyStatus.DataBind();
        ddlOccupancyStatus.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindUsage()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_USAGE", con);
        cmddd.Parameters.AddWithValue("@UG_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlUsage.DataSource = dsdd;
        ddlUsage.DataTextField = "UG_DESC";
        ddlUsage.DataValueField = "UG_ID";
        ddlUsage.DataBind();
        ddlUsage.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindBDAge()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_BD_AGE", con);
        cmddd.Parameters.AddWithValue("@BA_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();
        ddlAgeOfBuilding.DataSource = dsdd;
        ddlAgeOfBuilding.DataTextField = "BA_DESC";
        ddlAgeOfBuilding.DataValueField = "BA_DESC";
        ddlAgeOfBuilding.DataBind();
        ddlAgeOfBuilding.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindCategory()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
        cmddd.Parameters.AddWithValue("@CT_ID", "");
        cmddd.Parameters.AddWithValue("@CT_TYPE", "A");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        dtSourceOfIncome = dsdd.Tables[0];
        con.Close();
        ddlCustSource.DataSource = dsdd;
        ddlCustSource.DataTextField = "CT_DESC";
        ddlCustSource.DataValueField = "CT_DESC";
        ddlCustSource.DataBind();
        ddlCustSource.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindTenor()
    {
        string strFileName = "ASLTenor.xml";
        if (ddlLeadNo.SelectedItem.Text.Contains("ELP"))
        {
            strFileName = "EMPTenor.xml";
        }
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("XML/" + strFileName + ""));

        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();

        if (ds.Tables[0].Rows.Count != 0)
        {
            ddlTenure.DataSource = ds.Tables[0];

            ddlTenure.DataTextField = "Tenor";

            ddlTenure.DataValueField = "Tenor";

            ddlTenure.DataBind();
            ddlTenure.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        else
        {
            ddlTenure.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }

    public void BindIntrest()
    {
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("XML/ASLInterstRate.xml"));

        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();

        if (ds.Tables.Count != 0)
        {
            ddlIntrest.DataSource = ds;

            ddlIntrest.DataTextField = "Intrest";

            ddlIntrest.DataValueField = "Intrest";

            ddlIntrest.DataBind();

            ddlIntrest.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }

    public DataSet fetchLeadDetails(string strLeadNo)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Lead_Details", con);
        cmddd.Parameters.AddWithValue("@LD_NO", strLeadNo);
        cmddd.Parameters.AddWithValue("@Lead_Type", "SMFL");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        return dsdd;
    }
    // __________BIND DROP DOWN LIST END_____________//


    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            btnSubmit.Enabled = false;
            if (DDLkycName.SelectedIndex != 0 && ddlCustSource.SelectedItem.Text != "--Select--" && txtCustAge.Text != "" && ddlCustRelation.SelectedItem.Text != "--Select--"
                                   && txtIncome.Text != "")
            {
                AddNewRow();
            }
            else
            {
                if (DDLkycName.SelectedIndex == 0)
                {
                    DDLkycName.Focus();

                }
                else if (ddlCustSource.SelectedItem.Text == "--Select--")
                {
                    ddlCustSource.Focus();
                }
                else if (txtCustAge.Text == "")
                {
                    txtCustAge.Focus();

                }
                else if (ddlCustRelation.SelectedItem.Text == "--Select--")
                {
                    ddlCustSource.Focus();
                }
                else if (txtIncome.Text == "")
                {
                    txtCustAge.Focus();

                }
                uscMsgBox1.AddMessage("Please Give corresponding Inputs for Income details", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    private void FirstGridViewRow()
    {


        DataTable dt = new DataTable();
        DataRow dr = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("NAME", typeof(string)));
        dt.Columns.Add(new DataColumn("APP_TYPE", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_SOURCE", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_SOURCEID", typeof(string)));
        dt.Columns.Add(new DataColumn("AGE", typeof(string)));
        dt.Columns.Add(new DataColumn("RELATIONSHIP", typeof(string)));
        dt.Columns.Add(new DataColumn("RELATIONSHIPID", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_TAKEN", typeof(string)));
        dt.Columns.Add(new DataColumn("FACTORED_INCOME", typeof(string)));

        dr = dt.NewRow();
        //dr["RowNumber"] = 1;

        dr["NAME"] = string.Empty;
        dr["APP_TYPE"] = string.Empty;
        dr["INCOME_SOURCE"] = string.Empty;
        dr["INCOME_SOURCEID"] = string.Empty;
        dr["AGE"] = string.Empty;
        dr["RELATIONSHIP"] = string.Empty;
        dr["RELATIONSHIPID"] = string.Empty;
        dr["INCOME"] = string.Empty;
        dr["INCOME_TAKEN"] = string.Empty;
        dr["FACTORED_INCOME"] = string.Empty;
        dt.Rows.Add(dr);

        ViewState["CurrentTable"] = dt;

        gvIncomeDetail.DataSource = dt;
        gvIncomeDetail.DataBind();


    }
    private void AddNewRow()
    {
        int rowIndex = 0;
        bool blAgri = false;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;
            DataRow[] tempDr = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                tempDr = dtCurrentTable.Select("INCOME_SOURCE like '%Agri%'");
                // Non regular Income
                //if (tempDr != null && tempDr.Length == 0)
                //{
                //    tempDr = dtCurrentTable.Select("INCOME_SOURCE like '%Non regular Income%'");
                //}
            }

            if (tempDr != null && tempDr.Length > 0)
            {
                blAgri = true;
            }
            else
            {
                /* if (TBAppType.Text == "Applicant")
                 {
                     blAgri = true;
                 }*/
                if (TBAppType.Text == "Applicant" && ddlCustProfile.SelectedItem.Text == "Agri Laborer")
                {
                    blAgri = true;
                }

                if (TBAppType.Text == "Applicant" && ddlCustSource.SelectedItem.Text == "Agri Income")
                {
                    blAgri = true;
                }
                if (ddlCustProfile.SelectedItem.Text == "Agri Laborer")
                {
                    blAgri = true;
                }
            }


            if (dtCurrentTable.Rows.Count > 0 && dtCurrentTable.Rows[0][0].ToString() == "")
            {
                dtCurrentTable.Rows.RemoveAt(0);
            }
            drCurrentRow = dtCurrentTable.NewRow();
            drCurrentRow["NAME"] = DDLkycName.SelectedItem.Text;
            drCurrentRow["APP_TYPE"] = TBAppType.Text;

            //DDLkycName.Items.RemoveAt(DDLkycName.SelectedIndex);
            //DDLkycName.DataBind();
            drCurrentRow["INCOME_SOURCE"] = ddlCustSource.SelectedItem.Text != "--Select--" ? ddlCustSource.SelectedItem.Text : "";
            int INCOME_SOURCEID = FetchINCOME_SOURCEID(ddlCustSource.SelectedItem.Text);
            drCurrentRow["INCOME_SOURCEID"] = INCOME_SOURCEID;
            drCurrentRow["AGE"] = txtCustAge.Text;
            drCurrentRow["RELATIONSHIP"] = ddlCustRelation.SelectedItem.Text != "--Select--" ? ddlCustRelation.SelectedItem.Text : "";
            drCurrentRow["RELATIONSHIPID"] = ddlCustRelation.SelectedItem.Text != "--Select--" ? ddlCustRelation.SelectedValue.ToString() : "";
            drCurrentRow["INCOME"] = txtIncome.Text;
            drCurrentRow["INCOME_TAKEN"] = txtIncomeTaken.Text;
            drCurrentRow["FACTORED_INCOME"] = txtFactor.Text;

            //  rowIndex++;
            // }
            //if (ddlCustSource.SelectedItem.Text.Contains("Rent") || ddlCustSource.SelectedItem.Text.Contains("Pension"))
            //{
            if (blAgri == false)
            {
                uscMsgBox1.AddMessage("Other Income can be considered, only if there is an agricultural income established in the CAM", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                return;

            }
            //}
            dtCurrentTable.Rows.Add(drCurrentRow);
            ViewState["CurrentTable"] = dtCurrentTable;

            gvIncomeDetail.DataSource = dtCurrentTable;
            gvIncomeDetail.DataBind();
            Clear();

          /*  double dblOldIncome = 0.0;
            foreach (GridViewRow grow in gvIncomeDetail.Rows)
            {
                int index = grow.RowIndex;
                double dblIncome = Convert.ToDouble(gvIncomeDetail.Rows[index].Cells[5].Text);
                if (Convert.ToInt32(gvIncomeDetail.Rows[index].Cells[3].Text) < 60)
                {


                    if (dblIncome > dblOldIncome)
                    {
                        txtNameofInsuredPerson.Text = gvIncomeDetail.Rows[index].Cells[0].Text;
                        dblOldIncome = dblIncome;
                    }
                }

            }*/
            //bala changes 05112016
            string strOldname = "", strNewname = "";
            double Amount = 0.0;
            int nvalue = 0;
            DataTable dt1 = new DataTable();
            dt1.Columns.AddRange(new DataColumn[2] { 
                            new DataColumn("Name", typeof(string)),
                            new DataColumn("Amount", typeof(int)) });
            //DataTable dtTempData = dtCurrentTable.Select("AGE < 60").CopyToDataTable();
            DataRow[] drTemp = dtCurrentTable.Select("AGE < 60");
            if (drTemp.Length > 0)
            {
                DataTable dtTempData = drTemp.CopyToDataTable();
                if (dtTempData != null && dtTempData.Rows.Count > 0)
                {
                    for (int ncount = 0; ncount < dtTempData.Rows.Count; ncount++)
                    {
                        strNewname = dtTempData.Rows[ncount]["NAME"] != DBNull.Value ? dtTempData.Rows[ncount]["NAME"].ToString() : "";
                        Amount = dtTempData.Rows[ncount]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtTempData.Rows[ncount]["FACTORED_INCOME"]) : 0.0;
                        if (strOldname == "")
                        {
                            dt1.Rows.Add(strNewname, Amount);

                        }
                        else if (strOldname == strNewname)
                        {

                            dt1.Rows[nvalue]["Amount"] = Convert.ToDouble(dt1.Rows[nvalue]["Amount"]) + Amount;
                        }
                        else
                        {
                            dt1.Rows.Add(strNewname, Amount);
                            nvalue = nvalue + 1;
                        }
                        strOldname = strNewname;
                    }
                }
                if (dt1 != null && dt1.Rows.Count > 0)
                {
                    double dblTempAmount = 0.0;
                    for (int n = 0; n < dt1.Rows.Count; n++)
                    {

                        double dblAmont = dt1.Rows[n]["Amount"] != DBNull.Value ? Convert.ToDouble(dt1.Rows[n]["Amount"]) : 0.0;
                        if (dblAmont > dblTempAmount)
                        {
                            txtNameofInsuredPerson.Text = dt1.Rows[n]["Name"] != DBNull.Value ? dt1.Rows[n]["Name"].ToString() : "";
                            dblTempAmount = dblAmont;
                        }

                    }
                }
            }
            //bala changes end 05112016
            if (dtCurrentTable != null && dtCurrentTable.Rows.Count > 0)
            {
                double nTotalLoanEligibility = 0.0;

                for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                {
                    double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                    nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;
                }
                if (nTotalLoanEligibility > 100000)
                {
                    dtCurrentTable.Rows.RemoveAt(dtCurrentTable.Rows.Count - 1);
                    ViewState["CurrentTable"] = dtCurrentTable;
                    gvIncomeDetail.DataSource = dtCurrentTable;
                    gvIncomeDetail.DataBind();
                    uscMsgBox1.AddMessage("The Maximum Loan amount to be restricied Upto 1 Lakh", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    return;
                }
                txtTotalLoanEligibility.Text = nTotalLoanEligibility.ToString();

                BindBorrower(dtCurrentTable);
            }
            //  }
        }
        else
        {
            Response.Write("ViewState is null");
        }
        //  SetPreviousData();
    }
    public void BindBorrower(DataTable dt)
    {
        /// NAME

        string strBrwname1 = "", strBrwname2 = "", strBrwname3 = "", strBrwname4 = "", strBrwname5 = "";

        if (drpName1.Items.Count > 0)
        {
            strBrwname1 = drpName1.SelectedValue;
        }
        if (drpName2.Items.Count > 0)
        {
            strBrwname2 = drpName2.SelectedValue;
        }
        if (drpName3.Items.Count > 0)
        {
            strBrwname3 = drpName3.SelectedValue;
        }
        if (drpName4.Items.Count > 0)
        {
            strBrwname4 = drpName4.SelectedValue;
        }
        if (drpName5.Items.Count > 0)
        {
            strBrwname5 = drpName5.SelectedValue;
        }

        drpName1.Items.Clear();
        drpName2.Items.Clear();
        drpName3.Items.Clear();
        drpName4.Items.Clear();
        drpName5.Items.Clear();

        drpName1.DataSource = dt;
        drpName2.DataSource = dt;
        drpName3.DataSource = dt;
        drpName4.DataSource = dt;
        drpName5.DataSource = dt;

        drpName1.DataTextField = "NAME";
        drpName1.DataValueField = "NAME";

        drpName2.DataTextField = "NAME";
        drpName2.DataValueField = "NAME";

        drpName3.DataTextField = "NAME";
        drpName3.DataValueField = "NAME";

        drpName4.DataTextField = "NAME";
        drpName4.DataValueField = "NAME";

        drpName5.DataTextField = "NAME";
        drpName5.DataValueField = "NAME";

        drpName1.DataBind();
        drpName2.DataBind();
        drpName3.DataBind();
        drpName4.DataBind();
        drpName5.DataBind();

        drpName1.Items.Insert(0, "--Select--");
        drpName2.Items.Insert(0, "--Select--");
        drpName3.Items.Insert(0, "--Select--");
        drpName4.Items.Insert(0, "--Select--");
        drpName5.Items.Insert(0, "--Select--");
        if (strBrwname1 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname1 + "'");
            if (dr.Length > 0)
            {
                drpName1.SelectedValue = strBrwname1;
            }
            else
            {
                txtFinanciear1.Text = "";
                txtEMIAmount1.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }

        }
        if (strBrwname2 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname2 + "'");
            if (dr.Length > 0)
            {
                drpName2.SelectedValue = strBrwname2;
            }
            else
            {
                txtFinanciear2.Text = "";
                txtEMIAmount2.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname3 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname3 + "'");
            if (dr.Length > 0)
            {

                drpName3.SelectedValue = strBrwname3;
            }
            else
            {
                txtFinanciear3.Text = "";
                txtEMIAmount3.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname4 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname4 + "'");
            if (dr.Length > 0)
            {
                drpName4.SelectedValue = strBrwname4;
            }
            else
            {
                txtFinanciear4.Text = "";
                txtEMIAmount4.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname5 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname5 + "'");
            if (dr.Length > 0)
            {
                drpName5.SelectedValue = strBrwname5;
            }
            else
            {
                txtFinanciear5.Text = "";
                txtEMIAmount5.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }

    }
    public int FetchINCOME_SOURCEID(string strDesc)
    {
        int INCOME_SOURCEID = 0;
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("Select CT_ID from MR_CATEGORY where  CT_PR_TYPE='A' and CT_DESC='" + strDesc + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        INCOME_SOURCEID = Convert.ToInt32(dsdd.Tables[0].Rows[0][0]);
        con.Close();
        return INCOME_SOURCEID;
    }
    public void Clear()
    {
        DDLkycName.SelectedIndex = 0;
        ddlCustSource.SelectedIndex = 0;
        txtCustAge.Text = "";
        ddlCustRelation.SelectedIndex = 0;
        txtIncome.Text = "";
        txtIncomeTaken.Text = "";
        txtFactor.Text = "";
    }
    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    DropDownList DDLkycName =
                      (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[1].FindControl("DDLkycName");
                    TextBox txtCustName =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[1].FindControl("txtCustName");
                    DropDownList ddlCustSource =
                     (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[2].FindControl("ddlCustSource");
                    TextBox txtCustAge =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[3].FindControl("txtCustAge");
                    DropDownList ddlCustRelation =
                       (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[4].FindControl("ddlCustRelation");
                    TextBox txtIncome =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[5].FindControl("txtIncome");
                    DropDownList ddlIncomeTaken =
                      (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[6].FindControl("ddlIncomeTaken");
                    DropDownList ddlFactor =
                     (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[7].FindControl("ddlFactor");

                    DDLkycName.SelectedItem.Text = dt.Rows[i]["Col1"].ToString();
                    txtCustName.Text = dt.Rows[i]["Col1"].ToString();
                    ddlCustSource.SelectedItem.Text = dt.Rows[i]["Col2"].ToString();
                    txtCustAge.Text = dt.Rows[i]["Col3"].ToString();
                    ddlCustRelation.SelectedItem.Text = dt.Rows[i]["Col4"].ToString();
                    txtIncome.Text = dt.Rows[i]["Col5"].ToString();
                    ddlIncomeTaken.SelectedItem.Text = dt.Rows[i]["Col6"].ToString();
                    ddlFactor.SelectedItem.Text = dt.Rows[i]["Col7"].ToString();
                    rowIndex++;
                }
            }
        }
    }


    protected void gvIncomeDetail_RowCommand1(object sender, GridViewCommandEventArgs e)
    {
        //DataTable dtTempTable=null;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];

            if (e.CommandName == "Delete")
            {
                btnSubmit.Enabled = false;
                string strVal = e.CommandArgument.ToString();
                DataRow[] dr = dtCurrentTable.Select("NAME <> '" + strVal + "'");
                // DDLkycName.Items.Add(strVal);
                if (dr.Length > 0)
                {
                    dtCurrentTable = dr.CopyToDataTable();


                    ViewState["CurrentTable"] = dtCurrentTable;
                    gvIncomeDetail.DataSource = dtCurrentTable;
                    gvIncomeDetail.DataBind();
                    double dblOldIncome = 0.0;
                    if (dtCurrentTable != null && dtCurrentTable.Rows.Count > 0)
                    {
                        double nTotalLoanEligibility = 0.0;

                        for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                        {

                            double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                            int nAge = dtCurrentTable.Rows[n]["AGE"] != DBNull.Value ? Convert.ToInt32(dtCurrentTable.Rows[n]["AGE"]) : 0;
                            nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;
                            double dblIncome = nTempVal;
                            if (nAge < 60)
                            {
                                if (dblIncome > dblOldIncome)
                                {
                                    txtNameofInsuredPerson.Text = dtCurrentTable.Rows[n]["NAME"] != DBNull.Value ? Convert.ToString(dtCurrentTable.Rows[n]["NAME"]) : "";
                                    dblOldIncome = dblIncome;
                                }
                            }

                        }

                        //bala changes 05112016
                        string strOldname = "", strNewname = "";
                        double Amount = 0.0;
                        int nvalue = 0;
                        DataTable dt1 = new DataTable();
                        dt1.Columns.AddRange(new DataColumn[2] { 
                            new DataColumn("Name", typeof(string)),
                            new DataColumn("Amount", typeof(int)) });
                        //DataTable dtTempData = dtCurrentTable.Select("AGE < 60").CopyToDataTable();
                        DataRow[] drTemp = dtCurrentTable.Select("AGE < 60");
                        if (drTemp.Length > 0)
                        {
                            DataTable dtTempData = drTemp.CopyToDataTable();
                            if (dtTempData != null && dtTempData.Rows.Count > 0)
                            {
                                for (int ncount = 0; ncount < dtTempData.Rows.Count; ncount++)
                                {
                                    strNewname = dtTempData.Rows[ncount]["NAME"] != DBNull.Value ? dtTempData.Rows[ncount]["NAME"].ToString() : "";
                                    Amount = dtTempData.Rows[ncount]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtTempData.Rows[ncount]["FACTORED_INCOME"]) : 0.0;
                                    if (strOldname == "")
                                    {
                                        dt1.Rows.Add(strNewname, Amount);

                                    }
                                    else if (strOldname == strNewname)
                                    {

                                        dt1.Rows[nvalue]["Amount"] = Convert.ToDouble(dt1.Rows[nvalue]["Amount"]) + Amount;
                                    }
                                    else
                                    {
                                        dt1.Rows.Add(strNewname, Amount);
                                        nvalue = nvalue + 1;
                                    }
                                    strOldname = strNewname;
                                }
                            }
                            if (dt1 != null && dt1.Rows.Count > 0)
                            {
                                double dblTempAmount = 0.0;
                                for (int n = 0; n < dt1.Rows.Count; n++)
                                {

                                    double dblAmont = dt1.Rows[n]["Amount"] != DBNull.Value ? Convert.ToDouble(dt1.Rows[n]["Amount"]) : 0.0;
                                    if (dblAmont > dblTempAmount)
                                    {
                                        txtNameofInsuredPerson.Text = dt1.Rows[n]["Name"] != DBNull.Value ? dt1.Rows[n]["Name"].ToString() : "";
                                        dblTempAmount = dblAmont;
                                    }

                                }
                            }
                        }
                        //bala changes end 05112016
                        txtTotalLoanEligibility.Text = nTotalLoanEligibility.ToString();
                        BindBorrower(dtCurrentTable);

                    }

                }
                else
                {
                    FirstGridViewRow();
                    txtTotalLoanEligibility.Text = "";
                    drpName1.Items.Clear();
                    drpName2.Items.Clear();
                    drpName3.Items.Clear();
                    drpName4.Items.Clear();
                    drpName5.Items.Clear();
                    txtFinanciear1.Text = "";
                    txtFinanciear2.Text = "";
                    txtFinanciear3.Text = "";
                    txtFinanciear4.Text = "";
                    txtFinanciear5.Text = "";

                    txtEMIAmount1.Text = "";
                    txtEMIAmount2.Text = "";
                    txtEMIAmount3.Text = "";
                    txtEMIAmount4.Text = "";
                    txtEMIAmount5.Text = "";
                    txtTotalEMIAmount.Text = "";

                }


            }
        }
    }

    protected void gvIncomeDetail_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void gvIncomeDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void ddlLeadNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlLeadNo.SelectedIndex > 0)
        {
            BindTenor();
            if (ddlLeadNo.SelectedItem.Text.Contains("ELP"))
            {
                trEmp1.Visible = true;
                trEmp2.Visible = true;
                trEmp3.Visible = true;
            }
            else
            {
                trEmp1.Visible = false;
                trEmp2.Visible = false;
                trEmp3.Visible = false;
            }

            txtCAMDATE.Text = DateTime.Now.ToString("dd/MMM/yyyy");
            DataSet dsLead = fetchLeadDetails(ddlLeadNo.SelectedItem.Text.Trim());
            if (dsLead != null && dsLead.Tables[0].Rows.Count > 0)
            {

                txtRelWithEquitas.Text = dsLead.Tables[0].Rows[0]["LD_ISM"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_ISM"].ToString() : "";

                if (txtRelWithEquitas.Text == "1")
                {
                    txtRelWithEquitas.Text = "Member";
                }
                else if (txtRelWithEquitas.Text == "2")
                {
                    txtRelWithEquitas.Text = "Non Member";
                }
                else
                {
                    txtRelWithEquitas.Text = "";
                }
                BindProperty();
                KYC_details();
                FetchCam();
                txtPDDate.Text = dsLead.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsLead.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
                txtApplnName.Text = dsLead.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                txtContactNo.Text = dsLead.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
                txtMemberID.Text = dsLead.Tables[0].Rows[0]["LD_MID"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_MID"].ToString() : "";
                txtAddress.Text = dsLead.Tables[0].Rows[0]["LD_RADDRESS"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_RADDRESS"].ToString() : "";
                txt_enduse.Text = dsLead.Tables[0].Rows[0]["LD_PD_USE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_PD_USE"].ToString() : "";
                txtLoanAmountRequested.Text = dsLead.Tables[0].Rows[0]["LD_PD_AMT"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_PD_AMT"].ToString() : "";
                Session["PROPADDR"] = dsLead.Tables[0].Rows[0]["LD_ADDRESS"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_ADDRESS"].ToString() : "";

                txtBranchName.Text = dsLead.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
               
                string empName = dsLead.Tables[0].Rows[0]["EMP_CODE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["EMP_CODE"].ToString() : "";
                if (empName != "")
                    empName += "-";
                empName += dsLead.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
                string empDesignation = dsLead.Tables[0].Rows[0]["ET_DESC"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["ET_DESC"].ToString() : "";
                if (empName != "" && empDesignation != "")
                    txtEmpDetailes.Text = empName + " " + "(" + empDesignation + ")";
                //ddlRelationShip.Focus();

            }
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Age", con);
        cmddd.Parameters.AddWithValue("@KYC_Name", DDLkycName.SelectedIndex != 0 ? DDLkycName.SelectedItem.Text : "");
        cmddd.Parameters.AddWithValue("@KYC_LD_ID", ddlLeadNo.SelectedIndex != 0 ? ddlLeadNo.SelectedValue : "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();

        if (dsdd.Tables[0].Rows.Count > 0)
        {
            txtCustAge.Text = dsdd.Tables[0].Rows[0][0].ToString();
            TBAppType.Text = dsdd.Tables[0].Rows[0][1] != null ? dsdd.Tables[0].Rows[0][1].ToString() : "0";
        }
        if (DDLkycName.SelectedIndex == 0)
        {
            txtCustAge.Text = "";
        }
        if (dtSourceOfIncome != null && dtSourceOfIncome.Rows.Count > 0)
        {
            if (TBAppType.Text == "Applicant")
            {
                DataRow[] tempDs = null;
                DataTable tempDT = null;
                //if(ddlCustProfile.SelectedItem.Text.Contains("Agri"))
                //{
                //    tempDs = dtSourceOfIncome.Select("CT_DESC LIke '%Non regular Income%' ");
                //}
                //else
                //{
                //tempDs = dtSourceOfIncome.Select("CT_DESC LIke '%Agri%' ");
                // }

                //tempDT = tempDs.CopyToDataTable();
                tempDT = dtSourceOfIncome;
                if (tempDT != null && tempDT.Rows.Count > 0)
                {
                    ddlCustSource.DataSource = tempDT;

                }

            }
            else
            {
                txtIncome.Text = "";
                txtIncome.Enabled = true;
                txtFactor.Text = "";
                DataRow[] tempDs = dtSourceOfIncome.Select("CT_DESC not LIke '%Agri%' ");
                DataTable tempDT = tempDs.CopyToDataTable();
                if (tempDT != null && tempDT.Rows.Count > 0)
                {
                    ddlCustSource.DataSource = tempDT;

                }
                //ddlCustSource.DataSource = dtSourceOfIncome;
            }
            ddlCustSource.DataTextField = "CT_DESC";
            ddlCustSource.DataValueField = "CT_DESC";
            ddlCustSource.DataBind();
            ddlCustSource.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }
    public void clear()
    {
        // ddlLeadNo.SelectedIndex = 0;
        txtCAMDATE.Text = "";
        FirstGridViewRow();
    }
    protected void ddlMainApplicant_SelectedIndexChanged(object sender, EventArgs e)
    {
        //BindDepndsMainAppln();
    }
    protected void ddlPropType_SelectedIndexChanged(object sender, EventArgs e)
    {
        RadioBtnGV_No.Checked = false;
        RadioBtnGV_Yes.Checked = false;
        VisibleFalse();
        enable();
        btnSubmit.Enabled = false;
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY", con);
        cmddd.Parameters.AddWithValue("@PT_ID", "");
        cmddd.Parameters.AddWithValue("@PT_TYPE", "A");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();

        if (ddlPropType.SelectedItem.Text != "--Select--")
        {

            DataRow[] dr = dsdd.Tables[0].Select("PT_DESC='" + ddlPropType.SelectedItem.Text + "'");
            lblSqrft.Text = " @ " + dr[0].ItemArray[2].ToString() + " / Sqft ";
            ddlPropType.Focus();
        }

    }
    protected void ddlCustSource_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {


            txtIncome.Text = "";
            txtFactor.Text = "";
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
            cmddd.Parameters.AddWithValue("@CT_ID", "");
            cmddd.Parameters.AddWithValue("@CT_TYPE", "A");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            dtSourceOfIncome = dsdd.Tables[0];
            con.Close();

            if (ddlCustSource.SelectedItem.Text != "--Select--")
            {
                if (ddlCustSource.SelectedItem.Text.Contains("Agri"))
                {
                    //if (ddlCustProfile.SelectedItem.Text == "Farmer")
                    //{
                    //    txtIncome.Text = ddlCustProfile.SelectedValue;
                    //}
                    //else if (ddlCustProfile.SelectedItem.Text == "Tenant Farmer")
                    //{
                    //    txtIncome.Text = "500.00";
                    //}
                    string[] strCPVal = ddlCustProfile.SelectedValue.Split('|');
                    txtIncome.Text = strCPVal[1].ToString();
                    txtIncome.Enabled = false;
                    if (txtAgriLnadholding.Text != "")
                    {
                        if (ddlCustProfile.SelectedItem.Text == "Agri Laborer")
                        {
                            txtFactor.Text = Convert.ToString(Convert.ToDouble(txtIncome.Text));
                        }
                        else
                            if (rbtnAgriHoldingSts.SelectedValue == "Y")
                            {

                                txtFactor.Text = Convert.ToString(Convert.ToDouble(txtAgriLnadholding.Text) * Convert.ToDouble(txtIncome.Text));
                            }
                            else
                                if (rbtnAgriHoldingSts.SelectedValue == "N")
                                {

                                    txtFactor.Text = Convert.ToString(Convert.ToDouble(txtLeaseLandholding.Text) * Convert.ToDouble(txtIncome.Text));
                                }
                                else
                                    if (rbtnAgriHoldingSts.SelectedValue == "B")
                                    {

                                        //txtFactor.Text = (Convert.ToString(Convert.ToDouble(txtAgriLnadholding.Text) * Convert.ToDouble(txtIncome.Text) + Convert.ToDouble(txtLeaseLandholding.Text) * Convert.ToDouble(txtIncome.Text)));
                                        txtFactor.Text = (Convert.ToString(Convert.ToDouble(txtAgriLnadholding.Text) * Convert.ToDouble(3500) + Convert.ToDouble(txtLeaseLandholding.Text) * Convert.ToDouble(2500)));
                                        txtIncome.Text = (Convert.ToDouble(3500) + Convert.ToDouble(2500)).ToString();
                                    }

                    }
                }
                else
                {
                    txtIncome.Enabled = true;
                }
                DataRow[] dr = dtSourceOfIncome.Select("CT_DESC='" + ddlCustSource.SelectedItem.Text + "'");

                txtIncomeTaken.Text = dr[0].ItemArray[3].ToString();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    //PMT Calculation
    public static double GetEMI(double presentValue, double financingPeriod, double interestRatePerYear)
    {
        //interestRatePerYear = 26.00;
        //financingPeriod = 60;
        //presentValue = 100000;
        double a, b, x;
        double monthlyPayment;
        a = (1 + interestRatePerYear / 1200);
        b = financingPeriod;
        x = Math.Pow(a, b);
        x = 1 / x;
        x = 1 - x;
        monthlyPayment = (presentValue) * (interestRatePerYear / 1200) / x;
        return (monthlyPayment);
    }
    public void CalculateLoadELigibility()
    {
        try
        {
            string strval = this.txtTotalEMIAmount.Text;
            double presentValue = 100000;
            double financingPeriod = 0.0;
            double interestRatePerYear = 0.0;
            double IIREligibilit = 0.0;
            double FOIREligibility = 0.0;
            double AgriIncome = 0.0;
            if (txtAgriIncome.Text != "")
            {
                AgriIncome = Convert.ToDouble(txtAgriIncome.Text);
            }
            if (ddlTenure.SelectedItem.Text != "")
            {
                financingPeriod = Convert.ToDouble(ddlTenure.SelectedItem.Text) * 12;
            }
            if (ddlIntrest.SelectedItem.Text != "--Select--")
            {
                interestRatePerYear = Convert.ToDouble(ddlIntrest.SelectedItem.Text);
            }
            txtEMIperLakh.Text = Math.Round(GetEMI(presentValue, financingPeriod, interestRatePerYear)).ToString();
            IIREligibilit = (((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 40 / 100) / (Convert.ToDouble(txtEMIperLakh.Text != "" ? txtEMIperLakh.Text : "0.0"))) * 100000;
            FOIREligibility = ((((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 50 / 100) - Convert.ToDouble(txtTotalEMIAmount.Text != "" ? txtTotalEMIAmount.Text : "0.0")) / Convert.ToDouble(txtEMIperLakh.Text != "" ? txtEMIperLakh.Text : "0.0")) * 100000;
            //FOIREligibility =((Convert.ToDouble(txtTotalLoanEligibility.Text) * 50 / 100)- (Convert.ToDouble(txtTotalEMIAmount.Text))/ (GetEMI(presentValue, financingPeriod, interestRatePerYear))) * 100000;

            //IIREligibilit = IIREligibilit + AgriIncome;
            //FOIREligibility = FOIREligibility + AgriIncome;

            txtIIREligibility.Text = Convert.ToInt32(IIREligibilit).ToString();
            txtFOIREligibility.Text = Convert.ToInt32(FOIREligibility).ToString();

            if (IIREligibilit <= FOIREligibility)
            {
                txtLoanEligibility.Text = Convert.ToInt32(IIREligibilit).ToString();

            }
            else if (IIREligibilit > FOIREligibility)
            {
                txtLoanEligibility.Text = Convert.ToInt32(FOIREligibility).ToString();
            }

            //txtExtendElibility.Text = Convert.ToString(Convert.ToDouble(txtAgriLnadholding.Text) * 50000);


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtIntestRate_TextChanged(object sender, EventArgs e)
    {


    }
    protected void ddlAgeOfBuilding_SelectedIndexChanged(object sender, EventArgs e)
    {
        visible();
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_BD_AGE", con);
        cmddd.Parameters.AddWithValue("@BA_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();
        DataTable dtAge = dsdd.Tables[0];
        btnSubmit.Enabled = false;
        if (ddlAgeOfBuilding.SelectedItem.Text != "--Select--")
        {
            DataRow[] dr = dtAge.Select("BA_DESC='" + ddlAgeOfBuilding.SelectedItem.Text + "'");

            txtDepreciation.Text = dr[0].ItemArray[2].ToString();

        }
        else
        {
            ddlAgeOfBuilding.Focus();
        }
    }
    protected void txtMarketValueSqrt_TextChanged(object sender, EventArgs e)
    {
        visible();
        try
        {
            btnSubmit.Enabled = false;
            double dGuidline = 0.0;
            double dMarketValue = 0.0;
            double dLandArea = 0.0;
            if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "" && txtLandArea.Text != "")
            {
                if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                {
                    dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                }
                else
                {
                    dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                }
                dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);
                dLandArea = Convert.ToDouble(txtLandArea.Text);
                if (dGuidline < dMarketValue && dGuidline > 0)
                {
                    txtConsidered.Text = Convert.ToInt32(dGuidline * dLandArea).ToString();
                }
                else if (dGuidline > dMarketValue && dMarketValue > 0)
                {
                    txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                }
                else if (dGuidline == dMarketValue && dGuidline > 0)
                {
                    txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                }
                else
                {
                    if (dGuidline > 0)
                    {
                        txtConsidered.Text = Convert.ToInt32(dGuidline * dLandArea).ToString();
                    }
                    else
                    {
                        txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                    }
                }
            }
            txtBuildUpArea.Focus();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtBuildUpArea_TextChanged(object sender, EventArgs e)
    {
        visible();
        btnSubmit.Enabled = false;
        double nSqrftVal = 0;
        if (txtBuildUpArea.Text != "" && lblSqrft.Text != "")
        {
            nSqrftVal = Convert.ToDouble(txtBuildUpArea.Text) * Convert.ToDouble(lblSqrft.Text.Substring(2, lblSqrft.Text.IndexOf('/') - 2).Trim());
            txtBuildingValue.Text = Convert.ToInt32(nSqrftVal).ToString();
        }
        ddlAgeOfBuilding.Focus();
    }
    public int RoundNum(int num)
    {
        int rem = num % 10;
        return rem >= 5 ? (num - rem + 10) : (num - rem);
    }
    public int RoundDown(int toRound)
    {
        int nValue = 0;

        if (toRound.ToString().Length < 4)
        {
            nValue = toRound - toRound % 10;
        }
        else if (toRound.ToString().Length < 6)
        {
            nValue = toRound - toRound % 100;
        }
        else
        {
            nValue = toRound - toRound % 1000;
        }
        return nValue;
    }

    protected void txtAgriIncome_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        if (ddlIntrest.SelectedItem.Text != "--Select--")
        {
            CalculateLoadELigibility();
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        // InsertCamLapValues();
        InsertDraftCamLapValues("S");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("CAM_ASL_Sampling.aspx");
    }
    protected void InsertCamLapValues()
    {
        try
        {
            //if (ddlRelationShip.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Relation ship", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            //else if (ddlMainApplicant.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Main Source of Income", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            if (ddlVintage.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Vintage", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //else if (ddlNature.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Nature Of Bussiness/Job", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            //else if (ddlIncomType.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Income Type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            //else if (ddlLoanPurpose.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Loan Purpose", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            //else if (ddlCreditHistory.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Cedit History", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else
            {
                DataTable dtIncomeDetails = new DataTable();
                dtIncomeDetails = (DataTable)ViewState["CurrentTable"];
                dtIncomeDetails.Columns.Remove("INCOME_SOURCE");
                dtIncomeDetails.Columns.Remove("RELATIONSHIP");
                dtIncomeDetails.Columns.Remove("APP_TYPE");
                DataTable dtObligation = new DataTable();
                dtObligation = BindObligationTable();

                DataTable dtColletral = new DataTable();
                dtColletral = BindCollateralTable();

                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertCAM", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@CAM_TYPE", "S");
                //cmdinsert.Parameters.AddWithValue("@CAM_PR_ID", "1");

                //cmdinsert.Parameters.AddWithValue("@CAM_BR_ID", txtBranchName.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LD_ID", ddlLeadNo.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_AP_ADD", txtAddress.Text);
                //cmdinsert.Parameters.AddWithValue("@CAM_ER_ID", ddlRelationShip.SelectedValue.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_INS_ID", ddlMainApplicant.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_VN_ID", ddlVintage.SelectedValue.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_NT_ID", ddlNature.SelectedValue.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_IT_ID", ddlIncomType.SelectedValue.ToString());
                // cmdinsert.Parameters.AddWithValue("@CAM_PP_ID", ddlLoanPurpose.SelectedValue.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_CH_ID", ddlCreditHistory.SelectedValue.ToString());

                cmdinsert.Parameters.AddWithValue("@CAM_AGL", txtAgriLandAcres.Text != "" ? Convert.ToDouble(txtAgriLandAcres.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_AGI", txtAgriIncome.Text != "" ? Convert.ToDouble(txtAgriIncome.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_IN", txtTotalLoanEligibility.Text != "" ? Convert.ToDouble(txtTotalLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_EMI", txtTotalEMIAmount.Text != "" ? Convert.ToDouble(txtTotalEMIAmount.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TENURE", ddlTenure.SelectedValue);
                cmdinsert.Parameters.AddWithValue("@CAM_INR", ddlIntrest.SelectedItem.Text != "--Select--" ? Convert.ToDouble(ddlIntrest.SelectedItem.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_EPL", txtEMIperLakh.Text != "" ? Convert.ToDouble(txtEMIperLakh.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_IRR", txtIIREligibility.Text != "" ? Convert.ToDouble(txtIIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_FOIR", txtFOIREligibility.Text != "" ? Convert.ToDouble(txtFOIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LAMT_REQ", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_ELG", txtLoanEligibility.Text != "" ? Convert.ToDouble(txtLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_PT_ID", ddlPropType.SelectedItem.Text.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_OC_ID", ddlOccupancyStatus.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_UG_ID", ddlUsage.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_NOT", txtNoOFtenents.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LAREA", txtLandArea.Text != "" ? Convert.ToDouble(txtLandArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_GLV", txtGuideline.Text != "" ? Convert.ToDouble(txtGuideline.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_MV", txtMarketValueSqrt.Text != "" ? Convert.ToDouble(txtMarketValueSqrt.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CLV", txtConsidered.Text != "" ? Convert.ToDouble(txtConsidered.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BAREA", txtBuildUpArea.Text != "" ? Convert.ToDouble(txtBuildUpArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BV", txtBuildingValue.Text != "" ? Convert.ToDouble(txtBuildingValue.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BA_ID", ddlAgeOfBuilding.SelectedItem.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_DEP", txtDepreciation.Text != "" ? Convert.ToDouble(txtDepreciation.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CBV", txtonsideredBuilding.Text != "" ? Convert.ToDouble(txtonsideredBuilding.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_TPV", txtTotalPropertyValue.Text != "" ? Convert.ToDouble(txtTotalPropertyValue.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_LTV", txtLTVonProperty.Text != "" ? Convert.ToDouble(txtLTVonProperty.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_RLA", txtRecommendedLoan.Text != "" ? Convert.ToDouble(txtRecommendedLoan.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_Deviation", txtDeviation.Text);

                cmdinsert.Parameters.AddWithValue("@CAM_PCS", txtNameofInsuredPerson.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_CBY", Session["ID"].ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_MBY", Session["ID"].ToString());


                cmdinsert.Parameters.AddWithValue("@tblIncome_Details", dtIncomeDetails);
                cmdinsert.Parameters.AddWithValue("@tblOBLIGATE", dtObligation);
                cmdinsert.Parameters.AddWithValue("@tblCOLLATERAL", dtColletral);
                string strReg = "";
                if (RadioBtnGV_No.Checked)
                {
                    strReg = "N";
                }
                else if (RadioBtnGV_Yes.Checked)
                {
                    strReg = "Y";
                }

                cmdinsert.Parameters.AddWithValue("@CAM_Regnet", strReg);


                int n = cmdinsert.ExecuteNonQuery();
                if (n > 0)
                {

                    if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "")
                    {
                        double dGuidline = 0.0;
                        if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                        {
                            dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                        }
                        else
                        {
                            dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                        }
                        //if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text) && RadioBtnGV_No.Checked)
                        //{
                        //    sendMail();
                        //}
                        if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text))
                        {
                            sendMail();
                        }
                    }
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Saved Successfully');window.location.reload()", true);
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Failed to Save');", true);
                }

                con.Close();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public DataTable BindEndUse()
    {
        DataTable dtEndUse = new DataTable();
        DataRow drEndUse = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));

        dtEndUse.Columns.Add(new DataColumn("FCC_FA_ID", typeof(string)));
        dtEndUse.Columns.Add(new DataColumn("FCC_FAS_ID", typeof(string)));
        dtEndUse.Columns.Add(new DataColumn("FCC_AMOUNT", typeof(string)));
        double amtEnduse = 0.0;
        for (int n = 0; n < ddlFarmerActivity.Items.Count; n++)
        {
            if (ddlFarmerActivity.Items[n].Selected)
            {


                for (int m = 0; m < ddlLoanPurpose.Items.Count; m++)
                {
                    if (ddlLoanPurpose.Items[m].Selected)
                    {
                        string[] FASValu = ddlLoanPurpose.Items[m].Value.Split('|');
                        if (FASValu.Length > 1)
                        {
                            if (FASValu[2].ToString() == ddlFarmerActivity.Items[n].Value)
                            {
                                drEndUse = dtEndUse.NewRow();
                                drEndUse["FCC_FA_ID"] = ddlFarmerActivity.Items[n].Value;
                                drEndUse["FCC_FAS_ID"] = FASValu[0].ToString();
                                //drEndUse["FCC_AMOUNT"] = FASValu[1].ToString();
                                if (ddlLoanPurpose.Items[m].Text == "Farming/Crop Cultivation")
                                {
                                    amtEnduse = Convert.ToDouble(FASValu[1]) * Convert.ToDouble(txtAgriLnadholding.Text);
                                }
                                else if (ddlLoanPurpose.Items[m].Text == "Purchase of Cow")
                                {
                                    amtEnduse = Convert.ToDouble(FASValu[1]) * Convert.ToDouble(txtCowCount.Text);
                                }
                                #region Counts
                                else if (ddlLoanPurpose.Items[m].Text == "Feeding the Cattle")
                                {
                                    amtEnduse = Convert.ToDouble(FASValu[1]) * Convert.ToDouble(txtCowCount1.Text);
                                }
                                else if (ddlLoanPurpose.Items[m].Text == "Building the Cattle Shed")
                                {
                                    amtEnduse = Convert.ToDouble(FASValu[1]) * Convert.ToDouble(txtCowCOuntBuild.Text);
                                }
                                else if (ddlLoanPurpose.Items[m].Text == "Purchase of Buffalo")
                                {
                                    amtEnduse = Convert.ToDouble(FASValu[1]) * Convert.ToDouble(txtBuffaloCount.Text);
                                }
                                #endregion
                                else
                                {
                                    amtEnduse = Convert.ToDouble(FASValu[1]);
                                }
                                drEndUse["FCC_AMOUNT"] = Convert.ToString(amtEnduse);
                                dtEndUse.Rows.Add(drEndUse);
                            }
                        }



                    }


                }
            }

        }

        return dtEndUse;
    }
    public DataTable BindObligationTable()
    {
        DataTable dtObligation = new DataTable();
        DataRow drObligation = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string))); - IR/RL/SEP19/09/556_New Fields Required in RTS CAM Obligation details
        dtObligation.Columns.Add(new DataColumn("CO_TYPE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_FIN", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_TENURE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_LOAN_AMT", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_SOURCE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_BORW", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_AMOUNT", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_BAL_EMI", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_CIBIL", typeof(string)));

        if (txtFinanciear1.Text != "" && drpName1.SelectedItem != null && txtEMIAmount1.Text != "")
        {
            if (drpName1.SelectedItem.Text != "--Select--")
            {

                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear1.Text;
                drObligation["CO_TENURE"] = "";
                drObligation["CO_LOAN_AMT"] = "";
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName1.SelectedItem.Text;

                drObligation["CO_AMOUNT"] = txtEMIAmount1.Text;
                drObligation["CO_BAL_EMI"] = "0";
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }
        }
        if (txtFinanciear2.Text != "" && drpName2.SelectedItem != null && txtEMIAmount2.Text != "")
        {

            if (drpName2.SelectedItem.Text != "--Select--")
            {
                //drObligation = dtObligation.NewRow();
                //drObligation["CO_TYPE"] = "";
                //drObligation["CO_FIN"] = txtFinanciear2.Text;
                //drObligation["CO_BORW"] = drpName2.SelectedItem.Text;
                //drObligation["CO_AMOUNT"] = txtEMIAmount2.Text;

                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear2.Text;
                drObligation["CO_TENURE"] = "";
                drObligation["CO_LOAN_AMT"] = "";
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName2.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount2.Text;
                drObligation["CO_BAL_EMI"] = "0";
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }

        }
        if (txtFinanciear3.Text != "" && drpName3.SelectedItem != null && txtEMIAmount3.Text != "")
        {
            if (drpName3.SelectedItem.Text != "--Select--")
            {
                //drObligation = dtObligation.NewRow();
                //drObligation["CO_TYPE"] = "";
                //drObligation["CO_FIN"] = txtFinanciear3.Text;
                //drObligation["CO_BORW"] = drpName3.SelectedItem.Text;
                //drObligation["CO_AMOUNT"] = txtEMIAmount3.Text;
                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear3.Text;
                drObligation["CO_TENURE"] = "";
                drObligation["CO_LOAN_AMT"] = "";
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName3.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount3.Text;
                drObligation["CO_BAL_EMI"] = "0";
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }

        }
        if (txtFinanciear4.Text != "" && drpName4.SelectedItem != null && txtEMIAmount4.Text != "")
        {
            if (drpName4.SelectedItem.Text != "--Select--")
            {

                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear4.Text;
                drObligation["CO_TENURE"] = "";
                drObligation["CO_LOAN_AMT"] = "";
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName4.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount4.Text;
                drObligation["CO_BAL_EMI"] = "0";
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }
        }
        if (txtFinanciear5.Text != "" && drpName5.SelectedItem != null && txtEMIAmount5.Text != "")
        {
            if (drpName5.SelectedItem.Text != "--Select--")
            {


                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear5.Text;
                drObligation["CO_TENURE"] = "";
                drObligation["CO_LOAN_AMT"] = "";
                drObligation["CO_SOURCE"] = "";
                drObligation["CO_BORW"] = drpName5.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount5.Text;
                drObligation["CO_BAL_EMI"] = "0";
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }
        }
        return dtObligation;
    }

    public DataTable BindCollateralTable()
    {
        DataTable dtCollateral = new DataTable();
        DataRow drCollateral = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));     
        dtCollateral.Columns.Add(new DataColumn("CC_COLAT", typeof(string)));
        dtCollateral.Columns.Add(new DataColumn("CC_AMOUNT", typeof(string)));
        return dtCollateral;
    }

    protected void btnCalculate_Click(object sender, EventArgs e)
    {
        visible();
        try
        {


            txtEndUseAmnt.Text = "0";
            //txtEndUseValue.Text = "";

            for (int nEUCount = 0; nEUCount < ddlLoanPurpose.Items.Count; nEUCount++)
            {

                if (ddlLoanPurpose.Items[nEUCount].Selected)
                {
                    string[] strEUInputValue = ddlLoanPurpose.Items[nEUCount].Value.Split('|');

                    if (ddlLoanPurpose.Items[nEUCount].Text == "Farming/Crop Cultivation"

                            )
                    {
                        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + (Convert.ToDouble(txtAgriLnadholding.Text) * Convert.ToDouble(strEUInputValue[1])));
                    }
                    else if (ddlLoanPurpose.Items[nEUCount].Text == "Purchase of Cow")
                    {
                        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + (Convert.ToDouble(txtCowCount.Text) * Convert.ToDouble(strEUInputValue[1])));
                    }
                    #region Counts
                    else if (ddlLoanPurpose.Items[nEUCount].Text == "Feeding the Cattle")
                    {
                        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + (Convert.ToDouble(txtCowCount1.Text) * Convert.ToDouble(strEUInputValue[1])));
                    }
                    else if (ddlLoanPurpose.Items[nEUCount].Text == "Building the Cattle Shed")
                    {
                        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + (Convert.ToDouble(txtCowCOuntBuild.Text) * Convert.ToDouble(strEUInputValue[1])));
                    }
                    else if (ddlLoanPurpose.Items[nEUCount].Text == "Purchase of Buffalo")
                    {
                        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + (Convert.ToDouble(txtBuffaloCount.Text) * Convert.ToDouble(strEUInputValue[1])));
                    }
                    #endregion
                    else
                    {
                        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + Convert.ToDouble(strEUInputValue[1]));
                    }
                    //if (txtEndUseValue.Text!= "")
                    //{
                    //    txtEndUseValue.Text = txtEndUseValue.Text + "|" + ddlLoanPurpose.Items[nEUCount].Value;
                    //}
                    //else
                    //{
                    //    txtEndUseValue.Text = ddlLoanPurpose.Items[nEUCount].Value;
                    //}
                    //switch (nEUCount.ToString())
                    //{
                    //    case "0":
                    //        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + (Convert.ToDouble(txtAgriLnadholding.Text) * 50000));

                    //        break;
                    //    case "1":
                    //        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + 500000);
                    //        break;
                    //    case "2":
                    //        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + 200000);
                    //        break;
                    //    case "3":
                    //        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + 200000);
                    //        break;
                    //    case "4":
                    //        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + 100000);
                    //        break;
                    //    case "5":
                    //        txtEndUseAmnt.Text = Convert.ToString(Convert.ToDouble(txtEndUseAmnt.Text) + 5000);
                    //        break;
                    //}
                }

            }
            //if(txtEndUseAmnt.Text == "0")
            //{
            //    ddlLoanPurpose.Focus();
            //    uscMsgBox1.AddMessage("End Use is Mandatory", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            if (txtTotalLoanEligibility.Text == "")
            {
                DDLkycName.Focus();
                uscMsgBox1.AddMessage("Please Add Income Details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
            else if (ddlIntrest.SelectedItem.Text == "--Select--")
            {

                uscMsgBox1.AddMessage("Please Give Intrest Rate value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                ddlIntrest.Focus();
            }
            else if (txtLoanAmountRequested.Text == "")
            {
                uscMsgBox1.AddMessage("Please Give Loan Amount Requested value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtLoanAmountRequested.Focus();
            }
            else if (txtBuildingValue.Text == "")
            {
                uscMsgBox1.AddMessage("Please Give Building value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtBuildUpArea.Focus();
            }
            else if (txtDepreciation.Text == "")
            {
                uscMsgBox1.AddMessage("Please Select Age of Building", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                ddlAgeOfBuilding.Focus();
            }

            else
            {
                if (txtDepreciation.Text != "" && txtBuildingValue.Text != "" && txtLoanAmountRequested.Text != "")
                {
                    CalculateLoadELigibility();
                    double dGuidline = 0.0;
                    double dMarketValue = 0.0;
                    double dLandArea = 0.0;
                    if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "" && txtLandArea.Text != "")
                    {
                        if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                        {
                            dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                        }
                        else
                        {
                            dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                        }
                        dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);
                        dLandArea = Convert.ToDouble(txtLandArea.Text);
                        if (dGuidline < dMarketValue && dGuidline > 0)
                        {
                            txtConsidered.Text = Convert.ToInt32(dGuidline * dLandArea).ToString();
                        }
                        else if (dGuidline > dMarketValue && dMarketValue > 0)
                        {
                            txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                        }
                        else if (dGuidline == dMarketValue && dGuidline > 0)
                        {
                            txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                        }
                        else
                        {
                            if (dGuidline > 0)
                            {
                                txtConsidered.Text = Convert.ToInt32(dGuidline * dLandArea).ToString();
                            }
                            else
                            {
                                txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                            }
                        }
                    }

                    double nVal = 100 - Convert.ToDouble(txtDepreciation.Text);
                    txtonsideredBuilding.Text = Convert.ToString(Convert.ToDouble(txtBuildingValue.Text) * (nVal / 100));
                    if (txtConsidered.Text != "")
                    {
                        if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                        {
                            txtTotalPropertyValue.Text = Convert.ToDouble(txtConsidered.Text).ToString();
                        }
                        else
                        {
                            txtTotalPropertyValue.Text = Convert.ToString(Convert.ToDouble(txtonsideredBuilding.Text) + Convert.ToDouble(txtConsidered.Text));
                        }

                        txtLTVonProperty.Text = Convert.ToString(Convert.ToDouble(txtTotalPropertyValue.Text) * 50 / 100);
                        double nMinVal = 0;
                        if (txtLoanAmountRequested.Text != "" && txtLoanEligibility.Text != "")
                        {
                            nMinVal = Math.Min(Convert.ToDouble(txtLoanAmountRequested.Text), Convert.ToDouble(txtLoanEligibility.Text));
                            nMinVal = Math.Min(Convert.ToDouble(nMinVal), Convert.ToDouble(txtLTVonProperty.Text));
                            //nMinVal = Math.Min(Convert.ToDouble(nMinVal), Convert.ToDouble(txtExtendElibility.Text));
                            if (ddlPropType.SelectedItem.Text == "Vacant plot")
                            {
                                nMinVal = Math.Min(Convert.ToDouble(nMinVal), Convert.ToDouble(250000));
                            }
                            if (txtEndUseAmnt.Text != "0")
                            {
                                nMinVal = Math.Min(Convert.ToDouble(nMinVal), Convert.ToDouble(txtEndUseAmnt.Text));
                            }
                            int nAmount = Convert.ToInt32(Math.Round(nMinVal));
                            txtRecommendedLoan.Text = Convert.ToString(RoundDown(nAmount));
                            if (txtRecommendedLoan.Text != "")
                            {
                                btnSubmit.Enabled = true;
                            }
                        }

                    }
                    txtNameofInsuredPerson.Focus();
                }
                //  btnSubmit.Enabled = false;
            }
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
            cmddd.Parameters.AddWithValue("@CT_ID", "");
            cmddd.Parameters.AddWithValue("@CT_TYPE", "A");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            dtSourceOfIncome = dsdd.Tables[0];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtLoanAmountRequested_TextChanged(object sender, EventArgs e)
    {
        visible();
        btnSubmit.Enabled = false;
    }
    public void KYC_details()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_KYC", con);
        cmddd.Parameters.AddWithValue("@LD_ID", ddlLeadNo.SelectedValue.ToString().Trim());
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        DDLkycName.DataSource = dsdd;
        DDLkycName.DataTextField = "KYC_NAME";
        DDLkycName.DataValueField = "KYC_ID";
        DDLkycName.DataBind();
        DDLkycName.Items.Insert(0, new ListItem("--Select--", "0"));
        TBAppType.Text = "";
    }
    protected void ddlIntrest_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        if (ddlIntrest.SelectedItem.Text != "--Select--")
        {
            CalculateLoadELigibility();
            txtLoanAmountRequested.Focus();
        }
        else
        {
            uscMsgBox1.AddMessage("Please Give Intrest Rate value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            ddlIntrest.Focus();
        }
    }

    public void sendMail()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {

            area = Session["AREANAME"].ToString();
            brnch = txtBranchName.Text;
            ldno = ddlLeadNo.SelectedItem.Text;

            apname = txtApplnName.Text;
            apmobile = txtContactNo.Text;
            gv = Convert.ToDouble(txtGuideline.Text).ToString("F");
            landarea = Convert.ToDouble(txtLandArea.Text.Trim()).ToString("F");




            con.Open();
            /////// mail ///////////
            //  strMailDetail = "";

            SqlCommand cmddet = new SqlCommand("select * from MR_BRANCH where BR_NAME='" + Session["UNITNAME"].ToString() + "'", con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);




            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT * FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);

            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_RPA"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_RPA"].ToString() : "PalanikumarA@equitasbank.com";
                //cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                //bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                //bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
            }

            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            fromID = "VF-ITSupport<VF-ITSupport@equitasbank.com>";
            toID = to;//"ManimaranK@equitasbank.com";
            //bcc2ID = "shankarg@equitasbank.com";
            //ccID = "PalanikumarA@equitasbank.com";

            // toID = "shankarg@equitasbank.com";
            // To Auto mail ///////
            System.Threading.Thread threadSendMails;




            //threadSendMails = new System.Threading.Thread(delegate()
            //{

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear TRM,<br/><br/> Please find the request for Risk Property Assessment of market value. <br/><br/>";
                BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='16%'><b>Lead No.</b></td><td style='whiteSpace:nowrap;' width='16%'>" + ldno + "</td>";
                BodyTxt = BodyTxt + "<td width='16%'><b>Area Name</b></td><td width='16%'>" + area + "</td>";
                BodyTxt = BodyTxt + "<td width='16%'><b>Branch Name</b></td><td width='16%'>" + brnch + "</td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='16%'><b>Product</b></td><td> ASL </td>";
                BodyTxt = BodyTxt + "<td width='16%'><b>Applicant Name</b></td><td width='16%'>" + apname + "</td><td width='16%'><b>Applicant Mobile No.</b></td><td width='16%'> " + apmobile + "</td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td  width='16%'><b>Property Address</b></td><td  width='16%'>" + Session["PROPADDR"].ToString().Trim() + "</td>";
                BodyTxt = BodyTxt + "<td  width='16%'><b>Guideline Value (Rate/sqft)</b></td><td  width='16%'>Rs." + gv + "</td  width='16%'><td><b>Land Area (sqft)</b></td><td  width='16%'> " + landarea + "</td></tr></table><br/>";

                BodyTxt = BodyTxt + "<br/>Please initiate and submit the report as per the prescribed TAT. <br/><br/><br/>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'>Thanks and Regards,<br/>Risk Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";

                blMailStatus = EmailManager.sendemailRPA(toID, "VF-ITSupport<VF-ITSupport@equitasbank.com>", "", "", "RPA Initiated for LEAD NO: " + ddlLeadNo.SelectedItem.Text + " " + txtBranchName.Text + " Branch", BodyTxt, "", true);


            //});

            //threadSendMails.IsBackground = true;

            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(5000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally { con.Close(); }
    }

    
    private void visible()
    {
        row1.Visible = true;
        row2.Visible = true;
        row3.Visible = true;
        row4.Visible = true;
        row5.Visible = true;
        row6.Visible = true;
        row7.Visible = true;
        row8.Visible = true;
    }

    private void enable()
    {
        txtLandArea.Text = "";
        txtGuideline.Text = "0";
        txtMarketValueSqrt.Text = "0";
        txtConsidered.Text = "";
        txtBuildUpArea.Text = "";
        txtBuildingValue.Text = "";
        ddlAgeOfBuilding.SelectedIndex = 0;
        txtDepreciation.Text = "";
        txtonsideredBuilding.Text = "";
        txtTotalPropertyValue.Text = "";
        txtLTVonProperty.Text = "";
        txtRecommendedLoan.Text = "";
        //  txtNameofInsuredPerson.Text = "";
        txtDeviation.Text = "";
    }

    protected void RadioBtnGV_Yes_CheckedChanged(object sender, EventArgs e)
    {
        visible();
        enable();
        txtGuideline.Text = "0";
        txtMarketValueSqrt.Text = "0";
        if (ddlPropType.SelectedItem.Text == "Self-occupied residence with RCC roofing" || ddlPropType.SelectedItem.Text == "Self-occupied commercial with RCC roofing" || ddlPropType.SelectedItem.Text == "Let out & RCC roofing")
        {
            txtGuideline.Enabled = true;
            txtMarketValueSqrt.Enabled = true;
        }
        else if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
        {
            txtGuideline.Enabled = true;
            txtMarketValueSqrt.Enabled = true;
        }
    }

    protected void RadioBtnGV_No_CheckedChanged(object sender, EventArgs e)
    {
        visible();
        enable();
        txtGuideline.Text = "0";
        txtMarketValueSqrt.Text = "0";

        if (ddlPropType.SelectedItem.Text == "Self-occupied residence with RCC roofing" || ddlPropType.SelectedItem.Text == "Self-occupied commercial with RCC roofing" || ddlPropType.SelectedItem.Text == "Let out & RCC roofing")
        {
            txtGuideline.Enabled = false;
            txtMarketValueSqrt.Enabled = true;

        }
        else if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
        {
            txtGuideline.Enabled = false;
            txtMarketValueSqrt.Enabled = true;
        }
    }

    protected void txtGuideline_Load(object sender, EventArgs e)
    {
        double dGuidline = 0.0;
        if (txtGuideline.Text != "" && txtMarketValueSqrt.Text == "0" && txtGuideline.Text != "0")
        {
            visible();

            if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
            {
                dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
            }
            else
            {
                dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
            }

            double dblCRate = Convert.ToDouble(txtLandArea.Text) * dGuidline;
            txtConsidered.Text = dblCRate.ToString();
        }
    }
    protected void btnDraft_Click(object sender, EventArgs e)
    {
        InsertDraftCamLapValues("D");
    }
    protected void InsertDraftCamLapValues(string strType)
    {
        try
        {
            if (ddlLeadNo.SelectedItem.Text == "--Select--")
            {
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select Lead No ');", true);
            }
            else
            {
                if (ddlReason.SelectedIndex > 0)
                {
                    if (ddlReason.SelectedItem.Text == "--Select--" || txtRemarks.Text == "")
                    {
                        uscMsgBox1.AddMessage("Please Select Reason And Enter Remarks", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else
                    {
                        SqlConnection con = new SqlConnection(strcon);
                        try
                        {
                            con.Open();

                            int rsnid = Convert.ToInt32(ddlReason.SelectedValue.ToString());
                            string strRmks = " OCI Lead Close ," + txtRemarks.Text;
                            SqlCommand cmdupdate = new SqlCommand("RTS_SP_Update_LeadCloseDetails", con);
                            cmdupdate.CommandType = CommandType.StoredProcedure;
                            cmdupdate.Parameters.AddWithValue("@LD_LC_RSN_ID", rsnid);
                            cmdupdate.Parameters.AddWithValue("@LD_LC_RMKS", strRmks);
                            cmdupdate.Parameters.AddWithValue("@LD_LC_MBY", Session["ID"].ToString());
                            cmdupdate.Parameters.AddWithValue("@LD_NO", ddlLeadNo.SelectedItem.Text);
                            cmdupdate.ExecuteNonQuery();
                            //   uscMsgBox1.AddMessage("Lead Closed Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Lead " + ddlLeadNo.SelectedItem.Text + "   Closed Successfully');window.location.reload()", true);
                        }
                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            uscMsgBox1.AddMessage("Problem to Close Lead", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        }
                        finally
                        {
                            ddlReason.SelectedIndex = 0;
                            txtRemarks.Text = "";
                            con.Close();
                        }
                    }
                }
                else
                {
                    DataTable dtIncomeDetails = new DataTable();
                    dtIncomeDetails = (DataTable)ViewState["CurrentTable"];
                    if (dtIncomeDetails.Columns.Contains("INCOME_SOURCE"))
                    {
                        dtIncomeDetails.Columns.Remove("INCOME_SOURCE");
                    }
                    if (dtIncomeDetails.Columns.Contains("RELATIONSHIP"))
                    {
                        dtIncomeDetails.Columns.Remove("RELATIONSHIP");
                    }
                    if (dtIncomeDetails.Columns.Contains("APP_TYPE"))
                    {
                        dtIncomeDetails.Columns.Remove("APP_TYPE");
                    }
                    DataTable dtObligation = new DataTable();
                    dtObligation = BindObligationTable();

                    DataTable dtColletral = new DataTable();
                    dtColletral = BindCollateralTable();

                    DataTable dtEnduSe = new DataTable();
                    dtEnduSe = BindEndUse();

                    SqlConnection con = new SqlConnection(strcon);
                    con.Open();
                    SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertCAM_New", con);
                    cmdinsert.CommandType = CommandType.StoredProcedure;
                    cmdinsert.Parameters.AddWithValue("@CAM_TYPE", "S");
                    //cmdinsert.Parameters.AddWithValue("@CAM_PR_ID", "1");

                    //cmdinsert.Parameters.AddWithValue("@CAM_BR_ID", txtBranchName.Text);
                    cmdinsert.Parameters.AddWithValue("@CAM_LD_ID", ddlLeadNo.SelectedValue.ToString());
                    cmdinsert.Parameters.AddWithValue("@CAM_AP_ADD", txtAddress.Text);
                    //cmdinsert.Parameters.AddWithValue("@CAM_ER_ID", ddlRelationShip.SelectedItem.Text != "--Select--" ? ddlRelationShip.SelectedValue.ToString() : (object)DBNull.Value);
                    //cmdinsert.Parameters.AddWithValue("@CAM_INS_ID", ddlMainApplicant.SelectedItem.Text != "--Select--" ? ddlMainApplicant.SelectedValue.ToString() : (object)DBNull.Value);
                    cmdinsert.Parameters.AddWithValue("@CAM_VN_ID", ddlVintage.SelectedItem.Text != "--Select--" ? ddlVintage.SelectedValue.ToString() : (object)DBNull.Value);
                    //cmdinsert.Parameters.AddWithValue("@CAM_NT_ID", ddlNature.SelectedItem.Text != "--Select--" ? ddlNature.SelectedValue.ToString() : (object)DBNull.Value);
                    //cmdinsert.Parameters.AddWithValue("@CAM_IT_ID", ddlIncomType.SelectedItem.Text != "--Select--" ? ddlIncomType.SelectedValue.ToString() : (object)DBNull.Value);
                    //cmdinsert.Parameters.AddWithValue("@CAM_PP_ID", ddlLoanPurpose.SelectedItem.Text != "--Select--" ? ddlLoanPurpose.SelectedValue.ToString() : (object)DBNull.Value);
                    //cmdinsert.Parameters.AddWithValue("@CAM_CH_ID", ddlCreditHistory.SelectedItem.Text != "--Select--" ? ddlCreditHistory.SelectedValue.ToString() : (object)DBNull.Value);

                    cmdinsert.Parameters.AddWithValue("@CAM_AGL", txtAgriLandAcres.Text != "" ? Convert.ToDouble(txtAgriLandAcres.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_AGI", txtAgriIncome.Text != "" ? Convert.ToDouble(txtAgriIncome.Text) : 0.0);

                    cmdinsert.Parameters.AddWithValue("@CAM_TOT_IN", txtTotalLoanEligibility.Text != "" ? Convert.ToDouble(txtTotalLoanEligibility.Text) : 0.0);

                    cmdinsert.Parameters.AddWithValue("@CAM_TOT_EMI", txtTotalEMIAmount.Text != "" ? Convert.ToDouble(txtTotalEMIAmount.Text) : 0.0);

                    cmdinsert.Parameters.AddWithValue("@CAM_TENURE", ddlTenure.SelectedItem.Text != "--Select--" ? ddlTenure.SelectedValue : "0");
                    cmdinsert.Parameters.AddWithValue("@CAM_INR", ddlIntrest.SelectedItem.Text != "--Select--" ? Convert.ToDouble(ddlIntrest.SelectedItem.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_EPL", txtEMIperLakh.Text != "" ? Convert.ToDouble(txtEMIperLakh.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_IRR", txtIIREligibility.Text != "" ? Convert.ToDouble(txtIIREligibility.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_FOIR", txtFOIREligibility.Text != "" ? Convert.ToDouble(txtFOIREligibility.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_LAMT_REQ", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_LN_ELG", txtLoanEligibility.Text != "" ? Convert.ToDouble(txtLoanEligibility.Text) : 0.0);

                    cmdinsert.Parameters.AddWithValue("@CAM_PT_ID", ddlPropType.SelectedItem.Text != "--Select--" ? ddlPropType.SelectedItem.Text.ToString() : (object)DBNull.Value);
                    cmdinsert.Parameters.AddWithValue("@CAM_OC_ID", ddlOccupancyStatus.SelectedItem.Text != "--Select--" ? ddlOccupancyStatus.SelectedValue.ToString() : (object)DBNull.Value);
                    cmdinsert.Parameters.AddWithValue("@CAM_UG_ID", ddlUsage.SelectedItem.Text != "--Select--" ? ddlUsage.SelectedValue.ToString() : (object)DBNull.Value);
                    cmdinsert.Parameters.AddWithValue("@CAM_NOT", txtNoOFtenents.Text);
                    cmdinsert.Parameters.AddWithValue("@CAM_LAREA", txtLandArea.Text != "" ? Convert.ToDouble(txtLandArea.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_GLV", txtGuideline.Text != "" ? Convert.ToDouble(txtGuideline.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_MV", txtMarketValueSqrt.Text != "" ? Convert.ToDouble(txtMarketValueSqrt.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_CLV", txtConsidered.Text != "" ? Convert.ToDouble(txtConsidered.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_BAREA", txtBuildUpArea.Text != "" ? Convert.ToDouble(txtBuildUpArea.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_BV", txtBuildingValue.Text != "" ? Convert.ToDouble(txtBuildingValue.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_BA_ID", ddlAgeOfBuilding.SelectedItem.Text != "--Select--" ? ddlAgeOfBuilding.SelectedItem.Text : (object)DBNull.Value);
                    cmdinsert.Parameters.AddWithValue("@CAM_DEP", txtDepreciation.Text != "" ? Convert.ToDouble(txtDepreciation.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_CBV", txtonsideredBuilding.Text != "" ? Convert.ToDouble(txtonsideredBuilding.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_TPV", txtTotalPropertyValue.Text != "" ? Convert.ToDouble(txtTotalPropertyValue.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_LN_LTV", txtLTVonProperty.Text != "" ? Convert.ToDouble(txtLTVonProperty.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_RLA", txtRecommendedLoan.Text != "" ? Convert.ToDouble(txtRecommendedLoan.Text) : 0.0);
                    cmdinsert.Parameters.AddWithValue("@CAM_EMP_ID", txtEmpCode.Text);
                    cmdinsert.Parameters.AddWithValue("@CAM_Deviation", txtDeviation.Text);
                    string[] strCusVal = ddlCustProfile.SelectedValue.Split('|');
                    cmdinsert.Parameters.AddWithValue("@CAM_CP_ID", strCusVal[0].ToString());
                    cmdinsert.Parameters.AddWithValue("@CAM_PRTY_OWN", rbtnPropOwner.SelectedValue);

                    cmdinsert.Parameters.AddWithValue("@CAM_AGR_HOLD", rbtnAgriHoldingSts.SelectedValue);
                    cmdinsert.Parameters.AddWithValue("@CAM_EXTN_AGRI", txtAgriLnadholding.Text);
                    cmdinsert.Parameters.AddWithValue("@CAM_EXTN_LSE_AGRI", txtLeaseLandholding.Text);   

                    cmdinsert.Parameters.AddWithValue("@CAM_PCS", txtNameofInsuredPerson.Text);
                    cmdinsert.Parameters.AddWithValue("@CAM_CBY", Session["ID"].ToString());
                    cmdinsert.Parameters.AddWithValue("@CAM_MBY", Session["ID"].ToString());
                    if (dtIncomeDetails.Rows.Count > 0)
                    {
                        if (dtIncomeDetails.Rows[0][0].ToString() == "")
                        {
                            dtIncomeDetails.Rows.RemoveAt(0);
                        }
                    }

                    cmdinsert.Parameters.AddWithValue("@tblIncome_Details", dtIncomeDetails);
                    cmdinsert.Parameters.AddWithValue("@tblOBLIGATE", dtObligation);
                    cmdinsert.Parameters.AddWithValue("@tblCOLLATERAL", dtColletral);
                    cmdinsert.Parameters.AddWithValue("@tblEndUse", dtEnduSe);
                    string strReg = "";
                    if (RadioBtnGV_No.Checked)
                    {
                        strReg = "N";
                    }
                    else if (RadioBtnGV_Yes.Checked)
                    {
                        strReg = "Y";
                    }
                    cmdinsert.Parameters.AddWithValue("@CAM_Regnet", strReg);
                    cmdinsert.Parameters.AddWithValue("@SAVETYPE", strType);
                    cmdinsert.Parameters.AddWithValue("@CAM_END_AMOUNT", txtEndUseAmnt.Text);
                    cmdinsert.Parameters.AddWithValue("@CAM_COW_COUNT", txtCowCount.Text);
                    #region Counts
                    cmdinsert.Parameters.AddWithValue("@CAM_COW_COUNT1", txtCowCount1.Text);
                    cmdinsert.Parameters.AddWithValue("@CAM_COW_COUNT2", txtCowCOuntBuild.Text);
                    cmdinsert.Parameters.AddWithValue("@CAM_COW_COUNT3", txtBuffaloCount.Text);
                    #endregion
                    int n = cmdinsert.ExecuteNonQuery();
                    if (n > 0)
                    {


                        if (strType == "S")
                        {
                            if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "")
                            {
                                double dGuidline = 0.0;
                                if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                                {
                                    dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                                }
                                else
                                {
                                    dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                                }
                                //if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text) && RadioBtnGV_No.Checked)
                                //{
                                //    sendMail();
                                //}
                                if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text))
                                {
                                    sendMail();
                                }
                            }
                        }

                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Saved Successfully');window.location.reload()", true);
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Failed to Save');", true);
                    }

                    con.Close();
                }
            }



        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    //protected void BindDepndsMainAppln()
    //{
    //    if (ddlMainApplicant.SelectedIndex > 0)
    //    {
    //        SqlConnection con = new SqlConnection(strcon);
    //        con.Open();

    //        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);

    //        cmddd.Parameters.AddWithValue("@VN_ID", "");
    //        cmddd.Parameters.AddWithValue("@VN_INS_ID", ddlMainApplicant.SelectedValue.ToString());
    //        cmddd.CommandType = CommandType.StoredProcedure;
    //        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //        DataSet dsdd = new DataSet();
    //        dadd.Fill(dsdd);

    //        con.Close();
    //        ddlVintage.DataSource = dsdd;
    //        ddlVintage.DataTextField = "VN_DESC";
    //        ddlVintage.DataValueField = "VN_ID";
    //        ddlVintage.DataBind();
    //        ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));



    //        ddlNature.Items.Clear();
    //        con = new SqlConnection(strcon);
    //        con.Open();
    //        cmddd = new SqlCommand("RTS_SP_Fetch_MR_NATURE", con);
    //        cmddd.Parameters.AddWithValue("@NT_ID", "");
    //        cmddd.Parameters.AddWithValue("@NT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
    //        cmddd.CommandType = CommandType.StoredProcedure;
    //        dadd = new SqlDataAdapter(cmddd);
    //        dsdd = new DataSet();
    //        dadd.Fill(dsdd);


    //        ddlNature.DataSource = dsdd;
    //        ddlNature.DataTextField = "NT_DESC";
    //        ddlNature.DataValueField = "NT_ID";
    //        ddlNature.DataBind();
    //        ddlNature.Items.Insert(0, new ListItem("--Select--", "0"));


    //        ddlIncomType.Items.Clear();
    //        cmddd = new SqlCommand("RTS_SP_Fetch_MR_INCOME_TYPE", con);
    //        cmddd.Parameters.AddWithValue("@IT_ID", "");
    //        //cmddd.Parameters.AddWithValue("@IT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
    //        cmddd.Parameters.AddWithValue("@IT_INS_ID", "");
    //        cmddd.CommandType = CommandType.StoredProcedure;
    //        dadd = new SqlDataAdapter(cmddd);
    //        dsdd = new DataSet();
    //        dadd.Fill(dsdd);


    //        ddlIncomType.DataSource = dsdd;
    //        ddlIncomType.DataTextField = "IT_DESC";
    //        ddlIncomType.DataValueField = "IT_ID";
    //        ddlIncomType.DataBind();
    //        ddlIncomType.Items.Insert(0, new ListItem("--Select--", "0"));

    //        con.Close();
    //    }
    //}
    public void FetchCam()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_To_Update", con);
        cmddd.Parameters.AddWithValue("@Lead_ID", ddlLeadNo.SelectedValue.ToString());
        cmddd.Parameters.AddWithValue("@CamType", "S");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            //// Search creteria
            txtBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
            //txtLeadNo.Text = dsdd.Tables[0].Rows[0]["LD_NO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_NO"].ToString() : "";
            txtPDDate.Text = dsdd.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
            txtCAMDATE.Text = dsdd.Tables[0].Rows[0]["CAM_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["CAM_DATE"]).ToString("dd/MMM/yyyy") : DateTime.Now.ToString("dd/MMM/yyyy");
            // ddlRelationShip.SelectedValue = dsdd.Tables[0].Rows[0]["ER_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ER_ID"].ToString() : "0";
            //ddlMainApplicant.SelectedValue = dsdd.Tables[0].Rows[0]["INS_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["INS_ID"].ToString() : "0";
            //BindDepndsMainAppln();
            ddlVintage.SelectedValue = dsdd.Tables[0].Rows[0]["VN_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["VN_ID"].ToString() : "0";
            //ddlNature.SelectedValue = dsdd.Tables[0].Rows[0]["NT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["NT_ID"].ToString() : "0";
            //ddlIncomType.SelectedValue = dsdd.Tables[0].Rows[0]["IT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["IT_ID"].ToString() : "0";
            //  ddlLoanPurpose.SelectedValue = dsdd.Tables[0].Rows[0]["PP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PP_ID"].ToString() : "0";
            //ddlCreditHistory.SelectedValue = dsdd.Tables[0].Rows[0]["CH_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_ID"].ToString() : "0";
            txtApplnName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
            txtAddress.Text = dsdd.Tables[0].Rows[0]["CAM_AP_ADD"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AP_ADD"].ToString() : "";
            txtContactNo.Text = dsdd.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
            txtMemberID.Text = dsdd.Tables[0].Rows[0]["LD_MID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_MID"].ToString() : "";
            //   BindTenor();
            ddlTenure.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_TENURE"] != DBNull.Value ? Convert.ToInt32(dsdd.Tables[0].Rows[0]["CAM_TENURE"]).ToString() : "0";
            ddlIntrest.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_INR"] != DBNull.Value ? Convert.ToInt32(dsdd.Tables[0].Rows[0]["CAM_INR"]).ToString() : "0";
            txtEMIperLakh.Text = dsdd.Tables[0].Rows[0]["CAM_EPL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EPL"].ToString() : "";
            txtIIREligibility.Text = dsdd.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_IIR"].ToString() : "";
            txtFOIREligibility.Text = dsdd.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "";
            txtLoanAmountRequested.Text = dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"].ToString() : "";
            txtLoanEligibility.Text = dsdd.Tables[0].Rows[0]["CAM_LN_ELG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LN_ELG"].ToString() : "";
            txtCowCount.Text = dsdd.Tables[0].Rows[0]["CAM_COW_COUNT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_COW_COUNT"].ToString() : "";
            #region Counts
            if (txtCowCount.Text == "" || txtCowCount.Text == "0")
            {
                txtCowCount.Visible = false;
                lblCowCount.Visible = false;
            }
            else
            {
                txtCowCount.Visible = true;
                lblCowCount.Visible = true;
            }
            txtCowCount1.Text = dsdd.Tables[0].Rows[0]["CAM_COW_COUNT1"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_COW_COUNT1"].ToString() : "";
            if (txtCowCount1.Text == "" || txtCowCount1.Text == "0")
            {
                txtCowCount1.Visible = false;
                lblCowCount1.Visible = false;
            }
            else
            {
                txtCowCount1.Visible = true;
                lblCowCount1.Visible = true;
            }
            txtCowCOuntBuild.Text = dsdd.Tables[0].Rows[0]["CAM_COW_COUNT2"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_COW_COUNT2"].ToString() : "";
            if (txtCowCOuntBuild.Text == "" || txtCowCOuntBuild.Text == "0")
            {
                txtCowCOuntBuild.Visible = false;
                lblCowCountBuild.Visible = false;
            }
            else
            {
                txtCowCOuntBuild.Visible = true;
                lblCowCountBuild.Visible = true;
            }
            txtBuffaloCount.Text = dsdd.Tables[0].Rows[0]["CAM_COW_COUNT3"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_COW_COUNT3"].ToString() : "";
            if (txtBuffaloCount.Text == "" || txtBuffaloCount.Text == "0")
            {
                txtBuffaloCount.Visible = false;
                lblBuffaloCount.Visible = false;
            }
            else
            {
                txtBuffaloCount.Visible = true;
                lblBuffaloCount.Visible = true;
            }
            #endregion
            txtEndUseAmnt.Text = dsdd.Tables[0].Rows[0]["CAM_END_AMOUNT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_END_AMOUNT"].ToString() : "0";
            txtTotalLoanEligibility.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";

            ddlPropType.SelectedValue = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "";

            ddlCustProfile.SelectedValue = dsdd.Tables[0].Rows[0]["CP VAL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CP VAL"].ToString() : "";

            rbtnPropOwner.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_PRTY_OWN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_PRTY_OWN"].ToString() : "";

            rbtnAgriHoldingSts.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_AGR_HOLD"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGR_HOLD"].ToString() : "N";
            txtAgriLnadholding.Text = dsdd.Tables[0].Rows[0]["CAM_EXTN_AGRI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EXTN_AGRI"].ToString() : "0";
            txtLeaseLandholding.Text = dsdd.Tables[0].Rows[0]["CAM_EXTN_LSE_AGRI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EXTN_LSE_AGRI"].ToString() : "0";
            //txtExtendElibility.Text = Convert.ToString(Convert.ToDouble(txtAgriLnadholding.Text) * 50000);

            RadioBtnGV_No.Checked = false;
            RadioBtnGV_Yes.Checked = false;
            VisibleFalse();
            enable();
            btnSubmit.Enabled = false;

            if (rbtnAgriHoldingSts.SelectedValue == "Y")
            {
                dvLease.Visible = false;
                txtLeaseLandholding.Enabled = false;
                dvLand.Visible = true;
                txtAgriLnadholding.Enabled = true;
                //txtLeaseLandholding.Enabled = false;
                // txtAgriLnadholding.Enabled = true;
            }
            else
                if (rbtnAgriHoldingSts.SelectedValue == "N")
                {
                    // txtAgriLnadholding.Enabled = false;
                    dvLease.Visible = true;
                    txtLeaseLandholding.Enabled = true;
                    dvLand.Visible = false;
                    txtAgriLnadholding.Enabled = false;
                }
                else
                {
                    txtLeaseLandholding.Enabled = true;
                    txtAgriLnadholding.Enabled = true;
                    dvLease.Visible = true;
                    dvLand.Visible = true;
                }

            SqlCommand cmddd1 = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY", con);
            cmddd1.Parameters.AddWithValue("@PT_ID", "");
            cmddd1.Parameters.AddWithValue("@PT_TYPE", "A");
            cmddd1.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd1 = new SqlDataAdapter(cmddd1);
            DataSet dsdd1 = new DataSet();
            dadd1.Fill(dsdd1);



            if (ddlPropType.SelectedItem.Text != "--Select--")
            {

                DataRow[] dr1 = dsdd1.Tables[0].Select("PT_DESC='" + ddlPropType.SelectedItem.Text + "'");
                lblSqrft.Text = " @ " + dr1[0].ItemArray[2].ToString() + " / Sqft ";
                ddlPropType.Focus();
            }
            ddlOccupancyStatus.SelectedValue = dsdd.Tables[0].Rows[0]["OC_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["OC_ID"].ToString() : "0";
            ddlUsage.SelectedValue = dsdd.Tables[0].Rows[0]["UG_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["UG_ID"].ToString() : "0";
            txtNoOFtenents.Text = dsdd.Tables[0].Rows[0]["CAM_NOT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOT"].ToString() : "";

            string strCamReg = dsdd.Tables[0].Rows[0]["CAM_REGNET"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_REGNET"].ToString() : "";
            if (strCamReg == "Y")
            {
                RadioBtnGV_Yes.Checked = true;
                visible();
                enable();
                txtGuideline.Text = "0";
                txtMarketValueSqrt.Text = "0";
                if (ddlPropType.SelectedItem.Text == "Self-occupied residence with RCC roofing" || ddlPropType.SelectedItem.Text == "Self-occupied commercial with RCC roofing" || ddlPropType.SelectedItem.Text == "Let out & RCC roofing")
                {
                    txtGuideline.Enabled = true;
                    txtMarketValueSqrt.Enabled = true;
                }
                else if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                {
                    txtGuideline.Enabled = true;
                    txtMarketValueSqrt.Enabled = true;
                }
            }
            else if (strCamReg == "N")
            {
                RadioBtnGV_No.Checked = true;
                visible();
                enable();
                txtGuideline.Text = "0";
                txtMarketValueSqrt.Text = "0";

                if (ddlPropType.SelectedItem.Text == "Self-occupied residence with RCC roofing" || ddlPropType.SelectedItem.Text == "Self-occupied commercial with RCC roofing" || ddlPropType.SelectedItem.Text == "Let out & RCC roofing")
                {
                    txtGuideline.Enabled = false;
                    txtMarketValueSqrt.Enabled = true;

                }
                else if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                {
                    txtGuideline.Enabled = false;
                    txtMarketValueSqrt.Enabled = true;
                }
            }


            txtLandArea.Text = dsdd.Tables[0].Rows[0]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAREA"].ToString() : "";
            txtGuideline.Text = dsdd.Tables[0].Rows[0]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_GLV"].ToString() : "";
            txtMarketValueSqrt.Text = dsdd.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
            txtConsidered.Text = dsdd.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CLV"].ToString() : "";
            txtBuildUpArea.Text = dsdd.Tables[0].Rows[0]["CAM_BAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BAREA"].ToString() : "";
            txtBuildingValue.Text = dsdd.Tables[0].Rows[0]["CAM_BV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BV"].ToString() : "";
            ddlAgeOfBuilding.SelectedValue = dsdd.Tables[0].Rows[0]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BA_DESC"].ToString() : "0";
            // ddlFarmerActivity.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_FA_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FA_ID"].ToString() : "0";
            txtDepreciation.Text = dsdd.Tables[0].Rows[0]["CAM_DEP"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_DEP"].ToString() : "";
            txtonsideredBuilding.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
            txtTotalPropertyValue.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
            txtLTVonProperty.Text = dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
            txtRecommendedLoan.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
            txtNameofInsuredPerson.Text = dsdd.Tables[0].Rows[0]["CAM_PCS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_PCS"].ToString() : "";

            txtAgriLandAcres.Text = dsdd.Tables[0].Rows[0]["CAM_AGL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGL"].ToString() : "";
            txtAgriIncome.Text = dsdd.Tables[0].Rows[0]["CAM_AGI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGI"].ToString() : "";

            txtDeviation.Text = dsdd.Tables[0].Rows[0]["CAM_DEVIATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_DEVIATE"].ToString() : "";
            if (dsdd.Tables[1] != null && dsdd.Tables[1].Rows.Count > 0)
            {
                gvIncomeDetail.DataSource = dsdd.Tables[1];
                gvIncomeDetail.DataBind();
                BindBorrower(dsdd.Tables[1]);
                ViewState["CurrentTable"] = dsdd.Tables[1];
                for (int n = 0; n < dsdd.Tables[1].Rows.Count; n++)
                {
                    string strText = dsdd.Tables[1].Rows[n]["NAME"].ToString();
                    int nIndex = DDLkycName.Items.IndexOf(DDLkycName.Items.FindByText(strText));
                    //  DDLkycName.Items.RemoveAt(nIndex);
                }

                //   DDLkycName.DataBind();
            }


            if (dsdd.Tables[2] != null && dsdd.Tables[2].Rows.Count > 0)
            {
                for (int i = 0; i < dsdd.Tables[2].Rows.Count; i++)
                {
                    switch (i)
                    {
                        case 0:
                            txtFinanciear1.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                            drpName1.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                            txtEMIAmount1.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                            break;
                        case 1:
                            txtFinanciear2.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                            drpName2.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                            txtEMIAmount2.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                            break;
                        case 2:
                            txtFinanciear3.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                            drpName3.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                            txtEMIAmount3.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                            break;
                        case 3:
                            txtFinanciear4.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                            drpName4.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                            txtEMIAmount4.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                            break;
                        case 4:
                            txtFinanciear4.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                            drpName5.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                            txtEMIAmount5.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                            break;
                    }
                }
            }

            txtTotalEMIAmount.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";
            txtEmpCode.Text = dsdd.Tables[0].Rows[0]["CAM_EMP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EMP_ID"].ToString() : "";

            //string strEUIDS = dsdd.Tables[0].Rows[0]["CAM_EU_IDS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EU_IDS"].ToString() : "";

            //if (strEUIDS != "")
            //{
            //    string[] strEUarray = strEUIDS.Split('|');
            //    for(int nval=0;nval<strEUarray.Length;nval++)
            //    {
            //        for (int nECount = 0; nECount < ddlLoanPurpose.Items.Count; nECount++)
            //        {
            //            if (ddlLoanPurpose.Items[nECount].Value == strEUarray[nval].ToString())
            //            {
            //                ddlLoanPurpose.Items[nECount].Selected = true;
            //            }
            //        }

            //      //  ddlLoanPurpose.SelectedValue = strEUarray[nval].ToString();
            //    }
            //}
            if (dsdd.Tables[4] != null && dsdd.Tables[4].Rows.Count > 0)
            {
                for (int k = 0; k < ddlFarmerActivity.Items.Count; k++)
                {
                    for (int j = 0; j < dsdd.Tables[4].Rows.Count; j++)
                    {
                        if (ddlFarmerActivity.Items[k].Value == dsdd.Tables[4].Rows[j]["FCC_FA_ID"].ToString())
                        {
                            ddlFarmerActivity.Items[k].Selected = true;
                        }
                    }
                }
            }
            ViewState["LoanPurpose"] = dsdd.Tables[4];
            BIndLLProcess();

            if (dsdd.Tables[4] != null && dsdd.Tables[4].Rows.Count > 0)
            {

            }

            BindEMpDets();

        }
        con.Close();
    }
    protected void txtEmpCode_TextChanged(object sender, EventArgs e)
    {
        BindEMpDets();
    }
    protected void BindEMpDets()
    {

        if (txtEmpCode.Text.Length == 4)
        {
            txtEmpCode.Text = "0" + txtEmpCode.Text;
        }
        else if (txtEmpCode.Text.Length == 4)
        {
            txtEmpCode.Text = "00" + txtEmpCode.Text;
        }
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("SELECT * from HR_EMP_DETS  WHERE EMP_CODE='" + txtEmpCode.Text + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            txtEMpID.Text = dsdd.Tables[0].Rows[0]["EMP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_ID"].ToString() : "";
            txtEMpNAme.Text = dsdd.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
            txtDesgn.Text = dsdd.Tables[0].Rows[0]["EMP_DESIGN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_DESIGN"].ToString() : "";
            txtContact.Text = dsdd.Tables[0].Rows[0]["EMP_PHNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_PHNO"].ToString() : "";

            ttxEmailEmp.Text = dsdd.Tables[0].Rows[0]["EMP_EMAIL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_EMAIL"].ToString() : "";
            txtEmpCompany.Text = dsdd.Tables[0].Rows[0]["EMP_COMPANY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_COMPANY"].ToString() : "";
            txtDOJ.Text = dsdd.Tables[0].Rows[0]["EMP_DOJ"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_DOJ"].ToString() : "";
            txtGrade.Text = dsdd.Tables[0].Rows[0]["EMP_GRADE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_GRADE"].ToString() : "";
        }
        else
        {
            txtEMpID.Text = "";
            txtEMpNAme.Text = "";
            txtDesgn.Text = "";
            txtContact.Text = "";
        }
    }

    protected void bindCustProfile()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("FETCH_MR_CUST_PROF", con);
        cmddd.Parameters.AddWithValue("@PRI_ID", "29");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();

        //DataRow[] drTemp = dsdd.Tables[0].Select("CP_DESC like '%farmer%'");
        ddlCustProfile.DataSource = dsdd;
        ddlCustProfile.DataTextField = "CP_DESC";
        ddlCustProfile.DataValueField = "CP VAL";
        ddlCustProfile.DataBind();
        //ddlCustProfile.Enabled = false;
        ddlCustProfile.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void Hold_click(object sender, EventArgs e)
    {
        try
        {
            if (chk_hold.Checked == true)
            {
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmddd = new SqlCommand("RTS_SP_HOLD_B_CAM", con);
                cmddd.Parameters.AddWithValue("@Lead_ID", ddlLeadNo.SelectedValue.ToString());
                cmddd.CommandType = CommandType.StoredProcedure;
                cmddd.ExecuteNonQuery();
                con.Close();
                btnCalculate.Enabled = false;
                btnDraft.Enabled = false;
                uscMsgBox1.AddMessage("HOLD Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            else
            {

                btnCalculate.Enabled = true;
                btnDraft.Enabled = true;
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=CAM_LAP_Sampling.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }



    }

    protected void chk_hold_CheckedChanged(object sender, EventArgs e)
    {
        if (chk_hold.Checked)
        {
            if (ddlLeadNo.SelectedItem.Text != "--Select--")
            {
                btnCalculate.Enabled = false;
                btnDraft.Enabled = false;
                btn_go.Enabled = true;
            }
            else
            {
                uscMsgBox1.AddMessage("Please select Lead no", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                chk_hold.Checked = false;

            }
        }
        else
        {
            btnCalculate.Enabled = true;
            btnDraft.Enabled = true;
        }
    }

    public void bindCloseReason()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        SqlCommand cmdrsn = new SqlCommand("RTS_SP_Fetch_MR_REASON", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlReason.DataSource = dsrsn;
        ddlReason.DataTextField = "RSN_REASON";
        ddlReason.DataValueField = "RSN_ID";
        ddlReason.DataBind();
        ddlReason.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    protected void ddlReason_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (ddlReason.SelectedIndex > 0)
        {
            txtRemarks.Enabled = true;
            btnSubmit.Enabled = true;
        }
        else
        {
            txtRemarks.Enabled = false;
            txtRemarks.Text = "";
            btnSubmit.Enabled = false;
        }
    }

    protected void bindFarmerActivity()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_FARMER_ACTIVITY", con);
        //cmddd.Parameters.AddWithValue("@PRI_ID", "13");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        //DataRow[] drTemp = dsdd.Tables[0].Select("CP_DESC like '%farmer%'");
        //Bala changes starts 10/11/2016
        if (ddlCustProfile.SelectedItem.Text == "Agri Laborer")
        {
            DataRow[] drRel = dsdd.Tables[0].Select("FA_DESC not in  ('Crop Loans','Agriculture Infrastructure')");
            // 
            ddlFarmerActivity.DataSource = drRel.CopyToDataTable();
        }
        else
        {
            ddlFarmerActivity.DataSource = dsdd;
        }
        // ddlFarmerActivity.DataSource = dsdd;
        //Bala changes end 10/11/2016
        ddlFarmerActivity.DataTextField = "FA_DESC";
        ddlFarmerActivity.DataValueField = "FA_ID";
        ddlFarmerActivity.DataBind();
        //ddlCustProfile.Enabled = false;
        // ddlFarmerActivity.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void ddlLoanPurpose_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlFarmerActivity_SelectedIndexChanged(object sender, EventArgs e)
    {
        //bindFarmerActivity();


        BIndLLProcess();
    }
    public void BIndLLProcess()
    {
        string strINputValues = "0";

        for (int nValu = 0; nValu < ddlFarmerActivity.Items.Count; nValu++)
        {
            if (ddlFarmerActivity.Items[nValu].Selected)
            {
                strINputValues = strINputValues + "|" + ddlFarmerActivity.Items[nValu].Value;


            }

        }
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_FETCH_MR_SUB_FARMER_ACTIVITY", con);
        cmddd.Parameters.AddWithValue("@FA_ID", strINputValues);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();

        //DataRow[] drTemp = dsdd.Tables[0].Select("CP_DESC like '%farmer%'");
        ddlLoanPurpose.DataSource = dsdd;
        ddlLoanPurpose.DataTextField = "FAS_DESC";
        ddlLoanPurpose.DataValueField = "FAS VALUES";
        ddlLoanPurpose.DataBind();
        DataTable dtTemp = (DataTable)ViewState["LoanPurpose"];
        if (dtTemp != null && dtTemp.Rows.Count > 0)
        {
            for (int k = 0; k < ddlLoanPurpose.Items.Count; k++)
            {
                for (int j = 0; j < dtTemp.Rows.Count; j++)
                {
                    string[] strKval = ddlLoanPurpose.Items[k].Value.Split('|');
                    if (strKval[0].ToString() == dtTemp.Rows[j]["FCC_FAS_ID"].ToString())
                    {
                        ddlLoanPurpose.Items[k].Selected = true;

                        if (ddlLoanPurpose.Items[k].Text == "Purchase of Cow")
                        {

                            txtCowCount.Visible = true;
                            lblCowCount.Visible = true;
                        }
                        else
                        {
                            if (txtCowCount.Text == "" || txtCowCount.Text == "0")
                            {
                                lblCowCount.Visible = false;
                                txtCowCount.Visible = false;
                            }
                            else
                            {
                                lblCowCount.Visible = true;
                                txtCowCount.Visible = true;
                            }

                        }
                        #region Counts
                        if (ddlLoanPurpose.Items[k].Text == "Feeding the Cattle")
                        {

                            txtCowCount1.Visible = true;
                            lblCowCount1.Visible = true;
                        }
                        else
                        {
                            if (txtCowCount1.Text == "" || txtCowCount1.Text == "0")
                            {
                                lblCowCount1.Visible = false;
                                txtCowCount1.Visible = false;
                            }
                            else
                            {
                                lblCowCount1.Visible = true;
                                txtCowCount1.Visible = true;
                            }

                        }

                        if (ddlLoanPurpose.Items[k].Text == "Building the Cattle Shed")
                        {
                            lblCowCountBuild.Visible = true;
                            txtCowCOuntBuild.Visible = true;
                        }
                        else
                        {
                            if (txtCowCOuntBuild.Text == "" || txtCowCOuntBuild.Text == "0")
                            {
                                lblCowCountBuild.Visible = false;
                                txtCowCOuntBuild.Visible = false;
                            }
                            else
                            {
                                lblCowCountBuild.Visible = true;
                                txtCowCOuntBuild.Visible = true;
                            }

                        }
                        if (ddlLoanPurpose.Items[k].Text == "Purchase of Buffalo")
                        {
                            lblBuffaloCount.Visible = true;
                            txtBuffaloCount.Visible = true;
                        }
                        else
                        {
                            if (txtBuffaloCount.Text == "" || txtBuffaloCount.Text == "0")
                            {
                                lblBuffaloCount.Visible = false;
                                txtBuffaloCount.Visible = false;
                            }
                            else
                            {
                                lblBuffaloCount.Visible = true;
                                txtBuffaloCount.Visible = true;
                            }

                        }
                        #endregion
                    }
                }
            }
        }
    }
    protected void ddlLoanPurpose_SelectedIndexChanged1(object sender, EventArgs e)
    {


        for (int nValu = 0; nValu < ddlLoanPurpose.Items.Count; nValu++)
        {
           /* if (ddlLoanPurpose.Items[nValu].Selected)
            {

                if (ddlLoanPurpose.Items[nValu].Text == "Purchase of Cow" || ddlLoanPurpose.Items[nValu].Text == "Feeding the Cattle")
                {

                    txtCowCount.Visible = true;
                    lblCowCount.Visible = true;
                    txtCowCount.Text = "1";
                }
                else
                {
                    if (txtCowCount.Text == "" || txtCowCount.Text == "0")
                    {
                        lblCowCount.Visible = false;
                        txtCowCount.Visible = false;
                    }
                    else
                    {
                        lblCowCount.Visible = true;
                        txtCowCount.Visible = true;
                    }

                }
                #region Counts

                if (ddlLoanPurpose.Items[nValu].Text == "Feeding the Cattle")
                {

                    txtCowCount1.Visible = true;
                    lblCowCount1.Visible = true;
                    if (txtCowCount1.Text == "")
                    {
                        txtCowCount1.Text = "1";
                    }

                }
                else
                {
                    if (txtCowCount1.Text == "" || txtCowCount1.Text == "0")
                    {
                        lblCowCount1.Visible = false;
                        txtCowCount1.Visible = false;
                        txtCowCount1.Text = "";
                    }
                    else
                    {
                        lblCowCount1.Visible = true;
                        txtCowCount1.Visible = true;
                    }

                }

                if (ddlLoanPurpose.Items[nValu].Text == "Building the Cattle Shed")
                {
                    lblCowCountBuild.Visible = true;
                    txtCowCOuntBuild.Visible = true;
                    if (txtCowCOuntBuild.Text == "")
                        txtCowCOuntBuild.Text = "1";
                }
                else
                {
                    if (txtCowCOuntBuild.Text == "" || txtCowCOuntBuild.Text == "0")
                    {
                        lblCowCountBuild.Visible = false;
                        txtCowCOuntBuild.Visible = false;
                        txtCowCOuntBuild.Text = "";
                    }
                    else
                    {
                        lblCowCountBuild.Visible = true;
                        txtCowCOuntBuild.Visible = true;
                    }
                }


                if (ddlLoanPurpose.Items[nValu].Text == "Purchase of Buffalo")
                {
                    lblBuffaloCount.Visible = true;
                    txtBuffaloCount.Visible = true;
                    if (txtBuffaloCount.Text == "")
                        txtBuffaloCount.Text = "1";
                }
                else
                {
                    if (txtBuffaloCount.Text == "" || txtBuffaloCount.Text == "0")
                    {
                        lblBuffaloCount.Visible = false;
                        txtBuffaloCount.Visible = false;
                        txtBuffaloCount.Text = "";
                    }
                    else
                    {
                        lblBuffaloCount.Visible = true;
                        txtBuffaloCount.Visible = true;
                    }
                }
                #endregion


            }*/
            if (ddlLoanPurpose.Items[nValu].Text == "Purchase of Cow")
            {
                if (ddlLoanPurpose.Items[nValu].Selected == true)
                {
                    txtCowCount.Visible = true;
                    lblCowCount.Visible = true;
                    if (txtCowCount.Text == "" || txtCowCount.Text == "0")
                    {
                        txtCowCount.Text = "1";
                    }
                }
                else
                {
                    lblCowCount.Visible = false;
                    txtCowCount.Visible = false;
                    txtCowCount.Text = "0";
                }

            }


            if (ddlLoanPurpose.Items[nValu].Text == "Feeding the Cattle")
            {
                if (ddlLoanPurpose.Items[nValu].Selected == true)
                {
                    txtCowCount1.Visible = true;
                    lblCowCount1.Visible = true;
                    if (txtCowCount1.Text == "" || txtCowCount1.Text == "0")
                    {
                        txtCowCount1.Text = "1";
                    }
                }
                else
                {
                    lblCowCount1.Visible = false;
                    txtCowCount1.Visible = false;
                    txtCowCount1.Text = "0";
                }

            }

            if (ddlLoanPurpose.Items[nValu].Text == "Building the Cattle Shed")
            {
                if (ddlLoanPurpose.Items[nValu].Selected == true)
                {
                    lblCowCountBuild.Visible = true;
                    txtCowCOuntBuild.Visible = true;
                    if (txtCowCOuntBuild.Text == "" || txtCowCOuntBuild.Text == "0")
                    {
                        txtCowCOuntBuild.Text = "1";
                    }
                }
                else
                {
                    lblCowCountBuild.Visible = false;
                    txtCowCOuntBuild.Visible = false;
                    txtCowCOuntBuild.Text = "0";

                }
            }


            if (ddlLoanPurpose.Items[nValu].Text == "Purchase of Buffalo")
            {
                if (ddlLoanPurpose.Items[nValu].Selected == true)
                {


                    lblBuffaloCount.Visible = true;
                    txtBuffaloCount.Visible = true;
                    if (txtBuffaloCount.Text == "" || txtBuffaloCount.Text == "0")
                        txtBuffaloCount.Text = "1";
                }
                else
                {
                    lblBuffaloCount.Visible = false;
                    txtBuffaloCount.Visible = false;
                    txtBuffaloCount.Text = "0";

                }
            }

        }
    }
    //Bala changes starts 11/10/2016
    protected void ddlCustProfile_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            bindFarmerActivity();

            BIndLLProcess();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    //bala changes ends 11/10/2016
    protected void rbtnAgriHoldingSts_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (rbtnAgriHoldingSts.SelectedValue == "Y")
            {
                dvLease.Visible = false;
                txtLeaseLandholding.Enabled = false;
                dvLand.Visible = true;
                txtAgriLnadholding.Enabled = true;
                //txtLeaseLandholding.Enabled = false;
                // txtAgriLnadholding.Enabled = true;
            }
            else
                if (rbtnAgriHoldingSts.SelectedValue == "N")
                {
                    // txtAgriLnadholding.Enabled = false;
                    dvLease.Visible = true;
                    txtLeaseLandholding.Enabled = true;
                    dvLand.Visible = false;
                    txtAgriLnadholding.Enabled = false;
                }
                else
                {
                    txtLeaseLandholding.Enabled = true;
                    txtAgriLnadholding.Enabled = true;
                    dvLease.Visible = true;
                    dvLand.Visible = true;
                }
            Clear();
            ViewState["CurrentTable"] = null;


            gvIncomeDetail.DataSource = null;
            gvIncomeDetail.DataBind();
            FirstGridViewRow();
            txtTotalLoanEligibility.Text = "";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}