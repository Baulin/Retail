﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Web.Services;
using System.Web.UI.WebControls.WebParts;
using Tracker;
using Utilities.Enums;

public partial class Branch_PDCompletion : System.Web.UI.Page
{
    int rsnid;
    string orcdt;
    string currentdt;
    string[] leadno;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    ClsCommon clscommon = new ClsCommon();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UNITNAME"] != null)
            {
                txtBranch.Text = Session["UNITNAME"].ToString();
                bindArea();
                bind();
                End_use();
            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        ddlProduct.SelectedIndex = 0;

    }

    protected void ddlbranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlProduct.SelectedIndex = 0;
        ddlst_EmpCode.SelectedIndex = 0;
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        SqlCommand cmddd1 = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con);
        cmddd1.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da2 = new SqlDataAdapter(cmddd1);
        DataSet ds2 = new DataSet();
        da2.Fill(ds2);

        SqlCommand cmddd3 = new SqlCommand("RTS_SP_Fetch_MR_REASON", con);
        cmddd3.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da3 = new SqlDataAdapter(cmddd3);
        DataSet ds3 = new DataSet();
        da3.Fill(ds3);

        SqlCommand sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_DDL_MENU, con);
        sqlCmd.CommandType = CommandType.StoredProcedure;
        SqlParameter paramItemGroup = new SqlParameter(AppConstants.Param_Item_Group, "DIRECTION");
        SqlParameter paramItemSubGroup = new SqlParameter(AppConstants.Param_Item_SubGroup, "");
        sqlCmd.Parameters.Add(paramItemGroup);
        sqlCmd.Parameters.Add(paramItemSubGroup);
        SqlDataAdapter sqlDtAdptr = new SqlDataAdapter(sqlCmd);
        DataSet dsDirection = new DataSet();
        sqlDtAdptr.Fill(dsDirection);
        con.Close();

        //if (ds1.Tables[0].Rows.Count != 0)
        //{

        //}
        //if (ds2.Tables[0].Rows.Count != 0)
        //{
        //DataTable dtProduct = ds2.Tables[0];
        //if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        //{
        //    dtProduct = ds2.Tables[0].Select("PR_CODE not like '%BL%'").CopyToDataTable();
        //}
        DataTable dtProduct = ds2.Tables[0];
        if (Session["BRTYPE"].ToString() == "V" && Session["USR_ACS"].ToString() == "7")
        {
            // dtProduct = ds2.Tables[0].Select("PR_CODE  LIKE  '%BL%'").CopyToDataTable();
            dtProduct = ds2.Tables[0].Select("PR_ID IN (9,10,11,15,16,22,23,28,31)").CopyToDataTable();
        }
        else if (Session["BRTYPE"].ToString() == "R" && Session["USR_ACS"].ToString() == "7")
        {
            // dtProduct = ds2.Tables[0].Select("PR_CODE NOT LIKE  '%BL%'").CopyToDataTable();
            dtProduct = ds2.Tables[0].Select("PR_ID NOT IN (9,10,11,15,16,22,23,28,31)").CopyToDataTable();
        }

        ddlProduct.DataSource = dtProduct;
        ddlProduct.DataTextField = "PR_CODE";
        ddlProduct.DataValueField = "PR_ID";
        ddlProduct.DataBind();
        ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));
        // }
        //if (ds3.Tables[0].Rows.Count != 0)
        //{
        ddlReason.DataSource = ds3;
        ddlReason.DataTextField = "RSN_REASON";
        ddlReason.DataValueField = "RSN_ID";
        ddlReason.DataBind();
        ddlReason.Items.Insert(0, new ListItem("--Select--", "0"));
        //}

        if (dsDirection != null && dsDirection.Tables.Count > 0 && dsDirection.Tables[0].Rows.Count > 0)
        {
            ddlLatDirBp.DataSource = dsDirection;
            ddlLatDirBp.DataValueField = AppConstants.Col_ITEM_KEY;
            ddlLatDirBp.DataTextField = AppConstants.Col_ITEM_DESC;
            ddlLatDirBp.DataBind();
            ddlLatDirBp.Items.Insert(0, new ListItem("--Select--", "0"));

            ddlLongDirBp.DataSource = dsDirection;
            ddlLongDirBp.DataValueField = AppConstants.Col_ITEM_KEY;
            ddlLongDirBp.DataTextField = AppConstants.Col_ITEM_DESC;
            ddlLongDirBp.DataBind();
            ddlLongDirBp.Items.Insert(0, new ListItem("--Select--", "0"));

            ddlLatDirRp.DataSource = dsDirection;
            ddlLatDirRp.DataValueField = AppConstants.Col_ITEM_KEY;
            ddlLatDirRp.DataTextField = AppConstants.Col_ITEM_DESC;
            ddlLatDirRp.DataBind();
            ddlLatDirRp.Items.Insert(0, new ListItem("--Select--", "0"));

            ddlLongDirRp.DataSource = dsDirection;
            ddlLongDirRp.DataValueField = AppConstants.Col_ITEM_KEY;
            ddlLongDirRp.DataTextField = AppConstants.Col_ITEM_DESC;
            ddlLongDirRp.DataBind();
            ddlLongDirRp.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (ddlPDstatus.SelectedValue.ToString() == "Rejected")
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            if (ddlReason.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                //SqlCommand cmdrsn = new SqlCommand("select RSN_ID from MR_REASON where RSN_REASON='" + ddlReason.SelectedValue.ToString() + "'", con);
                //SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
                //DataSet dsrsn = new DataSet();
                //darsn.Fill(dsrsn);
                rsnid = Convert.ToInt32(ddlReason.SelectedValue.ToString());
                Session["rsnid"] = rsnid;
                txtLoanamt.Text = "NULL";
            }
            con.Close();
        }
        if (txt_pd_dt.Text == "")
        {
            uscMsgBox1.AddMessage("Please Select Date from Picker", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            if (ddlProduct.SelectedValue == "12" && Convert.ToDouble(txtLoanamt.Text) > 200000)
            {
                txtLoanamt.Focus();
                uscMsgBox1.AddMessage("The Loan amount should not greater than 200000", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if ((ddlProduct.SelectedValue == "13" || ddlProduct.SelectedValue == "14" || ddlProduct.SelectedValue == "29") && Convert.ToDouble(txtLoanamt.Text) > 500000)
            {
                txtLoanamt.Focus();
                uscMsgBox1.AddMessage("The Loan amount should not greater than 500000", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                //string value = Request.Form["Datepick"];
                string value = txt_pd_dt.Text;
                //DateTime dob = DateTime.Parse(Request.Form[FindControl("txtDate").UniqueID]);
                orcdt = txtLeaddt.Text;
                System.Globalization.DateTimeFormatInfo dateInfo = new System.Globalization.DateTimeFormatInfo();
                dateInfo.ShortDatePattern = "yyyy/MM/dd";
                System.Globalization.DateTimeFormatInfo recInfo = new System.Globalization.DateTimeFormatInfo();
                dateInfo.ShortDatePattern = "yyyy/MM/dd";
                System.Globalization.DateTimeFormatInfo curdt = new System.Globalization.DateTimeFormatInfo();
                dateInfo.ShortDatePattern = "yyyy/MM/dd";

                currentdt = String.Format("{0:dd MMM yyyy}", dt);

                DateTime validDate = Convert.ToDateTime(value, dateInfo);
                DateTime receiveddt = Convert.ToDateTime(orcdt, recInfo);
                DateTime currdt = Convert.ToDateTime(currentdt, curdt);
                if (receiveddt <= validDate && validDate <= currdt)
                {
                    if (ddlPDstatus.SelectedValue.ToString() == "Recommended" && txtLoanamt.Text == "")
                    {
                        uscMsgBox1.AddMessage("Please Enter Loan Amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlPDstatus.SelectedValue.ToString() == "Rejected" && txtRemarks.Text == "" && ddlProduct.SelectedItem.Text == "--Select--")
                    {
                        uscMsgBox1.AddMessage("Please Enter Remarks and Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlPDstatus.SelectedValue.ToString() == "Rejected" && txtRemarks.Text == "")
                    {
                        uscMsgBox1.AddMessage("Please Enter Remarks", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlPDstatus.SelectedValue.ToString() == "Rejected" && ddlProduct.SelectedItem.Text == "--Select--")
                    {
                        uscMsgBox1.AddMessage("Please Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtResidenceAddr1.Text == "")
                    {
                        txtResidenceAddr1.Focus();
                        uscMsgBox1.AddMessage("Please Enter Resident Address1", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtResidenceAddr2.Text == "")
                    {
                        txtResidenceAddr2.Focus();
                        uscMsgBox1.AddMessage("Please Enter Resident Address2", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtResidence_city.Text == "")
                    {
                        txtResidence_city.Focus();
                        uscMsgBox1.AddMessage("Please Enter City Name", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtPropAddr_pincode.Text == "")
                    {
                        txtPropAddr_pincode.Focus();
                        uscMsgBox1.AddMessage("Please Enter Pin Code", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtPropAddr1.Text == "")
                    {
                        txtPropAddr1.Focus();
                        uscMsgBox1.AddMessage("Please Enter Property Address", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                    else if (txtPropAddr2.Text == "")
                    {
                        txtPropAddr2.Focus();
                        uscMsgBox1.AddMessage("Please Enter Property Address", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtPropAddr_city.Text == "")
                    {
                        txtPropAddr_city.Focus();
                        uscMsgBox1.AddMessage("Please Enter City Name", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtPropAddr_pincode.Text == "")
                    {
                        txtPropAddr_pincode.Focus();
                        uscMsgBox1.AddMessage("Please Enter Pin Code No", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    //else if (txtEnduser.Text == "")
                    //{
                    //    txtEnduser.Focus();
                    //    uscMsgBox1.AddMessage("Please Enter End Use", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    //}
                    else if (ddlst_EmpCode.SelectedValue == "" && ddlPDstatus.SelectedValue.ToString() == "Recommended"
                                              && ddlProduct.SelectedItem.Text.Contains("E-") == false && ddlProduct.SelectedItem.Text.Contains("G-") == false)
                    {
                        uscMsgBox1.AddMessage("Please Select the Employee", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    //  else if (ddl_Enduse.SelectedValue == "0" && ddlProduct.SelectedItem.Text != "MSE" && ddlProduct.SelectedItem.Text != "ASL" && ddlProduct.SelectedItem.Text != "ADFL")
                    else if (ddl_Enduse.SelectedValue == "0" && ddlProduct.SelectedValue != "12" && ddlProduct.SelectedValue != "13" && ddlProduct.SelectedValue != "14" && ddlProduct.SelectedValue != "29")
                    {
                        ddl_Enduse.Focus();
                        uscMsgBox1.AddMessage("Please Enter End Use", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    // else if (ddlProduct.SelectedItem.Text == "TWL" && Convert.ToDouble(txtLoanamt.Text) > 60000)
                    else if (ddlProduct.SelectedValue == "8" && Convert.ToDouble(txtLoanamt.Text) > 60000)
                    {
                        uscMsgBox1.AddMessage("Loan amount should be less than or equal to 60000", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        txtLoanamt.Focus();
                    }
                    else if (ddlLatDirBp.SelectedIndex == 0 || ddlLongDirBp.SelectedIndex == 0)
                    {
                        uscMsgBox1.AddMessage("Please provide Latitude/Longtitude direction for Business Premises", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlLatDirRp.SelectedIndex == 0 || ddlLongDirRp.SelectedIndex == 0)
                    {
                        uscMsgBox1.AddMessage("Please provide Latitude/Longtitude direction for Residence Premises", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtBxLandMarkBp.Text == "" || txtBxLandMarkRp.Text == "")
                    {
                        uscMsgBox1.AddMessage("Please provide Landmark details for Business/Residence Premises", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else
                    {
                        SqlConnection con = new SqlConnection(strcon);
                        try
                        {
                            con.Open();

                            SqlCommand cmd = new SqlCommand("RTS_SP_Update_LSD_LEAD", con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@PDstatus", SqlDbType.Int).Value = ddlPDstatus.SelectedIndex;
                            cmd.Parameters.Add("@LD_PD_DATE", SqlDbType.DateTime).Value = validDate;
                            cmd.Parameters.Add("@LD_PD_STAT", SqlDbType.Int).Value = ddlPDstatus.SelectedIndex;

                            cmd.Parameters.Add("@LD_PD_AMT", SqlDbType.VarChar).Value = txtLoanamt.Text.Trim();
                            cmd.Parameters.Add("@LD_PD_MBY", SqlDbType.VarChar).Value = Session["ID"] != null ? Session["ID"].ToString() : "";
                            cmd.Parameters.Add("@LD_NO", SqlDbType.VarChar).Value = Session["leadid"] != null ? Session["leadid"].ToString() : "";
                            if (Session["rsnid"].ToString() != "NULL")
                            {
                                cmd.Parameters.Add("@LD_PD_RSN_ID", SqlDbType.Int).Value = Convert.ToInt32(Session["rsnid"]);
                            }
                            else
                            {
                                cmd.Parameters.Add("@LD_PD_RSN_ID", SqlDbType.Int).Value = 0;
                            }
                            // cmd.Parameters.Add("@LD_PD_USE", SqlDbType.VarChar).Value = txtEnduser.Text.Trim();
                            if (ddl_Enduse.SelectedItem.Text == "Others")
                            {
                                string pduse = ddl_Enduse.SelectedItem.Text + "," + txt_enduse1.Text.Trim();
                                cmd.Parameters.Add("@LD_PD_USE", SqlDbType.VarChar).Value = pduse;
                            }
                            else
                            {
                                cmd.Parameters.Add("@LD_PD_USE", SqlDbType.VarChar).Value = ddl_Enduse.SelectedItem.Text.Trim();
                            }
                            cmd.Parameters.Add("@LD_PD_EMP_ID", SqlDbType.Int).Value = ddlst_EmpCode.SelectedItem.Text != "--Select--" ? Convert.ToInt32(ddlst_EmpCode.SelectedValue) : 0;
                            cmd.Parameters.Add("@LD_PD_RMK", SqlDbType.VarChar).Value = txtRemarks.Text.Trim();
                            //senthil changes 22-12-2015
                            cmd.Parameters.Add("@LD_ADDRESS", SqlDbType.VarChar).Value = txtPropAddr1.Text.Trim();
                            cmd.Parameters.Add("@LD_ADDRESS1", SqlDbType.VarChar).Value = txtPropAddr2.Text.Trim();
                            cmd.Parameters.Add("@LD_CITY", SqlDbType.VarChar).Value = txtPropAddr_city.Text.Trim();
                            cmd.Parameters.Add("@LD_PINCODE", SqlDbType.VarChar).Value = txtPropAddr_pincode.Text.Trim();

                            cmd.Parameters.Add("@LD_RADDRESS", SqlDbType.VarChar).Value = txtResidenceAddr1.Text.Trim();
                            cmd.Parameters.Add("@LD_RADDRESS1", SqlDbType.VarChar).Value = txtResidenceAddr2.Text.Trim();
                            cmd.Parameters.Add("@LD_RCITY", SqlDbType.VarChar).Value = txtResidence_city.Text.Trim();
                            cmd.Parameters.Add("@LD_RPINCODE", SqlDbType.VarChar).Value = txt_pincode1.Text.Trim();
                            SqlDataAdapter showdata = new SqlDataAdapter(cmd);
                            DataSet ds = new DataSet();
                            showdata.Fill(ds);

                            string cmdText = "SELECT LD_ID FROM LSD_LEAD WHERE LD_NO = @LeadNo";
                            cmd = new SqlCommand(cmdText, con);
                            SqlParameter leadNo = new SqlParameter("@LeadNo", Session["leadid"] != null ? Session["leadid"].ToString() : "");
                            cmd.Parameters.Add(leadNo);
                            Int64 leadId = Convert.ToInt64(cmd.ExecuteScalar());

                            cmd = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_PREMISES_LOCATION, con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@PL_LD_ID", SqlDbType.Int).Value = leadId;
                            cmd.Parameters.Add("@PL_TYPE", SqlDbType.VarChar).Value = EnumUtils.GetEnumValue(PremisesType.BusinessPremises);
                            cmd.Parameters.Add("@PL_LAT", SqlDbType.Decimal).Value = Convert.ToDouble(txtBxLatBp.Text);
                            cmd.Parameters.Add("@PL_LAT_DIR", SqlDbType.VarChar).Value = ddlLatDirBp.SelectedItem.Text;
                            cmd.Parameters.Add("@PL_LONG", SqlDbType.Decimal).Value = Convert.ToDouble(txtBxLongBp.Text);
                            cmd.Parameters.Add("@PL_LONG_DIR", SqlDbType.VarChar).Value = ddlLongDirBp.SelectedItem.Text;
                            cmd.Parameters.Add("@PL_LANDMARK", SqlDbType.VarChar).Value = txtBxLandMarkBp.Text.Trim();

                            SqlParameter bpResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                            bpResult.Direction = ParameterDirection.Output;
                            cmd.Parameters.Add(bpResult);

                            SqlDataAdapter sqlDtAdptr = new SqlDataAdapter(cmd);
                            DataSet dsBusinessPremises = new DataSet();
                            sqlDtAdptr.Fill(dsBusinessPremises);
                            bool bpTransactionResult = Convert.ToBoolean(bpResult.Value);

                            cmd = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_PREMISES_LOCATION, con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@PL_LD_ID", SqlDbType.Int).Value = leadId;
                            cmd.Parameters.Add("@PL_TYPE", SqlDbType.VarChar).Value = EnumUtils.GetEnumValue(PremisesType.ResidencePremises);
                            cmd.Parameters.Add("@PL_LAT", SqlDbType.Decimal).Value = Convert.ToDouble(txtBxLatRp.Text);
                            cmd.Parameters.Add("@PL_LAT_DIR", SqlDbType.VarChar).Value = ddlLatDirRp.SelectedItem.Text;
                            cmd.Parameters.Add("@PL_LONG", SqlDbType.Decimal).Value = Convert.ToDouble(txtBxLongRp.Text);
                            cmd.Parameters.Add("@PL_LONG_DIR", SqlDbType.VarChar).Value = ddlLongDirRp.SelectedItem.Text;
                            cmd.Parameters.Add("@PL_LANDMARK", SqlDbType.VarChar).Value = txtBxLandMarkRp.Text.Trim();

                            SqlParameter rpResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                            rpResult.Direction = ParameterDirection.Output;
                            cmd.Parameters.Add(rpResult);

                            sqlDtAdptr = new SqlDataAdapter(cmd);
                            DataSet dsResidencePremises = new DataSet();
                            sqlDtAdptr.Fill(dsResidencePremises);
                            bool rpTransactionResult = Convert.ToBoolean(rpResult.Value);

                            if (ds != null && bpTransactionResult && rpTransactionResult)
                            {
                                bind();
                                txt_pd_dt.Text = "";
                                txtLoanamt.Text = "";
                                txtRemarks.Text = "";
                                btnSubmit.Enabled = false;
                                if (ddlPDstatus.SelectedIndex == 1)
                                {
                                    uscMsgBox1.AddMessage("PD Completed Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                                    clear();
                                }
                                else
                                {
                                    uscMsgBox1.AddMessage("PD Rejected Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                                }
                            }



                        }
                        catch (Exception ex)
                        {
                            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            ErrorLog.WriteError(ex);
                        }
                        finally
                        {
                            con.Close();
                        }
                    }
                }

                else
                {
                    uscMsgBox1.AddMessage("Please Select valid PD Date from Datepicker", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

            }
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_PDCompletion.aspx");
    }
    protected void ddlProduct_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            if (ddlProduct.SelectedIndex != 0)
            {
                ddlLeadno.Enabled = true;

                SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Product_Details", con);
                cmddd.CommandType = CommandType.StoredProcedure;
                //bala changes 24/02/2016
                // cmddd.Parameters.Add("@BR_NAME", SqlDbType.VarChar).Value = txtBranch.Text.Trim();
                cmddd.Parameters.Add("@BR_NAME", SqlDbType.VarChar).Value = ddlBranch.SelectedItem.Text.ToUpper().Trim();
                //cmddd.Parameters.Add("@PR_CODE", SqlDbType.VarChar).Value = ddlProduct.SelectedItem.ToString();
                cmddd.Parameters.Add("@PR_ID", SqlDbType.VarChar).Value = ddlProduct.SelectedValue.ToString();
                SqlDataAdapter da1 = new SqlDataAdapter(cmddd);
                DataSet ds1 = new DataSet();
                da1.Fill(ds1);
                con.Close();
                ddlLeadno.DataSource = ds1;
                ddlLeadno.DataTextField = "LEAD";
                ddlLeadno.DataValueField = "LEAD";
                ddlLeadno.DataBind();
                ddlLeadno.Items.Insert(0, new ListItem("--Select--", "0"));
                txt_pd_dt.Text = DateTime.Now.ToString("MM/dd/yyyy");

                //SET DEFAULT value for EndUse When Product is MERCHANT OD
                if (ddlProduct.SelectedItem.Text == "Merchant OD")
                {
                    ddl_Enduse.ClearSelection();
                    ddl_Enduse.Items.FindByValue("Working capital requirement").Selected = true;
                    ddl_Enduse.Enabled = false;
                }
            }
            else
            {
                ddlLeadno.SelectedIndex = 0;
                ddlLeadno.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlPDstatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlPDstatus.SelectedValue.ToString() == "Recommended")
        {
            btnSubmit.Enabled = true;
            txtLoanamt.Enabled = true;
            ddlReason.Enabled = false;
            txtRemarks.Enabled = false;
            Session["rsnid"] = "NULL";

        }
        else if (ddlPDstatus.SelectedValue.ToString() == "Rejected")
        {
            btnSubmit.Enabled = true;
            txtLoanamt.Enabled = false;
            ddlReason.Enabled = true;
            txtRemarks.Enabled = true;
        }
    }
    protected void ddlLeadno_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            if (ddlLeadno.SelectedIndex != 0)
            {
                leadno = ddlLeadno.SelectedValue.ToString().Split('-');
                Session["leadid"] = leadno[0].ToString();
                SqlCommand cmddt = new SqlCommand("RTS_SP_Fetch_Lead_Details", con);
                cmddt.CommandType = CommandType.StoredProcedure;
                cmddt.Parameters.Add("@LD_NO", SqlDbType.VarChar).Value = Session["leadid"] != null ? Session["leadid"].ToString() : "";
                SqlDataAdapter dadt = new SqlDataAdapter(cmddt);
                DataSet dsdt = new DataSet();
                dadt.Fill(dsdt);
                DateTime leaddt = Convert.ToDateTime(dsdt.Tables[0].Rows[0]["LD_DATE"]);
                txtLeaddt.Text = String.Format("{0:dd MMM yyyy}", leaddt);
                ddlPDstatus.Enabled = true;
                if (ddlProduct.SelectedValue == "12" 
                    || ddlProduct.SelectedValue == "13" 
                    || ddlProduct.SelectedValue == "14" 
                    || ddlProduct.SelectedValue == "29"
                    || ddlProduct.SelectedValue == "48")
                {
                    ddl_Enduse.Enabled = false;
                }
                else
                {
                    ddl_Enduse.Enabled = true;
                }

                txtResidenceAddr1.Focus();
                bindPDEmployees();
            }
            else
            {
                clear();
                ddlPDstatus.Enabled = false;
                ddl_Enduse.Enabled = false;
                ddlst_EmpCode.SelectedIndex = 0;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    //senthil
    //28-08-2015
    protected void End_use()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_MR_ENDUSE", con);

        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@EU_PRD_TYPE", "R");
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddl_Enduse.DataSource = dsdd;
        ddl_Enduse.DataTextField = "EU_DESC";
        ddl_Enduse.DataValueField = "EU_DESC";
        ddl_Enduse.DataBind();
        ddl_Enduse.Items.Insert(0, new ListItem("--Select--", "0"));

    }

    protected void clear()
    {
        txt_pd_dt.Text = "";
        txtLoanamt.Text = "";
        txtPropAddr1.Text = "";
        txtRemarks.Text = "";
        ddl_Enduse.SelectedIndex = 0;
        ddlPDstatus.SelectedIndex = 0;
        ddlProduct.SelectedIndex = 0;
        ddlLeadno.SelectedIndex = 0;
        txtResidenceAddr1.Text = "";
        txtResidenceAddr2.Text = "";
        txtResidence_city.Text = "";
        txt_pincode1.Text = "";
        txtPropAddr1.Text = "";
        txtPropAddr2.Text = "";
        txtPropAddr_city.Text = "";
        txtPropAddr_pincode.Text = "";
        txt_enduse1.Text = "";
        ddlst_EmpCode.SelectedIndex = 0;
        txtDesignation.Text = "";
        txtBxLatBp.Text = "";
        txtBxLongBp.Text = "";
        txtBxLatRp.Text = "";
        txtBxLongRp.Text = "";
        ddlLatDirBp.SelectedIndex = 0;
        ddlLongDirBp.SelectedIndex = 0;
        ddlLatDirRp.SelectedIndex = 0;
        ddlLongDirRp.SelectedIndex = 0;
        txtBxLandMarkBp.Text = "";
        txtBxLandMarkRp.Text = "";
    }
    protected void ddl_Enduse_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddl_Enduse.SelectedItem.Text.Trim() == "Others")
        {
            txt_enduse1.Visible = true;
        }
        else
        {
            txt_enduse1.Visible = false;
        }
    }

    protected void txtLoanamt_TextChanged(object sender, EventArgs e)
    {
        try
        {
            /* bALA CHANGES 31/03/2018
             * 
             * string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
             SqlConnection con = new SqlConnection(strcon);
             con.Open();
             SqlCommand cmd_Obj = new SqlCommand("RTS_SP_FETCH_ACM_ALLOC_USERS", con);
             cmd_Obj.CommandType = CommandType.StoredProcedure;
             // Bala changes 24/02/2016
             //cmd_Obj.Parameters.AddWithValue("@AREAID", Convert.ToString(Session["AREA_ID"]) != "" ? Convert.ToString(Session["AREA_ID"]) : null);
             //cmd_Obj.Parameters.AddWithValue("@BRANCHID", Convert.ToString(Session["BRANCHID"]) != "" ? Convert.ToString(Session["BRANCHID"]) : null);
             cmd_Obj.Parameters.AddWithValue("@AREAID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue : null);
             cmd_Obj.Parameters.AddWithValue("@BRANCHID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue : null);
             string prod = string.Empty;
           //  if (ddlProduct.SelectedValue == "MF-HF" || ddlProduct.SelectedItem.Text == "G-HF")
             if (ddlProduct.SelectedValue == "3" || ddlProduct.SelectedValue == "4")
                 prod = "G";
             else
                 prod = "";
             cmd_Obj.Parameters.AddWithValue("@PTYPE", prod);
             cmd_Obj.Parameters.AddWithValue("@Amount", txtLoanamt.Text.ToString() != "" ? txtLoanamt.Text.ToString() : "0");
             DataTable dtEmp = new DataTable();
             dtEmp.Load(cmd_Obj.ExecuteReader());
             ViewState["Employee"] = dtEmp;
             ddlst_EmpCode.DataSource = dtEmp;
             ddlst_EmpCode.DataTextField = "EMP_NAME";
             ddlst_EmpCode.DataValueField = "EMP_ID";
             ddlst_EmpCode.DataBind();
             ddlst_EmpCode.Items.Insert(0, new ListItem("--Select--", "0"));
             * */
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void bindPDEmployees()
    {
        try
        {


            DataTable dtEmp = new DataTable();
            dtEmp = clscommon.Bind_PD_Employees(Session["leadid"].ToString()).Tables[0];
            ViewState["Employee"] = dtEmp;
            ddlst_EmpCode.DataSource = dtEmp;
            ddlst_EmpCode.DataTextField = "EMP_NAME";
            ddlst_EmpCode.DataValueField = "EMP_ID";
            ddlst_EmpCode.DataBind();
            ddlst_EmpCode.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlst_EmpCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataTable dt = (DataTable)ViewState["Employee"];
            DataTable dtDesg = dt.Select("EMP_ID =" + ddlst_EmpCode.SelectedValue).CopyToDataTable();
            txtDesignation.Text = Convert.ToString(dtDesg.Rows[0]["ET_DESC"]);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}