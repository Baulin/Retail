﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_Area : System.Web.UI.Page
{
    int stid;
    int divid = 0;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
            bindDivision();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("SELECT ST_NAME,ST_ID FROM MR_STATE", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmddd);
            DataSet ds2 = new DataSet();
            da1.Fill(ds2);
            con.Close();
            ddlState.DataSource = ds2;
            ddlState.DataTextField = "ST_NAME";
            ddlState.DataValueField = "ST_ID";
            ddlState.DataBind();
            ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmd = new SqlCommand("select A.AR_CODE 'AREA CODE',A.AR_NAME 'AREA NAME',B.ST_NAME 'STATE' from MR_AREA A JOIN MR_STATE B ON A.AR_ST_ID=B.ST_ID", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvArea.DataSource = ds;
        gvArea.DataBind();
        if (gvArea.Rows.Count > 0)
        {
            gvArea.HeaderRow.Font.Bold = true;
            gvArea.HeaderRow.Cells[0].Text = "AREA CODE";
            gvArea.HeaderRow.Cells[1].Text = "AREA NAME";
            gvArea.HeaderRow.Cells[2].Text = "STATE";            

            gvArea.HeaderRow.Cells[0].Wrap = false;
            gvArea.HeaderRow.Cells[1].Wrap = false;
            gvArea.HeaderRow.Cells[2].Wrap = false;            
        }
    }
    protected void bindDivision()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("SELECT DV_ID,DV_NAME FROM MR_DIVISION", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmddd);
            DataSet ds2 = new DataSet();
            da1.Fill(ds2);
            con.Close();
            ddlDivision.DataSource = ds2;
            ddlDivision.DataTextField = "DV_NAME";
            ddlDivision.DataValueField = "DV_ID";
            ddlDivision.DataBind();
            ddlDivision.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {

            e.Row.Cells[0].Width = new Unit("125px");

            e.Row.Cells[1].Width = new Unit("265px");
            e.Row.Cells[2].Width = new Unit("263px");

        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[0].Width = new Unit("125px");

            e.Row.Cells[1].Width = new Unit("273px");
            e.Row.Cells[2].Width = new Unit("268px");

            if (e.Row.RowIndex == 0)
                e.Row.Style.Add("height", "50px");
            e.Row.VerticalAlign = VerticalAlign.Bottom;
        }
    }
       
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand stcmd = new SqlCommand("SELECT ST_ID FROM MR_STATE where ST_NAME='" + ddlState.SelectedValue.ToString() + "'", con);
            //SqlDataAdapter stda = new SqlDataAdapter(stcmd);
            //DataSet stds = new DataSet();
            //stda.Fill(stds);

            //stid = Convert.ToInt32(stds.Tables[0].Rows[0]["ST_ID"]);
            stid = Convert.ToInt32(ddlState.SelectedValue);
            divid = Convert.ToInt32(ddlDivision.SelectedValue);

            SqlCommand insertcmd = new SqlCommand("insert into MR_AREA values ('" + txtAreacode.Text + "','" + txtAreaname.Text + "','"+divid+"','" + stid + "','" + Session["ID"].ToString() + "',getdate(),'" + Session["ID"].ToString() + "',getdate())", con);
            insertcmd.ExecuteNonQuery();
            bind();
            txtAreacode.Text = "";
            txtAreaname.Text = "";            
            //ddlState.Text = "--Select--";
            uscMsgBox1.AddMessage("Area Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_Area.aspx");
    }
}