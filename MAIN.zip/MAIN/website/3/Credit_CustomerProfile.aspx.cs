﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Utilities;
using Tracker;

public partial class Credit_CustomerProfile : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    Customer_Profile ds = new Customer_Profile();
    string leadno;
    DataSet dsc = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session[AppConstants.ID] != null)
            {
                CustProfKey.Value = AppConstants.CustProfile + Session[AppConstants.ID].ToString() + Guid.NewGuid().ToString();
                //if(ViewState[CustProfKey.Value] != null) { ViewState.Remove(CustProfKey.Value); }

                txtdate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();

            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
    }

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        SqlCommand cmdrsn = new SqlCommand("RTS_SP_Fetch_MR_REASON", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);

        SqlCommand cmdcus = new SqlCommand("SP_CREDIT_CUSTOMER_PROFILE", con);
        cmdcus.CommandType = CommandType.StoredProcedure;
        cmdcus.Parameters.AddWithValue("@TYPE", 3);
        SqlDataAdapter dacus = new SqlDataAdapter(cmdcus);
        DataSet dscus = new DataSet();
        dacus.Fill(dscus);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlcustprofile.DataSource = dscus.Tables[0];
        ddlcustprofile.DataTextField = "PRF_DESC";
        ddlcustprofile.DataValueField = "PRF_ID";
        ddlcustprofile.DataBind();
        ddlcustprofile.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlempcategory.DataSource = dscus.Tables[1];
        ddlempcategory.DataTextField = "EMP_CT_DESC";
        ddlempcategory.DataValueField = "EMP_CT_ID";
        ddlempcategory.DataBind();
        ddlempcategory.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlsegment.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlsubcategory.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlempindustry.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_NAME";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Enabled = false;
    }

    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Credit_Approval", con);
            SqlCommand cmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_CREDIT_CUSTOMER_PROFILE, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            if (ddlArea.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@AR_NAME", "");
            }
            if (ddlBranch.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@BR_NAME", "");
            }

            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "C");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvApprv.Visible = true;
                gvApprv.DataSource = ds1.Tables[0];
                gvApprv.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    //gvApprv.HeaderRow.Font.Bold = true;
                    //gvApprv.HeaderRow.Cells[1].Text = "LEAD NO";
                    //gvApprv.HeaderRow.Cells[2].Text = "LEAD DATE";
                    //gvApprv.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    //gvApprv.HeaderRow.Cells[4].Text = "PD DATE";
                    //gvApprv.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                    gvApprv.HeaderRow.Cells[1].Wrap = false;
                    gvApprv.HeaderRow.Cells[2].Wrap = false;
                    gvApprv.HeaderRow.Cells[3].Wrap = false;
                    gvApprv.HeaderRow.Cells[4].Wrap = false;
                    gvApprv.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvApprv.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                //Session["View"] = "All";
                // gridbindall();
                uscMsgBox1.AddMessage("Please select Area.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                ddlArea.Enabled = false;
                //   gridbind();
            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";
                // gridbind();
            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                // gridbind();
            }
            BindqueryGrid();
            Panel1.Visible = false;
            Clear();
            foreach (GridViewRow grow in gvApprv.Rows)
            {
                Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                int index = grow.RowIndex;
                if (lblQryResult.Text == "T")
                {
                    gvApprv.Rows[index].Cells[1].ForeColor = Color.Red;
                    gvApprv.Rows[index].Cells[2].ForeColor = Color.Red;
                    gvApprv.Rows[index].Cells[3].ForeColor = Color.Red;
                    gvApprv.Rows[index].Cells[4].ForeColor = Color.Red;
                    gvApprv.Rows[index].Cells[5].ForeColor = Color.Red;
                }

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {

        }
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            Label lblLeadID = null;

            foreach (GridViewRow grow in gvApprv.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    lblLeadID = (Label)gvApprv.Rows[index].Cells[1].FindControl("lblLeadID");
                    leadno = gvApprv.Rows[index].Cells[1].Text;
                    con.Open();
                    Session["Lead_id"] = lblLeadID.Text;
                    SqlCommand cmd = new SqlCommand("SP_CREDIT_CUSTOMER_PROFILE", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@LD_ID", lblLeadID.Text);
                    cmd.Parameters.AddWithValue("@TYPE", 1);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);

                    da.Fill(dsc);

                    ddlname.DataSource = dsc.Tables[1];
                    ddlname.DataTextField = "KYC_NAME";
                    ddlname.DataValueField = "KYC_ID";
                    ddlname.DataBind();
                    ddlname.Items.Insert(0, new ListItem("--Select--", "0"));

                    gvcusprofile.DataSource = dsc.Tables[0];
                    gvcusprofile.DataBind();
                    Customer_Profile dsgr = new Customer_Profile();
                    dsgr.Tables[0].Merge(dsc.Tables[0]);

                    ViewState[CustProfKey.Value] = dsgr;

                    if (dsc != null && dsc.Tables[0].Rows.Count > 0)
                    {
                        if (dsc.Tables[0].Rows[0]["NO_OF_INCM"] != "")
                        {
                            txtnoofincome.Text = Convert.ToString(dsc.Tables[0].Rows[0]["NO_OF_INCM"]);
                        }
                        else
                        {
                            txtnoofincome.Text = "";
                        }
                        if (dsc.Tables[0].Rows[0]["REMARKS"] != "")
                        {
                            txtremarks.Text = Convert.ToString(dsc.Tables[0].Rows[0]["REMARKS"]);
                        }
                        else
                        {
                            txtremarks.Text = "";
                        }
                    }
                    else
                    {
                        txtnoofincome.Text = "";
                        txtremarks.Text = "";
                    }

                    Panel1.Visible = true;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtnoofincome != null && txtnoofincome.Text != "" && (int.Parse(txtnoofincome.Text) - 1 < gvcusprofile.Rows.Count))
            {
                uscMsgBox1.AddMessage("No of Income and no of customer profile should be Match.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlcustprofile.SelectedIndex == 0 || ddlname.SelectedIndex == 0)
            {
                uscMsgBox1.AddMessage("Please select Name/cusomer profile", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (txtnoofincome.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter the NO OF INCOME", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            else
            {
                Customer_Profile ds1 = new Customer_Profile();
                ds1 = (Customer_Profile)ViewState[CustProfKey.Value];

                DataRow dr = ds.Tables[0].NewRow();
                dr["NAME"] = ddlname.SelectedItem.Text;
                dr["APP_TYPE"] = txtapplicanttyp.Text;
                dr["CUST_PROFILE"] = ddlcustprofile.SelectedItem.Text;
                dr["CUST_PRF_ID"] = ddlcustprofile.SelectedItem.Value;
                if (ddlsegment.SelectedIndex != 0)
                {
                    dr["SEGMENT"] = ddlsegment.SelectedItem.Text;
                    dr["SEG_ID"] = ddlsegment.SelectedItem.Value;
                }
                else
                {
                    dr["SEGMENT"] = DBNull.Value;
                    dr["SEG_ID"] = DBNull.Value;
                }
                if (ddlsubcategory.SelectedIndex != 0)
                {
                    dr["SUBCATEGORY"] = ddlsubcategory.SelectedItem.Text;
                    dr["SUB_CTRY_ID"] = ddlsubcategory.SelectedItem.Value;
                }
                else
                {
                    dr["SUBCATEGORY"] = DBNull.Value;
                    dr["SUB_CTRY_ID"] = DBNull.Value;
                }
                if (ddlempcategory.SelectedIndex != 0)
                {
                    dr["EMPCATEGORY"] = ddlempcategory.SelectedItem.Text;
                    //dr["EMP_CTRY_ID"] = ddlempcategory.SelectedItem.Value;
                }
                else
                {
                    dr["EMPCATEGORY"] = DBNull.Value;
                    dr["EMP_CTRY_ID"] = DBNull.Value;
                }
                if (ddlempindustry.SelectedIndex != 0)
                {
                    dr["EMPINDUSTRY"] = ddlempindustry.SelectedItem.Text;
                    dr["EMP_indus_ID"] = ddlempindustry.SelectedItem.Value;
                }
                else
                {
                    dr["EMPINDUSTRY"] = DBNull.Value;
                    dr["EMP_indus_ID"] = DBNull.Value;
                }

                dr["LD_ID"] = Convert.ToString(Session["Lead_id"]);
                dr["NO_OF_INCM"] = txtnoofincome.Text;
                dr["REMARKS"] = txtremarks.Text;

                if (ds1 != null && ds1.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dra in ds1.Tables[0].Rows)
                    {
                        dra["NO_OF_INCM"] = txtnoofincome.Text;
                        dra["REMARKS"] = txtremarks.Text;
                    }

                    ds1.Tables[0].Rows.Add(dr.ItemArray);
                    ViewState[CustProfKey.Value] = ds1;

                    gvcusprofile.DataSource = ds1.Tables[0];
                    gvcusprofile.DataBind();
                }
                else
                {
                    ds.Tables[0].Rows.Add(dr.ItemArray);
                    ViewState[CustProfKey.Value] = ds;

                    gvcusprofile.DataSource = ds.Tables[0];
                    gvcusprofile.DataBind();
                }

                btnSubmit.Enabled = true;
                btnCancel.Enabled = true;

                ddlname.SelectedIndex = 0;
                txtapplicanttyp.Text = "";
                ddlcustprofile.SelectedIndex = 0;
                ddlsegment.SelectedIndex = 0;
                ddlsubcategory.SelectedIndex = 0;
                ddlempcategory.SelectedIndex = 0;
                ddlempindustry.SelectedIndex = 0;
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {

        }
    }

    protected void gvcusprofile_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string item = e.Row.Cells[0].Text;
            foreach (Button button in e.Row.Cells[8].Controls.OfType<Button>())
            {
                if (button.CommandName == "Delete")
                {
                    button.Attributes["onclick"] = "if(!confirm('Do you want to delete " + item + "?')){ return false; };";
                }
            }
        }
    }

    protected void gvcusprofile_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int index = Convert.ToInt32(e.RowIndex);
        DataSet dsd = (DataSet)ViewState[CustProfKey.Value];

        if (dsd != null)
        {
            dsd.Tables[0].Rows[index].Delete();
            ViewState[CustProfKey.Value] = dsd;

            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;
            gvcusprofile.DataSource = dsd.Tables[0];
            gvcusprofile.DataBind();
        }

    }

    protected void ddlname_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmd = new SqlCommand("SP_CREDIT_CUSTOMER_PROFILE", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@KYC_ID", ddlname.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@TYPE", 2);
            txtapplicanttyp.Text = Convert.ToString(cmd.ExecuteScalar());
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void ddlcustprofile_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmdcus = new SqlCommand("SP_CREDIT_CUSTOMER_PROFILE", con);
            cmdcus.CommandType = CommandType.StoredProcedure;
            cmdcus.Parameters.AddWithValue("@SU_PRF_ID", ddlcustprofile.SelectedItem.Value);
            cmdcus.Parameters.AddWithValue("@TYPE", 4);
            SqlDataAdapter dacus = new SqlDataAdapter(cmdcus);
            DataSet dscus = new DataSet();
            dacus.Fill(dscus);
            ddlsegment.Items.Clear();
            ddlsegment.DataSource = dscus;
            ddlsegment.DataTextField = "SG_DESG";
            ddlsegment.DataValueField = "SG_ID";
            ddlsegment.DataBind();
            ddlsegment.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void ddlsegment_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmdcus = new SqlCommand("SP_CREDIT_CUSTOMER_PROFILE", con);
            cmdcus.CommandType = CommandType.StoredProcedure;
            cmdcus.Parameters.AddWithValue("@SU_PRF_ID", ddlcustprofile.SelectedItem.Value);
            cmdcus.Parameters.AddWithValue("@SU_SEG_ID", ddlsegment.SelectedItem.Value);
            cmdcus.Parameters.AddWithValue("@TYPE", 5);
            SqlDataAdapter dacus = new SqlDataAdapter(cmdcus);
            DataSet dscus = new DataSet();
            dacus.Fill(dscus);
            ddlsubcategory.Items.Clear();
            ddlsubcategory.DataSource = dscus;
            ddlsubcategory.DataTextField = "SU_DESC";
            ddlsubcategory.DataValueField = "SU_ID";
            ddlsubcategory.DataBind();
            ddlsubcategory.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void ddlempcategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmdcus = new SqlCommand("SP_CREDIT_CUSTOMER_PROFILE", con);
            cmdcus.CommandType = CommandType.StoredProcedure;
            cmdcus.Parameters.AddWithValue("@EMP_CT_ID", ddlempcategory.SelectedItem.Value);
            cmdcus.Parameters.AddWithValue("@TYPE", 6);
            SqlDataAdapter dacus = new SqlDataAdapter(cmdcus);
            DataSet dscus = new DataSet();
            dacus.Fill(dscus);
            ddlempindustry.Items.Clear();
            ddlempindustry.DataSource = dscus;
            ddlempindustry.DataTextField = "EMP_CT_IND";
            ddlempindustry.DataValueField = "EMP_CT_ID";
            ddlempindustry.DataBind();
            ddlempindustry.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            if (int.Parse(txtnoofincome.Text) == gvcusprofile.Rows.Count)
            {
                DataSet dsins = (DataSet)ViewState[CustProfKey.Value];

                if(dsins != null && dsins.Tables.Count > 0)
                {
                    #region PROFILE ITERATION
                    foreach (DataRow dr in dsins.Tables[0].Rows)
                    {
                        if (dr.RowState == DataRowState.Added)
                        {
                            SqlCommand cmdinsert = new SqlCommand("RTS_INSERT_CUS_PROFILE", con);
                            cmdinsert.CommandType = CommandType.StoredProcedure;
                            cmdinsert.Parameters.AddWithValue("@LD_ID", dr["LD_ID"].ToString());
                            cmdinsert.Parameters.AddWithValue("@NO_OF_INCM", dr["NO_OF_INCM"].ToString());
                            cmdinsert.Parameters.AddWithValue("@NAME", dr["NAME"].ToString());
                            cmdinsert.Parameters.AddWithValue("@APP_TYPE", dr["APP_TYPE"].ToString());
                            cmdinsert.Parameters.AddWithValue("@CUST_PRF_ID", dr["CUST_PRF_ID"].ToString());
                            cmdinsert.Parameters.AddWithValue("@SEG_ID", dr["SEG_ID"].ToString());
                            cmdinsert.Parameters.AddWithValue("@SUB_CTRY_ID", dr["SUB_CTRY_ID"].ToString());
                            cmdinsert.Parameters.AddWithValue("@EMP_CTRY_ID", dr["EMP_INDUS_ID"].ToString());
                            cmdinsert.Parameters.AddWithValue("@EMP_INDUS_ID", dr["EMP_INDUS_ID"].ToString());
                            if (dr["REMARKS"].ToString() != "")
                            {
                                cmdinsert.Parameters.AddWithValue("@REMARKS", dr["REMARKS"].ToString());
                            }
                            else
                            {
                                cmdinsert.Parameters.AddWithValue("@REMARKS", txtremarks.Text);
                            }
                            cmdinsert.Parameters.AddWithValue("@CP_CBY", Session["ID"].ToString());
                            cmdinsert.Parameters.AddWithValue("@TYPE", 1);
                            cmdinsert.ExecuteNonQuery();
                        }

                        if (dr.RowState == DataRowState.Deleted)
                        {
                            string CP_PRF_ID = dr["CP_PRF_ID", DataRowVersion.Original].ToString();
                            SqlCommand cmddelete = new SqlCommand("RTS_INSERT_CUS_PROFILE", con);
                            cmddelete.CommandType = CommandType.StoredProcedure;
                            cmddelete.Parameters.AddWithValue("@CP_PRF_ID", CP_PRF_ID);
                            cmddelete.Parameters.AddWithValue("@TYPE", 2);
                            cmddelete.ExecuteNonQuery();
                        }

                        if (dr.RowState == DataRowState.Unchanged)
                        {
                            if (txtnoofincome.Text != dr["NO_OF_INCM"].ToString())
                            {
                                SqlCommand cmdupdate = new SqlCommand("RTS_INSERT_CUS_PROFILE", con);
                                cmdupdate.CommandType = CommandType.StoredProcedure;
                                cmdupdate.Parameters.AddWithValue("@NO_OF_INCM", txtnoofincome.Text);
                                cmdupdate.Parameters.AddWithValue("@REMARKS", txtremarks.Text);
                                cmdupdate.Parameters.AddWithValue("@CP_PRF_ID", dr["CP_PRF_ID"].ToString());
                                cmdupdate.Parameters.AddWithValue("@CP_CBY", Session["ID"].ToString());
                                cmdupdate.Parameters.AddWithValue("@TYPE", 3);
                                cmdupdate.ExecuteNonQuery();

                            }
                        }

                    }
                    #endregion
                    uscMsgBox1.AddMessage("Profile/s created sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
                else
                {
                    uscMsgBox1.AddMessage("Profile/s creation failed. Please refresh the page and try again.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }

                Clear();
                ViewState.Remove(CustProfKey.Value);

                gvcusprofile.DataSource = ds;
                gvcusprofile.DataBind();
            }
            else
            {
                uscMsgBox1.AddMessage("No of Income and no of customer profile should be Match.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
    }

    protected void Clear()
    {
        txtnoofincome.Text = "";

        if (ddlname != null && ddlname.SelectedIndex != -1)
        {
            ddlname.SelectedIndex = 0;
        }

        txtapplicanttyp.Text = "";

        if (ddlcustprofile != null && ddlcustprofile.SelectedIndex != -1)
        {
            ddlcustprofile.SelectedIndex = 0;
        }

        if (ddlsegment != null && ddlsegment.SelectedIndex != -1)
        {
            ddlsegment.SelectedIndex = 0;
        }

        if (ddlsubcategory != null && ddlsubcategory.SelectedIndex != -1)
        {
            ddlsubcategory.SelectedIndex = 0;
        }

        if (ddlempcategory != null && ddlempcategory.SelectedIndex != -1)
        {
            ddlempcategory.SelectedIndex = 0;
        }

        if (ddlempindustry != null && ddlempindustry.SelectedIndex != -1)
        {
            ddlempindustry.SelectedIndex = 0;
        }

        txtremarks.Text = "";
        btnSubmit.Enabled = false;
        btnCancel.Enabled = false;
    }
}