﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Utilities;
using Tracker;

public partial class Credit_PDoc_Entry : System.Web.UI.Page
{
    string leadno;
    static string previousval;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    DataSet dss = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                bind();
            }
            else
            {
                Response.Redirect("expire.aspx");
            }
        }
    }

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        SqlCommand cmdc = new SqlCommand("RTS_SP_FETCH_MR_CDOCUMENT", con);
        SqlDataAdapter dac = new SqlDataAdapter(cmdc);
        DataSet dsc = new DataSet();
        dac.Fill(dsc);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlDocType.DataSource = dsc;
        ddlDocType.DataTextField = "MDT_DESC";
        ddlDocType.DataValueField = "MDT_ID";
        ddlDocType.DataBind();
        ddlDocType.Items.Insert(0, new ListItem("--Select--", "0"));


    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtLeadNo.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                //Session["View"] = "All";
                uscMsgBox1.AddMessage("Please select Area.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else if (txtLeadNo.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                ddlArea.Enabled = false;

            }
            else if (txtLeadNo.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";

            }
            else if (txtLeadNo.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";

            }
            BindqueryGrid();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Credit", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadNo.Text);
            if (ddlArea.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@AR_NAME", "");
            }
            if (ddlBranch.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@BR_NAME", "");
            }

            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "C");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvApprv.Visible = true;
                gvApprv.DataSource = ds1.Tables[0];
                gvApprv.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvApprv.HeaderRow.Font.Bold = true;
                    gvApprv.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvApprv.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvApprv.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    gvApprv.HeaderRow.Cells[4].Text = "LOAN AMOUNT";

                    gvApprv.HeaderRow.Cells[1].Wrap = false;
                    gvApprv.HeaderRow.Cells[2].Wrap = false;
                    gvApprv.HeaderRow.Cells[3].Wrap = false;
                    gvApprv.HeaderRow.Cells[4].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvApprv.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_NAME";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadNo.Enabled = false;
    }

    protected void gvApprv_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }


    public void gridbind(string leadid)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_CREDIT_DOC", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CDX_LD_ID", leadid);
            cmd.Parameters.AddWithValue("@TYPE", "BIND");
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dss);

            grvdoc.DataSource = dss.Tables[0];
            grvdoc.DataBind();


        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void rbc_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            Label lblCDocID = null;

            foreach (GridViewRow growdoc in grvdoc.Rows)
            {
                RadioButton chkStat = growdoc.FindControl("rbc_select") as RadioButton;

                int index = growdoc.RowIndex;
                if (chkStat.Checked)
                {
                    lblCDocID = (Label)grvdoc.Rows[index].Cells[1].FindControl("lblCDocID");

                    con.Open();

                    SqlCommand cmd = new SqlCommand("RTS_SP_CREDIT_DOC", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@CDX_ID", lblCDocID.Text);
                    cmd.Parameters.AddWithValue("@TYPE", "DXBIND");
                    SqlDataAdapter da = new SqlDataAdapter(cmd);

                    Session["PDOC_CDX_ID"] = lblCDocID.Text;

                    da.Fill(ds);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtpattano.Text = Convert.ToString(ds.Tables[0].Rows[0]["CDX_PATTA"]);
                        txttotalextent.Text = Convert.ToString(ds.Tables[0].Rows[0]["CDX_EXTENT"]);
                        txtproownernam.Text = Convert.ToString(ds.Tables[0].Rows[0]["CDX_POWNR"]);
                        txtdocno.Text = Convert.ToString(ds.Tables[0].Rows[0]["CDX_NO"]);
                        //ddlDocType.SelectedValue= Convert.ToString(ds.Tables[0].Rows[0]["CDX_MDT_ID"]); 
                        if (ddlDocType.Items.FindByValue(Convert.ToString(ds.Tables[0].Rows[0]["CDX_MDT_ID"])) != null)
                        {
                            ddlDocType.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["CDX_MDT_ID"]);
                            previousval = Convert.ToString(ds.Tables[0].Rows[0]["CDX_MDT_ID"]);
                        }
                        else
                        {
                            ddlDocType.SelectedIndex = 0;
                        }
                        if (ddlst_ptype.Items.FindByValue(Convert.ToString(ds.Tables[0].Rows[0]["CDX_PTYPE"])) != null)
                        {
                            ddlst_ptype.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["CDX_PTYPE"]);

                        }
                        else
                        {
                            ddlst_ptype.SelectedIndex = 0;
                        }

                    }
                    btn_delete.Enabled = true;
                    btnSubmit.Text = "Update";
                    break;
                }


            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }

    }

    protected void grvdoc_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (btnSubmit.Text == "Submit")
            Insert_Update("INSERT");
        else
            Insert_Update("UPDATE");
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            clear();
            previousval = "";
            grCreditDoc.Visible = false;
            trCreditDoc.Visible = false;
            trsubmit.Visible = false;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void clear()
    {
        txtpattano.Text = "";
        txttotalextent.Text = "";
        txtproownernam.Text = "";
        ddlDocType.SelectedIndex = 0;
        txtdocno.Text = "";
        ddlst_ptype.SelectedIndex = 0;
    }



    protected void btn_delete_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            SqlCommand cmdinsert = new SqlCommand("RTS_SP_CREDIT_DOC", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;

            cmdinsert.Parameters.AddWithValue("@CDX_ID", Convert.ToString(Session["PDOC_CDX_ID"]));



            cmdinsert.Parameters.AddWithValue("@TYPE", "DELETE");
            int r = cmdinsert.ExecuteNonQuery();

            gridbind(Convert.ToString(Session["LeadId"]));
            if (r > 0)
            {

                clear();
                uscMsgBox1.AddMessage("Records deleted Sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                return;
            }
            else
            {
                uscMsgBox1.AddMessage("Records not deleted", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void Insert_Update(string psval)

    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            if (txtpattano.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter the Patta Number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else if (txttotalextent.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter the extent Number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else if (txtproownernam.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter theProperty Owner Name", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else if (ddlDocType.SelectedIndex == 0)
            {
                uscMsgBox1.AddMessage("Please select the Document Type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else if (txtdocno.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter the Document Number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else if (ddlst_ptype.SelectedItem.Text == "--Select--")
            {

                uscMsgBox1.AddMessage("Please select the Property Type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }

            else
            {


                SqlCommand cmdinsert = new SqlCommand("RTS_SP_CREDIT_DOC", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                
                cmdinsert.Parameters.AddWithValue("@CDX_PATTA", txtpattano.Text.Trim());
                cmdinsert.Parameters.AddWithValue("@CDX_EXTENT", txttotalextent.Text.Trim());

                cmdinsert.Parameters.AddWithValue("@CDX_CBY", Session["ID"]);
                cmdinsert.Parameters.AddWithValue("@CDX_MDT_ID", ddlDocType.SelectedItem.Value);
                cmdinsert.Parameters.AddWithValue("@CDX_POWNR", txtproownernam.Text);
                cmdinsert.Parameters.AddWithValue("@CDX_NO", txtdocno.Text);

                cmdinsert.Parameters.AddWithValue("@CDX_PTYPE", ddlst_ptype.SelectedValue);

                cmdinsert.Parameters.AddWithValue("@TYPE", psval);
                if(psval=="UPDATE")
                    cmdinsert.Parameters.AddWithValue("@CDX_ID", Convert.ToString(Session["PDOC_CDX_ID"]));
                else
                    cmdinsert.Parameters.AddWithValue("@CDX_LD_ID", Session["LeadId"]);
                int r = cmdinsert.ExecuteNonQuery();
                gridbind(Convert.ToString(Session["LeadId"]));
                if (r > 0)
                {
                    btn_delete.Enabled = false;
                    if (psval == "UPDATE")
                        btnSubmit.Text = "Submit";
                    clear();
                    uscMsgBox1.AddMessage("Records Saved Sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    return;
                }
                else
                {
                    uscMsgBox1.AddMessage("Records not Saved .", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
            }

        }
        catch (Exception ex)
        {

            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            trCreditDoc.Visible = true;
            trsubmit.Visible = true;

            Label lblLeadID = null;

            foreach (GridViewRow grow in gvApprv.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;

                //LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {

                    lblLeadID = (Label)gvApprv.Rows[index].Cells[1].FindControl("lblLeadID");

                    Label lblPRId = grow.FindControl("lblPRId") as Label;
                    leadno = gvApprv.Rows[index].Cells[1].Text;

                    Session["LeadId"] = lblLeadID.Text;
                    Session["Leadno"] = leadno;
                    lblleadNO.Text = leadno;

                    btnSubmit.Enabled = true;
                    btnCancel.Enabled = true;
                    grCreditDoc.Visible = true;
                    gridbind(lblLeadID.Text);
                    break;

                }
            }

            clear();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
}