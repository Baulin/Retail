﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using Tracker;
public partial class BC_Verification_Report : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    string ldid = "";
    ClsCommon clscomman = new ClsCommon();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnPrint);
        scriptManager.RegisterPostBackControl(this.btnSubmit);
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
              
            }
            else
            {
                Response.Redirect("expire.aspx", false);
            }
        }
    }
   
   
  
   
   
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try { 
        if (txtbxleadno.Text != "")
        {

            //System.Data.DataTable dt = new System.Data.DataTable();

            //DataTable vst = (DataTable)ViewState["SampLDNO"];

            //var res = from rw in vst.AsEnumerable()
            //          where rw.Field<string>("LD_NO").Equals(txtbxleadno.Text)
            //          select rw;

            //if (res.Count() > 0)
            //{
                //dt = res.CopyToDataTable();
              //  ldid = dt.Rows[0]["LD_ID"] != DBNull.Value ? dt.Rows[0]["LD_ID"].ToString() : "";
              ds = clscomman.Get_BC_Details_ByBCACODE(txtbxleadno.Text);
             
                if (ds.Tables[0].Rows.Count == 0)
                {
                   // ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('You have entered BC Code doesn't exist in the system.');", true);
                    uscMsgBox1.AddMessage("You have entered Connectors Code verification pending or doesn't exist in the system.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                
                }
                else
                {
                   
                   
                           

                            if (ds.Tables[0].Rows.Count > 0 )
                            {
                tblHead.Visible = true;
                tblBody.Visible = true;
              //  tblReport.Visible = true;
               // tblFIleCredit.Visible = true;

               // grdKYC.Visible = true;
               
                //BindDedupe();
                GenerateReport();
                             }
                         

                        }
                       
            //}
            //else
            //{
            //    tblHead.Visible = false;
            //    tblReport.Visible = false;
            //    tblFIleCredit.Visible = false;
            //    grdKYC.Visible = false;
            //    gv_Dedupe.Visible = false;
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
        }
        else
        {
              uscMsgBox1.AddMessage("Please enter Connector number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention); 
        }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
       
    }

    public void GenerateReport()
    {
        try
        {
            //SqlConnection con = new SqlConnection(strcon);
            //con.Open();
            //SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAMSummary_Report", con);
            //cmddd.Parameters.AddWithValue("@Lead_ID", ldid);
         
            //cmddd.CommandType = CommandType.StoredProcedure;
            //SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            //DataSet dsdd = new DataSet();
            //dadd.Fill(dsdd);
            DataSet dsdd = new DataSet();
            dsdd = clscomman.Get_BC_Details_ByBCACODE(txtbxleadno.Text);


            if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
            {
                // Search creteria
                //lblHeadBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                lblState.Text = dsdd.Tables[0].Rows[0]["ST_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ST_NAME"].ToString() : "";
                lblDivision.Text = dsdd.Tables[0].Rows[0]["DV_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["DV_NAME"].ToString() : "";
                lblArea.Text = dsdd.Tables[0].Rows[0]["AR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["AR_NAME"].ToString() : "";
                lblBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                lblBCRefCode.Text = dsdd.Tables[0].Rows[0]["BCA_CODE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_CODE"].ToString() : "";
                lblCreatedDate.Text = dsdd.Tables[0].Rows[0]["BCA_CDATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["BCA_CDATE"]).ToString("dd/MM/yyyy") : "";

                lblVerifierName.Text = dsdd.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
                lblVerifierCode.Text = dsdd.Tables[0].Rows[0]["EMP_CODE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_CODE"].ToString() : "";
                lblVerifiedDate.Text = dsdd.Tables[0].Rows[0]["BCA_VDATE"] != DBNull.Value ? Convert.ToDateTime( dsdd.Tables[0].Rows[0]["BCA_VDATE"]).ToString("dd/MM/yyyy") : "";



                string strAddress = "";

                //lblFullName.Text = dsdd.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
                lblFullName.Text = dsdd.Tables[0].Rows[0]["BCA_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_NAME"].ToString() : "";
                lblFatherHusbandText.Text = dsdd.Tables[0].Rows[0]["BCA_FHNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_FHNAME"].ToString() : "";
                strAddress += dsdd.Tables[0].Rows[0]["BCA_PA_DNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_PA_DNO"].ToString() + "," : "";
                strAddress += ((dsdd.Tables[0].Rows[0]["BCA_PA_LOC"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_PA_LOC"] != "") ? dsdd.Tables[0].Rows[0]["BCA_PA_LOC"].ToString() + ",<br/>" : "");
                strAddress += ((dsdd.Tables[0].Rows[0]["BCA_PA_PO"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_PA_PO"] != "") ? dsdd.Tables[0].Rows[0]["BCA_PA_PO"].ToString() + ",<br/>" : "");
                strAddress += ((dsdd.Tables[0].Rows[0]["BCA_PA_TALUK"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_PA_TALUK"] != "") ? dsdd.Tables[0].Rows[0]["BCA_PA_TALUK"].ToString() + ",<br/>" : "");
                strAddress += ((dsdd.Tables[0].Rows[0]["BCA_PA_DIST"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_PA_DIST"] != "") ? dsdd.Tables[0].Rows[0]["BCA_PA_DIST"].ToString() + ",<br/>" : "");
                strAddress += (dsdd.Tables[0].Rows[0]["BCA_PA_STATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_PA_STATE"].ToString() + ".<br/>" : "");
                strAddress += (dsdd.Tables[0].Rows[0]["BCA_PA_PINCODE"] != DBNull.Value ? "Pincode - " + dsdd.Tables[0].Rows[0]["BCA_PA_PINCODE"].ToString() + "" : "");
                lblAddress.Text = strAddress;
                lblResidencePhNo.Text = ((dsdd.Tables[0].Rows[0]["BCA_RES_PHNO"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_RES_PHNO"] != "") ? dsdd.Tables[0].Rows[0]["BCA_RES_PHNO"].ToString() : "Nil");
                lblOfficePhNo.Text = ((dsdd.Tables[0].Rows[0]["BCA_OFF_PHNO"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_OFF_PHNO"] != "") ? dsdd.Tables[0].Rows[0]["BCA_OFF_PHNO"].ToString() : "Nil");
                lblMobilePhNo.Text = ((dsdd.Tables[0].Rows[0]["BCA_MBL_NO"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_MBL_NO"] != "") ? dsdd.Tables[0].Rows[0]["BCA_MBL_NO"].ToString() : "Nil");
                lblRationCardNumber.Text = (dsdd.Tables[0].Rows[0]["BCA_RC_No"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_RC_No"] != "") ? dsdd.Tables[0].Rows[0]["BCA_RC_No"].ToString() : "Nil";
                lblAadharNo.Text = (dsdd.Tables[0].Rows[0]["BCA_AC_No"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_AC_No"] != "") ? dsdd.Tables[0].Rows[0]["BCA_AC_No"].ToString() : "Nil";
                lblVoterIDNo.Text = (dsdd.Tables[0].Rows[0]["BCA_VI_No"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_VI_No"] != "") ? dsdd.Tables[0].Rows[0]["BCA_VI_No"].ToString() : "Nil";
                lblPassportNo.Text = (dsdd.Tables[0].Rows[0]["BCA_PP_No"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_PP_No"] != "") ? dsdd.Tables[0].Rows[0]["BCA_PP_No"].ToString() : "Nil";
                lblPANCardNumber.Text = (dsdd.Tables[0].Rows[0]["BCA_PC_No"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_PC_No"] != "") ? dsdd.Tables[0].Rows[0]["BCA_PC_No"].ToString() : "Nil";
                lblDLNo.Text = (dsdd.Tables[0].Rows[0]["BCA_DL_No"] != DBNull.Value) && (dsdd.Tables[0].Rows[0]["BCA_DL_No"] != "") ? dsdd.Tables[0].Rows[0]["BCA_DL_No"].ToString() : "Nil";
                lblDOB.Text = dsdd.Tables[0].Rows[0]["BCA_DOB"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["BCA_DOB"]).ToString("dd/MMM/yyyy") : "";
                lblEducation.Text = dsdd.Tables[0].Rows[0]["BCA_DL_No"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_DL_No"].ToString() : "Nil";
                lblEducation.Text = dsdd.Tables[0].Rows[0]["BCA_EDUCATION"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_EDUCATION"].ToString() : "Nil";
                lblOccupation.Text = dsdd.Tables[0].Rows[0]["BCA_OCCUPATION"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_OCCUPATION"].ToString() : "Nil";
                lblIncomePerMonth.Text = dsdd.Tables[0].Rows[0]["BCA_MON_INC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_MON_INC"].ToString() : "Nil";
                lblLanguagesKnown.Text = dsdd.Tables[0].Rows[0]["BCA_LANG_KNW"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_LANG_KNW"].ToString() : "Nil";
                lblStayingStability.Text = dsdd.Tables[0].Rows[0]["BCA_YRS_STAY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_YRS_STAY"].ToString() : "Nil";
               // lblPoliceRecordStatus.Text = dsdd.Tables[0].Rows[0]["BCA_POLICE_REC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_POLICE_REC"].ToString() : "Nil";
                lblReferenceStatus.Text = dsdd.Tables[0].Rows[0]["BCA_REF1_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_REF1_NAME"].ToString() : "Nil";
                lblPropertyStatus.Text = dsdd.Tables[0].Rows[0]["BCA_OWN_PROP"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BCA_OWN_PROP"].ToString() : "Nil";

               
                   // rbFullName.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_NAME"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_NAME"]).ToString()=="1")
                {
                    lblVBCFullNameYes.Text = "Yes";
                 
                }
                else
                {
                 
                    lblVBCFullNameYes.Text = "No";
                 
                }
                 //   rbFatherHusbandName.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_FHNAME"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_FHNAME"]).ToString() == "1")
                    {
                    
                        lblFatherHusbandNameYes.Text = "Yes";
                       
                    }
                    else
                    {
                        lblFatherHusbandNameYes.Text = "No";
                   
                    }
                   // rblDOB.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_DOB"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_DOB"]).ToString() == "1")
                {
                    lblrblDOBYes.Text = "Yes";
                }
                else
                {
                    lblrblDOBYes.Text = "No";
                }
                   // rblEducation.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_EDUCATION"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_EDUCATION"]).ToString() == "1")
                {
                    lblrblEducationYes.Text = "Yes";
                }
                else
                {
                    lblrblEducationYes.Text = "No";
                }
                   // rblAddress.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_ADDRESS"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_ADDRESS"]).ToString() == "1")
                {

                    lblrblAddressYes.Text = "Yes";
                  
                }
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_ADDRESS"]).ToString() == "0")
               
                {
                    lblrblAddressYes.Text = "No";
                }
                  //  rblPropertyStatus.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_OWN_PROP"]).ToString();
                    if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_OWN_PROP"]).ToString() == "1")
                    {
                        lblrblPropertyStatusYes.Text = "Yes";
                    }
                    else
                    {
                        lblrblPropertyStatusYes.Text = "No";
                    }
                  //  rblStayingStablility.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_YRS_STAY"]).ToString();
                    if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_YRS_STAY"]).ToString() == "1")
                    {
                        lblrblStayingStablilityYes.Text = "Yes";
                    }
                    else
                    {
                        lblrblStayingStablilityYes.Text = "No";
                    }
                   // rbResidencePhNo.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_RES_PHNO"]).ToString();
                    if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_RES_PHNO"]).ToString() == "1")
                    {
                        lblrbResidencePhNoYes.Text = "Yes";
                    }
                    else
                    {
                        lblrbResidencePhNoYes.Text = "No";
                    }
                    //rbOfficePhNo.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_OFF_PHNO"]).ToString();
                    if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_OFF_PHNO"]).ToString() == "1")
                    {
                        lblrbOfficePhNoYes.Text = "Yes";
                    }
                    else
                    {
                        lblrbOfficePhNoYes.Text = "No";
                    }
                 //   rbMobileNo.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_MBL_NO"]).ToString();
                    if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_MBL_NO"]).ToString() == "1")
                    {
                        lblrbMobileNoYes.Text = "Yes";
                    }
                    else
                    {
                        lblrbMobileNoYes.Text = "No";
                    }
                    //rblRCNo.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_RC_NO"]).ToString();
                    if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_RC_NO"]).ToString() == "1")
                    {
                        lblrblRCNoYes.Text = "Yes";
                    }
                    else
                    {
                        lblrblRCNoYes.Text = "No";
                    }
                   // rblACNo.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_AC_NO"]).ToString();
                    if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_AC_NO"]).ToString() == "1")
                    {
                        lblrblACNoYes.Text = "Yes";
                    }
                    else
                    {
                        lblrblACNoYes.Text = "No";
                    }
               // rblVINo.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_VI_NO"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_VI_NO"]).ToString() == "1")
                {
                    lblrblVINoYes.Text = "Yes";
                }
                else
                {
                    lblrblVINoYes.Text = "No";
                }
                   // rblPPNo.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_PP_NO"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_PP_NO"]).ToString() == "1")
                    {
                        lblrblPPNoYes.Text = "Yes";
                    }
                    else
                    {
                        lblrblPPNoYes.Text = "No";
                    }
                   // rblPCNo.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_PC_NO"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_PC_NO"]).ToString() == "1")
                {
                    lblrblPCNoYes.Text = "Yes";
                }
                else
                {
                    lblrblPCNoYes.Text = "No";
                }
                    //rblDLNo.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_DL_NO"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_PC_NO"]).ToString() == "1")
                {
                    lblrblDLNoYes.Text = "Yes";
                }
                else
                {
                    lblrblDLNoYes.Text = "No";
                }
                 //   rblOccupation.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_OCCUPATION"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_OCCUPATION"]).ToString() == "1")
                {
                    lblrblOccupationYes.Text = "Yes";
                }
                else
                {
                    lblrblOccupationYes.Text = "No";
                }
                 //   rblIncomePerMonth.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_MON_INC"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_MON_INC"]).ToString() == "1")
                    {
                        lblrblIncomePerMonthYes.Text = "Yes";
                    }
                    else
                    {
                        lblrblIncomePerMonthYes.Text = "No";
                    }
                  //  rblLanguagesKnown.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_LANG_KNW"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_LANG_KNW"]).ToString() == "1")
                {
                    lblrblLanguagesKnownYes.Text = "Yes";
                }
                else
                {
                    lblrblLanguagesKnownYes.Text = "No";
                }
                    // rblPoliceRecordStat.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_POLICE_REC"]).ToString();
                    //rblRefStatus.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_REF"]).ToString();
                if (Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_REF"]).ToString() == "1")
                {
                    lblrblRefStatusYes.Text = "Yes";
                }
                else
                {
                    lblrblRefStatusYes.Text = "No";
                }
                    //  rblPropertyStatus.SelectedValue = Convert.ToInt32(dsdd.Tables[0].Rows[0]["VBCA_REF"]).ToString();

                   // rbApplicationStatus.SelectedValue = dsdd.Tables[0].Rows[0]["BCA_APP_STAT"].ToString();
                if (dsdd.Tables[0].Rows[0]["BCA_APP_STAT"].ToString() == "Shortlisted")
                    {
                        lblrbApplicationStatusYes.Text = "Positive";
                    }
                    else
                    {
                        lblrbApplicationStatusYes.Text = "Negative";
                    }

                if (dsdd.Tables[0].Rows[0]["BCA_RISK_STAT_RSN"].ToString() != "0")
                {
                    txtRiskReason.Text = dsdd.Tables[0].Rows[0]["BCA_RISK_STAT_RSN"].ToString();
                }
                  //  ddlRiskStatus.SelectedValue = dsdd.Tables[0].Rows[0]["BCA_RISK_STAT_RSN"].ToString();
                    txtRiskOvlRmks.Text = dsdd.Tables[0].Rows[0]["BCA_RISK_OVAL_RMKS"].ToString();

                    txtFullNameRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_NAME_RMKS"].ToString();
                    txtFatherHusbandText.Text = dsdd.Tables[0].Rows[0]["VBCA_FHNAME_RMKS"].ToString();
                    txtAddressRemarks.Text = dsdd.Tables[0].Rows[0]["VBCA_ADDRESS_RMKS"].ToString();
                    txtResidencePhNoRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_RES_PHNO_RMKS"].ToString();
                    txtOfficePhNoRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_OFF_PHNO_RMKS"].ToString();
                    txtMobileNoRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_MBL_NO_RMKS"].ToString();
                    txtRationCardNumberRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_RC_NO_RMKS"].ToString();
                    txtAadharCardNumberRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_AC_NO_RMKS"].ToString();
                    txtVoterIDRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_VI_NO_RMKS"].ToString();
                    // txtVoterIDRmks.Text = dsdd.Tables[0].Rows[0]["BCA_RISK_OVAL_RMKS"].ToString();
                    txtPassportNoRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_PP_NO_RMKS"].ToString();
                    txtPANCardNumberRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_PC_NO_RMKS"].ToString();
                    txtDLNoRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_DL_NO_RMKS"].ToString();
                    txtDOBRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_DOB_RMKS"].ToString();
                    txtEducationRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_EDUCATION_RMKS"].ToString();
                    txtOccupationRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_OCCUPATION_RMKS"].ToString();
                    txtIncomePerMonthRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_MON_INC_RMKS"].ToString();
                    txtLanguageKnownRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_LANG_KNW_RMKS"].ToString();
                    txtStayingStabilityRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_YRS_STAY_RMKS"].ToString();
                    txtPropertyStatusRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_OWN_PROP_RMKS"].ToString();
                    txtReferenceStatusRmks.Text = dsdd.Tables[0].Rows[0]["VBCA_REF_RMKS"].ToString();

                }


                }

            
           
        

        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

 

    protected void btnPrint_Click(object sender, EventArgs e)
    {
        try
        {
            System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();

            img.ImageUrl = Server.MapPath("~/Images/JPG/MIFLogo.JPG");
            tdLogo.Controls.Add(img);

            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=BC_Verification_" + txtbxleadno.Text + ".pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            StringWriter sw0 = new StringWriter();
            HtmlTextWriter hw0 = new HtmlTextWriter(sw0);
            pnlHeader.RenderControl(hw0);

            //StringWriter sw = new StringWriter();
            //HtmlTextWriter hw = new HtmlTextWriter(sw);
            //pnlpdf.RenderControl(hw);

            //StringWriter sw1 = new StringWriter();
            //HtmlTextWriter hw1 = new HtmlTextWriter(sw1);
            //pnlpdf1.RenderControl(hw1);


            StringWriter sw2 = new StringWriter();
            HtmlTextWriter hw2 = new HtmlTextWriter(sw2);
            pnlpdf0.RenderControl(hw2);


            //StringWriter sw3 = new StringWriter();
            //HtmlTextWriter hw3 = new HtmlTextWriter(sw3);
            ////pnlKYC.RenderControl(hw3);
            //grdKYC.RenderControl(hw3);

            //StringWriter sw4 = new StringWriter();
            //HtmlTextWriter hw4 = new HtmlTextWriter(sw4);
            ////pnlKYC.RenderControl(hw3);
            //gv_Dedupe.RenderControl(hw4);



            //  StringReader sr = new StringReader(sw0.ToString() + "<br/>" + sw2.ToString() + " <br/><br/><br/><br/><br/><br/><br/><br/> " + sw.ToString() + "<br/><br/> <br/><br/><br/> <br/><br/> <br/> <br/><br/><br/> <br/><br/><br/> <br/><br/> <br/> <br/><br/><br/> <br/><br/><br/> <br/><br/>" + sw1.ToString());
            StringReader sr = new StringReader(sw0.ToString() + "<br/>" + sw2.ToString());
           /* StringReader sr1 = new StringReader(sw0.ToString() + "<br/>" + sw.ToString());
            StringReader sr2 = new StringReader(sw0.ToString() + "<br/>" + sw1.ToString());
            StringReader sr3 = new StringReader(sw0.ToString() + "<br/>" + sw3.ToString());
            StringReader sr4 = new StringReader(sw0.ToString() + "<br/>" + sw4.ToString());
            */
            Document pdfDoc = new Document(PageSize.A4, 10f, 13f, 10f, 1f);
            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.Open();

            pdfDoc.NewPage();
            pdfDoc.HtmlStyleClass = "PdfClass";
            htmlparser.Parse(sr);


            //pdfDoc.NewPage();
            //pdfDoc.HtmlStyleClass = "PdfClass";
            //htmlparser.Parse(sr1);

            //pdfDoc.NewPage();

            //pdfDoc.HtmlStyleClass = "PdfClass";
            //htmlparser.Parse(sr2);

            //pdfDoc.NewPage();


            //pdfDoc.HtmlStyleClass = "PdfClass";
            //htmlparser.Parse(sr3);
            //pdfDoc.NewPage();

            //pdfDoc.HtmlStyleClass = "PdfClass";
            //htmlparser.Parse(sr4);

            pdfDoc.Close();
            Response.Write(pdfDoc);
            Response.End();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }
  

}