﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;


public partial class Branch_RCA_FORM_RPT : System.Web.UI.Page
{
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {


                }
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }
    }

    public void bind()
    {
        DataSet dsdd = new DataSet();
        dsdd = clscommon.GetArea();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        string Areaname = ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "";
        DataSet dsrsn = new DataSet();
        dsrsn = clscommon.GetAreaWiseBranch(Areaname);
        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        ddlApplicantid.Items.Clear();
        ddlApplicantid.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));
        SetFocus(ddlBranch);
    }

    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataSet dsrsn = new DataSet();
        string Areaname = ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "";
        string Branchname = ddlBranch.SelectedItem.ToString() != "--Select--" ? ddlBranch.SelectedItem.ToString() : "";

        string BranchName = "";
        string ProductName = "";

        if (ddlTypeofaudit.SelectedItem.Text != "--Select--")
        {
            ProductName = ddlTypeofaudit.SelectedItem.Text;
        }

        if (ddlArea.SelectedItem.Text != "--Select--")
        {
            if (ddlBranch.SelectedItem.Text != "--Select--")
            {
                BranchName = Convert.ToString(ddlBranch.SelectedItem.Text);
                dsrsn = clscommon.GetBranchwiseRiskAuditLoan(BranchName, ProductName);
            }
        }
        ddlApplicantid.DataSource = dsrsn;
        ddlApplicantid.DataTextField = "LD_LOAN_NO";
        ddlApplicantid.DataValueField = "LD_LOAN_NO";
        ddlApplicantid.DataBind();
        ddlApplicantid.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));
        ddlApplicantid.Enabled = true;
        SetFocus(ddlApplicantid);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();

        img.ImageUrl = Server.MapPath("~/Images/JPG/MIFLogo.JPG");
        tdLogo.Controls.Add(img);
        
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=Credit_Memo_" + ddlApplicantid.SelectedItem.Text + ".pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        StringWriter sw0 = new StringWriter();
        HtmlTextWriter hw0 = new HtmlTextWriter(sw0);
        pnlHeader.RenderControl(hw0);

        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        pnlTable.RenderControl(hw);

        StringReader sr1 = new StringReader(sw0.ToString() + "<br/>" + sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        pdfDoc.NewPage();
        pdfDoc.HtmlStyleClass = "PdfClass";
        htmlparser.Parse(sr1);
        pdfDoc.NewPage();

        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();   
    
    }

    protected void ddlApplicantid_SelectedIndexChanged(object sender, EventArgs e)
    {
        string ApplicantID = ddlApplicantid.SelectedItem.Text != "--Select--" ? ddlApplicantid.SelectedItem.ToString() : "";
        DataTable dt = new DataTable();

        if (ApplicantID != "--Select--")
        {
            dt = clscommon.RTS_SP_GETLOANNOWISE_RCA(ApplicantID);
            if (dt.Rows.Count != 0)
            {
                txtApplicantname.Text = Convert.ToString(dt.Rows[0]["APPLICANT_NAME"].ToString());
                txtPhonenumber.Text = Convert.ToString(dt.Rows[0]["MOBNO"].ToString());
                txtLoandisburseddate.Text = Convert.ToString(dt.Rows[0]["DISBURSEMENT_DATE"].ToString());
                txtLoanamount.Text = Convert.ToString(dt.Rows[0]["DISBURSEMENT_AMOUNT"]);
                txtTotalloantenor.Text = Convert.ToString(dt.Rows[0]["LOAN_TENURE"]);
                txtInterestrate.Text = Convert.ToString(dt.Rows[0]["INTEREST_RATE"]);
                txtProcessingfee.Text = Convert.ToString(dt.Rows[0]["PROCESSING_FEE"]);
                txtAdminfee.Text = Convert.ToString(dt.Rows[0]["ADMIN_FEE"]);
                txtCreditlifeins.Text = Convert.ToString(dt.Rows[0]["CREDIT_LIFE_INS"]);
                txtPropertyins.Text = Convert.ToString(dt.Rows[0]["PROPERTY_INS"]);
                txtTechprocessingfee.Text = Convert.ToString(dt.Rows[0]["TECH_FEE"]);
                txtAddress.Text = Convert.ToString(dt.Rows[0]["APPLICANT_ADDRESS"].ToString());
                txtInstallmentduedate.Text = Convert.ToString(dt.Rows[0]["INSTALLMENT_DUE_DATE"].ToString());

                DataTable dtone = new DataTable();
                dtone = clscommon.RTS_SP_GETLOANNOWISE_RCA_RPT(ApplicantID);
                if (dtone.Rows.Count != 0)
                {
                    txtLoanamountdisbursed.Text = dtone.Rows[0]["QUESTION_1"] != DBNull.Value ? dtone.Rows[0]["QUESTION_1"].ToString() : "";
                    string chargesbef = dtone.Rows[0]["QUESTION_2"] != DBNull.Value ? dtone.Rows[0]["QUESTION_2"].ToString() : "";
                    if (chargesbef == "Yes")
                    {
                        rbChargesbefore.SelectedIndex = 0;
                    }  else { rbChargesbefore.SelectedIndex = 1; }
                    //rbChargesbefore.SelectedItem.Text = dtone.Rows[0]["QUESTION_2"] != DBNull.Value ? dtone.Rows[0]["QUESTION_2"].ToString() : "";

                    string Processingfeeconfirm = dtone.Rows[0]["QUESTION_3"] != DBNull.Value ? dtone.Rows[0]["QUESTION_3"].ToString() : "";
                    if (Processingfeeconfirm == "Yes")
                    {
                        rbProcessingfeeconfirm.SelectedIndex = 0;
                    }
                    else { rbProcessingfeeconfirm.SelectedIndex = 1; }
                    //rbProcessingfeeconfirm.SelectedItem.Text = dtone.Rows[0]["QUESTION_3"] != DBNull.Value ? dtone.Rows[0]["QUESTION_3"].ToString() : "";

                    string Anyonewithoutpay = dtone.Rows[0]["QUESTION_4"] != DBNull.Value ? dtone.Rows[0]["QUESTION_4"].ToString() : "";
                    if (Anyonewithoutpay == "Yes")
                    {
                        rbAnyonewithoutpay.SelectedIndex = 0;
                    }
                    else { rbAnyonewithoutpay.SelectedIndex = 1; }

                    //rbAnyonewithoutpay.SelectedItem.Text = dtone.Rows[0]["QUESTION_4"] != DBNull.Value ? dtone.Rows[0]["QUESTION_4"].ToString() : "";
                    
                    txtWithoutreceipt.Text = dtone.Rows[0]["QUESTION_5"] != DBNull.Value ? dtone.Rows[0]["QUESTION_5"].ToString() : "";

                    string Informedcreditconditionofloan = dtone.Rows[0]["QUESTION_6"] != DBNull.Value ? dtone.Rows[0]["QUESTION_6"].ToString() : "";
                    if (Informedcreditconditionofloan == "Yes")
                    {
                        rbInformedcreditconditionofloan.SelectedIndex = 0;
                    }
                    else { rbInformedcreditconditionofloan.SelectedIndex = 1; }
                   // rbInformedcreditconditionofloan.SelectedItem.Text = dtone.Rows[0]["QUESTION_6"] != DBNull.Value ? dtone.Rows[0]["QUESTION_6"].ToString() : "";

                    string Awareinstallmentduedate = dtone.Rows[0]["QUESTION_7"] != DBNull.Value ? dtone.Rows[0]["QUESTION_7"].ToString() : "";
                    if (Awareinstallmentduedate == "Yes")
                    {
                        rbAwareinstallmentduedate.SelectedIndex = 0;
                    }
                    else { rbAwareinstallmentduedate.SelectedIndex = 1; }
                    //rbAwareinstallmentduedate.SelectedItem.Text = dtone.Rows[0]["QUESTION_7"] != DBNull.Value ? dtone.Rows[0]["QUESTION_7"].ToString() : "";
                    
                    txtTenorofloaninmonth.Text = dtone.Rows[0]["QUESTION_8"] != DBNull.Value ? dtone.Rows[0]["QUESTION_8"].ToString() : "";
                    txtInterestrateavailed.Text = dtone.Rows[0]["QUESTION_9"] != DBNull.Value ? dtone.Rows[0]["QUESTION_9"].ToString() : "";


                    string Acknowledgement = dtone.Rows[0]["QUESTION_10"] != DBNull.Value ? dtone.Rows[0]["QUESTION_10"].ToString() : "";
                    if (Acknowledgement == "Received")
                    {
                        rbAcknowledgement.SelectedIndex = 0;
                    }
                    else { rbAcknowledgement.SelectedIndex = 1; }
                    //rbAcknowledgement.SelectedItem.Text = dtone.Rows[0]["QUESTION_10"] != DBNull.Value ? dtone.Rows[0]["QUESTION_10"].ToString() : "";

                    string Overallequitasrate = dtone.Rows[0]["QUESTION_11"] != DBNull.Value ? dtone.Rows[0]["QUESTION_11"].ToString() : "";
                    if (Overallequitasrate == "Good")
                    {
                        rbOverallequitasrate.SelectedIndex = 0;
                    }
                    else { rbOverallequitasrate.SelectedIndex = 1; }
                    //rbOverallequitasrate.SelectedItem.Text = dtone.Rows[0]["QUESTION_11"] != DBNull.Value ? dtone.Rows[0]["QUESTION_11"].ToString() : "";
                    txtCustomerresponse.Text = dtone.Rows[0]["QUESTION_12"] != DBNull.Value ? dtone.Rows[0]["QUESTION_12"].ToString() : "";

                    string Employedorbuisness = dtone.Rows[0]["QUESTION_13"] != DBNull.Value ? dtone.Rows[0]["QUESTION_13"].ToString() : "";
                    if (Employedorbuisness == "Employed")
                    {
                        rbEmployedorbuisness.SelectedIndex = 0;
                    }
                    else { rbEmployedorbuisness.SelectedIndex = 1; }
                    //rbEmployedorbuisness.SelectedItem.Text = Convert.ToString(dtone.Rows[0]["QUESTION_13"].ToString());

                    txtIncometypeofbuisness.Text = Convert.ToString(dtone.Rows[0]["QUESTION_14"].ToString());
                    txtVintageofbuisness.Text = Convert.ToString(dtone.Rows[0]["QUESTION_15"].ToString());
                    txtAveragedailyincome.Text = Convert.ToString(dtone.Rows[0]["QUESTION_16"].ToString());

                    txtIncomenameofcompanyemploy.Text = Convert.ToString(dtone.Rows[0]["QUESTION_17"].ToString());
                    txtNoofyearsemployment.Text = Convert.ToString(dtone.Rows[0]["QUESTION_18"].ToString());
                    txtIncomegrosssalary.Text = Convert.ToString(dtone.Rows[0]["QUESTION_19"].ToString());

                    txtSMEcases.Text = Convert.ToString(dtone.Rows[0]["QUESTION_20"].ToString());
                    txtCurrentstageofconstruction.Text = Convert.ToString(dtone.Rows[0]["QUESTION_21"].ToString());

                    string Localmoneylendors = dtone.Rows[0]["QUESTION_22"] != DBNull.Value ? dtone.Rows[0]["QUESTION_22"].ToString() : "";
                    if (Localmoneylendors == "Yes")
                    {
                        rbLocalmoneylendors.SelectedIndex = 0;
                    }
                    else { rbLocalmoneylendors.SelectedIndex = 1; }
                   // rbLocalmoneylendors.SelectedItem.Text = Convert.ToString(dtone.Rows[0]["QUESTION_22"].ToString());
                    txtPreviousinstallment.Text = Convert.ToString(dtone.Rows[0]["QUESTION_23"].ToString());

                    txtMarketvalueofpropertyfro.Text = Convert.ToString(dtone.Rows[0]["QUESTION_24"].ToString());

                }

            }
        }
        SetFocus(txtLoanamountdisbursed);
    }

    protected void rbEmployedorbuisness_SelectedIndexChanged(object sender, EventArgs e)
    {
        trSmallbuisness.Visible = false;
        trSmalltypeofbuisness.Visible = false;
        trSmallvintageofbuisness.Visible = false;
        trSmalldailyincomeofbuisness.Visible = false;
        trEmployed.Visible = false;
        trEmployedcompany.Visible = false;
        trEmployednoofyears.Visible = false;
        trEmployedincomesalary.Visible = false;

        if (rbEmployedorbuisness.SelectedItem.Text != "")
        {
            string Buisnesstype = rbEmployedorbuisness.SelectedItem.Text;
            if (Buisnesstype != "Employed")
            {
                trSmallbuisness.Visible = true;
                trSmalltypeofbuisness.Visible = true;
                trSmallvintageofbuisness.Visible = true;
                trSmalldailyincomeofbuisness.Visible = true;
            }
            else
            {
                trEmployed.Visible = true;
                trEmployedcompany.Visible = true;
                trEmployednoofyears.Visible = true;
                trEmployedincomesalary.Visible = true;
            }
        }

    }
}