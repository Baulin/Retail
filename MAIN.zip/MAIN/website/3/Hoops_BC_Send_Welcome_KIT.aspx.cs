﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Tracker;

public partial class Hoops_BC_Send_Welcome_KIT : System.Web.UI.Page
{
    int ldid;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
    }
    //public void bind()
    //{
    //    SqlConnection con = new SqlConnection(strcon);
    //    con.Open();
    //    SqlCommand cmddd = new SqlCommand("select AR_NAME from MR_AREA", con);
    //    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //    DataSet dsdd = new DataSet();
    //    dadd.Fill(dsdd);

    //    //SqlCommand cmdquery = new SqlCommand("select QY_QUERY from MR_QUERY", con);
    //    //SqlDataAdapter daquery = new SqlDataAdapter(cmdquery);
    //    //DataSet dsquery = new DataSet();
    //    //daquery.Fill(dsquery);        
    //    //con.Close();

    //    ddlArea.DataSource = dsdd;
    //    ddlArea.DataTextField = "AR_NAME";
    //    ddlArea.DataValueField = "AR_NAME";
    //    ddlArea.DataBind();
    //    ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

    //    SqlCommand cmdquery = new SqlCommand("select DISTINCT QY_QUERY from MR_QUERY ORDER BY QY_QUERY ASC", con);
    //    SqlDataAdapter daquery = new SqlDataAdapter(cmdquery);
    //    DataSet dsquery = new DataSet();
    //    daquery.Fill(dsquery);
    //    con.Close();
    //    gvUserInfo.DataSource = dsquery;
    //    gvUserInfo.DataBind();

    //    //ddlQuery.DataSource = dsquery;
    //    //ddlQuery.DataTextField = "QY_QUERY";
    //    //ddlQuery.DataValueField = "QY_QUERY";
    //    //ddlQuery.DataBind();
    //    //ddlQuery.Items.Insert(0, new ListItem("--Select--", "0"));

    //}

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        // ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();




    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
            // gvUserInfo.Visible = false;
            if (txtBCACODE.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "All";
                gridbindall();
            }
            else if (txtBCACODE.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                gridbindall();
                //gridbind();
            }
            else if (txtBCACODE.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";
                gridbindall();
                //gridbind();
            }
            else if (txtBCACODE.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                gridbindall();
                //  gridbind();
            }
            else if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please select Area and Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlBranch.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (txtBCACODE.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter Connectors Code.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            /* SqlCommand cmd = new SqlCommand("select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE isnull(LD_SANTD_DATE,'')='' AND (FT_SENTBY='C' OR FT_SENTBY='B') AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' ORDER BY LD_NO", con);
             SqlDataAdapter da = new SqlDataAdapter(cmd);
             da.Fill(ds);
           */
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_BC_APP_FOR_SEND_WKIT", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@BCA_CODE", txtBCACODE.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    public void gvEmp_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {


            if (e.CommandName == "NewUpdate")
            {
                int bca_id = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                DropDownList ddlCourier = (DropDownList)row.FindControl("ddlCourier");
                TextBox txtPOD = (TextBox)row.FindControl("txtPOD");
                LinkButton lnkUpdate = (LinkButton)row.FindControl("lnkUpdate");
                string strClientID = string.Empty;
                strClientID = lnkUpdate.ClientID;
                if (txtPOD.Text != "")
                {

                    clscommon.UpdateBCApp_SEND_WKIT_By_Ops(bca_id, Session["ID"].ToString(), ddlCourier.SelectedValue, txtPOD.Text);
                    //clscommon.UpdateCreditEmployeeApprovalAmount(emp_id, Convert.ToDecimal(txtEmpAprvAmt.Text));

                    // bind();
                    uscMsgBox1.AddMessage("Connector Welcome Kit has been sent successfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    //ScriptManager.RegisterClientScriptBlock(lnkUpdate, this.GetType(), "alert", "swal('Credit approval amount has been updated successfully','','success');", true);

                    gridbindall();
                }
                else
                {
                    uscMsgBox1.AddMessage("Please enter the POD", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    public void gridbind()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(" select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE ( FT_SENTBY='C' OR FT_SENTBY='B')  AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND LD_NO='" + txtBCACODE.Text + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' OR ( FT_SENTBY='C' OR FT_SENTBY='B') AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedItem.Text.ToString() + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' ORDER BY LD_NO ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }


    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            foreach (GridViewRow grow in gvQuery.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                Label lblBCAID = grow.FindControl("lblBCAID") as Label;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    dvTbl.Visible = true;
                    Session["BCAID"] = lblBCAID.Text;
                    leadno = lnbtn.Text;
                    appname = gvQuery.Rows[index].Cells[3].Text;
                    pddt = gvQuery.Rows[index].Cells[2].Text;
                    //lnamt = gvQuery.Rows[index].Cells[5].Text;
                    bind();
                }
            }
            //gvUserInfo.Visible = true;
            lbLeadno.Visible = true;
            lbAppname.Visible = true;
            lbPDdate.Visible = true;
            lbLoanamt.Visible = true;
            //ddlQuery.Enabled = true;
            //ddlSubquery.Enabled = true;
            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;


            lbLeadno.Text = leadno;
            lbAppname.Text = appname;
            lbPDdate.Text = pddt;
            lbLoanamt.Text = lnamt;
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('HOOps_QCQuery_Popup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {




        int i1 = 0, i3 = 0;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            //con.Open();
            //SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + lbLeadno.Text + "'", con);
            //SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
            //DataSet dsbr = new DataSet();
            //dabr.Fill(dsbr);
            //ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["BCA_ID"]);

            ldid = Convert.ToInt32(Session["BCAID"]);






            gridbind();
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
            // gvUserInfo.Visible = false;
            btnSubmit.Enabled = false;
            uscMsgBox1.AddMessage("Query Raised Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }


    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HOOps_QCQuery.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {


            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

            ddlBranch.DataSource = dsrsn;
            ddlBranch.DataTextField = "BR_NAME";
            ddlBranch.DataValueField = "BR_ID";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlBranch.Enabled = true;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void ddlQuery_SelectedIndexChanged(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(strcon);
        //con.Open();
        //ddlSubquery.Enabled = true;
        //SqlCommand cmdsquery = new SqlCommand("select QY_SQUERY from MR_QUERY where QY_QUERY='" + ddlQuery.SelectedValue.ToString() + "'", con);
        //SqlDataAdapter dasquery = new SqlDataAdapter(cmdsquery);
        //DataSet dssquery = new DataSet();
        //dasquery.Fill(dssquery);
        //con.Close();

        //ddlSubquery.DataSource = dssquery;
        //ddlSubquery.DataTextField = "QY_SQUERY";
        //ddlSubquery.DataValueField = "QY_SQUERY";
        //ddlSubquery.DataBind();
        //ddlSubquery.Items.Insert(0, new ListItem("--Select--", "0"));

    }
}