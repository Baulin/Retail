﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;



public partial class Master_Document_Type : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    static string dcheck="0";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                bind();
            }
            else
            {
                Response.Redirect("Expire.aspx");
            }
        }
    }

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmd = new SqlCommand("select MDT_ID,MDT_DESC,MDT_STAT from MR_CDOC_TYPE", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvdocument.DataSource = ds;
        gvdocument.DataBind();
        if (gvdocument.Rows.Count > 0)
        {
            gvdocument.HeaderRow.Font.Bold = true;
            gvdocument.HeaderRow.Cells[1].Text = "DOC.DESCRIPTION";
            gvdocument.HeaderRow.Cells[2].Text = "DOC.STATUS";

            gvdocument.HeaderRow.Cells[1].Wrap = false;
            gvdocument.HeaderRow.Cells[2].Wrap = false;
        }
    }

    protected void gvdocument_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
        }
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        Label lblMDTID = null;
        try
        {
            foreach (GridViewRow grow in gvdocument.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                int index = grow.RowIndex;
                 if (chkStat.Checked)
                 {
                     lblMDTID = (Label)gvdocument.Rows[index].Cells[1].FindControl("lblMDTID");
                      Session["MDT_ID"] = lblMDTID.Text;
                     SqlCommand cmd = new SqlCommand("select MDT_ID,MDT_DESC,MDT_STAT from MR_CDOC_TYPE Where MDT_ID=" + Session["MDT_ID"].ToString(), con);
                     SqlDataAdapter da = new SqlDataAdapter(cmd);
                     DataSet ds = new DataSet();
                     da.Fill(ds);
                     con.Close();
                     if(ds.Tables[0].Rows.Count>0)
                     {
                         txtDocdesc.Text = Convert.ToString(ds.Tables[0].Rows[0]["MDT_DESC"]);
                         ddldocstatus.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["MDT_STAT"]);
                         dcheck = "1";
                     }

                 }
            }
        }        
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            if(ddldocstatus.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Document Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            if (dcheck == "0")
            {
                int nCount = 0;
                SqlCommand cmd = new SqlCommand("select count(MDT_ID) from MR_CDOC_TYPE where MDT_DESC='" + txtDocdesc.Text +"'", con);
                nCount = ((int)cmd.ExecuteScalar());

                if (nCount == 0) { 
                SqlCommand insertcmd = new SqlCommand("insert into MR_CDOC_TYPE values ('" + txtDocdesc.Text + "','" + ddldocstatus.SelectedItem.Value + "','" + Session["ID"].ToString() + "',getdate(),'" + Session["ID"].ToString() + "',getdate())", con);
                insertcmd.ExecuteNonQuery();
                uscMsgBox1.AddMessage("Property Document Details Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
            }
            else
            { 
                SqlCommand insertcmd = new SqlCommand("Update MR_CDOC_TYPE set MDT_DESC='" + txtDocdesc.Text + "',MDT_STAT='" + ddldocstatus.SelectedItem.Value + "',MDT_MBY='" + Session["ID"].ToString() + "',MDT_MDATE=getdate() Where MDT_ID=" + Session["MDT_ID"].ToString(), con);
                insertcmd.ExecuteNonQuery();
                uscMsgBox1.AddMessage("Property Document Details Updated Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
            

            bind();
            txtDocdesc.Text = "";
            ddldocstatus.SelectedIndex=0;
            
            dcheck = "0";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txtDocdesc.Text = "";
        ddldocstatus.SelectedIndex = 0;
    }
    
}