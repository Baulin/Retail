﻿using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;
using Utilities.Enums;
using Utilities.SessionKeys;

public partial class Credit_Approval_Unsecured_OD_TL : System.Web.UI.Page
{
    #region VARIABLES

    string leadno;
    string appname;
    string pddt;
    string lnamt;
    int ldid;
    double approvedAmt;
    ClsCommon clscommon = new ClsCommon();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    DataSet dss = new DataSet();
    DataSet dsDisb = new DataSet();
    DataSet dsd = new DataSet();

    public static bool blMailStatus = false;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";

    #endregion

    public int Session_EMP_ID
    {
        get
        {
            int _employeeId = -1;

            if (Session["EMP_ID"] != null)
            {
                var _empId = Convert.ToString(Session["EMP_ID"]);

                if (!String.IsNullOrEmpty(_empId))
                {
                    _employeeId = Convert.ToInt32(_empId);
                }
            }

            return _employeeId;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                txtBxApprovedAmount.Enabled = false;
                txtdate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();

                //Reset Session key
                if (Session[SessionKeys.DATA_MANIPULATION_MODE] != null) { Session[SessionKeys.DATA_MANIPULATION_MODE] = null; }
            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            Reset();

            ddlApprv.SelectedIndex = 0;
            ddlReason.SelectedIndex = 0;
            ddlReason.Enabled = false;
            txtBxApprovedAmount.Text = "";
            txtBxComment.Text = "";
            DataSet apprvlSummary = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            Label lblLeadID = null;
            Label lblLglAprvl = null;

            foreach (GridViewRow grow in gvCreditApprovalLeads.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                int index = grow.RowIndex;

                if (chkStat.Checked)
                {
                    lblLeadID = (Label)gvCreditApprovalLeads.Rows[index].Cells[1].FindControl("lblLeadID");
                    lblLglAprvl = (Label)gvCreditApprovalLeads.Rows[index].Cells[1].FindControl("lblLgAprvl");

                    Label lblMPSId = grow.FindControl("lblMPSId") as Label;
                    Label lblPRId = grow.FindControl("lblPRId") as Label;
                    Label lblldAcNo = grow.FindControl("lblldAcNo") as Label;
                    Label lblprcde = grow.FindControl("lblprcde") as Label;

                    leadno = gvCreditApprovalLeads.Rows[index].Cells[1].Text;
                    appname = gvCreditApprovalLeads.Rows[index].Cells[3].Text;
                    pddt = gvCreditApprovalLeads.Rows[index].Cells[4].Text;
                    lnamt = gvCreditApprovalLeads.Rows[index].Cells[5].Text;

                    Session["LeadId"] = lblLeadID.Text;
                    Session["Leadno"] = leadno;
                    Session["Loanamt"] = lnamt;
                    Session["lblldAcNo"] = lblldAcNo.Text;
                    Session["Appname"] = appname;
                    Session["MPS_ID"] = lblMPSId.Text;
                    Session["PR_ID"] = lblPRId.Text;
                    var prodId = Convert.ToInt64(lblPRId.Text);

                    apprvlSummary = GetLeadApplrovalSummary();

                    if (apprvlSummary != null && apprvlSummary.Tables.Count > 1 && apprvlSummary.Tables[0].Rows.Count > 0 && apprvlSummary.Tables[1].Rows.Count > 0)
                    {
                        tblApprovalSummary.Visible = true;
                        approvalPanel.Visible = true;
                        submitPanel.Visible = true;

                        DataTable tableOne = apprvlSummary.Tables[0];

                        if (tableOne != null && tableOne.Rows.Count > 0)
                        {
                            lblLeadNo.Text = tableOne.Rows[0]["LD_NO"] != DBNull.Value ? tableOne.Rows[0]["LD_NO"].ToString() : "";
                            lblProduct.Text = tableOne.Rows[0]["PR_CODE"] != DBNull.Value ? tableOne.Rows[0]["PR_CODE"].ToString() : "";
                            lblCustName.Text = tableOne.Rows[0]["LD_APNAME"] != DBNull.Value ? tableOne.Rows[0]["LD_APNAME"].ToString() : "";

                            if (tableOne.Rows[0]["AR_NAME"] != DBNull.Value && tableOne.Rows[0]["BR_NAME"] != DBNull.Value)
                            {
                                String areaBranch = tableOne.Rows[0]["AR_NAME"].ToString() + "/" + tableOne.Rows[0]["BR_NAME"].ToString();
                                lblAreaBranch.Text = !String.IsNullOrEmpty(areaBranch) ? areaBranch : String.Empty;
                            }
                        }

                        DataTable tableTwo = apprvlSummary.Tables[1];
                        Int64 tableTwoRowCount = tableTwo.Rows.Count;

                        if (tableTwoRowCount > 0 && tableTwo.Rows[0]["KYC_NAME"] != DBNull.Value)
                        {
                            trApplicant.Visible = true;
                            lblApplicant.Text = tableTwo.Rows[0]["KYC_NAME"] != DBNull.Value ? tableTwo.Rows[0]["KYC_NAME"].ToString() : "";
                            hdnKycApplicant.Value = tableTwo.Rows[0]["KYC_ID"] != DBNull.Value ? tableTwo.Rows[0]["KYC_ID"].ToString() : "";
                        }

                        if (tableTwoRowCount > 1 && tableTwo.Rows[1]["KYC_NAME"] != DBNull.Value)
                        {
                            trCoApplicant1.Visible = true;
                            lblCoApplicant1.Text = tableTwo.Rows[1]["KYC_NAME"] != DBNull.Value ? tableTwo.Rows[1]["KYC_NAME"].ToString() : "";
                            hdnKycCoApplicant1.Value = tableTwo.Rows[1]["KYC_ID"] != DBNull.Value ? tableTwo.Rows[1]["KYC_ID"].ToString() : "";
                        }

                        if (tableTwoRowCount > 2 && tableTwo.Rows[2]["KYC_NAME"] != DBNull.Value)
                        {
                            trCoApplicant2.Visible = true;
                            lblCoApplicant2.Text = tableTwo.Rows[2]["KYC_NAME"] != DBNull.Value ? tableTwo.Rows[2]["KYC_NAME"].ToString() : "";
                            hdnKycCoApplicant2.Value = tableTwo.Rows[2]["KYC_ID"] != DBNull.Value ? tableTwo.Rows[2]["KYC_ID"].ToString() : "";
                        }

                        if (tableTwoRowCount > 3 && tableTwo.Rows[3]["KYC_NAME"] != DBNull.Value)
                        {
                            trCoApplicant3.Visible = true;
                            lblCoApplicant3.Text = tableTwo.Rows[3]["KYC_NAME"] != DBNull.Value ? tableTwo.Rows[3]["KYC_NAME"].ToString() : "";
                            hdnKycCoApplicant3.Value = tableTwo.Rows[3]["KYC_ID"] != DBNull.Value ? tableTwo.Rows[3]["KYC_ID"].ToString() : "";
                        }

                        if (tableTwoRowCount > 4 && tableTwo.Rows[4]["KYC_NAME"] != DBNull.Value)
                        {
                            trCoApplicant4.Visible = true;
                            lblCoApplicant4.Text = tableTwo.Rows[4]["KYC_NAME"] != DBNull.Value ? tableTwo.Rows[4]["KYC_NAME"].ToString() : "";
                            hdnKycCoApplicant4.Value = tableTwo.Rows[4]["KYC_ID"] != DBNull.Value ? tableTwo.Rows[4]["KYC_ID"].ToString() : "";
                        }

                        if (tableTwoRowCount > 5 && tableTwo.Rows[5]["KYC_NAME"] != DBNull.Value)
                        {
                            trCoApplicant5.Visible = true;
                            lblCoApplicant5.Text = tableTwo.Rows[5]["KYC_NAME"] != DBNull.Value ? tableTwo.Rows[5]["KYC_NAME"].ToString() : "";
                            hdnKycCoApplicant5.Value = tableTwo.Rows[5]["KYC_ID"] != DBNull.Value ? tableTwo.Rows[5]["KYC_ID"].ToString() : "";
                        }

                        if (prodId > 0)
                        {
                            if (prodId == Convert.ToInt64(Declared_Product_Program.UnSecured_TL_Based_On_POS))
                            {
                                trAveragePOS.Visible = true;
                                trFinalApprvedLoan.Visible = true;
                                trEMI.Visible = true;
                            }
                            else if (prodId == Convert.ToInt64(Declared_Product_Program.UnSecured_OD_Based_On_POS))
                            {
                                trAveragePOS.Visible = true;
                                trFinalApprvedLimitODPOS.Visible = true;
                            }
                            else if (prodId == Convert.ToInt64(Assessed_Product_Program.Merchant_OD))
                            {
                                trEligibility.Visible = true;
                                trFinalApprvedLimit.Visible = true;
                            }
                        }

                        ShowPremisesLocation(con);

                        lblApprovedBy.Text = Session[SessionKeys.EMPNAME] != null ? Session[SessionKeys.EMPNAME].ToString() : "";
                        lblApprovedDate.Text = DateTime.Now.ToLongDateString();

                        ddlApprv.Enabled = true;
                        btnSubmit.Enabled = true;
                        btnCancel.Enabled = true;
                    }
                    else
                    {
                        uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_NO_KYC_AVAILABLE, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
            }

            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_NAME";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;

        txtBxLeadno.Text = "";
        txtBxLeadno.Enabled = false;
    }

    protected void ddlApprv_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlReason.SelectedIndex = 0;
        if (ddlApprv.SelectedValue.ToString() == "Rejected")
        {
            ddlReason.Enabled = true;
            txtBxApprovedAmount.Text = "";
            txtBxApprovedAmount.Enabled = false;
        }
        else
        {
            ddlReason.Enabled = false;
            txtBxApprovedAmount.Text = "";
            txtBxApprovedAmount.Enabled = true;
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        bool _passValidation = false;

        try
        {
            if (txtBxLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "All";
                _passValidation = false;
                uscMsgBox1.AddMessage("Please Select Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (txtBxLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                _passValidation = true;
            }
            else if (txtBxLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";
                _passValidation = true;
            }
            else if (txtBxLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                _passValidation = true;
            }
            else if (txtBxLeadno.Text != "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                _passValidation = true;
            }
            else if (txtBxLeadno.Text != "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";
                _passValidation = true;
            }

            if (_passValidation)
            {
                BindqueryGrid();

                foreach (GridViewRow grow in gvCreditApprovalLeads.Rows)
                {
                    Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                    int index = grow.RowIndex;
                    if (lblQryResult.Text == "T")
                    {
                        gvCreditApprovalLeads.Rows[index].Cells[1].ForeColor = Color.Red;
                        gvCreditApprovalLeads.Rows[index].Cells[2].ForeColor = Color.Red;
                        gvCreditApprovalLeads.Rows[index].Cells[3].ForeColor = Color.Red;
                        gvCreditApprovalLeads.Rows[index].Cells[4].ForeColor = Color.Red;
                        gvCreditApprovalLeads.Rows[index].Cells[5].ForeColor = Color.Red;
                        gvCreditApprovalLeads.Rows[index].Cells[6].ForeColor = Color.Red;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        if (ddlArea != null && ddlArea.SelectedIndex > 0) { ddlArea.ClearSelection(); }
        if (ddlBranch != null && ddlBranch.SelectedIndex > 0) { ddlBranch.ClearSelection(); }
        if (txtBxLeadno != null && !String.IsNullOrEmpty(txtBxLeadno.Text)) { txtBxLeadno.Text = String.Empty; }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlApprv.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_PROPOSAL_ACTION_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlApprv.SelectedItem.Text == "Approved")
            {
                if (ValidateProposalForApproval())
                {
                    if (Session[SessionKeys.EMP_ET_ID] != null)
                    {
                        //Get CO/CM's loan approval limit
                        int emp_aprv_amt = clscommon.GetEmpAprvAmountByEmpID(Session_EMP_ID);

                        var empTypeId = Convert.ToInt64(Session[SessionKeys.EMP_ET_ID]);

                        if ((empTypeId == 6) || (empTypeId == 7) || (empTypeId == 15) || (empTypeId == 18) || (empTypeId == 19) || (empTypeId == 28))
                        {
                            if (Convert.ToDouble(txtBxApprovedAmount.Text) <= Convert.ToDouble(emp_aprv_amt))
                            {
                                ApproveRejectCredit();
                            }
                            else
                            {
                                uscMsgBox1.AddMessage("You are not eligible to approve this amount.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }
                        }
                        else
                        {
                            ApproveRejectCredit();
                        }
                    }
                }
            }
            else if (ddlApprv.SelectedItem.Text == "Rejected")
            {
                if (ValidateProposalForRejection())
                {
                    if (Session[SessionKeys.EMP_ET_ID] != null)
                    {
                        ApproveRejectCredit();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Credit_Approval.aspx");
    }

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_MR_AREA, con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        SqlCommand cmdrsn = new SqlCommand(AppConstants.Proc_RTS_SP_Fetch_MR_REASON, con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlReason.DataSource = dsrsn;
        ddlReason.DataTextField = "RSN_REASON";
        ddlReason.DataValueField = "RSN_ID";
        ddlReason.DataBind();
        ddlReason.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);

        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_IB_SME_UNSECURED_OT_TL, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 1200000;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtBxLeadno.Text);

            if (ddlArea.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@AR_NAME", "");
            }

            if (ddlBranch.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@BR_NAME", "");
            }

            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "C");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);

            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvCreditApprovalLeads.Visible = true;
                gvCreditApprovalLeads.DataSource = ds1.Tables[0];
                gvCreditApprovalLeads.DataBind();

                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvCreditApprovalLeads.HeaderRow.Font.Bold = true;
                    gvCreditApprovalLeads.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvCreditApprovalLeads.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvCreditApprovalLeads.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    gvCreditApprovalLeads.HeaderRow.Cells[4].Text = "PD DATE";
                    gvCreditApprovalLeads.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                    gvCreditApprovalLeads.HeaderRow.Cells[1].Wrap = false;
                    gvCreditApprovalLeads.HeaderRow.Cells[2].Wrap = false;
                    gvCreditApprovalLeads.HeaderRow.Cells[3].Wrap = false;
                    gvCreditApprovalLeads.HeaderRow.Cells[4].Wrap = false;
                    gvCreditApprovalLeads.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvCreditApprovalLeads.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }

    public DataSet GetLeadApplrovalSummary()
    {
        SqlConnection con = new SqlConnection(strcon);

        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_CREDIT_APPROVAL_MEMO_OD_TL, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue(AppConstants.Param_Lead_Id, Session["LeadId"].ToString());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dss);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }

        return dss;
    }

    public void ApproveRejectCredit()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        try
        {
            if (Session[SessionKeys.Leadno] != null)
            {
                var leadNo = Session[SessionKeys.Leadno].ToString();
                ldid = Convert.ToInt32(Session[SessionKeys.LeadId]);
                var prodId = Convert.ToInt64(Session[SessionKeys.PR_ID]);

                if (!String.IsNullOrEmpty(leadNo))
                {
                    SqlCommand cmdinsert = new SqlCommand(AppConstants.Proc_RTS_SP_UPDATE_CREDIT_APPROVAL, con);
                    cmdinsert.CommandType = CommandType.StoredProcedure;
                    cmdinsert.CommandTimeout = 1200000;
                    cmdinsert.Parameters.AddWithValue("@LD_CRAP_APRL", ddlApprv.SelectedIndex.ToString());
                    cmdinsert.Parameters.AddWithValue("@LD_CRAP_AMT", txtBxApprovedAmount.Text != "" ? txtBxApprovedAmount.Text : "0");
                    cmdinsert.Parameters.AddWithValue("@LD_CRAP_CMTS", txtBxComment.Text != "" ? txtBxComment.Text : "");
                    cmdinsert.Parameters.AddWithValue("@LD_CRAP_MBY", Session[SessionKeys.ID].ToString());
                    cmdinsert.Parameters.AddWithValue("@LD_ID", ldid);
                    cmdinsert.Parameters.AddWithValue("@LD_CRAP_RSN_ID", ddlReason.SelectedValue.ToString());
                    cmdinsert.Parameters.AddWithValue("@LD_RCARDNO", "");
                    cmdinsert.Parameters.AddWithValue("@LD_CR_SCORE", txtBxFileCreditScore.Text != "" ? txtBxFileCreditScore.Text : "0");
                    cmdinsert.Parameters.AddWithValue("@LD_CASTE", "");
                    cmdinsert.Parameters.AddWithValue("@LD_PR_OWND", "");
                    cmdinsert.Parameters.AddWithValue("@LD_PPR_OWND", "");
                    cmdinsert.Parameters.AddWithValue("@LD_CRE", "");
                    cmdinsert.ExecuteNonQuery();

                    cmdinsert = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_UNSECURED_CR_APRVL, con);
                    cmdinsert.CommandType = CommandType.StoredProcedure;
                    cmdinsert.CommandTimeout = 1200000;
                    SqlDataAdapter sqlDtAdprt = new SqlDataAdapter(cmdinsert);
                    DataSet resultSet = new DataSet();
                    cmdinsert.Parameters.AddWithValue("@LUD_LD_ID", ldid);
                    cmdinsert.Parameters.AddWithValue("@LUD_SAMPLE_MARKING", ddlSamplingMarking.SelectedIndex > 0 ? ddlSamplingMarking.SelectedValue.ToString() : String.Empty);
                    cmdinsert.Parameters.AddWithValue("@LUD_FI_STATUS", ddlFIStatus.SelectedIndex > 0 ? ddlFIStatus.SelectedValue.ToString() : String.Empty);
                    cmdinsert.Parameters.AddWithValue("@LUD_RCU_STATUS", ddlRCUStatus.SelectedIndex > 0 ? ddlRCUStatus.SelectedValue.ToString() : String.Empty);
                    cmdinsert.Parameters.AddWithValue("@LUD_CR_AMB_ELIGIBILITY", txtBxEligibility.Text != "" ? txtBxEligibility.Text.ToString() : String.Empty);

                    if (prodId == Convert.ToInt64(Declared_Product_Program.UnSecured_OD_Based_On_POS))
                    {
                        cmdinsert.Parameters.AddWithValue("@LUD_FIN_APPRV_LIMIT", txtBxFinalApprvedLimitODPOS.Text != "" ? txtBxFinalApprvedLimitODPOS.Text.ToString() : String.Empty);
                    }
                    else
                    {
                        cmdinsert.Parameters.AddWithValue("@LUD_FIN_APPRV_LIMIT", txtBxFinalApprvedLimit.Text != "" ? txtBxFinalApprvedLimit.Text.ToString() : String.Empty);
                    }

                    cmdinsert.Parameters.AddWithValue("@LUD_FIN_APPRV_LN_AMT", txtBxFinalApprvedLoan.Text != "" ? txtBxFinalApprvedLoan.Text.ToString() : String.Empty);
                    cmdinsert.Parameters.AddWithValue("@LUD_AVG_POS_SWIPES", txtBxAveragePOS.Text != "" ? txtBxAveragePOS.Text.ToString() : String.Empty);
                    cmdinsert.Parameters.AddWithValue("@LUD_TENOR", txtBxTenor.Text != "" ? txtBxTenor.Text.ToString() : String.Empty);
                    cmdinsert.Parameters.AddWithValue("@LUD_ROI", txtBxROI.Text != "" ? txtBxROI.Text.ToString() : String.Empty);
                    cmdinsert.Parameters.AddWithValue("@LUD_EMI", txtBxEMI.Text != "" ? txtBxEMI.Text.ToString() : String.Empty);
                    cmdinsert.Parameters.AddWithValue("@LUD_RCMND_BY", txtBxRecommendedBy.Text != "" ? txtBxRecommendedBy.Text.ToString() : String.Empty);
                    cmdinsert.Parameters.AddWithValue("@LUD_OFFLINE_APPRV_BY", txtBxOfflineApprovedBy.Text != "" ? txtBxOfflineApprovedBy.Text.ToString() : String.Empty);
                    cmdinsert.Parameters.AddWithValue("@LUD_APPRV_BY", Session[SessionKeys.ID].ToString());
                    sqlDtAdprt.Fill(resultSet);

                    Int64 ludId = 0;
                    if (resultSet != null && resultSet.Tables.Count > 0 && resultSet.Tables[0].Rows.Count > 0)
                    {
                        ludId = Convert.ToInt64(resultSet.Tables[0].Rows[0]["LUD_ID"]);
                    }

                    if (txtBxApplicantCibil != null && txtBxApplicantCibil.Visible == true && !String.IsNullOrEmpty(txtBxApplicantCibil.Text))
                    {
                        cmdinsert = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_UNSECURED_CIBIL, con);
                        cmdinsert.CommandType = CommandType.StoredProcedure;
                        cmdinsert.CommandTimeout = 1200000;
                        cmdinsert.Parameters.AddWithValue("@LC_LUD_ID", ludId);
                        cmdinsert.Parameters.AddWithValue("@LC_KYC_ID", Convert.ToInt64(hdnKycApplicant.Value));
                        cmdinsert.Parameters.AddWithValue("@LC_CIBIL", Convert.ToInt64(txtBxApplicantCibil.Text.ToString()));
                        cmdinsert.ExecuteNonQuery();
                    }

                    if (txtBxCoApplicant1Cibil != null && txtBxCoApplicant1Cibil.Visible == true && !String.IsNullOrEmpty(txtBxCoApplicant1Cibil.Text))
                    {
                        cmdinsert = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_UNSECURED_CIBIL, con);
                        cmdinsert.CommandType = CommandType.StoredProcedure;
                        cmdinsert.CommandTimeout = 1200000;
                        cmdinsert.Parameters.AddWithValue("@LC_LUD_ID", ludId);
                        cmdinsert.Parameters.AddWithValue("@LC_KYC_ID", Convert.ToInt64(hdnKycCoApplicant1.Value));
                        cmdinsert.Parameters.AddWithValue("@LC_CIBIL", Convert.ToInt64(txtBxCoApplicant1Cibil.Text.ToString()));
                        cmdinsert.ExecuteNonQuery();
                    }

                    if (txtBxCoApplicant2Cibil != null && txtBxCoApplicant2Cibil.Visible == true && !String.IsNullOrEmpty(txtBxCoApplicant2Cibil.Text))
                    {
                        cmdinsert = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_UNSECURED_CIBIL, con);
                        cmdinsert.CommandType = CommandType.StoredProcedure;
                        cmdinsert.CommandTimeout = 1200000;
                        cmdinsert.Parameters.AddWithValue("@LC_LUD_ID", ludId);
                        cmdinsert.Parameters.AddWithValue("@LC_KYC_ID", Convert.ToInt64(hdnKycCoApplicant2.Value));
                        cmdinsert.Parameters.AddWithValue("@LC_CIBIL", Convert.ToInt64(txtBxCoApplicant2Cibil.Text.ToString()));
                        cmdinsert.ExecuteNonQuery();
                    }

                    if (txtBxCoApplicant3Cibil != null && txtBxCoApplicant3Cibil.Visible == true && !String.IsNullOrEmpty(txtBxCoApplicant3Cibil.Text))
                    {
                        cmdinsert = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_UNSECURED_CIBIL, con);
                        cmdinsert.CommandType = CommandType.StoredProcedure;
                        cmdinsert.CommandTimeout = 1200000;
                        cmdinsert.Parameters.AddWithValue("@LC_LUD_ID", ludId);
                        cmdinsert.Parameters.AddWithValue("@LC_KYC_ID", Convert.ToInt64(hdnKycCoApplicant3.Value));
                        cmdinsert.Parameters.AddWithValue("@LC_CIBIL", Convert.ToInt64(txtBxCoApplicant3Cibil.Text.ToString()));
                        cmdinsert.ExecuteNonQuery();
                    }

                    if (txtBxCoApplicant4Cibil != null && txtBxCoApplicant4Cibil.Visible == true && !String.IsNullOrEmpty(txtBxCoApplicant4Cibil.Text))
                    {
                        cmdinsert = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_UNSECURED_CIBIL, con);
                        cmdinsert.CommandType = CommandType.StoredProcedure;
                        cmdinsert.CommandTimeout = 1200000;
                        cmdinsert.Parameters.AddWithValue("@LC_LUD_ID", ludId);
                        cmdinsert.Parameters.AddWithValue("@LC_KYC_ID", Convert.ToInt64(hdnKycCoApplicant4.Value));
                        cmdinsert.Parameters.AddWithValue("@LC_CIBIL", Convert.ToInt64(txtBxCoApplicant4Cibil.Text.ToString()));
                        cmdinsert.ExecuteNonQuery();
                    }

                    if (txtBxCoApplicant5Cibil != null && txtBxCoApplicant5Cibil.Visible == true && !String.IsNullOrEmpty(txtBxCoApplicant5Cibil.Text))
                    {
                        cmdinsert = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_UNSECURED_CIBIL, con);
                        cmdinsert.CommandType = CommandType.StoredProcedure;
                        cmdinsert.CommandTimeout = 1200000;
                        cmdinsert.Parameters.AddWithValue("@LC_LUD_ID", ludId);
                        cmdinsert.Parameters.AddWithValue("@LC_KYC_ID", Convert.ToInt64(hdnKycCoApplicant5.Value));
                        cmdinsert.Parameters.AddWithValue("@LC_CIBIL", Convert.ToInt64(txtBxCoApplicant5Cibil.Text.ToString()));
                        cmdinsert.ExecuteNonQuery();
                    }

                    SaveGeoTaggingInfo(con);

                    if (ddlApprv.SelectedItem.ToString() == "Approved")
                    {
                        string message = "";
                        message += "<br/>Credit Approved Successfully..!! ";

                        if (!String.IsNullOrEmpty(txtBxApprovedAmount.Text))
                        {
                            message += "<br/>Credit Approved Amount : " + txtBxApprovedAmount.Text + " ";
                        }

                        if (!String.IsNullOrEmpty(txtBxComment.Text))
                        {
                            message += "<br/>Credit Comments :" + txtBxComment.Text + "";
                        }

                        Reset();
                        BindqueryGrid();
                        uscMsgBox1.AddMessage(message, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else if (ddlApprv.SelectedItem.Text == "Rejected")
                    {
                        InsertSmsRejection();

                        string message = "";
                        message += "<br/>Credit Rejected Successfully..!! ";

                        if (!String.IsNullOrEmpty(txtBxApprovedAmount.Text))
                        {
                            message += "<br/>Credit Rejected Amount : " + txtBxApprovedAmount.Text + " ";
                        }

                        if (!String.IsNullOrEmpty(txtBxComment.Text))
                        {
                            message += "<br/>Credit Comments :" + txtBxComment.Text + "";
                        }

                        Reset();
                        BindqueryGrid();
                        uscMsgBox1.AddMessage(message, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                }
            }
            else
            {
                uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_APPRV_RECORD_USER_INELIGIBLE, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_CREDIT_APPROVAL, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    public void RejectCredit()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        try
        {
            if (Session[SessionKeys.EMP_ET_ID] != null)
            {
                //Get CO/CM's loan approval limit
                int emp_aprv_amt = clscommon.GetEmpAprvAmountByEmpID(Session_EMP_ID);

                var empTypeId = Convert.ToInt64(Session[SessionKeys.EMP_ET_ID]);

                if ((empTypeId == 6) || (empTypeId == 7) || (empTypeId == 15) || (empTypeId == 18) || (empTypeId == 19) || (empTypeId == 28))
                {
                    if (Session[SessionKeys.Leadno] != null)
                    {
                        var leadNo = Session[SessionKeys.Leadno].ToString();

                        if (!String.IsNullOrEmpty(leadNo))
                        {
                            InsertSmsRejection();

                            string message = "";

                            if (!String.IsNullOrEmpty(txtBxApprovedAmount.Text))
                            {
                                message += "<br/>Credit Rejected Amount : " + txtBxApprovedAmount.Text + " ";
                            }

                            if (!String.IsNullOrEmpty(txtBxComment.Text))
                            {
                                message += "<br/>Credit Comments :" + txtBxComment.Text + "";
                            }

                            Reset();
                            uscMsgBox1.AddMessage(message, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        }
                    }
                    else
                    {
                        uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_APPRV_RECORD_USER_INELIGIBLE, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_CREDIT_APPROVAL, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    public void InsertSmsRejection()
    {
        try
        {
            if (ddlReason.SelectedItem.Value != "15"
                && ddlReason.SelectedItem.Value != "16"
                && ddlReason.SelectedItem.Value != "17"
                && ddlReason.SelectedItem.Value != "18")
            {
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand insertcmd = new SqlCommand("INSERT INTO LSD_CREDIT_REJ_SMS (CRS_LD_NO,CRS_AC_NO,CRS_AC_NAM,CRS_CMTS,CRS_CBY,CRS_CDATE) VALUES ('" + Session["Leadno"].ToString() + "','" + Session["lblldAcNo"].ToString() + "','" + Session["Appname"].ToString() + "','" + txtBxComment.Text + "','" + Session["ID"].ToString() + "',getdate())", con);
                insertcmd.CommandType = CommandType.Text;
                insertcmd.ExecuteNonQuery();
                con.Close();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }

    private void Reset()
    {
        lblLeadNo.Text = String.Empty;
        lblProduct.Text = String.Empty;
        lblCustName.Text = String.Empty;
        lblAreaBranch.Text = String.Empty;

        lblApplicant.Text = String.Empty;
        txtBxApplicantCibil.Text = String.Empty;
        hdnKycApplicant.Value = String.Empty;

        lblCoApplicant1.Text = String.Empty;
        txtBxCoApplicant1Cibil.Text = String.Empty;
        hdnKycCoApplicant1.Value = String.Empty;

        lblCoApplicant2.Text = String.Empty;
        txtBxCoApplicant2Cibil.Text = String.Empty;
        hdnKycCoApplicant2.Value = String.Empty;

        lblCoApplicant3.Text = String.Empty;
        txtBxCoApplicant3Cibil.Text = String.Empty;
        hdnKycCoApplicant3.Value = String.Empty;

        lblCoApplicant4.Text = String.Empty;
        txtBxCoApplicant4Cibil.Text = String.Empty;
        hdnKycCoApplicant4.Value = String.Empty;

        lblCoApplicant5.Text = String.Empty;
        txtBxCoApplicant5Cibil.Text = String.Empty;
        hdnKycCoApplicant5.Value = String.Empty;

        ddlSamplingMarking.ClearSelection();
        ddlSamplingMarking.SelectedIndex = 0;

        ddlFIStatus.ClearSelection();
        ddlFIStatus.SelectedIndex = 0;

        ddlRCUStatus.ClearSelection();
        ddlRCUStatus.SelectedIndex = 0;

        if (trEligibility.Visible) { txtBxEligibility.Text = String.Empty; }
        if (trFinalApprvedLimit.Visible) { txtBxFinalApprvedLimit.Text = String.Empty; }
        if (trFinalApprvedLimitODPOS.Visible) { txtBxFinalApprvedLimitODPOS.Text = String.Empty; }
        if (trAveragePOS.Visible) { txtBxAveragePOS.Text = String.Empty; }
        if (trFinalApprvedLoan.Visible) { txtBxFinalApprvedLoan.Text = String.Empty; }

        txtBxTenor.Text = String.Empty;
        txtBxROI.Text = String.Empty;

        if (trEMI.Visible) { txtBxEMI.Text = String.Empty; }

        txtBxRecommendedBy.Text = String.Empty;
        lblApprovedBy.Text = String.Empty;
        lblApprovedDate.Text = String.Empty;

        ddlApprv.SelectedIndex = 0;
        ddlReason.SelectedIndex = 0;
        ddlReason.Enabled = false;

        txtBxApprovedAmount.Text = String.Empty;
        txtBxApprovedAmount.Enabled = false;

        txtBxFileCreditScore.Text = String.Empty;
        txtBxComment.Text = String.Empty;
        btnSubmit.Enabled = false;
        btnCancel.Enabled = false;

        trApplicant.Visible = false;
        trCoApplicant1.Visible = false;
        trCoApplicant2.Visible = false;
        trCoApplicant3.Visible = false;
        trCoApplicant4.Visible = false;
        trCoApplicant5.Visible = false;
        trEligibility.Visible = false;
        trFinalApprvedLimit.Visible = false;
        trFinalApprvedLimitODPOS.Visible = false;
        trAveragePOS.Visible = false;
        trFinalApprvedLoan.Visible = false;
        trEMI.Visible = false;

        ClearPremisesLocation();

        tblApprovalSummary.Visible = false;
        approvalPanel.Visible = false;
        submitPanel.Visible = false;
    }

    private bool ValidateProposalForApproval()
    {
        bool validationResult = true;

        try
        {
            #region FORM VALIDATION

            approvedAmt = 0;

            double n = Convert.ToDouble(txtBxApprovedAmount.Text != "" ? txtBxApprovedAmount.Text : "0");
            double memoapprovedAmt = 0;
            var prodId = Convert.ToInt64(Session[SessionKeys.PR_ID]);

            if (txtBxApprovedAmount.Text != "")
            {
                approvedAmt = Convert.ToDouble(txtBxApprovedAmount.Text);
            }

            if (ddlApprv.SelectedItem.Text == "--Select--")
            {
                validationResult = false;
                uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_PROPOSAL_ACTION_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if ((validationResult) && txtBxApprovedAmount.Text == "")
            {
                validationResult = false;
                uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_APPROVED_AMOUNT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if ((validationResult) && approvedAmt > Convert.ToDouble(Session["Loanamt"]) && Convert.ToInt32(Session["MPS_ID"]) != 32)
            {
                validationResult = false;
                uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_APPROVED_AMOUNT_MAX_VAL, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (validationResult)
            {
                if (prodId == Convert.ToInt64(Assessed_Product_Program.Merchant_OD))
                {
                    Double.TryParse(txtBxFinalApprvedLimit.Text, out memoapprovedAmt);
                }
                else if (prodId == Convert.ToInt64(Declared_Product_Program.UnSecured_OD_Based_On_POS))
                {
                    Double.TryParse(txtBxFinalApprvedLimitODPOS.Text, out memoapprovedAmt);
                }
                else if (prodId == Convert.ToInt64(Declared_Product_Program.UnSecured_TL_Based_On_POS))
                {
                    Double.TryParse(txtBxFinalApprvedLoan.Text, out memoapprovedAmt);
                }

                if (memoapprovedAmt > 0 && memoapprovedAmt != approvedAmt)
                {
                    validationResult = false;
                    uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_MEMO_AND_FINAL_APPROV_AMT_NOT_EQUAL, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }

            if ((validationResult) && string.IsNullOrWhiteSpace(txtBxFileCreditScore.Text))
            {
                validationResult = false;
                uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_FILE_CREDIT_SCORE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            if ((validationResult) && txtBxFileCreditScore.Text != "" && Convert.ToInt32(txtBxFileCreditScore.Text) >= 100)
            {
                validationResult = false;
                uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_FILE_CREDIT_SCORE_MAX_VAL, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            if ((trBpLatDir.Visible && ddlLatDirBp.SelectedIndex == 0) || (trBpLongDir.Visible && ddlLongDirBp.SelectedIndex == 0))
            {
                validationResult = false;
                uscMsgBox1.AddMessage("Please provide Latitude/Longtitude direction for Business Premises", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            if ((trRpLatDir.Visible && ddlLatDirRp.SelectedIndex == 0) || (trRpLongDir.Visible && ddlLongDirRp.SelectedIndex == 0))
            {
                validationResult = false;
                uscMsgBox1.AddMessage("Please provide Latitude/Longtitude direction for Residence Premises", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            if ((trBpLandmark.Visible && txtBxLandMarkBp.Text == "") || (trRpLandmark.Visible && txtBxLandMarkRp.Text == ""))
            {
                validationResult = false;
                uscMsgBox1.AddMessage("Please provide Landmark details for Business/Residence Premises", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            #endregion

            #region CUSTOMER PROFILE

            if (validationResult)
            {
                List<int> checkValues = new List<int> { 46, 47, 48 };
                if (checkValues.Contains(Convert.ToInt32(Session["PR_ID"])))
                {
                    SqlConnection con1 = new SqlConnection(strcon);
                    con1.Open();

                    SqlCommand cmd1 = new SqlCommand("SELECT COUNT(CP_PRF_ID) FROM LSD_CUS_PROFILE WHERE CP_LD_ID=@LD_ID", con1);
                    cmd1.Parameters.AddWithValue("@LD_ID", Convert.ToString(Session[SessionKeys.LeadId]));
                    cmd1.CommandType = CommandType.Text;
                    int cs = ((int)cmd1.ExecuteScalar());

                    if (cs <= 0)
                    {
                        validationResult = false;
                        uscMsgBox1.AddMessage("Please Complete Customer Profile", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    con1.Close();
                }
            }

            #endregion

            #region CAM UPLOAD

            //if (validationResult)
            //{
            //    SqlConnection con1 = new SqlConnection(strcon);
            //    con1.Open();

            //    SqlCommand cmd1 = new SqlCommand("SELECT COUNT(LD_ID) FROM LSD_LEAD WHERE LD_ID = @LD_ID AND (LD_CAM_UPD_ID IS NULL OR LD_CAM_UPD_ID = 0 OR LD_CAM_UPD_SDATE IS NULL OR LD_CAM_UPD_SDATE = '')", con1);
            //    cmd1.Parameters.AddWithValue("@LD_ID", Convert.ToString(Session[SessionKeys.LeadId]));
            //    cmd1.CommandType = CommandType.Text;
            //    int cs = ((int)cmd1.ExecuteScalar());

            //    if (cs > 0)
            //    {
            //        validationResult = false;
            //        uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_CAM_UPLOAD_INCOMPLETE, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //    }
            //    con1.Close();
            //}

            #endregion

            #region TECHNICAL INITIATION
            if (validationResult)
            {
                if (Session[SessionKeys.PR_ID] != null)
                {
                    if (prodId == Convert.ToInt64(Declared_Product_Program.UnSecured_TL_Based_On_POS)
                        || prodId == Convert.ToInt64(Declared_Product_Program.UnSecured_OD_Based_On_POS)
                        || prodId == Convert.ToInt64(Assessed_Product_Program.Merchant_OD))
                    {
                        SqlConnection con = new SqlConnection(strcon);
                        con.Open();
                        SqlCommand cmd = new SqlCommand(AppConstants.Proc_RTS_SP_UNSECURED_CHECK_PENDING_TECH_INIT, con);
                        cmd.Parameters.AddWithValue("@LD_ID", Convert.ToString(Session[SessionKeys.LeadId]));
                        cmd.CommandType = CommandType.StoredProcedure;
                        DataTable cdt = new DataTable();
                        cdt.Load(cmd.ExecuteReader());

                        if (cdt.Rows.Count > 0)
                        {
                            validationResult = false;
                            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_TECH_INIT_FI_RCU_INCOMPLETE, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }

                        con.Close();
                    }
                }
            }
            #endregion

            #region CREDIT QUERY
            if (validationResult)
            {
                ldid = Convert.ToInt32(Session[SessionKeys.LeadId]);

                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = "select count(*) as count from LSD_QUERY where QRY_LD_ID='" + ldid + "' and QRY_RSD_BY='C' and QRY_RSL_DATE is NULL";
                int pendingCreditQryCount = ((int)cmd.ExecuteScalar());

                if (pendingCreditQryCount != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtBxComment.Text.Trim() == "")
                {
                    validationResult = false;
                    uscMsgBox1.AddMessage("" + pendingCreditQryCount + " Query pending, To Continue Please Enter Comments...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
            #endregion
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

        return validationResult;
    }

    private bool ValidateProposalForRejection()
    {
        bool validationResult = true;

        #region FORM VALIDATION

        approvedAmt = Convert.ToDouble(txtBxApprovedAmount.Text != "" ? txtBxApprovedAmount.Text : "0");

        if ((validationResult) && string.IsNullOrWhiteSpace(txtBxFileCreditScore.Text))
        {
            validationResult = false;
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_FILE_CREDIT_SCORE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if ((validationResult) && txtBxFileCreditScore.Text != "" && Convert.ToInt32(txtBxFileCreditScore.Text) >= 100)
        {
            validationResult = false;
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_FILE_CREDIT_SCORE_MAX_VAL, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if ((validationResult) && ddlReason.SelectedItem.Text == "--Select--")
        {
            validationResult = false;
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_REJECTION_REASON_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if ((trBpLatDir.Visible && ddlLatDirBp.SelectedIndex == 0) || (trBpLongDir.Visible && ddlLongDirBp.SelectedIndex == 0))
        {
            validationResult = false;
            uscMsgBox1.AddMessage("Please provide Latitude/Longtitude direction for Business Premises", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if ((trRpLatDir.Visible && ddlLatDirRp.SelectedIndex == 0) || (trRpLongDir.Visible && ddlLongDirRp.SelectedIndex == 0))
        {
            validationResult = false;
            uscMsgBox1.AddMessage("Please provide Latitude/Longtitude direction for Residence Premises", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if ((trBpLandmark.Visible && txtBxLandMarkBp.Text == "") || (trRpLandmark.Visible && txtBxLandMarkRp.Text == ""))
        {
            validationResult = false;
            uscMsgBox1.AddMessage("Please provide Landmark details for Business/Residence Premises", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        #endregion

        return validationResult;
    }

    private void ShowPremisesLocation(SqlConnection con)
    {
        #region DISPLAY GEO-TAGGING CONTROLS
        hdrBusinessPremises.Visible = true;
        trBpLat.Visible = true;
        trBpLatDir.Visible = true;
        trBpLong.Visible = true;
        trBpLongDir.Visible = true;
        trBpLandmark.Visible = true;

        hdrResidencePremises.Visible = true;
        trRpLat.Visible = true;
        trRpLatDir.Visible = true;
        trRpLong.Visible = true;
        trRpLongDir.Visible = true;
        trRpLandmark.Visible = true;
        #endregion

        #region LOAD GEO-TAGGING DIRECTION DDLs
        SqlCommand sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_DDL_MENU, con);
        sqlCmd.CommandType = CommandType.StoredProcedure;
        SqlParameter paramItemGroup = new SqlParameter(AppConstants.Param_Item_Group, "DIRECTION");
        SqlParameter paramItemSubGroup = new SqlParameter(AppConstants.Param_Item_SubGroup, "");
        sqlCmd.Parameters.Add(paramItemGroup);
        sqlCmd.Parameters.Add(paramItemSubGroup);
        SqlDataAdapter sqlDtAdptr = new SqlDataAdapter(sqlCmd);
        DataSet dsDirection = new DataSet();
        sqlDtAdptr.Fill(dsDirection);

        if (dsDirection != null && dsDirection.Tables.Count > 0 && dsDirection.Tables[0].Rows.Count > 0)
        {
            ddlLatDirBp.DataSource = dsDirection;
            ddlLatDirBp.DataValueField = AppConstants.Col_ITEM_KEY;
            ddlLatDirBp.DataTextField = AppConstants.Col_ITEM_DESC;
            ddlLatDirBp.DataBind();
            ddlLatDirBp.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));

            ddlLongDirBp.DataSource = dsDirection;
            ddlLongDirBp.DataValueField = AppConstants.Col_ITEM_KEY;
            ddlLongDirBp.DataTextField = AppConstants.Col_ITEM_DESC;
            ddlLongDirBp.DataBind();
            ddlLongDirBp.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));

            ddlLatDirRp.DataSource = dsDirection;
            ddlLatDirRp.DataValueField = AppConstants.Col_ITEM_KEY;
            ddlLatDirRp.DataTextField = AppConstants.Col_ITEM_DESC;
            ddlLatDirRp.DataBind();
            ddlLatDirRp.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));

            ddlLongDirRp.DataSource = dsDirection;
            ddlLongDirRp.DataValueField = AppConstants.Col_ITEM_KEY;
            ddlLongDirRp.DataTextField = AppConstants.Col_ITEM_DESC;
            ddlLongDirRp.DataBind();
            ddlLongDirRp.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
        }
        #endregion

        #region FETCH GEO-TAGGING INFO IF AVAILABLE
        sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_PREMISES_LOCATION, con);
        sqlCmd.CommandType = CommandType.StoredProcedure;
        sqlCmd.Parameters.AddWithValue(AppConstants.Param_Lead_Id, Convert.ToInt32(Session[SessionKeys.LeadId]));
        sqlDtAdptr = new SqlDataAdapter(sqlCmd);
        DataSet dsPremisesLocation = new DataSet();
        sqlDtAdptr.Fill(dsPremisesLocation);

        if (dsPremisesLocation != null && dsPremisesLocation.Tables.Count > 0 & dsPremisesLocation.Tables[0].Rows.Count == 2)
        {
            Session[SessionKeys.DATA_MANIPULATION_MODE] = Convert.ToString(DataManipulationMode.UPDATE);

            DataTable dtPremisesLocation = dsPremisesLocation.Tables[0];

            DataRow drBusinessPremises = dtPremisesLocation.Rows[0];
            txtBxLatBp.Text = Convert.ToString(drBusinessPremises[AppConstants.Col_PL_LAT]);
            txtBxLongBp.Text = Convert.ToString(drBusinessPremises[AppConstants.Col_PL_LONG]);
            ddlLatDirBp.Items.FindByText(Convert.ToString(drBusinessPremises[AppConstants.Col_PL_LAT_DIR])).Selected = true;
            ddlLongDirBp.Items.FindByText(Convert.ToString(drBusinessPremises[AppConstants.Col_PL_LONG_DIR])).Selected = true;
            txtBxLandMarkBp.Text = Convert.ToString(drBusinessPremises[AppConstants.Col_PL_LANDMARK]);

            DataRow drResidencePremises = dtPremisesLocation.Rows[1];
            txtBxLatRp.Text = Convert.ToString(drResidencePremises[AppConstants.Col_PL_LAT]);
            txtBxLongRp.Text = Convert.ToString(drResidencePremises[AppConstants.Col_PL_LONG]);
            ddlLatDirRp.Items.FindByText(Convert.ToString(drResidencePremises[AppConstants.Col_PL_LAT_DIR])).Selected = true;
            ddlLongDirRp.Items.FindByText(Convert.ToString(drResidencePremises[AppConstants.Col_PL_LONG_DIR])).Selected = true;
            txtBxLandMarkRp.Text = Convert.ToString(drResidencePremises[AppConstants.Col_PL_LANDMARK]);
        }
        else
        {
            Session[SessionKeys.DATA_MANIPULATION_MODE] = Convert.ToString(DataManipulationMode.INSERT);
        }
        #endregion
    }

    private bool SaveGeoTaggingInfo(SqlConnection con)
    {
        bool rpTransactionResult = false;
        bool bpTransactionResult = false;

        if (Session[SessionKeys.DATA_MANIPULATION_MODE] != null)
        {
            String dataManipulationMode = Convert.ToString(Session[SessionKeys.DATA_MANIPULATION_MODE]);
            String storedProcedureName = String.Empty;

            if (dataManipulationMode == Convert.ToString(DataManipulationMode.INSERT))
            {
                storedProcedureName = AppConstants.Proc_RTS_SP_INSERT_PREMISES_LOCATION;
            }
            else if (dataManipulationMode == Convert.ToString(DataManipulationMode.UPDATE))
            {
                storedProcedureName = AppConstants.Proc_RTS_SP_UPDATE_PREMISES_LOCATION;
            }

            SqlCommand cmd = new SqlCommand(storedProcedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@PL_LD_ID", SqlDbType.Int).Value = ldid;
            cmd.Parameters.Add("@PL_TYPE", SqlDbType.VarChar).Value = EnumUtils.GetEnumValue(PremisesType.BusinessPremises);
            cmd.Parameters.Add("@PL_LAT", SqlDbType.Decimal).Value = Convert.ToDouble(txtBxLatBp.Text);
            cmd.Parameters.Add("@PL_LAT_DIR", SqlDbType.VarChar).Value = ddlLatDirBp.SelectedItem.Text;
            cmd.Parameters.Add("@PL_LONG", SqlDbType.Decimal).Value = Convert.ToDouble(txtBxLongBp.Text);
            cmd.Parameters.Add("@PL_LONG_DIR", SqlDbType.VarChar).Value = ddlLongDirBp.SelectedItem.Text;
            cmd.Parameters.Add("@PL_LANDMARK", SqlDbType.VarChar).Value = txtBxLandMarkBp.Text.Trim();

            SqlParameter bpResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
            bpResult.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(bpResult);

            SqlDataAdapter sqlDtAdptr = new SqlDataAdapter(cmd);
            DataSet dsBusinessPremises = new DataSet();
            sqlDtAdptr.Fill(dsBusinessPremises);
            bpTransactionResult = Convert.ToBoolean(bpResult.Value);

            cmd = new SqlCommand(storedProcedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@PL_LD_ID", SqlDbType.Int).Value = ldid;
            cmd.Parameters.Add("@PL_TYPE", SqlDbType.VarChar).Value = EnumUtils.GetEnumValue(PremisesType.ResidencePremises);
            cmd.Parameters.Add("@PL_LAT", SqlDbType.Decimal).Value = Convert.ToDouble(txtBxLatRp.Text);
            cmd.Parameters.Add("@PL_LAT_DIR", SqlDbType.VarChar).Value = ddlLatDirRp.SelectedItem.Text;
            cmd.Parameters.Add("@PL_LONG", SqlDbType.Decimal).Value = Convert.ToDouble(txtBxLongRp.Text);
            cmd.Parameters.Add("@PL_LONG_DIR", SqlDbType.VarChar).Value = ddlLongDirRp.SelectedItem.Text;
            cmd.Parameters.Add("@PL_LANDMARK", SqlDbType.VarChar).Value = txtBxLandMarkRp.Text.Trim();

            SqlParameter rpResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
            rpResult.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(rpResult);

            sqlDtAdptr = new SqlDataAdapter(cmd);
            DataSet dsResidencePremises = new DataSet();
            sqlDtAdptr.Fill(dsResidencePremises);
            rpTransactionResult = Convert.ToBoolean(rpResult.Value);
        }

        return bpTransactionResult && rpTransactionResult;
    }

    private void ClearPremisesLocation()
    {
        txtBxLatBp.Text = "";
        txtBxLongBp.Text = "";
        txtBxLatRp.Text = "";
        txtBxLongRp.Text = "";

        if (ddlLatDirBp.Items.Count > 0) { ddlLatDirBp.SelectedIndex = 0; }
        if (ddlLongDirBp.Items.Count > 0) { ddlLongDirBp.SelectedIndex = 0; }
        if (ddlLatDirRp.Items.Count > 0) { ddlLatDirRp.SelectedIndex = 0; }
        if (ddlLongDirRp.Items.Count > 0) { ddlLongDirRp.SelectedIndex = 0; }

        txtBxLandMarkBp.Text = "";
        txtBxLandMarkRp.Text = "";

        hdrBusinessPremises.Visible = false;
        trBpLat.Visible = false;
        trBpLatDir.Visible = false;
        trBpLong.Visible = false;
        trBpLongDir.Visible = false;
        trBpLandmark.Visible = false;

        hdrResidencePremises.Visible = false;
        trRpLat.Visible = false;
        trRpLatDir.Visible = false;
        trRpLong.Visible = false;
        trRpLongDir.Visible = false;
        trRpLandmark.Visible = false;

        //Reset Session key
        if (Session[SessionKeys.DATA_MANIPULATION_MODE] != null) { Session[SessionKeys.DATA_MANIPULATION_MODE] = null; }
    }
}