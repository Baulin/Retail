﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class Letter_of_Authority : System.Web.UI.Page
{
    #region SQL FIELDS
    SqlConnection con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_Obj = new SqlCommand();
    DataTable dt_obj = new DataTable();
    CreateLogFiles Err = new CreateLogFiles();
    #endregion
    ReportDocument rpt = new ReportDocument();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {

                }
            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void chkAddrSame_CheckedChanged(object sender, EventArgs e)
    {
        if (chkAddrSame.Checked == true)
            txtBMAddreChng.Text = txtHRAddrBM.Text.Trim();
        else
            txtBMAddreChng.Text = "";
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string custoPay = getPaymentAmt();
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("RTS_SP_LOA", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.CommandTimeout = 24000000;
            cmd_Obj.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text.Trim());
            cmd_Obj.Parameters.AddWithValue("@LOA_EMP_CODE", txtBMempId.Text.Trim());
            cmd_Obj.Parameters.AddWithValue("@LOA_EMP_AGE", txtAge.Text.Trim());
            cmd_Obj.Parameters.AddWithValue("@LOA_FATHER_NAME", txtBMFatherName.Text.Trim());
            if (txtBMAddreChng.Text.Trim() != "")
                cmd_Obj.Parameters.AddWithValue("@LOA_ADDRESS", txtBMAddreChng.Text.Trim());
            else
                cmd_Obj.Parameters.AddWithValue("@LOA_ADDRESS", txtHRAddrBM.Text.Trim());
            cmd_Obj.Parameters.AddWithValue("@LOA_CBY", Session["ID"].ToString());
            #region preclosureamt
            //string custoPay = getPaymentAmt();
            if (!string.IsNullOrEmpty(custoPay))
            {
                string[] prePaymnt = custoPay.Split(',');
                cmd_Obj.Parameters.AddWithValue("@LOA_AMT", prePaymnt[1]);
                if (txtNewMobile.Text != "")
                    cmd_Obj.Parameters.AddWithValue("@LOA_PHNO", txtNewMobile.Text.Trim());
                else
                    cmd_Obj.Parameters.AddWithValue("@LOA_PHNO", prePaymnt[0]);
            }
            #endregion
            cmd_Obj.Parameters.AddWithValue("@PTYPE", "INSERTLOADDET");
           
            int res = cmd_Obj.ExecuteNonQuery();
            if (res > 0)
            {
                Clearvalues();
                clearEstimate();
                btnEstimate.Text = "Estimate";
                uscMsgBox1.AddMessage("LOA details added successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                return;
            }
            else
            {
                uscMsgBox1.AddMessage("Insertion Failed", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clearEstimate();
        btnEstimate.Text = "Estimate";
        Response.Redirect("Letter_of_Authority.aspx", false);
    }

    protected void Clearvalues()
    {
        txtLoanNo.Text = "";
        txtAppName.Text = "";
        txtCoAppName.Text = "";
        txtBMempId.Text = "";
        txtBMFatherName.Text = "";
        txtBMname.Text = "";
        txtBMAddreChng.Text = "";
        txtHRAddrBM.Text = "";
        txtAge.Text = "";
        chkAddrSame.Checked = false;
        //trAppName.Visible = false;
        //tdCoApp.Visible = false;
        hdnEmpBrId.Value = "";
        hdnLoanBrId.Value = "";
    }

    protected void chkExists()
    {
        try
        {
            string isExists = string.Empty;
            //int isExists;
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("RTS_SP_LOA", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.CommandTimeout = 24000000;
            cmd_Obj.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text.Trim());
            cmd_Obj.Parameters.AddWithValue("@PTYPE", "CHKEXISTS");
            isExists = Convert.ToString(cmd_Obj.ExecuteScalar());
            //isExists = Convert.ToInt16(cmd_Obj.ExecuteScalar());
            if (!string.IsNullOrEmpty(isExists))
            //if (isExists != 0)
            {
                btnSubmit.Enabled = false;
                uscMsgBox1.AddMessage("LOA details already submitted", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            else
                btnSubmit.Enabled = true;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    protected void imgLoansrch_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            chkExists();
            DataSet ds = new DataSet();
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("RTS_SP_LOA", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.CommandTimeout = 24000000;
            cmd_Obj.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text.Trim());
            cmd_Obj.Parameters.AddWithValue("@PTYPE", "CHKLOANNO");
            string hoRcvdate = Convert.ToString(cmd_Obj.ExecuteScalar());
            if (!string.IsNullOrEmpty(hoRcvdate))
            {
                cmd_Obj = new SqlCommand("RTS_SP_LOA", con_Obj);
                cmd_Obj.CommandType = CommandType.StoredProcedure;
                cmd_Obj.CommandTimeout = 24000000;
                cmd_Obj.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text.Trim());
                cmd_Obj.Parameters.AddWithValue("@PTYPE", "GETAPPCOAPP");
                SqlDataAdapter da = new SqlDataAdapter(cmd_Obj);
                da.Fill(ds);
                if (ds.Tables[3].Rows.Count > 0)
                {
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        //hdnLoanBrId.Value = Convert.ToString(ds.Tables[1].Rows[0]["LD_BR_ID"]);
                        //if (!string.IsNullOrEmpty(Convert.ToString(hdnEmpBrId.Value)) && (hdnEmpBrId.Value != hdnLoanBrId.Value))
                        //{
                        //    uscMsgBox1.AddMessage("The BM branch and Loan branch are mismatched", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        //    return;
                        //}
                        //else
                        //{
                            if (ds.Tables[0].Rows.Count > 0)
                            {
                                txtAppName.Text = (from DataRow dr in ds.Tables[0].Rows
                                                   where (string)dr["MCB_TYPE"] == "A"
                                                   select (string)dr["CO-BORROWER"]).FirstOrDefault();
                                string[] cbrw = ds.Tables[0].AsEnumerable().Where(x => x.Field<string>("MCB_TYPE") == "C").Select(x => x.Field<string>("CO-BORROWER")).ToArray();
                                string coBorrower = string.Empty;
                                foreach (string s in cbrw)
                                {
                                    if (string.IsNullOrEmpty(coBorrower))
                                        coBorrower += s;
                                    else
                                    {
                                        coBorrower += "\n";
                                        coBorrower += s;
                                    }
                                }
                                txtCoAppName.Text = Convert.ToString(coBorrower);
                                //trAppName.Visible = true;
                                //tdCoApp.Visible = true;
                            }
                            else
                            {
                                //trAppName.Visible = false;
                                //tdCoApp.Visible = false;
                            }
                            if (ds.Tables[2].Rows.Count > 0)
                            {
                                txtLdNo.Text = Convert.ToString(ds.Tables[2].Rows[0]["LD_NO"]);
                            }
                        //}
                    }
                }
                else
                {
                    uscMsgBox1.AddMessage("The loan is not Live", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Please input the correct loan number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    protected void imgBMSrch_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("RTS_SP_LOA", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.CommandTimeout = 24000000;
            cmd_Obj.Parameters.AddWithValue("@BM_EMP_CODE", txtBMempId.Text.Trim());
            cmd_Obj.Parameters.AddWithValue("@PTYPE", "GETBMDET");
            dt_obj = new DataTable();
            dt_obj.Load(cmd_Obj.ExecuteReader());

            if (dt_obj.Rows.Count > 0)
            {
                hdnEmpBrId.Value = Convert.ToString(dt_obj.Rows[0]["EMP_BR_ID"]);
                //if (!string.IsNullOrEmpty(Convert.ToString(hdnLoanBrId.Value)) && (hdnEmpBrId.Value != hdnLoanBrId.Value))
                //{
                //    uscMsgBox1.AddMessage("The BM branch and Loan branch are mismatched", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //    return;
                //}
                //else
                //{
                    txtBMname.Text = Convert.ToString(dt_obj.Rows[0]["EMP_NAME"]);
                    txtAge.Text = Convert.ToString(dt_obj.Rows[0]["AGE"]);
                    //txtHRAddrBM.Text = Convert.ToString(dt_obj.Rows[0]["EMP_ADDR"]);
                    string bmAddr = Convert.ToString(dt_obj.Rows[0]["EMP_ADDR"]);
                    if (!string.IsNullOrEmpty(bmAddr))
                    {
                        txtHRAddrBM.Text = Convert.ToString(dt_obj.Rows[0]["EMP_ADDR"]);
                        chkAddrSame.Enabled = true;
                    }
                    else
                        chkAddrSame.Enabled = false;
                //}
            }
            else
            {
                uscMsgBox1.AddMessage("Employee Id not exists or not a Branch Manager", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    protected void btnEstimate_Click(object sender, EventArgs e)
    {
        DataTable dtEsimate = new DataTable();
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            if (btnEstimate.Text != "Print")
            {
                cmd_Obj = new SqlCommand("RTS_PRECLOSURE_RPT", con_Obj);
                cmd_Obj.CommandType = CommandType.StoredProcedure;
                cmd_Obj.CommandTimeout = 24000000;
                cmd_Obj.Parameters.AddWithValue("@LNNO", txtLoanNo.Text.Trim());
                dtEsimate.Load(cmd_Obj.ExecuteReader());
                if (dtEsimate.Rows.Count > 0)
                {
                    divMain.Visible = true;
                    string dateTimeAson = Serverdate();
                    lblDate.Text = dateTimeAson;
                    lblDatebal.Text = dateTimeAson;
                    lblCusName.Text = Convert.ToString(dtEsimate.Rows[0][1]);
                    lblCusMobile.Text = Convert.ToString(dtEsimate.Rows[0][2]);
                    lblRIAReceivable.Text = Convert.ToString(dtEsimate.Rows[0][3]);
                    lblRIAReceived.Text = Convert.ToString(dtEsimate.Rows[0][4]);
                    lblRIADue.Text = Convert.ToString(dtEsimate.Rows[0][5]);
                    lblCBCReceivable.Text = Convert.ToString(dtEsimate.Rows[0][6]);
                    lblCBCReceived.Text = Convert.ToString(dtEsimate.Rows[0][7]);
                    lblCBCDue.Text = Convert.ToString(dtEsimate.Rows[0][8]);
                    lblODReceivable.Text = Convert.ToString(dtEsimate.Rows[0][9]);
                    lblODReceived.Text = Convert.ToString(dtEsimate.Rows[0][10]);
                    lblODDue.Text = Convert.ToString(dtEsimate.Rows[0][11]);
                    lblBalanceReceivable.Text = Convert.ToString(dtEsimate.Rows[0][12]);
                    lblBalReceived.Text = Convert.ToString(dtEsimate.Rows[0][13]);
                    lblBalDue.Text = Convert.ToString(dtEsimate.Rows[0][14]);
                    lblBalance.Text = Convert.ToString(dtEsimate.Rows[0][14]);
                    lblFuturePrincipal.Text = Convert.ToString(dtEsimate.Rows[0][15]);
                    lblBI.Text = Convert.ToString(dtEsimate.Rows[0][16]);
                    lblPrepayChrg.Text = Convert.ToString(dtEsimate.Rows[0][17]);
                    lblIDP.Text = Convert.ToString(dtEsimate.Rows[0][18]);
                    lblTotDue.Text = Convert.ToString(dtEsimate.Rows[0][19]);
                    lblChqBounce.Text = Convert.ToString(dtEsimate.Rows[0][20]);
                    lblBnkngSts.Text = Convert.ToString(dtEsimate.Rows[0][21]);
                    btnEstimate.Text = "Print";
                }
                else
                {
                    uscMsgBox1.AddMessage("Please enter the valid loan number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
            }
            else
            {
                Print();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    protected string Serverdate()
    {
        string date = string.Empty;
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select CONVERT(nvarchar(20),GETDATE(),105)", con_Obj);
            date = Convert.ToString(cmd_Obj.ExecuteScalar());
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);            
        }
        return date;
    }

    protected void Print()
    {
        try
        {
            rpt = new ReportDocument();
            //set a ReportPath and assign the dataset to reportdocument object
            rpt.Load(Server.MapPath("Reports/Preclosure.rpt"));

            string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

            //assign the values to crystal report viewer
            rpt.SetParameterValue(0, txtLoanNo.Text.Trim());
            rpt.SetParameterValue(1, Session["UNIT"].ToString().ToUpper());
            rpt.SetParameterValue(2, Session["UNITNAME"].ToString());

            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Preclosure/Closure Letter For " + txtLoanNo.Text.Trim() + "");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    protected void clearEstimate()
    {
        lblDate.Text = "";
        lblDatebal.Text = "";
        lblCusName.Text = "";
        lblCusMobile.Text = "";
        lblRIAReceivable.Text = "";
        lblRIAReceived.Text = "";
        lblRIADue.Text = "";
        lblCBCReceivable.Text = "";
        lblCBCReceived.Text = "";
        lblCBCDue.Text = "";
        lblODReceivable.Text = "";
        lblODReceived.Text = "";
        lblODDue.Text = "";
        lblBalanceReceivable.Text = "";
        lblBalReceived.Text = "";
        lblBalDue.Text = "";
        lblBalance.Text = "";
        lblFuturePrincipal.Text = "";
        lblBI.Text = "";
        lblPrepayChrg.Text = "";
        lblIDP.Text = "";
        lblTotDue.Text = "";
    }

    protected string getPaymentAmt()
    {
        string payAmt = string.Empty;
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("RTS_SP_LOA", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.CommandTimeout = 24000000;
            cmd_Obj.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text.Trim());
            cmd_Obj.Parameters.AddWithValue("@PTYPE", "GETPRECLSAMT");
            //payAmt = Convert.ToString(cmd_Obj.ExecuteScalar());
            SqlDataReader dr = cmd_Obj.ExecuteReader();
            while(dr.Read())
            {
                payAmt += Convert.ToString(dr["Cust_Mobile"]);
                payAmt += "," + Convert.ToString(dr["Total_Due_From_Customer"]);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
        return payAmt;
    }
}