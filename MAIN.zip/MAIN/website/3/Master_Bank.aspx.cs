﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_Bank : System.Web.UI.Page
{
    int areaid;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                bind();

                BankList();
               
            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    public void bind()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            //SqlCommand cmd = new SqlCommand("select BR_ID,BR_CODE 'BR. CODE',BR_NAME 'BR. NAME',BR_CITY 'CITY',BR_CTPERSON 'CONTACT PERSON',BR_PHNO 'CONTACT NO.' from MR_BRANCH", con);
            SqlCommand cmd = new SqlCommand("RTS_SP_BIND_MR_BANK", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@BK_NAME", ddlSearchBank.SelectedItem.Text != "--Select--" ? Convert.ToString(ddlSearchBank.SelectedItem.Text) : "");
            cmd.Parameters.AddWithValue("@BK_BRANCH", ddlSearchBranch.SelectedItem.Text != "--Select--" ? Convert.ToString(ddlSearchBranch.SelectedValue) : "");
            cmd.Parameters.AddWithValue("@BK_IFSC", txtSearchIFSCCode.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            gvBank.DataSource = ds;
            gvBank.DataBind();
        
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow grow in gvBank.Rows)
            {
                RadioButton chkUserID = (RadioButton)grow.FindControl("rb_select");
                if (chkUserID.Checked)
                {
                    Label lblBR_ID = (Label)grow.FindControl("lblBR_ID");
                    DataSet ds = new DataSet();
                    ds = clscommon.Bind_FETCH_DETAILS_BRANCH(lblBR_ID.Text);
                   /* txtBrcode.Text = ds.Tables[0].Rows[0]["BR_CODE"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_CODE"].ToString() : "";
                    txtBrname.Text = ds.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                    txtAddr1.Text = ds.Tables[0].Rows[0]["BR_ADD1"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_ADD1"].ToString() : "";
                    txtAddr2.Text = ds.Tables[0].Rows[0]["BR_ADD2"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_ADD2"].ToString() : "";
                    txtbrVFcode.Text = ds.Tables[0].Rows[0]["BR_VFCODE"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_VFCODE"].ToString() : "";
                    txtHFbrcode.Text = ds.Tables[0].Rows[0]["BR_HFCODE"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_HFCODE"].ToString() : "";
                    txtVFbrname.Text = ds.Tables[0].Rows[0]["BR_VFBRANCH"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_VFBRANCH"].ToString() : "";
                    txtHFbrname.Text = ds.Tables[0].Rows[0]["BR_HFBRANCH"] != DBNull.Value ? ds.Tables[0].Rows[0]["BR_HFBRANCH"].ToString() : "";*/
                    btnSubmit.Text = "Update";
                    Session["BR_ID"] = lblBR_ID.Text;
                    break;
                }
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {

            //e.Row.Cells[0].Width = new Unit("127px");

            //e.Row.Cells[1].Width = new Unit("279px");
            //e.Row.Cells[2].Width = new Unit("116px");
            //e.Row.Cells[3].Width = new Unit("59px");
            //e.Row.Cells[4].Width = new Unit("73px");

        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            //e.Row.Cells[0].Width = new Unit("135px");

            //e.Row.Cells[1].Width = new Unit("298px");
            //e.Row.Cells[2].Width = new Unit("122px");
            //e.Row.Cells[3].Width = new Unit("59px");
            //e.Row.Cells[4].Width = new Unit("73px");

            //if (e.Row.RowIndex == 0)
            //    e.Row.Style.Add("height", "50px");
            //e.Row.VerticalAlign = VerticalAlign.Bottom;
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            /* SqlCommand stcmd = new SqlCommand("select AR_ID from MR_AREA where AR_NAME='" + ddlArea.SelectedValue.ToString() + "'", con);
             SqlDataAdapter stda = new SqlDataAdapter(stcmd);
             DataSet stds = new DataSet();
             stda.Fill(stds);

             areaid = Convert.ToInt32(stds.Tables[0].Rows[0]["AR_ID"]);
            
             SqlCommand insertcmd = new SqlCommand("insert into MR_BRANCH(BR_CODE,BR_NAME,BR_ADD1,BR_ADD2,BR_CITY,BR_PINCODE,BR_AR_ID,BR_CTPERSON,BR_PHNO,BR_EMAILID,BR_VFCODE,BR_VFBRANCH,BR_HFCODE,BR_HFBRANCH,BR_CBY,BR_CDATE,BR_STATUS,BR_TYPE) values ('" + txtBrcode.Text.ToUpper() + "','" + txtBrname.Text.ToUpper() + "','" + txtAddr1.Text.ToUpper() + "','" + txtAddr2.Text.ToUpper() + "','" + txtCity.Text.ToUpper() + "','" + txtPincode.Text + "','" + areaid + "','" + txtContactperson.Text.ToUpper() + "','" + txtContactno.Text + "','" + txtEmailid.Text.ToUpper() + "','" + txtbrVFcode.Text.ToUpper() + "','" + txtVFbrname.Text.ToUpper() + "','" + txtHFbrcode.Text.ToUpper() + "','" + txtHFbrname.Text.ToUpper() + "','" + Session["ID"].ToString() + "',getdate(),'" + ddlstatus.SelectedValue + "','" + ddlBranchType.SelectedValue.ToString() + "')", con);
             insertcmd.ExecuteNonQuery();*/
            int cntBank=0;
            cntBank = clscommon.Bind_MR_BANK_Count(txtIFSCCode.Text.Trim());
            if (cntBank == 0)
            {

                string strStat = "";
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_BIND_MR_BANK", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                if (btnSubmit.Text == "Submit")
                {
                    cmdinsert.Parameters.AddWithValue("@TYPE", "INSERT");
                    strStat = "Bank Added Successfully";
                }
                else
                    if (btnSubmit.Text == "Update")
                    {
                        cmdinsert.Parameters.AddWithValue("@TYPE", "UPDATE");
                        strStat = "Bank has been updated successfully.";
                    }
                cmdinsert.Parameters.AddWithValue("@BK_CODE", txtBankCode.Text);
                cmdinsert.Parameters.AddWithValue("@BK_NAME", ddlBank.SelectedItem.Text);
                cmdinsert.Parameters.AddWithValue("@BK_BRANCH", txtBankBranch.Text);
                cmdinsert.Parameters.AddWithValue("@BK_MICR", txtMICR.Text);

                cmdinsert.Parameters.AddWithValue("@BK_IFSC", txtIFSCCode.Text);
                cmdinsert.Parameters.AddWithValue("@BK_ADDRESS", txtAddress.Text);
                cmdinsert.Parameters.AddWithValue("@BK_CITY", txtCity.Text);
                cmdinsert.Parameters.AddWithValue("@BK_STATE", txtState.Text);

                cmdinsert.Parameters.AddWithValue("@ID", Convert.ToString(Session["ID"]));
                //cmdinsert.Parameters.AddWithValue("@BR_ID", Convert.ToString(Session["BR_ID"]));
                //cmdinsert.Parameters.AddWithValue("@BK_STAT", SqlDbType.VarChar).Direction = ParameterDirection.Output;
                cmdinsert.ExecuteNonQuery();

                // strStat = Convert.ToString(cmdinsert.Parameters["@BK_STAT"].Value);

                ddlBank.SelectedValue = "0";
                txtBankCode.Text = "";
                txtBankBranch.Text = "";
                txtMICR.Text = "";
                txtIFSCCode.Text = "";
                txtCity.Text = "";
                txtState.Text = "";
                txtAccountNo.Text = "";
                txtAddress.Text = "";
                ddlSearchBank.SelectedValue = "0";
                ddlSearchBranch.SelectedValue = "0";
                txtSearchIFSCCode.Text = "";
                bind();

                /*   txtBrcode.Text = "";
                   txtBrname.Text = "";
                   txtAddr1.Text = "";
                   txtAddr2.Text = "";
          
                   txtbrVFcode.Text = "";
                   txtVFbrname.Text = "";
                   txtHFbrcode.Text = "";
                   txtHFbrname.Text = "";*/

                btnSubmit.Text = "Submit";
                uscMsgBox1.AddMessage(strStat, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
            else
            {
                uscMsgBox1.AddMessage("Record Already Exist.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_Branch.aspx");
    }
    public static void MakeAccessible(GridView grid)
    {
        if (grid.Rows.Count <= 0) return;
        grid.UseAccessibleHeader = true;
        grid.HeaderRow.TableSection = TableRowSection.TableHeader;
        if (grid.ShowFooter)
            grid.FooterRow.TableSection = TableRowSection.TableFooter;
    }
    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);

        MakeAccessible(gvBank);
    }
    protected void gvBank_PageIndexChanged(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvBank.PageIndex = e.NewPageIndex;
            bind();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlSearchBank_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet dt = new DataSet();
            dt = clscommon.BindBankDetails_ByBankCode(ddlSearchBank.SelectedValue);
            ddlSearchBranch.DataSource = dt;
            ddlSearchBranch.DataTextField = "BK_BRANCH";
            ddlSearchBranch.DataValueField = "BK_BRANCH";
            ddlSearchBranch.DataBind();
            ddlSearchBranch.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        bind();
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {

    }
    public void BankList()
    {

        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_NACH_BIND_BANK", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        //cmddd.Parameters.AddWithValue("@BankName", "");
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        Session["Bank"] = dsdd.Tables[0];
        con.Close();
        ddlSearchBank.DataSource = dsdd;
        ddlSearchBank.DataTextField = "BK_NAME";
        ddlSearchBank.DataValueField = "BK_CODE";
        ddlSearchBank.DataBind();
        ddlSearchBank.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));

        ddlBank.DataSource = dsdd;
        ddlBank.DataTextField = "BK_NAME";
        ddlBank.DataValueField = "BK_CODE";
        ddlBank.DataBind();
        ddlBank.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));

    }
    protected void ddlBank_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlBank.SelectedItem.Text != "--Select")
            {
                txtBankCode.Text = Convert.ToString(ddlBank.SelectedValue);
                
            }
            else
            {
                txtBankCode.Text = "";
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}