﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class HO_OPS_PRE_Receive_ACK : System.Web.UI.Page
{

    #region Common
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    string leadno = string.Empty;
    string appname = string.Empty;
    string pddt = string.Empty;
    string lnamt = string.Empty;
    string loanno = string.Empty;
    string filePath = string.Empty;
    string loannum = string.Empty;
    CreateLogFiles Err = new CreateLogFiles();
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {            
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                    bind();
                    //BindCourierName();
                }

            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    //protected void btnSubmit_Click(object sender, EventArgs e)
    //{

    //}
    //protected void btnCancel_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("HO_OPS_PRE_Receive_ACK.aspx");
    //}

    protected void btnView_Click(object sender, EventArgs e)
    {
        bind1();
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
    }

    public void getLoanNo(SqlConnection con)
    {
        SqlCommand cmdbr = new SqlCommand();
        con = new SqlConnection(strcon);
        try
        {
            con.Open();
            cmdbr = new SqlCommand("select LD_LOAN_NO from LSD_LEAD where LD_NO ='" + Convert.ToString(Session["LeadId"]) + "'", con);
            loanno = Convert.ToString(cmdbr.ExecuteScalar());
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
            cmdbr.Dispose();
        }
    }

    protected void DownloadFile(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            trPod.Visible = true;
            filePath = (sender as LinkButton).CommandArgument;
            Session["LeadId"] = filePath;
            txtLeadno.Text = filePath;
            getLead(con);
            //Update();
            //AckDownload();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {

        }
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        trPod.Visible = true;
        SqlConnection con = new SqlConnection(strcon);
        foreach (GridViewRow grow in gvHORecvPreAck.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            LinkButton lnbtn = grow.FindControl("lnk_Rec_Dwnld") as LinkButton;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                //getLeadID(con);
                filePath = lnbtn.Text;
                Session["LeadId"] = filePath;
                LinkButton lnbtnloan = grow.FindControl("lnkLoan") as LinkButton;
                loannum = lnbtnloan.Text.Trim();
                txtLeadno.Text = loannum;
                getPOD(con);
                getLead(con);
                //Update();
                //AckDownload();
                break;
            }
        }
    }

    protected void AckDownload()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            //getLoanNo(con);
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            //con.Open();
            SqlCommand cmd = new SqlCommand("select LD_NO from LSD_LEAD where LD_ID ='" + Session["IDLead"] + "' ", con);
            string ldno = Convert.ToString(cmd.ExecuteScalar());
            cmd.Dispose();
            //string filename = filePath.Substring(filePath.Length - 5) + loanno;
            string filename = ldno.Substring(ldno.Length - 5) + txtLeadno.Text.Trim();
            string[] fileNames = Directory.GetFiles(Server.MapPath("~\\Upload\\Acknowledgement\\"));
            string f = "";
            int nameIndex = 0;
            string[] file;
            foreach (var item in fileNames)
            {
                double length = new FileInfo(item).Length / 1024;
                nameIndex = item.LastIndexOf("\\") + 1;
                f = item.Remove(0, nameIndex);
                f = f.Remove(f.Length - 4);
                file = f.Split('.');
                if (filename == file[0])
                {
                    filePath = item;
                    break;
                }
            }
            Response.ContentType = ContentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
            Response.WriteFile(filePath);
            //Response.End();
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //bind1();
        }
    }

    protected void Update()
    {
        SqlConnection con = new SqlConnection(strcon);
        SqlCommand cmdUpdate = new SqlCommand();
        try
        {
            //getLeadID(con);
            con.Open();
            string qry = "UPDATE LSD_MOTD SET MD_PHO_RDATE = GETDATE() WHERE MD_LD_ID= " + Convert.ToString(Session["IDLead"]) + "";
            cmdUpdate = new SqlCommand(qry, con);
            //int res = cmdUpdate.ExecuteNonQuery();
            int res = 1;
            if (res > 0)
                AckDownload();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
            cmdUpdate.Dispose();
        }
    }

    public void getLeadID(SqlConnection con)
    {
        try
        {
            SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
            cmdbr.CommandType = CommandType.StoredProcedure;
            cmdbr.Parameters.AddWithValue("@LeadNo", Session["LeadId"].ToString());
            SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
            DataSet dsbr = new DataSet();
            dabr.Fill(dsbr);
            Session["IDLead"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void lnkname_OnClick(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(strcon);
        //try
        //{
        string loanno = ((LinkButton)sender).Text;
        txtLeadno.Text = loanno;
        //    con.Open();
        //    //getLead(con);
        //    getPOD(con);
        //}
        //catch (Exception ex)
        //{
        //    uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        //}
        //finally
        //{
        //    con.Close();

        //}
    }

    protected void getPOD(SqlConnection con)
    {
        try
        {
            SqlCommand cmd = new SqlCommand("select MD_PHO_POD_NO,CR.CR_NAME from LSD_MOTD MD inner join MR_COURIER CR  on CR.CR_ID = MD.MD_PHO_CR_ID  where MD_LD_ID = (select LD_ID from LSD_LEAD where LD_LOAN_NO = '" + txtLeadno.Text.Trim().ToString() + "')", con);
            DataTable dtpod = new DataTable();
            con.Open();
            dtpod.Load(cmd.ExecuteReader());
            if (dtpod.Rows.Count > 0)
            {
                txtCourier.Text = Convert.ToString(dtpod.Rows[0][1]);
                txtPODNo.Text = Convert.ToString(dtpod.Rows[0][0]);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //cmd.Dispose();
            con.Close();
            SqlConnection.ClearPool(con);
        }
    }

    public void getLead(SqlConnection con)
    {
        using (SqlCommand cmdbr = new SqlCommand("SP_UNO_BIND_LOAN", con))
        {
            try
            {
                con.Open();
                cmdbr.CommandType = CommandType.StoredProcedure;
                cmdbr.CommandTimeout = 2400000;
                cmdbr.Parameters.AddWithValue("@LOANNO", txtLeadno.Text.Trim());
                cmdbr.Parameters.AddWithValue("@PTYPE", "GETLEADID");
                string lead = Convert.ToString(cmdbr.ExecuteScalar());
                string[] leadDet = lead.Split(',');
                Session["Lead"] = leadDet[1];
                Session["IDLead"] = leadDet[0];
                if (!string.IsNullOrEmpty(Convert.ToString(Session["Lead"])))
                    Update();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmdbr.Dispose();
                con.Close();
                SqlConnection.ClearPool(con);
            }
        }

    }

    protected void bind1()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_ReceiveDoc", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PR_ID", "0");
            cmd.Parameters.AddWithValue("@LD_BR_ID", ddlBranch.SelectedIndex > 0 ? ddlBranch.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@LD_AR_ID", ddlArea.SelectedIndex > 0 ? ddlArea.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@ReceiveType", "HOACKR");
            cmd.Parameters.AddWithValue("@LoanNo", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@Type", "P");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    Session["Leadno"] = ds.Tables[0].Rows[0]["LD_NO"];
            //    //getPOD(con);  
            //    getLead(con);
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("Acknowledgement not Received", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            gvHORecvPreAck.DataSource = ds.Tables[0];
            gvHORecvPreAck.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                RegisterPostBackControl();
                gvHORecvPreAck.HeaderRow.Font.Bold = true;
                gvHORecvPreAck.HeaderRow.Cells[1].Text = "LOAN NO";
                gvHORecvPreAck.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvHORecvPreAck.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvHORecvPreAck.HeaderRow.Cells[4].Text = "PD DATE";
                gvHORecvPreAck.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvHORecvPreAck.HeaderRow.Cells[6].Text = "BRANCH NAME";


                gvHORecvPreAck.HeaderRow.Cells[1].Wrap = false;
                gvHORecvPreAck.HeaderRow.Cells[2].Wrap = false;
                gvHORecvPreAck.HeaderRow.Cells[3].Wrap = false;
                gvHORecvPreAck.HeaderRow.Cells[4].Wrap = false;
                gvHORecvPreAck.HeaderRow.Cells[5].Wrap = false;
                gvHORecvPreAck.HeaderRow.Cells[6].Wrap = false;

            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    private void RegisterPostBackControl()
    {
        foreach (GridViewRow row in gvHORecvPreAck.Rows)
        {
            LinkButton lnkFull = row.FindControl("lnkLoan") as LinkButton;
            ScriptManager.GetCurrent(this).RegisterPostBackControl(lnkFull);
            RadioButton rbtnFull = row.FindControl("rb_select") as RadioButton;
            ScriptManager.GetCurrent(this).RegisterPostBackControl(rbtnFull);
        }
    }
}