﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Tracker;
using Utilities;

public partial class HOOps_Disb_QCQuery : System.Web.UI.Page
{
    int ldid;
    int ftid;
    public string status = "";
    string leadno = "";
    string appname;
    string pddt;
    string lnamt;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string bcc3;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    public static DataTable dtQuery = null;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    public static bool blMailStatus = false;
    ClsCommon clscommon = new ClsCommon();
   protected void Page_Load(object sender, EventArgs e)
    {
        MICR_NO.Visible = false;
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
            }
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
    }


    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        //   ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();
    }
    protected void cb_selectheader_SelectedIndexChanged(object sender, EventArgs e)
    {
        CheckBox chkheader = gvQuerydets.HeaderRow.FindControl("cb_selectheader") as CheckBox;
        if (chkheader.Checked)
        {
            foreach (GridViewRow grow in gvQuerydets.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                chkStat.Checked = true;
                TextBox txtRmrks = grow.FindControl("txtRemarks") as TextBox;
                txtRmrks.Enabled = true;
            }
        }
        else
        {
            foreach (GridViewRow grow in gvQuerydets.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                chkStat.Checked = false;
                TextBox txtRmrks = grow.FindControl("txtRemarks") as TextBox;
                txtRmrks.Enabled = false;
            }
        }
    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void cb_select_CheckedChanged(object sender, EventArgs e)
    {
        foreach (GridViewRow grow in gvQuerydets.Rows)
        {
            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                txtRemarks.Enabled = true;

            }
            else
            {
                txtRemarks.Enabled = false;
                txtRemarks.Text = "";
            }
        }
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
    }
    protected void cb_select_CheckedChanged1(object sender, EventArgs e)
    {
        foreach (GridViewRow grow in gvUserInfo.Rows)
        {
            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
            int index = grow.RowIndex;
            GridView gvQueries = (GridView)grow.FindControl("gvQueries");


            if (chkStat.Checked)
            {
                CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                chkStat1.Enabled = true;
                //txtRemarks.Enabled = true ;
                foreach (GridViewRow growQuery in gvQueries.Rows)
                {

                    CheckBox chkQuery = growQuery.FindControl("chkQuery") as CheckBox;
                    TextBox txtRemarks1 = growQuery.FindControl("txtRemarks1") as TextBox;
                    RadioButtonList rblDesc = growQuery.FindControl("rblDesc") as RadioButtonList;
                    chkQuery.Enabled = true;
                    txtRemarks1.Enabled = true;
                    rblDesc.Enabled = true;
                    
                }
            }
            else
            {
                CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                int index1 = grow.RowIndex;
                foreach (ListItem i in chkStat1.Items)
                {
                    i.Selected = false;

                }
                foreach (GridViewRow growQuery in gvQueries.Rows)
                {

                    CheckBox chkQuery = growQuery.FindControl("chkQuery") as CheckBox;
                    TextBox txtRemarks1 = growQuery.FindControl("txtRemarks1") as TextBox;
                    RadioButtonList rblDesc = growQuery.FindControl("rblDesc") as RadioButtonList;
                    chkQuery.Enabled = false;
                    chkQuery.Checked = false;
                    txtRemarks1.Visible = false;
                    rblDesc.Enabled = false;
                }
                chkStat1.Enabled = false;
                txtRemarks.Enabled = true;
            }
        }
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
            gvQuerydets.Visible = false;
            MICR_NO.Visible = false;
            //if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            //{
            //    Session["View"] = "A";
            //    gridbindall();
            //}
            //else if (txtLeadno.Text != "")// && ddlBranch.SelectedItem.Text == "--Select--"
            //{
            //    Session["View"] = "F";

            //    gridbind();
            //}
            //else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--")//&& ddlBranch.SelectedItem.Text != "--Select--"
            //{
            //    Session["View"] = "F";
            //    gridbind();
            //}
            gridbind();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        
    }
   /* public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = null;

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                // cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
                cmd = new SqlCommand("select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_CRAP_AMT 'LOAN AMOUNT',MPS.MPS_NAME 'SCHEME',case  when (select COUNT(*)  from LSD_DISB_QUERY where QRY_LD_ID=LD_ID  and QRY_RSD_BY ='H') > 0 then 'T' else 'F'  end as QueryResult,MP.PR_CODE,LD_SANTD_NO  from LSD_LEAD A LEFT JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_DISB_QUERY E ON A.LD_ID=E.QRY_LD_ID  LEFT JOIN MR_PRODUCT MP ON A.LD_PR_ID =MP.PR_ID LEFT JOIN MR_PROD_SCHEME MPS ON MPS.MPS_ID=A.LD_MPS_ID   WHERE  FT_SENTBY='D' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' AND ISNULL(LD_RDY_MDATE,'')='' and D.AR_ST_ID='" + Session["STATEID"].ToString() + "' ORDER BY LD_NO", con);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                //cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
                cmd = new SqlCommand("select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_CRAP_AMT 'LOAN AMOUNT',MPS.MPS_NAME 'SCHEME',case  when (select COUNT(*)  from LSD_DISB_QUERY where QRY_LD_ID=LD_ID  and QRY_RSD_BY ='H') > 0 then 'T' else 'F'  end as QueryResult,MP.PR_CODE,LD_SANTD_NO  from LSD_LEAD A LEFT JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_DISB_QUERY E ON A.LD_ID=E.QRY_LD_ID  LEFT JOIN MR_PRODUCT MP ON A.LD_PR_ID =MP.PR_ID LEFT JOIN MR_PROD_SCHEME MPS ON MPS.MPS_ID=A.LD_MPS_ID  WHERE  FT_SENTBY='D' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' AND ISNULL(LD_RDY_MDATE,'')='' and D.AR_DV_ID='" + Session["DIVID"].ToString() + "' ORDER BY LD_NO", con);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                //cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
                cmd = new SqlCommand("select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_CRAP_AMT 'LOAN AMOUNT',MPS.MPS_NAME 'SCHEME',case  when (select COUNT(*)  from LSD_DISB_QUERY where QRY_LD_ID=LD_ID  and QRY_RSD_BY ='H') > 0 then 'T' else 'F'  end as QueryResult,MP.PR_CODE,LD_SANTD_NO  from LSD_LEAD A LEFT JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_DISB_QUERY E ON A.LD_ID=E.QRY_LD_ID  LEFT JOIN MR_PRODUCT MP ON A.LD_PR_ID =MP.PR_ID LEFT JOIN MR_PROD_SCHEME MPS ON MPS.MPS_ID=A.LD_MPS_ID  WHERE  FT_SENTBY='D' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' AND ISNULL(LD_RDY_MDATE,'')='' and D.AR_ID='" + Session["AREA_ID"].ToString() + "' ORDER BY LD_NO", con);
            }

            else
            {
                cmd = new SqlCommand("select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_CRAP_AMT 'LOAN AMOUNT',MPS.MPS_NAME 'SCHEME',case  when (select COUNT(*)  from LSD_DISB_QUERY where QRY_LD_ID=LD_ID  and QRY_RSD_BY ='H') > 0 then 'T' else 'F'  end as QueryResult,MP.PR_CODE,LD_SANTD_NO  from LSD_LEAD A LEFT JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_DISB_QUERY E ON A.LD_ID=E.QRY_LD_ID  LEFT JOIN MR_PRODUCT MP ON A.LD_PR_ID =MP.PR_ID LEFT JOIN MR_PROD_SCHEME MPS ON MPS.MPS_ID=A.LD_MPS_ID  WHERE  FT_SENTBY='D' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' AND ISNULL(LD_RDY_MDATE,'')='' ORDER BY LD_NO", con);
            }
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "SANCTION NO";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    */
    public void gridbind()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = null;
            cmd = new SqlCommand("RTS_SP_DISB_RAISE_QUERY", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", Convert.ToString(txtLeadno.Text) != "" ? txtLeadno.Text : "");
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@USR_ACS_TYPE", Session["USR_ACS"].ToString());
           
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            foreach (GridViewRow grow in gvQuery.Rows)
            {
                Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                Label lblLglStat = (Label)grow.FindControl("lblLglStat");

                int index = grow.RowIndex;
                if (lblQryResult.Text == "T")
                {
                    gvQuery.Rows[index].Cells[1].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[2].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[3].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[4].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[5].ForeColor = Color.Red;
                }
                if (lblLglStat.Text == "APPROVED")
                {
                    //grow.BackColor = System.Drawing.Color.Cornsilk;
                    grow.BackColor = System.Drawing.Color.BlanchedAlmond;
                }

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                con.Open();
                var ddl = (CheckBoxList)e.Row.FindControl("ddlCity");
                //var txtremarks = (CheckBoxList)e.Row.FindControl("txtRemarks");
                string CountryId = e.Row.Cells[1].Text.ToString();
                SqlCommand cmd = new SqlCommand("select QY_QUERY,QY_SQUERY from MR_QUERY  where QY_QUERY='" + CountryId + "' ORDER BY QY_QUERY,QY_SQUERY ASC", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                con.Close();
                ddl.DataSource = ds;
                ddl.DataTextField = "QY_SQUERY";
                ddl.DataValueField = "QY_QUERY";
                ddl.DataBind();

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void gvUserInfo1_RowDataBound(object o, GridViewRowEventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                con.Open();
                var ddl = (CheckBoxList)e.Row.FindControl("ddlCity");
                //var txtremarks = (CheckBoxList)e.Row.FindControl("txtRemarks");
                string CountryId = e.Row.Cells[1].Text.ToString();
                SqlCommand cmd = new SqlCommand("select QY_QUERY,QY_SQUERY from MR_QUERY  where QY_QUERY='" + CountryId + "' ORDER BY QY_QUERY,QY_SQUERY ASC", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                con.Close();
                ddl.DataSource = ds;
                ddl.DataTextField = "QY_SQUERY";
                ddl.DataValueField = "QY_QUERY";
                ddl.DataBind();

                GridView gvQueries = (GridView)e.Row.FindControl("gvQueries");
                DataSet dsqry = new DataSet();

                dsqry = clscommon.Bind_MR_DISBQueries_By_QY_QUERY(CountryId);

                gvQueries.DataSource = dsqry;
                gvQueries.DataBind();

                //dd
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlCity_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            foreach (GridViewRow grow in gvUserInfo.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {

                    // a = gvUserInfo.Rows[index].Cells[1].Text.ToString();
                    chkStat.Enabled = false;
                    CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                    TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
                    int index1 = grow.RowIndex;
                    foreach (ListItem i2 in chkStat1.Items)
                    {
                        if (i2.Selected)
                        {
                            txtRemarks.Visible = true;
                        }
                        else
                        {
                            txtRemarks.Visible = false;
                        }
                    }
                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void chkQuery_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow grow in gvUserInfo.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
                int index = grow.RowIndex;
                GridView gvQueries = (GridView)grow.FindControl("gvQueries");


                if (chkStat.Checked)
                {
                    CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                    chkStat1.Enabled = true;
                    //txtRemarks.Enabled = true ;
                    foreach (GridViewRow growQuery in gvQueries.Rows)
                    {

                        CheckBox chkQuery = growQuery.FindControl("chkQuery") as CheckBox;
                        TextBox txtRemarks1 = growQuery.FindControl("txtRemarks1") as TextBox;
                        RadioButtonList rblDesc = growQuery.FindControl("rblDesc") as RadioButtonList;
                        chkQuery.Enabled = true;
                        if (chkQuery.Checked)
                        {
                            txtRemarks1.Visible = true;
                            rblDesc.Enabled = true;
                        }
                        else
                        {
                            txtRemarks1.Visible = false;
                            rblDesc.Enabled = false;
                        }
                    }
                }
                else
                {
                    CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                    int index1 = grow.RowIndex;
                    foreach (ListItem i in chkStat1.Items)
                    {
                        i.Selected = false;

                    }
                    foreach (GridViewRow growQuery in gvQueries.Rows)
                    {

                        CheckBox chkQuery = growQuery.FindControl("chkQuery") as CheckBox;
                        TextBox txtRemarks1 = growQuery.FindControl("txtRemarks1") as TextBox;
                        RadioButtonList rblDesc = growQuery.FindControl("rblDesc") as RadioButtonList;
                        chkQuery.Enabled = false;
                        if (!chkQuery.Checked)
                        {
                            txtRemarks1.Visible = false;
                            rblDesc.Enabled = false;
                        }

                        //txtRemarks1.Enabled = true;



                    }
                    chkStat1.Enabled = false;
                    txtRemarks.Enabled = true;
                }
            }
            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void gvQueries_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

        }
    }
    protected void gvUserInfo_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);

            con.Open();

            GridView dgQuery = gvQuerydets;
            dgQuery.Visible = false;
            MICR_NO.Visible = true;
            foreach (GridViewRow grow in gvQuery.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                Label lnbtn = grow.FindControl("lnkname") as Label;
                Label lblProdCode = grow.FindControl("lblProdCode") as Label;
                //DropDownList ddrsp = grow.FindControl("Editdd") as DropDownList;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    leadno = lnbtn.Text;
                    appname = gvQuery.Rows[index].Cells[3].Text;
                    pddt = gvQuery.Rows[index].Cells[4].Text;
                    lnamt = gvQuery.Rows[index].Cells[5].Text;
                    Session["PCODE"] = lblProdCode.Text;
                }
            }

            SqlCommand cmd = new SqlCommand("RTS_SP_DISB_QUERYCHECK", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LEADNO", leadno);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            lblLead.Text = ds.Tables[0].Rows[0][0].ToString();

            Session["Leadno"] = leadno;

            getLeadID(con);
            if (leadno.Contains("HF") == true || leadno.Contains("IBAH") == true || leadno.Contains("SLAP") == true)
            {
                gvQuerydets.Visible = false;
                //trSME.Visible = false;
                Bind_HF_Queries();
                divCol.Visible = true;
            }
            else
            {
                gvQuerydets.Visible = true;            
                //trSME.Visible = true;
                qrydetsbind();
                divCol.Visible = false;
            }
           
            lbLeadno.Visible = true;
            lbAppname.Visible = true;
            lbPDdate.Visible = true;
            lbLoanamt.Visible = true;
            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;
            MICR_NO.Visible = true;

            lbLeadno.Text = leadno;
            lbAppname.Text = appname;
            lbPDdate.Text = pddt;
            lbLoanamt.Text = lnamt;
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void getLeadID(SqlConnection con)
    {
        try
        {
            SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
            cmdbr.CommandType = CommandType.StoredProcedure;
            cmdbr.Parameters.AddWithValue("@LeadNo", Session["Leadno"].ToString());
            SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
            DataSet dsbr = new DataSet();
            dabr.Fill(dsbr);
            Session["LeadId"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void qrydetsbind()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            GridView gvQuery = null;
            gvQuery = gvQuerydets;
            //  int  qryldid = Session["LeadId"] !=null? Convert.ToInt32(Session["LeadId"]):0;

            SqlCommand cmdqry = new SqlCommand("RTS_SP_FETCH_MDISB_QUERY", con);
            cmdqry.CommandType = CommandType.StoredProcedure;
            cmdqry.Parameters.AddWithValue("@QY_QUERY", Session["PCODE"] != null ? Session["PCODE"].ToString() : "");
            SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
            DataSet dsqry = new DataSet();
            daqry.Fill(dsqry);
            if (dsqry.Tables[0].Rows.Count > 0)
            {
                gvQuery.DataSource = dsqry.Tables[0];
                gvQuery.DataBind();
                gvQuery.Visible = true;
            }
            else
            {
                uscMsgBox1.AddMessage("No Record Found !", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            con.Close();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }


    }
    public void Bind_HF_Queries()
    {
        try
        {
            DataSet ds = new DataSet();
            ds = clscommon.Bind_MDisbQuery_By_PRSTYPE("HFQRY");          
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvUserInfo.DataSource = ds;
                gvUserInfo.DataBind();
                gvUserInfo.Visible = true;
            }
            else
            {
                uscMsgBox1.AddMessage("No Record Found !", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }


    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('HOOps_QCQuery_Popup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            SqlCommand cmd = new SqlCommand("RTS_SP_DISB_QUERYCHECK", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LEADNO", lbLeadno.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            if (lbLeadno.Text.Contains("HF") == true || lbLeadno.Text.Contains("IBAH") == true || lbLeadno.Text.Contains("SLAP") == true)
            {
                Insert_HF_RaiseQuery();
            }
            else
            {
                InsertHORaiseQuery();
            }


            //if (Session["View"] == "F")
            //{
                gridbind();
            //}
            //else
            //{
            //    gridbindall();
            //}
            foreach (GridViewRow grow in gvQuery.Rows)
            {
                Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                int index = grow.RowIndex;
                if (lblQryResult.Text == "T")
                {
                    gvQuery.Rows[index].Cells[1].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[2].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[3].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[4].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[5].ForeColor = Color.Red;
                }
            }
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
            gvQuerydets.Visible = false;
            btnSubmit.Enabled = false;
            MICR_NO.Visible = false;
            gvUserInfo.Visible = false;

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //con.Close();
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HOOps_Disb_QCQuery.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME ,BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //txtLeadno.Enabled = false;
        txtLeadno.Text = "";
    }
    protected void ddlQuery_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    public void Insert_HF_RaiseQuery()
    {
        GridView dgQuery = null;
        int selectedcnt = 0;
      //  dgQuery = gvQuerydets;
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            int i1 = 0, i3 = 0;
            string a;
            dtQuery = new DataTable();
            DataRow dr = null;
            dtQuery.Columns.Add(new DataColumn("Query Raised", typeof(string)));
            dtQuery.Columns.Add(new DataColumn("Descision", typeof(string)));
            dtQuery.Columns.Add(new DataColumn("Sub Query Raised", typeof(string)));
            foreach (GridViewRow grow in gvUserInfo.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;
                GridView gvQueries = (GridView)grow.FindControl("gvQueries");
                if (chkStat.Checked)
                {
                    i1++;
                    a = gvUserInfo.Rows[index].Cells[1].Text.ToString();
                    chkStat.Enabled = false;
                    CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                    TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
                    int index1 = grow.RowIndex;
                    foreach (GridViewRow growQuery in gvQueries.Rows)
                    {

                        CheckBox chkQuery = growQuery.FindControl("chkQuery") as CheckBox;
                        Label lbl_QUERY = growQuery.FindControl("lbl_QUERY") as Label;
                        Label lblSquery = growQuery.FindControl("lblSquery") as Label;
                        TextBox txtRemarks1 = growQuery.FindControl("txtRemarks1") as TextBox;
                        RadioButtonList rblDesc = growQuery.FindControl("rblDesc") as RadioButtonList; 
                        // foreach (ListItem i2 in chkStat1.Items)
                        // {
                        // if (i2.Selected)
                        if (chkQuery.Checked)
                        {
                            SqlCommand cmdbr1 = new SqlCommand("RTS_PR_Insert_Disburse_Query", con);
                            cmdbr1.CommandType = CommandType.StoredProcedure;
                            cmdbr1.Parameters.AddWithValue("@LEAD_ID", Session["LeadId"].ToString());
                            cmdbr1.Parameters.AddWithValue("@QRY_QUERY", lbl_QUERY.Text + " | " + lblSquery.Text);
                            cmdbr1.Parameters.AddWithValue("@QRY_SQUERY", txtRemarks1.Text);
                            cmdbr1.Parameters.AddWithValue("@QRY_DESCN", rblDesc.SelectedValue);
                            cmdbr1.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                            int n = cmdbr1.ExecuteNonQuery();


                            if (n <= 0)
                            {
                                uscMsgBox1.AddMessage("Query already Raised for that Lead ID =" + Session["LeadId"].ToString() + " ( " + lbl_QUERY.Text + " | " + lblSquery.Text + ")", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            }
                            else
                            {
                                dr = dtQuery.NewRow();
                                dr["Query Raised"] = lbl_QUERY.Text + " | " + lblSquery.Text + " | " + rblDesc.SelectedValue;
                                dr["Descision"] = rblDesc.SelectedValue;
                                dr["Sub Query Raised"] = txtRemarks1.Text;
                                dtQuery.Rows.Add(dr);
                                selectedcnt = selectedcnt + 1;

                            }
                        }
                        //}
                    }
                }
            }

        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            if (selectedcnt <= 0)
            {


                uscMsgBox1.AddMessage("Please Select Query", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                uscMsgBox1.AddMessage("Query Raised Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                sendMail(con);

                string strMailStatus = "";
                string strSuccessMsg = "";
                if (blMailStatus == true)
                {
                    strMailStatus = "Successfully";
                }
                else
                {
                    strMailStatus = "Failed";
                }
                strSuccessMsg = Session["Leadno"].ToString() + " - " + " <br/> Mail Sent " + strMailStatus + "  ";
                strSuccessMsg += "<br/> Mail To: " + toID + " ; CC To: " + ccID + " ";



                uscMsgBox1.AddMessage(strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }

            con.Close();
        }
    }
    public void InsertHORaiseQuery()
    {
        GridView dgQuery = null;
        int selectedcnt = 0;
        dgQuery = gvQuerydets;

        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        try
        {
            dtQuery = new DataTable();
            DataRow dr = null;
            dtQuery.Columns.Add(new DataColumn("Query Raised", typeof(string)));
            dtQuery.Columns.Add(new DataColumn("Sub Query Raised", typeof(string)));
            foreach (GridViewRow grow in dgQuery.Rows)
            {

                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                Label lblname = grow.FindControl("lblname") as Label;
                TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
                int index = grow.RowIndex;

                if (chkStat.Checked)
                {

                    SqlCommand cmdbr1 = new SqlCommand("RTS_PR_Insert_Disburse_Query", con);
                    cmdbr1.CommandType = CommandType.StoredProcedure;
                    cmdbr1.Parameters.AddWithValue("@LEAD_ID", Session["LeadId"].ToString());
                    cmdbr1.Parameters.AddWithValue("@QRY_QUERY", lblname.Text);
                    cmdbr1.Parameters.AddWithValue("@QRY_SQUERY", txtRemarks.Text);
                    cmdbr1.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                    int n = cmdbr1.ExecuteNonQuery();


                    if (n <= 0)
                    {
                        uscMsgBox1.AddMessage("Query already Raised for that Lead ID =" + Session["LeadId"].ToString() + " ( " + lblname.Text + ")", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                    else
                    {
                        dr = dtQuery.NewRow();
                        dr["Query Raised"] = lblname.Text;
                        dr["Sub Query Raised"] = txtRemarks.Text;
                        dtQuery.Rows.Add(dr);
                        selectedcnt = selectedcnt + 1;

                    }

                }

            }



        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            if (selectedcnt <= 0)
            {


                uscMsgBox1.AddMessage("Please Select Query", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                uscMsgBox1.AddMessage("Query Raised Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                sendMail(con);

                string strMailStatus = "";
                string strSuccessMsg = "";
                if (blMailStatus == true)
                {
                    strMailStatus = "Successfully";
                }
                else
                {
                    strMailStatus = "Failed";
                }
                strSuccessMsg = Session["Leadno"].ToString() + " - " + " <br/> Mail Sent " + strMailStatus + "  ";
                strSuccessMsg += "<br/> Mail To: " + toID + " ; CC To: " + ccID + " ";



                uscMsgBox1.AddMessage(strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }

            con.Close();
        }

        // gvResolve.Visible = false;
    }
    public void sendMail(SqlConnection con)
    {
        try
        {
            /////// mail ///////////
            //  strMailDetail = "";

          /* Bala changes as per sepertated HF Mail 17/07/2017
           * SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "'", con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);

            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["LD_BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["LD_BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT EM_BM,EM_AM,EM_CM,EM_BCC,EM_CLM FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);*/
            DataSet dsmailto = new DataSet();
            dsmailto = clscommon.Bind_FETCH_MR_EMAIL(Session["Leadno"].ToString());      
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
                //Bala changes 17/07/2017 cc = dsmailto.Tables[0].Rows[0]["EM_AM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() : "";
                cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() + ";" + dsmailto.Tables[0].Rows[0]["EM_HO"].ToString();
                cc = cc.Replace("\n", "");
                bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
                bcc3 = dsmailto.Tables[0].Rows[0]["EM_CLM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_CLM"].ToString() : "";
            }

           /* if (cc != "")
            {
                cc = cc + ";retail-helpdesk@equitasbank.com";
            }
            else
            {
                cc = "retail-helpdesk@equitasbank.com";
            }*/
            if (bcc3 != "")
            {
                cc = cc + ";" + bcc3;
            }


            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            //to = "ManimaranK@equitasbank.com";
            //bcc2 = "ManimaranK@equitasbank.com";
            //cc = "rts-helpdesk@equitasbank.com";
            fromID = "RTS Alerts";
            toID = to;
            //   to = "ManimaranK@equitasbank.com";
            bcc2ID = bcc2;
            ccID = cc;

            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/>Please find below details of  Pre-Disbursement queries<br/>";
                //BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td>";
                //BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + dsdet.Tables[0].Rows[0]["LD_APNAME"].ToString() + "</strong></td></tr>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + "</strong></td>";
                //BodyTxt = BodyTxt + "<td>Loan Amount</td><td><strong>" + Session["Loanamt"] + "</strong></td></tr></table><br/><br/>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Address </td><td align='center'>:</td><td><strong>" + cusaddr + "</strong></td></tr>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Mobile No.</td><td align='center'>:</td><td><strong>" + mobile + "</strong></td></tr></table><br/><br/>";
                int b = dtQuery.Rows.Count;
                if (b != 0)
                {
                    BodyTxt = BodyTxt + "<table width='90%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='center'  width='10%'>Sl. No.</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Credit Query Details</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Query Date</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Response</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Response Date</td>";

                    BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' width='50%'>Query Type</td>";
                    BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' width='50%'>Remarks</td></span></tr>";
                    for (int j = 0; j <= b - 1; j++)
                    {
                        int sno = j + 1;
                        BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td bgcolor='#FFFFFF' align='right'> " + sno + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Query Raised"].ToString() + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Date"].ToString() + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response"].ToString() + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response Date"].ToString() + "</td>";
                        BodyTxt = BodyTxt + "<td bgcolor='#FFFFFF'> " + dtQuery.Rows[j]["Query Raised"].ToString() + "</td>";
                        BodyTxt = BodyTxt + "<td bgcolor='#FFFFFF'> " + dtQuery.Rows[j]["Sub Query Raised"].ToString() + "</td></span></tr>";
                    }
                    BodyTxt = BodyTxt + "</table>";
                }

                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>Retail Ops - QC Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
                //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

                blMailStatus = EmailManager.sendemail(to, "RTS Alerts", bcc2, cc, "PRDD QUERY  " + Session["Leadno"].ToString() + " - " + dsmailto.Tables[0].Rows[0]["LD_APNAME"].ToString() + " - " + dsmailto.Tables[0].Rows[0]["AR_NAME"].ToString() + "- " + dsmailto.Tables[0].Rows[0]["BR_NAME"].ToString() + "", BodyTxt, "", true);
                //sendemail("SurendharR@equitasbank.com;PrabhakaranA@equitasbank.com;Tamilalagand@equitasbank.com", "surendharr@equitasbank.com", "Test", BodyTxt, "", true);

                //strMailBody = BodyTxt.Replace("<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Credit " + ddlApprv.SelectedItem.ToString() + "<br/><br/>", "");
                //strMailBody = BodyTxt.Replace("</html>", " ");


            //});
            //// strMailDetail = to + "," + bcc2 + "," + cc;
            //threadSendMails.IsBackground = true;

            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(5000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void btn_MICR_Click(object sender, EventArgs e)
    {
        MICR_NO.Visible = true;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_GET_MICR", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MICR_NO", txt_MICR.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            gv_MICR.DataSource = ds.Tables[0];
            gv_MICR.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gv_MICR.HeaderRow.Font.Bold = true;
                gv_MICR.HeaderRow.Cells[0].Text = "MICR No";
                gv_MICR.HeaderRow.Cells[1].Text = "Bank Name";
                gv_MICR.HeaderRow.Cells[2].Text = "Bank Branch";
                gv_MICR.HeaderRow.Cells[3].Text = "Location";

            }
            else
            {
                uscMsgBox1.AddMessage("Invalid MICR No", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
}