﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using CrystalDecisions.Shared;
using System.Configuration;
using CrystalDecisions.CrystalReports.Engine;
using System.Drawing;
using System.Text;
using Tracker;

public partial class Legal_MOTD : System.Web.UI.Page
{

    string sancno;
    string leadno;
    string appname;
    string product;
    string lnamt;
    string brnch;

    int ldid;
    DateTime dt = DateTime.Now;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    ReportDocument rpt = new ReportDocument();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {

                bindArea();
                txtbxcurdate.Text = String.Format("{0:dd MMM yyyy}", dt);
                this.ld.Visible = false;
                this.sanc.Visible = false;
                this.sch1h.Visible = false;
                this.sch1.Visible = false;
                this.sch2h.Visible = false;
                this.sch2.Visible = false;

            }
        }
        else Response.Redirect("Expire.aspx");
    }
    // Shankar_Nov_14_01 
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    // Shankar_Nov_14_01 
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        bool _passValidation = false;

        try
        {
            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "All";
                //   gridbindall();
                _passValidation = false;
                uscMsgBox1.AddMessage("Please Select Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                // ddlArea.Enabled = false;
                // gridbind();
                _passValidation = true;
            }
            else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                // ddlArea.Enabled = false;
                // gridbind();
                _passValidation = true;
            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";
                //  gridbind();
                _passValidation = true;
            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                //  gridbind();
                _passValidation = true;
            }
            else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";
                //  gridbind();
                _passValidation = true;
            }

            if (_passValidation)
            {
                BindqueryGrid();
                foreach (GridViewRow grow in gvlead.Rows)
                {
                    Label lblQryResult = (Label)grow.FindControl("lblsanc");
                    int index = grow.RowIndex;
                    if (lblQryResult.Text == "")
                    {
                        gvlead.Rows[index].Cells[1].ForeColor = Color.Red;
                        gvlead.Rows[index].Cells[2].ForeColor = Color.Red;
                        gvlead.Rows[index].Cells[3].ForeColor = Color.Red;
                        gvlead.Rows[index].Cells[4].ForeColor = Color.Red;
                        gvlead.Rows[index].Cells[5].ForeColor = Color.Red;


                    }
                }
                if (gvlead.Rows.Count > 0)
                    this.ld.Visible = true;
                else
                    this.ld.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_BIND_LGL_MOTD", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "L");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvlead.Visible = true;
                //Panel1.Visible = true;
                gvlead.DataSource = ds1.Tables[0];
                gvlead.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvlead.HeaderRow.Font.Bold = true;
                    gvlead.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvlead.HeaderRow.Cells[2].Text = "APPLICANT NAME";
                    gvlead.HeaderRow.Cells[3].Text = "PRODUCT";
                    gvlead.HeaderRow.Cells[4].Text = "LOAN AMOUNT";
                    gvlead.HeaderRow.Cells[5].Text = "SANCTION NO";
                    gvlead.HeaderRow.Cells[6].Text = "BRANCH";

                    gvlead.HeaderRow.Cells[1].Wrap = false;
                    gvlead.HeaderRow.Cells[2].Wrap = false;
                    gvlead.HeaderRow.Cells[3].Wrap = false;
                    gvlead.HeaderRow.Cells[4].Wrap = false;
                    gvlead.HeaderRow.Cells[5].Wrap = false;
                    gvlead.HeaderRow.Cells[6].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvlead.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void View()
    {
        bool _passValidation = false;

        try
        {
            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "All";
                //   gridbindall();
                _passValidation = false;
                uscMsgBox1.AddMessage("Please Select Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                // ddlArea.Enabled = false;
                // gridbind();
                _passValidation = true;
            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";
                //  gridbind();
                _passValidation = true;
            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                //  gridbind();
                _passValidation = true;
            }

            if (_passValidation)
            {
                SqlConnection con = new SqlConnection(strcon);
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("RTS_SP_BIND_LGL_MOTD", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
                    cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
                    cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
                    cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
                    cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
                    cmd.Parameters.AddWithValue("@FT_SENTTO", "L");
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds1 = new DataSet();
                    da.Fill(ds1);
                    if (ds1.Tables[0].Rows.Count != 0)
                    {
                        gvlead.Visible = true;
                        //Panel1.Visible = true;
                        gvlead.DataSource = ds1.Tables[0];
                        gvlead.DataBind();
                        if (ds1.Tables[0].Rows.Count > 0)
                        {
                            gvlead.HeaderRow.Font.Bold = true;
                            gvlead.HeaderRow.Cells[1].Text = "LEAD NO";
                            gvlead.HeaderRow.Cells[2].Text = "APPLICANT NAME";
                            gvlead.HeaderRow.Cells[3].Text = "PRODUCT";
                            gvlead.HeaderRow.Cells[4].Text = "LOAN AMOUNT";
                            gvlead.HeaderRow.Cells[5].Text = "SANCTION NO";
                            gvlead.HeaderRow.Cells[6].Text = "BRANCH";

                            gvlead.HeaderRow.Cells[1].Wrap = false;
                            gvlead.HeaderRow.Cells[2].Wrap = false;
                            gvlead.HeaderRow.Cells[3].Wrap = false;
                            gvlead.HeaderRow.Cells[4].Wrap = false;
                            gvlead.HeaderRow.Cells[5].Wrap = false;
                            gvlead.HeaderRow.Cells[6].Wrap = false;
                        }
                    }
                    else
                    {
                        //uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        gvlead.Visible = false;
                    }
                }
                catch (Exception ex)
                {
                    uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    ErrorLog.WriteError(ex);
                }
                finally
                {
                    con.Close();
                }
                foreach (GridViewRow grow in gvlead.Rows)
                {
                    Label lblQryResult = (Label)grow.FindControl("lblsanc");
                    int index = grow.RowIndex;
                    if (lblQryResult.Text == "")
                    {
                        gvlead.Rows[index].Cells[1].ForeColor = Color.Red;
                        gvlead.Rows[index].Cells[2].ForeColor = Color.Red;
                        gvlead.Rows[index].Cells[3].ForeColor = Color.Red;
                        gvlead.Rows[index].Cells[4].ForeColor = Color.Red;
                        gvlead.Rows[index].Cells[5].ForeColor = Color.Red;


                    }
                }
                if (gvlead.Rows.Count > 0)
                    this.ld.Visible = true;
                else
                    this.ld.Visible = false;


                this.sanc.Visible = false;
                this.sch1h.Visible = false;
                this.sch1.Visible = false;
                this.sch2h.Visible = false;
                this.sch2.Visible = false;
                btnsubmit.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        Print();

        //SqlConnection con = new SqlConnection(strcon);
        //try
        //{
        //    con.Open();
        //    id = 0;

        //    SqlCommand cmdmd = new SqlCommand("select * from LSD_MOTD WHERE MD_SANTD_NO='" + txtSanctionno.Text + "'", con);

        //    //SqlCommand cmdlamt = new SqlCommand("select * from LSD_LEAD where LD_SANTD_NO='" + txtSanctionno.Text + "'", con);

        //    SqlDataAdapter damd = new SqlDataAdapter(cmdmd);
        //    DataSet dsmd = new DataSet();
        //    damd.Fill(dsmd);

        //    mdid = Convert.ToInt32(dsmd.Tables[0].Rows[0]["MD_ID"]);

        //    //SqlDataAdapter dap = new SqlDataAdapter(cmdlamt);
        //    //DataSet dsamt = new DataSet();
        //    //dap.Fill(dsamt);
        //    string amt = "";
        //    string TMP = dsmd.Tables[0].Rows[0]["MD_LOAN_AMT"] == DBNull.Value ? "" : dsmd.Tables[0].Rows[0]["MD_LOAN_AMT"].ToString();
        //    if (TMP != "")
        //    {
        //        string[] tp = TMP.Split('.');
        //        amt = NumberToWords(Convert.ToInt32(tp[0]));
        //    }
        //    SqlCommand mycomm = new SqlCommand("select MD_ID from LSD_MOTD where MD_SANTD_NO='" + txtSanctionno.Text + "'", con);
        //    //mycomm.CommandType = CommandType.StoredProcedure;
        //    //mycomm.Parameters.Add("@LNNO", SqlDbType.VarChar).Value = txt_loan.Text;
        //    SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
        //    DataSet ds1 = new DataSet();
        //    showdata.Fill(ds1);
        //    id = ds1.Tables[0].Rows.Count;
        //    if (id == 0)
        //    {
        //        uscMsgBox1.AddMessage("Enter Valid Sanction No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        //    }
        //    else
        //    {
        //        rpt = new ReportDocument();
        //        //ParameterValues para = new ParameterValues(); 
        //        //set a ReportPath and assign the dataset to reportdocument object
        //        rpt.Load(Server.MapPath("Reports/MOTD.rpt"));
        //        //ConnectionInfo connectionInfo = new ConnectionInfo();
        //        //connectionInfo.ServerName = "172.16.2.95";
        //        //connectionInfo.DatabaseName = "RTS1";
        //        //connectionInfo.IntegratedSecurity = true;

        //        rpt.SetDatabaseLogon("uno", "uno", @"172.16.2.95", "RTS1");
        //        //assign the values to crystal report viewer                              
        //        rpt.SetParameterValue(0, txtSanctionno.Text);
        //        rpt.SetParameterValue(1, mdid);
        //        rpt.SetParameterValue(2, "");
        //        rpt.SetParameterValue(3, amt);
        //        rpt.SetParameterValue(4, "");
        //        rpt.SetParameterValue(5, mdid);
        //        rpt.ExportToHttpResponse(ExportFormatType.WordForWindows, Response, true, "MOTD For " + txtSanctionno.Text + "");
        //    }

        //}
        //catch (Exception ex)
        //{
        //    uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        //}
        //finally
        //{
        //    con.Close();
        //    rpt.Close();
        //    rpt.Dispose();
        //    rpt = null;
        //    GC.Collect();

        //}
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        btnPreview.Visible = false;
        Response.Redirect("Legal_MOTD.aspx");
    }
    public static string NumberToWords(int number)
    {
        if (number == 0)
            return "zero";

        if (number < 0)
            return "minus " + NumberToWords(Math.Abs(number));

        string words = "";

        if ((number / 10000000) > 0)
        {
            words += NumberToWords(number / 10000000) + " Crore ";
            number %= 10000000;
        }

        if ((number / 100000) > 0)
        {
            words += NumberToWords(number / 100000) + " Lakh ";
            number %= 100000;
        }

        if ((number / 1000) > 0)
        {
            words += NumberToWords(number / 1000) + " Thousand ";
            number %= 1000;
        }

        if ((number / 100) > 0)
        {
            words += NumberToWords(number / 100) + " Hundred ";
            number %= 100;
        }

        if (number > 0)
        {
            if (words != "")
                words += "and ";

            var unitsMap = new[] { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
            var tensMap = new[] { "Zero", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

            if (number < 20)
                words += unitsMap[number];
            else
            {
                words += tensMap[number / 10];
                if ((number % 10) > 0)
                    words += "-" + unitsMap[number % 10];
            }
        }
        return words;
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();


            foreach (GridViewRow grow in gvlead.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                Label lblldid = grow.FindControl("lblLeadID") as Label;
                sancno = (grow.FindControl("lblsanc") as Label).Text;
                ldid = Convert.ToInt32(lblldid.Text);

                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    Session["LD_ID"] = ldid;
                    Session["LDNOS"] = gvlead.Rows[index].Cells[1].Text;
                    leadno = gvlead.Rows[index].Cells[1].Text;
                    appname = gvlead.Rows[index].Cells[2].Text;
                    product = gvlead.Rows[index].Cells[3].Text;
                    lnamt = gvlead.Rows[index].Cells[4].Text;
                    brnch = gvlead.Rows[index].Cells[5].Text;
                    Session["SanctionNo"] = (grow.FindControl("lblsanc") as Label).Text;
                    if ((grow.FindControl("lblsanc") as Label).Text != "")
                    {
                        BindAllFields();

                        this.sanc.Visible = true;
                        this.sch1h.Visible = true;
                        this.sch1.Visible = true;
                        this.sch2h.Visible = true;
                        this.sch2.Visible = true;
                    }
                    else
                    {
                        uscMsgBox1.AddMessage(Session["LDNOS"].ToString() + " not yet sanctioned...", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                }

            }
            btnPreview.Visible = true;

            con.Close();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void BindAllFields()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_FETCH_MOTD", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LD_ID", Session["LD_ID"].ToString());

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows[0][0].ToString() == "1")
            {

                txtSanctionno.Text = ds1.Tables[1].Rows[0]["MD_SANTD_NO"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_SANTD_NO"].ToString();
                txtDate.Text = ds1.Tables[1].Rows[0]["MD_MTDATE"] == DBNull.Value ? "" : String.Format("{0:dd MMM yyyy}", ds1.Tables[1].Rows[0]["MD_MTDATE"]);
                txtname1.Text = ds1.Tables[1].Rows[0]["MD_BR1_NAME"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_BR1_NAME"].ToString();
                txtofname1.Text = ds1.Tables[1].Rows[0]["MD_BR1_FNAME"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_BR1_FNAME"].ToString();
                txtage1.Text = ds1.Tables[1].Rows[0]["MD_BR1_AGE"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_BR1_AGE"].ToString();
                txtbxloanamt.Text = ds1.Tables[1].Rows[0]["MD_LOAN_AMT"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_LOAN_AMT"].ToString();
                gvCO.DataSource = ds1.Tables[4];
                gvCO.DataBind();

                txtResiding1.Text = ds1.Tables[1].Rows[0]["MD_BR_ADD1"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_BR_ADD1"].ToString();
                txtResiding2.Text = ds1.Tables[1].Rows[0]["MD_BR_ADD2"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_BR_ADD2"].ToString();
                txtResiding3.Text = ds1.Tables[1].Rows[0]["MD_BR_ADD3"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_BR_ADD3"].ToString();

                txtProperty.Text = ds1.Tables[1].Rows[0]["MD_PROP_DET"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_PROP_DET"].ToString();

                gvview.DataSource = ds1.Tables[2];
                gvview.DataBind();

                //txtbxpropschedule.Text = ds1.Tables[1].Rows[0]["MD_PROP_DET"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_PROP_DET"].ToString();
                //txtbxnorthby.Text = ds1.Tables[1].Rows[0]["MD_NORTH"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_NORTH"].ToString();
                //txtbxsouthby.Text = ds1.Tables[1].Rows[0]["MD_SOUTH"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_SOUTH"].ToString();
                //txtbxeastby.Text = ds1.Tables[1].Rows[0]["MD_EAST"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_EAST"].ToString();
                //txtbxwestby.Text = ds1.Tables[1].Rows[0]["MD_WEST"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_WEST"].ToString();

                //txtbxregoffice.Text = ds1.Tables[1].Rows[0]["MD_REGISTR"] == DBNull.Value ? "" : ds1.Tables[1].Rows[0]["MD_REGISTR"].ToString();

                //Session["COMPANY"] = ds1.Tables[1].Rows[0]["MD_CMP_FULL"].ToString();

                //Session["COMPANYSHORT"] = ds1.Tables[1].Rows[0]["MD_CMP_SHRT"].ToString();

                if (gvCO.Rows.Count > 0)
                {
                    foreach (GridViewRow grow in gvCO.Rows)
                    {
                        Label lblcbrwincl = (Label)grow.FindControl("lblcbrwinclude");
                        int index = grow.RowIndex;
                        if (lblcbrwincl.Text == "Y")
                        {
                            (grow.FindControl("chkbxcbrwinclude") as CheckBox).Checked = true;
                        }
                    }
                }
                gvCO.Enabled = false;

                gvschedule.DataSource = ds1.Tables[5];
                gvschedule.DataBind();
                btnsubmit.Enabled = false;
                btnPrint.Enabled = true;
            }
            else if (ds1.Tables[0].Rows[0][0].ToString() == "2")
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);//ds1.Tables[4].Rows[0]["MD_PDATE"] == DBNull.Value ? "" : String.Format("{0:dd MMM yyyy}", ds1.Tables[4].Rows[0]["MD_PDATE"]);
                txtSanctionno.Text = ds1.Tables[2].Rows[0]["PRPSLNO"] == DBNull.Value ? "" : ds1.Tables[2].Rows[0]["PRPSLNO"].ToString();
                txtname1.Text = ds1.Tables[1].Rows[0]["BORROWER"].ToString();
                txtofname1.Text = ds1.Tables[1].Rows[0]["S/o/ W/o /F/O"].ToString();
                txtage1.Text = ds1.Tables[1].Rows[0]["AGE"].ToString();

                //txtname2.Text = ds.Tables[0].Rows[0]["COTITLESHORTDESC"].ToString() + ds.Tables[0].Rows[0]["CO-BORROWER"].ToString();
                //txtofname2.Text = ds.Tables[0].Rows[0]["CO_S/o/ W/o /F/O"].ToString();
                //txtage2.Text = ds.Tables[0].Rows[0]["COAGE"].ToString();


                //ds1.Tables[2].Merge(ds1.Tables[5], true, MissingSchemaAction.Ignore);


                gvCO.DataSource = ds1.Tables[5];
                gvCO.DataBind();

                // Panel1.Visible = true;

                txtResiding1.Text = ds1.Tables[1].Rows[0]["ADDRESS"].ToString();
                txtResiding2.Text = ds1.Tables[1].Rows[0]["AREA"].ToString();
                txtResiding3.Text = ds1.Tables[1].Rows[0]["CITY"].ToString();

                txtbxloanamt.Text = ds1.Tables[1].Rows[0]["LNAMT"].ToString();

                gvview.DataSource = ds1.Tables[3];
                gvview.DataBind();

                Session["COMPANY"] = ds1.Tables[1].Rows[0]["COMPANY"].ToString();

                Session["COMPANYSHORT"] = ds1.Tables[1].Rows[0]["COMPANY CODE"].ToString();

                txtProperty.Text = ds1.Tables[4].Rows[0]["MD_PROP_DET"] == DBNull.Value ? "" : ds1.Tables[4].Rows[0]["MD_PROP_DET"].ToString();

                //txtbxpropschedule.Text = ds1.Tables[4].Rows[0]["MD_PROP_DET"] == DBNull.Value ? "" : ds1.Tables[4].Rows[0]["MD_PROP_DET"].ToString();
                //txtbxnorthby.Text = ds1.Tables[4].Rows[0]["MD_NORTH"] == DBNull.Value ? "" : ds1.Tables[4].Rows[0]["MD_NORTH"].ToString();
                //txtbxsouthby.Text = ds1.Tables[4].Rows[0]["MD_SOUTH"] == DBNull.Value ? "" : ds1.Tables[4].Rows[0]["MD_SOUTH"].ToString();
                //txtbxeastby.Text = ds1.Tables[4].Rows[0]["MD_EAST"] == DBNull.Value ? "" : ds1.Tables[4].Rows[0]["MD_EAST"].ToString();
                //txtbxwestby.Text = ds1.Tables[4].Rows[0]["MD_WEST"] == DBNull.Value ? "" : ds1.Tables[4].Rows[0]["MD_WEST"].ToString();

                //txtbxregoffice.Text = ds1.Tables[4].Rows[0]["MD_REGISTR"] == DBNull.Value ? "" : ds1.Tables[4].Rows[0]["MD_REGISTR"].ToString();

                gvschedule.DataSource = ds1.Tables[6];
                gvschedule.DataBind();
                btnsubmit.Enabled = true;


            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally { con.Close(); }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Update_MODT", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Lead_ID", Session["LD_ID"].ToString());
            cmd.Parameters.AddWithValue("@Sanc_NO", txtSanctionno.Text.Trim());
            cmd.Parameters.AddWithValue("@Borrower", txtname1.Text.Trim());
            cmd.Parameters.AddWithValue("@BorrowerFName", txtofname1.Text.Trim());
            cmd.Parameters.AddWithValue("@BorrowerAge", txtage1.Text.Trim());
            cmd.Parameters.AddWithValue("@BorrowerAddress1", txtResiding1.Text.Trim());
            cmd.Parameters.AddWithValue("@BorrowerAddress2", txtResiding2.Text.Trim());
            cmd.Parameters.AddWithValue("@BorrowerAddress3", txtResiding3.Text.Trim());
            cmd.Parameters.AddWithValue("@Loanamt", txtbxloanamt.Text);
            cmd.Parameters.AddWithValue("@CompanyShort", Session["COMPANYSHORT"].ToString());
            cmd.Parameters.AddWithValue("@CompanyFull", Session["COMPANY"].ToString());
            cmd.Parameters.AddWithValue("@MBY", Session["ID"].ToString());
            cmd.Parameters.AddWithValue("@tblCoBorrower", CoBorrowerDataTable(gvCO));

            //DataTable dt = new DataTable();
            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //da.Fill(6);


            int uprs = cmd.ExecuteNonQuery();
            if (uprs >= 2)
            {

                //string confirmValue = Request.Form["confirm_value"];
                //if (confirmValue == "Yes")
                //{
                //    ClearMODTDScreen();
                //    View();
                //   // Print();
                //}
                //else
                //{

                //}


                uscMsgBox1.AddMessage("MODTD done Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                ClearMODTDScreen();
                View();

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally { con.Close(); }

    }

    public DataTable CoBorrowerDataTable(GridView pgv)
    {
        DataTable passdt = new DataTable();
        try
        {

            DataRow dr = null;
            passdt.Columns.Add(new DataColumn("MCB_SLNO", typeof(int)));
            passdt.Columns.Add(new DataColumn("MCB_NAME", typeof(string)));
            passdt.Columns.Add(new DataColumn("MCB_FNAME", typeof(string)));
            passdt.Columns.Add(new DataColumn("MCB_AGE", typeof(string)));
            passdt.Columns.Add(new DataColumn("MCB_MOTD", typeof(string)));

            foreach (GridViewRow pdr in pgv.Rows)
            {
                int index = pdr.RowIndex;

                dr = passdt.NewRow();

                CheckBox chkStat = pdr.FindControl("chkbxcbrwinclude") as CheckBox;
                dr["MCB_SLNO"] = index + 1;
                dr["MCB_NAME"] = pgv.Rows[index].Cells[1].Text;
                dr["MCB_FNAME"] = pgv.Rows[index].Cells[2].Text;
                dr["MCB_AGE"] = pgv.Rows[index].Cells[3].Text;

                if (chkStat.Checked)
                    dr["MCB_MOTD"] = "Y";
                else
                    dr["MCB_MOTD"] = "N";


                passdt.Rows.Add(dr);
            }
        }
        catch { }

        return passdt;

    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
    }
    protected void Print()
    {


        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmdmd = new SqlCommand("RTS_SP_RPT_MODTD_BRW_CBRW", con);
            cmdmd.Parameters.AddWithValue("@LDNO", Session["LDNOS"].ToString());
            cmdmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter damd = new SqlDataAdapter(cmdmd);
            DataSet dsmd = new DataSet();
            damd.Fill(dsmd);

            if (dsmd.Tables[0].Rows.Count <= 0)
            {
                uscMsgBox1.AddMessage("Please check the lead number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {

                string amt = "";
                string TMP = dsmd.Tables[0].Rows[0]["MD_LOAN_AMT"] == DBNull.Value ? "" : dsmd.Tables[0].Rows[0]["MD_LOAN_AMT"].ToString();
                if (TMP != "")
                {
                    string[] tp = TMP.Split('.');
                    amt = NumberToWords(Convert.ToInt32(tp[0]));
                }

                StringBuilder brw_cbrw = new StringBuilder();
                if (dsmd.Tables[0].Rows[0]["MD_BR1_NAME"] != DBNull.Value)
                {
                    brw_cbrw.Append("1) ");
                    brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_NAME"].ToString().TrimEnd());
                    brw_cbrw.Append(",");

                }

                /* Borrower Details*/
                if (dsmd.Tables[0].Rows[0]["MD_BR1_FNAME"] != DBNull.Value)
                {
                    brw_cbrw.Append("S/W/F of ");
                    brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_NAME"].ToString().TrimEnd());
                    brw_cbrw.Append(",");
                }


                if (dsmd.Tables[0].Rows[0]["MD_BR1_AGE"] != DBNull.Value)
                {
                    brw_cbrw.Append(" aged about ");
                    brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_AGE"].ToString().TrimEnd());
                    brw_cbrw.Append(" years,");
                }




                /*Co - Borrower Details*/

                for (int i = 0; i <= dsmd.Tables[1].Rows.Count - 1; i++)
                {

                    brw_cbrw.AppendLine();
                    brw_cbrw.Append((i + 2).ToString() + ") ");
                    brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_NAME"].ToString().TrimEnd());
                    brw_cbrw.Append(",");
                    brw_cbrw.Append("S/W/F of ");
                    brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_FNAME"].ToString().TrimEnd());
                    brw_cbrw.Append(",");
                    brw_cbrw.Append(" aged about ");
                    brw_cbrw.Append(dsmd.Tables[1].Rows[i]["MCB_AGE"].ToString().TrimEnd());
                    brw_cbrw.Append(" years,");


                }


                int cnt = 1 + dsmd.Tables[1].Rows.Count;



                //  for(int brw=0; brw<=dsmd.Tables[0])1
                rpt = new ReportDocument();

                //ParameterValues para = new ParameterValues(); 
                //set a ReportPath and assign the dataset to reportdocument object
                rpt.Load(Server.MapPath("Reports/MODTD.rpt"));

                rpt.SetDatabaseLogon("uno", "uno", @"172.16.2.95", "RTS1");
                //assign the values to crystal report viewer                              
                rpt.SetParameterValue(0, Session["LDNOS"].ToString());
                rpt.SetParameterValue(1, amt);
                rpt.SetParameterValue(2, brw_cbrw.ToString());
                rpt.SetParameterValue(3, cnt);
                rpt.SetParameterValue(4, Session["LDNOS"].ToString());
                rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "MOTD For " + Session["SanctionNo"].ToString() + "");

            }

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
            rpt.Close();
            rpt.Dispose();
            rpt = null;
            GC.Collect();

        }
    }

    protected void ClearMODTDScreen()
    {
        txtSanctionno.Text = "";
        txtbxloanamt.Text = "";
        txtDate.Text = "";
        txtname1.Text = "";
        txtofname1.Text = "";
        txtage1.Text = "";
        gvCO.DataSource = null;
        gvCO.DataBind();
        txtResiding1.Text = "";
        txtResiding2.Text = "";
        txtResiding3.Text = "";
        txtProperty.Text = "";
        gvview.DataSource = null;
        gvview.DataBind();
        //txtbxpropschedule.Text = "";
        //txtbxnorthby.Text = "";
        //txtbxsouthby.Text = "";
        //txtbxwestby.Text = "";
        //txtbxeastby.Text = "";
        //txtbxregoffice.Text = "";


    }

    protected void btnPreview_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmdmd = new SqlCommand("RTS_SP_RPT_MODIFYD_BRW_CBRW", con);
            //cmdmd.Parameters.AddWithValue("@LDNO", Session["LDNOS"].ToString());
            cmdmd.CommandType = CommandType.StoredProcedure;
            cmdmd.CommandTimeout = 20000;
            cmdmd.Parameters.AddWithValue("@LDNO", Session["LDNOS"].ToString());
            SqlDataAdapter damd = new SqlDataAdapter(cmdmd);
            DataSet dsmd = new DataSet();
            damd.Fill(dsmd);

            if (dsmd.Tables[0].Rows.Count <= 0)
            {
                uscMsgBox1.AddMessage("Please check the lead number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {

                string amt = "";
                string TMP = dsmd.Tables[0].Rows[0]["MD_LOAN_AMT"] == DBNull.Value ? "" : dsmd.Tables[0].Rows[0]["MD_LOAN_AMT"].ToString();
                //if (TMP != "")
                //{
                //    string[] tp = TMP.Split('.');
                //    amt = NumberToWords(Convert.ToInt32(tp[0]));
                //}

                StringBuilder brw_cbrw = new StringBuilder();
                if (dsmd.Tables[0].Rows[0]["MD_BR1_NAME"] != DBNull.Value)
                {
                    brw_cbrw.Append("1) ");
                    brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_NAME"].ToString().TrimEnd());
                    brw_cbrw.Append(",");

                }

                /* Borrower Details*/
                if (dsmd.Tables[0].Rows[0]["MD_BR1_FNAME"] != DBNull.Value)
                {
                    brw_cbrw.Append("S/W/F of ");
                    brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_FNAME"].ToString().TrimEnd());
                    brw_cbrw.Append(",");
                }


                if (dsmd.Tables[0].Rows[0]["MD_BR1_AGE"] != DBNull.Value)
                {
                    brw_cbrw.Append(" aged about ");
                    brw_cbrw.Append(dsmd.Tables[0].Rows[0]["MD_BR1_AGE"].ToString().TrimEnd());
                    brw_cbrw.Append(" years,");
                }




                /*Co - Borrower Details*/

                //for (int i = 0; i <= dsmd.Tables[2].Rows.Count - 1; i++)
                //{

                //    brw_cbrw.AppendLine();
                //    brw_cbrw.Append((i + 2).ToString() + ") ");
                //    brw_cbrw.Append(dsmd.Tables[2].Rows[i]["MCB_NAME"].ToString().TrimEnd());
                //    brw_cbrw.Append(",");
                //    brw_cbrw.Append("S/W/F of ");
                //    brw_cbrw.Append(dsmd.Tables[2].Rows[i]["MCB_FNAME"].ToString().TrimEnd());
                //    brw_cbrw.Append(",");
                //    brw_cbrw.Append(" aged about ");
                //    brw_cbrw.Append(dsmd.Tables[2].Rows[i]["MCB_AGE"].ToString().TrimEnd());
                //    brw_cbrw.Append(" years,");
                //}


                //int cnt = 1 + dsmd.Tables[2].Rows.Count;

                #region  MODT Draft
                //string amt = "";
                //if (txtbxloanamt.Text.Trim() != "")
                //{
                //    string[] tp = txtbxloanamt.Text.Split('.');
                //    amt = NumberToWords(Convert.ToInt32(tp[0]));
                //}
                //StringBuilder brw_cbrw = new StringBuilder();
                //brw_cbrw.Append("1) ");
                //brw_cbrw.Append(txtname1.Text.Trim());
                //brw_cbrw.Append(",");
                //brw_cbrw.Append("S/W/F of ");
                //brw_cbrw.Append(txtofname1.Text.ToString().TrimEnd());
                //brw_cbrw.Append(",");
                //brw_cbrw.Append(" aged about ");
                //brw_cbrw.Append(txtage1.Text.ToString().TrimEnd());
                //brw_cbrw.Append(" years,");

                string cbwName = string.Empty;
                string cbwFname = string.Empty;
                string cbwAge = string.Empty;
                DataTable dtCBW = new DataTable();
                dtCBW.Columns.Add("CBW_NAME", typeof(string));
                dtCBW.Columns.Add("CBW_FNAME", typeof(string));
                dtCBW.Columns.Add("CBW_AGE", typeof(string));
                DataRow dtRow;
                foreach (GridViewRow gvRow in gvCO.Rows)
                {
                    cbwName = gvRow.Cells[1].Text;
                    cbwFname = gvRow.Cells[2].Text;
                    cbwAge = gvRow.Cells[3].Text;
                    if (Convert.ToString(dsmd.Tables[0].Rows[0]["MD_BR1_NAME"]) == cbwName)
                    {
                        if (Convert.ToString(dsmd.Tables[0].Rows[0]["MD_BR1_FNAME"]) != cbwFname && Convert.ToString(dsmd.Tables[0].Rows[0]["MD_BR1_AGE"]) != cbwAge)
                        {
                            dtRow = dtCBW.NewRow();
                            dtRow["CBW_NAME"] = cbwName;
                            dtRow["CBW_FNAME"] = cbwFname;
                            dtRow["CBW_AGE"] = cbwAge;
                            dtCBW.Rows.Add(dtRow);
                            dtCBW.AcceptChanges();
                        }
                    }
                    else
                    {
                        dtRow = dtCBW.NewRow();
                        dtRow["CBW_NAME"] = cbwName;
                        dtRow["CBW_FNAME"] = cbwFname;
                        dtRow["CBW_AGE"] = cbwAge;
                        dtCBW.Rows.Add(dtRow);
                        dtCBW.AcceptChanges();
                    }
                }
                if (dtCBW.Rows.Count > 0)
                {
                    for (int i = 0; i <= dtCBW.Rows.Count - 1; i++)
                    {

                        brw_cbrw.AppendLine();
                        brw_cbrw.Append((i + 2).ToString() + ") ");
                        brw_cbrw.Append(dtCBW.Rows[i]["CBW_NAME"].ToString().TrimEnd());
                        brw_cbrw.Append(",");
                        brw_cbrw.Append("S/W/F of ");
                        brw_cbrw.Append(dtCBW.Rows[i]["CBW_FNAME"].ToString().TrimEnd());
                        brw_cbrw.Append(",");
                        brw_cbrw.Append(" aged about ");
                        brw_cbrw.Append(dtCBW.Rows[i]["CBW_AGE"].ToString().TrimEnd());
                        brw_cbrw.Append(" years,");
                    }
                }
                int cnt = 1 + dtCBW.Rows.Count;
                #endregion
                amt = NumberToWords(Convert.ToInt32(txtbxloanamt.Text.Trim()));
                rpt = new ReportDocument();

                //ParameterValues para = new ParameterValues(); 
                //set a ReportPath and assign the dataset to reportdocument object
                //rpt.Load(Server.MapPath("Reports/MODTD_D1.rpt"));
                if (dsmd.Tables[0].Rows[0]["MD_SM_APPLCNT"].ToString() == "Yes")
                {
                    rpt.Load(Server.MapPath("Reports/MODTDF1_D.rpt"));
                }
                else if (dsmd.Tables[0].Rows[0]["MD_SM_APPLCNT"].ToString() == "No")
                {
                    rpt.Load(Server.MapPath("Reports/MODTDF2_D.rpt"));
                }
                else
                {
                    rpt.Load(Server.MapPath("Reports/MODTD_D.rpt"));
                }

                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);
                if (dsmd.Tables[0].Rows[0]["MD_SM_APPLCNT"].ToString() == "")
                {
                    rpt.SetParameterValue(0, Session["LDNOS"].ToString());
                    rpt.SetParameterValue(1, amt);
                    //rpt.SetParameterValue(1, amt);
                    rpt.SetParameterValue(2, brw_cbrw.ToString());

                    rpt.SetParameterValue(3, cnt);
                    rpt.SetParameterValue(4, Session["COMPANYSHORT"].ToString());
                    rpt.SetParameterValue(5, txtbxloanamt.Text.Trim());
                    rpt.SetParameterValue(6, Session["COMPANY"].ToString());
                    rpt.SetParameterValue(7, Session["LDNOS"].ToString());
                    //For Documents Report
                    rpt.SetParameterValue(8, Session["LDNOS"].ToString());
                }
                else
                {
                    rpt.SetParameterValue(0, Session["LDNOS"].ToString());
                    rpt.SetParameterValue(1, amt);
                    rpt.SetParameterValue(2, brw_cbrw.ToString());
                    rpt.SetParameterValue(3, cnt);
                    rpt.SetParameterValue(4, txtSanctionno.Text);
                    rpt.SetParameterValue(5, txtbxloanamt.Text);
                    rpt.SetParameterValue(6, Session["LDNOS"].ToString());
                    rpt.SetParameterValue(7, Session["LDNOS"].ToString());
                }

                rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "MOTD Draft For " + Session["SanctionNo"].ToString() + "");


            }

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
            rpt.Close();
            rpt.Dispose();
            rpt = null;
            GC.Collect();

        }
    }
}