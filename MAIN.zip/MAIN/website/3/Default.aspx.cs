﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Threading;
using Tracker;

public partial class _Default : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {//live
            //if (Session["ID"] != null)
            //{
            if (Request.QueryString["LoginName"] != null && Request.QueryString["LoginPwd"] != null)
            {
                txt_username.Text = Request.QueryString["LoginName"].ToString();
                txt_password.Text = Request.QueryString["LoginPwd"].ToString();
                login();
            }

            btnExit.Attributes.Add("onclick", "window.close()");
            //}
            //else
            //{
            //    Response.Redirect("default.aspx");
            //}
        }
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        login();
    }
    public void login()
    {
        SqlConnection con = new SqlConnection(strcon);
        DataSet ds = new DataSet();
        try
        {
            Session["LoginName"] = txt_username.Text;
            Session["LoginPwd"] = txt_password.Text;
            con.Open();
            //  SqlCommand cmd = new SqlCommand("SELECT A.EMP_CODE,B.USR_PWD,A.EMP_NAME,C.ET_DESC,B.USR_LLOGIN,C.ET_CODE,B.USR_PWDM,B.USR_ID,B.USR_UTP_ID,B.USR_STAT,MB.BR_NAME FROM MR_EMPLOYEE A JOIN MR_USER B ON A.EMP_ID=B.USR_EMP_ID JOIN MR_EMP_TYPE C ON A.EMP_ET_ID=C.ET_ID JOIN MR_BRANCH MB ON MB.BR_ID= A.EMP_BR_ID WHERE EMP_CODE='" + txt_username.Text.ToUpper() + "'", con);
            SqlCommand cmd = null;
            if (txt_username.Text.ToUpper() != "" || txt_password.Text != "")
            {
                if (ddlModule.SelectedValue != "0")
                {

                    if (ddlModule.SelectedValue == "RTS")
                    {

                        cmd = new SqlCommand("SELECT A.EMP_ID,A.EMP_CODE,A.EMP_ET_ID,A.EMP_EMAILID,A.EMP_TYPE,B.USR_PWD,A.EMP_NAME,C.ET_DESC,B.USR_LLOGIN,B.USR_UAL_ID,C.ET_CODE,B.USR_PWDM,B.USR_ID,B.USR_UTP_ID,B.USR_STAT,MB.BR_NAME,MB.BR_CODE FROM MR_EMPLOYEE A JOIN MR_USER B ON A.EMP_ID=B.USR_EMP_ID JOIN MR_EMP_TYPE C ON A.EMP_ET_ID=C.ET_ID JOIN MR_BRANCH MB ON MB.BR_ID= A.EMP_BR_ID WHERE EMP_CODE='" + txt_username.Text.ToUpper() + "' AND (B.USR_TYPE ='R' OR B.USR_TYPE='B')  ", con);
                    }
                    //  else
                    if (ddlModule.SelectedValue == "RMP")
                    {
                        cmd = new SqlCommand("SELECT A.EMP_ID,A.EMP_CODE,A.EMP_ET_ID,A.EMP_EMAILID,A.EMP_TYPE,B.USR_PWD,A.EMP_NAME,C.ET_DESC,B.USR_LLOGIN,B.USR_UAL_ID,C.ET_CODE,B.USR_PWDM,B.USR_ID,B.USR_UTP_ID,B.USR_STAT,MB.BR_NAME,MB.BR_CODE FROM MR_EMPLOYEE A JOIN MR_USER B ON A.EMP_ID=B.USR_EMP_ID JOIN MR_EMP_TYPE C ON A.EMP_ET_ID=C.ET_ID JOIN MR_BRANCH MB ON MB.BR_ID= A.EMP_BR_ID WHERE EMP_CODE='" + txt_username.Text.ToUpper() + "' AND (B.USR_TYPE ='M' OR B.USR_TYPE='B') ", con);
                    }
                    SqlDataAdapter showdata = new SqlDataAdapter(cmd);
                    showdata.Fill(ds);
                    if (txt_username.Text.ToUpper() == "" || txt_password.Text == "")
                    {
                        //Response.Write("<script>alert('Enter User ID and Password')</script>");
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", "alert('Enter User ID and Password');", true);
                        ScriptManager.RegisterClientScriptBlock(this.btnLogin, this.GetType(), "alert", "swal({title:'Heyyy!!!',text:'Enter User ID and Password',imageUrl:'Images/JPG/enter.jpg'});", true);
                    }
                    else if (ds.Tables[0].Rows.Count == 0 || txt_password.Text != ds.Tables[0].Rows[0]["USR_PWD"].ToString())
                    {
                        //Response.Write("<script>alert('Enter User ID and Password')</script>");
                        //ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('Invalid User ID / Password');", true);
                        ScriptManager.RegisterClientScriptBlock(this.btnLogin, this.GetType(), "alert", "swal({title:'Oh Ohhhhh!!!',text:'Invalid User ID / Password',imageUrl:'Images/JPG/invalid.jpg'});", true);
                    }
                    else if (ds.Tables[0].Rows[0]["USR_PWDM"].ToString() == "1/1/1900 12:00:00 AM" || ds.Tables[0].Rows[0]["USR_PWDM"].ToString() == "")
                    {
                        Session["ID"] = ds.Tables[0].Rows[0]["USR_ID"];
                        Session["TYPEID"] = ds.Tables[0].Rows[0]["USR_UTP_ID"];
                        Session["USR_ID"] = ds.Tables[0].Rows[0]["EMP_CODE"];
                        Session["User"] = ds.Tables[0].Rows[0]["EMP_NAME"].ToString();
                        Session["Lastlogin"] = ds.Tables[0].Rows[0]["USR_LLOGIN"];
                        Session["USR_DESG"] = ds.Tables[0].Rows[0]["ET_DESC"].ToString();
                        Session["USR_TYPE"] = ds.Tables[0].Rows[0]["ET_DESC"].ToString();
                        Session["UNITNAME"] = ds.Tables[0].Rows[0]["BR_NAME"].ToString();
                        Session["USR_ACS"] = ds.Tables[0].Rows[0]["USR_UAL_ID"].ToString();
                        Session["EMP_CODE"] = ds.Tables[0].Rows[0]["EMP_CODE"].ToString();
                        Session["EMP_TYPE"] = ds.Tables[0].Rows[0]["EMP_TYPE"];
                        Session["EMP_ET_ID"] = ds.Tables[0].Rows[0]["EMP_ET_ID"];
                        Session["BR_CODE"] = ds.Tables[0].Rows[0]["BR_CODE"];
                        //Bala changes 12/12/2015
                        Session["EMP_ID"] = ds.Tables[0].Rows[0]["EMP_ID"];
                        Session["EMP_EMAILID"] = ds.Tables[0].Rows[0]["EMP_EMAILID"];
                        //Session["Pro"] = ds.Tables[0].Rows[0]["PRDT_ACCS"].ToString();
                        //Session["logi"] = ds.Tables[0].Rows[0]["LGSTCS_ACCS"].ToString();
                        //string fileLoc = @"C:\WINDOWS\Temp\" + txt_username.Text + ".txt";
                        //if (!File.Exists(fileLoc))
                        //{
                        //    FileStream fs = null;
                        //    fs = File.Create(fileLoc);
                        //    fs.Close();
                        //}
                        cmd = new SqlCommand("update MR_USER set USR_LLOGIN = '" + DateTime.Now.ToString("yyyy-MM-dd H:mm:ss") + "' where USR_ID = '" + Session["ID"] + "'", con);
                        cmd.ExecuteNonQuery();

                        #region User Login Log


                        HttpCookie userLog = new HttpCookie("userLogCookie");
                        userLog.Value = Convert.ToString(Session["ID"]);
                        userLog.Expires = DateTime.Now.AddHours(10);
                        Response.Cookies.Add(userLog);
                        string now = DateTime.Now.ToString("yyyy-MM-dd H:mm:ss");
                        HttpCookie userLoginTime = new HttpCookie("loginTimeCookie");
                        userLoginTime.Value = Convert.ToString(now);
                        userLoginTime.Expires = DateTime.Now.AddHours(10);
                        Response.Cookies.Add(userLoginTime);
                        cmd = new SqlCommand("insert into LSD_USER_LOG (UL_USR_ID,UL_LI_DATE) values ('" + Request.Cookies["userLogCookie"].Value + "','" + now + "')", con);
                        cmd.ExecuteNonQuery();
                        #endregion
                        Response.Redirect("Change Password.aspx");
                    }
                    else if (txt_username.Text.ToUpper() == ds.Tables[0].Rows[0]["EMP_CODE"].ToString() && txt_password.Text == ds.Tables[0].Rows[0]["USR_PWD"].ToString())
                    {
                        if (ds.Tables[0].Rows[0]["USR_STAT"].ToString() == "1")
                        {
                            Session["ID"] = ds.Tables[0].Rows[0]["USR_ID"];
                            Session["TYPEID"] = ds.Tables[0].Rows[0]["USR_UTP_ID"];
                            Session["USR_ID"] = ds.Tables[0].Rows[0]["EMP_CODE"];
                            Session["User"] = ds.Tables[0].Rows[0]["EMP_NAME"].ToString();
                            Session["Lastlogin"] = ds.Tables[0].Rows[0]["USR_LLOGIN"];
                            Session["USR_DESG"] = ds.Tables[0].Rows[0]["ET_DESC"].ToString();
                            Session["USR_TYPE"] = ds.Tables[0].Rows[0]["ET_DESC"].ToString();
                            Session["UNITNAME"] = ds.Tables[0].Rows[0]["BR_NAME"].ToString();
                            Session["USR_ACS"] = ds.Tables[0].Rows[0]["USR_UAL_ID"].ToString();
                            Session["EMP_CODE"] = ds.Tables[0].Rows[0]["EMP_CODE"].ToString();
                            Session["EMP_ID"] = ds.Tables[0].Rows[0]["EMP_ID"];
                            Session["EMP_TYPE"] = ds.Tables[0].Rows[0]["EMP_TYPE"];
                            Session["EMP_ET_ID"] = ds.Tables[0].Rows[0]["EMP_ET_ID"];
                            Session["EMP_EMAILID"] = ds.Tables[0].Rows[0]["EMP_EMAILID"];
                            Session["BR_CODE"] = ds.Tables[0].Rows[0]["BR_CODE"];
                            //Session["Pro"] = ds.Tables[0].Rows[0]["PRDT_ACCS"].ToString();
                            //Session["logi"] = ds.Tables[0].Rows[0]["LGSTCS_ACCS"].ToString();
                            string fileLoc = @"C:\WINDOWS\Temp\" + txt_username.Text + ".txt";
                            //if (!File.Exists(fileLoc))
                            //{
                            //    FileStream fs = null;
                            //    fs = File.Create(fileLoc);
                            //    fs.Close();
                            //}
                            cmd = new SqlCommand("update MR_USER set USR_LLOGIN = '" + DateTime.Now.ToString("yyyy-MM-dd H:mm:ss") + "' where USR_ID = '" + Session["ID"] + "'", con);
                            cmd.ExecuteNonQuery();


                            #region User Login Log


                            HttpCookie userLog = new HttpCookie("userLogCookie");
                            userLog.Value = Convert.ToString(Session["ID"]);
                            userLog.Expires = DateTime.Now.AddHours(10);
                            Response.Cookies.Add(userLog);
                            string now = DateTime.Now.ToString("yyyy-MM-dd H:mm:ss");
                            HttpCookie userLoginTime = new HttpCookie("loginTimeCookie");
                            userLoginTime.Value = Convert.ToString(now);
                            userLoginTime.Expires = DateTime.Now.AddHours(10);
                            Response.Cookies.Add(userLoginTime);
                            cmd = new SqlCommand("insert into LSD_USER_LOG (UL_USR_ID,UL_LI_DATE) values ('" + Request.Cookies["userLogCookie"].Value + "','" + now + "')", con);
                            cmd.ExecuteNonQuery();
                            #endregion

                            if (ddlModule.SelectedItem.Text == "RTS")
                            {
                                Response.Redirect("Home.aspx");
                            }
                            else
                            {
                                Response.Redirect("http://rts.equitasbank.com/RMP/DashboardPipeline.aspx?val=" + Convert.ToBase64String(ASCIIEncoding.UTF8.GetBytes(Convert.ToString(Session["USR_ID"]))));

                                //if (Session["TYPEID"].ToString() == "2")
                                //{
                                //   // Response.Redirect("http://172.16.2.95/RMP/Home.aspx?ID=" + Session["ID"].ToString() + "&TYPEID=" + Session["TYPEID"].ToString() + "&USR_ID=" + Session["USR_ID"].ToString() + "&User=" + Session["User"].ToString() + "&Lastlogin=" + Session["Lastlogin"].ToString() + "&USR_TYPE=" + Session["USR_TYPE"].ToString() + "&USR_DESG=" + Session["USR_DESG"].ToString() + "&BRANCH=" + Session["UNITNAME"].ToString() + "");
                                //    Response.Redirect("http://rts.equitasbank.com/RMP/Home.aspx?ID=" + Session["ID"].ToString() + "&TYPEID=" + Session["TYPEID"].ToString() + "&USR_ID=" + Session["USR_ID"].ToString() + "&User=" + Session["User"].ToString() + "&Lastlogin=" + Session["Lastlogin"].ToString() + "&USR_TYPE=" + Session["USR_TYPE"].ToString() + "&USR_DESG=" + Session["USR_DESG"].ToString() + "&BRANCH=" + Session["UNITNAME"].ToString() + "");

                                //}
                                //else
                                //{
                                //    //Response.Redirect("http://172.16.2.95/RMP/Home.aspx?ID=" + Session["ID"].ToString() + "&TYPEID=" + Session["TYPEID"].ToString() + "&USR_ID=" + Session["USR_ID"].ToString() + "&User=" + Session["User"].ToString() + "&Lastlogin=" + Session["Lastlogin"].ToString() + "&USR_TYPE=" + Session["USR_TYPE"].ToString() + "&USR_DESG=" + Session["USR_DESG"].ToString() + "&BRANCH=" + Session["UNITNAME"].ToString() + "");
                                //    Response.Redirect("http://rts.equitasbank.com/RMP/Home.aspx?ID=" + Session["ID"].ToString() + "&TYPEID=" + Session["TYPEID"].ToString() + "&USR_ID=" + Session["USR_ID"].ToString() + "&User=" + Session["User"].ToString() + "&Lastlogin=" + Session["Lastlogin"].ToString() + "&USR_TYPE=" + Session["USR_TYPE"].ToString() + "&USR_DESG=" + Session["USR_DESG"].ToString() + "&BRANCH=" + Session["UNITNAME"].ToString() + "");

                                //}
                                //Response.Redirect("http://172.16.2.95/LTS");
                                // Response.Redirect("http://rts.equitasbank.com/RMP/Home.aspx?ID=" + Session["ID"].ToString() + "&TYPEID=" + Session["TYPEID"].ToString() + "&USR_ID=" + Session["USR_ID"].ToString() + "&User=" + Session["User"].ToString() + "&Lastlogin=" + Session["Lastlogin"].ToString() + "&USR_TYPE=" + Session["USR_TYPE"].ToString() + "&USR_DESG=" + Session["USR_DESG"].ToString() + "&UNITNAME=" + Session["UNITNAME"].ToString() + "");
                            }
                        }
                        else if (ds.Tables[0].Rows[0]["USR_STAT"].ToString() == "0")
                        {
                            //uscMsgBox1.AddMessage("Given User is Inactive", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                            ScriptManager.RegisterClientScriptBlock(this.btnLogin, this.GetType(), "alert", "swal({title:'ohhhhhhh!!!',text:'Given User is Inactive',imageUrl:'Images/JPG/norecord.jpg'});", true);
                        }
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this.btnLogin, this.GetType(), "alert", "swal({title:'Heyyy!!!',text:'Please select application type',imageUrl:'Images/JPG/enter.jpg'});", true);

                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this.btnLogin, this.GetType(), "alert", "swal({title:'Heyyy!!!',text:'Enter User ID and Password',imageUrl:'Images/JPG/enter.jpg'});", true);
            }


        }
        catch (Exception ex)
        {
            //uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ScriptManager.RegisterClientScriptBlock(this.btnLogin, this.GetType(), "alert", "swal({title:'',text:'Invalid Input',imageUrl:'Images/JPG/invalid.jpg'});", true);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnExit_Click(object sender, EventArgs e)
    {

    }
}
