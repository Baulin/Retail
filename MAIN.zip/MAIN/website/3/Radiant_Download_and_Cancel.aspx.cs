﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Ionic.Zip;
using System.Text;
using System.ComponentModel;
using System.Net;
using Tracker;

public partial class Radiant_Download_and_Cancel : System.Web.UI.Page
{
    #region SQL FIELDS

    SqlConnection con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_Obj = new SqlCommand();
    DataTable dt_obj = new DataTable();
    CreateLogFiles Err = new CreateLogFiles();

    //double size = 9046;
    double size = 9766;
    //double size = 48;
    double f_size = 0;
    List<string> listAsyncDownload = new List<string>();
    string serverTime = string.Empty;
    Dictionary<string, string> fileList = new Dictionary<string, string>();
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    bindArea();
                    dateBind();
                    bindProduct();
                    //copy();                    
                }
            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlst_Action.SelectedValue == "D")
            {
                trCancelGrid.Visible = false;
                trCancel.Visible = false;
                trCancelReason.Visible = false;
                trFileSize.Visible = true;
                trAsynDownload.Visible = true;
                //bind(serverTime);
                bind();
                RegisterPostBackControl();
            }
            else
            {
                trCancelGrid.Visible = true;
                trCancel.Visible = true;
                trCancelReason.Visible = true;
                trReceiptDwnld.Visible = false;
                trFileSize.Visible = false;
                trAsynDownload.Visible = false;
                serverTime = getServerTime();
                collection_Proccess(ddlst_Branch.SelectedValue, "2015-10-01", serverTime, ddlProduct.SelectedItem.Text);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void bindArea()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();

            cmd_Obj = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
            }
            else
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", 0);
            }
            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());




            ddlst_Area.DataSource = dt_obj;
            ddlst_Area.DataTextField = "AR_NAME";
            ddlst_Area.DataValueField = "AR_ID";
            ddlst_Area.DataBind();

            ddlst_Area.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Area.SelectedValue = Session["AREA_ID"].ToString();

            bindBranch();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }


    }

    public void bindBranch()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);

            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());



            ddlst_Branch.DataSource = dt_obj;
            ddlst_Branch.DataTextField = "BR_NAME";
            ddlst_Branch.DataValueField = "BR_ID";
            ddlst_Branch.DataBind();
            ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
            if (Session["USR_ACS"].ToString() == "7")
            {
                ddlst_Branch.SelectedValue = Session["BRANCHID"].ToString();
                ddlst_Branch.Enabled = false;
                ddlst_Area.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }

    }

    protected void ddlst_Area_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ClearValues();
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);
            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());

            ddlst_Branch.DataSource = dt_obj;
            ddlst_Branch.DataTextField = "BR_NAME";
            ddlst_Branch.DataValueField = "BR_ID";
            ddlst_Branch.DataBind();
            ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Branch.Enabled = true;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }
    }

    //protected void bind(string date)
    protected void bind()
    {
        try
        {
            string[] fileNames = Directory.GetFiles(Server.MapPath("~\\Upload\\File\\"));
            int nameIndex = 0;
            string branch = "";
            string[] file;
            string f = "";
            string date = "";
            //date = "";
            string area = "";
            dt_obj.Columns.Add("BranchName", typeof(string));
            dt_obj.Columns.Add("FilePath", typeof(string));
            dt_obj.Columns.Add("ReceiptNumber", typeof(string));
            dt_obj.Columns.Add("ReceiptDate", typeof(string));
            dt_obj.Columns.Add("ReceiptAmount", typeof(string));
            dt_obj.Columns.Add("FileSize", typeof(double));
            foreach (var item in fileNames)
            {
                if (item != Convert.ToString(Server.MapPath("~\\Upload\\File\\" + "Thumbs.db")))
                {
                    double length = new FileInfo(item).Length / 1024;
                    nameIndex = item.LastIndexOf("\\") + 1;
                    f = item.Remove(0, nameIndex);
                    f = f.Remove(f.Length - 4);
                    file = f.Split('_');
                    branch = file[1];
                    area = file[0];
                    date = file[2];
                    if (ddlst_Branch.SelectedIndex != 0)
                    {
                        if (branch.ToString() == ddlst_Branch.SelectedItem.Text)
                        {
                            DataRow dtRow = dt_obj.NewRow();
                            dtRow["BranchName"] = file[1];
                            dtRow["ReceiptDate"] = file[2];
                            dtRow["ReceiptNumber"] = file[3];
                            dtRow["ReceiptAmount"] = file[4] + ".00";
                            dtRow["FilePath"] = Convert.ToString(item);
                            dtRow["FileSize"] = length;
                            dt_obj.Rows.Add(dtRow);
                        }
                    }
                    if (ddlDate.SelectedIndex != 0)
                    {
                        if ((area.ToString() == ddlst_Area.SelectedItem.Text) && (date.ToString() == ddlDate.SelectedItem.Text))
                        {
                            DataRow dtRow = dt_obj.NewRow();
                            dtRow["BranchName"] = file[1];
                            dtRow["ReceiptDate"] = file[2];
                            dtRow["ReceiptNumber"] = file[3];
                            dtRow["ReceiptAmount"] = file[4] + ".00";
                            dtRow["FilePath"] = Convert.ToString(item);
                            dtRow["FileSize"] = length;
                            dt_obj.Rows.Add(dtRow);
                        }
                    }
                }
            }
            trReceiptDwnld.Visible = true;
            gvReceiptDwnld.DataSource = dt_obj;
            gvReceiptDwnld.DataBind();
            ////ScriptManager.RegisterStartupScript(Page, this.GetType(), "freez", "freezing();", true);

            //con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            //if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
            //    con_Obj.Open();
            //date = Convert.ToString(Convert.ToDateTime(date).AddDays(1).ToString("yyyy-MM-dd"));
            //string qry = "select * from LSD_RECEIPT where RC_RDATE between '2015-08-19' and '" + date + "'";
            //SqlCommand cmdDownload = new SqlCommand(qry, con_Obj);
            //dt_obj = new DataTable();
            //dt_obj.Load(cmdDownload.ExecuteReader());
            //trReceiptDwnld.Visible = true;
            //gvReceiptDwnld.DataSource = dt_obj;
            //gvReceiptDwnld.DataBind();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    protected void DownloadFile(object sender, EventArgs e)
    {
        string filePath = (sender as LinkButton).CommandArgument;
        //filePath = Server.MapPath("~\\Upload\\File\\") + filePath;
        try
        {
            Response.ContentType = ContentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
            Response.WriteFile(filePath);
            Response.End();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //FileInfo hasFile = new FileInfo(filePath);
            //if (hasFile.Exists)
            //{
            //    Response.Flush();
            //    File.Delete(filePath);
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("This file does not exist.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            //}
            //bind(serverTime);
            bind();
        }
    }

    protected void collection_Proccess(string branchId, string stDate, string endDate, string pro)
    {
        try
        {
            //stDate = Convert.ToString(Convert.ToDateTime(stDate).ToString("yyyy-MM-dd"));
            endDate = Convert.ToString(Convert.ToDateTime(endDate).ToString("yyyy-MM-dd"));
            //stDate = "2015-08-19";
            //endDate = "2015-08-19";
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("RTS_MBL_RCPT_DET", con_Obj);
            cmd_Obj.CommandTimeout = 240000;
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@BR", branchId);
            cmd_Obj.Parameters.AddWithValue("@STDT", stDate);
            cmd_Obj.Parameters.AddWithValue("@ENDDT", endDate);
            //if (!string.IsNullOrEmpty(pro) && pro != "0")
            //{
            //    char c = pro.FirstOrDefault();
            //    cmd_Obj.Parameters.AddWithValue("@PRODUCT", c);
            //}
            //else
            cmd_Obj.Parameters.AddWithValue("@PRODUCT", DBNull.Value);
            dt_obj = new DataTable();
            dt_obj.Load(cmd_Obj.ExecuteReader());
            trCancelGrid.Visible = true;
            DataTable dtTempCollection = new DataTable();
            DataRow[] drTempProd = null;
            if (dt_obj.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(pro) && pro == "SME")
                {
                    //drTempProd = dt_obj.Select("PRODUCT = 'LAP' or PRODUCT ='SME' or PRODUCT ='G-LAP'");
                    //drTempProd = dt_obj.Select("(PRODUCT = 'LAP' or PRODUCT ='SME' or PRODUCT ='G-LAP' or PRODUCT ='EMP-LAP') and RECEIPT_MODE ='Cash'");
                    //bala changes 17/03/2017
                    drTempProd = dt_obj.Select("(PRODUCT <> 'IB-G-HF' AND PRODUCT <> 'IB-MFHF' AND PRODUCT <> 'EMP-HF' AND PRODUCT <> 'IB-Affordable Home' AND PRODUCT <> 'IB-TWL') and RECEIPT_MODE ='Cash'");
                    //drTempProd = dt_obj.Select("(PR_ID <> 4 AND PR_ID <> 3 AND PR_ID <> 'EMP-HF' AND PRODUCT <> 'TWL') and RECEIPT_MODE ='Cash'");
                }
                else if (pro == "IB-MFHF")
                {
                    //drTempProd = dt_obj.Select("PRODUCT = 'MF-HF' or PRODUCT ='G-HF'");
                    drTempProd = dt_obj.Select("(PRODUCT = 'IB-MFHF' or PRODUCT ='IB-G-HF' or PRODUCT ='EMP-HF' or PRODUCT ='IB-Affordable Home' ) and RECEIPT_MODE ='Cash'");
                }
                else if (pro == "IB-TWL")
                {
                    drTempProd = dt_obj.Select("(PRODUCT = 'IB-TWL') and RECEIPT_MODE ='Cash'");
                }
                if (drTempProd.Length > 0)
                    dtTempCollection = drTempProd.CopyToDataTable();
                //gridCancel.DataSource = dtTempCollection;
                //gridCancel.DataBind();
            }
            gridCancel.DataSource = dtTempCollection;
            gridCancel.DataBind();
            if (dtTempCollection.Rows.Count > 0)
                trCancelReason.Visible = true;
            else
                trCancelReason.Visible = false;
            dtTempCollection.Dispose();
            // ScriptManager.RegisterStartupScript(Page, this.GetType(), "freez", "freezing();", true);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    protected void ClearValues()
    {
        hdnServerTime.Value = "";
        txtReason.Text = "";
        lblResult.Text = "";
        trCancelGrid.Visible = false;
        trReceiptDwnld.Visible = false;
        trCancel.Visible = false;
        trCancelReason.Visible = false;
        trFileSize.Visible = false;
        trAsynDownload.Visible = false;
        ddlProduct.SelectedIndex = 0;
    }

    protected void ddlst_Branch_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlst_Action.SelectedIndex = 0;
        ddlDate.SelectedIndex = 0;
        ClearValues();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            SelectedInsert();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearValues();
        ddlst_Branch.SelectedIndex = 0;
        ddlst_Action.SelectedIndex = 0;
        lblResult.Text = "";
    }

    protected void ddlst_Action_SelectedIndexChanged(object sender, EventArgs e)
    {
        ClearValues();
        //if (ddlst_Action.SelectedValue == "D")
        //    trFileSize.Visible = true;
        //else
        //    trFileSize.Visible = false;
    }

    private void RegisterPostBackControl()
    {
        foreach (GridViewRow row in gvReceiptDwnld.Rows)
        {
            LinkButton lnkFull = row.FindControl("lnk_Rec_Dwnld") as LinkButton;
            ScriptManager.GetCurrent(this).RegisterPostBackControl(lnkFull);
        }
    }

    protected int SelectedInsert()
    {
        int rs = 0;
        try
        {
            dt_obj.Dispose();

            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("RTS_SP_FETCH_INSERT_RADIANT_RECEIPT", con_Obj);
            cmd_Obj.CommandTimeout = 240000;
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@PTYPE", "SERVDATE");
            dt_obj = new DataTable();
            dt_obj.Load(cmd_Obj.ExecuteReader());
            hdnServerTime.Value = Convert.ToString(dt_obj.Rows[0][0]);
            dt_obj.Rows.Clear();
            dt_obj.Columns.Clear();
            dt_obj.Clear();
            dt_obj.Columns.Add("RC_MBL_RNO", typeof(string));
            dt_obj.Columns.Add("RC_EMP_NO", typeof(string));
            dt_obj.Columns.Add("RC_EMP_NAME", typeof(string));
            dt_obj.Columns.Add("RC_REF_NO", typeof(string));
            dt_obj.Columns.Add("RC_DISB_BRNAME", typeof(string));
            dt_obj.Columns.Add("RC_PRODUCT", typeof(string));
            dt_obj.Columns.Add("RC_CNAME", typeof(string));
            dt_obj.Columns.Add("RC_AMT", typeof(double));
            dt_obj.Columns.Add("RC_RDATE", typeof(string));
            dt_obj.Columns.Add("RC_CNCL_DATE", typeof(string));
            dt_obj.Columns.Add("RC_CNCL_RMKS", typeof(string));
            dt_obj.Columns.Add("RC_SYN_DATE", typeof(string));
            dt_obj.Columns.Add("RC_BOOK_NO", typeof(string));

            foreach (GridViewRow gvRowChecked in gridCancel.Rows)
            {
                CheckBox chkbxIns = (CheckBox)gvRowChecked.FindControl("chkbxCollection");
                if (chkbxIns.Checked)
                {
                    Label lbl_ln_san_no = (Label)gvRowChecked.FindControl("lbl_loan_no");
                    Label lbl_brnh_Name = (Label)gvRowChecked.FindControl("lbl_branch");
                    Label lbl_cust_name = (Label)gvRowChecked.FindControl("lbl_cust_name");
                    Label lbl_product = (Label)gvRowChecked.FindControl("lbl_product");
                    Label lbl_rcno = (Label)gvRowChecked.FindControl("lbl_rc_number");
                    Label lbl_rcamt = (Label)gvRowChecked.FindControl("lbl_rc_amt_col");
                    Label lbl_ro_name = (Label)gvRowChecked.FindControl("lbl_ro_name");
                    Label lbl_ro_code = (Label)gvRowChecked.FindControl("lbl_ro_code");
                    Label lbl_rc_rdate = (Label)gvRowChecked.FindControl("lbl_rc_date");
                    Label lbl_rc_syn_amt = (Label)gvRowChecked.FindControl("lbl_rc_syn_amt");
                    Label lbl_Book_NO = (Label)gvRowChecked.FindControl("lbl_Book_NO");    
                    DataRow dtRow = dt_obj.NewRow();
                    //string[] rc_date = lbl_rc_rdate.Text.Trim().Substring(0, 10).Split('/');
                    //string rc_rdate = rc_date[0] + "/" + rc_date[1] + "/" + rc_date[2];
                    dtRow["RC_MBL_RNO"] = lbl_rcno.Text.ToUpper().Trim();
                    dtRow["RC_EMP_NO"] = lbl_ro_code.Text.Trim().ToUpper();
                    dtRow["RC_EMP_NAME"] = lbl_ro_name.Text.Trim().ToUpper();
                    dtRow["RC_REF_NO"] = lbl_ln_san_no.Text.ToUpper().Trim();
                    dtRow["RC_DISB_BRNAME"] = lbl_brnh_Name.Text.Trim().ToUpper();
                    dtRow["RC_PRODUCT"] = lbl_product.Text.Trim();
                    dtRow["RC_CNAME"] = lbl_cust_name.Text.Trim().ToUpper();
                    dtRow["RC_AMT"] = lbl_rcamt.Text;
                    //dtRow["RC_RDATE"] = rc_rdate;
                    dtRow["RC_RDATE"] = lbl_rc_rdate.Text.Trim();
                    //dtRow["RC_CNCL_DATE"] = hdnServerTime.Value;
                    dtRow["RC_CNCL_DATE"] = DateTime.Now.ToString();
                    dtRow["RC_CNCL_RMKS"] = txtReason.Text.Trim();
                    dtRow["RC_BOOK_NO"] = lbl_Book_NO.Text.Trim();
                    dt_obj.Rows.Add(dtRow);
                }
            }

            cmd_Obj = new SqlCommand("RTS_SP_FETCH_INSERT_RADIANT_RECEIPT", con_Obj);
            cmd_Obj.CommandTimeout = 240000;
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@PTYPE", "CANCEL");
            cmd_Obj.Parameters.AddWithValue("@RC_BR_ID", ddlst_Branch.SelectedItem.Text != "--Select--" ? ddlst_Branch.SelectedValue.ToString() : Session["BRANCHID"].ToString());
            cmd_Obj.Parameters.AddWithValue("@UserDefineTable", dt_obj);
            cmd_Obj.Parameters.AddWithValue("@RC_MBY", Convert.ToString(Session["ID"]) != "" ? Session["ID"].ToString() : "");
            rs = cmd_Obj.ExecuteNonQuery();
            if (rs > 0)
            {
                uscMsgBox1.AddMessage("Collection Cancelled successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                ClearValues();
            }
            else
                uscMsgBox1.AddMessage("Collection not Cancelled", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);


        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
        return rs;
    }

    protected void chkbxDownCollection_OnCheckedChanged(object sender, EventArgs e)
    {
        f_size = SelectedFileSize();
        if (f_size > size)
        {
            uscMsgBox1.AddMessage("The total file download size should be 4Mb or less", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            return;
        }

        txt_size.Text = Convert.ToString(f_size);
        // ScriptManager.RegisterStartupScript(Page, this.GetType(), "freez", "freezing();", true);
    }

    protected void chkbxDownAll_OnCheckedChanged(object sender, EventArgs e)
    {
        CheckBox chkAllSize = (CheckBox)gvReceiptDwnld.HeaderRow.FindControl("chkbxDownAll");
        if (chkAllSize.Checked)
        {
            f_size = SelectedFileSize();
            if (f_size > size)
            {
                uscMsgBox1.AddMessage("The total file download size should be 4Mb or less", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
        }
        //ScriptManager.RegisterStartupScript(Page, this.GetType(), "freez", "freezing();", true);

    }

    protected double SelectedFileSize()
    {
        double f_size = 0;
        try
        {
            foreach (GridViewRow gvRowSize in gvReceiptDwnld.Rows)
            {
                CheckBox chkSize = (CheckBox)gvRowSize.FindControl("chkbxDownCollection");
                Label lblSize = (Label)gvRowSize.FindControl("lbl_file_size");
                if (chkSize.Checked)
                {
                    f_size += Convert.ToDouble(lblSize.Text);
                    if (f_size > size)
                    {
                        chkSize.Checked = false;
                        break;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        return f_size;
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        //string filePath = "";
        //string first = "";
        //string last = "";
        try
        {
            if (txt_size.Text != "" && txt_size.Text != "0")
            {
                //using (ZipFile zip = new ZipFile())
                //{
                //    foreach (GridViewRow gvRowSize in gvReceiptDwnld.Rows)
                //    {
                //        CheckBox chkSize = (CheckBox)gvRowSize.FindControl("chkbxDownCollection");
                //        Label lblPath = (Label)gvRowSize.FindControl("lbl_Rec_path");
                //        if (chkSize.Checked)
                //        {
                //            string[] path = lblPath.Text.ToString().Split('_');
                //            if (first == "")
                //                first = path[2];
                //            if (first != "")
                //                last = path[2];
                //            filePath = lblPath.Text.ToString();
                //            zip.AddFile(filePath, "File");
                //            listAsyncDownload.Add(lblPath.Text.ToString());
                //        }
                //    }

                //    Response.Clear();
                //    Response.AddHeader("Content-Disposition", "inline; filename=" + first + last + "DownloadedReceipt.zip");
                //    Response.ContentType = "application/zip";
                //    zip.Save(Response.OutputStream);
                //    Response.Flush();
                //    Response.End();
                //}
                int nameIndex = 0;
                string downloadPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                downloadPath = Path.Combine(downloadPath, "Downloads");
                foreach (GridViewRow gvRowSize in gvReceiptDwnld.Rows)
                {
                    CheckBox chkSize = (CheckBox)gvRowSize.FindControl("chkbxDownCollection");
                    Label lblPath = (Label)gvRowSize.FindControl("lbl_Rec_path");
                    if (chkSize.Checked)
                    {
                        nameIndex = lblPath.Text.ToString().LastIndexOf("\\") + 1;
                        string f = lblPath.Text.ToString().Remove(0, nameIndex);
                        //fileList.Add(lblPath.Text, @"C:\Users\saravananss\Desktop\download\" + f);
                        fileList.Add(lblPath.Text, downloadPath + "\\" + f);
                    }
                }
                for (int i = 0; i < fileList.Count; i++)
                {
                    KeyValuePair<string, string> file = fileList.ElementAt(i);
                    InitiateDownload(file.Key, file.Value, FileDownloadCompleted, file.Key);
                }

            }
            else
            {
                uscMsgBox1.AddMessage("Please Select the File", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            //if (listAsyncDownload.Count > 0)
            //{
            //    foreach (string li in listAsyncDownload)
            //    {
            //        filePath = li.ToString();
            //        FileInfo hasFile = new FileInfo(filePath);
            //        if (hasFile.Exists)
            //        {
            //            Response.Flush();
            //            File.Delete(filePath);
            //        }
            //        else
            //        {
            //            uscMsgBox1.AddMessage("This file does not exist.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            //        }
            //    }
            //}
            //bind(serverTime);
            //bind();
        }
    }

    public void InitiateDownload(string RemoteAddress, string LocalFile, AsyncCompletedEventHandler CompletedCallback, object userToken)
    {
        // Remove file from queue
        fileList.Remove(userToken.ToString());

        WebClient wc = new WebClient();
        wc.DownloadFileCompleted += CompletedCallback;
        wc.DownloadFileAsync(new Uri(RemoteAddress), LocalFile, userToken);
    }

    public void FileDownloadCompleted(object sender, AsyncCompletedEventArgs e)
    {
        if (e.Error != null)
            //Console.WriteLine("Error downloading {0}: {1}", e.UserState, e.Error); 
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "error", "error();", true);

        else if (e.Cancelled)
            //Console.WriteLine("Download of {0} cancelled.", e.UserState);
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "cancel", "cancel();", true);
        else
            //Console.WriteLine("File with userToke {0} completed.", e.UserState);
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "complete", "complete();", true);

        // if there are files left in queue start another
        if (fileList.Count > 0)
            InitiateDownload(fileList.First().Key, fileList.First().Value, FileDownloadCompleted, fileList.First().Key);


        // Dispose of the WebClient that just finished
        ((IDisposable)sender).Dispose();
    }

    protected void dateBind()
    {
        try
        {
            DataTable dtDates = new DataTable();
            dtDates.Columns.Add("Date", typeof(string));
            dtDates.Columns.Add("DateValue", typeof(string));
            string[] date = Directory.GetFiles(Server.MapPath("~\\Upload\\File\\"));
            string previousDate = "";
            foreach (var item in date)
            {
                int nameIndex = 0;
                string[] file;
                string f = "";
                nameIndex = item.LastIndexOf("\\") + 1;
                f = item.Remove(0, nameIndex);
                f = f.Remove(f.Length - 4);
                file = f.Split('_');
                if (previousDate != file[2].ToString())
                {
                    previousDate = file[2].ToString();
                    DataRow dtRows = dtDates.NewRow();
                    dtRows["Date"] = previousDate;
                    dtRows["DateValue"] = Convert.ToString(Convert.ToDateTime(previousDate).ToString("yyyy-MM-dd"));
                    dtDates.Rows.Add(dtRows);
                }
            }
            ddlDate.DataSource = dtDates;
            ddlDate.DataTextField = "Date";
            ddlDate.DataValueField = "DateValue";
            ddlDate.DataBind();
            ddlDate.Items.Insert(0, new ListItem("---Select---", "0"));

            //string dat = Server.MapPath("~\\Upload\\File\\").ToString();
            //int nameIndex = 0;
            //string previousDate = "";
            //string[] file;
            //    string f = "";
            //    nameIndex = dat.LastIndexOf("\\") + 1;
            //    f = dat.Remove(0, nameIndex);
            //    f = f.Remove(f.Length - 4);
            //    file = f.Split('_');
            //previousDate = file[2].ToString();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void ddlDate_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDate.SelectedIndex != 0)
            ddlst_Branch.SelectedIndex = 0;
    }

    protected void bindProduct()
    {
        try
        {
            DataTable dtTempproduct = new DataTable();
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@COLLECTION", 1);
            //SqlDataAdapter da2 = new SqlDataAdapter(cmd_Obj);
            //DataSet ds2 = new DataSet();
            //da2.Fill(ds2);
            //con_Obj.Close();
            //DataTable dtTempproduct = ds2.Tables[0].Select("PR_ID in (2,3)").CopyToDataTable();
            //ddlProduct.DataSource = dtTempproduct;
            dtTempproduct.Load(cmd_Obj.ExecuteReader());
            ddlProduct.DataSource = dtTempproduct;
            ddlProduct.DataTextField = "PR_CODE";
            ddlProduct.DataValueField = "PRD";
            ddlProduct.DataBind();
            ddlProduct.Items.Insert(0, new ListItem("Select", "0"));
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected string getServerTime()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("RTS_SP_FETCH_INSERT_RADIANT_RECEIPT", con_Obj);
            cmd_Obj.CommandTimeout = 240000;
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@PTYPE", "SERVDATE");
            dt_obj = new DataTable();
            dt_obj.Load(cmd_Obj.ExecuteReader());
            hdnServerTime.Value = Convert.ToString(dt_obj.Rows[0][0]);
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);


        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
        return Convert.ToString(hdnServerTime.Value);
    }

    public void copy()
    {
        try
        {
            string sourcePath = Server.MapPath("~\\Upload\\File");
            //string targetPath = @"C:\Users\saravananss\Desktop\download";
            string targetPath = @"C:\Users\" + Environment.UserName + @"\Desktop\download";
            if (!Directory.Exists(targetPath))
            {
                Directory.CreateDirectory(targetPath);
            }
            foreach (var srcPath in Directory.GetFiles(sourcePath))
            {
                //Copy the file from sourcepath and place into mentioned target path, 
                //Overwrite the file if same file is exist in target 
                File.Copy(srcPath, srcPath.Replace(sourcePath, targetPath), true);
            }
            //delete();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void delete()
    {
        try
        {
            string[] fileNames = Directory.GetFiles(Server.MapPath("~\\Upload\\File\\"));
            int nameIndex = 0;
            string[] file;
            string f = "";
            string date = "";
            string filePath = string.Empty;
            List<string> listDelete = new List<string>();
            foreach (var item in fileNames)
            {
                double length = new FileInfo(item).Length / 1024;
                nameIndex = item.LastIndexOf("\\") + 1;
                f = item.Remove(0, nameIndex);
                f = f.Remove(f.Length - 4);
                file = f.Split('_');
                date = file[2];
                string delDate = DateTime.Now.Date.AddDays(-2).ToString("dd MMM yyyy");
                if (date == delDate)
                {
                    listDelete.Add(Convert.ToString(item));
                }
            }
            if (listDelete.Count > 0)
            {
                foreach (string li in listDelete)
                {
                    filePath = li.ToString();
                    FileInfo hasFile = new FileInfo(filePath);
                    if (hasFile.Exists)
                    {
                        Response.Flush();
                        File.Delete(filePath);
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("This file does not exist.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

                    }
                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}
