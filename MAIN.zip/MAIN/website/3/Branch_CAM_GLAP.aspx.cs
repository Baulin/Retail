﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Linq;
using System.Data;
using System.Net.Mail;
using System.Configuration;
using System.Globalization;
using Tracker;
using Utilities;
public partial class Branch_CAM_GLAP : System.Web.UI.Page
{
    public static DataTable dtSourceOfIncome = null;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    public static bool blMailStatus = false;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";

    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;

    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    ClsCommon clscommon = new ClsCommon();
    public static double ptypval;
    int cmrs;
    protected void Page_Load(object sender, EventArgs e)
    {


        // gvIncomeDetail.Visible = true;
        //  int nRoundVal = RoundDown(153333);
        // int nRoundVal1 = RoundNum(153);
        // RoundDown();
        if (Session["ID"] != null)
        {
            txtPDDate.Attributes.Add("readonly", "readonly");
            if (!IsPostBack)
            {
                // double dt = GetEMI(0.0, 0.0, 0.0);

                clear();
                ddlTenure.SelectedValue = "5";
                txtBranchName.Text = Session["UNITNAME"].ToString();
                BindDropdownList();
                FirstGridViewRow();

            }

        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    protected void BindDropdownList()
    {
        BindLeadNo();
        BindRelationship();
        BindIncomeSource();
        //BindVintage();
        BindLoanPurpose();
        BindCreditHistory();
        BindCustRelation();
        BindProperty();
        BindOccupancy();
        BindUsage();
        BindBDAge();
        BindCategory();
        BindTenor();
        BindIntrest();
        BindLoanTYpe();
        BindLoanSource();
        // BindLawyerName();
    }

    // __________BIND DROP DOWN LIST START_____________//
    public void BindLeadNo()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_Lead_Details", con);
        cmddd.Parameters.AddWithValue("@LD_NO", "");
        cmddd.Parameters.AddWithValue("@Lead_Type", "GLP");
        cmddd.Parameters.AddWithValue("@BranchName", txtBranchName.Text);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLeadNo.DataSource = dsdd;
        ddlLeadNo.DataTextField = "LD_NO";
        ddlLeadNo.DataValueField = "LD_ID";
        ddlLeadNo.DataBind();
        ddlLeadNo.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindLoanTYpe()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_PR_FETCH_LOAN_TYPE", con);
        //cmddd.Parameters.AddWithValue("@LD_NO", "");
        //cmddd.Parameters.AddWithValue("@Lead_Type", "GLP");
        //cmddd.Parameters.AddWithValue("@BranchName", txtBranchName.Text);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLoanType1.DataSource = dsdd;
        ddlLoanType1.DataTextField = "LT_DESC";
        ddlLoanType1.DataValueField = "LT_ID";
        ddlLoanType1.DataBind();
        ddlLoanType1.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlLoanType2.DataSource = dsdd;
        ddlLoanType2.DataTextField = "LT_DESC";
        ddlLoanType2.DataValueField = "LT_ID";
        ddlLoanType2.DataBind();
        ddlLoanType2.Items.Insert(0, new ListItem("--Select--", "0"));


        ddlLoanType3.DataSource = dsdd;
        ddlLoanType3.DataTextField = "LT_DESC";
        ddlLoanType3.DataValueField = "LT_ID";
        ddlLoanType3.DataBind();
        ddlLoanType3.Items.Insert(0, new ListItem("--Select--", "0"));


        ddlLoanType4.DataSource = dsdd;
        ddlLoanType4.DataTextField = "LT_DESC";
        ddlLoanType4.DataValueField = "LT_ID";
        ddlLoanType4.DataBind();
        ddlLoanType4.Items.Insert(0, new ListItem("--Select--", "0"));


        ddlLoanType5.DataSource = dsdd;
        ddlLoanType5.DataTextField = "LT_DESC";
        ddlLoanType5.DataValueField = "LT_ID";
        ddlLoanType5.DataBind();
        ddlLoanType5.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindLoanSource()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_PR_FETCH_LOAN_SOURCE", con);
        //cmddd.Parameters.AddWithValue("@LD_NO", "");
        //cmddd.Parameters.AddWithValue("@Lead_Type", "GLP");
        //cmddd.Parameters.AddWithValue("@BranchName", txtBranchName.Text);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlSource1.DataSource = dsdd;
        ddlSource1.DataTextField = "MLS_DESC";
        ddlSource1.DataValueField = "MLS_ID";
        ddlSource1.DataBind();
        ddlSource1.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlSource2.DataSource = dsdd;
        ddlSource2.DataTextField = "MLS_DESC";
        ddlSource2.DataValueField = "MLS_ID";
        ddlSource2.DataBind();
        ddlSource2.Items.Insert(0, new ListItem("--Select--", "0"));


        ddlSource3.DataSource = dsdd;
        ddlSource3.DataTextField = "MLS_DESC";
        ddlSource3.DataValueField = "MLS_ID";
        ddlSource3.DataBind();
        ddlSource3.Items.Insert(0, new ListItem("--Select--", "0"));


        ddlSource4.DataSource = dsdd;
        ddlSource4.DataTextField = "MLS_DESC";
        ddlSource4.DataValueField = "MLS_ID";
        ddlSource4.DataBind();
        ddlSource4.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlSource5.DataSource = dsdd;
        ddlSource5.DataTextField = "MLS_DESC";
        ddlSource5.DataValueField = "MLS_ID";
        ddlSource5.DataBind();
        ddlSource5.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindRelationship()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Relation", con);
        cmddd.Parameters.AddWithValue("@ER_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlRelationShip.DataSource = dsdd;
        ddlRelationShip.DataTextField = "ER_DESC";
        ddlRelationShip.DataValueField = "ER_ID";
        ddlRelationShip.DataBind();
        ddlRelationShip.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindIncomeSource()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_IN_SOURCE", con);
        cmddd.Parameters.AddWithValue("@INS_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlMainApplicant.DataSource = dsdd;
        ddlMainApplicant.DataTextField = "INS_DESC";
        ddlMainApplicant.DataValueField = "INS_ID";
        ddlMainApplicant.DataBind();
        ddlMainApplicant.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindVintage()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);
        cmddd.Parameters.AddWithValue("@VN_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlVintage.DataSource = dsdd;
        ddlVintage.DataTextField = "VN_DESC";
        ddlVintage.DataValueField = "VN_ID";
        ddlVintage.DataBind();
        ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindLoanPurpose()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PURPOSE", con);
        cmddd.Parameters.AddWithValue("@PP_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLoanPurpose.DataSource = dsdd;
        ddlLoanPurpose.DataTextField = "PP_DESC";
        ddlLoanPurpose.DataValueField = "PP_ID";
        ddlLoanPurpose.DataBind();
        ddlLoanPurpose.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindCreditHistory()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CR_HISTORY", con);
        cmddd.Parameters.AddWithValue("@CH_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlCreditHistory.DataSource = dsdd;
        ddlCreditHistory.DataTextField = "CH_DESC";
        ddlCreditHistory.DataValueField = "CH_ID";
        ddlCreditHistory.DataBind();
        ddlCreditHistory.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindCustRelation()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_RELATION", con);
        cmddd.Parameters.AddWithValue("@RL_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlCustRelation.DataSource = dsdd;
        ddlCustRelation.DataTextField = "RL_DESC";
        ddlCustRelation.DataValueField = "Rl_ID";
        ddlCustRelation.DataBind();
        ddlCustRelation.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindProperty()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY", con);
        cmddd.Parameters.AddWithValue("@PT_ID", "");
        cmddd.Parameters.AddWithValue("@PT_TYPE", "G");

        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlPropType.DataSource = dsdd;
        ddlPropType.DataTextField = "PT_DESC";
        ddlPropType.DataValueField = "PT_DESC";
        //ddlPropType.DataValueField = "PT_RSQRT";
        ddlPropType.DataBind();
        ddlPropType.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindOccupancy()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_OCCUPANCY", con);
        cmddd.Parameters.AddWithValue("@OC_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlOccupancyStatus.DataSource = dsdd;
        ddlOccupancyStatus.DataTextField = "OC_DESC";
        ddlOccupancyStatus.DataValueField = "OC_ID";
        ddlOccupancyStatus.DataBind();
        ddlOccupancyStatus.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindUsage()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_USAGE", con);
        cmddd.Parameters.AddWithValue("@UG_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlUsage.DataSource = dsdd;
        ddlUsage.DataTextField = "UG_DESC";
        ddlUsage.DataValueField = "UG_ID";
        ddlUsage.DataBind();
        ddlUsage.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindBDAge()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_BD_AGE", con);
        cmddd.Parameters.AddWithValue("@BA_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();
        ddlAgeOfBuilding.DataSource = dsdd;
        ddlAgeOfBuilding.DataTextField = "BA_DESC";
        ddlAgeOfBuilding.DataValueField = "BA_DESC";
        ddlAgeOfBuilding.DataBind();
        ddlAgeOfBuilding.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindCategory()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
        cmddd.Parameters.AddWithValue("@CT_ID", "");
        cmddd.Parameters.AddWithValue("@CT_TYPE", "G");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        dtSourceOfIncome = dsdd.Tables[0];
        con.Close();
        ddlCustSource.DataSource = dsdd;
        ddlCustSource.DataTextField = "CT_DESC";
        ddlCustSource.DataValueField = "CT_DESC";
        ddlCustSource.DataBind();
        ddlCustSource.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindTenor()
    {
        string strFileName = "GLPTenure.xml";
        if (ddlLeadNo.SelectedItem.Text.Contains("ELP"))
        {
            strFileName = "EMPTenor.xml";
        }
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("XML/" + strFileName + ""));

        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();

        if (ds.Tables[0].Rows.Count != 0)
        {
            ddlTenure.DataSource = ds.Tables[0];

            ddlTenure.DataTextField = "Tenor";

            ddlTenure.DataValueField = "Tenor";

            ddlTenure.DataBind();
            ddlTenure.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        else
        {
            ddlTenure.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }

    public void BindIntrest()
    {
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("XML/GLPInterestRate.xml"));

        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();

        if (ds.Tables.Count != 0)
        {
            ddlIntrest.DataSource = ds;

            ddlIntrest.DataTextField = "Interest";

            ddlIntrest.DataValueField = "Interest";

            ddlIntrest.DataBind();

            ddlIntrest.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }

    public DataSet fetchLeadDetails(string strLeadNo)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Lead_Details", con);
        cmddd.Parameters.AddWithValue("@LD_NO", strLeadNo);
        cmddd.Parameters.AddWithValue("@Lead_Type", "GLP");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        return dsdd;
    }
    // __________BIND DROP DOWN LIST END_____________//


    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            btnSubmit.Enabled = false;
            if (DDLkycName.SelectedIndex != 0 && ddlCustSource.SelectedItem.Text != "--Select--" && txtCustAge.Text != "" && ddlCustRelation.SelectedItem.Text != "--Select--"
                                   && txtIncome.Text != "")
            {
                AddNewRow();
            }
            else
            {
                if (DDLkycName.SelectedIndex == 0)
                {
                    DDLkycName.Focus();

                }
                else if (ddlCustSource.SelectedItem.Text == "--Select--")
                {
                    ddlCustSource.Focus();
                }
                else if (txtCustAge.Text == "")
                {
                    txtCustAge.Focus();

                }
                else if (ddlCustRelation.SelectedItem.Text == "--Select--")
                {
                    ddlCustSource.Focus();
                }
                else if (txtIncome.Text == "")
                {
                    txtCustAge.Focus();

                }
                uscMsgBox1.AddMessage("Please Give corresponding Inputs for Income details", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    private void FirstGridViewRow()
    {


        DataTable dt = new DataTable();
        DataRow dr = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("NAME", typeof(string)));
        dt.Columns.Add(new DataColumn("APP_TYPE", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_SOURCE", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_SOURCEID", typeof(string)));
        dt.Columns.Add(new DataColumn("AGE", typeof(string)));
        dt.Columns.Add(new DataColumn("RELATIONSHIP", typeof(string)));
        dt.Columns.Add(new DataColumn("RELATIONSHIPID", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_TAKEN", typeof(string)));
        dt.Columns.Add(new DataColumn("FACTORED_INCOME", typeof(string)));

        dr = dt.NewRow();
        //dr["RowNumber"] = 1;

        dr["NAME"] = string.Empty;
        dr["APP_TYPE"] = string.Empty;
        dr["INCOME_SOURCE"] = string.Empty;
        dr["INCOME_SOURCEID"] = string.Empty;
        dr["AGE"] = string.Empty;
        dr["RELATIONSHIP"] = string.Empty;
        dr["RELATIONSHIPID"] = string.Empty;
        dr["INCOME"] = string.Empty;
        dr["INCOME_TAKEN"] = string.Empty;
        dr["FACTORED_INCOME"] = string.Empty;
        dt.Rows.Add(dr);

        ViewState["CurrentTable"] = dt;

        gvIncomeDetail.DataSource = dt;
        gvIncomeDetail.DataBind();


    }
    private void AddNewRow()
    {
        int rowIndex = 0;

        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;



            if (dtCurrentTable.Rows.Count > 0 && dtCurrentTable.Rows[0][0].ToString() == "")
            {
                dtCurrentTable.Rows.RemoveAt(0);
            }
            drCurrentRow = dtCurrentTable.NewRow();
            drCurrentRow["NAME"] = DDLkycName.SelectedItem.Text;
            drCurrentRow["APP_TYPE"] = TBAppType.Text;
            drCurrentRow["INCOME_SOURCE"] = ddlCustSource.SelectedItem.Text != "--Select--" ? ddlCustSource.SelectedItem.Text : "";
            int INCOME_SOURCEID = FetchINCOME_SOURCEID(ddlCustSource.SelectedItem.Text);
            drCurrentRow["INCOME_SOURCEID"] = INCOME_SOURCEID;
            drCurrentRow["AGE"] = txtCustAge.Text;
            drCurrentRow["RELATIONSHIP"] = ddlCustRelation.SelectedItem.Text != "--Select--" ? ddlCustRelation.SelectedItem.Text : "";
            drCurrentRow["RELATIONSHIPID"] = ddlCustRelation.SelectedItem.Text != "--Select--" ? ddlCustRelation.SelectedValue.ToString() : "";
            drCurrentRow["INCOME"] = txtIncome.Text;
            drCurrentRow["INCOME_TAKEN"] = txtIncomeTaken.Text;
            drCurrentRow["FACTORED_INCOME"] = Convert.ToString(Convert.ToDouble(txtIncome.Text) * (Convert.ToDouble(txtIncomeTaken.Text) / 100));
            string strFactorIncome = drCurrentRow["FACTORED_INCOME"].ToString();
            //  rowIndex++;
            // }
            dtCurrentTable.Rows.Add(drCurrentRow);
            ViewState["CurrentTable"] = dtCurrentTable;

            gvIncomeDetail.DataSource = dtCurrentTable;
            gvIncomeDetail.DataBind();




            Clear();





            if (dtCurrentTable != null && dtCurrentTable.Rows.Count > 0)
            {
                BindCreditSheild(dtCurrentTable);
                double nTotalLoanEligibility = 0.0;
                txtbxotherincome.Text = "";
                txtbxsumofrental.Text = "";
                txtPensionIncome.Text = "";
                double nCashIncome = 0.0;
                for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                {
                    double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                    string strIncomeSource = dtCurrentTable.Rows[n]["INCOME_SOURCE"] != DBNull.Value ? dtCurrentTable.Rows[n]["INCOME_SOURCE"].ToString() : "";
                    nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;
                    
                    if (strIncomeSource.Contains("RENT"))
                    {
                        if (txtbxsumofrental.Text == "")
                        {
                            txtbxsumofrental.Text = Convert.ToDouble(nTempVal).ToString();
                        }
                        else
                        {

                            txtbxsumofrental.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxsumofrental.Text)).ToString();
                        }
                    }
                    else if (strIncomeSource.Contains("CASH"))
                    {
                        nCashIncome += nTempVal;
                    }
                    else if (strIncomeSource.Contains("PENSION"))
                    {
                        if (txtPensionIncome.Text == "")
                        {
                            txtPensionIncome.Text = Convert.ToDouble(nTempVal).ToString();
                        }
                        else
                        {

                            txtPensionIncome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtPensionIncome.Text)).ToString();
                        }
                    }
                    else
                    {
                        if (txtbxotherincome.Text == "")
                        {
                            txtbxotherincome.Text = Convert.ToDouble(nTempVal).ToString();
                        }
                        else
                        {

                            txtbxotherincome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxotherincome.Text)).ToString();
                        }
                    }
                    double rent = 0.0;
                    double Pension = 0.0;
                    double other = 0.0;

                    
                    if (txtbxsumofrental.Text != "")
                    {
                        rent = Convert.ToDouble(txtbxsumofrental.Text);
                    }
                    if (txtPensionIncome.Text != "")
                    {
                        Pension = Convert.ToDouble(txtPensionIncome.Text);
                    }
                    if (txtbxotherincome.Text != "")
                    {
                        other = Convert.ToDouble(txtbxotherincome.Text);
                    }

                    if (strIncomeSource.Contains("PENSION") && txtbxsumofrental.Text == "")
                    {
                        txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, other) + other);
                    }
                    else if (strIncomeSource.Contains("PENSION") && txtbxsumofrental.Text != "")
                    {
                        txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, Convert.ToDouble(txtTotalLoanEligibility.Text)) + Convert.ToDouble(txtTotalLoanEligibility.Text));
                    }
                    else if (strIncomeSource.Contains("RENT") && txtPensionIncome.Text == "")
                    {
                        txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(rent, other) + other);
                    }
                    else if (strIncomeSource.Contains("RENT") && txtPensionIncome.Text != "")
                    {
                        txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(rent, Convert.ToDouble(txtTotalLoanEligibility.Text)) + Convert.ToDouble(txtTotalLoanEligibility.Text));
                    }

                    else
                    {
                        if (txtPensionIncome.Text == "" && txtbxsumofrental.Text != "")
                        {
                            txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(rent, other) + other);
                        }
                        else if (txtPensionIncome.Text != "" && txtbxsumofrental.Text == "")
                        {
                            txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, other) + other);
                        }
                        else
                        {
                            txtTotalLoanEligibility.Text = Convert.ToString(other);
                        }

                    }

                    if(nCashIncome != 0.0)
                    {
                        double nOverallOtherIncome = Convert.ToDouble(string.IsNullOrWhiteSpace(txtbxotherincome.Text)?"0": txtbxotherincome.Text) + 
                                                     Convert.ToDouble(string.IsNullOrWhiteSpace(txtbxsumofrental.Text)?"0":txtbxsumofrental.Text) + 
                                                     Convert.ToDouble(string.IsNullOrWhiteSpace(txtPensionIncome.Text)?"0":txtPensionIncome.Text);
                        if (nCashIncome >= nOverallOtherIncome)
                        {
                            txtTotalLoanEligibility.Text = (nOverallOtherIncome + nOverallOtherIncome).ToString();
                        }
                        if (nCashIncome < nOverallOtherIncome)
                        {
                            txtTotalLoanEligibility.Text  = (nOverallOtherIncome + nCashIncome).ToString();
                        }
                        if (nOverallOtherIncome == 0.0)
                        {
                            txtTotalLoanEligibility.Text = string.Empty;
                        }
                    }

                }


                BindBorrower(dtCurrentTable);
            }
            //  }
        }
        else
        {
            Response.Write("ViewState is null");
        }
        //  SetPreviousData();
    }

    public void BindCreditSheild(DataTable dtCreditSheild)
    {
        try
        {
            var result = from tab in dtCreditSheild.AsEnumerable()
                         where int.Parse(tab.Field<string>("AGE")) <= 60
                         group tab by tab["NAME"]
                             into groupDt
                         select new
                         {
                             Group = groupDt.Key,
                             Sum = groupDt.Sum((r) => decimal.Parse(r["FACTORED_INCOME"].ToString()))
                         };


            DataTable dt = new DataTable();

            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Amount", typeof(int));

            foreach (var item in result)
            {
                DataRow dr = dt.NewRow();
                dr["Name"] = item.Group;
                dr["Amount"] = Convert.ToInt32(item.Sum);
                dt.Rows.Add(dr);
            }


            DataRow[] drTemp = dt.Select("Amount=  max(Amount)");
            if (drTemp.Length > 0)
            {
                txtNameofInsuredPerson.Text = drTemp[0].ItemArray[0].ToString();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindBorrower(DataTable dt)
    {
        /// NAME
        /// 
        string strBrwname1 = "", strBrwname2 = "", strBrwname3 = "", strBrwname4 = "", strBrwname5 = "";

        if (drpName1.Items.Count > 0)
        {
            strBrwname1 = drpName1.SelectedValue;
        }
        if (drpName2.Items.Count > 0)
        {
            strBrwname2 = drpName2.SelectedValue;
        }
        if (drpName3.Items.Count > 0)
        {
            strBrwname3 = drpName3.SelectedValue;
        }
        if (drpName4.Items.Count > 0)
        {
            strBrwname4 = drpName4.SelectedValue;
        }
        if (drpName5.Items.Count > 0)
        {
            strBrwname5 = drpName5.SelectedValue;
        }

        drpName1.Items.Clear();
        drpName2.Items.Clear();
        drpName3.Items.Clear();
        drpName4.Items.Clear();
        drpName5.Items.Clear();
        DataTable temNameDB = new DataTable();
        temNameDB = dt.Copy();
        for (int n = 1; n <= 9; n++)
        {
            temNameDB.Columns.RemoveAt(1);

        }

        temNameDB = temNameDB.DefaultView.ToTable(true);
        drpName1.DataSource = temNameDB;
        drpName2.DataSource = temNameDB;
        drpName3.DataSource = temNameDB;
        drpName4.DataSource = temNameDB;
        drpName5.DataSource = temNameDB;

        drpName1.DataTextField = "NAME";
        drpName1.DataValueField = "NAME";

        drpName2.DataTextField = "NAME";
        drpName2.DataValueField = "NAME";

        drpName3.DataTextField = "NAME";
        drpName3.DataValueField = "NAME";

        drpName4.DataTextField = "NAME";
        drpName4.DataValueField = "NAME";

        drpName5.DataTextField = "NAME";
        drpName5.DataValueField = "NAME";

        drpName1.DataBind();
        drpName2.DataBind();
        drpName3.DataBind();
        drpName4.DataBind();
        drpName5.DataBind();

        drpName1.Items.Insert(0, "--Select--");
        drpName2.Items.Insert(0, "--Select--");
        drpName3.Items.Insert(0, "--Select--");
        drpName4.Items.Insert(0, "--Select--");
        drpName5.Items.Insert(0, "--Select--");

        if (strBrwname1 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname1 + "'");
            if (dr.Length > 0)
            {
                drpName1.SelectedValue = strBrwname1;
            }
            else
            {
                txtFinanciear1.Text = "";
                txtEMIAmount1.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }

        }
        if (strBrwname2 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname2 + "'");
            if (dr.Length > 0)
            {
                drpName2.SelectedValue = strBrwname2;
            }
            else
            {
                txtFinanciear2.Text = "";
                txtEMIAmount2.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname3 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname3 + "'");
            if (dr.Length > 0)
            {

                drpName3.SelectedValue = strBrwname3;
            }
            else
            {
                txtFinanciear3.Text = "";
                txtEMIAmount3.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname4 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname4 + "'");
            if (dr.Length > 0)
            {
                drpName4.SelectedValue = strBrwname4;
            }
            else
            {
                txtFinanciear4.Text = "";
                txtEMIAmount4.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname5 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname5 + "'");
            if (dr.Length > 0)
            {
                drpName5.SelectedValue = strBrwname5;
            }
            else
            {
                txtFinanciear5.Text = "";
                txtEMIAmount5.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }

    }
    public int FetchINCOME_SOURCEID(string strDesc)
    {
        int INCOME_SOURCEID = 0;
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("Select CT_ID from MR_CATEGORY where  CT_PR_TYPE='G' AND CT_DESC='" + strDesc + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        INCOME_SOURCEID = Convert.ToInt32(dsdd.Tables[0].Rows[0][0]);
        con.Close();
        return INCOME_SOURCEID;
    }
    public void Clear()
    {
        DDLkycName.SelectedIndex = 0;
        ddlCustSource.SelectedIndex = 0;
        txtCustAge.Text = "";
        ddlCustRelation.SelectedIndex = 0;
        txtIncome.Text = "";
        txtIncomeTaken.Text = "";
        txtFactor.Text = "";
        //txtNomineeRelation.Text = "";
        //txtNomineeName.Text = "";
    }
    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    TextBox txtCustName =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[1].FindControl("txtCustName");
                    DropDownList ddlCustSource =
                     (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[2].FindControl("ddlCustSource");
                    TextBox txtCustAge =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[3].FindControl("txtCustAge");
                    DropDownList ddlCustRelation =
                       (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[4].FindControl("ddlCustRelation");
                    TextBox txtIncome =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[5].FindControl("txtIncome");
                    DropDownList ddlIncomeTaken =
                      (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[6].FindControl("ddlIncomeTaken");
                    DropDownList ddlFactor =
                     (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[7].FindControl("ddlFactor");

                    txtCustName.Text = dt.Rows[i]["Col1"].ToString();
                    ddlCustSource.SelectedItem.Text = dt.Rows[i]["Col2"].ToString();
                    txtCustAge.Text = dt.Rows[i]["Col3"].ToString();
                    ddlCustRelation.SelectedItem.Text = dt.Rows[i]["Col4"].ToString();
                    txtIncome.Text = dt.Rows[i]["Col5"].ToString();
                    ddlIncomeTaken.SelectedItem.Text = dt.Rows[i]["Col6"].ToString();
                    ddlFactor.SelectedItem.Text = dt.Rows[i]["Col7"].ToString();
                    rowIndex++;
                }
            }
        }
    }


    protected void gvIncomeDetail_RowCommand1(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            //DataTable dtTempTable=null;
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];

                if (e.CommandName == "Delete")
                {
                    btnSubmit.Enabled = false;
                    txtPensionIncome.Text = "";
                    txtbxotherincome.Text = "";
                    txtbxsumofrental.Text = "";
                    txtTotalLoanEligibility.Text = "";
                    string[] strVal = e.CommandArgument.ToString().Split('|');

                    DataRow[] dr = dtCurrentTable.Select("NAME = '" + strVal[0].ToString() + "' AND INCOME_SOURCEID = '" + strVal[1].ToString() + "'");
                    if (dr.Length > 0)
                    {

                        // dtCurrentTable = dr.CopyToDataTable();
                        DataTable dtTempTable = dr.CopyToDataTable();
                        for (int i = 0; i < dtCurrentTable.Rows.Count; i++)
                        {

                            if (dtCurrentTable.Rows[i]["NAME"].ToString() == dtTempTable.Rows[0]["NAME"].ToString() && dtCurrentTable.Rows[i]["INCOME_SOURCEID"].ToString() == dtTempTable.Rows[0]["INCOME_SOURCEID"].ToString())
                            {
                                dtCurrentTable.Rows.RemoveAt(i);
                            }
                        }
                        dtCurrentTable.AcceptChanges();



                        ViewState["CurrentTable"] = dtCurrentTable;
                        gvIncomeDetail.DataSource = dtCurrentTable;
                        gvIncomeDetail.DataBind();

                        if (dtCurrentTable != null && dtCurrentTable.Rows.Count > 0)
                        {
                            double nTotalLoanEligibility = 0.0;
                            txtbxotherincome.Text = "";
                            txtbxsumofrental.Text = "";
                            double nCashIncome = 0.0;
                            for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                            {
                                double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                                string strIncomeSource = dtCurrentTable.Rows[n]["INCOME_SOURCE"] != DBNull.Value ? dtCurrentTable.Rows[n]["INCOME_SOURCE"].ToString() : "";
                                string strName = dtCurrentTable.Rows[n]["NAME"] != DBNull.Value ? dtCurrentTable.Rows[n]["NAME"].ToString() : "";
                                int nAge = dtCurrentTable.Rows[n]["AGE"] != DBNull.Value ? Convert.ToInt32(dtCurrentTable.Rows[n]["AGE"]) : 0;
                                nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;
                                BindCreditSheild(dtCurrentTable);
                                if (strIncomeSource.Contains("RENT"))
                                {
                                    if (txtbxsumofrental.Text == "")
                                    {
                                        txtbxsumofrental.Text = Convert.ToDouble(nTempVal).ToString();
                                    }
                                    else
                                    {

                                        txtbxsumofrental.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxsumofrental.Text)).ToString();
                                    }
                                }
                                else if (strIncomeSource.Contains("CASH"))
                                {
                                    nCashIncome += nTempVal;
                                }
                                else if (strIncomeSource.Contains("PENSION"))
                                {
                                    if (txtPensionIncome.Text == "")
                                    {
                                        txtPensionIncome.Text = Convert.ToDouble(nTempVal).ToString();
                                    }
                                    else
                                    {

                                        txtPensionIncome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtPensionIncome.Text)).ToString();
                                    }
                                }
                                else
                                {
                                    if (txtbxotherincome.Text == "")
                                    {
                                        txtbxotherincome.Text = Convert.ToDouble(nTempVal).ToString();
                                    }
                                    else
                                    {

                                        txtbxotherincome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxotherincome.Text)).ToString();
                                    }
                                }
                                double rent = 0.0;
                                double Pension = 0.0;
                                double other = 0.0;

                                if (txtbxsumofrental.Text != "")
                                {
                                    rent = Convert.ToDouble(txtbxsumofrental.Text);
                                }
                                if (txtPensionIncome.Text != "")
                                {
                                    Pension = Convert.ToDouble(txtPensionIncome.Text);
                                }
                                if (txtbxotherincome.Text != "")
                                {
                                    other = Convert.ToDouble(txtbxotherincome.Text);
                                }

                                if (strIncomeSource.Contains("PENSION") && txtbxsumofrental.Text == "")
                                {
                                    txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, other) + other);
                                }
                                else if (strIncomeSource.Contains("PENSION") && txtbxsumofrental.Text != "")
                                {
                                    txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, Convert.ToDouble(txtTotalLoanEligibility.Text)) + Convert.ToDouble(txtTotalLoanEligibility.Text));
                                }
                                else if (strIncomeSource.Contains("RENT") && txtPensionIncome.Text == "")
                                {
                                    txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(rent, other) + other);
                                }
                                else if (strIncomeSource.Contains("RENT") && txtPensionIncome.Text != "")
                                {
                                    txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, Convert.ToDouble(txtTotalLoanEligibility.Text)) + Convert.ToDouble(txtTotalLoanEligibility.Text));
                                }

                                else
                                {
                                    if (txtPensionIncome.Text == "" && txtbxsumofrental.Text != "")
                                    {
                                        txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(rent, other) + other);
                                    }
                                    else if (txtPensionIncome.Text != "" && txtbxsumofrental.Text == "")
                                    {
                                        txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, other) + other);
                                    }
                                    else
                                    {
                                        txtTotalLoanEligibility.Text = Convert.ToString(other);
                                    }

                                }

                                if (nCashIncome != 0.0)
                                {
                                    double nOverallOtherIncome = Convert.ToDouble(string.IsNullOrWhiteSpace(txtbxotherincome.Text) ? "0" : txtbxotherincome.Text) +
                                                                 Convert.ToDouble(string.IsNullOrWhiteSpace(txtbxsumofrental.Text) ? "0" : txtbxsumofrental.Text) +
                                                                 Convert.ToDouble(string.IsNullOrWhiteSpace(txtPensionIncome.Text) ? "0" : txtPensionIncome.Text);
                                    if (nCashIncome >= nOverallOtherIncome)
                                    {
                                        txtTotalLoanEligibility.Text = (nOverallOtherIncome + nOverallOtherIncome).ToString();
                                    }
                                    if (nCashIncome < nOverallOtherIncome)
                                    {
                                        txtTotalLoanEligibility.Text = (nOverallOtherIncome + nCashIncome).ToString();
                                    }
                                    if (nOverallOtherIncome == 0.0)
                                    {
                                        txtTotalLoanEligibility.Text = string.Empty;
                                    }
                                }
                            }


                            BindBorrower(dtCurrentTable);
                        }
                        else
                        {
                            txtPensionIncome.Text = "";
                            txtbxsumofrental.Text = "";
                            txtbxotherincome.Text = "";
                        }

                    }
                    else
                    {
                        FirstGridViewRow();
                        txtbxotherincome.Text = "";
                        txtbxsumofrental.Text = "";
                        txtTotalLoanEligibility.Text = "";
                        drpName1.Items.Clear();
                        drpName2.Items.Clear();
                        drpName3.Items.Clear();
                        drpName4.Items.Clear();
                        drpName5.Items.Clear();
                        txtFinanciear1.Text = "";
                        txtFinanciear2.Text = "";
                        txtFinanciear3.Text = "";
                        txtFinanciear4.Text = "";
                        txtFinanciear5.Text = "";

                        txtEMIAmount1.Text = "";
                        txtEMIAmount2.Text = "";
                        txtEMIAmount3.Text = "";
                        txtEMIAmount4.Text = "";
                        txtEMIAmount5.Text = "";
                        txtTotalEMIAmount.Text = "";

                    }

                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void gvIncomeDetail_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void gvIncomeDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    public void KYC_details()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_KYC", con);
        cmddd.Parameters.AddWithValue("@LD_ID", ddlLeadNo.SelectedValue.ToString().Trim());
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        DDLkycName.DataSource = dsdd;
        DDLkycName.DataTextField = "KYC_NAME";
        DDLkycName.DataValueField = "KYC_ID";
        DDLkycName.DataBind();
        DDLkycName.Items.Insert(0, new ListItem("--Select--", "0"));
        TBAppType.Text = "";
    }

    public void KYC_APP_details()
    {
        try
        {
            DataSet ds = new DataSet();
            ds = clscommon.Bind_MR_KYC_APP_DETAILS(ddlLeadNo.SelectedValue != "--Select--" ? Convert.ToString(ddlLeadNo.SelectedValue).Trim() : "0");
            ddlNomineeName.DataSource = ds;
            ddlNomineeName.DataTextField = "KYC_NAME";
            ddlNomineeName.DataValueField = "APP_DESC";
            ddlNomineeName.DataBind();
            ddlNomineeName.Items.Add(new ListItem("Others", "Others"));
            ddlNomineeName.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlLeadNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlLeadNo.SelectedIndex > 0)
            {
                if (ddlLeadNo.SelectedItem.Text.Contains("ELP"))
                {
                    trEmp1.Visible = true;
                    trEmp2.Visible = true;
                    trEmp3.Visible = true;
                }
                else
                {
                    trEmp1.Visible = false;
                    trEmp2.Visible = false;
                    trEmp3.Visible = false;
                }
                txtCAMDATE.Text = DateTime.Now.ToString("dd/MMM/yyyy");
                DataSet dsLead = fetchLeadDetails(ddlLeadNo.SelectedItem.Text.Trim());
                if (dsLead != null && dsLead.Tables[0].Rows.Count > 0)
                {
                    BindTenor();
                    KYC_details();
                    KYC_APP_details();
                    FetchCam();
                    txtPDDate.Text = dsLead.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsLead.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
                    txtApplnName.Text = dsLead.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";

                    txt_enduse.Text = dsLead.Tables[0].Rows[0]["LD_PD_USE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_PD_USE"].ToString() : "";
                    txtContactNo.Text = dsLead.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
                    txtMemberID.Text = dsLead.Tables[0].Rows[0]["LD_MID"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_MID"].ToString() : "";
                    txtAddress.Text = dsLead.Tables[0].Rows[0]["LD_RADDRESS"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_RADDRESS"].ToString() : "";

                    hfdcrdtglp.Value = dsLead.Tables[0].Rows[0]["LD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsLead.Tables[0].Rows[0]["LD_DATE"]).ToString("dd/MM/yyyy") : "";
                    Session["PROPADDR"] = dsLead.Tables[0].Rows[0]["LD_ADDRESS"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_ADDRESS"].ToString() : "";
                    //bala changes 16112016
                    Session["PD_AMT"] = dsLead.Tables[0].Rows[0]["LD_PD_AMT"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_PD_AMT"].ToString() : "";

                    string empName = dsLead.Tables[0].Rows[0]["EMP_CODE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["EMP_CODE"].ToString() : "";
                    if (empName != "")
                        empName += "-";
                    empName += dsLead.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
                    string empDesignation = dsLead.Tables[0].Rows[0]["ET_DESC"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["ET_DESC"].ToString() : "";
                    if (empName != "" && empDesignation != "")
                        txtEmpDetailes.Text = empName + " " + "(" + empDesignation + ")";
                    ddlRelationShip.Focus();
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void FetchCam()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_To_Update", con);
            cmddd.Parameters.AddWithValue("@Lead_ID", ddlLeadNo.SelectedValue.ToString());
            cmddd.Parameters.AddWithValue("@CamType", "B");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);



            if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
            {
                //// Search creteria
                txtBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                //txtLeadNo.Text = dsdd.Tables[0].Rows[0]["LD_NO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_NO"].ToString() : "";
                txtPDDate.Text = dsdd.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
                txt_enduse.Text = dsdd.Tables[0].Rows[0]["LD_PD_USE"] != DBNull.Value ? Convert.ToString(dsdd.Tables[0].Rows[0]["LD_PD_USE"]).ToString() : "";
                txtCAMDATE.Text = dsdd.Tables[0].Rows[0]["CAM_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["CAM_DATE"]).ToString("dd/MMM/yyyy") : DateTime.Now.ToString("dd/MMM/yyyy");
                ddlRelationShip.SelectedValue = dsdd.Tables[0].Rows[0]["ER_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ER_ID"].ToString() : "";
                ddlMainApplicant.SelectedValue = dsdd.Tables[0].Rows[0]["INS_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["INS_ID"].ToString() : "";
                BindDepndsMainAppln();
                ddlVintage.SelectedValue = dsdd.Tables[0].Rows[0]["VN_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["VN_ID"].ToString() : "";
                ddlNature.SelectedValue = dsdd.Tables[0].Rows[0]["NT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["NT_ID"].ToString() : "";
                ddlIncomType.SelectedValue = dsdd.Tables[0].Rows[0]["IT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["IT_ID"].ToString() : "";
                // ddlLoanPurpose.SelectedValue = dsdd.Tables[0].Rows[0]["CH_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_ID"].ToString() : "";
                ddlCreditHistory.SelectedValue = dsdd.Tables[0].Rows[0]["CH_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_ID"].ToString() : "";
                txtApplnName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                txtAddress.Text = dsdd.Tables[0].Rows[0]["CAM_AP_ADD"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AP_ADD"].ToString() : "";
                txtContactNo.Text = dsdd.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
                txtMemberID.Text = dsdd.Tables[0].Rows[0]["LD_MID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_MID"].ToString() : "";
                BindTenor();
                ddlTenure.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_TENURE"] != DBNull.Value ? Convert.ToUInt32(dsdd.Tables[0].Rows[0]["CAM_TENURE"]).ToString() : "0";
                ddlIntrest.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_INR"] != DBNull.Value ? Convert.ToDouble(dsdd.Tables[0].Rows[0]["CAM_INR"]).ToString() : "0";
                txtEMIperLakh.Text = dsdd.Tables[0].Rows[0]["CAM_EPL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EPL"].ToString() : "";
                txtIIREligibility.Text = dsdd.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_IIR"].ToString() : "";
                txtFOIREligibility.Text = dsdd.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "";
                txtLoanAmountRequested.Text = dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"].ToString() : "";
                txtLoanEligibility.Text = dsdd.Tables[0].Rows[0]["CAM_LN_ELG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LN_ELG"].ToString() : "";

                txtTotalLoanEligibility.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";

                ddlPropType.SelectedValue = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "0";
                txtbassumedobligation.Text = dsdd.Tables[0].Rows[0]["CAM_HOBLIG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_HOBLIG"].ToString() : "";
                txtAssumdHLoan.Text = dsdd.Tables[0].Rows[0]["CAM_HLOAN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_HLOAN"].ToString() : "";

                btnSubmit.Enabled = false;

                SqlCommand cmddd1 = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY", con);
                cmddd1.Parameters.AddWithValue("@PT_ID", "");
                cmddd1.Parameters.AddWithValue("@PT_TYPE", "G");
                cmddd1.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter dadd1 = new SqlDataAdapter(cmddd1);
                DataSet dsdd1 = new DataSet();
                dadd1.Fill(dsdd1);
                if (ddlPropType.SelectedItem.Text != "--Select--")
                {

                    DataRow[] dr1 = dsdd1.Tables[0].Select("PT_DESC='" + ddlPropType.SelectedItem.Text + "'");
                    lblSqrft.Text = " @ " + dr1[0].ItemArray[2].ToString() + " / Sqft ";
                    ddlPropType.Focus();
                }
                ddlOccupancyStatus.SelectedValue = dsdd.Tables[0].Rows[0]["OC_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["OC_ID"].ToString() : "0";
                ddlUsage.SelectedValue = dsdd.Tables[0].Rows[0]["UG_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["UG_ID"].ToString() : "0";
                txtNoOFtenents.Text = dsdd.Tables[0].Rows[0]["CAM_NOT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOT"].ToString() : "";
                string strCamReg = dsdd.Tables[0].Rows[0]["CAM_REGNET"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_REGNET"].ToString() : "";
                txtLandArea.Text = dsdd.Tables[0].Rows[0]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAREA"].ToString() : "";
                txtGuideline.Text = dsdd.Tables[0].Rows[0]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_GLV"].ToString() : "";
                txtMarketValueSqrt.Text = dsdd.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
                txtConsidered.Text = dsdd.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CLV"].ToString() : "";
                txtBuildUpArea.Text = dsdd.Tables[0].Rows[0]["CAM_BAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BAREA"].ToString() : "";
                txtSqft.Text = dsdd.Tables[0].Rows[0]["CAM_SQFT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_SQFT"].ToString() : "";
                SqlCommand cmddd11 = new SqlCommand("RTS_SP_fetch_GLAP_datas", con);
                cmddd11.Parameters.AddWithValue("@LreqAmt", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
                cmddd11.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter dadd11 = new SqlDataAdapter(cmddd11);
                DataSet dsdd11 = new DataSet();
                dadd11.Fill(dsdd11);
                DataTable dtBlvAl = dsdd11.Tables[0];
                double nSqrftVal = Convert.ToDouble(txtBuildUpArea.Text) * Convert.ToDouble(dtBlvAl.Rows[0][0]);
                txtBuildingValue1.Text = nSqrftVal.ToString();
                txtSqft.Text = dsdd.Tables[0].Rows[0]["CAM_SQFT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_SQFT"].ToString() : "";
                txtAmunity.Text = dsdd.Tables[0].Rows[0]["CAM_AMENITIES"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AMENITIES"].ToString() : "";
                txtBuildingValue.Text = dsdd.Tables[0].Rows[0]["CAM_BV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BV"].ToString() : "";
                ddlAgeOfBuilding.SelectedValue = dsdd.Tables[0].Rows[0]["BA_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BA_ID"].ToString() : "0";
                txtDepreciation.Text = dsdd.Tables[0].Rows[0]["CAM_DEP"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_DEP"].ToString() : "";
                txtonsideredBuilding.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
                txtTotalPropertyValue.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
                txtLTVonProperty.Text = dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
                txtRecommendedLoan.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
                txtNameofInsuredPerson.Text = dsdd.Tables[0].Rows[0]["CAM_PCS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_PCS"].ToString() : "";

                txtAgriLandAcres.Text = dsdd.Tables[0].Rows[0]["CAM_AGL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGL"].ToString() : "";
                txtAgriIncome.Text = dsdd.Tables[0].Rows[0]["CAM_AGI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGI"].ToString() : "";

                txtDeviation.Text = dsdd.Tables[0].Rows[0]["CAM_DEVIATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_DEVIATE"].ToString() : "";
                if (dsdd.Tables[1] != null && dsdd.Tables[1].Rows.Count > 0)
                {
                    gvIncomeDetail.DataSource = dsdd.Tables[1];
                    gvIncomeDetail.DataBind();
                    BindBorrower(dsdd.Tables[1]);
                    ViewState["CurrentTable"] = dsdd.Tables[1];
                    for (int n = 0; n < dsdd.Tables[1].Rows.Count; n++)
                    {
                        string strText = dsdd.Tables[1].Rows[n]["NAME"].ToString();
                        int nIndex = DDLkycName.Items.IndexOf(DDLkycName.Items.FindByText(strText));
                        //  DDLkycName.Items.RemoveAt(nIndex);
                    }
                    DataTable dtCurrentTable = dsdd.Tables[1];
                    double nTotalLoanEligibility = 0.0;
                    for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                    {
                        double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                        string strIncomeSource = dtCurrentTable.Rows[n]["INCOME_SOURCE"] != DBNull.Value ? dtCurrentTable.Rows[n]["INCOME_SOURCE"].ToString() : "";
                        nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;

                        if (strIncomeSource.Contains("RENT"))
                        {
                            if (txtbxsumofrental.Text == "")
                            {
                                txtbxsumofrental.Text = Convert.ToDouble(nTempVal).ToString();
                            }
                            else
                            {

                                txtbxsumofrental.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxsumofrental.Text)).ToString();
                            }
                        }
                        else if (strIncomeSource.Contains("PENSION"))
                        {
                            if (txtPensionIncome.Text == "")
                            {
                                txtPensionIncome.Text = Convert.ToDouble(nTempVal).ToString();
                            }
                            else
                            {

                                txtPensionIncome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtPensionIncome.Text)).ToString();
                            }
                        }
                        else
                        {
                            if (txtbxotherincome.Text == "")
                            {
                                txtbxotherincome.Text = Convert.ToDouble(nTempVal).ToString();
                            }
                            else
                            {

                                txtbxotherincome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxotherincome.Text)).ToString();
                            }
                        }
                        double rent = 0.0;
                        double Pension = 0.0;
                        double other = 0.0;

                        if (txtbxsumofrental.Text != "")
                        {
                            rent = Convert.ToDouble(txtbxsumofrental.Text);
                        }
                        if (txtPensionIncome.Text != "")
                        {
                            Pension = Convert.ToDouble(txtPensionIncome.Text);
                        }
                        if (txtbxotherincome.Text != "")
                        {
                            other = Convert.ToDouble(txtbxotherincome.Text);
                        }


                    }

                    //   DDLkycName.DataBind();
                }


                if (dsdd.Tables[2] != null && dsdd.Tables[2].Rows.Count > 0)
                {
                    for (int i = 0; i < dsdd.Tables[2].Rows.Count; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                ddlLoanType1.SelectedValue = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                txtFinanciear1.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                ddlSource1.SelectedValue = dsdd.Tables[2].Rows[i]["CO_SOURCE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_SOURCE"].ToString() : "";
                                drpName1.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                txtEMIAmount1.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtBALEMIAmount1.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                txtcibil1.Text = dsdd.Tables[2].Rows[i]["CO_CIBIL"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_CIBIL"].ToString() : "";
                                break;
                            case 1:
                                ddlLoanType2.SelectedValue = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                txtFinanciear2.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName2.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                ddlSource2.SelectedValue = dsdd.Tables[2].Rows[i]["CO_SOURCE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_SOURCE"].ToString() : "";
                                txtEMIAmount2.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtBALEMIAmount2.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                txtcibil2.Text = dsdd.Tables[2].Rows[i]["CO_CIBIL"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_CIBIL"].ToString() : "";
                                break;
                            case 2:
                                ddlLoanType3.SelectedValue = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                txtFinanciear3.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName3.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                ddlSource3.SelectedValue = dsdd.Tables[2].Rows[i]["CO_SOURCE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_SOURCE"].ToString() : "";
                                txtEMIAmount3.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtBALEMIAmount3.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                txtcibil3.Text = dsdd.Tables[2].Rows[i]["CO_CIBIL"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_CIBIL"].ToString() : "";
                                break;
                            case 3:
                                ddlLoanType4.SelectedValue = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                txtFinanciear4.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName4.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                ddlSource4.SelectedValue = dsdd.Tables[2].Rows[i]["CO_SOURCE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_SOURCE"].ToString() : "";
                                txtEMIAmount4.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtBALEMIAmount4.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                txtcibil4.Text = dsdd.Tables[2].Rows[i]["CO_CIBIL"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_CIBIL"].ToString() : "";
                                break;
                            case 4:
                                ddlLoanType5.SelectedValue = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                txtFinanciear5.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName5.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                ddlSource5.SelectedValue = dsdd.Tables[2].Rows[i]["CO_SOURCE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_SOURCE"].ToString() : "";
                                txtEMIAmount5.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtBALEMIAmount5.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                txtcibil5.Text = dsdd.Tables[2].Rows[i]["CO_CIBIL"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_CIBIL"].ToString() : "";
                                break;
                        }
                    }
                }

                txtTotalEMIAmount.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";
                txtEmpCode.Text = dsdd.Tables[0].Rows[0]["CAM_EMP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EMP_ID"].ToString() : "";
                //bala changes for nominee details
                if (dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"] != DBNull.Value)
                {
                    if (Convert.ToString(dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"]).StartsWith("Others") == true)
                    {
                        tdNomineeName.Visible = true;
                        tdNomineeName1.Visible = true;
                        string[] strOthers = Convert.ToString(dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"]).Split('-');
                        // ddlNomineeName.SelectedItem.Text = strOthers[0].ToString();
                        ddlNomineeName.Items.FindByText(strOthers[0].ToString()).Selected = true;
                        txtNomineeName.Text = strOthers[1].ToString();

                        txtNomineeName.Enabled = true;
                        //Bala changes 05042018
                        tdRelationType.Visible = false;
                        tdRelationType1.Visible = false;
                        txtNomineeRelation.Enabled = true;
                    }
                    else
                    {
                        tdNomineeName.Visible = false;
                        tdNomineeName1.Visible = false;
                        //Bala changes 05042018
                        tdRelationType.Visible = true;
                        tdRelationType1.Visible = true;
                        // ddlNomineeName.SelectedItem.Text = dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"].ToString() : "0";
                        ddlNomineeName.Items.FindByText(dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"].ToString() : "0").Selected = true;


                    }
                }

                txtNomineeRelation.Text = dsdd.Tables[0].Rows[0]["CAM_NOMEE_RELN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOMEE_RELN"].ToString() : "";
                txtRelationShip.Text = dsdd.Tables[0].Rows[0]["CAM_NOMEE_RELN_TYPE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOMEE_RELN_TYPE"].ToString() : "";


                BindEMpDets();

            }
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void BindDepndsMainAppln()
    {
        if (ddlMainApplicant.SelectedIndex > 0)
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);

            cmddd.Parameters.AddWithValue("@VN_ID", "");
            cmddd.Parameters.AddWithValue("@VN_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlVintage.DataSource = dsdd;
            ddlVintage.DataTextField = "VN_DESC";
            ddlVintage.DataValueField = "VN_ID";
            ddlVintage.DataBind();
            ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));



            ddlNature.Items.Clear();
            con = new SqlConnection(strcon);
            con.Open();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_NATURE", con);
            cmddd.Parameters.AddWithValue("@NT_ID", "");
            cmddd.Parameters.AddWithValue("@NT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlNature.DataSource = dsdd;
            ddlNature.DataTextField = "NT_DESC";
            ddlNature.DataValueField = "NT_ID";
            ddlNature.DataBind();
            ddlNature.Items.Insert(0, new ListItem("--Select--", "0"));


            ddlIncomType.Items.Clear();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_INCOME_TYPE", con);
            cmddd.Parameters.AddWithValue("@IT_ID", "");
            //cmddd.Parameters.AddWithValue("@IT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.Parameters.AddWithValue("@IT_INS_ID", "");
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlIncomType.DataSource = dsdd;
            ddlIncomType.DataTextField = "IT_DESC";
            ddlIncomType.DataValueField = "IT_ID";
            ddlIncomType.DataBind();
            ddlIncomType.Items.Insert(0, new ListItem("--Select--", "0"));

            con.Close();
        }
    }

    public void clear()
    {
        // ddlLeadNo.SelectedIndex = 0;
        txtCAMDATE.Text = "";
        FirstGridViewRow();
    }
    protected void ddlMainApplicant_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlMainApplicant.SelectedIndex > 0)
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);

            cmddd.Parameters.AddWithValue("@VN_ID", "");
            cmddd.Parameters.AddWithValue("@VN_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlVintage.DataSource = dsdd;
            ddlVintage.DataTextField = "VN_DESC";
            ddlVintage.DataValueField = "VN_ID";
            ddlVintage.DataBind();
            ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));



            ddlNature.Items.Clear();
            con = new SqlConnection(strcon);
            con.Open();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_NATURE", con);
            cmddd.Parameters.AddWithValue("@NT_ID", "");
            cmddd.Parameters.AddWithValue("@NT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlNature.DataSource = dsdd;
            ddlNature.DataTextField = "NT_DESC";
            ddlNature.DataValueField = "NT_ID";
            ddlNature.DataBind();
            ddlNature.Items.Insert(0, new ListItem("--Select--", "0"));


            ddlIncomType.Items.Clear();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_INCOME_TYPE", con);
            cmddd.Parameters.AddWithValue("@IT_ID", "");
            //cmddd.Parameters.AddWithValue("@IT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.Parameters.AddWithValue("@IT_INS_ID", "");
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlIncomType.DataSource = dsdd;
            ddlIncomType.DataTextField = "IT_DESC";
            ddlIncomType.DataValueField = "IT_ID";
            ddlIncomType.DataBind();
            ddlIncomType.Items.Insert(0, new ListItem("--Select--", "0"));

            con.Close();
        }
    }
    protected void ddlPropType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            btnSubmit.Enabled = false;
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY", con);
            cmddd.Parameters.AddWithValue("@PT_ID", "");
            cmddd.Parameters.AddWithValue("@PT_TYPE", "G");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();

            if (ddlPropType.SelectedItem.Text != "--Select--")
            {

                DataRow[] dr = dsdd.Tables[0].Select("PT_DESC='" + ddlPropType.SelectedItem.Text + "'");
                lblSqrft.Text = " @ " + dr[0].ItemArray[2].ToString() + " / Sqft ";
                ptypval = Convert.ToDouble(dr[0].ItemArray[2].ToString());
                ddlPropType.Focus();
            }

            //bala changes 10.11.2016
            if (ddlPropType.SelectedItem.Text == "Vacant plot")
            {
                // ddlOccupancyStatus.SelectedItem.Text = "NA";
                ddlOccupancyStatus.SelectedValue = "4";
                ddlOccupancyStatus.Enabled = false;
                // ddlUsage.SelectedItem.Text = "NA";
                ddlUsage.SelectedValue = "4";
                ddlUsage.Enabled = false;
            }
            else
            {
                BindOccupancy();
                BindUsage();
                ddlOccupancyStatus.Enabled = true;
                ddlUsage.Enabled = true;

            }
            //Bala changes ends 10.11.2016
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void ddlCustSource_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtIncome.Text = "";
            txtFactor.Text = "";
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
            cmddd.Parameters.AddWithValue("@CT_ID", "");
            cmddd.Parameters.AddWithValue("@CT_TYPE", "G");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            dtSourceOfIncome = dsdd.Tables[0];
            con.Close();

            if (ddlCustSource.SelectedItem.Text != "--Select--")
            {

                DataRow[] dr = dtSourceOfIncome.Select("CT_DESC='" + ddlCustSource.SelectedItem.Text + "'");
                //bala changes 16112016
                //Check the SOURCE OF INCOME - "Rent By Cash Receipt" is more than 10 lakhs
                //if (ddlCustSource.SelectedItem.Text == "RENT BY CASH RECEIPT")
                //{
                //    if (Convert.ToInt32(Session["PD_AMT"].ToString()) > 1000000)
                //    {
                //        txtIncomeTaken.Text = "50.0";
                //    }
                //    else
                //    {
                //        txtIncomeTaken.Text = dr[0].ItemArray[3].ToString();
                //    }
                //}
                //else
                //{
                //    txtIncomeTaken.Text = dr[0].ItemArray[3].ToString();
                //}

                txtIncomeTaken.Text = dr[0].ItemArray[3].ToString();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    //PMT Calculation
    public static double GetEMI(double presentValue, double financingPeriod, double interestRatePerYear)
    {
        //interestRatePerYear = 26.00;
        //financingPeriod = 60;
        //presentValue = 100000;
        double a, b, x;
        double monthlyPayment;
        a = (1 + interestRatePerYear / 1200);
        b = financingPeriod;
        x = Math.Pow(a, b);
        x = 1 / x;
        x = 1 - x;
        monthlyPayment = (presentValue) * (interestRatePerYear / 1200) / x;
        return (monthlyPayment);
    }
    public void CalculateLoadELigibility()
    {
        try
        {
            string strval = this.txtTotalEMIAmount.Text;
            double presentValue = 100000;
            double financingPeriod = 0.0;
            double interestRatePerYear = 0.0;
            double IIREligibilit = 0.0;
            double FOIREligibility = 0.0;
            double AgriIncome = 0.0;
            double assumeobligation = 0.0;
            txtAssumdHLoan.Text = "";
            txtbassumedobligation.Text = "";
            if (txtAgriIncome.Text != "")
            {
                AgriIncome = Convert.ToDouble(txtAgriIncome.Text);
            }
            if (ddlTenure.SelectedItem.Text != "")
            {
                financingPeriod = Convert.ToDouble(ddlTenure.SelectedItem.Text) * 12;
            }
            if (ddlIntrest.SelectedItem.Text != "--Select--")
            {
                interestRatePerYear = Convert.ToDouble(ddlIntrest.SelectedItem.Text);
            }

            if (txtLoanAmountRequested.Text != "")
            {
                if (Convert.ToDouble(txtLoanAmountRequested.Text) > Convert.ToDouble(1500000))
                {
                    txtAssumdHLoan.Text = Convert.ToString(Convert.ToDouble(txtLoanAmountRequested.Text) * 10 / 100);

                    //txtbassumedobligation.Text = Convert.ToString((Convert.ToDouble(txtLoanAmountRequested.Text) - Convert.ToDouble(1500000)) * 3 / 100);
                    txtbassumedobligation.Text = Convert.ToString((Convert.ToDouble(txtAssumdHLoan.Text)) * 3 / 100);


                }

            }


            if (txtbassumedobligation.Text.Trim() != "")
            {
                assumeobligation = Convert.ToDouble(txtbassumedobligation.Text);
            }
            txtEMIperLakh.Text = Math.Round(GetEMI(presentValue, financingPeriod, interestRatePerYear)).ToString();
            //IIREligibilit = (((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome ) * 40 / 100) / (GetEMI(presentValue, financingPeriod, interestRatePerYear))) * 100000;
            IIREligibilit = (((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 50 / 100) / (GetEMI(presentValue, financingPeriod, interestRatePerYear))) * 100000;
            FOIREligibility = ((((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 50 / 100) - (Convert.ToDouble(txtTotalEMIAmount.Text != "" ? txtTotalEMIAmount.Text : "0.0") + assumeobligation)) / GetEMI(presentValue, financingPeriod, interestRatePerYear)) * 100000;
            //FOIREligibility =((Convert.ToDouble(txtTotalLoanEligibility.Text) * 50 / 100)- (Convert.ToDouble(txtTotalEMIAmount.Text))/ (GetEMI(presentValue, financingPeriod, interestRatePerYear))) * 100000;

            //IIREligibilit = IIREligibilit + AgriIncome;
            //FOIREligibility = FOIREligibility + AgriIncome;

            txtIIREligibility.Text = Convert.ToInt32(IIREligibilit).ToString();
            txtFOIREligibility.Text = Convert.ToInt32(FOIREligibility).ToString();

            if (IIREligibilit <= FOIREligibility)
            {
                txtLoanEligibility.Text = Convert.ToInt32(IIREligibilit).ToString();

            }
            else if (IIREligibilit > FOIREligibility)
            {
                txtLoanEligibility.Text = Convert.ToInt32(FOIREligibility).ToString();
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtIntestRate_TextChanged(object sender, EventArgs e)
    {


    }
    protected void ddlAgeOfBuilding_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_BD_AGE", con);
        cmddd.Parameters.AddWithValue("@BA_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();
        DataTable dtAge = dsdd.Tables[0];
        btnSubmit.Enabled = false;
        if (ddlAgeOfBuilding.SelectedItem.Text != "--Select--")
        {
            DataRow[] dr = dtAge.Select("BA_DESC='" + ddlAgeOfBuilding.SelectedItem.Text + "'");

            txtDepreciation.Text = dr[0].ItemArray[2].ToString();

        }
        else
        {
            ddlAgeOfBuilding.Focus();
        }
    }
    protected void txtMarketValueSqrt_TextChanged(object sender, EventArgs e)
    {
        /*CR changes for IR-534
        Description: Calculate considered land value based on market value
        Changes done by : Baulin. D
        Changes done on : 15-July-2019
        */
        #region OLD CODE
        /*
        try
        {
            btnSubmit.Enabled = false;
            double dGuidline = 0.0;
            double dMarketValue = 0.0;
            double dLandArea = 0.0;
            //if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "" && txtLandArea.Text != "")
            //{
            if (txtMarketValueSqrt.Text.Trim() != "")
            {
                dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);
                dLandArea = Convert.ToDouble(txtLandArea.Text);

                if (dGuidline < dMarketValue && dGuidline > 0)
                {
                    txtConsidered.Text = Convert.ToInt32(dGuidline * dLandArea).ToString();
                }
                else if (dGuidline > dMarketValue && dMarketValue > 0)
                {
                    txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                }
                else if (dGuidline == dMarketValue && dGuidline > 0)
                {
                    txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                }
                else
                {
                if (dGuidline > 0)
                {
                    txtConsidered.Text = Convert.ToInt32(dGuidline * dLandArea).ToString();
                }
                else
                //{
               // if (dMarketValue > 0)
                {
                    //txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                    txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                }
                }
                //}
            }
            txtBuildUpArea.Focus();
        }
        catch (Exception ex)
        {
        }
        */
        #endregion

        #region VARIABLES
        string txtMarketValue = string.Empty;
        string txtLndArea = string.Empty;

        double dMarketValue = 0.0;
        double dLandArea = 0.0;
        #endregion

        txtMarketValue = txtMarketValueSqrt.Text.Trim();
        txtLndArea = txtLandArea.Text.Trim();

        btnSubmit.Enabled = false;

        if (!string.IsNullOrEmpty(txtMarketValue) && !string.IsNullOrEmpty(txtLndArea))
        {
            dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);
            dLandArea = Convert.ToDouble(txtLandArea.Text);

            if (dMarketValue > 0 && dLandArea > 0)
            {
                txtConsidered.Text = Convert.ToDouble(dMarketValue * dLandArea).ToString();
            }
        }
        /*End of CR changes for IR-534*/
    }
    protected void txtBuildUpArea_TextChanged(object sender, EventArgs e)
    {

    }
    public int RoundNum(int num)
    {
        int rem = num % 10;
        return rem >= 5 ? (num - rem + 10) : (num - rem);
    }
    public int RoundDown(int toRound)
    {
        int nValue = 0;

        if (toRound.ToString().Length < 4)
        {
            nValue = toRound - toRound % 10;
        }
        else if (toRound.ToString().Length < 6)
        {
            nValue = toRound - toRound % 100;
        }
        else
        {
            nValue = toRound - toRound % 1000;
        }
        return nValue;
    }



    protected void txtAgriIncome_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        if (ddlIntrest.SelectedItem.Text != "--Select--")
        {
            if (txtbassumedobligation.Text.Trim() != "")
            {
                CalculateLoadELigibility();
            }
            else
            {
                txtbassumedobligation.Focus();
                uscMsgBox1.AddMessage("Please enter the assumed obligation", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //InsertCamLapValues();
        //InsertDraftCamLapValues("S");
        if (ddlLeadNo.SelectedItem.Text.Contains("ELP"))
        {
            if (txtEmpCode.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Code');", true);
            else if (txtEMpNAme.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Name');", true);
            else if (txtDesgn.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Designation');", true);
            else if (txtContact.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Contact Number');", true);
            else if (ttxEmailEmp.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Email');", true);
            else if (txtEmpCompany.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Company');", true);
            else if (txtDOJ.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Date Of Joining');", true);
            else if (txtGrade.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Grade');", true);
            else
                InsertDraftCamLapValues("S");
        }
        else
            InsertDraftCamLapValues("S");
        if (cmrs > 0)
        {
            //UpdateValues();
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Failed to Save');", true);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_CAM_GLAP.aspx");
    }
    protected void UpdateValues()
    {
        try
        {
            System.DateTime dtpddate;
            System.DateTime dtgn;

            try
            {
                dtpddate = Convert.ToDateTime(DateTime.ParseExact(hfdcrdtglp.Value, "dd/M/yyyy", CultureInfo.InvariantCulture));//Convert.ToDateTime(hfdcrdtghf.Value);

                dtgn = Convert.ToDateTime(txtPDDate.Text);

                TimeSpan diff = dtgn.Subtract(dtpddate);

                if (diff.Days >= 0)
                {
                    con = new SqlConnection(strcon);

                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();

                    cmd = new SqlCommand("RTS_SP_UPDATE_CAM_GHF_GLAP", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 120000;
                    cmd.Parameters.AddWithValue("@LDID", Convert.ToInt32(ddlLeadNo.SelectedValue.ToString()));
                    cmd.Parameters.AddWithValue("@PDDATE", dtgn.ToString("MM/dd/yyyy"));
                    cmd.Parameters.AddWithValue("@RADDR", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@CAM_HOBLIG", txtbassumedobligation.Text);
                    cmd.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                    int rs = cmd.ExecuteNonQuery();

                    if (rs > 0)
                    {

                        //if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "")
                        //{
                        //    if (2 * Convert.ToDouble(txtGuideline.Text) < Convert.ToDouble(txtMarketValueSqrt.Text))
                        //    {
                        //        sendMail();
                        //    }

                        //}

                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Saved Successfully');window.location.reload()", true);
                        //  Response.Redirect("CAM_LAP.aspx");
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   not Saved');", true);
                    }


                }
                else
                {
                    uscMsgBox1.AddMessage("PD Date should not be less than the lead Created date...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }


    }
    protected void InsertCamLapValues()
    {

        try
        {
            if (ddlRelationShip.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Relation ship", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlMainApplicant.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Main Source of Income", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlVintage.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Vintage", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlNature.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Nature OfBussiness/Job", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlIncomType.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Income Type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //else if (ddlLoanPurpose.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Loan Purpose", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else if (ddlCreditHistory.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Cedit History", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                DataTable dtIncomeDetails = new DataTable();
                dtIncomeDetails = (DataTable)ViewState["CurrentTable"];
                if (dtIncomeDetails.Columns.Contains("INCOME_SOURCE"))
                {
                    dtIncomeDetails.Columns.Remove("INCOME_SOURCE");
                }
                if (dtIncomeDetails.Columns.Contains("RELATIONSHIP"))
                {
                    dtIncomeDetails.Columns.Remove("RELATIONSHIP");
                }

                DataTable dtObligation = new DataTable();
                dtObligation = BindObligationTable();

                DataTable dtColletral = new DataTable();
                dtColletral = BindCollateralTable();

                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertCAM", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@CAM_TYPE", "B");
                //cmdinsert.Parameters.AddWithValue("@CAM_PR_ID", "1");

                //cmdinsert.Parameters.AddWithValue("@CAM_BR_ID", txtBranchName.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LD_ID", ddlLeadNo.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_AP_ADD", txtAddress.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_ER_ID", ddlRelationShip.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_INS_ID", ddlMainApplicant.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_VN_ID", ddlVintage.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_NT_ID", ddlNature.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_IT_ID", ddlIncomType.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_PP_ID", ddlLoanPurpose.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_CH_ID", ddlCreditHistory.SelectedValue.ToString());

                cmdinsert.Parameters.AddWithValue("@CAM_AGL", txtAgriLandAcres.Text != "" ? Convert.ToDouble(txtAgriLandAcres.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_AGI", txtAgriIncome.Text != "" ? Convert.ToDouble(txtAgriIncome.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_IN", txtTotalLoanEligibility.Text != "" ? Convert.ToDouble(txtTotalLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_EMI", txtTotalEMIAmount.Text != "" ? Convert.ToDouble(txtTotalEMIAmount.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TENURE", ddlTenure.SelectedItem.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_INR", ddlIntrest.SelectedItem.Text != "--Select--" ? Convert.ToDouble(ddlIntrest.SelectedItem.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_EPL", txtEMIperLakh.Text != "" ? Convert.ToDouble(txtEMIperLakh.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_IRR", txtIIREligibility.Text != "" ? Convert.ToDouble(txtIIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_FOIR", txtFOIREligibility.Text != "" ? Convert.ToDouble(txtFOIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LAMT_REQ", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_ELG", txtLoanEligibility.Text != "" ? Convert.ToDouble(txtLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_PT_ID", ddlPropType.SelectedItem.Text.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_OC_ID", ddlOccupancyStatus.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_UG_ID", ddlUsage.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_NOT", txtNoOFtenents.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LAREA", txtLandArea.Text != "" ? Convert.ToDouble(txtLandArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_GLV", txtGuideline.Text != "" ? Convert.ToDouble(txtGuideline.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_MV", txtMarketValueSqrt.Text != "" ? Convert.ToDouble(txtMarketValueSqrt.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CLV", txtConsidered.Text != "" ? Convert.ToDouble(txtConsidered.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BAREA", txtBuildUpArea.Text != "" ? Convert.ToDouble(txtBuildUpArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_SQFT", txtSqft.Text != "" ? Convert.ToDouble(txtSqft.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BV", txtBuildingValue.Text != "" ? Convert.ToDouble(txtBuildingValue.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_AMENITIES", txtAmunity.Text != "" ? Convert.ToDouble(txtAmunity.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BA_ID", ddlAgeOfBuilding.SelectedItem.Text);
                //cmdinsert.Parameters.AddWithValue("@CAM_DEP", txtDepreciation.Text != "" ? Convert.ToDouble(txtDepreciation.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_DEP", 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CBV", txtonsideredBuilding.Text != "" ? Convert.ToDouble(txtonsideredBuilding.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_TPV", txtTotalPropertyValue.Text != "" ? Convert.ToDouble(txtTotalPropertyValue.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_LTV", txtLTVonProperty.Text != "" ? Convert.ToDouble(txtLTVonProperty.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_RLA", txtRecommendedLoan.Text != "" ? Convert.ToDouble(txtRecommendedLoan.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_Deviation", txtDeviation.Text);

                cmdinsert.Parameters.AddWithValue("@CAM_PCS", txtNameofInsuredPerson.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_CBY", Session["ID"].ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_MBY", Session["ID"].ToString());


                cmdinsert.Parameters.AddWithValue("@tblIncome_Details", dtIncomeDetails);
                cmdinsert.Parameters.AddWithValue("@tblOBLIGATE", dtObligation);
                cmdinsert.Parameters.AddWithValue("@tblCOLLATERAL", dtColletral);

                int n = cmdinsert.ExecuteNonQuery();
                cmrs = n;


                con.Close();
            }
        }
        catch (Exception ex
            )
        {
            ErrorLog.WriteError(ex);
        }
    }


    public DataTable BindObligationTable()
    {
        DataTable dtObligation = new DataTable();
        DataRow drObligation = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string))); -IR/RL/SEP19/09/556_New Fields Required in RTS CAM Obligation details
        dtObligation.Columns.Add(new DataColumn("CO_TYPE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_FIN", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_TENURE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_LOAN_AMT", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_SOURCE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_BORW", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_AMOUNT", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_BAL_EMI", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_CIBIL", typeof(string)));

        if (txtFinanciear1.Text != "" && drpName1.SelectedItem.Text != "--Select--" && txtEMIAmount1.Text != "")
        {

            drObligation = dtObligation.NewRow();
            drObligation["CO_TYPE"] = ddlLoanType1.SelectedItem.Text != "--Select--" ? ddlLoanType1.SelectedValue : "";
            drObligation["CO_FIN"] = txtFinanciear1.Text;
            drObligation["CO_TENURE"] = "";
            drObligation["CO_LOAN_AMT"] = "";
            drObligation["CO_SOURCE"] = ddlSource1.SelectedItem.Text != "--Select--" ? ddlSource1.SelectedValue : "";
            drObligation["CO_BORW"] = drpName1.SelectedItem.Text != "--Select--" ? drpName1.SelectedItem.Text : "";
            drObligation["CO_AMOUNT"] = txtEMIAmount1.Text;
            drObligation["CO_BAL_EMI"] = txtBALEMIAmount1.Text;
            drObligation["CO_CIBIL"] = txtcibil1.Text;
            dtObligation.Rows.Add(drObligation);
        }
        if (txtFinanciear2.Text != "" && drpName2.SelectedItem.Text != "--Select--" && txtEMIAmount2.Text != "")
        {
            drObligation = dtObligation.NewRow();
            drObligation["CO_TYPE"] = ddlLoanType2.SelectedItem.Text != "--Select--" ? ddlLoanType2.SelectedValue : "";
            drObligation["CO_FIN"] = txtFinanciear2.Text;
            drObligation["CO_TENURE"] = "";
            drObligation["CO_LOAN_AMT"] = "";
            drObligation["CO_SOURCE"] = ddlSource2.SelectedItem.Text != "--Select--" ? ddlSource2.SelectedValue : "";
            drObligation["CO_BORW"] = drpName2.SelectedItem.Text;
            drObligation["CO_AMOUNT"] = txtEMIAmount2.Text;
            drObligation["CO_BAL_EMI"] = txtBALEMIAmount2.Text;
            drObligation["CO_CIBIL"] = txtcibil2.Text;
            dtObligation.Rows.Add(drObligation);
        }
        if (txtFinanciear3.Text != "" && drpName3.SelectedItem.Text != "--Select--" && txtEMIAmount3.Text != "")
        {
            drObligation = dtObligation.NewRow();
            drObligation["CO_TYPE"] = ddlLoanType3.SelectedItem.Text != "--Select--" ? ddlLoanType3.SelectedValue : "";
            drObligation["CO_FIN"] = txtFinanciear3.Text;
            drObligation["CO_TENURE"] = "";
            drObligation["CO_LOAN_AMT"] = "";
            drObligation["CO_SOURCE"] = ddlSource3.SelectedItem.Text != "--Select--" ? ddlSource3.SelectedValue : "";
            drObligation["CO_BORW"] = drpName3.SelectedItem.Text;
            drObligation["CO_AMOUNT"] = txtEMIAmount3.Text;
            drObligation["CO_BAL_EMI"] = txtBALEMIAmount3.Text;
            drObligation["CO_CIBIL"] = txtcibil3.Text;
            dtObligation.Rows.Add(drObligation);
        }
        if (txtFinanciear4.Text != "" && drpName4.SelectedItem.Text != "--Select--" && txtEMIAmount4.Text != "")
        {
            drObligation = dtObligation.NewRow();
            drObligation["CO_TYPE"] = ddlLoanType4.SelectedItem.Text != "--Select--" ? ddlLoanType4.SelectedValue : "";
            drObligation["CO_FIN"] = txtFinanciear4.Text;
            drObligation["CO_TENURE"] = "";
            drObligation["CO_LOAN_AMT"] = "";
            drObligation["CO_SOURCE"] = ddlSource4.SelectedItem.Text != "--Select--" ? ddlSource4.SelectedValue : "";
            drObligation["CO_BORW"] = drpName4.SelectedItem.Text;
            drObligation["CO_AMOUNT"] = txtEMIAmount4.Text;
            drObligation["CO_BAL_EMI"] = txtBALEMIAmount4.Text;
            drObligation["CO_CIBIL"] = txtcibil4.Text;
            dtObligation.Rows.Add(drObligation);
        }
        if (txtFinanciear5.Text != "" && drpName5.SelectedItem.Text != "--Select--" && txtEMIAmount5.Text != "")
        {
            drObligation = dtObligation.NewRow();
            drObligation["CO_TYPE"] = ddlLoanType5.SelectedItem.Text != "--Select--" ? ddlLoanType5.SelectedValue : "";
            drObligation["CO_FIN"] = txtFinanciear5.Text;
            drObligation["CO_TENURE"] = "";
            drObligation["CO_LOAN_AMT"] = "";
            drObligation["CO_SOURCE"] = ddlSource5.SelectedItem.Text != "--Select--" ? ddlSource5.SelectedValue : "";
            drObligation["CO_BORW"] = drpName5.SelectedItem.Text;
            drObligation["CO_AMOUNT"] = txtEMIAmount5.Text;
            drObligation["CO_BAL_EMI"] = txtBALEMIAmount5.Text;
            drObligation["CO_CIBIL"] = txtcibil5.Text;
            dtObligation.Rows.Add(drObligation);
        }
        return dtObligation;
    }

    public DataTable BindCollateralTable()
    {
        DataTable dtCollateral = new DataTable();
        DataRow drCollateral = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));     
        dtCollateral.Columns.Add(new DataColumn("CC_COLAT", typeof(string)));
        dtCollateral.Columns.Add(new DataColumn("CC_AMOUNT", typeof(string)));
        return dtCollateral;
    }


    protected void btnCalculate_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtTotalLoanEligibility.Text == "")
            {
                DDLkycName.Focus();
                uscMsgBox1.AddMessage("Please Add Income Details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
            else if (ddlIntrest.SelectedItem.Text == "--Select--")
            {

                uscMsgBox1.AddMessage("Please Give Intrest Rate value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                ddlIntrest.Focus();
            }
            else if (txtLoanAmountRequested.Text == "")
            {
                uscMsgBox1.AddMessage("Please Give Loan Amount Requested value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtLoanAmountRequested.Focus();
            }
            else if (txtBuildingValue.Text == "")
            {
                uscMsgBox1.AddMessage("Please Give Building value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtBuildUpArea.Focus();
            }
            //else if (txtDepreciation.Text == "")
            //{
            //    uscMsgBox1.AddMessage("Please Select Age of Building", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //    ddlAgeOfBuilding.Focus();
            //}

            else
            {
                if (txtBuildingValue.Text != "" && txtLoanAmountRequested.Text != "")//txtDepreciation.Text != "" && 
                {
                    //if (txtbassumedobligation.Text.Trim() != "")
                    //{

                    CalculateLoadELigibility();
                    //}
                    //else
                    //{
                    //    txtbassumedobligation.Focus();
                    //    uscMsgBox1.AddMessage("Please enter the assumed obligation", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    //    return;
                    //}

                    /*CR changes for IR-534
                     Description: Calculate considered land value based on market value
                     Changes done by : Baulin. D
                     Changes done on : 15-July-2019
                     */
                    //if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "" && txtLandArea.Text != "")
                    //{
                    //    dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                    //    dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);
                    //    dLandArea = Convert.ToDouble(txtLandArea.Text);
                    //    if (dGuidline < dMarketValue)
                    //    {
                    //        txtConsidered.Text = Convert.ToDouble(dGuidline * dLandArea).ToString();
                    //    }
                    //    else if (dGuidline > dMarketValue)
                    //    {
                    //        txtConsidered.Text = Convert.ToDouble(dMarketValue * dLandArea).ToString();
                    //    }
                    //}

                    double dMarketValue = 0.0;
                    double dLandArea = 0.0;

                    string txtMarketValue = txtMarketValueSqrt.Text.Trim();
                    string txtLndArea = txtLandArea.Text.Trim();

                    if (!string.IsNullOrEmpty(txtMarketValue) && !string.IsNullOrEmpty(txtLndArea))
                    {
                        dLandArea = Convert.ToDouble(txtLandArea.Text);
                        dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);

                        if (dMarketValue > 0 && dLandArea > 0)
                        {
                            txtConsidered.Text = Convert.ToDouble(dMarketValue * dLandArea).ToString();
                        }
                    }
                    /*End of CR changes for IR-534*/

                    // double nVal = 100 - Convert.ToDouble(txtDepreciation.Text);
                    // txtonsideredBuilding.Text = Convert.ToString(Convert.ToDouble(txtBuildingValue.Text) * (nVal / 100));
                    //   txtonsideredBuilding.Text = Math.Min((Convert.ToDouble(txtBuildUpArea.Text) * ptypval), Convert.ToDouble(txtBuildingValue.Text)).ToString();
                    double nAmnt1 = Convert.ToDouble(txtBuildingValue.Text) + Convert.ToDouble(txtAmunity.Text != "" ? txtAmunity.Text : "0");
                    double nAmnt2 = Convert.ToDouble(txtBuildingValue1.Text);
                    double nMin = Math.Min(nAmnt1, nAmnt2);
                    //  txtonsideredBuilding.Text = Convert.ToString(Convert.ToDouble(txtBuildingValue.Text) + Convert.ToDouble(txtAmunity.Text != "" ?  txtAmunity.Text :"0"));
                    txtonsideredBuilding.Text = nMin.ToString();
                    int prop_percent = 0;

                    if (txtConsidered.Text != "")
                    {
                        txtTotalPropertyValue.Text = Convert.ToString(Convert.ToDouble(txtonsideredBuilding.Text) + Convert.ToDouble(txtConsidered.Text));
                        // txtLTVonProperty.Text = Convert.ToString(Convert.ToDouble(txtTotalPropertyValue.Text) * 50 / 100);

                        prop_percent = clscommon.Get_MR_Property_Percentage(ddlPropType.SelectedValue, "G");
                        double nMinVal = 0;
                        if (txtLoanAmountRequested.Text != "" && txtLoanEligibility.Text != "")
                        {
                            nMinVal = Math.Min(Convert.ToDouble(txtLoanAmountRequested.Text), Convert.ToDouble(txtLoanEligibility.Text));
                            //LTV amount calcualtion starts
                            if (ddlPropType.SelectedItem.Text != "--Select--" && ddlPropType.SelectedItem.Text == "Mangalore tiled roofing")
                            {
                                txtLTVonProperty.Text = Convert.ToString(Convert.ToDouble(txtTotalPropertyValue.Text) * prop_percent / 100);
                            }
                            else
                                if (Convert.ToDouble(nMinVal) > 500000 && Convert.ToDouble(nMinVal) < 1000000 && (ddlPropType.SelectedItem.Text).Contains("RCC roofing"))
                            {
                                txtLTVonProperty.Text = Convert.ToString(Convert.ToDouble(txtTotalPropertyValue.Text) * prop_percent / 100);
                            }
                            else
                                if (Convert.ToDouble(nMinVal) > 1000000 && (ddlPropType.SelectedItem.Text).Contains("RCC roofing"))
                            {
                                txtLTVonProperty.Text = Convert.ToString(Convert.ToDouble(txtTotalPropertyValue.Text) * 50 / 100);
                            }
                            else
                                    if (Convert.ToDouble(nMinVal) > 500000 && Convert.ToDouble(nMinVal) < 1000000 && !(ddlPropType.SelectedItem.Text).Contains("RCC roofing"))
                            {
                                txtLTVonProperty.Text = Convert.ToString(Convert.ToDouble(txtConsidered.Text) * prop_percent / 100);
                            }
                            else
                                        if (Convert.ToDouble(nMinVal) > 1000000 && !(ddlPropType.SelectedItem.Text).Contains("RCC roofing"))
                            {
                                txtLTVonProperty.Text = Convert.ToString(Convert.ToDouble(txtConsidered.Text) * 50 / 100);
                            }
                            else
                            {
                                txtLTVonProperty.Text = Convert.ToString(Convert.ToDouble(txtTotalPropertyValue.Text) * 50 / 100);
                            }
                            //LTV amount calcualtion starts
                            nMinVal = Math.Min(Convert.ToDouble(nMinVal), Convert.ToDouble(txtLTVonProperty.Text));
                            int nAmount = Convert.ToInt32(Math.Round(nMinVal));
                            txtRecommendedLoan.Text = Convert.ToString(RoundDown(nAmount));
                            if (txtRecommendedLoan.Text != "")
                            {
                                btnSubmit.Enabled = true;
                            }
                        }

                    }
                    txtNameofInsuredPerson.Focus();
                }
                //  btnSubmit.Enabled = false;
            }
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
            cmddd.Parameters.AddWithValue("@CT_ID", "");
            cmddd.Parameters.AddWithValue("@CT_TYPE", "G");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            dtSourceOfIncome = dsdd.Tables[0];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtLoanAmountRequested_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        CalculateLoadELigibility();
    }
    protected void ddlIntrest_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        if (ddlIntrest.SelectedItem.Text != "--Select--")
        {
            //if (txtbassumedobligation.Text.Trim() != "")
            //{
            CalculateLoadELigibility();
            //}
            //else
            //{
            //    txtbassumedobligation.Focus();
            //    uscMsgBox1.AddMessage("Please enter the assumed obligation", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //    return;
            //}
            txtLoanAmountRequested.Focus();
        }
        else
        {
            uscMsgBox1.AddMessage("Please Give Intrest Rate value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            ddlIntrest.Focus();
        }
    }

    public void sendMail()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {

            con.Open();
            /////// mail ///////////
            //  strMailDetail = "";

            SqlCommand cmddet = new SqlCommand("select * from MR_BRANCH where BR_NAME='" + Session["UNITNAME"].ToString() + "'", con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);


            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT * FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_RPA"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_RPA"].ToString() : "rts-helpdesk@equitasbank.com";
                //cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                //bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                //bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
            }

            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            fromID = "VF-ITSupport<VF-ITSupport@equitasbank.com>";
            toID = to;//"ManimaranK@equitasbank.com";
            //bcc2ID = "shankarg@equitasbank.com";
            //ccID = "rts-helpdesk@equitasbank.com";
            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            /*  threadSendMails = new System.Threading.Thread(delegate()
              {*/

            String BodyTxt = "<html><body><basefont face='Calibri'> Dear TRM,<br/><br/> Request for Risk Property Assessment of market value has been made by " + txtBranchName.Text + " Branch, " + Session["AREANAME"].ToString() + " Area <br/>";
            BodyTxt = BodyTxt + "Please initiate and submit the report as per the prescribed TAT. <br/> Lead No:" + ddlLeadNo.SelectedItem.Text + "<br/>" +
                                "Property Address : " + Session["PROPADDR"].ToString().Trim() + " <br/><br/>"


                + "Thanks and Regards,<br/>Risk Team<br/><br/> <span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></body></html>";


            blMailStatus = EmailManager.sendemailRPA(toID, "VF-ITSupport<VF-ITSupport@equitasbank.com>", "", "", "RPA Initiated for LEAD NO: " + ddlLeadNo.SelectedItem.Text + " " + txtBranchName.Text + " Branch", BodyTxt, "", true);


            /*   });

               threadSendMails.IsBackground = true;

               threadSendMails.Start();
               System.Threading.Thread.Sleep(5000);*/

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally { con.Close(); }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Age", con);
        cmddd.Parameters.AddWithValue("@KYC_Name", DDLkycName.SelectedIndex != 0 ? DDLkycName.SelectedItem.Text : "");
        cmddd.Parameters.AddWithValue("@KYC_LD_ID", ddlLeadNo.SelectedIndex != 0 ? ddlLeadNo.SelectedValue : "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();

        if (dsdd.Tables[0].Rows.Count > 0)
        {
            txtCustAge.Text = dsdd.Tables[0].Rows[0][0].ToString();
            TBAppType.Text = dsdd.Tables[0].Rows[0][1] != null ? dsdd.Tables[0].Rows[0][1].ToString() : "0";
        }
        if (DDLkycName.SelectedIndex == 0)
        {
            txtCustAge.Text = "";
        }
    }
    protected void txtSqft_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        DataTable dtDataG;
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_fetch_GLAP_datas", con);
        cmddd.Parameters.AddWithValue("@LreqAmt", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        dtDataG = dsdd.Tables[0];
        con.Close();

        double nSqrftVal = 0, nSqrftVal1 = 0;
        if (txtBuildUpArea.Text != "" && txtSqft.Text != "")
        {
            //nSqrftVal = Convert.ToDouble(txtBuildUpArea.Text) * Convert.ToDouble(lblSqrft.Text.Substring(2, lblSqrft.Text.IndexOf('/') - 2).Trim());
            if (ddlPropType.SelectedItem.Text != "--Select--" && ddlPropType.SelectedItem.Text == "Mangalore tiled roofing")
            {
                con.Open();
                SqlCommand cmddd1 = new SqlCommand("RTS_SP_FETCH_BVSQFT", con);

                cmddd1.Parameters.AddWithValue("@PT_DESC", ddlPropType.SelectedItem.Text);
                cmddd1.Parameters.AddWithValue("@PT_TYPE", "G");
                cmddd1.CommandType = CommandType.StoredProcedure;
                var sqft = cmddd1.ExecuteScalar();

                con.Close();

                nSqrftVal = Convert.ToDouble(txtBuildUpArea.Text) * Convert.ToDouble(sqft);
            }
            else
            {
                nSqrftVal = Convert.ToDouble(txtBuildUpArea.Text) * Convert.ToDouble(dtDataG.Rows[0][0]);
            }


            txtBuildingValue1.Text = nSqrftVal.ToString();
            double nsqft = txtSqft.Text != "" ? Convert.ToDouble(txtSqft.Text) : 0;
            nSqrftVal1 = Convert.ToDouble(txtBuildUpArea.Text) * Convert.ToDouble(nsqft);
            double nMinBArea = Math.Min(nSqrftVal, nSqrftVal1);
            // txtBuildingValue.Text = Convert.ToInt32(nMinBArea).ToString();
            txtBuildingValue.Text = nSqrftVal1.ToString();
        }
        ddlAgeOfBuilding.Focus();
    }
    protected void btnDraft_Click(object sender, EventArgs e)
    {
        InsertDraftCamLapValues("D");
    }
    protected void InsertDraftCamLapValues(string strType)
    {
        try
        {
            if (ddlLeadNo.SelectedItem.Text == "--Select--")
            {
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select Lead No ');", true);
            }
            else if (ddlRelationShip.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Relation ship", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlMainApplicant.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Main Source of Income", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlVintage.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Vintage", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlNature.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Nature OfBussiness/Job", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlIncomType.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Income Type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //else if (ddlLoanPurpose.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Loan Purpose", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else if (ddlCreditHistory.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Credit History", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            if (ddlNomineeName.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please select the nominee name", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
                if (ddlNomineeName.SelectedItem.Text == "Others" && string.IsNullOrWhiteSpace(txtNomineeName.Text))
            {
                uscMsgBox1.AddMessage("Please enter the nominee name", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
                    if (ddlNomineeName.SelectedItem.Text == "Others" && string.IsNullOrWhiteSpace(txtNomineeRelation.Text))
            {
                uscMsgBox1.AddMessage("Please enter the nominee relation", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
                        if (ddlNomineeName.SelectedItem.Text != "Others" && string.IsNullOrWhiteSpace(txtRelationShip.Text))
            {
                uscMsgBox1.AddMessage("Please enter the nominee relationship type", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
            {
                DataTable dtIncomeDetails = new DataTable();
                dtIncomeDetails = (DataTable)ViewState["CurrentTable"];
                if (dtIncomeDetails.Columns.Contains("INCOME_SOURCE"))
                {
                    dtIncomeDetails.Columns.Remove("INCOME_SOURCE");
                }
                if (dtIncomeDetails.Columns.Contains("RELATIONSHIP"))
                {
                    dtIncomeDetails.Columns.Remove("RELATIONSHIP");
                }
                if (dtIncomeDetails.Columns.Contains("APP_TYPE"))
                {
                    dtIncomeDetails.Columns.Remove("APP_TYPE");
                }
                DataTable dtObligation = new DataTable();
                dtObligation = BindObligationTable();

                DataTable dtColletral = new DataTable();
                dtColletral = BindCollateralTable();

                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertCAM_New", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@CAM_TYPE", "B");
                //cmdinsert.Parameters.AddWithValue("@CAM_PR_ID", "1");

                //cmdinsert.Parameters.AddWithValue("@CAM_BR_ID", txtBranchName.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LD_ID", ddlLeadNo.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_AP_ADD", txtAddress.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_ER_ID", ddlRelationShip.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_INS_ID", ddlMainApplicant.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_VN_ID", ddlVintage.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_NT_ID", ddlNature.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_IT_ID", ddlIncomType.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_PP_ID", ddlLoanPurpose.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_CH_ID", ddlCreditHistory.SelectedValue.ToString());

                cmdinsert.Parameters.AddWithValue("@CAM_AGL", txtAgriLandAcres.Text != "" ? Convert.ToDouble(txtAgriLandAcres.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_AGI", txtAgriIncome.Text != "" ? Convert.ToDouble(txtAgriIncome.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_IN", txtTotalLoanEligibility.Text != "" ? Convert.ToDouble(txtTotalLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_EMI", txtTotalEMIAmount.Text != "" ? Convert.ToDouble(txtTotalEMIAmount.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TENURE", ddlTenure.SelectedItem.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_INR", ddlIntrest.SelectedItem.Text != "--Select--" ? Convert.ToDouble(ddlIntrest.SelectedItem.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_EPL", txtEMIperLakh.Text != "" ? Convert.ToDouble(txtEMIperLakh.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_IRR", txtIIREligibility.Text != "" ? Convert.ToDouble(txtIIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_FOIR", txtFOIREligibility.Text != "" ? Convert.ToDouble(txtFOIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LAMT_REQ", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_ELG", txtLoanEligibility.Text != "" ? Convert.ToDouble(txtLoanEligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_HOBIG", txtbassumedobligation.Text != "" ? Convert.ToDouble(txtbassumedobligation.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_HLOAN", txtAssumdHLoan.Text != "" ? Convert.ToDouble(txtAssumdHLoan.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_PT_ID", ddlPropType.SelectedItem.Text.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_OC_ID", ddlOccupancyStatus.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_UG_ID", ddlUsage.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_NOT", txtNoOFtenents.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LAREA", txtLandArea.Text != "" ? Convert.ToDouble(txtLandArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_GLV", txtGuideline.Text != "" ? Convert.ToDouble(txtGuideline.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_MV", txtMarketValueSqrt.Text != "" ? Convert.ToDouble(txtMarketValueSqrt.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CLV", txtConsidered.Text != "" ? Convert.ToDouble(txtConsidered.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BAREA", txtBuildUpArea.Text != "" ? Convert.ToDouble(txtBuildUpArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_SQFT", txtSqft.Text != "" ? Convert.ToDouble(txtSqft.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BV", txtBuildingValue.Text != "" ? Convert.ToDouble(txtBuildingValue.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_AMENITIES", txtAmunity.Text != "" ? Convert.ToDouble(txtAmunity.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BA_ID", ddlAgeOfBuilding.SelectedItem.Text);
                //cmdinsert.Parameters.AddWithValue("@CAM_DEP", txtDepreciation.Text != "" ? Convert.ToDouble(txtDepreciation.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_DEP", 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CBV", txtonsideredBuilding.Text != "" ? Convert.ToDouble(txtonsideredBuilding.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_TPV", txtTotalPropertyValue.Text != "" ? Convert.ToDouble(txtTotalPropertyValue.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_LTV", txtLTVonProperty.Text != "" ? Convert.ToDouble(txtLTVonProperty.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_RLA", txtRecommendedLoan.Text != "" ? Convert.ToDouble(txtRecommendedLoan.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_EMP_ID", txtEmpCode.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_Deviation", txtDeviation.Text);

                cmdinsert.Parameters.AddWithValue("@CAM_PCS", txtNameofInsuredPerson.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_CBY", Session["ID"].ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_MBY", Session["ID"].ToString());


                cmdinsert.Parameters.AddWithValue("@tblIncome_Details", dtIncomeDetails);
                cmdinsert.Parameters.AddWithValue("@tblOBLIGATE", dtObligation);
                cmdinsert.Parameters.AddWithValue("@tblCOLLATERAL", dtColletral);
                cmdinsert.Parameters.AddWithValue("@CAM_NOMEE_NAME", ddlNomineeName.SelectedItem.Text != "Others" ? ddlNomineeName.SelectedItem.Text : ("Others-" + txtNomineeName.Text).ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_NOMEE_RELN", txtNomineeRelation.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_NOMEE_RELN_TYPE", txtRelationShip.Text);
                cmdinsert.Parameters.AddWithValue("@SAVETYPE", strType);
                int n = cmdinsert.ExecuteNonQuery();
                cmrs = n;
                if (n > 0)
                {


                    //if (strType == "S")
                    //{
                    //    if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "")
                    //    {
                    //        double dGuidline = 0.0;
                    //        if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                    //        {
                    //            dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                    //        }
                    //        else
                    //        {
                    //            dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                    //        }
                    //        //if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text) && RadioBtnGV_No.Checked)
                    //        //{
                    //        //    sendMail();
                    //        //}
                    //        if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text))
                    //        {
                    //            sendMail();
                    //        }
                    //    }
                    //}

                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Saved Successfully');window.location.reload()", true);
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Failed to Save');", true);
                }

                con.Close();
            }



        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void txtEmpCode_TextChanged(object sender, EventArgs e)
    {
        BindEMpDets();
    }
    protected void BindEMpDets()
    {

        if (txtEmpCode.Text.Length == 4)
        {
            txtEmpCode.Text = "0" + txtEmpCode.Text;
        }
        else if (txtEmpCode.Text.Length == 4)
        {
            txtEmpCode.Text = "00" + txtEmpCode.Text;
        }
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("SELECT * from HR_EMP_DETS  WHERE EMP_CODE='" + txtEmpCode.Text + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            txtEMpID.Text = dsdd.Tables[0].Rows[0]["EMP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_ID"].ToString() : "";
            txtEMpNAme.Text = dsdd.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
            txtDesgn.Text = dsdd.Tables[0].Rows[0]["EMP_DESIGN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_DESIGN"].ToString() : "";
            txtContact.Text = dsdd.Tables[0].Rows[0]["EMP_PHNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_PHNO"].ToString() : "";

            ttxEmailEmp.Text = dsdd.Tables[0].Rows[0]["EMP_EMAIL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_EMAIL"].ToString() : "";
            txtEmpCompany.Text = dsdd.Tables[0].Rows[0]["EMP_COMPANY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_COMPANY"].ToString() : "";
            txtDOJ.Text = dsdd.Tables[0].Rows[0]["EMP_DOJ"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_DOJ"].ToString() : "";
            txtGrade.Text = dsdd.Tables[0].Rows[0]["EMP_GRADE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_GRADE"].ToString() : "";
            txtEMpNAme.Enabled = false;
            txtDesgn.Enabled = false;
            txtContact.Enabled = false;
            ttxEmailEmp.Enabled = false;
            txtEmpCompany.Enabled = false;
            txtDOJ.Enabled = false;
            txtGrade.Enabled = false;
        }
        else
        {
            txtEMpID.Text = "";
            txtEMpNAme.Text = "";
            txtDesgn.Text = "";
            txtContact.Text = "";
            ttxEmailEmp.Text = "";
            txtEmpCompany.Text = "";
            txtDOJ.Text = "";
            txtGrade.Text = "";

            txtEMpNAme.Enabled = true;
            txtDesgn.Enabled = true;
            txtContact.Enabled = true;
            ttxEmailEmp.Enabled = true;
            txtEmpCompany.Enabled = true;
            txtDOJ.Enabled = true;
            txtGrade.Enabled = true;
        }
    }
    protected void txtLTVonProperty_TextChanged(object sender, EventArgs e)
    {

    }
    protected void ddlNomineeName_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlNomineeName.SelectedItem.Text != "--Select--" && ddlNomineeName.SelectedItem.Text != "Others")
            {
                txtNomineeRelation.Text = Convert.ToString(ddlNomineeName.SelectedValue);
                txtNomineeRelation.Enabled = false;
                tdNomineeName.Visible = false;
                tdNomineeName1.Visible = false;
                //bala changes
                tdRelationType.Visible = true;
                tdRelationType1.Visible = true;
                txtRelationShip.Text = "";

            }
            else
                if (ddlNomineeName.SelectedItem.Text == "Others")
            {
                txtNomineeRelation.Text = "";
                txtNomineeRelation.Enabled = true;
                tdNomineeName.Visible = true;
                tdNomineeName1.Visible = true;
                txtNomineeName.Enabled = true;
                //bala changes 05042018
                tdRelationType.Visible = false;
                tdRelationType1.Visible = false;
                txtRelationShip.Text = "";
            }
            else
            {
                txtNomineeRelation.Text = "";
                txtNomineeRelation.Enabled = false;
                tdNomineeName.Visible = false;
                tdNomineeName1.Visible = false;
                //bala changes 05042018
                tdRelationType.Visible = true;
                tdRelationType1.Visible = true;
                txtRelationShip.Text = "";
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}