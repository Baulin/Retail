﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;

public partial class CAMAMApprooval : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                BindLeadNo();
            }
        }
        else
          {
              Response.Redirect("Default.aspx");
          }
    }
    public void BindLeadNo()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_Lead_For_Sampling_Report", con);
        cmddd.Parameters.AddWithValue("@LD_NO", "");
        cmddd.Parameters.AddWithValue("@Lead_Type", "LAP");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLeadNo.DataSource = dsdd;
        ddlLeadNo.DataTextField = "LD_NO";
        ddlLeadNo.DataValueField = "LD_ID";
        ddlLeadNo.DataBind();
        ddlLeadNo.Items.Insert(0, "Select");
    }
    protected void ddlLeadNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlLeadNo.SelectedIndex > 0)
        {
            GenerateReport();
        }
    }
    public void GenerateReport()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAMSummary_Report", con);
        cmddd.Parameters.AddWithValue("@Lead_ID", ddlLeadNo.SelectedValue.ToString());
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);


        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            lblBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
            lblCustomerName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";

            lblNetIncomeafterfactoring.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";
            lblNetIncomeafterfactoring_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TOT_IN"].ToString() : "";
            if (lblNetIncomeafterfactoring.Text != "" && lblNetIncomeafterfactoring_CI.Text != "")
            {
                lblNetIncomeafterfactoring_Var.Text = Convert.ToString((Convert.ToDouble(lblNetIncomeafterfactoring_CI.Text) * 100) / Convert.ToDouble(lblNetIncomeafterfactoring.Text));
            }

            lblObligation.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";
            lblObligation_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TOT_EMI"].ToString() : "";

            if (lblObligation.Text != "" && lblObligation_CI.Text != "")
            {
                lblObligation_Var.Text = Convert.ToString((Convert.ToDouble(lblObligation_CI.Text) * 100) / Convert.ToDouble(lblObligation.Text));
            }

            lblLandSQFT.Text = dsdd.Tables[0].Rows[0]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAREA"].ToString() : "";
            lblLandSQFT_CI.Text = dsdd.Tables[0].Rows[1]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_LAREA"].ToString() : "";
            if (lblLandSQFT.Text != "" && lblLandSQFT_CI.Text != "")
            {
                lblLandSQFT_Var.Text = Convert.ToString((Convert.ToDouble(lblLandSQFT_CI.Text) * 100) / Convert.ToDouble(lblLandSQFT.Text));
            }

            lblReginet.Text = dsdd.Tables[0].Rows[0]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_GLV"].ToString() : "";
            lblReginet_CI.Text = dsdd.Tables[0].Rows[1]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_GLV"].ToString() : "";

            if (lblReginet.Text != "" && lblReginet_CI.Text != "")
            {
                lblReginet_Var.Text = Convert.ToString((Convert.ToDouble(lblReginet_CI.Text) * 100) / Convert.ToDouble(lblReginet.Text));
            }


            lblMarketvalue.Text = dsdd.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
            lblMarketvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_MV"].ToString() : "";
            if (lblMarketvalue.Text != "" && lblMarketvalue_CI.Text != "")
            {
                lblMarketvalue_Var.Text = Convert.ToString((Convert.ToDouble(lblMarketvalue_CI.Text) * 100) / Convert.ToDouble(lblMarketvalue.Text));
            }

            lblTotalLandvalue.Text = dsdd.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CLV"].ToString() : "";
            lblTotalLandvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_CLV"].ToString() : "";
            if (lblTotalLandvalue.Text != "" && lblTotalLandvalue_CI.Text != "")
            {
                lblTotalLandvalue_Var.Text = Convert.ToString((Convert.ToDouble(lblTotalLandvalue_CI.Text) * 100) / Convert.ToDouble(lblTotalLandvalue.Text));
            }

            lblBuildingType.Text = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "";
            lblBuildingType_CI.Text = dsdd.Tables[0].Rows[1]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["PT_DESC"].ToString() : "";


            lblAgeofbuilding.Text = dsdd.Tables[0].Rows[0]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BA_DESC"].ToString() : "";
            lblAgeofbuilding_CI.Text = dsdd.Tables[0].Rows[1]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["BA_DESC"].ToString() : "";
            if (lblAgeofbuilding.Text != "" && lblAgeofbuilding_CI.Text != "")
            {
                lblAgeofbuilding_Var.Text = Convert.ToString((Convert.ToDouble(lblAgeofbuilding_CI.Text) * 100) / Convert.ToDouble(lblAgeofbuilding.Text));
            }

            lblBuildingValue.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
            lblBuildingValue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_CBV"].ToString() : "";
            if (lblBuildingValue.Text != "" && lblBuildingValue_CI.Text != "")
            {
                lblBuildingValue_Var.Text = Convert.ToString((Convert.ToDouble(lblBuildingValue_CI.Text) * 100) / Convert.ToDouble(lblBuildingValue.Text));
            }

            lblTotalpropertyvalue.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
            lblTotalpropertyvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TPV"].ToString() : "";
            if (lblTotalpropertyvalue.Text != "" && lblTotalpropertyvalue_CI.Text != "")
            {
                lblTotalpropertyvalue_Var.Text = Convert.ToString((Convert.ToDouble(lblTotalpropertyvalue_CI.Text) * 100) / Convert.ToDouble(lblTotalpropertyvalue.Text));
            }

            lblLoanamountrecommeded.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
            lblLoanamountrecommeded_CR.Text = dsdd.Tables[0].Rows[1]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_RLA"].ToString() : "";
            if (lblLoanamountrecommeded.Text != "" && lblLoanamountrecommeded_CR.Text != "")
            {
                lblLoanamountrecommeded_Var.Text = Convert.ToString((Convert.ToDouble(lblLoanamountrecommeded_CR.Text) * 100) / Convert.ToDouble(lblLoanamountrecommeded.Text));
            }
        }
    }
    protected void ddlApproove_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlApproove.SelectedValue == "2")
        {
            trResult.Visible = true;
        }
        else
        {
            trResult.Visible = false;

        }
    }
    protected void rdnSpot_CheckedChanged(object sender, EventArgs e)
    {
        trSPot.Visible = true;
    }
    protected void rdnPDD_CheckedChanged(object sender, EventArgs e)
    {
        trSPot.Visible = false;
        trBussEmpRelt.Visible = false;
        trIncomeTol.Visible = false;
        trPropRel.Visible = false;
        trVerRel.Visible = false;
    }
    protected void rdnBussEmpRelated_CheckedChanged(object sender, EventArgs e)
    {
        trBussEmpRelt.Visible = true;
        trIncomeTol.Visible = false;
        trPropRel.Visible = false;
        trVerRel.Visible = false;
    }
    protected void rdnIncomeRelated_CheckedChanged(object sender, EventArgs e)
    {
        trBussEmpRelt.Visible = false;
        trIncomeTol.Visible = true;
        trPropRel.Visible = false;
        trVerRel.Visible = false;
    }
    protected void rdnPropRelated_CheckedChanged(object sender, EventArgs e)
    {
        trBussEmpRelt.Visible = false;
        trIncomeTol.Visible = false;
        trPropRel.Visible = true;
        trVerRel.Visible = false;
    }
    protected void rdnVerRelated_CheckedChanged(object sender, EventArgs e)
    {
        trBussEmpRelt.Visible = false;
        trIncomeTol.Visible = false;
        trPropRel.Visible = false;
        trVerRel.Visible = true;
    }
}