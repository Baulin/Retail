﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_Lawyer : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
      
        if (!IsPostBack)
        {

            bindArea();
            getMaxLawCode();
            bindLawyerGrid();
        }
    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));


    }
    public void getMaxLawCode()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmd = new SqlCommand("Select top 1 LR_ID from MR_LAWYER  Order By LR_ID DESC", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        string strLawyerCode = "";
        if (ds.Tables[0].Rows.Count > 0)
        {
            int nVal = Convert.ToInt32(ds.Tables[0].Rows[0]["LR_ID"]) + 1;
            strLawyerCode =nVal.ToString();
            //strLawyerCode = strLawyerCode.Substring(2, strLawyerCode.Length - 2);
            //int nCode = Convert.ToInt32(strLawyerCode) + 1;
            strLawyerCode = "EL" + strLawyerCode.PadLeft(4,'0');
            //strLawyerCode = "EL" +strLawyerCode.Substring(0,strLawyerCode.Length-1)+ nCode.ToString().PadLeft("0000");
        }
        else
        {
            strLawyerCode = "EL0001";
        }
        txtLawyercode.Text = strLawyerCode;
    }
    public void bindLawyerGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmd = new SqlCommand("RTS_Fetch_MR_Lawyer", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@LawyerID", "");
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvlawyer.DataSource = ds;
        gvlawyer.DataBind();
        if (gvlawyer.Rows.Count > 0)
        {
            gvlawyer.HeaderRow.Font.Bold = true;
            gvlawyer.HeaderRow.Cells[0].Text = "Lawyer Code";
            gvlawyer.HeaderRow.Cells[1].Text = "Lawyer Name";           
            gvlawyer.HeaderRow.Cells[2].Text = "Area";
            gvlawyer.HeaderRow.Cells[3].Text = "Contact No";
            gvlawyer.HeaderRow.Cells[4].Text = "Pre Opinion Fee";
            gvlawyer.HeaderRow.Cells[5].Text = "Final Opinion Fee";

            gvlawyer.HeaderRow.Cells[0].Wrap = false;
            gvlawyer.HeaderRow.Cells[1].Wrap = false;
            gvlawyer.HeaderRow.Cells[2].Wrap = false;
            gvlawyer.HeaderRow.Cells[3].Wrap = false;
            gvlawyer.HeaderRow.Cells[4].Wrap = false;
            gvlawyer.HeaderRow.Cells[5].Wrap = false;
      
        }
    }
    
  
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            if (ddlArea.SelectedIndex > 0)
            {
                SqlCommand insertcmd = new SqlCommand("RTS_SP_InsertUpdate_MR_Lawyer", con);
                insertcmd.CommandType = CommandType.StoredProcedure;
                insertcmd.Parameters.AddWithValue("@LawyerCode", txtLawyercode.Text);
                insertcmd.Parameters.AddWithValue("@LawyerName", txtLawyername.Text);
                insertcmd.Parameters.AddWithValue("@Address1", txtAddr1.Text);
                insertcmd.Parameters.AddWithValue("@Address2", txtAddr2.Text);
                insertcmd.Parameters.AddWithValue("@Pincode", txtPinCode.Text);
                insertcmd.Parameters.AddWithValue("@Area", ddlArea.SelectedValue.ToString());
                insertcmd.Parameters.AddWithValue("@ContactNo", txtContactno.Text);
                insertcmd.Parameters.AddWithValue("@EmailID", txtEmailid.Text);
                insertcmd.Parameters.AddWithValue("@PrimaryFee", txtPrimaryFee.Text);
                insertcmd.Parameters.AddWithValue("@FinalFee", txtFinalFee.Text);
                insertcmd.Parameters.AddWithValue("@CBY", Session["ID"].ToString());
                insertcmd.Parameters.AddWithValue("@MBY", Session["ID"].ToString());
   
                int n= insertcmd.ExecuteNonQuery();
                if (n > 0)
                {
                    bindLawyerGrid();
                    getMaxLawCode();
                    txtLawyercode.Text = "";
                    txtLawyername.Text = "";
                    txtAddr1.Text = "";
                    txtAddr2.Text = "";
                    ddlArea.SelectedIndex = 0;
                    txtPinCode.Text = "";
                    txtPrimaryFee.Text = "";
                    txtContactno.Text = "";
                    txtFinalFee.Text = "";
                    txtEmailid.Text = "";
                    //ddlState.Text = "--Select--";

                    uscMsgBox1.AddMessage("Lawyer Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
                else
                {
                    uscMsgBox1.AddMessage("lawyer Name Already Exsist !", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
                    
                
                lblErr.Visible = false;
               
               
            }
            else
            {
                lblErr.Visible = true;
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    protected void gvlawyer_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Right;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Right;
        }
    }
}