﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using System.Text;
using Tracker;

public partial class Master_FIRCU : System.Web.UI.Page
{
    int usrid;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    public static bool blMailStatus = false;
    public static string frmID = "", toID = "", bccID = "", ccID = "", strMailBody = "";
    public string EMPNAME, CODE, PWD, MAILID;
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();

    Thread mail;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {


                bind();
               

                //bindUserAcs();
            }
        }
        else
        {
            Response.Redirect("Expire.aspx", false);
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT FIRCU_ID, FIRCU_NAME,FIRCU_EMAIL,FIRCU_CON_NO,FIRCU_ADDR,FIRCU_PAN,CASE WHEN FIRCU_STAT=1 THEN 'ACTIVE' WHEN FIRCU_STAT=0 THEN 'INACTIVE' END 'STATUS',FIRCU_STAT FROM MR_FIRCU ", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvUser.DataSource = ds;
        gvUser.DataBind();
       /* if (gvUser.Rows.Count > 0)
        {
            gvUser.HeaderRow.Font.Bold = true;
            gvUser.HeaderRow.Cells[0].Text = "EDIT";
            gvUser.HeaderRow.Cells[1].Text = "USER CODE";
            gvUser.HeaderRow.Cells[2].Text = "USER NAME";
            gvUser.HeaderRow.Cells[3].Text = "USER TYPE";
            gvUser.HeaderRow.Cells[4].Text = "STATUS";
            gvUser.HeaderRow.Cells[0].Wrap = false;
            gvUser.HeaderRow.Cells[1].Wrap = false;
            gvUser.HeaderRow.Cells[2].Wrap = false;
            gvUser.HeaderRow.Cells[3].Wrap = false;
            gvUser.HeaderRow.Cells[4].Wrap = false;
        }*/
    }
    
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Right;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {

            con.Open();
            if (btnSubmit.Text == "Submit")
            {
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_MR_FIRCU", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@FIRCU_NAME", txtUsername.Text);
                cmdinsert.Parameters.AddWithValue("@FIRCU_EMAIL", txtEmail.Text);
                cmdinsert.Parameters.AddWithValue("@FIRCU_CON_NO", txtContactNo.Text);
                cmdinsert.Parameters.AddWithValue("@FIRCU_ADDR",txtAddress.Text);
                cmdinsert.Parameters.AddWithValue("@FIRCU_PAN", txtPANNo.Text);               
                cmdinsert.Parameters.AddWithValue("@FIRCU_STAT", ddlStatus.SelectedValue);
                cmdinsert.Parameters.AddWithValue("@FIRCU_CBY", Convert.ToInt32(Session["ID"]));
                cmdinsert.Parameters.AddWithValue("@FIRCU_CDATE", DateTime.Now);
                cmdinsert.Parameters.AddWithValue("@TYPE", "MR_INSERT");
               // cmdinsert.Parameters.AddWithValue("@MFC_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmdinsert.ExecuteNonQuery();
               // int MFC_ID = Convert.ToInt32(cmdinsert.Parameters["@MFC_ID"].Value);

                // uscMsgBox1.AddMessage("Branch Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('FI-RCU Details has been Saved Successfully.');window.location.reload()", true);

            }
            else
                if (btnSubmit.Text == "Update")
                {
                    int fircu_id = Convert.ToInt32(Session["FIRCU_ID"]);
                    SqlCommand cmdinsert = new SqlCommand("RTS_SP_MR_FIRCU", con);
                    cmdinsert.CommandType = CommandType.StoredProcedure;

                    cmdinsert.Parameters.AddWithValue("@FIRCU_NAME", txtUsername.Text);
                    cmdinsert.Parameters.AddWithValue("@FIRCU_EMAIL", txtEmail.Text);
                    cmdinsert.Parameters.AddWithValue("@FIRCU_CON_NO", txtContactNo.Text);
                    cmdinsert.Parameters.AddWithValue("@FIRCU_ADDR", txtAddress.Text);
                    cmdinsert.Parameters.AddWithValue("@FIRCU_PAN", txtPANNo.Text);
                    cmdinsert.Parameters.AddWithValue("@FIRCU_STAT", ddlStatus.SelectedValue);
                    cmdinsert.Parameters.AddWithValue("@FIRCU_MBY", Convert.ToInt32(Session["ID"]));
                    cmdinsert.Parameters.AddWithValue("@FIRCU_MDATE", DateTime.Now);
                    cmdinsert.Parameters.AddWithValue("@TYPE", "MR_UPDATE");
                    cmdinsert.Parameters.AddWithValue("@FIRCU_ID", fircu_id);
                    //cmdinsert.Parameters.AddWithValue("@MFC_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
                    cmdinsert.ExecuteNonQuery();
                    // int MFC_ID = Convert.ToInt32(cmdinsert.Parameters["@MFC_ID"].Value);

                    // uscMsgBox1.AddMessage("Branch Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('FI-RCU Details has been updated successfully.');window.location.reload()", true);

                }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_FIRCU.aspx");
    }
   
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow grow in gvUser.Rows)
            {
                RadioButton chkUserID = (RadioButton)grow.FindControl("rb_select");
                if (chkUserID.Checked)
                {
                    //txtUsercode.Text = grow.Cells[1].Text;
                    //  txtUsercode.Enabled = false;
                    //txtUsername.Text = grow.Cells[2].Text;
                    //  ddlUsertype.SelectedItem.Text = grow.Cells[3].Text;
                    if (grow.Cells[4].Text == "ACTIVE")
                    {
                        ddlStatus.SelectedValue = "1";
                    }
                    else
                    {

                        ddlStatus.SelectedValue = "0";
                    }
                    Label lblFIRCU_NAME = (Label)grow.FindControl("lblFIRCU_NAME");
                    Label lblUSRID = (Label)grow.FindControl("lblUSRID");
                    Label lblFIRCU_EMAIL = (Label)grow.FindControl("lblFIRCU_EMAIL");
                    Label lblFIRCU_CON_NO = (Label)grow.FindControl("lblFIRCU_CON_NO");
                    Label lblFIRCU_ADDR = (Label)grow.FindControl("lblFIRCU_ADDR");
                    Label lblFIRCU_PAN = (Label)grow.FindControl("lblFIRCU_PAN");
                    // Label lblFIRCU_STAT = (Label)grow.FindControl("lblFIRCU_STAT");
                    txtUsername.Text = lblFIRCU_NAME.Text;
                    txtEmail.Text = lblFIRCU_EMAIL.Text;
                    txtContactNo.Text = lblFIRCU_CON_NO.Text;
                    txtAddress.Text = lblFIRCU_ADDR.Text;
                    txtPANNo.Text = lblFIRCU_PAN.Text;


                    // ddlmodule.SelectedValue = lbl_usr_type.Text.Trim() != "" ? lbl_usr_type.Text.Trim() : "R";
                    // ddlUsertype.SelectedValue = lblUsrTypeID.Text;
                    //txtPwd.Enabled = false;
                    //txtPwddays.Text = lblPwdExp.Text;
                    // txtPwd.Text = lblUSRPwd.Text;
                    //txtPwd.TextMode = TextBoxMode.Password;
                    RequiredFieldValidator3.Enabled = false;
                    // txtPwddays.Enabled = false;

                    Label lblFIRCU_STAT = (Label)grow.FindControl("lblFIRCU_STAT");
                    if (lblFIRCU_STAT.Text == "False")
                    {
                        ddlStatus.SelectedValue = "0";
                    }
                    else
                    {
                        ddlStatus.SelectedValue = "1";
                    }



                    btnSubmit.Text = "Update";
                    Session["FIRCU_ID"] = lblUSRID.Text;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
 

}