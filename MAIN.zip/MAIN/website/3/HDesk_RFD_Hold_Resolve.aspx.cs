﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Tracker;
using Utilities;

public partial class HDesk_RFD_Hold_Resolve : System.Web.UI.Page
{
    int ldid;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string bcc3;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    public static DataTable dtQuery = null;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    public static bool blMailStatus = false;
   protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
                rmk.Visible = false;
            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("select AR_NAME,AR_ID from MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        //SqlCommand cmdquery = new SqlCommand("select QY_QUERY from MR_QUERY", con);
        //SqlDataAdapter daquery = new SqlDataAdapter(cmdquery);
        //DataSet dsquery = new DataSet();
        //daquery.Fill(dsquery);        
        //con.Close();

        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));




    }
    protected void cb_select_CheckedChanged(object sender, EventArgs e)
    {
        //foreach (GridViewRow grow in gvQuerydets.Rows)
        //{
        //    CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
        //    int index = grow.RowIndex;
        //    if (chkStat.Checked)
        //    {
        //        CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
        //        chkStat1.Enabled = true;

        //    }
        //    else
        //    {
        //        CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
        //        int index1 = grow.RowIndex;
        //        foreach (ListItem i in chkStat1.Items)
        //        {
        //            i.Selected = false;
        //        }
        //        chkStat1.Enabled = false;
        //    }
        //}
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        lbLeadno.Text = "";
        lbAppname.Text = "";
        lbPDdate.Text = "";
        lbLoanamt.Text = "";

        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "A";
            gridbind();
        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            ddlArea.Enabled = false;
            gridbind();
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";
            gridbind();
        }
        else if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select Area and Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (ddlBranch.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please Select Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txtLeadno.Text == "")
        {
            uscMsgBox1.AddMessage("Please Enter Lead No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }

        foreach (GridViewRow grow in gvQuery.Rows)
        {
            Label lblQryResult = (Label)grow.FindControl("lblQryResult");
            int index = grow.RowIndex;
            if (lblQryResult.Text == "T")
            {
                gvQuery.Rows[index].Cells[1].ForeColor = Color.Red;
                gvQuery.Rows[index].Cells[2].ForeColor = Color.Red;
                gvQuery.Rows[index].Cells[3].ForeColor = Color.Red;
                gvQuery.Rows[index].Cells[4].ForeColor = Color.Red;
                gvQuery.Rows[index].Cells[5].ForeColor = Color.Red;
            }

        }
    }
    public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_CRAP_AMT 'LOAN AMOUNT',case  when (select COUNT(*)  from LSD_DISB_QUERY where QRY_LD_ID=LD_ID  and E.QRY_RSD_BY ='H') > 0 then 'T' else 'F'  end as QueryResult,MP.PR_CODE,LD_SANTD_NO  from LSD_LEAD A LEFT JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_DISB_QUERY E ON A.LD_ID=E.QRY_LD_ID  LEFT JOIN MR_PRODUCT MP ON A.LD_PR_ID =MP.PR_ID  WHERE isnull(LD_SANTD_DATE,'')='' AND FT_SENTBY='D' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' ORDER BY LD_NO", con);
            //SqlCommand cmd = new SqlCommand("select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE isnull(LD_SANTD_DATE,'')='' AND FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' ORDER BY LD_NO", con);
            //SqlCommand cmd = new SqlCommand("select distinct LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_QUERY E ON A.LD_ID=E.QRY_LD_ID WHERE FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND isnull(LD_CRAP_MBY,'')='' AND ISNULL(LD_LC_DATE,'')=''", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "SANCTION NO";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            // SqlCommand cmd = new SqlCommand(" select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT',case  when (select COUNT(*)  from LSD_DISB_QUERY where QRY_LD_ID=LD_ID  and E.QRY_RSD_BY ='H') > 0 then 'T' else 'F'  end as QueryResult,MP.PR_CODE  from LSD_LEAD A LEFT JOIN LSD_DISB_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_DISB_QUERY E ON A.LD_ID=E.QRY_LD_ID   LEFT JOIN MR_PRODUCT MP ON A.LD_PR_ID =MP.PR_ID   WHERE FT_SENTBY='D' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND LD_NO='" + txtLeadno.Text + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' OR FT_SENTBY='D' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND AR_NAME='" + ddlArea.SelectedValue.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedValue.ToString() + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' ORDER BY LD_NO ", con);
            SqlCommand cmd = new SqlCommand("RTS_SP_RFD_HOLD", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LEADNO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@BRANCHID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue : "");
            cmd.Parameters.AddWithValue("@AREAID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue : "");
            cmd.Parameters.AddWithValue("@TYPE", "GET_DATA");
            cmd.Parameters.AddWithValue("@TRANS", "HDESK_RES");

            //SqlCommand cmd = new SqlCommand(" select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND LD_NO='" + txtLeadno.Text + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' OR FT_SENTBY='C' AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND AR_NAME='" + ddlArea.SelectedValue.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedValue.ToString() + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' ORDER BY LD_NO ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "SANCTION NO";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            con.Open();
            var ddl = (CheckBoxList)e.Row.FindControl("ddlCity");
            string CountryId = e.Row.Cells[1].Text.ToString();
            SqlCommand cmd = new SqlCommand("select QY_QUERY,QY_SQUERY from MR_DISB_QUERY  where QY_QUERY='" + CountryId + "' ORDER BY QY_QUERY,QY_SQUERY ASC", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            ddl.DataSource = ds;
            ddl.DataTextField = "QY_SQUERY";
            ddl.DataValueField = "QY_QUERY";
            ddl.DataBind();
            //ddl.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }
    protected void gvUserInfo_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);

        // GridView dgQuery = gvQuerydets;
        //dgQuery.Visible = false;

       
        foreach (GridViewRow grow in gvQuery.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            Label lnbtn = grow.FindControl("lnkname") as Label;
            Label lblProdCode = grow.FindControl("lblProdCode") as Label;
            Label lblHold_ID = grow.FindControl("lblHold_ID") as Label;
            Label lblHold_RFD_RMKS = grow.FindControl("lblHold_RFD_RMKS") as Label;
            Label lblBR_RFD_RMKS = grow.FindControl("lblBR_RFD_RMKS") as Label;
            //DropDownList ddrsp = grow.FindControl("Editdd") as DropDownList;
            int index = grow.RowIndex;
            Label lbllegl = grow.FindControl("lbllgl") as Label;


            if (chkStat.Checked)
            {

                if (lbllegl.Text == "F")
                {
                    uscMsgBox1.AddMessage("Lead No." + lnbtn.Text + " is not legally approved...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                rmk.Visible = true;
                leadno = lnbtn.Text;
                appname = gvQuery.Rows[index].Cells[3].Text;
                pddt = gvQuery.Rows[index].Cells[4].Text;
                lnamt = gvQuery.Rows[index].Cells[5].Text;
                Session["PCODE"] = lblProdCode.Text;
                Session["HOLD_ID"] = lblHold_ID.Text;
                txtRFDHoldRMKS.Text = lblHold_RFD_RMKS.Text;
                txtBRResponse.Text = lblBR_RFD_RMKS.Text;
                Tr1.Visible = true;
                Tr2.Visible = true;
            }

        }
        Session["Leadno"] = leadno;

        getLeadID(con);

        //gvQuerydets.Visible = true;
        //qrydetsbind();
        lbLeadno.Visible = true;
        lbAppname.Visible = true;
        lbPDdate.Visible = true;
        lbLoanamt.Visible = true;
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;


        lbLeadno.Text = leadno;
        lbAppname.Text = appname;
        lbPDdate.Text = pddt;
        lbLoanamt.Text = lnamt;
        con.Close();
    }
    public void getLeadID(SqlConnection con)
    {
        SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
        cmdbr.CommandType = CommandType.StoredProcedure;
        cmdbr.Parameters.AddWithValue("@LeadNo", Session["Leadno"].ToString());
        SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        DataSet dsbr = new DataSet();
        dabr.Fill(dsbr);
        Session["LeadId"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
    }
    public void qrydetsbind()
    {

        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        GridView gvQuery = null;
        // gvQuery = gvQuerydets;
        //  int  qryldid = Session["LeadId"] !=null? Convert.ToInt32(Session["LeadId"]):0;

        SqlCommand cmdqry = new SqlCommand("SELECT DISTINCT * FROM MR_DISB_CONDITION", con);
        SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
        DataSet dsqry = new DataSet();
        daqry.Fill(dsqry);
        if (dsqry.Tables[0].Rows.Count > 0)
        {
            gvQuery.DataSource = dsqry.Tables[0];
            gvQuery.DataBind();
            gvQuery.Visible = true;
        }
        else
        {
            uscMsgBox1.AddMessage("No Record Found !", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        con.Close();



    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('HOOps_QCQuery_Popup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {


        if (txtbxrfdrmks.Text.Trim() != "")
        {


            try
            {

                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                //RTS_SP_UPDATE_RFD_HOLD_RMKS

                /* SqlCommand cmdbr1 = new SqlCommand("RTS_SP_UPDATE_RFD_HOLD_RMKS", con);
                 cmdbr1.CommandType = CommandType.StoredProcedure;
                 cmdbr1.Parameters.AddWithValue("@LD_ID", Session["LeadId"].ToString());
                 cmdbr1.Parameters.AddWithValue("@LD_RDY_RMKS_MBY", Session["ID"].ToString());
                 cmdbr1.Parameters.AddWithValue("@LD_RDY_RMKS", txtbxrfdrmks.Text.Replace("'", "''").ToString());

                 int n = cmdbr1.ExecuteNonQuery();
                 */
                SqlCommand cmdbr2 = new SqlCommand("RTS_SP_RFD_HOLD", con);
                cmdbr2.CommandType = CommandType.StoredProcedure;
                cmdbr2.Parameters.AddWithValue("@HLD_ID", Session["HOLD_ID"].ToString());
                cmdbr2.Parameters.AddWithValue("@HLD_HDK_BY", Session["ID"].ToString());
                cmdbr2.Parameters.AddWithValue("@HLD_HDK_RMKS", txtbxrfdrmks.Text.Replace("'", "''").ToString());
                cmdbr2.Parameters.AddWithValue("@TYPE", "HDESK_UPT");

                int n1 = cmdbr2.ExecuteNonQuery();
                if (n1 > 0)
                {
                    gridbind();
                    foreach (GridViewRow grow in gvQuery.Rows)
                    {
                        Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                        int index = grow.RowIndex;
                        if (lblQryResult.Text == "T")
                        {
                            gvQuery.Rows[index].Cells[1].ForeColor = Color.Red;
                            gvQuery.Rows[index].Cells[2].ForeColor = Color.Red;
                            gvQuery.Rows[index].Cells[3].ForeColor = Color.Red;
                            gvQuery.Rows[index].Cells[4].ForeColor = Color.Red;
                            gvQuery.Rows[index].Cells[5].ForeColor = Color.Red;
                        }
                    }
                    lbLeadno.Text = "";
                    lbAppname.Text = "";
                    lbPDdate.Text = "";
                    lbLoanamt.Text = "";

                    btnSubmit.Enabled = false;
                    // sendMail(con);
                    string strMailStatus = "";
                    string strSuccessMsg = "";
                    if (blMailStatus == true)
                    {
                        strMailStatus = "Successfully";
                    }
                    else
                    {
                        strMailStatus = "Failed";
                    }
                    //strSuccessMsg = Session["Leadno"].ToString() + " - " + " <br/> Mail Sent " + strMailStatus + "  ";
                    //strSuccessMsg += "<br/> Mail To: " + toID + " ; CC To: " + ccID + " ";
                    uscMsgBox1.AddMessage("Helpdesk RFD Hold has been resolved successfully  <br/>" + strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    Tr1.Visible = false;
                    rmk.Visible = false;
                    Tr2.Visible = false;

                }
                else
                {
                    uscMsgBox1.AddMessage("Branch RFD Hold Response not resolved", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
            }

            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            finally
            {
                //con.Close();
            }
        }
        else
        {
            uscMsgBox1.AddMessage("please enter the remarks", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("BR_RFD_Hold_Response.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME,BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Enabled = false;
    }
    protected void ddlQuery_SelectedIndexChanged(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(strcon);
        //con.Open();
        //ddlSubquery.Enabled = true;
        //SqlCommand cmdsquery = new SqlCommand("select QY_SQUERY from MR_QUERY where QY_QUERY='" + ddlQuery.SelectedValue.ToString() + "'", con);
        //SqlDataAdapter dasquery = new SqlDataAdapter(cmdsquery);
        //DataSet dssquery = new DataSet();
        //dasquery.Fill(dssquery);
        //con.Close();

        //ddlSubquery.DataSource = dssquery;
        //ddlSubquery.DataTextField = "QY_SQUERY";
        //ddlSubquery.DataValueField = "QY_SQUERY";
        //ddlSubquery.DataBind();
        //ddlSubquery.Items.Insert(0, new ListItem("--Select--", "0"));

    }
    public void InsertHORaiseQuery()
    {
        GridView dgQuery = null;
        int selectedcnt = 0;
        // dgQuery = gvQuerydets;


        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        try
        {

            dtQuery = new DataTable();
            DataRow dr = null;
            dtQuery.Columns.Add(new DataColumn("Condition", typeof(string)));

            foreach (GridViewRow grow in dgQuery.Rows)
            {

                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                Label lblname = grow.FindControl("lblname") as Label;
                TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
                int index = grow.RowIndex;

                if (chkStat.Checked)
                {

                    SqlCommand cmdbr1 = new SqlCommand("RTS_PR_Insert_ReadyForDisb", con);
                    cmdbr1.CommandType = CommandType.StoredProcedure;
                    cmdbr1.Parameters.AddWithValue("@LEAD_ID", Session["LeadId"].ToString());
                    cmdbr1.Parameters.AddWithValue("@QRY_QUERY", "Ready For Disbursement");
                    cmdbr1.Parameters.AddWithValue("@QRY_SQUERY", lblname.Text);
                    cmdbr1.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                    int n = cmdbr1.ExecuteNonQuery();

                    dr = dtQuery.NewRow();
                    dr["Condition"] = lblname.Text;
                    dtQuery.Rows.Add(dr);
                    //if (n <= 0)
                    //{
                    //    uscMsgBox1.AddMessage("Query already Raised for that Lead ID =" + Session["LeadId"].ToString() + "", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    //}
                    //else
                    //{
                    //    selectedcnt = selectedcnt + 1;
                    //}

                }
                else
                {
                    SqlCommand cmdbr1 = new SqlCommand("RTS_PR_Insert_ReadyForDisb", con);
                    cmdbr1.CommandType = CommandType.StoredProcedure;
                    cmdbr1.Parameters.AddWithValue("@LEAD_ID", Session["LeadId"].ToString());
                    cmdbr1.Parameters.AddWithValue("@QRY_QUERY", "Ready For Disbursement");
                    cmdbr1.Parameters.AddWithValue("@QRY_SQUERY", "");
                    cmdbr1.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                    int n = cmdbr1.ExecuteNonQuery();
                }

            }



            string strMailStatus = "";
            string strSuccessMsg = "";
            if (blMailStatus == true)
            {
                strMailStatus = "Successfully";
            }
            else
            {
                strMailStatus = "Failed";
            }
            strSuccessMsg = Session["Leadno"].ToString() + " - " + " <br/> Mail Sent " + strMailStatus + "  ";
            strSuccessMsg += "<br/> Mail To: " + toID + " ; CC To: " + ccID + " ";
            uscMsgBox1.AddMessage(strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }



        // gvResolve.Visible = false;


    }
    public void sendMail(SqlConnection con)
    {
        try
        {
            /////// mail ///////////
            //  strMailDetail = "";

            SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "'", con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);



            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["LD_BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["LD_BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT EM_BM,EM_AM,EM_CM,EM_BCC,EM_HO,EM_CLM FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                //CHANGES ON 24-09-2015 MAIL CHANGES
                to = dsmailto.Tables[0].Rows[0]["EM_BM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_CLM"].ToString() : "";
                cc = dsmailto.Tables[0].Rows[0]["EM_AM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() : "" + ";" + dsmailto.Tables[0].Rows[0]["EM_CM"] != null ? dsmailto.Tables[0].Rows[0]["EM_CM"].ToString() : "" + ";" + dsmailto.Tables[0].Rows[0]["EM_HO"] != null ? dsmailto.Tables[0].Rows[0]["EM_HO"].ToString() : "";
                bcc = "";// dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString() : "";
                bcc3 = dsmailto.Tables[0].Rows[0]["EM_CLM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_CLM"].ToString() : "";
            }

            //if (cc != "")
            //{
            //    cc = cc + ";retail-helpdesk@equitasbank.com;valanK@equitasbank.com;BalachandiranS@equitasbank.com;manikandane@equitasbank.com;shankarpl@equitasbank.com";
            //}
            //else
            //{
            //    cc = "retail-helpdesk@equitasbank.com;valanK@equitasbank.com;BalachandiranS@equitasbank.com;manikandane@equitasbank.com";
            //}
            if (bcc3 != "")
            {
                cc = cc + ";" + bcc3;
            }

            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            // to = "ManimaranK@equitasbank.com";
            // bcc2 = "ManimaranK@equitasbank.com";
            // cc = "PalanikumarA@equitasbank.com";
            fromID = "RTS Alerts";
            toID = to;
            //  to = "ManimaranK@equitasbank.com";
            bcc2ID = bcc2;
            ccID = cc;

            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear All ,<br/>The captioned file is “Put on Hold after marking RFD” due to following Reason. <br/> ";
                //BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td>";
                //BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + dsdet.Tables[0].Rows[0]["LD_APNAME"].ToString() + "</strong></td></tr>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + "</strong></td>";
                //BodyTxt = BodyTxt + "<td>Loan Amount</td><td><strong>" + Session["Loanamt"] + "</strong></td></tr></table><br/><br/>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Address </td><td align='center'>:</td><td><strong>" + cusaddr + "</strong></td></tr>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Mobile No.</td><td align='center'>:</td><td><strong>" + mobile + "</strong></td></tr></table><br/><br/>";
                int b = 1;
                if (b != 0)
                {
                    BodyTxt = BodyTxt + " Please check and revert at the earliest <br/><br/>";
                    BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='center'  width='10%'>Sl. No.</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Credit Query Details</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Query Date</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Response</td>";
                    //BodyTxt = BodyTxt + "<td  align='center'>Response Date</td>";

                    BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' width='40%'>RFD HOLD Remarks</td>";

                    for (int j = 0; j <= b - 1; j++)
                    {
                        int sno = j + 1;
                        BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td bgcolor='#FFFFFF' align='right'> " + sno + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Query Raised"].ToString() + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Date"].ToString() + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response"].ToString() + "</td>";
                        //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response Date"].ToString() + "</td>";

                        BodyTxt = BodyTxt + "<td bgcolor='#FFFFFF'> " + txtbxrfdrmks.Text + "</td></span></tr>";
                    }
                    BodyTxt = BodyTxt + "</table>";
                }

                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>Retail Ops - QC Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
                //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

                blMailStatus = EmailManager.sendemail(to, "RTS Alerts", bcc2, cc, "PRDD STATUS - RFD HOLD  - " + Session["Leadno"].ToString() + " -  " + dsdet.Tables[0].Rows[0]["LD_APNAME"].ToString() + " -  " + dsdet.Tables[0].Rows[0]["AR_NAME"].ToString() + " -  " + dsdet.Tables[0].Rows[0]["BR_NAME"].ToString() + "", BodyTxt, "", true);
                //sendemail("SurendharR@equitasbank.com;PrabhakaranA@equitasbank.com;Tamilalagand@equitasbank.com", "surendharr@equitasbank.com", "Test", BodyTxt, "", true);

                //strMailBody = BodyTxt.Replace("<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Credit " + ddlApprv.SelectedItem.ToString() + "<br/><br/>", "");
                //strMailBody = BodyTxt.Replace("</html>", " ");


            //});
            //// strMailDetail = to + "," + bcc2 + "," + cc;
            //threadSendMails.IsBackground = true;

            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(5000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }

    }
}