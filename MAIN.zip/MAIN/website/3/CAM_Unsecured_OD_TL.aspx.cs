﻿using BusinessAccessLayer.CAM;
using BusinessAccessLayer.Common;
using BusinessAccessLayer.CustomerProfile;
using DataObjects.Error;
using DataObjects.CAM.Unsecured;
using Resources;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;
using Utilities.Enums;
using Utilities.FormValidations;
using Utilities.SessionKeys;

public partial class CAM_Unsecured_OD_TL : Page
{
    #region COMMON VARIABLES

    private DataTable _dt = null;
    private DataSet _ds = null;
    private CAM_BL _CAM_BL;
    private Common_BL _common_BL;
    private Cust_Prof_BL _custProf_BL;
    private Boolean _isMasterDataLoadSuccess = true;

    public Int64 SessionEMP_ID
    {
        get
        {
            Int64 employeeId = -1;
            var empId = Convert.ToInt64(Session[SessionKeys.EMP_ID]);

            if (empId > 0)
            {
                employeeId = Convert.ToInt32(Session[SessionKeys.EMP_ID]);
            }

            return employeeId;
        }
    }

    #endregion

    #region CONSTRUCTOR

    public CAM_Unsecured_OD_TL()
    {
        _CAM_BL = new CAM_BL();
        _common_BL = new Common_BL();
        _custProf_BL = new Cust_Prof_BL();
    }

    #endregion

    #region PAGE EVENTS

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                ClearCAMSessionData();

                //GET BRANCH DETAILS FROM SESSION
                if (Session[SessionKeys.BRANCHID] != null) { lblBranchId.Text = Session[SessionKeys.BRANCHID].ToString(); }
                if (Session[SessionKeys.UNITNAME] != null) { lblBranchName.Text = Session[SessionKeys.UNITNAME].ToString(); }

                //GET AREA DETAILS FROM SESSION
                if (Session[SessionKeys.AREA_ID] != null) { lblAreaId.Text = Session[SessionKeys.AREA_ID].ToString(); }
                if (Session[SessionKeys.AREANAME] != null) { lblAreaName.Text = Session[SessionKeys.AREANAME].ToString(); }

                BindLeadNoByBranch();
                BindMasterCustomerProfile();
                GetMasterDataForCAM();

                if (!_isMasterDataLoadSuccess) { uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_GENERIC, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention); }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_GENERIC, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }

    #endregion

    #region BUTTON EVENTS

    protected void btnAddBusinessDetails_Click(object sender, EventArgs e)
    {
        try
        {
            if (ValidateBusinessDetailsIntegrity())
            {
                Int64 leadId = 0;
                Int64 kycId = 0;
                DataTable businessDetailsGrid = null;

                var applName = ddlApplicantName.SelectedItem.Text;
                var applType = lblApplicantType.Text;
                var cibilScore = txtBxCIBILScore.Text;

                var natureOfBusinessId = ddlNatureOfBusiness.SelectedItem.Value;
                var natureOfBusiness = ddlNatureOfBusiness.SelectedItem.Text;

                var custProfile = ddlCustomerProfile.SelectedItem.Text;
                var custProfileId = ddlCustomerProfile.SelectedValue;

                var segment = ddlSegment.SelectedItem.Text;
                var segmentId = ddlSegment.SelectedValue;

                var subCategory = String.Empty;
                Int64 subCategoryId = 0;

                if (ddlSubCategory != null && ddlSubCategory.Items.Count > 1 && ddlSubCategory.SelectedItem.Text != AppConstants.DropdownDefaultSelection)
                {
                    subCategory = ddlSubCategory.SelectedItem.Text;
                    Int64.TryParse(Convert.ToString(ddlSubCategory.SelectedValue), out subCategoryId);
                }

                var annlBusnsTurnoveBasedOnAssmnt = txtBxAnnlBusnsTurnOvrBasedOnAssmnt.Text;

                Int64 cibil = 0;
                Int64.TryParse(Convert.ToString(cibilScore), out cibil);

                Double annlBsnsTrnOvr = 0.0;
                Double.TryParse(Convert.ToString(annlBusnsTurnoveBasedOnAssmnt), out annlBsnsTrnOvr);
                annlBsnsTrnOvr = Math.Round(annlBsnsTrnOvr, 2);

                if (Session[SessionKeys.KYC_CUST_PROF_DETAILS] != null)
                {
                    DataTable _leadKycCustProfDetails = (DataTable)Session[SessionKeys.KYC_CUST_PROF_DETAILS];
                    kycId = Convert.ToInt64(ddlApplicantName.SelectedValue);

                    if (_leadKycCustProfDetails != null && _leadKycCustProfDetails.Rows.Count > 0)
                    {
                        DataRow drLeadKyc = _leadKycCustProfDetails.AsEnumerable().Where(obj => obj.Field<Int32>(AppConstants.Col_KYC_ID) == kycId).FirstOrDefault();
                        leadId = Convert.ToInt64(drLeadKyc[AppConstants.Col_KYC_LD_ID]);
                    }
                }

                if (Session[SessionKeys.GV_BUSINESS_DETAILS] != null)
                {
                    businessDetailsGrid = (DataTable)Session[SessionKeys.GV_BUSINESS_DETAILS];
                }
                else
                {
                    LoadEmptyBusinessDetailsGrid();
                    businessDetailsGrid = (DataTable)Session[SessionKeys.GV_BUSINESS_DETAILS];
                }

                if (businessDetailsGrid != null && businessDetailsGrid.Rows.Count > 0 && businessDetailsGrid.Rows[0][0].ToString() == "")
                {
                    businessDetailsGrid.Rows.RemoveAt(0);
                }

                Int32 _maxRowId = 0;
                Int32 _currRowId = 0;
                _maxRowId = businessDetailsGrid.Rows.Count;
                _currRowId = _maxRowId + 1;

                DataRow businessDetailRow = businessDetailsGrid.NewRow();

                businessDetailRow[AppConstants.GV_COL_ROW_ID] = _currRowId;
                businessDetailRow[AppConstants.GV_COL_KYC_LEAD_ID] = leadId;
                businessDetailRow[AppConstants.GV_COL_KYC_ID] = kycId;
                businessDetailRow[AppConstants.GV_COL_NAME] = applName;
                businessDetailRow[AppConstants.GV_COL_APPL_TYPE] = applType;
                businessDetailRow[AppConstants.GV_COL_CIBIL_SCORE] = cibil;

                businessDetailRow[AppConstants.GV_COL_NATURE_OF_BUSINESS] = natureOfBusiness;
                businessDetailRow[AppConstants.GV_COL_NATURE_OF_BUSINESS_KEY] = natureOfBusinessId;

                businessDetailRow[AppConstants.GV_COL_CUST_PROFILE] = custProfile;
                businessDetailRow[AppConstants.GV_COL_CUST_PROFILE_ID] = custProfileId;

                businessDetailRow[AppConstants.GV_COL_SEGMENT] = segment;
                businessDetailRow[AppConstants.GV_COL_SEGMENT_ID] = segmentId;

                businessDetailRow[AppConstants.GV_COL_SUB_CATEGORY] = subCategory;
                businessDetailRow[AppConstants.GV_COL_SUB_CATEGORY_ID] = subCategoryId;

                businessDetailRow[AppConstants.GV_COL_SALES_BASED_ON_ASSESSMENT] = annlBsnsTrnOvr;

                businessDetailsGrid.Rows.Add(businessDetailRow);
                Session[SessionKeys.GV_BUSINESS_DETAILS] = businessDetailsGrid;

                gvBusinessDetails.DataSource = businessDetailsGrid;
                gvBusinessDetails.DataBind();

                Double totSales = 0;
                Double currSales = 0;
                Double.TryParse(lblTotalAnnlBusnsTurnOvrBasedOnAssmnt.Text, out totSales);
                currSales = annlBsnsTrnOvr;

                if (currSales > 0)
                {
                    totSales = totSales + currSales;
                    lblTotalAnnlBusnsTurnOvrBasedOnAssmnt.Text = Convert.ToString(totSales);
                    lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt.Text = Convert.ToString(totSales);
                }

                UpdateEligibilityDetailsGrid();
                ResetBusinessDetailsGrid();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnAddESFBObligation_Click(object sender, EventArgs e)
    {
        try
        {
            if (ValidateESFBLoanDetailsIntegrity())
            {
                String _esfbLoanAgreement = null;
                String _esfbProductName = null;
                var _esfbLoanAmount = 0.0;
                var _esfbLoanOutstandingAmount = 0.0;
                DataTable _esfbLoanDetailsGrid = null;

                _esfbLoanAgreement = txtBxExistingLoanAgreement.Text;
                _esfbProductName = txtBxProductName.Text;
                Double.TryParse(txtBxExistingLoanAmount.Text, out _esfbLoanAmount);
                Double.TryParse(txtBxExistingOutstandingAmount.Text, out _esfbLoanOutstandingAmount);

                if (Session[SessionKeys.GV_ESFB_LOAN_DETAILS] != null)
                {
                    _esfbLoanDetailsGrid = (DataTable)Session[SessionKeys.GV_ESFB_LOAN_DETAILS];
                }
                else
                {
                    LoadEmptyESFBLoanDetailsGrid();
                    _esfbLoanDetailsGrid = (DataTable)Session[SessionKeys.GV_ESFB_LOAN_DETAILS];
                }

                if (_esfbLoanDetailsGrid != null && _esfbLoanDetailsGrid.Rows.Count > 0 && _esfbLoanDetailsGrid.Rows[0][0].ToString() == "")
                {
                    _esfbLoanDetailsGrid.Rows.RemoveAt(0);
                }

                Int32 _maxRowId = 0;
                Int32 _currRowId = 0;
                _maxRowId = _esfbLoanDetailsGrid.Rows.Count;
                _currRowId = _maxRowId + 1;

                DataRow _esfbLoanDetailRow = _esfbLoanDetailsGrid.NewRow();

                _esfbLoanDetailRow[AppConstants.GV_COL_ROW_ID] = _currRowId;
                _esfbLoanDetailRow[AppConstants.GV_COL_ESFB_LN_AGRMNT] = _esfbLoanAgreement;
                _esfbLoanDetailRow[AppConstants.GV_COL_ESFB_PR_NAME] = _esfbProductName;
                _esfbLoanDetailRow[AppConstants.GV_COL_ESFB_LN_AMT] = _esfbLoanAmount;
                _esfbLoanDetailRow[AppConstants.GV_COL_ESFB_LN_OS_AMT] = _esfbLoanOutstandingAmount;

                _esfbLoanDetailsGrid.Rows.Add(_esfbLoanDetailRow);
                Session[SessionKeys.GV_ESFB_LOAN_DETAILS] = _esfbLoanDetailsGrid;

                gvESFBObligations.DataSource = _esfbLoanDetailsGrid;
                gvESFBObligations.DataBind();

                //Calculate Total ESFB Loan Amount
                Double _totEsfbLoanAmount = 0;
                Double _currEsfbLoanAmount = 0;
                Double.TryParse(lblTotalEsfbLoanAmount.Text, out _totEsfbLoanAmount);
                _currEsfbLoanAmount = _esfbLoanAmount;

                if (_currEsfbLoanAmount > 0)
                {
                    _totEsfbLoanAmount = _totEsfbLoanAmount + _currEsfbLoanAmount;
                    lblTotalEsfbLoanAmount.Text = Convert.ToString(_totEsfbLoanAmount);
                }

                //Calculate Total ESFB Loan Outstanding Amount
                Double _totLoanOutstandingAmount = 0;
                Double _currLoanOutstandingAmount = 0;
                Double.TryParse(lblTotalEsfbLoanOutstandingAmount.Text, out _totLoanOutstandingAmount);
                _currLoanOutstandingAmount = _esfbLoanOutstandingAmount;

                if (_currLoanOutstandingAmount > 0)
                {
                    _totLoanOutstandingAmount += _currLoanOutstandingAmount;
                    lblTotalEsfbLoanOutstandingAmount.Text = Convert.ToString(_totLoanOutstandingAmount);
                }

                UpdateEligibilityDetailsGrid();
                ResetESFBLoanDetailsGrid();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnAddOtherLoanDetails_Click(object sender, EventArgs e)
    {
        try
        {
            if (ValidateOtherLoanDetailsIntegrity())
            {
                Int64 _leadId = 0;
                DataTable dtOtherLoanDetailsGrid = null;

                String _financier = txtBxFinancier.Text;
                String _loanType = ddlLoanType.SelectedItem.Text;
                String _lnTypeId = ddlLoanType.SelectedItem.Value;
                String _sanctionAmount = txtBxSanctionAmount.Text;
                String _outstandingAmount = txtBxOutstandingAmount.Text;
                String _emiAmount = txtBxEMIAmount.Text;
                String _tenor = txtBxTenor.Text;

                Int64 _loanTypeId = 0;
                Int64.TryParse(_lnTypeId, out _loanTypeId);

                Double sanctionAmount = 0.0;
                Double.TryParse(Convert.ToString(_sanctionAmount), out sanctionAmount);
                sanctionAmount = Math.Round(sanctionAmount, 2);

                Double outstandingAmount = 0.0;
                Double.TryParse(Convert.ToString(_outstandingAmount), out outstandingAmount);
                outstandingAmount = Math.Round(outstandingAmount, 2);

                Double emiAmount = 0.0;
                Double.TryParse(Convert.ToString(_emiAmount), out emiAmount);
                emiAmount = Math.Round(emiAmount, 2);

                Int64 tenor = 0;
                Int64.TryParse(Convert.ToString(_tenor), out tenor);

                if (Session[SessionKeys.LeadId] != null) { Int64.TryParse(Convert.ToString(Session[SessionKeys.LeadId]), out _leadId); }

                if (Session[SessionKeys.GV_OTHER_LOAN_DETAILS] != null)
                {
                    dtOtherLoanDetailsGrid = (DataTable)Session[SessionKeys.GV_OTHER_LOAN_DETAILS];
                }
                else
                {
                    LoadEmptyOtherLoanDetailsGrid();
                    dtOtherLoanDetailsGrid = (DataTable)Session[SessionKeys.GV_OTHER_LOAN_DETAILS];
                }

                if (dtOtherLoanDetailsGrid != null && dtOtherLoanDetailsGrid.Rows.Count > 0 && dtOtherLoanDetailsGrid.Rows[0][0].ToString() == "")
                {
                    dtOtherLoanDetailsGrid.Rows.RemoveAt(0);
                }

                Int32 _maxRowId = 0;
                Int32 _currRowId = 0;
                _maxRowId = dtOtherLoanDetailsGrid.Rows.Count;
                _currRowId = _maxRowId + 1;

                DataRow drOtherLoanDetailRow = dtOtherLoanDetailsGrid.NewRow();

                drOtherLoanDetailRow[AppConstants.GV_COL_ROW_ID] = _currRowId;
                drOtherLoanDetailRow[AppConstants.GV_COL_KYC_LEAD_ID] = _leadId;
                drOtherLoanDetailRow[AppConstants.GV_COL_FINANCIER] = _financier;
                drOtherLoanDetailRow[AppConstants.GV_COL_LOAN_TYPE] = _loanType;
                drOtherLoanDetailRow[AppConstants.GV_COL_LOAN_TYPE_ID] = _loanTypeId;
                drOtherLoanDetailRow[AppConstants.GV_SANCTION_AMOUNT] = sanctionAmount;
                drOtherLoanDetailRow[AppConstants.GV_COL_OUTSTANDING_AMOUNT] = outstandingAmount;
                drOtherLoanDetailRow[AppConstants.GV_COL_EMI_AMOUNT] = emiAmount;
                drOtherLoanDetailRow[AppConstants.GV_COL_TENOR] = tenor;

                dtOtherLoanDetailsGrid.Rows.Add(drOtherLoanDetailRow);
                Session[SessionKeys.GV_OTHER_LOAN_DETAILS] = dtOtherLoanDetailsGrid;

                gvOtherLoanDetails.DataSource = dtOtherLoanDetailsGrid;
                gvOtherLoanDetails.DataBind();

                //Total Outstanding Amount
                if (_loanType != "GOLD LOAN")
                {
                    Double totOutstandingAmt = 0;
                    Double currOutstandingAmt = 0;
                    Double.TryParse(lblTotalOutstandingAmt.Text, out totOutstandingAmt);
                    currOutstandingAmt = outstandingAmount;

                    if (currOutstandingAmt > 0)
                    {
                        totOutstandingAmt = totOutstandingAmt + currOutstandingAmt;
                        lblTotalOutstandingAmt.Text = Convert.ToString(totOutstandingAmt);
                        lblElig_TotalOutstandingAmount.Text = Convert.ToString(totOutstandingAmt);
                    }

                    //Total EMI Amount
                    Double totEMIAmt = 0;
                    Double currEMIAmt = 0;
                    Double.TryParse(lblTotalEMIAmt.Text, out totEMIAmt);
                    currEMIAmt = emiAmount;

                    if (currEMIAmt > 0)
                    {
                        totEMIAmt = totEMIAmt + currEMIAmt;
                        lblTotalEMIAmt.Text = Convert.ToString(totEMIAmt);
                    }
                }

                UpdateEligibilityDetailsGrid();
                ResetOtherLoanDetailsGrid();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Boolean _result = false;
        try
        {
            if (ValidateUnsecuredCAMSumaryDataIntegrity())
            {
                _result = SaveUnsecuredBranchCAMSummary();

                if (_result)
                {
                    Reset();
                    ClearCAMSessionData();
                    uscMsgBox1.AddMessage(CAM_BusinessMessages.SAVE_UNSECURED_CAM_SUCCESS, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
                else
                {
                    uscMsgBox1.AddMessage(CAM_BusinessMessages.SAVE_UNSECURED_CAM_FAIL, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage(ErrorMessages.MSG_ERR_GENERIC, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
    }

    #endregion

    #region TEXTBOX EVENTS

    /*protected void txtBxElig_FactoringDeviationPercentage_OnTextChanged(object sender, EventArgs e)
    {
        if (txtBxElig_FactoringDeviationPercentage != null
        && !String.IsNullOrEmpty(txtBxElig_FactoringDeviationPercentage.Text)
        && (!FormValidations.AllowDecimals(txtBxElig_FactoringDeviationPercentage.Text) || (Convert.ToDecimal(txtBxElig_FactoringDeviationPercentage.Text) > 100)))
        {
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_FACT_DEV_PRCNT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            UpdateEligibilityDetailsGrid();
        }
    }*/

    protected void txtBxCustRequestedAmt_OnTextChanged(object sender, EventArgs e)
    {
        if (txtBxCustRequestedAmt != null
            && !String.IsNullOrEmpty(txtBxCustRequestedAmt.Text)
            && !FormValidations.IsIncomeValid(txtBxCustRequestedAmt.Text))
        {
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_CUST_REQ_LOAN_AMT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            UpdateEligibilityDetailsGrid();
        }
    }

    protected void txtBxMnthlPopOfLoclty_OnTextChanged(object sender, EventArgs e)
    {
        if (txtBxMnthlPopOfLoclty != null
            && !String.IsNullOrEmpty(txtBxMnthlPopOfLoclty.Text)
            && !FormValidations.IsPopulationValid(txtBxMnthlPopOfLoclty.Text))
        {
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_MONTHLY_POPULATION_OF_CITY_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
    }

    #endregion

    #region DROPDOWN EVENTS

    protected void ddlLeadNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable _dtLeadDtls = null;
        DataTable _dtKycCustProfDtls = null;
        DataSet _dsLeadDtls = null;

        try
        {
            if (ddlLeadNo.SelectedIndex > 0)
            {
                _dsLeadDtls = GetFullLeadDetails();

                if (_dsLeadDtls != null
                    && _dsLeadDtls.Tables.Count == 2
                    && _dsLeadDtls.Tables[0].Rows.Count > 0
                    && _dsLeadDtls.Tables[1].Rows.Count > 0)
                {
                    _dtLeadDtls = _dsLeadDtls.Tables[0];

                    lblApplnName.Text = _dtLeadDtls.Rows[0]["LD_APNAME"] != DBNull.Value ? _dtLeadDtls.Rows[0]["LD_APNAME"].ToString() : "";
                    lblContactNo.Text = _dtLeadDtls.Rows[0]["LD_ACNO"] != DBNull.Value ? _dtLeadDtls.Rows[0]["LD_ACNO"].ToString() : "";

                    String _resAddress = null;
                    String _resAddress1 = null;
                    String _resCity = null;
                    String _resPincode = null;

                    _resAddress = _dtLeadDtls.Rows[0]["LD_RADDRESS"] != DBNull.Value ? _dtLeadDtls.Rows[0]["LD_RADDRESS"].ToString() : "";
                    _resAddress1 = _dtLeadDtls.Rows[0]["LD_RADDRESS1"] != DBNull.Value ? _dtLeadDtls.Rows[0]["LD_RADDRESS1"].ToString() : "";
                    _resCity = _dtLeadDtls.Rows[0]["LD_RCITY"] != DBNull.Value ? _dtLeadDtls.Rows[0]["LD_RCITY"].ToString() : "";
                    _resPincode = _dtLeadDtls.Rows[0]["LD_RPINCODE"] != DBNull.Value ? _dtLeadDtls.Rows[0]["LD_RPINCODE"].ToString() : "";
                    lblAddress.Text = _resAddress + ", " + _resAddress1 + ", " + _resCity + ", " + _resPincode;

                    _dtKycCustProfDtls = _dsLeadDtls.Tables[1];
                    Int64 leadApplCount = _dtKycCustProfDtls.Rows.Count;

                    if (leadApplCount > 0)
                    {
                        Session[SessionKeys.KYC_CUST_PROF_DETAILS] = _dtKycCustProfDtls;
                        ddlApplicantName.DataSource = _dtKycCustProfDtls;
                        ddlApplicantName.DataValueField = AppConstants.Col_KYC_ID;
                        ddlApplicantName.DataTextField = AppConstants.Col_KYC_NAME;
                        ddlApplicantName.DataBind();
                        ddlApplicantName.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
                    }

                    btnSubmit.Enabled = true;
                    btnCancel.Enabled = true;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void ddlCustCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        String _custCategory = null;
        String _limit = null;
        Double _limitPercent = 0.0;

        try
        {
            if (ddlCustCategory != null && ddlCustCategory.SelectedIndex > 0)
            {
                _custCategory = ddlCustCategory.SelectedItem.Text.Trim();
                Double.TryParse(ddlCustCategory.SelectedValue, out _limitPercent);

                _limit = _limitPercent + " %";
                Session[SessionKeys.FACTORING_PERCENATGE] = _limitPercent;

                ResetESFBLoanDetailsGrid();

                if (_custCategory == EnumUtils.GetEnumValue(CustomerCategory.EXISTING_CUSTOMER).ToUpper())
                {
                    tblCustomerLoanDetails.Visible = true;

                    txtBxExistingLoanAgreement.Enabled = true;
                    txtBxExistingLoanAgreement.Visible = true;

                    txtBxProductName.Enabled = true;
                    txtBxProductName.Visible = true;

                    txtBxExistingLoanAmount.Enabled = true;
                    txtBxExistingLoanAmount.Visible = true;

                    txtBxExistingOutstandingAmount.Enabled = true;
                    txtBxExistingOutstandingAmount.Visible = true;

                    btnAddESFBObligation.Enabled = true;
                    btnAddESFBObligation.Visible = true;

                    gvESFBObligations.Visible = true;

                    tblESFBTotalObligations.Visible = true;

                    lblTotalEsfbLoanAmount.Enabled = false;
                    lblTotalEsfbLoanAmount.Visible = true;

                    lblTotalEsfbLoanOutstandingAmount.Enabled = false;
                    lblTotalEsfbLoanOutstandingAmount.Visible = true;

                    tdLimitEligibilityBasedOnESFBLoansHeader.Visible = true;
                    tdLimitEligibilityBasedOnESFBLoansValue.Visible = true;
                    lblLimitBasedOnEsfbLoans.Text = String.Empty;

                    tdLimitPostObligatingOutstandingLoansHeader.Visible = false;
                    tdLimitPostObligatingOutstandingLoansValue.Visible = false;
                    lblLimitPostObligatingOutstandingLoans.Text = String.Empty;
                }
                else if ((_custCategory == EnumUtils.GetEnumValue(CustomerCategory.NEW_CUSTOMER).ToUpper()) || (_custCategory == AppConstants.DropdownDefaultSelection))
                {
                    tblCustomerLoanDetails.Visible = false;

                    txtBxExistingLoanAgreement.Enabled = false;
                    txtBxExistingLoanAgreement.Visible = false;

                    txtBxProductName.Enabled = false;
                    txtBxProductName.Visible = false;

                    txtBxExistingLoanAmount.Enabled = false;
                    txtBxExistingLoanAmount.Visible = false;

                    txtBxExistingOutstandingAmount.Enabled = false;
                    txtBxExistingOutstandingAmount.Visible = false;

                    gvESFBObligations.Visible = false;

                    btnAddESFBObligation.Enabled = false;
                    btnAddESFBObligation.Visible = false;

                    tblESFBTotalObligations.Visible = false;

                    lblTotalEsfbLoanAmount.Enabled = false;
                    lblTotalEsfbLoanAmount.Visible = false;

                    lblTotalEsfbLoanOutstandingAmount.Enabled = false;
                    lblTotalEsfbLoanOutstandingAmount.Visible = false;

                    tdLimitEligibilityBasedOnESFBLoansHeader.Visible = false;
                    tdLimitEligibilityBasedOnESFBLoansValue.Visible = false;
                    lblLimitBasedOnEsfbLoans.Text = String.Empty;

                    tdLimitPostObligatingOutstandingLoansHeader.Visible = true;
                    tdLimitPostObligatingOutstandingLoansValue.Visible = true;
                    lblLimitPostObligatingOutstandingLoans.Text = String.Empty;
                }

                lblTotalEsfbLoanAmount.Text = String.Empty;
                lblTotalEsfbLoanOutstandingAmount.Text = String.Empty;

                //RESET ESFB Obligations Gridview
                if (gvESFBObligations != null && gvESFBObligations.Rows.Count > 0)
                {
                    gvESFBObligations.DataSource = null;
                    gvESFBObligations.DataBind();
                }
            }

            if (!String.IsNullOrEmpty(_limit)) { lblElig_Limit.Text = _limit; }
            else { lblElig_Limit.Text = ""; }

            if (!String.IsNullOrEmpty(lblElig_20PercentOfTotalAssessedTurnover.Text)) { lblElig_20PercentOfTotalAssessedTurnover.Text = String.Empty; }
            if (!String.IsNullOrEmpty(lblLimitBasedOnEsfbLoans.Text)) { lblLimitBasedOnEsfbLoans.Text = String.Empty; }

            UpdateEligibilityDetailsGrid();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void ddlApplicantName_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable _dtKycCustProfDtls = null;

        try
        {
            if (Session[SessionKeys.KYC_CUST_PROF_DETAILS] != null)
            {
                _dtKycCustProfDtls = (DataTable)Session[SessionKeys.KYC_CUST_PROF_DETAILS];
                Int32 kycId = Convert.ToInt32(ddlApplicantName.SelectedValue);

                if (_dtKycCustProfDtls != null && _dtKycCustProfDtls.Rows.Count > 0)
                {
                    DataRow drKycCustProf = _dtKycCustProfDtls.AsEnumerable().Where(obj => obj.Field<Int32>(AppConstants.Col_KYC_ID) == kycId).FirstOrDefault();

                    if (drKycCustProf != null)
                    {
                        lblApplicantType.Text = Convert.ToString(drKycCustProf[AppConstants.Col_KYC_APPL_TYPE]);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void ddlCustomerProfile_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindMasterSegment();
    }

    protected void ddlSegment_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindMasterSubCategory();
    }

    #endregion

    #region GRID EVENTS

    protected void gvESFBObligations_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (Session[SessionKeys.GV_ESFB_LOAN_DETAILS] != null)
            {
                DataTable dtEsfbLoanDetailsGrid = (DataTable)Session[SessionKeys.GV_ESFB_LOAN_DETAILS];

                if (e.CommandName == "Delete")
                {
                    btnSubmit.Enabled = false;
                    string[] esfbLoanParams = e.CommandArgument.ToString().Split('/');

                    String filterQuery = ("ROW_ID = '" + esfbLoanParams[0] + "'");

                    DataRow[] filteredRow = dtEsfbLoanDetailsGrid.Select(filterQuery);
                    dtEsfbLoanDetailsGrid.Rows.Remove(filteredRow[0]);

                    if (dtEsfbLoanDetailsGrid.Rows.Count > 0)
                    {
                        Session[SessionKeys.GV_ESFB_LOAN_DETAILS] = dtEsfbLoanDetailsGrid;
                        gvESFBObligations.DataSource = dtEsfbLoanDetailsGrid;
                        gvESFBObligations.DataBind();

                        Double dblTotalEsfbLoanAmount = 0.0;
                        Double dblTotalEsfbLoanOutstandingAmount = 0.0;

                        if (dtEsfbLoanDetailsGrid != null && dtEsfbLoanDetailsGrid.Rows.Count > 0)
                        {
                            foreach (var esfbLoanDetailRow in dtEsfbLoanDetailsGrid.AsEnumerable())
                            {
                                Double dblCurrEsfbLoanAmount = 0.0;
                                Double dblCurrEsfbLoanOutstandingAmount = 0.0;

                                Double.TryParse(esfbLoanDetailRow[AppConstants.GV_COL_ESFB_LN_AMT].ToString(), out dblCurrEsfbLoanAmount);
                                Double.TryParse(esfbLoanDetailRow[AppConstants.GV_COL_ESFB_LN_OS_AMT].ToString(), out dblCurrEsfbLoanOutstandingAmount);

                                dblTotalEsfbLoanAmount += dblCurrEsfbLoanAmount;
                                dblTotalEsfbLoanOutstandingAmount += dblCurrEsfbLoanOutstandingAmount;
                            }

                            lblTotalEsfbLoanAmount.Text = dblTotalEsfbLoanAmount.ToString();
                            lblTotalEsfbLoanOutstandingAmount.Text = dblTotalEsfbLoanOutstandingAmount.ToString();
                        }
                    }
                    else
                    {
                        LoadEmptyESFBLoanDetailsGrid();

                        lblTotalEsfbLoanAmount.Text = String.Empty;
                        lblTotalEsfbLoanOutstandingAmount.Text = String.Empty;
                    }

                    ResetESFBLoanDetailsGrid();
                    UpdateEligibilityDetailsGrid();
                    btnSubmit.Enabled = true;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void gvESFBObligations_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //This empty method is created only to handle ROW_EDIT event raised during DELETE operation.
        //If this methoed is not created, then DELETE operation in GRID 'gvESFBObligations' will not work.
    }

    protected void gvESFBObligations_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //This empty method is created only to handle ROW_EDIT event raised during DELETE operation.
        //If this methoed is not created, then DELETE operation in GRID 'gvESFBObligations' will not work.
    }

    protected void gvBusinessDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (Session[SessionKeys.GV_BUSINESS_DETAILS] != null)
            {
                DataTable dtBusinessDetailsGrid = (DataTable)Session[SessionKeys.GV_BUSINESS_DETAILS];

                if (e.CommandName == "Delete")
                {
                    btnSubmit.Enabled = false;
                    string[] businessParams = e.CommandArgument.ToString().Split('/');

                    String filterQuery = ("ROW_ID = '" + businessParams[0] + "'");

                    DataRow[] filteredRow = dtBusinessDetailsGrid.Select(filterQuery);
                    dtBusinessDetailsGrid.Rows.Remove(filteredRow[0]);

                    if (dtBusinessDetailsGrid.Rows.Count > 0)
                    {
                        Session[SessionKeys.GV_BUSINESS_DETAILS] = dtBusinessDetailsGrid;
                        gvBusinessDetails.DataSource = dtBusinessDetailsGrid;
                        gvBusinessDetails.DataBind();

                        Double dblTotalAnnualBusinessTurnover = 0.0;
                        if (dtBusinessDetailsGrid != null && dtBusinessDetailsGrid.Rows.Count > 0)
                        {
                            foreach (var businessDetailRow in dtBusinessDetailsGrid.AsEnumerable())
                            {
                                Double dblCurrAnnualBusinessTurnover = 0.0;
                                Double.TryParse(businessDetailRow[AppConstants.GV_COL_SALES_BASED_ON_ASSESSMENT].ToString(), out dblCurrAnnualBusinessTurnover);
                                dblTotalAnnualBusinessTurnover = dblTotalAnnualBusinessTurnover + dblCurrAnnualBusinessTurnover;
                            }

                            lblTotalAnnlBusnsTurnOvrBasedOnAssmnt.Text = dblTotalAnnualBusinessTurnover.ToString();
                            lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt.Text = dblTotalAnnualBusinessTurnover.ToString();
                        }
                    }
                    else
                    {
                        LoadEmptyBusinessDetailsGrid();

                        lblTotalAnnlBusnsTurnOvrBasedOnAssmnt.Text = String.Empty;
                        lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt.Text = String.Empty;
                        lblLimitOfTotalAssessedTurnover.Text = String.Empty;
                    }

                    ResetBusinessDetailsGrid();
                    UpdateEligibilityDetailsGrid();
                    btnSubmit.Enabled = true;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void gvBusinessDetails_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //This empty method is created only to handle ROW_EDIT event raised during DELETE operation.
        //If this methoed is not created, then DELETE operation in GRID 'gvBusinessDetails' will not work.
    }

    protected void gvBusinessDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //This empty method is created only to handle ROW_EDIT event raised during DELETE operation.
        //If this methoed is not created, then DELETE operation in GRID 'gvBusinessDetails' will not work.
    }

    protected void gvOtherLoanDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (Session[SessionKeys.GV_OTHER_LOAN_DETAILS] != null)
            {
                DataTable dtOtherLoanDetailsGrid = (DataTable)Session[SessionKeys.GV_OTHER_LOAN_DETAILS];

                if (e.CommandName == "Delete")
                {
                    btnSubmit.Enabled = false;
                    string[] otherLoanParams = e.CommandArgument.ToString().Split('/');

                    String filterQuery = ("ROW_ID = '" + otherLoanParams[0] + "'");

                    DataRow[] filteredRow = dtOtherLoanDetailsGrid.Select(filterQuery);
                    dtOtherLoanDetailsGrid.Rows.Remove(filteredRow[0]);

                    if (dtOtherLoanDetailsGrid.Rows.Count > 0)
                    {
                        Session[SessionKeys.GV_OTHER_LOAN_DETAILS] = dtOtherLoanDetailsGrid;
                        gvOtherLoanDetails.DataSource = dtOtherLoanDetailsGrid;
                        gvOtherLoanDetails.DataBind();

                        Double dblTotalOutstandingAmt = 0.0;
                        Double dblTotalEmiAmt = 0.0;

                        if (dtOtherLoanDetailsGrid != null && dtOtherLoanDetailsGrid.Rows.Count > 0)
                        {
                            foreach (var outstandingAmtRow in dtOtherLoanDetailsGrid.AsEnumerable())
                            {
                                if (outstandingAmtRow[AppConstants.GV_COL_LOAN_TYPE].ToString() != "GOLD LOAN")
                                {
                                    Double dblCurrOutstandingAmt = 0.0;
                                    Double.TryParse(outstandingAmtRow[AppConstants.GV_COL_OUTSTANDING_AMOUNT].ToString(), out dblCurrOutstandingAmt);
                                    dblTotalOutstandingAmt = dblTotalOutstandingAmt + dblCurrOutstandingAmt;

                                    Double dblCurrEMIAmt = 0.0;
                                    Double.TryParse(outstandingAmtRow[AppConstants.GV_COL_EMI_AMOUNT].ToString(), out dblCurrEMIAmt);
                                    dblTotalEmiAmt = dblTotalEmiAmt + dblCurrEMIAmt;
                                }
                            }

                            lblTotalOutstandingAmt.Text = dblTotalOutstandingAmt.ToString();
                            lblTotalEMIAmt.Text = dblTotalEmiAmt.ToString();
                            lblElig_TotalOutstandingAmount.Text = dblTotalOutstandingAmt.ToString();
                        }
                    }
                    else
                    {
                        LoadEmptyOtherLoanDetailsGrid();

                        lblTotalOutstandingAmt.Text = String.Empty;
                        lblTotalEMIAmt.Text = String.Empty;
                        lblElig_TotalOutstandingAmount.Text = String.Empty;
                    }

                    ResetOtherLoanDetailsGrid();
                    UpdateEligibilityDetailsGrid();
                    btnSubmit.Enabled = true;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void gvOtherLoanDetails_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //This empty method is created only to handle ROW_EDIT event raised during DELETE operation.
        //If this methoed is not created, then DELETE operation in GRID 'gvOtherLoanDetails' will not work.
    }

    protected void gvOtherLoanDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //This empty method is created only to handle ROW_EDIT event raised during DELETE operation.
        //If this methoed is not created, then DELETE operation in GRID 'gvOtherLoanDetails' will not work.
    }

    #endregion

    #region CRUD

    #region INSERT    

    private Boolean SaveUnsecuredBranchCAMSummary()
    {
        Int64 _userId = 0;
        Int64 _leadId = 0;

        Boolean _result = false;
        Double _factPercent = 0;

        String _productName = String.Empty;
        String _existingLoanAgreement = String.Empty;

        UnsecuredCamDO _unsecuredCamSmmryDO = null;

        DataTable dtDbEsfbLoanDetails = null;
        DataTable dtDbBusinessDetails = null;
        DataTable dtDbOtherLoanDetails = null;

        DataTable dtGridEsfbLoanDetails = null;
        DataTable dtGridBusinessDetails = null;
        DataTable dtGridOtherLoanDetails = null;

        try
        {
            if (Session[SessionKeys.ID] != null) { Int64.TryParse(Convert.ToString(Session[SessionKeys.ID]), out _userId); }

            #region CAM SUMMARY

            _unsecuredCamSmmryDO = new UnsecuredCamDO();

            if (Session[SessionKeys.LeadId] != null) { Int64.TryParse(Convert.ToString(Session[SessionKeys.LeadId]), out _leadId); }
            _unsecuredCamSmmryDO.UCAM_LD_ID = Convert.ToString(_leadId);

            //LEAD DETAILS
            _unsecuredCamSmmryDO.UCAM_CAM_TYPE = "B";
            _unsecuredCamSmmryDO.UCAM_APPL_NAME = lblApplnName.Text;
            _unsecuredCamSmmryDO.UCAM_AR_ID = lblAreaId.Text;
            _unsecuredCamSmmryDO.UCAM_AR_NAME = lblAreaName.Text;
            _unsecuredCamSmmryDO.UCAM_BR_ID = lblBranchId.Text;
            _unsecuredCamSmmryDO.UCAM_BR_NAME = lblBranchName.Text;
            _unsecuredCamSmmryDO.UCAM_RES_ADDRESS = lblAddress.Text;
            _unsecuredCamSmmryDO.UCAM_CONTACT_NO = lblContactNo.Text;
            _unsecuredCamSmmryDO.UCAM_LIAB_BR_ID = ddlLiabilityBranch.SelectedItem.Value;
            _unsecuredCamSmmryDO.UCAM_LIAB_BR_NAME = ddlLiabilityBranch.SelectedItem.Text;
            _unsecuredCamSmmryDO.UCAM_CUST_REQ_AMT = txtBxCustRequestedAmt.Text;

            //CUSTOMER CATEGORY
            _unsecuredCamSmmryDO.UCAM_CUST_CTGRY_ID = ddlCustCategory.SelectedItem.Value;
            _unsecuredCamSmmryDO.UCAM_CUST_CTGRY = ddlCustCategory.SelectedItem.Text;

            //PROPERTY OWNERSHIP DETAILS
            _unsecuredCamSmmryDO.UCAM_PRPTY_TYPE_ID = ddlPropertyType.SelectedItem.Value;
            _unsecuredCamSmmryDO.UCAM_PRPTY_TYPE = ddlPropertyType.SelectedItem.Text;

            _unsecuredCamSmmryDO.UCAM_OCC_STAT_ID = ddlOccupancyStatus.SelectedItem.Value;
            _unsecuredCamSmmryDO.UCAM_OCC_STAT = ddlOccupancyStatus.SelectedItem.Text;

            _unsecuredCamSmmryDO.UCAM_USG_ID = ddlUsage.SelectedItem.Value;
            _unsecuredCamSmmryDO.UCAM_USG = ddlUsage.SelectedItem.Text;

            //OTHER DETAILS
            _unsecuredCamSmmryDO.UCAM_OTH_DT_MON_INC_FRM_BSNS = txtBxMnthlIncmFrmBusiness.Text;
            _unsecuredCamSmmryDO.UCAM_OTH_DT_FACT_PRCNT = String.Empty;
            _unsecuredCamSmmryDO.UCAM_OTH_DT_FIN_INC = String.Empty;
            _unsecuredCamSmmryDO.UCAM_OTH_DT_POP_CITY = txtBxMnthlPopOfLoclty.Text;

            //ELIGIBILITY DETAILS
            _unsecuredCamSmmryDO.UCAM_TOT_SAL_ASSMT = lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt.Text;

            if (Session[SessionKeys.FACTORING_PERCENATGE] != null) { Double.TryParse(Convert.ToString(Session[SessionKeys.FACTORING_PERCENATGE]), out _factPercent); }
            _unsecuredCamSmmryDO.UCAM_FACT_PRCNT = Convert.ToString(_factPercent);

            _unsecuredCamSmmryDO.UCAM_FACT_DEV_PRCNT = String.Empty;
            _unsecuredCamSmmryDO.UCAM_SAL_AFTR_FACTR = lblLimitOfTotalAssessedTurnover.Text;
            _unsecuredCamSmmryDO.UCAM_TOT_OUT_AMT = lblElig_TotalOutstandingAmount.Text;
            _unsecuredCamSmmryDO.UCAM_ESFB_LMT_ELIG = lblLimitPostObligatingOutstandingLoans.Text;
            _unsecuredCamSmmryDO.UCAM_FIN_ESFB_LMT_ELIG = lblFinalESFBEligibleLimit.Text;
            _unsecuredCamSmmryDO.UCAM_STAT = "1";

            #endregion

            #region ESFB LOAN DETAILS

            if (gvESFBObligations != null && gvESFBObligations.Rows.Count > 0)
            {
                if (Session[SessionKeys.GV_ESFB_LOAN_DETAILS] != null)
                {
                    dtGridEsfbLoanDetails = (DataTable)Session[SessionKeys.GV_ESFB_LOAN_DETAILS];
                    dtDbEsfbLoanDetails = CreateESFBLoanDetailsDbDataTable();
                    DataRow drEsfbLoanDetailRow;

                    foreach (DataRow dataRow in dtGridEsfbLoanDetails.Rows)
                    {
                        drEsfbLoanDetailRow = dtDbEsfbLoanDetails.NewRow();

                        drEsfbLoanDetailRow[AppConstants.Col_UELD_ESFB_LN_AGRMNT] = dataRow[AppConstants.GV_COL_ESFB_LN_AGRMNT];
                        drEsfbLoanDetailRow[AppConstants.Col_UELD_ESFB_PR_NAME] = dataRow[AppConstants.GV_COL_ESFB_PR_NAME];
                        drEsfbLoanDetailRow[AppConstants.Col_UELD_ESFB_LN_AMT] = dataRow[AppConstants.GV_COL_ESFB_LN_AMT];
                        drEsfbLoanDetailRow[AppConstants.Col_UELD_ESFB_LN_OS_AMT] = dataRow[AppConstants.GV_COL_ESFB_LN_OS_AMT];

                        dtDbEsfbLoanDetails.Rows.Add(drEsfbLoanDetailRow);
                    }
                }
            }

            #endregion

            #region BUSINESS DETAILS

            if (gvBusinessDetails != null && gvBusinessDetails.Rows.Count > 0)
            {
                if (Session[SessionKeys.GV_BUSINESS_DETAILS] != null)
                {
                    dtGridBusinessDetails = (DataTable)Session[SessionKeys.GV_BUSINESS_DETAILS];
                    dtDbBusinessDetails = CreateBusinessDetailsDbDataTable();
                    DataRow drBusinessDetail;

                    foreach (DataRow dataRow in dtGridBusinessDetails.Rows)
                    {
                        drBusinessDetail = dtDbBusinessDetails.NewRow();

                        Int64 _kycLeadId = 0;
                        Int64.TryParse(Convert.ToString(dataRow[AppConstants.GV_COL_KYC_LEAD_ID]), out _kycLeadId);
                        drBusinessDetail[AppConstants.Col_UBD_LD_ID] = _kycLeadId.ToString();

                        Int64 _kycId = 0;
                        Int64.TryParse(Convert.ToString(dataRow[AppConstants.GV_COL_KYC_ID]), out _kycId);
                        drBusinessDetail[AppConstants.Col_UBD_KYC_ID] = _kycId.ToString();

                        drBusinessDetail[AppConstants.Col_UBD_UCAM_ID] = null;
                        drBusinessDetail[AppConstants.Col_UBD_CIBIL] = dataRow[AppConstants.GV_COL_CIBIL_SCORE];
                        drBusinessDetail[AppConstants.Col_UBD_NAT_OF_BUSINESS] = dataRow[AppConstants.GV_COL_NATURE_OF_BUSINESS];
                        drBusinessDetail[AppConstants.Col_UBD_NAT_OF_BUSINESS_KEY] = dataRow[AppConstants.GV_COL_NATURE_OF_BUSINESS_KEY];
                        drBusinessDetail[AppConstants.Col_UBD_CUST_PROF_ID] = dataRow[AppConstants.GV_COL_CUST_PROFILE_ID];
                        drBusinessDetail[AppConstants.Col_UBD_SGMT_ID] = dataRow[AppConstants.GV_COL_SEGMENT_ID];
                        drBusinessDetail[AppConstants.Col_UBD_SUB_CTGRY_ID] = dataRow[AppConstants.GV_COL_SUB_CATEGORY_ID];

                        var _annlBusnsTurnOvrBasedOnAssmnt = 0.0;
                        Double.TryParse(Convert.ToString(dataRow[AppConstants.GV_COL_SALES_BASED_ON_ASSESSMENT]), out _annlBusnsTurnOvrBasedOnAssmnt);
                        _annlBusnsTurnOvrBasedOnAssmnt = Math.Round(_annlBusnsTurnOvrBasedOnAssmnt, 2);
                        drBusinessDetail[AppConstants.Col_UBD_SALES_BASED_ON_ASSMT] = _annlBusnsTurnOvrBasedOnAssmnt.ToString();

                        drBusinessDetail[AppConstants.Col_UBD_STAT] = "1";
                        drBusinessDetail[AppConstants.Col_UBD_CRTD_BY] = "";
                        drBusinessDetail[AppConstants.Col_UBD_CRTD_DT] = "";
                        drBusinessDetail[AppConstants.Col_UBD_MDFD_BY] = "";
                        drBusinessDetail[AppConstants.Col_UBD_MDFD_DT] = "";

                        dtDbBusinessDetails.Rows.Add(drBusinessDetail);
                    }
                }
            }

            #endregion

            #region OTHER LOAN DETAILS

            if (gvOtherLoanDetails != null && gvOtherLoanDetails.Rows.Count > 0)
            {
                if (Session[SessionKeys.GV_OTHER_LOAN_DETAILS] != null)
                {
                    dtGridOtherLoanDetails = (DataTable)Session[SessionKeys.GV_OTHER_LOAN_DETAILS];
                    dtDbOtherLoanDetails = CreateOtherLoanDetailsDbDataTable();
                    DataRow drOtherLoanDetail;

                    foreach (DataRow dataRow in dtGridOtherLoanDetails.Rows)
                    {
                        drOtherLoanDetail = dtDbOtherLoanDetails.NewRow();

                        drOtherLoanDetail[AppConstants.Col_UOLD_LD_ID] = dataRow[AppConstants.GV_COL_KYC_LEAD_ID];
                        drOtherLoanDetail[AppConstants.Col_UOLD_UCAM_ID] = null;
                        drOtherLoanDetail[AppConstants.Col_UOLD_FIN] = dataRow[AppConstants.GV_COL_FINANCIER];
                        drOtherLoanDetail[AppConstants.Col_UOLD_LN_TYPE] = dataRow[AppConstants.GV_COL_LOAN_TYPE];
                        drOtherLoanDetail[AppConstants.Col_UOLD_LN_TYPE_ID] = dataRow[AppConstants.GV_COL_LOAN_TYPE_ID];
                        drOtherLoanDetail[AppConstants.Col_UOLD_SANC_AMT] = Math.Round(Convert.ToDouble(dataRow[AppConstants.GV_SANCTION_AMOUNT]), 2).ToString();
                        drOtherLoanDetail[AppConstants.Col_UOLD_OUTSTAND_AMT] = Math.Round(Convert.ToDouble(dataRow[AppConstants.GV_COL_OUTSTANDING_AMOUNT]), 2).ToString();
                        drOtherLoanDetail[AppConstants.Col_UOLD_EMI_AMT] = Math.Round(Convert.ToDouble(dataRow[AppConstants.GV_COL_EMI_AMOUNT]), 2).ToString();
                        drOtherLoanDetail[AppConstants.Col_UOLD_TENOR] = dataRow[AppConstants.GV_COL_TENOR];
                        drOtherLoanDetail[AppConstants.Col_UOLD_STAT] = "1";
                        drOtherLoanDetail[AppConstants.Col_UOLD_CRTD_BY] = "";
                        drOtherLoanDetail[AppConstants.Col_UOLD_CRTD_DT] = "";
                        drOtherLoanDetail[AppConstants.Col_UOLD_MDFD_BY] = "";
                        drOtherLoanDetail[AppConstants.Col_UOLD_MDFD_DT] = "";

                        dtDbOtherLoanDetails.Rows.Add(drOtherLoanDetail);
                    }
                }
            }

            #endregion

            if (_unsecuredCamSmmryDO != null
                && ((dtDbEsfbLoanDetails == null) || (dtDbEsfbLoanDetails != null && dtDbEsfbLoanDetails.Rows.Count > 0))
                && (dtDbBusinessDetails != null && dtDbBusinessDetails.Rows.Count > 0)
                && (dtDbOtherLoanDetails != null && dtDbOtherLoanDetails.Rows.Count > 0))
            {
                _CAM_BL.SaveUnsecuredBranchCAMSummary(_unsecuredCamSmmryDO, dtDbEsfbLoanDetails, dtDbBusinessDetails, dtDbOtherLoanDetails, _userId, out _result);
            }
        }
        catch (Exception ex)
        {
            _result = false;
            throw ex;
        }

        return _result;
    }

    #endregion

    #endregion

    #region PRIVATE METHODS

    private void BindProductLoanCap(DataTable dtProductLoanCap)
    {
        Double _prodLoanCap = 0.0;

        try
        {
            if (dtProductLoanCap != null && dtProductLoanCap.Rows.Count > 0 && dtProductLoanCap.Rows[0]["PLC_PR_LN_CAP"] != null)
            {
                Double.TryParse(dtProductLoanCap.Rows[0]["PLC_PR_LN_CAP"].ToString(), out _prodLoanCap);
            }

            Session[SessionKeys.MERCHANT_OD_LOAN_CAP] = _prodLoanCap;
            lblMaxProductCap.Text = Convert.ToString(_prodLoanCap);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindLeadNoByBranch()
    {
        String branchName = null;

        try
        {
            if (lblBranchName != null)
            {
                branchName = lblBranchName.Text;

                if (!String.IsNullOrEmpty(branchName))
                {
                    _ds = _CAM_BL.GetLeadsForUnsecuredBranchCAM(branchName);

                    if (_ds != null && _ds.Tables.Count > 0 && _ds.Tables[0].Rows.Count > 0)
                    {
                        ddlLeadNo.DataSource = _ds;
                        ddlLeadNo.DataTextField = AppConstants.DDL_DATATEXT_KEY_LD_NO;
                        ddlLeadNo.DataValueField = AppConstants.DDL_DATAVALUE_KEY_LD_ID;
                        ddlLeadNo.DataBind();
                        ddlLeadNo.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void GetMasterDataForCAM()
    {
        #region VARIABLES

        String _camType = null;
        DataSet _resultSet = null;

        DataTable _dtLiabilityBranch = null;
        DataTable _dtNatureOfBusiness = null;
        DataTable _dtCustomerCategory = null;
        DataTable _dtLoanType = null;
        DataTable _dtPropertyType = null;
        DataTable _dtOccupancyStatus = null;
        DataTable _dtUsage = null;
        DataTable _dtProductLoanCap = null;

        #endregion

        try
        {
            _camType = EnumUtils.GetEnumValue(Department.BRANCH);
            _resultSet = _CAM_BL.GetMasterDataForCAM(_camType);

            if (_resultSet != null && _resultSet.Tables.Count > 0)
            {
                if (_resultSet.Tables.Count > 0 && _resultSet.Tables[0] != null && _resultSet.Tables[0].Rows.Count > 0) { _dtLiabilityBranch = _resultSet.Tables[0]; }
                if (_resultSet.Tables.Count > 1 && _resultSet.Tables[1] != null && _resultSet.Tables[1].Rows.Count > 0) { _dtNatureOfBusiness = _resultSet.Tables[1]; }
                if (_resultSet.Tables.Count > 2 && _resultSet.Tables[2] != null && _resultSet.Tables[2].Rows.Count > 0) { _dtCustomerCategory = _resultSet.Tables[2]; }
                if (_resultSet.Tables.Count > 3 && _resultSet.Tables[3] != null && _resultSet.Tables[3].Rows.Count > 0) { _dtLoanType = _resultSet.Tables[3]; }
                if (_resultSet.Tables.Count > 4 && _resultSet.Tables[4] != null && _resultSet.Tables[4].Rows.Count > 0) { _dtPropertyType = _resultSet.Tables[4]; }
                if (_resultSet.Tables.Count > 5 && _resultSet.Tables[5] != null && _resultSet.Tables[5].Rows.Count > 0) { _dtOccupancyStatus = _resultSet.Tables[5]; }
                if (_resultSet.Tables.Count > 6 && _resultSet.Tables[6] != null && _resultSet.Tables[6].Rows.Count > 0) { _dtUsage = _resultSet.Tables[6]; }
                if (_resultSet.Tables.Count > 7 && _resultSet.Tables[7] != null && _resultSet.Tables[7].Rows.Count > 0) { _dtProductLoanCap = _resultSet.Tables[7]; }

                BindLiabilityBranch(_dtLiabilityBranch);
                BindNatureOfBusiness(_dtNatureOfBusiness);
                BindCustomerCategory(_dtCustomerCategory);
                BindMasterLoanType(_dtLoanType);
                BindMasterPropertyType(_dtPropertyType);
                BindMasterOccupancyStatus(_dtOccupancyStatus);
                BindMasterUsage(_dtUsage);
                BindProductLoanCap(_dtProductLoanCap);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindLiabilityBranch(DataTable dtLiabilityBranch)
    {
        try
        {
            if (_isMasterDataLoadSuccess && dtLiabilityBranch != null && dtLiabilityBranch.Rows.Count > 0)
            {
                ddlLiabilityBranch.DataSource = dtLiabilityBranch;
                ddlLiabilityBranch.DataTextField = AppConstants.DDL_DATATEXT_KEY_LBR_NAME;
                ddlLiabilityBranch.DataValueField = AppConstants.DDL_DATAVALUE_KEY_LBR_CODE;
                ddlLiabilityBranch.DataBind();
                ddlLiabilityBranch.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }
            else { _isMasterDataLoadSuccess = false; }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindNatureOfBusiness(DataTable dtNatureOfBusiness)
    {
        try
        {
            if (_isMasterDataLoadSuccess && dtNatureOfBusiness != null && dtNatureOfBusiness.Rows.Count > 0)
            {
                ddlNatureOfBusiness.DataSource = dtNatureOfBusiness;
                ddlNatureOfBusiness.DataTextField = AppConstants.DDL_DATAVALUE_KEY_ITEM_DESC;
                ddlNatureOfBusiness.DataValueField = AppConstants.DDL_DATATEXT_KEY_ITEM_KEY;
                ddlNatureOfBusiness.DataBind();
                ddlNatureOfBusiness.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }
            else { _isMasterDataLoadSuccess = false; }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindCustomerCategory(DataTable dtCustomerCategory)
    {
        try
        {
            if (_isMasterDataLoadSuccess && dtCustomerCategory != null && dtCustomerCategory.Rows.Count > 0)
            {
                ddlCustCategory.DataSource = dtCustomerCategory;
                ddlCustCategory.DataTextField = AppConstants.DDL_DATATEXT_KEY_CC_DESC;
                ddlCustCategory.DataValueField = AppConstants.DDL_DATAVALUE_KEY_CC_FACT_PRCNT;
                ddlCustCategory.DataBind();
                ddlCustCategory.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));

                Session[SessionKeys.CUSTOMER_CATEGORY] = dtCustomerCategory;
            }
            else { _isMasterDataLoadSuccess = false; }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindMasterLoanType(DataTable dtLoanType)
    {
        try
        {
            if (_isMasterDataLoadSuccess && dtLoanType != null && dtLoanType.Rows.Count > 0)
            {
                ddlLoanType.DataSource = dtLoanType;
                ddlLoanType.DataTextField = AppConstants.DDL_DATATEXT_KEY_LT_DESC;
                ddlLoanType.DataValueField = AppConstants.DDL_DATAVALUE_KEY_LT_ID;
                ddlLoanType.DataBind();
                ddlLoanType.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }
            else { _isMasterDataLoadSuccess = false; }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindMasterCustomerProfile()
    {
        String _type = null;
        String _su_Prf_Id = null;
        String _su_Seg_Id = null;

        try
        {
            _type = "3";
            _su_Prf_Id = String.Empty;
            _su_Seg_Id = String.Empty;

            _dt = _custProf_BL.GetMasterCustomerProfile(_type, _su_Prf_Id, _su_Seg_Id);

            if (_dt != null && _dt.Rows.Count > 0)
            {
                ddlCustomerProfile.DataSource = _dt;
                ddlCustomerProfile.DataTextField = "PRF_DESC";
                ddlCustomerProfile.DataValueField = "PRF_ID";
                ddlCustomerProfile.DataBind();
                ddlCustomerProfile.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));

                if (ddlSegment != null && ddlCustomerProfile.Items.Count == 0) { ddlSegment.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0")); }
                if (ddlSubCategory != null && ddlSubCategory.Items.Count == 0) { ddlSubCategory.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0")); }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindMasterSegment()
    {
        String _type = null;
        String _su_Prf_Id = null;
        String _su_Seg_Id = null;

        try
        {
            _type = "4";
            _su_Prf_Id = ddlCustomerProfile.SelectedItem.Value.ToString();
            _su_Seg_Id = String.Empty;

            _dt = _custProf_BL.GetMasterCustomerProfile(_type, _su_Prf_Id, _su_Seg_Id);

            if (_dt != null && _dt.Rows.Count > 0)
            {
                ddlSegment.DataSource = _dt;
                ddlSegment.DataTextField = "SG_DESG";
                ddlSegment.DataValueField = "SG_ID";
                ddlSegment.DataBind();
                ddlSegment.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }
            else
            {
                ddlSegment.ClearSelection();
                ddlSegment.Items.Clear();
                ddlSegment.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindMasterSubCategory()
    {
        String _type = null;
        String _su_Prf_Id = null;
        String _su_Seg_Id = null;

        try
        {
            _type = "5";
            _su_Prf_Id = ddlCustomerProfile.SelectedItem.Value.ToString();
            _su_Seg_Id = ddlSegment.SelectedItem.Value.ToString();

            _dt = _custProf_BL.GetMasterCustomerProfile(_type, _su_Prf_Id, _su_Seg_Id);

            if (_dt != null && _dt.Rows.Count > 0)
            {
                ddlSubCategory.DataSource = _dt;
                ddlSubCategory.DataTextField = "SU_DESC";
                ddlSubCategory.DataValueField = "SU_ID";
                ddlSubCategory.DataBind();
                ddlSubCategory.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }
            else
            {
                ddlSubCategory.ClearSelection();
                ddlSubCategory.Items.Clear();
                ddlSubCategory.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindMasterPropertyType(DataTable dtPropertyType)
    {
        try
        {
            if (_isMasterDataLoadSuccess && dtPropertyType != null && dtPropertyType.Rows.Count > 0)
            {
                ddlPropertyType.DataSource = dtPropertyType;
                ddlPropertyType.DataTextField = AppConstants.DDL_DATATEXT_KEY_PT_DESC;
                ddlPropertyType.DataValueField = AppConstants.DDL_DATAVALUE_KEY_PT_ID;
                ddlPropertyType.DataBind();
                ddlPropertyType.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }
            else { _isMasterDataLoadSuccess = false; }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindMasterOccupancyStatus(DataTable dtOccupancyStatus)
    {
        try
        {
            if (_isMasterDataLoadSuccess && dtOccupancyStatus != null && dtOccupancyStatus.Rows.Count > 0)
            {
                ddlOccupancyStatus.DataSource = dtOccupancyStatus;
                ddlOccupancyStatus.DataTextField = AppConstants.DDL_DATATEXT_KEY_OC_DESC;
                ddlOccupancyStatus.DataValueField = AppConstants.DDL_DATAVALUE_KEY_OC_ID;
                ddlOccupancyStatus.DataBind();
                ddlOccupancyStatus.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }
            else { _isMasterDataLoadSuccess = false; }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindMasterUsage(DataTable dtUsage)
    {
        try
        {
            if (_isMasterDataLoadSuccess && dtUsage != null && dtUsage.Rows.Count > 0)
            {
                ddlUsage.DataSource = dtUsage;
                ddlUsage.DataTextField = AppConstants.DDL_DATATEXT_KEY_UG_DESC;
                ddlUsage.DataValueField = AppConstants.DDL_DATAVALUE_KEY_UG_ID;
                ddlUsage.DataBind();
                ddlUsage.Items.Insert(0, new ListItem(AppConstants.DropdownDefaultSelection, "0"));
            }
            else { _isMasterDataLoadSuccess = false; }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private DataSet GetFullLeadDetails()
    {
        Int64 _leadId = 0;

        try
        {
            if (ddlLeadNo != null && ddlLeadNo.SelectedIndex > 0)
            {
                Int64.TryParse(Convert.ToString(ddlLeadNo.SelectedItem.Value), out _leadId);

                if (_leadId > 0)
                {
                    Session[SessionKeys.LeadId] = _leadId;
                    _ds = _common_BL.GetFullLeadDetails(_leadId);
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

        return _ds;
    }

    private bool ValidateESFBLoanDetailsIntegrity()
    {
        bool _passValidation = true;

        //Existing ESFB Loan agreement number
        if (txtBxExistingLoanAgreement == null || String.IsNullOrEmpty(txtBxExistingLoanAgreement.Text))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ESFB_LOAN_AGREEMENT_NUMBER_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && ((txtBxExistingLoanAgreement.Text.Length > 50)
                || (!FormValidations.IsESFBLoanAgreementNumberValid(txtBxExistingLoanAgreement.Text))))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ESFB_LOAN_AGREEMENT_NUMBER_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        //Existing ESFB Product Name
        else if (txtBxProductName == null || String.IsNullOrEmpty(txtBxProductName.Text))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ESFB_PRODUCT_NAME_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && ((txtBxProductName.Text.Length > 50)
                || (!FormValidations.IsESFBLoanAgreementNumberValid(txtBxProductName.Text))))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ESFB_PRODUCT_NAME_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        //Existing ESFB Loan Amount
        else if (_passValidation && (txtBxExistingLoanAmount == null || String.IsNullOrEmpty(txtBxExistingLoanAmount.Text)))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ESFB_LOAN_AMOUNT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && !FormValidations.AllowDecimals(txtBxExistingLoanAmount.Text))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ESFB_LOAN_AMOUNT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && !(Convert.ToDouble(txtBxExistingLoanAmount.Text) > 0))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ESFB_LOAN_AMOUNT_INVALID_NUMBER, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        //Existing ESFB Loan Outstanding Amount
        else if (_passValidation && (txtBxExistingOutstandingAmount == null || String.IsNullOrEmpty(txtBxExistingOutstandingAmount.Text)))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ESFB_OUTSTANDING_LOAN_AMOUNT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && !FormValidations.AllowDecimals(txtBxExistingOutstandingAmount.Text))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ESFB_OUTSTANDING_LOAN_AMOUNT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (_passValidation && !(Convert.ToDouble(txtBxExistingOutstandingAmount.Text) > 0))
        {
            _passValidation = false;
            uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ESFB_OUTSTANDING_LOAN_AMOUNT_INVALID_NUMBER, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }

        return _passValidation;
    }

    private bool ValidateBusinessDetailsIntegrity()
    {
        bool _passValidation = true;

        try
        {
            //Applicant Name
            if (ddlApplicantName == null || ddlApplicantName.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_APPLICANT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Customer Profile
            else if (ddlCustomerProfile == null || ddlCustomerProfile.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_CUST_PROFILE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Segment
            else if (ddlSegment == null || ddlSegment.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_SEGMENT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Sub-Category
            else if (ddlSubCategory != null && ddlSubCategory.Items.Count > 1 && ddlSubCategory.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_SUB_CATEGORY_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //CIBIL Score
            else if (_passValidation && txtBxCIBILScore == null || txtBxCIBILScore.Text == String.Empty)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_CIBIL_SCORE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation && !FormValidations.IsCibilValid(txtBxCIBILScore.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_CIBIL_SCORE_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Nature Of Business
            else if (_passValidation && ddlNatureOfBusiness == null || ddlNatureOfBusiness.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_NATURE_OF_BUSINESS_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Annual Business T/O Based On Assessment
            else if (txtBxAnnlBusnsTurnOvrBasedOnAssmnt == null || txtBxAnnlBusnsTurnOvrBasedOnAssmnt.Text == String.Empty)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ANNUAL_BUSINESS_TURNOVER_BASED_ON_ASSESSMENT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if ((!FormValidations.IsIncomeValid(txtBxAnnlBusnsTurnOvrBasedOnAssmnt.Text)))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_ANNUAL_BUSINESS_TURNOVER_BASED_ON_ASSESSMENT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw ex;
        }

        return _passValidation;
    }

    private bool ValidateOtherLoanDetailsIntegrity()
    {
        bool _passValidation = true;

        try
        {
            //Financier
            if (txtBxFinancier == null || txtBxFinancier.Text == String.Empty)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_FINANCIER_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Loan Type
            else if (_passValidation && ddlLoanType == null || ddlLoanType.SelectedItem.Text == AppConstants.DropdownDefaultSelection)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_LOAN_TYPE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Sanction Amount
            else if (_passValidation && txtBxSanctionAmount == null || txtBxSanctionAmount.Text == String.Empty)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_SANCTION_AMOUNT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation && !FormValidations.IsIncomeValid(txtBxSanctionAmount.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_SANCTION_AMOUNT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Outstanding Amount
            else if (_passValidation && txtBxOutstandingAmount == null || txtBxOutstandingAmount.Text == String.Empty)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_OUTSTANDING_AMOUNT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation && !FormValidations.IsIncomeValid(txtBxOutstandingAmount.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_OUTSTANDING_AMOUNT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //EMI Amount
            else if (_passValidation && txtBxEMIAmount == null || txtBxEMIAmount.Text == String.Empty)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_EMI_AMOUNT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation && !FormValidations.IsIncomeValid(txtBxEMIAmount.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_EMI_AMOUNT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Tenor
            else if (txtBxTenor == null || txtBxTenor.Text == String.Empty)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_TENOR_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if ((!FormValidations.IsTenorValid(txtBxTenor.Text)))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_TENOR_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw ex;
        }

        return _passValidation;
    }

    private bool ValidateUnsecuredCAMSumaryDataIntegrity()
    {
        bool _passValidation = true;

        try
        {
            #region LEAD DETAILS
            //Lead Details
            if ((lblApplnName == null || String.IsNullOrEmpty(lblApplnName.Text))
                || (lblAreaName == null || String.IsNullOrEmpty(lblAreaName.Text))
                || (lblBranchName == null || String.IsNullOrEmpty(lblBranchName.Text))
                || (lblAddress == null || String.IsNullOrEmpty(lblAddress.Text))
                || (lblAddress == null || String.IsNullOrEmpty(lblAddress.Text))
                || (lblContactNo == null || String.IsNullOrEmpty(lblContactNo.Text)))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_LEAD_DETAILS_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Liability Branch
            else if (ddlLiabilityBranch != null && ddlLiabilityBranch.SelectedIndex == 0)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_LIABILITY_BRANCH_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            //Customer requested loan amount
            else if (txtBxCustRequestedAmt == null || String.IsNullOrEmpty(txtBxCustRequestedAmt.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_CUST_REQ_LOAN_AMT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation && !FormValidations.IsIncomeValid(txtBxCustRequestedAmt.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_CUST_REQ_LOAN_AMT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            #endregion

            #region CUSTOMER EXISTING/NEW LOAN DETAILS
            //Customer Category
            else if (_passValidation && (ddlCustCategory == null || ddlCustCategory.SelectedIndex == 0))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_CUST_CATEGORY_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Existing loan agreement number
            else if (_passValidation
                && (ddlCustCategory != null && ddlCustCategory.SelectedItem.Text == "EXISTING CUSTOMER")
                && (txtBxExistingLoanAgreement == null || String.IsNullOrEmpty(txtBxExistingLoanAgreement.Text)) && (gvESFBObligations.Rows.Count == 0))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_EXISTING_LOAN_AGREEMENT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Product Name
            else if (_passValidation
                && (ddlCustCategory != null && ddlCustCategory.SelectedItem.Text == "EXISTING CUSTOMER")
                && (txtBxProductName == null || String.IsNullOrEmpty(txtBxProductName.Text)) && (gvESFBObligations.Rows.Count == 0))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_PRODUCT_NAME_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Existing loan amount
            else if (_passValidation
                && (ddlCustCategory != null && ddlCustCategory.SelectedItem.Text == "EXISTING CUSTOMER")
                && (txtBxExistingLoanAmount == null || String.IsNullOrEmpty(txtBxExistingLoanAmount.Text)) && (gvESFBObligations.Rows.Count == 0))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_EXISTING_LOAN_AMOUNT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation
                && (ddlCustCategory != null && ddlCustCategory.SelectedItem.Text == "EXISTING CUSTOMER")
                && !FormValidations.AllowDecimals(txtBxExistingLoanAmount.Text) && (gvESFBObligations.Rows.Count == 0))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_EXISTING_LOAN_AMOUNT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            #endregion

            #region BUSINESS DETAILS GRID
            else if (gvBusinessDetails == null || gvBusinessDetails.Rows.Count == 0)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_BUSINESS_DETAILS_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Total Annual Business Turnover Based On Assessment
            else if (lblTotalAnnlBusnsTurnOvrBasedOnAssmnt == null || String.IsNullOrEmpty(lblTotalAnnlBusnsTurnOvrBasedOnAssmnt.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_TOT_BUSNS_TURNOVER_BASED_ON_ASSMT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            #endregion

            #region OTHER LOAN DETAILS GRID
            else if (gvOtherLoanDetails != null
                && (gvOtherLoanDetails.Rows.Count > 0)
                && (lblTotalOutstandingAmt == null || String.IsNullOrEmpty(lblTotalOutstandingAmt.Text))
                    || (lblTotalEMIAmt == null || String.IsNullOrEmpty(lblTotalEMIAmt.Text)))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_OTHER_LOAN_DETAILS_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            #endregion

            #region PROPERTY OWNERSHIP
            //Property type
            else if (_passValidation && ddlPropertyType != null && ddlPropertyType.SelectedIndex == 0)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_PROPERTY_TYPE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Ocupancy Status
            else if (_passValidation && ddlOccupancyStatus != null && ddlOccupancyStatus.SelectedIndex == 0)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_OCCUPANCY_STATUS_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Usage
            else if (_passValidation && ddlUsage != null && ddlUsage.SelectedIndex == 0)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_PROPERTY_USAGE_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            #endregion

            #region OTHER DETAILS
            //Monthly Income from business
            else if (_passValidation && txtBxMnthlIncmFrmBusiness != null
                && !String.IsNullOrEmpty(txtBxMnthlIncmFrmBusiness.Text)
                && !FormValidations.AllowDecimals(txtBxMnthlIncmFrmBusiness.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_MONTHLY_INCOME_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //Population Of The City
            else if (_passValidation && txtBxMnthlPopOfLoclty != null
                && !String.IsNullOrEmpty(txtBxMnthlPopOfLoclty.Text)
                && !FormValidations.IsPopulationValid(txtBxMnthlPopOfLoclty.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_MONTHLY_POPULATION_OF_CITY_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            #endregion

            #region ELIGIBILITY DETAILS
            else if (_passValidation
                && lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt != null
                && lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt.Text == String.Empty)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_TOT_BUSNS_TURNOVR_BASED_ON_ASSMT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation
                && lblElig_Limit != null
                && lblElig_Limit.Text == String.Empty)
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_LIMIT_PERCENT_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation && lblElig_Limit != null
            && !String.IsNullOrEmpty(lblElig_Limit.Text)
            && (!FormValidations.AllowDecimals(lblElig_Limit.Text.Remove(2)) || (Convert.ToDecimal(lblElig_Limit.Text.Remove(2)) > 100)))
            {
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_LIMIT_PERCENT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation
                && lblLimitOfTotalAssessedTurnover != null
                && !String.IsNullOrEmpty(lblLimitOfTotalAssessedTurnover.Text)
                && !FormValidations.AllowDecimals(lblLimitOfTotalAssessedTurnover.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_LIMIT_OF_TOTAL_ASSESSED_TURNOVER_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation
                && lblElig_TotalOutstandingAmount != null
                && !String.IsNullOrEmpty(lblElig_TotalOutstandingAmount.Text)
                && !FormValidations.AllowDecimals(lblElig_TotalOutstandingAmount.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_TOTAL_OUTSTANDING_AMOUNT_AFTER_FACTORING_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation
                && lblLimitPostObligatingOutstandingLoans != null
                && !String.IsNullOrEmpty(lblLimitPostObligatingOutstandingLoans.Text)
                && !FormValidations.AllowDecimals(lblLimitPostObligatingOutstandingLoans.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_LIMIT_POST_OBLIGATING_OUTSTANDING_LOANS_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (_passValidation
                && lblFinalESFBEligibleLimit != null
                && !String.IsNullOrEmpty(lblFinalESFBEligibleLimit.Text)
                && !FormValidations.AllowDecimals(lblFinalESFBEligibleLimit.Text))
            {
                _passValidation = false;
                uscMsgBox1.AddMessage(CAM_BusinessMessages.MSG_FINAL_ESFB_ELIGIBLE_LIMIT_INVALID, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            #endregion
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return _passValidation;
    }

    private void UpdateEligibilityDetailsGrid()
    {
        #region VARIABLES

        String _custCategory = null;

        Double _maxProductCap = 0.0;
        Double _custReqLoanAmt = 0.0;
        Double _elig_LimitPercentage = 0.0;
        Double _dblTotalEsfbLoanAmount = 0.0;
        Double _finalESFBEligibleLimit = 0.0;
        Double _dblLimitBasedOnEsfbLoans = 0.0;
        Double _elig_TotalOutstandingAmount = 0.0;
        Double _limitOfTotalAssessedTurnover = 0.0;
        Double _limitPostObligatingOutstandingLoans = 0.0;
        Double _elig_TotalAnnlBusnsTurnOvrBasedOnAssmnt = 0.0;
        Double _dblTwentyPercentOfTotalAssessedTurnOver = 0.0;

        #endregion

        if (lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt != null && !String.IsNullOrEmpty(lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt.Text))
        {
            Double.TryParse(lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt.Text, out _elig_TotalAnnlBusnsTurnOvrBasedOnAssmnt);
        }

        if (lblElig_Limit != null && !String.IsNullOrEmpty(lblElig_Limit.Text))
        {
            Double.TryParse(lblElig_Limit.Text.Remove(2), out _elig_LimitPercentage);
            if (_elig_LimitPercentage > 0) { _elig_LimitPercentage = Math.Round((_elig_LimitPercentage / 100), 2); }
        }
        _limitOfTotalAssessedTurnover = _elig_TotalAnnlBusnsTurnOvrBasedOnAssmnt * (_elig_LimitPercentage);


        if (_limitOfTotalAssessedTurnover > 0) { lblLimitOfTotalAssessedTurnover.Text = Convert.ToString(_limitOfTotalAssessedTurnover); }
        else { lblLimitOfTotalAssessedTurnover.Text = String.Empty; }

        if (lblElig_TotalOutstandingAmount != null && !String.IsNullOrEmpty(lblElig_TotalOutstandingAmount.Text))
        {
            Double.TryParse(lblElig_TotalOutstandingAmount.Text, out _elig_TotalOutstandingAmount);
        }

        #region CUSTOMER CATEGORY BASED CALCULATIONS

        if (ddlCustCategory != null && ddlCustCategory.SelectedIndex > 0) { _custCategory = ddlCustCategory.SelectedItem.Text; }

        if (_elig_LimitPercentage > 0)
        {
            if (_custCategory == EnumUtils.GetEnumValue(CustomerCategory.EXISTING_CUSTOMER).ToUpper())
            {
                Double.TryParse(lblTotalEsfbLoanAmount.Text, out _dblTotalEsfbLoanAmount);

                //Calculate '20% Limit Of Total Assessed T/O'
                Double.TryParse(lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt.Text, out _dblTwentyPercentOfTotalAssessedTurnOver);
                _dblTwentyPercentOfTotalAssessedTurnOver = Math.Round((_dblTwentyPercentOfTotalAssessedTurnOver * (_elig_LimitPercentage)), 2);
                lblElig_20PercentOfTotalAssessedTurnover.Text = Convert.ToString(_dblTwentyPercentOfTotalAssessedTurnOver);

                //Calculate 'Limit Eligibility Based On Existing ESFB Loans'
                if (_dblTotalEsfbLoanAmount > 0 && _dblTotalEsfbLoanAmount <= 200000) { _dblLimitBasedOnEsfbLoans = 100000; }
                else if (_dblTotalEsfbLoanAmount > 200000 && _dblTotalEsfbLoanAmount <= 400000) { _dblLimitBasedOnEsfbLoans = 150000; }
                else if (_dblTotalEsfbLoanAmount > 400000) { _dblLimitBasedOnEsfbLoans = 200000; }
                lblLimitBasedOnEsfbLoans.Text = Convert.ToString(Math.Round(_dblLimitBasedOnEsfbLoans, 2));

                //Calculate 'Limit Post Obligating Outstanding Loans'
                _limitPostObligatingOutstandingLoans = Math.Round(_limitOfTotalAssessedTurnover, 2);
            }
            else if (_custCategory == EnumUtils.GetEnumValue(CustomerCategory.NEW_CUSTOMER).ToUpper())
            {
                //Calculate '20% Limit Of Total Assessed T/O'
                Double.TryParse(lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt.Text, out _dblTwentyPercentOfTotalAssessedTurnOver);
                _dblTwentyPercentOfTotalAssessedTurnOver = Math.Round((_dblTwentyPercentOfTotalAssessedTurnOver * (0.2)), 2);
                lblElig_20PercentOfTotalAssessedTurnover.Text = Convert.ToString(_dblTwentyPercentOfTotalAssessedTurnOver);

                //Calculate 'Limit Eligibility Based On Existing ESFB Loans'
                lblLimitBasedOnEsfbLoans.Text = String.Empty;

                //Calculate 'Limit Post Obligating Outstanding Loans'
                _limitPostObligatingOutstandingLoans = Math.Round(((_limitOfTotalAssessedTurnover) - (_elig_TotalOutstandingAmount)), 2);
            }

            lblLimitPostObligatingOutstandingLoans.Text = (_limitPostObligatingOutstandingLoans > 0) ? Convert.ToString(_limitPostObligatingOutstandingLoans) : "0";
        }

        #endregion

        #region FINAL ESFB LIMIT

        if (txtBxCustRequestedAmt != null && !String.IsNullOrEmpty(txtBxCustRequestedAmt.Text))
        {
            Double.TryParse(txtBxCustRequestedAmt.Text, out _custReqLoanAmt);
        }

        if (Session[SessionKeys.MERCHANT_OD_LOAN_CAP] != null) { Double.TryParse(Convert.ToString(Session[SessionKeys.MERCHANT_OD_LOAN_CAP]), out _maxProductCap); }

        if (_custCategory == EnumUtils.GetEnumValue(CustomerCategory.EXISTING_CUSTOMER).ToUpper())
        {
            /* Formula => Minimum of 
                * limitOfTotalAssessedTurnover
                * dblLimitBasedOnEsfbLoans
                * _custReqLoanAmt
                * _maxProductCap */

            _finalESFBEligibleLimit = Math.Round(Math.Min(Math.Min(Math.Min(_limitOfTotalAssessedTurnover, _dblLimitBasedOnEsfbLoans), _custReqLoanAmt), _maxProductCap), 2);
        }
        else if (_custCategory == EnumUtils.GetEnumValue(CustomerCategory.NEW_CUSTOMER).ToUpper())
        {
            /* Formula => Minimum of 
                * limitPostObligatingOutstandingLoans
                * dblTwentyPercentOfTotalAssessedTurnOver
                * _custReqLoanAmt
                * _maxProductCap */

            _finalESFBEligibleLimit = Math.Round(Math.Min(Math.Min(Math.Min(_limitPostObligatingOutstandingLoans, _dblTwentyPercentOfTotalAssessedTurnOver), _custReqLoanAmt), _maxProductCap), 2);
        }

        lblFinalESFBEligibleLimit.Text = Convert.ToString(_finalESFBEligibleLimit);

        #endregion
    }

    private DataTable CreateESFBLoanDetailsGridDataTable()
    {
        DataTable dtESFBLoanDetails = new DataTable();

        try
        {
            dtESFBLoanDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_ROW_ID, typeof(String)));
            dtESFBLoanDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_ESFB_LN_AGRMNT, typeof(String)));
            dtESFBLoanDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_ESFB_PR_NAME, typeof(String)));
            dtESFBLoanDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_ESFB_LN_AMT, typeof(String)));
            dtESFBLoanDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_ESFB_LN_OS_AMT, typeof(String)));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw ex;
        }

        return dtESFBLoanDetails;
    }

    private DataTable CreateESFBLoanDetailsDbDataTable()
    {
        DataTable dtESFBLoanDetails = new DataTable();

        try
        {
            dtESFBLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UELD_CAM_ID, typeof(String)));
            dtESFBLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UELD_ESFB_LN_AGRMNT, typeof(String)));
            dtESFBLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UELD_ESFB_PR_NAME, typeof(String)));
            dtESFBLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UELD_ESFB_LN_AMT, typeof(String)));
            dtESFBLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UELD_ESFB_LN_OS_AMT, typeof(String)));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw ex;
        }

        return dtESFBLoanDetails;
    }

    private DataTable CreateBusinessDetailsGridDataTable()
    {
        DataTable dtBusinessDetails = new DataTable();

        try
        {
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_ROW_ID, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_KYC_LEAD_ID, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_KYC_ID, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_NAME, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_APPL_TYPE, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_CIBIL_SCORE, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_NATURE_OF_BUSINESS, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_NATURE_OF_BUSINESS_KEY, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_CUST_PROFILE, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_CUST_PROFILE_ID, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_SEGMENT, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_SEGMENT_ID, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_SUB_CATEGORY, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_SUB_CATEGORY_ID, typeof(String)));
            dtBusinessDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_SALES_BASED_ON_ASSESSMENT, typeof(String)));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw ex;
        }

        return dtBusinessDetails;
    }

    private DataTable CreateBusinessDetailsDbDataTable()
    {
        DataTable dtIncomeDetails = new DataTable();

        try
        {
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_LD_ID, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_UCAM_ID, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_KYC_ID, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_CIBIL, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_NAT_OF_BUSINESS, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_NAT_OF_BUSINESS_KEY, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_CUST_PROF_ID, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_SGMT_ID, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_SUB_CTGRY_ID, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_SALES_BASED_ON_ASSMT, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_STAT, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_CRTD_BY, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_CRTD_DT, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_MDFD_BY, typeof(String)));
            dtIncomeDetails.Columns.Add(new DataColumn(AppConstants.Col_UBD_MDFD_DT, typeof(String)));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw ex;
        }

        return dtIncomeDetails;
    }

    private DataTable CreateOtherLoanDetailsGridDataTable()
    {
        DataTable dtObligationDetails = new DataTable();

        try
        {
            dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_ROW_ID, typeof(String)));
            dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_KYC_LEAD_ID, typeof(String)));
            dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_FINANCIER, typeof(String)));
            dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_LOAN_TYPE, typeof(String)));
            dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_LOAN_TYPE_ID, typeof(String)));
            dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_SANCTION_AMOUNT, typeof(String)));
            dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_OUTSTANDING_AMOUNT, typeof(String)));
            dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_EMI_AMOUNT, typeof(String)));
            dtObligationDetails.Columns.Add(new DataColumn(AppConstants.GV_COL_TENOR, typeof(String)));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw ex;
        }

        return dtObligationDetails;
    }

    private DataTable CreateOtherLoanDetailsDbDataTable()
    {
        DataTable dtOtherLoanDetails = new DataTable();

        try
        {
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_LD_ID, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_UCAM_ID, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_FIN, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_LN_TYPE, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_SANC_AMT, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_OUTSTAND_AMT, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_EMI_AMT, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_TENOR, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_STAT, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_CRTD_BY, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_CRTD_DT, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_MDFD_BY, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_MDFD_DT, typeof(String)));
            dtOtherLoanDetails.Columns.Add(new DataColumn(AppConstants.Col_UOLD_LN_TYPE_ID, typeof(String)));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw ex;
        }

        return dtOtherLoanDetails;
    }

    private void LoadEmptyESFBLoanDetailsGrid()
    {
        try
        {
            DataTable dtESFBLoanDetails = CreateESFBLoanDetailsGridDataTable();
            DataRow drESFBLoanDetailRow = dtESFBLoanDetails.NewRow();

            drESFBLoanDetailRow[AppConstants.GV_COL_ROW_ID] = String.Empty;
            drESFBLoanDetailRow[AppConstants.GV_COL_ESFB_LN_AGRMNT] = String.Empty;
            drESFBLoanDetailRow[AppConstants.GV_COL_ESFB_PR_NAME] = String.Empty;
            drESFBLoanDetailRow[AppConstants.GV_COL_ESFB_LN_AMT] = String.Empty;
            drESFBLoanDetailRow[AppConstants.GV_COL_ESFB_LN_OS_AMT] = String.Empty;

            dtESFBLoanDetails.Rows.Add(drESFBLoanDetailRow);

            gvESFBObligations.DataSource = dtESFBLoanDetails;
            gvESFBObligations.DataBind();

            Session[SessionKeys.GV_ESFB_LOAN_DETAILS] = dtESFBLoanDetails;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw ex;
        }
    }

    private void LoadEmptyBusinessDetailsGrid()
    {
        try
        {
            DataTable dtBusinessDetails = CreateBusinessDetailsGridDataTable();
            DataRow drBusinessDetailRow = dtBusinessDetails.NewRow();

            drBusinessDetailRow[AppConstants.GV_COL_ROW_ID] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_KYC_LEAD_ID] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_KYC_ID] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_NAME] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_APPL_TYPE] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_CIBIL_SCORE] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_NATURE_OF_BUSINESS] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_NATURE_OF_BUSINESS_KEY] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_CUST_PROFILE] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_CUST_PROFILE_ID] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_SEGMENT] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_SEGMENT_ID] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_SUB_CATEGORY] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_SUB_CATEGORY_ID] = String.Empty;
            drBusinessDetailRow[AppConstants.GV_COL_SALES_BASED_ON_ASSESSMENT] = String.Empty;

            dtBusinessDetails.Rows.Add(drBusinessDetailRow);

            gvBusinessDetails.DataSource = dtBusinessDetails;
            gvBusinessDetails.DataBind();

            Session[SessionKeys.GV_BUSINESS_DETAILS] = dtBusinessDetails;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw ex;
        }
    }

    private void LoadEmptyOtherLoanDetailsGrid()
    {
        try
        {
            DataTable dtOtherLoanDetails = CreateOtherLoanDetailsGridDataTable();
            DataRow drOtherLoanDetailRow = dtOtherLoanDetails.NewRow();

            drOtherLoanDetailRow[AppConstants.GV_COL_ROW_ID] = String.Empty;
            drOtherLoanDetailRow[AppConstants.GV_COL_KYC_LEAD_ID] = String.Empty;
            drOtherLoanDetailRow[AppConstants.GV_COL_FINANCIER] = String.Empty;
            drOtherLoanDetailRow[AppConstants.GV_COL_LOAN_TYPE_ID] = String.Empty;
            drOtherLoanDetailRow[AppConstants.GV_COL_LOAN_TYPE] = String.Empty;
            drOtherLoanDetailRow[AppConstants.GV_SANCTION_AMOUNT] = String.Empty;
            drOtherLoanDetailRow[AppConstants.GV_COL_OUTSTANDING_AMOUNT] = String.Empty;
            drOtherLoanDetailRow[AppConstants.GV_COL_EMI_AMOUNT] = String.Empty;
            drOtherLoanDetailRow[AppConstants.GV_COL_TENOR] = String.Empty;

            dtOtherLoanDetails.Rows.Add(drOtherLoanDetailRow);

            gvOtherLoanDetails.DataSource = dtOtherLoanDetails;
            gvOtherLoanDetails.DataBind();

            Session[SessionKeys.GV_OTHER_LOAN_DETAILS] = dtOtherLoanDetails;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw ex;
        }
    }

    private void ResetESFBLoanDetailsGrid()
    {
        try
        {
            txtBxExistingLoanAgreement.Text = String.Empty;
            txtBxProductName.Text = String.Empty;
            txtBxExistingLoanAmount.Text = String.Empty;
            txtBxExistingOutstandingAmount.Text = String.Empty;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void ResetBusinessDetailsGrid()
    {
        try
        {
            if (ddlApplicantName != null && ddlApplicantName.Items.Count > 0) { ddlApplicantName.ClearSelection(); }
            if (ddlNatureOfBusiness != null && ddlNatureOfBusiness.Items.Count > 0) { ddlNatureOfBusiness.ClearSelection(); }

            lblApplicantType.Text = String.Empty;
            txtBxCIBILScore.Text = String.Empty;

            if (ddlCustomerProfile != null && ddlCustomerProfile.SelectedIndex > 0) { ddlCustomerProfile.ClearSelection(); }
            if (ddlSegment != null && ddlSegment.SelectedIndex > 0) { ddlSegment.ClearSelection(); }
            if (ddlSubCategory != null && ddlSubCategory.SelectedIndex > 0) { ddlSubCategory.ClearSelection(); }

            txtBxAnnlBusnsTurnOvrBasedOnAssmnt.Text = String.Empty;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void ResetOtherLoanDetailsGrid()
    {
        try
        {
            if (ddlLoanType != null && ddlLoanType.Items.Count > 0) { ddlLoanType.ClearSelection(); }

            txtBxFinancier.Text = String.Empty;
            txtBxSanctionAmount.Text = String.Empty;
            txtBxOutstandingAmount.Text = String.Empty;
            txtBxEMIAmount.Text = String.Empty;
            txtBxTenor.Text = String.Empty;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void Reset()
    {
        try
        {
            //Lead Details
            lblApplnName.Text = String.Empty;

            if (ddlLeadNo != null && ddlLeadNo.SelectedIndex > 0) { ddlLeadNo.ClearSelection(); }
            if (ddlLiabilityBranch != null && ddlLiabilityBranch.SelectedIndex > 0) { ddlLiabilityBranch.ClearSelection(); }

            lblAddress.Text = String.Empty;
            lblContactNo.Text = String.Empty;
            txtBxCustRequestedAmt.Text = String.Empty;

            //Existing ESFB Loan Details
            if (ddlCustCategory != null && ddlCustCategory.SelectedIndex > 0) { ddlCustCategory.ClearSelection(); }
            ResetESFBLoanDetailsGrid();

            if (gvESFBObligations != null && gvESFBObligations.Rows.Count > 0)
            {
                gvESFBObligations.DataSource = null;
                gvESFBObligations.DataBind();
            }

            if (lblTotalEsfbLoanAmount != null && !String.IsNullOrEmpty(lblTotalEsfbLoanAmount.Text)) { lblTotalEsfbLoanAmount.Text = String.Empty; }
            if (lblTotalEsfbLoanOutstandingAmount != null && !String.IsNullOrEmpty(lblTotalEsfbLoanOutstandingAmount.Text)) { lblTotalEsfbLoanOutstandingAmount.Text = String.Empty; }

            //Business Details
            ResetBusinessDetailsGrid();
            if (gvBusinessDetails != null && gvBusinessDetails.Rows.Count > 0)
            {
                gvBusinessDetails.DataSource = null;
                gvBusinessDetails.DataBind();
            }

            if (lblTotalAnnlBusnsTurnOvrBasedOnAssmnt != null && !String.IsNullOrEmpty(lblTotalAnnlBusnsTurnOvrBasedOnAssmnt.Text))
            { lblTotalAnnlBusnsTurnOvrBasedOnAssmnt.Text = String.Empty; }

            //Other Loan Details
            ResetOtherLoanDetailsGrid();
            if (gvOtherLoanDetails != null && gvOtherLoanDetails.Rows.Count > 0)
            {
                gvOtherLoanDetails.DataSource = null;
                gvOtherLoanDetails.DataBind();
            }
            if (lblTotalOutstandingAmt != null && !String.IsNullOrEmpty(lblTotalOutstandingAmt.Text)) { lblTotalOutstandingAmt.Text = String.Empty; }
            if (lblTotalEMIAmt != null && !String.IsNullOrEmpty(lblTotalEMIAmt.Text)) { lblTotalEMIAmt.Text = String.Empty; }

            //Property Ownership Details
            if (ddlPropertyType != null && ddlPropertyType.SelectedIndex > 0) { ddlPropertyType.ClearSelection(); }
            if (ddlOccupancyStatus != null && ddlOccupancyStatus.SelectedIndex > 0) { ddlOccupancyStatus.ClearSelection(); }
            if (ddlUsage != null && ddlUsage.SelectedIndex > 0) { ddlUsage.ClearSelection(); }

            //Other Details
            if (txtBxMnthlIncmFrmBusiness != null) { txtBxMnthlIncmFrmBusiness.Text = String.Empty; }
            if (txtBxMnthlPopOfLoclty != null) { txtBxMnthlPopOfLoclty.Text = String.Empty; }

            //Eligibility Details
            lblElig_TotalAnnlBusnsTurnOvrBasedOnAssmnt.Text = String.Empty;
            lblElig_Limit.Text = String.Empty;
            lblElig_20PercentOfTotalAssessedTurnover.Text = String.Empty;
            lblLimitBasedOnEsfbLoans.Text = String.Empty;
            lblLimitOfTotalAssessedTurnover.Text = String.Empty;
            lblElig_TotalOutstandingAmount.Text = String.Empty;
            lblLimitPostObligatingOutstandingLoans.Text = String.Empty;
            lblFinalESFBEligibleLimit.Text = String.Empty;

            //Submit Panel
            btnSubmit.Enabled = false;
            btnCancel.Enabled = false;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void ClearCAMSessionData()
    {
        try
        {
            if (Session[SessionKeys.MERCHANT_OD_LOAN_CAP] != null) { Session[SessionKeys.MERCHANT_OD_LOAN_CAP] = null; }
            if (Session[SessionKeys.LeadId] != null) { Session[SessionKeys.LeadId] = null; }
            if (Session[SessionKeys.GV_ESFB_LOAN_DETAILS] != null) { Session[SessionKeys.GV_ESFB_LOAN_DETAILS] = null; };
            if (Session[SessionKeys.GV_BUSINESS_DETAILS] != null) { Session[SessionKeys.GV_BUSINESS_DETAILS] = null; };
            if (Session[SessionKeys.GV_OTHER_LOAN_DETAILS] != null) { Session[SessionKeys.GV_OTHER_LOAN_DETAILS] = null; };
            if (Session[SessionKeys.FACTORING_PERCENATGE] != null) { Session[SessionKeys.FACTORING_PERCENATGE] = null; }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    #endregion
}