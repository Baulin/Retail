﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Utilities;
using Tracker;

public partial class Credit_CAM_Uploan : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    int ldid;
    double Apprvamt;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    ClsCommon clscommon = new ClsCommon();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    DataSet dss = new DataSet();
    DataSet dsDisb = new DataSet();
    public static bool blMailStatus = false;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    public int SessionEMP_ID
    {
        get
        {
            int employee_id = -1;

            if (Session["EMP_ID"] != null)
            {
                if (Session["EMP_ID"] != "")
                {
                    employee_id = Convert.ToInt32(Session["EMP_ID"]);

                }
            }

            return employee_id;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnSubmit);
        MICR_NO.Visible = false;
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                txtApprvamt.Enabled = false;
                txtdate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
                if (Session["EMP_CODE"].ToString() == "09126")
                {
                    LoadOffline();
                }
            }
            else
            {
                Response.Redirect("expire.aspx");
            }
        }
    }
    protected void LoadOffline()
    {
        try
        {
            trOffline.Visible = true;

            ds = clscommon.Bind_Manual_employees();
            ddlOffineEmployees.DataSource = ds;
            ddlOffineEmployees.DataTextField = "MAN_EMP_CODE";
            ddlOffineEmployees.DataValueField = "MAN_ID";
            ddlOffineEmployees.DataBind();
            ddlOffineEmployees.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        SqlCommand cmdrsn = new SqlCommand("RTS_SP_Fetch_MR_REASON", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlReason.DataSource = dsrsn;
        ddlReason.DataTextField = "RSN_REASON";
        ddlReason.DataValueField = "RSN_ID";
        ddlReason.DataBind();
        ddlReason.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Credit_CAM_Upload", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            if (ddlArea.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@AR_NAME", "");
            }
            if (ddlBranch.SelectedItem.Text != "--Select--")
            {
                cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@BR_NAME", "");
            }

            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "C");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvApprv.Visible = true;
                gvApprv.DataSource = ds1.Tables[0];
                gvApprv.DataBind();
                /* if (ds1.Tables[0].Rows.Count > 0)
                 {
                     gvApprv.HeaderRow.Font.Bold = true;
                     gvApprv.HeaderRow.Cells[1].Text = "LEAD NO";
                     gvApprv.HeaderRow.Cells[2].Text = "LEAD DATE";
                     gvApprv.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                     gvApprv.HeaderRow.Cells[4].Text = "PD DATE";
                     gvApprv.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                     gvApprv.HeaderRow.Cells[1].Wrap = false;
                     gvApprv.HeaderRow.Cells[2].Wrap = false;
                     gvApprv.HeaderRow.Cells[3].Wrap = false;
                     gvApprv.HeaderRow.Cells[4].Wrap = false;
                     gvApprv.HeaderRow.Cells[5].Wrap = false;
                 }*/
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvApprv.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        bool _passValidation = false;

        try
        {
            clearCreditMemoDatas();
            MICR_NO.Visible = false;
            gvQuerypop.Visible = false;
            gvSampleData.Visible = false;
            gvRPA.Visible = false;
            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                //Session["View"] = "All";
                // gridbindall();
                _passValidation = false;
                uscMsgBox1.AddMessage("Please Select Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                //ddlArea.Enabled = false;
                //   gridbind();
                _passValidation = true;
            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";
                // gridbind();
                _passValidation = true;
            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                // gridbind();
                _passValidation = true;
            }

            if (_passValidation)
            {
                BindqueryGrid();
                foreach (GridViewRow grow in gvApprv.Rows)
                {
                    Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                    int index = grow.RowIndex;
                    if (lblQryResult.Text == "T")
                    {
                        gvApprv.Rows[index].Cells[1].ForeColor = Color.Red;
                        gvApprv.Rows[index].Cells[2].ForeColor = Color.Red;
                        gvApprv.Rows[index].Cells[3].ForeColor = Color.Red;
                        gvApprv.Rows[index].Cells[4].ForeColor = Color.Red;
                        gvApprv.Rows[index].Cells[5].ForeColor = Color.Red;
                    }

                }
                tbSubmit.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void gridbindall()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select distinct LD_NO 'LOAN NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_QUERY E ON A.LD_ID=E.QRY_LD_ID WHERE FT_SENTBY<>'C' AND FT_SENTBY='B' AND FT_SENTTO='C' AND isnull(FT_RDATE,'')<>'' AND isnull(LD_CRAP_MBY,'')='' AND ISNULL(LD_LC_DATE,'')='' ORDER BY LD_NO", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvApprv.DataSource = ds1.Tables[0];
            gvApprv.DataBind();
            if (ds1.Tables[0].Rows.Count > 0)
            {
                gvApprv.HeaderRow.Font.Bold = true;
                gvApprv.HeaderRow.Cells[1].Text = "LEAD NO";
                gvApprv.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvApprv.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvApprv.HeaderRow.Cells[4].Text = "PD DATE";
                gvApprv.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                //gvApprv.HeaderRow.Cells[6].Text = "RESOLVED";

                gvApprv.HeaderRow.Cells[1].Wrap = false;
                gvApprv.HeaderRow.Cells[2].Wrap = false;
                gvApprv.HeaderRow.Cells[3].Wrap = false;
                gvApprv.HeaderRow.Cells[4].Wrap = false;
                gvApprv.HeaderRow.Cells[5].Wrap = false;
                //gvApprv.HeaderRow.Cells[6].Wrap = false;
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select distinct LD_NO 'LOAN NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID  LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_QUERY E ON A.LD_ID=E.QRY_LD_ID WHERE FT_SENTBY<>'C' AND FT_SENTBY='B' AND FT_SENTTO='C' AND isnull(FT_RDATE,'')<>'' AND LD_NO='" + txtLeadno.Text + "' AND isnull(LD_CRAP_MBY,'')='' AND ISNULL(LD_LC_DATE,'')='' OR FT_SENTBY<>'C' AND FT_SENTBY='B' AND FT_SENTTO='C' AND isnull(FT_RDATE,'')<>'' AND AR_NAME='" + ddlArea.SelectedValue.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedValue.ToString() + "' AND isnull(LD_CRAP_MBY,'')='' AND ISNULL(LD_LC_DATE,'')='' ORDER BY LD_NO", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //Panel1.Visible = true;
            gvApprv.DataSource = ds.Tables[0];
            gvApprv.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvApprv.HeaderRow.Font.Bold = true;
                gvApprv.HeaderRow.Cells[1].Text = "LEAD NO";
                gvApprv.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvApprv.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvApprv.HeaderRow.Cells[4].Text = "PD DATE";
                gvApprv.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                //gvApprv.HeaderRow.Cells[6].Text = "RESOLVED";

                gvApprv.HeaderRow.Cells[1].Wrap = false;
                gvApprv.HeaderRow.Cells[2].Wrap = false;
                gvApprv.HeaderRow.Cells[3].Wrap = false;
                gvApprv.HeaderRow.Cells[4].Wrap = false;
                gvApprv.HeaderRow.Cells[5].Wrap = false;
                //gvApprv.HeaderRow.Cells[6].Wrap = false;
            }

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            clearCreditMemoDatas();
            ddlApprv.SelectedIndex = 0;
            ddlReason.SelectedIndex = 0;
            MICR_NO.Visible = true;
            ddlReason.Enabled = false;
            txtApprvamt.Text = "";
            txtComment.Text = "";
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            Label lblLeadID = null;
            Label lblLglAprvl = null;

            foreach (GridViewRow grow in gvApprv.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                bool blStatus = true;
                //LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {

                    lblLeadID = (Label)gvApprv.Rows[index].Cells[1].FindControl("lblLeadID");
                    lblLglAprvl = (Label)gvApprv.Rows[index].Cells[1].FindControl("lblLgAprvl");
                    leadno = gvApprv.Rows[index].Cells[1].Text;
                    appname = gvApprv.Rows[index].Cells[3].Text;
                    pddt = gvApprv.Rows[index].Cells[4].Text;
                    lnamt = gvApprv.Rows[index].Cells[5].Text;
                    //rcvquery = gvApprv.Rows[index].Cells[6].Text;
                    Session["LeadId"] = lblLeadID.Text;
                    Session["Leadno"] = leadno;
                    Session["Loanamt"] = lnamt;
                    Session["Appname"] = appname;

                    gridbind1();
                    BindSampleAndRpa();
                    Bind_Disb_Outstanding();

                    if (leadno.Contains("MSE") && lblLglAprvl.Text != "1")
                    {
                        blStatus = false;
                    }
                    // fillCreditApprvMemo(lblLeadID.Text, con);
                    //if (blStatus)
                    //{
                    if (leadno.Contains("TWL"))
                    {
                        trCreditMemo.Visible = false;
                        trTWLCreditMemo.Visible = true;
                        // fillCreditApprvMemo(lblLeadID.Text, leadno, con);
                        fillTWLCreditApprvMemo(lblLeadID.Text, leadno, con);
                    }
                    else
                    {
                        if (!leadno.Contains("BL"))
                        {
                            trCreditMemo.Visible = true;
                            trTWLCreditMemo.Visible = false;
                            fillCreditApprvMemo(lblLeadID.Text, leadno, con);
                        }
                        else
                        {
                            trCreditMemo.Visible = false;
                            trTWLCreditMemo.Visible = false;
                        }
                    }



                    int emp_aprv_amt = 0;
                    // emp_aprv_amt = clscommon.GetEmpAprvAmountByEmpID(SessionEMP_ID);

                    //bindCreditEmpAprl(emp_aprv_amt);
                    // dvAssign.Visible = true;

                }

                //}
                //if (blStatus)
                //{
                /* bala changes 05/10/2016  gridbind1();
                  BindSampleAndRpa();*/
                gvQuerypop.Visible = true;
                gvSampleData.Visible = true;
                gvRPA.Visible = true;

                gvDisb_Outstanding.Visible = true;

                tbSubmit.Visible = true;
                //lbLeadno.Visible = true;
                //lbAppname.Visible = true;
                //lbPDdate.Visible = true;
                //lbLoanamt.Visible = true;
                ddlApprv.Enabled = true;
                //txtQuery.Enabled = true;
                btnSubmit.Enabled = true;
                btnCancel.Enabled = true;

                Panel1.Visible = true;
                //lbLeadno.Text = leadno.ToString();
                //lbAppname.Text = appname;
                //lbPDdate.Text = pddt;
                //lbLoanamt.Text = lnamt;
                //}
                if (blStatus == false)
                {
                    //btnSubmit.Enabled = true;
                    uscMsgBox1.AddMessage("Legal Approval pending", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
                //else
                //{
                //    btnSubmit.Enabled = false;
                //    uscMsgBox1.AddMessage("Legal Approval pending", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                //}
            }

            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void bindCreditEmpAprl(int emp_aprv_amt)
    {
        DataSet ds = new DataSet();
        ds = clscommon.GetCOCMAmountByEmpID(SessionEMP_ID, Convert.ToDecimal(Session["Loanamt"]));
        ddlAprvEmployee.DataSource = ds;
        ddlAprvEmployee.DataTextField = "EMP_NAME";
        ddlAprvEmployee.DataValueField = "EMP_ID";
        ddlAprvEmployee.DataBind();
        ddlAprvEmployee.Items.Insert(0, new ListItem("--Select--", "0"));

    }
    public void fillCreditApprvMemo(string strLeadID, string strLeadNO, SqlConnection con)
    {
        try
        {
            SqlCommand cmdCrdAprvMemo = new SqlCommand("RTS_SP_FetchCredit_Approval_Memo", con);
            cmdCrdAprvMemo.CommandType = CommandType.StoredProcedure;
            cmdCrdAprvMemo.Parameters.AddWithValue("@LeadID", strLeadID);
            SqlDataAdapter daCrdAprvMemo = new SqlDataAdapter(cmdCrdAprvMemo);
            DataSet dsCrdAprvMemo = new DataSet();
            DataSet dsCrdAprvMemo1 = new DataSet();
            dsCrdAprvMemo1 = clscommon.Get_RTS_SP_CAMFULLDETAILS(strLeadNO, "C");
            daCrdAprvMemo.Fill(dsCrdAprvMemo);
            DataSet dsMemo = new DataSet();
            dsMemo = clscommon.Get_RTS_SP_Fetch_Credit_Memo_Detail_mailer(strLeadNO, "");
            if (dsMemo.Tables[0].Rows.Count == 0)
            {
                if (dsCrdAprvMemo.Tables[0].Rows.Count > 0 && dsCrdAprvMemo.Tables[0] != null)
                {
                    txtProduct.Text = dsCrdAprvMemo.Tables[0].Rows[0]["PR_CODE"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["PR_CODE"].ToString() : "";
                    txtCustname.Text = dsCrdAprvMemo.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                    string strAraAndBranch = dsCrdAprvMemo.Tables[0].Rows[0]["AR_NAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["AR_NAME"].ToString() : "";
                    if (strAraAndBranch != "")
                    {
                        strAraAndBranch = strAraAndBranch + "/";
                    }
                    if (dsCrdAprvMemo1.Tables[0].Rows.Count > 0 && dsCrdAprvMemo1.Tables[0] != null)
                    {
                        txtApplicant.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT FACTORED INCOME"].ToString() : "0.00";
                        txtCoapp1.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT1 FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT1 FACTORED INCOME"].ToString() : "0.00";
                        txtCoapp2.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT2 FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT2 FACTORED INCOME"].ToString() : "0.00";
                        txtCoapp3.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT3 FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT3 FACTORED INCOME"].ToString() : "0.00";
                        txtCoapp4.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT4 FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT4 FACTORED INCOME"].ToString() : "0.00";
                        txtCoapp5.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT5 FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT5 FACTORED INCOME"].ToString() : "0.00";
                        txtLoanAmount.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["RECOMMENDED LOAN AMOUNT"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["RECOMMENDED LOAN AMOUNT"].ToString() : "0.00";
                        txtEMI.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CM_EMI"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_EMI"].ToString() : "";
                        txtRentalIncome.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CM_RINC"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_RINC"].ToString() : "";
                        txtClubIncome.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["TOTAL INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["TOTAL INCOME"].ToString() : "";
                        txtOtherObligation.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["TOTAL OBLIGATION"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["TOTAL OBLIGATION"].ToString() : "";
                        txtInsurPropValue.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CM_IPV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_IPV"].ToString() : "";
                        txtBuildingVal.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_CBV"].ToString() : "0.00";
                        txtLandVal.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_CLV"].ToString() : "0.00";
                        txtIIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_IIR"].ToString() : "0.00";
                        txtFOIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "0.00";
                        txtActIIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["IIR ELGIBILITY"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["IIR ELGIBILITY"].ToString() : "";
                        txtActFIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["FOIR ELIGILIBILITY"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["FOIR ELIGILIBILITY"].ToString() : "";
                        txtLapPropLTV.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CM_LLTV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_LLTV"].ToString() : "";
                        txtTotProbVal.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
                        txtConditon.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "Subject to legal clearance.";
                        txtLCRVal.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
                        txtConstrCost.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";

                        //Property Type
                        if (strLeadNO.Contains("GLP") == true)
                        {
                            string prop_type = dsCrdAprvMemo1.Tables[0].Rows[0]["PROPERTY TYPE"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["PROPERTY TYPE"].ToString() : "";
                            txtProp_Desc.Value = prop_type;
                            txtProp_Percent.Value = clscommon.Get_MR_Property_Percentage(prop_type).ToString();
                        }
                    }
                    strAraAndBranch += dsCrdAprvMemo.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["BR_NAME"].ToString() : "0.00";
                    txtLocation.Text = strAraAndBranch;
                    txtROI.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_INR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_INR"].ToString() : "0.00";
                    // txtTenure.Text = dsCrdAprvMemo.Tables[0].Rows[0]["CAM_TENURE"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["CAM_TENURE"].ToString() : "0.00";
                    txtTenure.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["TENURE"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["TENURE"].ToString() : "0";
                    if (txtTenure.Text != "")
                    {
                        txtTenure.Text = Math.Round(Convert.ToDouble(txtTenure.Text) * 12).ToString();
                    }
                    double presentValue = 100000;
                    if (txtTenure.Text != "" && txtROI.Text != "")
                    {
                        // txtEMI.Text = Math.Round(GetEMI(presentValue, Convert.ToDouble(txtTenure.Text), Convert.ToDouble(txtROI.Text))).ToString();
                    }

                    txtApprovedBy.Text = Session["EMPNAME"] != null ? Session["EMPNAME"].ToString() : "";

                }
            }
            else
            {
                //Start
                if (dsMemo.Tables[0].Rows.Count > 0 && dsMemo.Tables[0] != null)
                {
                    txtProduct.Text = dsCrdAprvMemo.Tables[0].Rows[0]["PR_CODE"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["PR_CODE"].ToString() : "";
                    txtCustname.Text = dsCrdAprvMemo.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                    string strAraAndBranch = dsCrdAprvMemo.Tables[0].Rows[0]["AR_NAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["AR_NAME"].ToString() : "";
                    if (strAraAndBranch != "")
                    {
                        strAraAndBranch = strAraAndBranch + "/";
                    }
                    // if (dsCrdAprvMemo1.Tables[0].Rows.Count > 0 && dsCrdAprvMemo1.Tables[0] != null)
                    // {
                    txtApplicant.Text = dsMemo.Tables[0].Rows[0]["CM_APL"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_APL"].ToString() : "0.00";
                    txtCoapp1.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL1"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL1"].ToString() : "0.00";
                    txtCoapp2.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL2"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL2"].ToString() : "0.00";
                    txtCoapp3.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL3"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL3"].ToString() : "0.00";
                    txtCoapp4.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL4"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL4"].ToString() : "0.00";
                    txtCoapp5.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL5"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL5"].ToString() : "0.00";
                    txtLoanAmount.Text = dsMemo.Tables[0].Rows[0]["CM_LMNT"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LMNT"].ToString() : "0.00";
                    txtEMI.Text = dsMemo.Tables[0].Rows[0]["CM_EMI"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_EMI"].ToString() : "";
                    txtRentalIncome.Text = dsMemo.Tables[0].Rows[0]["CM_RINC"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_RINC"].ToString() : "";
                    txtClubIncome.Text = dsMemo.Tables[0].Rows[0]["CM_CINC"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CINC"].ToString() : "";
                    txtOtherObligation.Text = dsMemo.Tables[0].Rows[0]["CM_OBLIG"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_OBLIG"].ToString() : "";
                    txtInsurPropValue.Text = dsMemo.Tables[0].Rows[0]["CM_IPV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_IPV"].ToString() : "";
                    txtBuildingVal.Text = dsMemo.Tables[0].Rows[0]["CM_BV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_BV"].ToString() : "0.00";
                    txtLandVal.Text = dsMemo.Tables[0].Rows[0]["CM_LV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LV"].ToString() : "0.00";
                    // txtIIR.Text = dsMemo.Tables[0].Rows[0]["CM_IIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_IIR"].ToString() : "0.00";
                    //txtFOIR.Text = dsMemo.Tables[0].Rows[0]["CM_FOIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_FOIR"].ToString() : "0.00";
                    txtIIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_IIR"].ToString() : "0.00";
                    txtFOIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "0.00";

                    txtActIIR.Text = dsMemo.Tables[0].Rows[0]["CM_IIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_IIR"].ToString() : "";
                    txtActFIR.Text = dsMemo.Tables[0].Rows[0]["CM_FOIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_FOIR"].ToString() : "";
                    txtLapPropLTV.Text = dsMemo.Tables[0].Rows[0]["CM_LLTV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LLTV"].ToString() : "";
                    txtTotProbVal.Text = dsMemo.Tables[0].Rows[0]["CM_TPV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_TPV"].ToString() : "";
                    txtConditon.Text = dsMemo.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "Subject to legal clearance.";
                    txtLCRVal.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
                    txtConstrCost.Text = dsMemo.Tables[0].Rows[0]["CM_BV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_BV"].ToString() : "0";
                    //}
                    strAraAndBranch += dsCrdAprvMemo.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["BR_NAME"].ToString() : "0.00";
                    txtLocation.Text = strAraAndBranch;
                    txtROI.Text = dsMemo.Tables[0].Rows[0]["CM_ROI"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_ROI"].ToString() : "0.00";
                    txtTenure.Text = dsMemo.Tables[0].Rows[0]["CM_TNR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_TNR"].ToString() : "0.00";
                    /*  if (txtTenure.Text != "")
                      {
                          txtTenure.Text = Math.Round(Convert.ToDouble(txtTenure.Text) * 12).ToString();
                      }*/
                    double presentValue = 100000;
                    if (txtTenure.Text != "" && txtROI.Text != "")
                    {
                        // txtEMI.Text = Math.Round(GetEMI(presentValue, Convert.ToDouble(txtTenure.Text), Convert.ToDouble(txtROI.Text))).ToString();
                    }

                    txtApprovedBy.Text = Session["EMPNAME"] != null ? Session["EMPNAME"].ToString() : "";
                    txtRemarks.Text = dsMemo.Tables[0].Rows[0]["CM_REMARKS"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_REMARKS"].ToString() : "";
                }
                //END
            }

            if (txtProduct.Text.Contains("MF") || txtProduct.Text.Contains("G-HF") || txtProduct.Text.Contains("EMP-HF"))
            {
                trMFProd1.Visible = true;
                trMFProd2.Visible = true;
                trMFProd3.Visible = true;

                trNonMFProd1.Visible = false;
                trNonMFProd2.Visible = false;
                trNonMFProd3.Visible = false;
                trNonMFProd4.Visible = false;
            }
            else
            {
                trNonMFProd1.Visible = true;
                trNonMFProd2.Visible = true;
                trNonMFProd3.Visible = true;
                trNonMFProd4.Visible = true;

                trMFProd1.Visible = false;
                trMFProd2.Visible = false;
                trMFProd3.Visible = false;
            }
            //Property Type
            if (strLeadNO.Contains("GLP") == true)
            {
                string prop_type = dsCrdAprvMemo1.Tables[0].Rows[0]["PROPERTY TYPE"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["PROPERTY TYPE"].ToString() : "";
                txtProp_Desc.Value = prop_type;
                txtProp_Percent.Value = clscommon.Get_MR_Property_Percentage(prop_type).ToString();
                trPropertyType.Visible = true;
                txtPropType.Text = prop_type;
            }
            else
            {
                trPropertyType.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    //Bala changes 23/12/2015
    public void fillTWLCreditApprvMemo(string strLeadID, string strLeadNO, SqlConnection con)
    {
        try
        {
            SqlCommand cmdCrdAprvMemo = new SqlCommand("RTS_SP_FetchCredit_Approval_Memo", con);
            cmdCrdAprvMemo.CommandType = CommandType.StoredProcedure;
            cmdCrdAprvMemo.Parameters.AddWithValue("@LeadID", strLeadID);
            SqlDataAdapter daCrdAprvMemo = new SqlDataAdapter(cmdCrdAprvMemo);
            DataSet dsCrdAprvMemo = new DataSet();
            DataSet dsCrdAprvMemo1 = new DataSet();
            dsCrdAprvMemo1 = clscommon.Get_RTS_SP_CAMFULLDETAILS_TWL(strLeadNO, "C");
            daCrdAprvMemo.Fill(dsCrdAprvMemo);
            DataSet dsMemo = new DataSet();
            dsMemo = clscommon.Get_RTS_SP_Fetch_Credit_Memo_Detail_mailer(strLeadNO, "");
            if (dsMemo.Tables[0].Rows.Count == 0)
            {
                if (dsCrdAprvMemo.Tables[0].Rows.Count > 0 && dsCrdAprvMemo.Tables[0] != null)
                {
                    txtTWLProduct.Text = dsCrdAprvMemo.Tables[0].Rows[0]["PR_CODE"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["PR_CODE"].ToString() : "";
                    txtTWLCusName.Text = dsCrdAprvMemo.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                    string strAraAndBranch = dsCrdAprvMemo.Tables[0].Rows[0]["AR_NAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["AR_NAME"].ToString() : "";
                    if (strAraAndBranch != "")
                    {
                        strAraAndBranch = strAraAndBranch + "/";
                    }
                    if (dsCrdAprvMemo1.Tables[0].Rows.Count > 0 && dsCrdAprvMemo1.Tables[0] != null)
                    {
                        lblTWLMemberType.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["RELATIONSHIP WITH EQUITASIN"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["RELATIONSHIP WITH EQUITASIN"].ToString() : "";
                        txtTWLApplicant.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT_NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT_NAME"].ToString() : "";
                        txtTWLApplicant1.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT1 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT1 NAME"].ToString() : "";
                        txtTWLApplicant2.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT2 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT2 NAME"].ToString() : "";
                        txtTWLApplicant3.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT3 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT3 NAME"].ToString() : "";
                        txtTWLApplicant4.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT4 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT4 NAME"].ToString() : "";
                        txtTWLApplicant5.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT5 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT5 NAME"].ToString() : "";
                        txtTWLSRCofIncome.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT SOURCE OF INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT SOURCE OF INCOME"].ToString() : "";

                        txtTWLSRCofIncome.Text = txtTWLSRCofIncome.Text.Replace(",", "");
                        txtTWLAplAMT.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT FACTORED INCOME"].ToString() : "0.00";
                        txtTWLCOAplAMT1.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT1 FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT1 FACTORED INCOME"].ToString() : "0.00";
                        txtTWLCOAplAMT2.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT2 FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT2 FACTORED INCOME"].ToString() : "0.00";
                        txtTWLCOAplAMT3.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT3 FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT3 FACTORED INCOME"].ToString() : "0.00";
                        txtTWLCOAplAMT4.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT4 FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT4 FACTORED INCOME"].ToString() : "0.00";
                        txtTWLCOAplAMT5.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT5 FACTORED INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT5 FACTORED INCOME"].ToString() : "0.00";
                        txtTWLLoanAmount.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["RECOMMENDED LOAN AMOUNT"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["RECOMMENDED LOAN AMOUNT"].ToString() : "0.00";
                        txtTWLEMI.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CM_EMI"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_EMI"].ToString() : "";
                        //txtRentalIncome.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CM_RINC"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_RINC"].ToString() : "";
                        txtTWLManufacturer.Text = (dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_NAME"].ToString() : "") + "/" + (dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_MODEL"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_MODEL"].ToString() : "");
                        txtTWLVehicleCost.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_RATE"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_RATE"].ToString() : "0.00";

                        txtTWLClubIncome.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["TOTAL INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["TOTAL INCOME"].ToString() : "";
                        txtTWLOtherObligation.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["TOTAL OBLIGATION"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["TOTAL OBLIGATION"].ToString() : "";
                        txtInsurPropValue.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CM_IPV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_IPV"].ToString() : "";
                        // txtBuildingVal.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_CBV"].ToString() : "0.00";
                        //txtLandVal.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_CLV"].ToString() : "0.00";
                        txtIIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_IIR"].ToString() : "0.00";
                        txtFOIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "0.00";
                        txtActIIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["IIR ELGIBILITY"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["IIR ELGIBILITY"].ToString() : "";
                        txtActFIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["FOIR ELIGILIBILITY"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["FOIR ELIGILIBILITY"].ToString() : "";
                        //Bala changes 12/0/2016 txtTWLLapPropLTV.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
                        txtTotProbVal.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
                        txtConditon.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "Subject to legal clearance.";
                        txtLCRVal.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
                    }
                    strAraAndBranch += dsCrdAprvMemo.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["BR_NAME"].ToString() : "0.00";
                    txtTWLLocation.Text = strAraAndBranch;
                    txtTWLROI.Text = dsCrdAprvMemo.Tables[0].Rows[0]["CAM_INR"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["CAM_INR"].ToString() : "0.00";
                    txtTWLTenure.Text = dsCrdAprvMemo.Tables[0].Rows[0]["CAM_TENURE"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["CAM_TENURE"].ToString() : "";
                    if (txtTWLTenure.Text != "")
                    {
                        txtTWLTenure.Text = Math.Round(Convert.ToDouble(txtTWLTenure.Text) * 12).ToString();
                    }

                    double presentValue = 100000;
                    if (txtTWLTenure.Text != "" && txtTWLROI.Text != "")
                    {
                        // txtEMI.Text = Math.Round(GetEMI(presentValue, Convert.ToDouble(txtTenure.Text), Convert.ToDouble(txtROI.Text))).ToString();
                    }

                    txtTWLApprovedBy.Text = Session["EMPNAME"] != null ? Session["EMPNAME"].ToString() : "";

                }
            }
            else
            {
                //Start
                if (dsMemo.Tables[0].Rows.Count > 0 && dsMemo.Tables[0] != null)
                {
                    txtTWLProduct.Text = dsCrdAprvMemo.Tables[0].Rows[0]["PR_CODE"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["PR_CODE"].ToString() : "";
                    txtTWLCusName.Text = dsCrdAprvMemo.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                    string strAraAndBranch = dsCrdAprvMemo.Tables[0].Rows[0]["AR_NAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["AR_NAME"].ToString() : "";
                    txtTWLSRCofIncome.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT SOURCE OF INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT SOURCE OF INCOME"].ToString() : "";
                    lblTWLMemberType.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["RELATIONSHIP WITH EQUITASIN"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["RELATIONSHIP WITH EQUITASIN"].ToString() : "";

                    if (strAraAndBranch != "")
                    {
                        strAraAndBranch = strAraAndBranch + "/";
                    }
                    // if (dsCrdAprvMemo1.Tables[0].Rows.Count > 0 && dsCrdAprvMemo1.Tables[0] != null)
                    // {
                    txtTWLApplicant.Text = dsMemo.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                    txtTWLApplicant1.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT1 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT1 NAME"].ToString() : "";
                    txtTWLApplicant2.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT2 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT2 NAME"].ToString() : "";
                    txtTWLApplicant3.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT3 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT3 NAME"].ToString() : "";
                    txtTWLApplicant4.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT4 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT4 NAME"].ToString() : "";
                    txtTWLApplicant5.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT5 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT5 NAME"].ToString() : "";
                    txtTWLAplAMT.Text = dsMemo.Tables[0].Rows[0]["CM_APL"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_APL"].ToString() : "0.00";

                    txtTWLCOAplAMT1.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL1"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL1"].ToString() : "0.00";
                    txtTWLCOAplAMT2.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL2"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL2"].ToString() : "0.00";
                    txtTWLCOAplAMT3.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL3"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL3"].ToString() : "0.00";
                    txtTWLCOAplAMT4.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL4"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL4"].ToString() : "0.00";
                    txtTWLCOAplAMT5.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL5"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL5"].ToString() : "0.00";
                    txtTWLLoanAmount.Text = dsMemo.Tables[0].Rows[0]["CM_LMNT"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LMNT"].ToString() : "0.00";
                    txtTWLEMI.Text = dsMemo.Tables[0].Rows[0]["CM_EMI"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_EMI"].ToString() : "";
                    //txtRentalIncome.Text = dsMemo.Tables[0].Rows[0]["CM_RINC"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_RINC"].ToString() : "";
                    txtTWLClubIncome.Text = dsMemo.Tables[0].Rows[0]["CM_CINC"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CINC"].ToString() : "";
                    txtTWLOtherObligation.Text = dsMemo.Tables[0].Rows[0]["CM_OBLIG"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_OBLIG"].ToString() : "";
                    // txtTWLInsurPropValue.Text = dsMemo.Tables[0].Rows[0]["CM_IPV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_IPV"].ToString() : "";
                    // txtBuildingVal.Text = dsMemo.Tables[0].Rows[0]["CM_BV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_BV"].ToString() : "0.00";
                    //txtLandVal.Text = dsMemo.Tables[0].Rows[0]["CM_LV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LV"].ToString() : "0.00";
                    // txtIIR.Text = dsMemo.Tables[0].Rows[0]["CM_IIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_IIR"].ToString() : "0.00";
                    //txtFOIR.Text = dsMemo.Tables[0].Rows[0]["CM_FOIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_FOIR"].ToString() : "0.00";
                    //  txttwlIIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_IIR"].ToString() : "0.00";
                    //  txtFOIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "0.00";

                    txtTWLActIIR.Text = dsMemo.Tables[0].Rows[0]["CM_IIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_IIR"].ToString() : "";
                    txtTWLActFIR.Text = dsMemo.Tables[0].Rows[0]["CM_FOIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_FOIR"].ToString() : "";
                    //Bala changes 12/0/2016 txtTWLLapPropLTV.Text = dsMemo.Tables[0].Rows[0]["CM_LLTV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LLTV"].ToString() : "";


                    //txttwlTotProbVal.Text = dsMemo.Tables[0].Rows[0]["CM_TPV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_TPV"].ToString() : "";
                    txtTWLManufacturer.Text = (dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_NAME"].ToString() : "") + "/" + (dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_MODEL"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_MODEL"].ToString() : "");
                    txtTWLVehicleCost.Text = dsMemo.Tables[0].Rows[0]["CM_LVH_RATE"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LVH_RATE"].ToString() : "0.00";

                    txtTWLCondition.Text = dsMemo.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "Subject to legal clearance.";
                    // txtLCRVal.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
                    //}
                    strAraAndBranch += dsCrdAprvMemo.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["BR_NAME"].ToString() : "0.00";
                    txtTWLLocation.Text = strAraAndBranch;
                    txtTWLROI.Text = dsMemo.Tables[0].Rows[0]["CM_ROI"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_ROI"].ToString() : "0.00";
                    txtTWLTenure.Text = dsMemo.Tables[0].Rows[0]["CM_TNR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_TNR"].ToString() : "0.00";
                    /*  if (txtTenure.Text != "")
                      {
                          txtTenure.Text = Math.Round(Convert.ToDouble(txtTenure.Text) * 12).ToString();
                      }*/
                    double presentValue = 100000;
                    if (txtTWLTenure.Text != "" && txtTWLROI.Text != "")
                    {
                        // txtEMI.Text = Math.Round(GetEMI(presentValue, Convert.ToDouble(txtTenure.Text), Convert.ToDouble(txtROI.Text))).ToString();
                    }

                    txtTWLApprovedBy.Text = Session["EMPNAME"] != null ? Session["EMPNAME"].ToString() : "";
                    txtTWLRemarks.Text = dsMemo.Tables[0].Rows[0]["CM_REMARKS"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_REMARKS"].ToString() : "";
                }
                //END
            }
            if (txtProduct.Text.Contains("MF") || txtProduct.Text.Contains("G-HF") || txtProduct.Text.Contains("EMP-HF"))
            {
                trMFProd1.Visible = true;
                trMFProd2.Visible = true;
                trMFProd3.Visible = true;

                trNonMFProd1.Visible = false;
                trNonMFProd2.Visible = false;
                trNonMFProd3.Visible = false;
                trNonMFProd4.Visible = false;
            }
            else
            {
                trNonMFProd1.Visible = true;
                trNonMFProd2.Visible = true;
                trNonMFProd3.Visible = true;
                trNonMFProd4.Visible = true;

                trMFProd1.Visible = false;
                trMFProd2.Visible = false;
                trMFProd3.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    //PMT Calculation
    public static double GetEMI(double presentValue, double financingPeriod, double interestRatePerYear)
    {
        //interestRatePerYear = 26.00;
        //financingPeriod = 60;
        //presentValue = 100000;
        double a, b, x;
        double monthlyPayment;
        a = (1 + interestRatePerYear / 1200);
        b = financingPeriod;
        x = Math.Pow(a, b);
        x = 1 / x;
        x = 1 - x;
        monthlyPayment = (presentValue) * (interestRatePerYear / 1200) / x;
        return (monthlyPayment);
    }

    public void clearCreditMemoDatas()
    {
        txtProduct.Text = "";
        txtCustname.Text = "";
        txtLocation.Text = "";
        txtApplicant.Text = "";
        txtCoapp1.Text = "";
        txtCoapp2.Text = "";
        txtCoapp3.Text = "";
        txtCoapp4.Text = "";
        txtCoapp5.Text = "";
        txtRentalIncome.Text = "";
        txtClubIncome.Text = "";
        txtOtherObligation.Text = "";
        txtInsurPropValue.Text = "";
        txtBuildingVal.Text = "";
        txtConstrCost.Text = "";
        txtLandVal.Text = "";
        txtTotProbVal.Text = "";
        txtTenure.Text = "";
        txtROI.Text = "";
        txtLoanAmount.Text = "";
        txtEMI.Text = "";
        txtActIIR.Text = "";
        txtActFIR.Text = "";
        txtLCR.Text = "";
        txtLTV.Text = "";
        txtIIRLCR.Text = "";
        txtLapPropLTV.Text = "";
        txtConditon.Text = "";
        txtApprovedBy.Text = "";
        txtRemarks.Text = "";
        txtIIR.Text = "";
        txtFOIR.Text = "";
        txtLCRVal.Text = "";

        clearTWLCreditMemoDatas();

    }
    public void clearTWLCreditMemoDatas()
    {
        txtTWLProduct.Text = "";
        txtTWLCusName.Text = "";
        txtTWLLocation.Text = "";
        txtTWLApplicant.Text = "";
        txtTWLApplicant1.Text = "";
        txtTWLApplicant2.Text = "";
        txtTWLApplicant3.Text = "";
        txtTWLApplicant4.Text = "";
        txtTWLApplicant5.Text = "";
        txtTWLAplAMT.Text = "";
        txtTWLCOAplAMT1.Text = "";
        txtTWLCOAplAMT2.Text = "";
        txtTWLCOAplAMT3.Text = "";
        txtTWLCOAplAMT4.Text = "";
        txtTWLCOAplAMT5.Text = "";



        txtTWLClubIncome.Text = "";
        txtTWLOtherObligation.Text = "";


        txtTWLVehicleCost.Text = "";
        txtTWLTenure.Text = "";
        txtTWLROI.Text = "";
        txtTWLLoanAmount.Text = "";
        txtTWLEMI.Text = "";
        txtTWLActIIR.Text = "";
        txtTWLActFIR.Text = "";


        txtTWLLapPropLTV.Text = "";
        txtTWLCondition.Text = "";
        txtTWLApprovedBy.Text = "";
        txtTWLRemarks.Text = "";


    }
    public void gridbind1()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmd = new SqlCommand("select QRY_QUERY 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "' AND QRY_RSD_BY='C'", con);


            SqlCommand cmd = new SqlCommand("RTS_SP_BindQueryRaised", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LD_NO", Session["Leadno"].ToString());
            cmd.Parameters.AddWithValue("@QRY_RSD_BY", "C");
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dss);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //    //Panel1.Visible = true;
            gvQuerypop.DataSource = dss.Tables[0];
            gvQuerypop.DataBind();
            if (dss.Tables[0].Rows.Count > 0)
            {
                gvQuerypop.HeaderRow.Font.Bold = true;
                gvQuerypop.HeaderRow.Cells[1].Text = "Query Raised";
                gvQuerypop.HeaderRow.Cells[2].Text = "Query Date";
                gvQuerypop.HeaderRow.Cells[3].Text = "Response";
                gvQuerypop.HeaderRow.Cells[4].Text = "Response Date";
                gvQuerypop.HeaderRow.Cells[5].Text = "Resolve Date";

                gvQuerypop.HeaderRow.Cells[1].Wrap = false;
                gvQuerypop.HeaderRow.Cells[2].Wrap = false;
                gvQuerypop.HeaderRow.Cells[3].Wrap = false;
                gvQuerypop.HeaderRow.Cells[4].Wrap = false;
                gvQuerypop.HeaderRow.Cells[5].Wrap = false;

            }
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    public void Bind_Disb_Outstanding()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmd = new SqlCommand("select QRY_QUERY 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "' AND QRY_RSD_BY='C'", con);


            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_ALDF_Disb_Breakup", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LD_NO", Session["Leadno"].ToString());
            cmd.Parameters.AddWithValue("@CAM_TYPE", "C");
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dsDisb);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //    //Panel1.Visible = true;
            gvDisb_Outstanding.DataSource = dsDisb.Tables[0];
            gvDisb_Outstanding.DataBind();
            /* if (dss.Tables[0].Rows.Count > 0)
             {
                 gvDisb_Outstanding.HeaderRow.Font.Bold = true;
                 gvDisb_Outstanding.HeaderRow.Cells[1].Text = "Name of the Non-Institutional lendor";
                 gvDisb_Outstanding.HeaderRow.Cells[2].Text = "Amount of Disbursement to be made";


                 gvDisb_Outstanding.HeaderRow.Cells[1].Wrap = false;
                 gvDisb_Outstanding.HeaderRow.Cells[2].Wrap = false;
               

             }*/
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    public void BindSampleAndRpa()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmd = new SqlCommand("select QRY_QUERY 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "' AND QRY_RSD_BY='C'", con);


            SqlCommand cmd = new SqlCommand("RTS_SP_GETSAMPLANDRPA_DATAS", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LEADID", Session["LeadId"]);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            //if (ds.Tables[0].Rows.Count != 0)
            //{
            //    //Panel1.Visible = true;

            gvSampleData.DataSource = ds1.Tables[0];
            gvSampleData.DataBind();

            gvRPA.DataSource = ds1.Tables[1];
            gvRPA.DataBind();



        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound1(object o, GridViewRowEventArgs e)
    {
        if (dss.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Right;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Credit_ApprovalPopup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
    }
    public void InsertUpdateCreditApproved()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {

            Apprvamt = 0;

            double n = Convert.ToDouble(txtApprvamt.Text != "" ? txtApprvamt.Text : "0");

            if (txtApprvamt.Text != "")
            {
                Apprvamt = Convert.ToDouble(txtApprvamt.Text);
            }

            if (ddlApprv.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Approved/Rejected", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlApprv.SelectedValue.ToString() == "Approved" && txtApprvamt.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter Approved Amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlApprv.SelectedValue.ToString() == "Rejected" && ddlReason.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            // Changes by Vijayan
            else if (ddlApprv.SelectedValue.ToString() == "Approved" && Apprvamt != Convert.ToDouble(txtLoanAmount.Text))
            {
                uscMsgBox1.AddMessage("Approved amount should be equal than Loan amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //End
            else if (ddlApprv.SelectedValue.ToString() == "Approved" && Apprvamt > Convert.ToDouble(Session["Loanamt"]))
            {
                uscMsgBox1.AddMessage("Approved amount is more than Loan amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (gvRPA.Rows.Count > 0 && ChkVacantLand.Checked && n > 250000)
            {
                uscMsgBox1.AddMessage("RPA Initiated  for Vacand Land,Approved amount must be less than 250000", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //else if (rdnUrban.Checked == false && rdnRural.Checked == false)
            //{
            //    uscMsgBox1.AddMessage("Please Select any one of Area type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else
            {


                ldid = Convert.ToInt32(Session["LeadId"]);

                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = "select count(*) as count from LSD_QUERY where QRY_LD_ID='" + ldid + "' and QRY_RSD_BY='C' and QRY_RSL_DATE is NULL";

                int nCount = ((int)cmd.ExecuteScalar());

                //   con.Close();
                int nCount1 = 0;
                /*Bala changes 16/12/2016 
               SqlCommand cmd1 = con.CreateCommand();
                cmd1.CommandText = "select count(*) as count from LSD_RPA where RPA_LD_ID='" + ldid + "' and  RPA_VDATE is NULL ";

                nCount1 = ((int)cmd1.ExecuteScalar());*/
                nCount1 = clscommon.GetRPACount(ldid);

                int nCount2 = 0;
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandText = "select count(*) as count from LSD_CAM_SAMPLE where SL_LD_ID='" + ldid + "' and  SL_RAMT IS NULL ";

                nCount2 = ((int)cmd2.ExecuteScalar());


                int nCount3 = 0;
                SqlCommand cmd3 = con.CreateCommand();
                cmd3.CommandText = "select count(*) as count from LSD_VALUAR where LV_LD_ID='" + ldid + "' and  LV_RDATE IS NULL ";

                nCount3 = ((int)cmd3.ExecuteScalar());

                if (nCount != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage("" + nCount + " Query pending, To Continue Please Enter Comments...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                //else if (nCount1 != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "")
                else if (nCount1 != 0 && ddlApprv.SelectedItem.ToString() == "Approved")
                {
                    uscMsgBox1.AddMessage(" RPA pending,Credit approval can't proceed...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                else if (nCount2 != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage(" Sampling pending, Credit approval can't proceed...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                else if (nCount3 != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "" && txtProduct.Text.Contains("G"))
                {
                    uscMsgBox1.AddMessage(" Technical Initiation pending,Credit approval can't proceed...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                else if (ddlApprv.SelectedItem.Text == "Approved" && txtActIIR.Text == "")
                {
                    uscMsgBox1.AddMessage(" Please enter credit memo details...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else
                {

                    bool blStatus = true;
                    if (ddlApprv.SelectedItem.Text == "Approved")
                    {
                        if (Session["Leadno"].ToString().Contains("TWL"))
                        {
                            blStatus = InsertCamMemo_TWL(con);
                        }
                        else
                        {
                            if (!Session["Leadno"].ToString().Contains("BL"))
                            {
                                blStatus = InsertCamMemo(con);
                            }
                        }
                    }
                    if (blStatus == true)
                    {
                        SqlCommand cmdinsert = new SqlCommand("RTS_SP_Update_Credit_Approval", con);
                        cmdinsert.CommandType = CommandType.StoredProcedure;
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_APRL", ddlApprv.SelectedIndex.ToString());
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_AMT", txtApprvamt.Text != "" ? txtApprvamt.Text : "0");
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_CMTS", txtComment.Text);
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_MBY", Session["ID"].ToString());
                        cmdinsert.Parameters.AddWithValue("@LD_ID", ldid);
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_RSN_ID", ddlReason.SelectedValue.ToString());
                        cmdinsert.Parameters.AddWithValue("@LD_RCARDNO", txt_Ration_card_no.Text.ToUpper());

                        cmdinsert.ExecuteNonQuery();

                        //BALA Changes starts 21/01/2017
                        if (ddlOffineEmployees.SelectedValue != "0")
                        {
                            clscommon.UpdateCreditManualApproval(ldid, Convert.ToInt32(ddlOffineEmployees.SelectedValue));
                        }

                        if (!Session["Leadno"].ToString().Contains("BL"))
                        {
                            sendMail(con);
                        }
                        else
                        {
                            blMailStatus = true;
                        }

                        SqlCommand cmdMediIns = new SqlCommand("RTS_SP_FETCH_MEDDETS", con);
                        cmdMediIns.CommandType = CommandType.StoredProcedure;
                        cmdMediIns.Parameters.AddWithValue("@LD_ID", ldid);
                        SqlDataAdapter daMedInit = new SqlDataAdapter(cmdMediIns);
                        DataSet dsMedInit = new DataSet();
                        daMedInit.Fill(dsMedInit);
                        if (dsMedInit.Tables[0] != null && dsMedInit.Tables[0].Rows.Count > 0)
                        {
                            double dblAmount = dsMedInit.Tables[0].Rows[0]["LD_CRAP_AMT"] != DBNull.Value ? Convert.ToDouble(dsMedInit.Tables[0].Rows[0]["LD_CRAP_AMT"]) : 0.0;
                            int age = dsMedInit.Tables[0].Rows[0]["CI_AGE"] != DBNull.Value ? Convert.ToInt32(dsMedInit.Tables[0].Rows[0]["CI_AGE"]) : 0;
                            int Tenure = dsMedInit.Tables[0].Rows[0]["CAM_TENURE"] != DBNull.Value ? Convert.ToInt32(dsMedInit.Tables[0].Rows[0]["CAM_TENURE"]) : 0;
                            string Name = dsMedInit.Tables[0].Rows[0]["CI_NAME"] != DBNull.Value ? Convert.ToString(dsMedInit.Tables[0].Rows[0]["CI_NAME"]) : "";
                            string ContactNumber = dsMedInit.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? Convert.ToString(dsMedInit.Tables[0].Rows[0]["LD_ACNO"]) : "";
                            bool blStatusVal = false;
                            if (dblAmount > 500000 && dblAmount <= 750000 && age > 55)
                            {
                                blStatusVal = true;
                            }
                            else if (dblAmount > 750000 && dblAmount <= 1000000 && age > 50)
                            {
                                blStatusVal = true;
                            }
                            else if (dblAmount > 1000000 && dblAmount <= 1500000 && age > 40)
                            {
                                blStatusVal = true;
                            }
                            else if (dblAmount > 1500000)
                            {
                                blStatusVal = true;
                            }
                            if (blStatusVal)
                            {
                                sendMedcInitmail(Name, dblAmount.ToString(), Tenure.ToString(), age.ToString(), ContactNumber.ToString());
                            }
                        }

                        string strMailStatus = "";
                        string strSuccessMsg = "";
                        if (blMailStatus == true)
                        {
                            strMailStatus = "Successfully";
                        }
                        else
                        {
                            strMailStatus = "Failed";
                        }
                        strSuccessMsg = Session["Leadno"].ToString() + " " + ddlApprv.SelectedItem.ToString() + " Successfully" + " <br/> Mail Sent " + strMailStatus + "  ";
                        strSuccessMsg += "<br/> Mail To: " + toID + " ; CC To: " + ccID + " ";
                        if (txtApprvamt.Text != "")
                        {
                            strSuccessMsg += "<br/>Credit Approved Amount : " + txtApprvamt.Text + " ";
                        }
                        if (txtComment.Text != "")
                        {
                            strSuccessMsg += "<br/>Credit Comments :" + txtComment.Text + "";
                        }


                        uscMsgBox1.AddMessage(strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        //  ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('MailStatusPopup.aspx?ApprvSt=" + ddlApprv.SelectedItem.ToString() + "&MailStatus=" + blMailStatus + "&from=" + fromID + "&To=" + toID + "&cc=" + ccID + ",&bcc=" + bcc2ID + "&body=" + strMailBody + "', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
                        if (ChkVacantLand.Checked)
                        {
                            //bool blStatus =   
                            InsertRPA(con);
                        }
                        BindqueryGrid();
                        tbSubmit.Visible = false;
                        ddlOffineEmployees.SelectedValue = "0";
                        lbLeadno.Text = "";
                        lbAppname.Text = "";
                        lbPDdate.Text = "";
                        lbLoanamt.Text = "";
                        txtApprvamt.Text = "";
                        txtComment.Text = "";
                        ddlApprv.SelectedIndex = 0;
                        ddlReason.SelectedIndex = 0;
                        ddlApprv.Enabled = false;
                        ddlReason.Enabled = false;
                        btnSubmit.Enabled = false;
                        btnCancel.Enabled = false;
                        gvQuerypop.Visible = false;
                        gvSampleData.Visible = false;
                        gvRPA.Visible = false;
                        clearCreditMemoDatas();
                        trCreditMemo.Visible = false;
                        trTWLCreditMemo.Visible = false;
                        Panel1.Visible = false;
                    }

                }
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    public void InsertTWLUpdateCreditApproved()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {


            Apprvamt = 0;

            double n = Convert.ToDouble(txtApprvamt.Text != "" ? txtApprvamt.Text : "0");

            if (txtApprvamt.Text != "")
            {
                Apprvamt = Convert.ToDouble(txtApprvamt.Text);
            }

            if (ddlApprv.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Approved/Rejected", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlApprv.SelectedValue.ToString() == "Approved" && txtApprvamt.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter Approved Amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlApprv.SelectedValue.ToString() == "Rejected" && ddlReason.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            // Changes by Vijayan
            else if (ddlApprv.SelectedValue.ToString() == "Approved" && Apprvamt != Convert.ToDouble(txtTWLLoanAmount.Text))
            {
                uscMsgBox1.AddMessage("Approved amount should be equal than Loan amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //End
            else if (ddlApprv.SelectedValue.ToString() == "Approved" && Apprvamt > Convert.ToDouble(Session["Loanamt"]))
            {
                uscMsgBox1.AddMessage("Approved amount is more than Loan amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (gvRPA.Rows.Count > 0 && ChkVacantLand.Checked && n > 250000)
            {
                uscMsgBox1.AddMessage("RPA Initiated  for Vacand Land,Approved amount must be less than 250000", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //else if (rdnUrban.Checked == false && rdnRural.Checked == false)
            //{
            //    uscMsgBox1.AddMessage("Please Select any one of Area type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else
            {


                ldid = Convert.ToInt32(Session["LeadId"]);

                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = "select count(*) as count from LSD_QUERY where QRY_LD_ID='" + ldid + "' and QRY_RSD_BY='C' and QRY_RSL_DATE is NULL";

                int nCount = ((int)cmd.ExecuteScalar());

                //   con.Close();
                int nCount1 = 0;
                /*Bala changes 16/12/2016 
                SqlCommand cmd1 = con.CreateCommand();
                 cmd1.CommandText = "select count(*) as count from LSD_RPA where RPA_LD_ID='" + ldid + "' and  RPA_VDATE is NULL ";

                 nCount1 = ((int)cmd1.ExecuteScalar());*/
                nCount1 = clscommon.GetRPACount(ldid);

                int nCount2 = 0;
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandText = "select count(*) as count from LSD_CAM_SAMPLE where SL_LD_ID='" + ldid + "' and  SL_RAMT IS NULL ";

                nCount2 = ((int)cmd2.ExecuteScalar());


                int nCount3 = 0;
                SqlCommand cmd3 = con.CreateCommand();
                cmd3.CommandText = "select count(*) as count from LSD_VALUAR where LV_LD_ID='" + ldid + "' and  LV_RDATE IS NULL ";

                nCount3 = ((int)cmd3.ExecuteScalar());

                if (nCount != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage("" + nCount + " Query pending, To Continue Please Enter Comments...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                //else if (nCount1 != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "")
                else if (nCount1 != 0 && ddlApprv.SelectedItem.ToString() == "Approved")
                {
                    uscMsgBox1.AddMessage(" RPA pending,Credit approval can't proceed...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                else if (nCount2 != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage(" Sampling pending,Credit approval can't proceed...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                else if (nCount3 != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "" && txtProduct.Text.Contains("G"))
                {
                    uscMsgBox1.AddMessage(" Technical Initiation pending,Credit approval can't proceed...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                else if (ddlApprv.SelectedItem.Text == "Approved" && txtTWLActIIR.Text == "")
                {
                    uscMsgBox1.AddMessage(" Please enter credit memo details...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else
                {

                    bool blStatus = true;
                    if (ddlApprv.SelectedItem.Text == "Approved")
                    {
                        if (Session["Leadno"].ToString().Contains("TWL"))
                        {
                            blStatus = InsertCamMemo_TWL(con);
                        }
                        else
                        {
                            blStatus = InsertCamMemo(con);
                        }
                    }
                    if (blStatus == true)
                    {
                        SqlCommand cmdinsert = new SqlCommand("RTS_SP_Update_Credit_Approval", con);
                        cmdinsert.CommandType = CommandType.StoredProcedure;
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_APRL", ddlApprv.SelectedIndex.ToString());
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_AMT", txtApprvamt.Text != "" ? txtApprvamt.Text : "0");
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_CMTS", txtComment.Text);
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_MBY", Session["ID"].ToString());
                        cmdinsert.Parameters.AddWithValue("@LD_ID", ldid);
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_RSN_ID", ddlReason.SelectedValue.ToString());
                        cmdinsert.Parameters.AddWithValue("@LD_RCARDNO", txt_Ration_card_no.Text.ToUpper());

                        cmdinsert.ExecuteNonQuery();


                        //BALA Changes starts 21/01/2017
                        if (ddlOffineEmployees.SelectedValue != "0")
                        {
                            clscommon.UpdateCreditManualApproval(ldid, Convert.ToInt32(ddlOffineEmployees.SelectedValue));
                        }

                        sendMail(con);

                        SqlCommand cmdMediIns = new SqlCommand("RTS_SP_FETCH_MEDDETS", con);
                        cmdMediIns.CommandType = CommandType.StoredProcedure;
                        cmdMediIns.Parameters.AddWithValue("@LD_ID", ldid);
                        SqlDataAdapter daMedInit = new SqlDataAdapter(cmdMediIns);
                        DataSet dsMedInit = new DataSet();
                        daMedInit.Fill(dsMedInit);
                        if (dsMedInit.Tables[0] != null && dsMedInit.Tables[0].Rows.Count > 0)
                        {
                            double dblAmount = dsMedInit.Tables[0].Rows[0]["LD_CRAP_AMT"] != DBNull.Value ? Convert.ToDouble(dsMedInit.Tables[0].Rows[0]["LD_CRAP_AMT"]) : 0.0;
                            int age = dsMedInit.Tables[0].Rows[0]["CI_AGE"] != DBNull.Value ? Convert.ToInt32(dsMedInit.Tables[0].Rows[0]["CI_AGE"]) : 0;
                            int Tenure = dsMedInit.Tables[0].Rows[0]["CAM_TENURE"] != DBNull.Value ? Convert.ToInt32(dsMedInit.Tables[0].Rows[0]["CAM_TENURE"]) : 0;
                            string Name = dsMedInit.Tables[0].Rows[0]["CI_NAME"] != DBNull.Value ? Convert.ToString(dsMedInit.Tables[0].Rows[0]["CI_NAME"]) : "";
                            string ContactNumber = dsMedInit.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? Convert.ToString(dsMedInit.Tables[0].Rows[0]["LD_ACNO"]) : "";

                            bool blStatusVal = false;
                            if (dblAmount > 500000 && dblAmount <= 750000 && age > 55)
                            {
                                blStatusVal = true;
                            }
                            else if (dblAmount > 750000 && dblAmount <= 1000000 && age > 50)
                            {
                                blStatusVal = true;
                            }
                            else if (dblAmount > 1000000 && dblAmount <= 1500000 && age > 40)
                            {
                                blStatusVal = true;
                            }
                            else if (dblAmount > 1500000)
                            {
                                blStatusVal = true;
                            }
                            if (blStatusVal)
                            {
                                sendMedcInitmail(Name, dblAmount.ToString(), Tenure.ToString(), age.ToString(), ContactNumber.ToString());
                            }
                        }

                        string strMailStatus = "";
                        string strSuccessMsg = "";
                        if (blMailStatus == true)
                        {
                            strMailStatus = "Successfully";
                        }
                        else
                        {
                            strMailStatus = "Failed";
                        }
                        strSuccessMsg = Session["Leadno"].ToString() + " " + ddlApprv.SelectedItem.ToString() + " Successfully" + " <br/> Mail Sent " + strMailStatus + "  ";
                        strSuccessMsg += "<br/> Mail To: " + toID + " ; CC To: " + ccID + " ";
                        if (txtApprvamt.Text != "")
                        {
                            strSuccessMsg += "<br/>Credit Approved Amount : " + txtApprvamt.Text + " ";
                        }
                        if (txtComment.Text != "")
                        {
                            strSuccessMsg += "<br/>Credit Comments :" + txtComment.Text + "";
                        }


                        uscMsgBox1.AddMessage(strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        //  ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('MailStatusPopup.aspx?ApprvSt=" + ddlApprv.SelectedItem.ToString() + "&MailStatus=" + blMailStatus + "&from=" + fromID + "&To=" + toID + "&cc=" + ccID + ",&bcc=" + bcc2ID + "&body=" + strMailBody + "', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
                        if (ChkVacantLand.Checked)
                        {
                            //bool blStatus =   
                            InsertRPA(con);
                        }
                        BindqueryGrid();
                        tbSubmit.Visible = false;
                        ddlOffineEmployees.SelectedValue = "0";
                        lbLeadno.Text = "";
                        lbAppname.Text = "";
                        lbPDdate.Text = "";
                        lbLoanamt.Text = "";
                        txtApprvamt.Text = "";
                        txtComment.Text = "";
                        ddlApprv.SelectedIndex = 0;
                        ddlReason.SelectedIndex = 0;
                        ddlApprv.Enabled = false;
                        ddlReason.Enabled = false;
                        btnSubmit.Enabled = false;
                        btnCancel.Enabled = false;
                        gvQuerypop.Visible = false;
                        gvSampleData.Visible = false;
                        gvRPA.Visible = false;
                        clearCreditMemoDatas();
                        trCreditMemo.Visible = false;
                        trTWLCreditMemo.Visible = false;
                        Panel1.Visible = false;
                    }

                }
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void clear()
    {
        BindqueryGrid();
        lbLeadno.Text = "";
        lbAppname.Text = "";
        lbPDdate.Text = "";
        lbLoanamt.Text = "";
        txtApprvamt.Text = "";
        txtComment.Text = "";
        ddlApprv.SelectedIndex = 0;
        ddlReason.SelectedIndex = 0;
        ddlApprv.Enabled = false;
        ddlReason.Enabled = false;
        btnSubmit.Enabled = false;
        btnCancel.Enabled = false;
        gvQuerypop.Visible = false;
        gvSampleData.Visible = false;
        gvRPA.Visible = false;
        clearCreditMemoDatas();
    }
    public void sendMedcInitmail(string strName, string stAmnt, string strTenure, string strAge, string contactNo)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            SqlCommand cmddet1 = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_ADDRESS,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV',LC.CAM_PCS from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID JOIN LSD_CAM LC ON A.LD_ID = LC.CAM_LD_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "'", con);
            SqlDataAdapter dadet1 = new SqlDataAdapter(cmddet1);
            DataSet dsdet1 = new DataSet();
            dadet1.Fill(dsdet1);

            string area = Session["AREANAME"].ToString();
            string brnch = "";
            string ldno = "", apname = "";
            string strAddress = "";
            if (dsdet1 != null)
            {
                brnch = dsdet1.Tables[0].Rows[0]["BR_NAME"].ToString();
                ldno = Session["Leadno"].ToString();

                apname = dsdet1.Tables[0].Rows[0]["LD_APNAME"].ToString();
                strAddress = dsdet1.Tables[0].Rows[0]["LD_ADDRESS"].ToString();
                //apmobile =  dsdet.Tables[0].Rows[0]["LD_APNAME"].ToString();
                //gv = Convert.ToDouble(txtGuideline.Text).ToString("F");
                //landarea = Convert.ToDouble(txtLandArea.Text.Trim()).ToString("F");
            }



            con.Open();
            /////// mail ///////////
            //  strMailDetail = "";

            SqlCommand cmddet = new SqlCommand("select * from MR_BRANCH where BR_NAME='" + Session["UNITNAME"].ToString() + "'", con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);




            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT * FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);

            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_HO"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_HO"].ToString() : "rts-helpdesk@equitasbank.com";
                //cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                //bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                //bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
            }

            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            fromID = "RTS Alerts";
            toID = to;//"ManimaranK@equitasbank.com";
            //bcc2ID = "shankarg@equitasbank.com";
            //ccID = "rts-helpdesk@equitasbank.com";

            // toID = "shankarg@equitasbank.com";
            // To Auto mail ///////
            System.Threading.Thread threadSendMails;




            threadSendMails = new System.Threading.Thread(delegate()
            {

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the Detail for Medical Intiation. <br/><br/>";
                BodyTxt = BodyTxt + "<table width='40%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Policy No **</b></td><td style='whiteSpace:nowrap;' ></td></tr>";
                if (txtProduct.Text.Contains("GHF"))
                {
                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Policy Holder Name **</b></td><td style='whiteSpace:nowrap;' >Equitas Housing Finance Pvt. Ltd</td></tr>";
                }
                else
                {
                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Policy Holder Name **</b></td><td style='whiteSpace:nowrap;' >Equitas Finance Pvt. Ltd</td></tr>";
                }

                BodyTxt = BodyTxt + "<tr ><td ><b>Lead No.</b></td><td style='whiteSpace:nowrap;' >" + ldno + "</td></tr>";
                BodyTxt = BodyTxt + "<tr><td ><b>Area Name</b></td><td >" + area + "</td></tr>";
                BodyTxt = BodyTxt + "<tr><td ><b>Branch Name</b></td><td >" + brnch + "</td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='16%'><b>Product</b></td><td> " + txtProduct.Text + " </td></tr>";
                BodyTxt = BodyTxt + "<tr><td ><b>Name Of the Insured Person</b></td><td >" + strName + "</td></tr>";
                BodyTxt = BodyTxt + "<tr><td ><b>Property Address</b></td><td >" + strAddress + "</td></tr>";
                BodyTxt = BodyTxt + "<tr><td ><b>Loan Amnt</b></td><td >" + stAmnt + "</td></tr>";
                BodyTxt = BodyTxt + "<tr><td ><b>Tenure</b></td><td >" + strTenure + "</td></tr>";
                BodyTxt = BodyTxt + "<tr><td ><b>Age</b></td><td >" + strAge + "</td></tr>";
                BodyTxt = BodyTxt + "<tr><td ><b>Contact No.</b></td><td >" + contactNo + "</td></tr>";
                BodyTxt = BodyTxt + "</table><br/>";

                BodyTxt = BodyTxt + "<br/>Please initiate and submit the report as per the prescribed TAT. <br/><br/><br/>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'>Thanks and Regards,<br/>Risk Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";

                blMailStatus = EmailManager.sendemail(toID, "RTS Alerts", "", "", "Medical Initiated for LEAD NO: " + Session["Leadno"].ToString() + " " + brnch + " Branch", BodyTxt, "", true);


            });

            threadSendMails.IsBackground = true;

            threadSendMails.Start();
            System.Threading.Thread.Sleep(5000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally { con.Close(); }
    }
    public bool InsertRPA(SqlConnection con)
    {
        bool blStatus = false;
        try
        {
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertRPA", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@LD_ID", ldid);
            cmdinsert.Parameters.AddWithValue("@CBY", Session["ID"].ToString());

            int n = cmdinsert.ExecuteNonQuery();
            if (n > 0)
            {
                blStatus = true;
                sendRPAMail();
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Fail to Save Credit Memo Detatils", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        return blStatus;

    }

    public bool InsertCamMemo(SqlConnection con1)
    {
        bool blStatus = false;
        SqlConnection con = new SqlConnection(strcon);
        try
        {

            con.Open();
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_Update_CAM_Memo", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            //cmdinsert.Parameters.AddWithValue("@LD_ID", ldid);
            ldid = Convert.ToInt32(Session["LeadId"]);
            cmdinsert.Parameters.AddWithValue("@LD_ID", ldid);
            //cmdinsert.Parameters.AddWithValue("@CM_DATE", "");
            cmdinsert.Parameters.AddWithValue("@CM_VLAND", ChkVacantLand.Checked ? 1 : 0);
            cmdinsert.Parameters.AddWithValue("@CM_APL", txtApplicant.Text != "" ? Convert.ToDouble(txtApplicant.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_CAPL1", txtCoapp1.Text != "" ? Convert.ToDouble(txtCoapp1.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_CAPL2", txtCoapp2.Text != "" ? Convert.ToDouble(txtCoapp2.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_CAPL3", txtCoapp3.Text != "" ? Convert.ToDouble(txtCoapp3.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_CAPL4", txtCoapp4.Text != "" ? Convert.ToDouble(txtCoapp4.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_CAPL5", txtCoapp5.Text != "" ? Convert.ToDouble(txtCoapp5.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_RINC", txtRentalIncome.Text != "" ? Convert.ToDouble(txtRentalIncome.Text) : 0.0);

            cmdinsert.Parameters.AddWithValue("@CM_CINC", txtClubIncome.Text != "" ? Convert.ToDouble(txtClubIncome.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_OBLIG", txtOtherObligation.Text != "" ? Convert.ToDouble(txtOtherObligation.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_IPV", txtInsurPropValue.Text != "" ? Convert.ToDouble(txtInsurPropValue.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_BV", txtBuildingVal.Text != "" ? Convert.ToDouble(txtBuildingVal.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_LV", txtLandVal.Text != "" ? Convert.ToDouble(txtLandVal.Text) : 0.0);

            cmdinsert.Parameters.AddWithValue("@CM_TPV", txtTotProbVal.Text != "" ? Convert.ToDouble(txtTotProbVal.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_CC", txtConstrCost.Text != "" ? Convert.ToDouble(txtConstrCost.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_TNR", txtTenure.Text != "" ? Convert.ToDouble(txtTenure.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_ROI", txtROI.Text != "" ? Convert.ToDouble(txtROI.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_LMNT", txtLoanAmount.Text != "" ? Convert.ToDouble(txtLoanAmount.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_EMI", txtEMI.Text != "" ? Convert.ToDouble(txtEMI.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_IIR", txtActIIR.Text != "" ? Convert.ToDouble(txtActIIR.Text) : 0.00);
            cmdinsert.Parameters.AddWithValue("@CM_FOIR", txtActFIR.Text != "" ? Convert.ToDouble(txtActFIR.Text) : 0.00);
            cmdinsert.Parameters.AddWithValue("@CM_LCR", txtLCR.Text != "" ? Convert.ToDouble(txtLCR.Text) : 0.00);
            cmdinsert.Parameters.AddWithValue("@CM_LTV", txtLTV.Text != "" ? Convert.ToDouble(txtLTV.Text) : 0.00);
            cmdinsert.Parameters.AddWithValue("@CM_IIR_LCR", txtIIRLCR.Text != "" ? Convert.ToDouble(txtIIRLCR.Text) : 0.00);
            cmdinsert.Parameters.AddWithValue("@CM_LLTV", txtLapPropLTV.Text != "" ? Convert.ToDouble(txtLapPropLTV.Text) : 0.00);

            /* Bala changes starts 10/11/2016
             * string strCondition = "";
              if (txt_MICR.Text != "" && gv_MICR.Rows.Count == 0)
              {
                  strCondition = txtConditon.Text != "" ? txtConditon.Text + " ,New Bank A/C Required" : "New Bank A/C Required";
                  cmdinsert.Parameters.AddWithValue("@CM_CREDIT", strCondition);
              }
              else
              {
                  cmdinsert.Parameters.AddWithValue("@CM_CREDIT", txtConditon.Text);
              }
          
              */
            cmdinsert.Parameters.AddWithValue("@CM_CREDIT", txtConditon.Text);
            // * bala changes ends 10/11/2016
            cmdinsert.Parameters.AddWithValue("@CM_REMARKS", txtRemarks.Text);
            cmdinsert.Parameters.AddWithValue("@USERID", Session["ID"].ToString());

            DataSet dsMemo = new DataSet();
            dsMemo = clscommon.Get_RTS_SP_Fetch_Credit_Memo_Detail_mailer(Session["Leadno"].ToString(), "");
            if (dsMemo.Tables[0].Rows.Count > 0)
            {
                cmdinsert.Parameters.AddWithValue("@UTYPE", "UPDATE");
            }

            int n = cmdinsert.ExecuteNonQuery();
            if (n > 0)
            {
                blStatus = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Fail to Save Credit Memo Detatils", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally { con.Close(); }
        return blStatus;

    }
    public bool InsertCamMemo_TWL(SqlConnection con1)
    {
        SqlConnection con = new SqlConnection(strcon);
        bool blStatus = false;
        try
        {

            con.Open();
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_Update_CAM_Memo", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            //cmdinsert.Parameters.AddWithValue("@LD_ID", ldid);
            ldid = Convert.ToInt32(Session["LeadId"]);
            cmdinsert.Parameters.AddWithValue("@LD_ID", ldid);
            //cmdinsert.Parameters.AddWithValue("@CM_DATE", "");
            // cmdinsert.Parameters.AddWithValue("@CM_VLAND", ChkVacantLand.Checked ? 1 : 0);
            cmdinsert.Parameters.AddWithValue("@CM_APL", txtTWLAplAMT.Text != "" ? Convert.ToDouble(txtTWLAplAMT.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_CAPL1", txtTWLCOAplAMT1.Text != "" ? Convert.ToDouble(txtTWLCOAplAMT1.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_CAPL2", txtTWLCOAplAMT2.Text != "" ? Convert.ToDouble(txtTWLCOAplAMT2.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_CAPL3", txtTWLCOAplAMT3.Text != "" ? Convert.ToDouble(txtTWLCOAplAMT3.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_CAPL4", txtTWLCOAplAMT4.Text != "" ? Convert.ToDouble(txtTWLCOAplAMT4.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_CAPL5", txtTWLCOAplAMT5.Text != "" ? Convert.ToDouble(txtTWLCOAplAMT5.Text) : 0.0);
            //cmdinsert.Parameters.AddWithValue("@CM_RINC", txtRentalIncome.Text != "" ? Convert.ToDouble(txtRentalIncome.Text) : 0.0);

            cmdinsert.Parameters.AddWithValue("@CM_CINC", txtTWLClubIncome.Text != "" ? Convert.ToDouble(txtTWLClubIncome.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_OBLIG", txtTWLOtherObligation.Text != "" ? Convert.ToDouble(txtTWLOtherObligation.Text) : 0.0);
            //cmdinsert.Parameters.AddWithValue("@CM_IPV", txtInsurPropValue.Text != "" ? Convert.ToDouble(txtInsurPropValue.Text) : 0.0);
            // cmdinsert.Parameters.AddWithValue("@CM_BV", txtBuildingVal.Text != "" ? Convert.ToDouble(txtBuildingVal.Text) : 0.0);
            // cmdinsert.Parameters.AddWithValue("@CM_LV", txtLandVal.Text != "" ? Convert.ToDouble(txtLandVal.Text) : 0.0);

            cmdinsert.Parameters.AddWithValue("@CM_LVH_RATE", txtTWLVehicleCost.Text != "" ? Convert.ToDouble(txtTWLVehicleCost.Text) : 0.0);
            //cmdinsert.Parameters.AddWithValue("@CM_CC", txtConstrCost.Text != "" ? Convert.ToDouble(txtConstrCost.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_TNR", txtTWLTenure.Text != "" ? Convert.ToDouble(txtTWLTenure.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_ROI", txtTWLROI.Text != "" ? Convert.ToDouble(txtTWLROI.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_LMNT", txtTWLLoanAmount.Text != "" ? Convert.ToDouble(txtTWLLoanAmount.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_EMI", txtTWLEMI.Text != "" ? Convert.ToDouble(txtTWLEMI.Text) : 0.0);
            cmdinsert.Parameters.AddWithValue("@CM_IIR", txtTWLActIIR.Text != "" ? Convert.ToDouble(txtTWLActIIR.Text) : 0.00);
            cmdinsert.Parameters.AddWithValue("@CM_FOIR", txtTWLActFIR.Text != "" ? Convert.ToDouble(txtTWLActFIR.Text) : 0.00);
            //// cmdinsert.Parameters.AddWithValue("@CM_LCR", txtLCR.Text != "" ? Convert.ToDouble(txtLCR.Text) : 0.00);
            //cmdinsert.Parameters.AddWithValue("@CM_LTV", txtLTV.Text != "" ? Convert.ToDouble(txtLTV.Text) : 0.00);
            // cmdinsert.Parameters.AddWithValue("@CM_IIR_LCR", txtIIRLCR.Text != "" ? Convert.ToDouble(txtIIRLCR.Text) : 0.00);
            cmdinsert.Parameters.AddWithValue("@CM_LLTV", txtTWLLapPropLTV.Text != "" ? Convert.ToDouble(txtTWLLapPropLTV.Text) : 0.00);

            /* string strCondition = "";
             if (txt_MICR.Text != "" && gv_MICR.Rows.Count == 0)
             {
                 strCondition = txtConditon.Text != "" ? txtConditon.Text + " ,New Bank A/C Required" : "New Bank A/C Required";
                 cmdinsert.Parameters.AddWithValue("@CM_CREDIT", strCondition);
             }
             else
             {
                 cmdinsert.Parameters.AddWithValue("@CM_CREDIT", txtTWLCondition.Text);
             }*/
            cmdinsert.Parameters.AddWithValue("@CM_CREDIT", txtTWLCondition.Text);

            // * bala changes ends 10/11/2016

            cmdinsert.Parameters.AddWithValue("@CM_REMARKS", txtTWLRemarks.Text);
            cmdinsert.Parameters.AddWithValue("@USERID", Session["ID"].ToString());

            DataSet dsMemo = new DataSet();
            dsMemo = clscommon.Get_RTS_SP_Fetch_Credit_Memo_Detail_mailer(Session["Leadno"].ToString(), "");
            if (dsMemo.Tables[0].Rows.Count > 0)
            {
                cmdinsert.Parameters.AddWithValue("@UTYPE", "UPDATE");
            }

            int n = cmdinsert.ExecuteNonQuery();
            if (n > 0)
            {
                blStatus = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Fail to Save Credit Memo Detatils", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
        return blStatus;

    }
    public void sendRPAMail()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            SqlCommand cmddet1 = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "'", con);
            SqlDataAdapter dadet1 = new SqlDataAdapter(cmddet1);
            DataSet dsdet1 = new DataSet();
            dadet1.Fill(dsdet1);

            string area = Session["AREANAME"].ToString();
            string brnch = "";
            string ldno = "", apname = "";
            if (dsdet1 != null)
            {
                brnch = dsdet1.Tables[0].Rows[0]["BR_NAME"].ToString();
                ldno = Session["Leadno"].ToString();

                apname = dsdet1.Tables[0].Rows[0]["LD_APNAME"].ToString();
                //apmobile =  dsdet.Tables[0].Rows[0]["LD_APNAME"].ToString();
                //gv = Convert.ToDouble(txtGuideline.Text).ToString("F");
                //landarea = Convert.ToDouble(txtLandArea.Text.Trim()).ToString("F");
            }



            con.Open();
            /////// mail ///////////
            //  strMailDetail = "";

            SqlCommand cmddet = new SqlCommand("select * from MR_BRANCH where BR_NAME='" + Session["UNITNAME"].ToString() + "'", con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);




            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT * FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);

            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_RPA"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_RPA"].ToString() : "rts-helpdesk@equitasbank.com";
                //cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                //bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                //bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
            }

            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            fromID = "RTS Alerts";
            toID = to;//"ManimaranK@equitasbank.com";
            //bcc2ID = "shankarg@equitasbank.com";
            //ccID = "rts-helpdesk@equitasbank.com";

            // toID = "shankarg@equitasbank.com";
            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            threadSendMails = new System.Threading.Thread(delegate()
            {

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear TRM,<br/><br/> Please find the request for Risk Property Assessment of market value. <br/><br/>";
                BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='16%'><b>Lead No.</b></td><td style='whiteSpace:nowrap;' width='16%'>" + ldno + "</td>";
                BodyTxt = BodyTxt + "<td width='16%'><b>Area Name</b></td><td width='16%'>" + area + "</td>";
                BodyTxt = BodyTxt + "<td width='16%'><b>Branch Name</b></td><td width='16%'>" + brnch + "</td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='16%'><b>Product</b></td><td> LAP </td>";
                BodyTxt = BodyTxt + "<td width='16%'><b>Applicant Name</b></td><td width='16%'>" + apname + "</td><td width='16%'></td><td width='16%'></td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td  width='16%'><b>Property Address</b></td><td  width='16%'>" + Session["PROPADDR"].ToString().Trim() + "</td>";
                BodyTxt = BodyTxt + "<td  width='16%'><b></b></td><td  width='16%'></td ><td><b></b></td><td  width='16%'></td></tr></table><br/>";

                BodyTxt = BodyTxt + "<br/>Please initiate and submit the report as per the prescribed TAT. <br/><br/><br/>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'>Thanks and Regards,<br/>Risk Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";

                blMailStatus = EmailManager.sendemailRPA(toID, "RTS Alerts", "", "", "RPA Initiated for LEAD NO: " + Session["Leadno"].ToString() + " " + brnch + " Branch", BodyTxt, "", true);


            });

            threadSendMails.IsBackground = true;

            threadSendMails.Start();
            System.Threading.Thread.Sleep(5000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally { con.Close(); }
    }
    public void sendMail(SqlConnection con)
    {
        try
        {
            /////// mail ///////////
            //  strMailDetail = "";

            SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "'", con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);

            SqlCommand cmdmail = new SqlCommand("select CASE WHEN ISNULL(QRY_SQUERY,'')='' THEN QRY_QUERY ELSE QRY_SQUERY END 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "' AND QRY_RSD_BY='C'", con);
            SqlDataAdapter damail = new SqlDataAdapter(cmdmail);
            DataSet dsmail = new DataSet();
            damail.Fill(dsmail);

            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["LD_BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["LD_BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT EM_BM,EM_AM,EM_CM,EM_BCC ,EM_CLM FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);
            string clmid = "";
            if (dsmailto.Tables[0].Rows.Count != 0)
            {

                to = dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
                cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
                clmid = dsmailto.Tables[0].Rows[0]["EM_CLM"].ToString();
                //to = "balasubramanind@equitasbank.com";
                //cc = "balasubramanind@equitasbank.com";
                //bcc = "balasubramanind@equitasbank.com";
                //bcc1 = "balasubramanind@equitasbank.com";
                //clmid = "balasubramanind@equitasbank.com";

            }

            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }



            // to = "ManimaranK@equitasbank.com";
            // bcc2 = "ManimaranK@equitasbank.com";
            // cc = "rts-helpdesk@equitasbank.com";
            fromID = "RTS Alerts";
            toID = to;
            bcc2ID = bcc2;
            if (clmid != "")
                cc = cc + ";" + clmid;
            ccID = cc;
            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            threadSendMails = new System.Threading.Thread(delegate()
            {

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Credit " + ddlApprv.SelectedItem.ToString() + "<br/><br/>";

                if (ddlApprv.SelectedValue == "Rejected")
                {
                    BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: calibri; font-size:12px'>";
                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%' style='background-color:#1061B0;font-weight:bold;color:#ffffff;'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td>";
                    BodyTxt = BodyTxt + "<td style='background-color:#1061B0;font-weight:bold;color:#ffffff;'>Applicant Name</td><td><strong>" + Session["Appname"].ToString() + "</strong></td></tr>";
                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td style='background-color:#1061B0;font-weight:bold;color:#ffffff;'>Product</td><td><strong>" + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + "</strong></td>";
                    BodyTxt = BodyTxt + "<td style='background-color:#1061B0;font-weight:bold;color:#ffffff;'>PD Amount</td><td><strong>" + Session["Loanamt"] + "</strong></td></tr></table><br/><br/>";
                    //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Address </td><td align='center'>:</td><td><strong>" + cusaddr + "</strong></td></tr>";
                    //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Mobile No.</td><td align='center'>:</td><td><strong>" + mobile + "</strong></td></tr></table><br/><br/>";

                }

                //Cash Memo Report Written by Vijayan
                #region CashMemo
                if (ddlApprv.SelectedValue == "Approved")
                {
                    if (!Session["Leadno"].ToString().Contains("TWL"))
                    {
                        SqlCommand cmddd = new SqlCommand("RTS_SP_FetchCredit_Approval_Memo", con);
                        cmddd.Parameters.AddWithValue("@LeadID", Session["LeadId"].ToString() != "--Select--" ? Session["LeadId"].ToString() : "");
                        //cmddd.Parameters.AddWithValue("@Lead_Type", "");
                        cmddd.CommandType = CommandType.StoredProcedure;
                        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
                        DataSet dsdd = new DataSet();
                        dadd.Fill(dsdd);
                        DataSet dsMemo = new DataSet();
                        DataSet dsMemo1 = new DataSet();
                        dsMemo1 = clscommon.Get_RTS_SP_CAMFULLDETAILS(Session["Leadno"].ToString(), "C");
                        dsMemo = clscommon.Get_RTS_SP_Fetch_Credit_Memo_Detail_mailer(Session["Leadno"].ToString(), "");

                        //if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
                        if (dsMemo.Tables[0] != null && dsMemo.Tables[0].Rows.Count > 0)
                        {
                            BodyTxt = BodyTxt + "<table width='100%' border='0' cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri; font-size:12px'><tr><td width='50%'>";
                            BodyTxt = BodyTxt + "<table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri; font-size:12px'>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#1061B0' ><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>CREDIT APPROVAL </td></tr>";
                            BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: calibri;font-size:12px'>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Product.</td><td><strong>" + dsdd.Tables[0].Rows[0]["PR_CODE"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Customer Name.</td><td><strong>" + dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() + "</strong></td></tr>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'>Area/Branch.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["LOCATION"].ToString() + " </strong></td></tr></table></td></tr>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#1061B0'><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>ELIGIBLITY WORKING</td></tr>";
                            BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: calibri; font-size:12px'>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF' style='font-weight:bold;'><td width='40%'>Applicant.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_APL"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_APL"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant1.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL1"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL1"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant2.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL2"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL2"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant3.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL3"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL3"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant4.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL4"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL4"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold; '>Co-Applicant5.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL5"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL5"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Rental Income - if any.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_RINC"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_RINC"].ToString().ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Total Clubbed Income.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_CINC"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Other Personnel Oblication in total.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_OBLIG"].ToString() + "</strong></td></tr></table></td></tr>";


                            BodyTxt = BodyTxt + "<tr bgcolor='#1061B0'><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>ELIGIBLITY DETAILS</td></tr>";
                            BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family:calibri; font-size:12px'>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Insurance Property Value.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_IPV"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Building Value.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_BV"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold; '>Land Value.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LV"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold; '>Total Property Value.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_TPV"].ToString() + "</strong></td></tr></table></td></tr>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#1061B0'><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>FINAL RECOMENDATION</td></tr>";
                            BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family:calibri; font-size:12px'>";

                            // BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Tenor in months.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CAM_TENURE"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Tenor in months.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_TNR"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>ROI.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_ROI"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'>Loan Amount.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LMNT"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>EMI.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_EMI"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Actual IIR / FOIR.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_IIR"].ToString() + " / " + dsMemo.Tables[0].Rows[0]["CM_FOIR"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'>LAP Property LTV%.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LLTV"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Credit Condition.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold;'>Remarks.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_REMARKS"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_REMARKS"].ToString() : "") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Approved  By/ Date.</td><td><strong>" + txtApprovedBy.Text + " / " + DateTime.Now.ToString("dd MMM yyyy") + " </strong></td></tr>";


                            BodyTxt = BodyTxt + "</table></td></tr></table></td>";
                            BodyTxt = BodyTxt + "<td width='50%' style='float:left;margin-left:20px;vertical-align:top;'><table width='30%' border='1' cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri; font-size:12px'><tr bgcolor='#1061B0' ><td colspan='2' style='font-size:16px;color:#ffffff;font-weight:bold;'>Eligibility</td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;font-size:12px; '>IIR</td><td><strong>" + (dsMemo1.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsMemo1.Tables[0].Rows[0]["CAM_IIR"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;font-size:12px; '>FOIR</td><td><strong>" + (dsMemo1.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsMemo1.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;font-size:12px; '>LCR/LTV</td><td><strong>" + (dsMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "</table></td></tr></table><br/><br/>";
                        }
                    }
                    else
                    {
                        SqlCommand cmddd = new SqlCommand("RTS_SP_FetchCredit_Approval_Memo", con);
                        cmddd.Parameters.AddWithValue("@LeadID", Session["LeadId"].ToString() != "--Select--" ? Session["LeadId"].ToString() : "");
                        //cmddd.Parameters.AddWithValue("@Lead_Type", "");
                        cmddd.CommandType = CommandType.StoredProcedure;
                        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
                        DataSet dsdd = new DataSet();
                        dadd.Fill(dsdd);
                        DataSet dsMemo = new DataSet();
                        DataSet dsMemo1 = new DataSet();
                        dsMemo1 = clscommon.Get_RTS_SP_CAMFULLDETAILS_TWL(Session["Leadno"].ToString(), "C");
                        dsMemo = clscommon.Get_RTS_SP_Fetch_Credit_Memo_Detail_mailer_TWL(Session["Leadno"].ToString(), "");

                        //if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
                        if (dsMemo.Tables[0] != null && dsMemo.Tables[0].Rows.Count > 0)
                        {
                            BodyTxt = BodyTxt + "<table width='100%' border='0' cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri; font-size:12px'><tr><td width='50%'>";
                            BodyTxt = BodyTxt + "<table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri; font-size:12px'>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#1061B0' ><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>CREDIT APPROVAL </td></tr>";
                            BodyTxt = BodyTxt + "<tr><td width='100%' colspan='4'><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: calibri;font-size:12px'>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Product.</td><td><strong>" + dsdd.Tables[0].Rows[0]["PR_CODE"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Customer Name.</td><td><strong>" + dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() + "</strong></td></tr>";


                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Source Of Income</td><td><strong>" + dsMemo1.Tables[0].Rows[0]["APPLICANT SOURCE OF INCOME"].ToString().Replace(",", "") + "</strong></td></tr>";


                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Member Type.</td><td><strong>" + dsMemo1.Tables[0].Rows[0]["RELATIONSHIP WITH EQUITASIN"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'>Area/Branch.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["LOCATION"].ToString() + " </strong></td></tr></table></td></tr>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#1061B0'><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>ELIGIBLITY WORKING</td></tr>";
                            BodyTxt = BodyTxt + "<tr><td width='100%' colspan='4'><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: calibri; font-size:12px'>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF' style='font-weight:bold;'><td width='40%'>Applicant.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_APL"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_APL"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant1.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL1"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL1"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant2.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL2"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL2"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant3.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL3"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL3"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant4.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL4"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL4"].ToString() : "0.00") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold; '>Co-Applicant5.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL5"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL5"].ToString() : "0.00") + "</strong></td></tr>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Total Clubbed Income.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_CINC"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Other Personnel Oblication in total.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_OBLIG"].ToString() + "</strong></td></tr>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold; '>Manufacturer Name - Model</td><td><strong>" + dsMemo1.Tables[0].Rows[0]["LVH_NAME"].ToString() + "/" + dsMemo1.Tables[0].Rows[0]["LVH_MODEL"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold; '>Vehicle cost.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LVH_RATE"].ToString() + "</strong></td></tr></table></td></tr>";

                            BodyTxt = BodyTxt + "<tr bgcolor='#1061B0'><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>FINAL RECOMENDATION</td></tr>";
                            BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family:calibri; font-size:12px'>";


                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Tenor in months.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_TNR"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>ROI.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_ROI"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'>Loan Amount.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LMNT"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>EMI.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_EMI"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Actual IIR / FOIR.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_IIR"].ToString() + " / " + dsMemo.Tables[0].Rows[0]["CM_FOIR"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'> LTV%.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LLTV"].ToString() + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Credit Condition.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold;'>Remarks.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_REMARKS"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_REMARKS"].ToString() : "") + "</strong></td></tr>";
                            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Approved  By/ Date.</td><td><strong>" + txtTWLApprovedBy.Text + " / " + DateTime.Now.ToString("dd MMM yyyy") + " </strong></td></tr>";

                            BodyTxt = BodyTxt + "</table></td></tr></table></td>";
                            BodyTxt = BodyTxt + "<td width='50%' style='float:left;margin-left:20px;vertical-align:top;display:none;'><table width='30%'  cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri;display:none; font-size:12px'><tr ><td colspan='2' style='font-size:16px;color:#ffffff;font-weight:bold;'></td></tr>";
                            BodyTxt = BodyTxt + "</table></td></tr></table><br/><br/>";
                        }
                    }



                }
                #endregion CashMemo

                //End of Cash memo report
                int b = dsmail.Tables[0].Rows.Count;
                if (b != 0)
                {
                    BodyTxt = BodyTxt + "<table width='100%' border='1' style='font-family: calibri ; font-size:12px'>";
                    BodyTxt = BodyTxt + "<tr bgcolor='#1061B0' style='font-weight:bold;color:#ffffff;'><span ><td align='center'>Sl. No.</td>";
                    BodyTxt = BodyTxt + "<td  align='center'>Credit Query Details</td>";
                    BodyTxt = BodyTxt + "<td  align='center'>Query Date</td>";
                    BodyTxt = BodyTxt + "<td  align='center'>Response</td>";
                    BodyTxt = BodyTxt + "<td  align='center'>Response Date</td>";
                    BodyTxt = BodyTxt + "<td  align='center'>Resolve Date</td></span></tr>";
                    for (int j = 0; j <= b - 1; j++)
                    {
                        int sno = j + 1;
                        BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='right'> " + sno + "</td>";
                        BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Query Raised"].ToString() + "</td>";
                        BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Date"].ToString() + "</td>";
                        BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response"].ToString() + "</td>";
                        BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response Date"].ToString() + "</td>";
                        BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Resolve Date"].ToString() + "</td></span></tr>";
                    }
                    BodyTxt = BodyTxt + "</table>";
                }
                if (ddlApprv.SelectedItem.ToString() == "Approved")
                {
                    BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/><strong>Credit Approved Amount :</strong> Rs." + txtApprvamt.Text + "<br/><strong>Credit Comments :</strong> " + txtComment.Text + "</td></tr>";
                }
                else
                {
                    BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><strong>Reason : </strong>" + ddlReason.SelectedItem.Text + "</td></tr>";
                    BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><strong>Credit Comments : </strong>" + txtComment.Text + "</td></tr>";
                }
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>Credit Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
                //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

                blMailStatus = EmailManager.sendemail(to, "RTS Alerts", "", cc, "Lead No. : " + Session["Leadno"].ToString() + " - Applicant Name : " + Session["Appname"].ToString() + " - Product: " + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + " - Credit " + ddlApprv.SelectedItem.ToString() + "", BodyTxt, "", true);
                //sendemail("SurendharR@equitasbank.com;PrabhakaranA@equitasbank.com;Tamilalagand@equitasbank.com", "surendharr@equitasbank.com", "Test", BodyTxt, "", true);

                strMailBody = BodyTxt.Replace("<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Credit " + ddlApprv.SelectedItem.ToString() + "<br/><br/>", "");
                strMailBody = BodyTxt.Replace("</html>", " ");


            });
            // strMailDetail = to + "," + bcc2 + "," + cc;
            threadSendMails.IsBackground = true;

            threadSendMails.Start();
            System.Threading.Thread.Sleep(5000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {

            if (fup_Challon.HasFile==true)
            {
                if (fup_Challon.PostedFile.ContentLength > 512000)
                {
                    uscMsgBox1.AddMessage("The file size should be 500kb or less", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                else
                {
                    string fileExt = Path.GetExtension(fup_Challon.PostedFile.FileName);
                    string fileName = AppConstants.FileNamePrefix_CAM + Convert.ToString(Session["leadno"]) + fileExt;
                    string fileUploadPath = ConfigurationManager.AppSettings[AppConstants.FileUploadPath] + "\\" + fileName;
                    fup_Challon.SaveAs(Server.MapPath(fileUploadPath));

                    using (SqlConnection conSub = new SqlConnection(strcon))
                    {
                        using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_Credit_PD_INIT", conSub))
                        {
                            SqlDataAdapter adapter = new SqlDataAdapter(command);
                            conSub.Open();
                            command.CommandType = System.Data.CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@PTYPE", "UPLOAD_CAM_UPD");
                            command.Parameters.AddWithValue("@USR_ID", Session["ID"].ToString());
                            command.Parameters.AddWithValue("@LD_ID", Session["LeadId"].ToString());
                            command.ExecuteNonQuery();
                            //  sendFIRCUMail(Convert.ToInt32(Convert.ToInt32(Session["DSA_FIRCU_ID"].ToString())),Convert.ToInt32( Session["DSA_ID"].ToString()));
                            uscMsgBox1.AddMessage("CAM has been uploaded successfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

                            BindqueryGrid();
                            // trInitiation.Visible = false;
                            lbLeadno.Visible = false;
                            lbAppname.Visible = false;
                            lbPDdate.Visible = false;
                            lbLoanamt.Visible = false;
                        }
                    }
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Please select any one of the file to upload", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }


    }
    public void InsertUpdateBLCreditApproved()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {

            Apprvamt = 0;

            double n = Convert.ToDouble(txtApprvamt.Text != "" ? txtApprvamt.Text : "0");

            if (txtApprvamt.Text != "")
            {
                Apprvamt = Convert.ToDouble(txtApprvamt.Text);
            }

            if (ddlApprv.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Approved/Rejected", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlApprv.SelectedValue.ToString() == "Approved" && txtApprvamt.Text == "")
            {
                uscMsgBox1.AddMessage("Please Enter Approved Amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlApprv.SelectedValue.ToString() == "Rejected" && ddlReason.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Reason", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

            else if (ddlApprv.SelectedValue.ToString() == "Approved" && Apprvamt > Convert.ToDouble(Session["Loanamt"]))
            {
                uscMsgBox1.AddMessage("Approved amount is more than Loan amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (gvRPA.Rows.Count > 0 && ChkVacantLand.Checked && n > 250000)
            {
                uscMsgBox1.AddMessage("RPA Initiated  for Vacand Land,Approved amount must be less than 250000", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //else if (rdnUrban.Checked == false && rdnRural.Checked == false)
            //{
            //    uscMsgBox1.AddMessage("Please Select any one of Area type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else
            {


                ldid = Convert.ToInt32(Session["LeadId"]);

                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = "select count(*) as count from LSD_QUERY where QRY_LD_ID='" + ldid + "' and QRY_RSD_BY='C' and QRY_RSL_DATE is NULL";

                int nCount = ((int)cmd.ExecuteScalar());

                //   con.Close();
                int nCount1 = 0;
                /*Bala changes 16/12/2016 
              SqlCommand cmd1 = con.CreateCommand();
               cmd1.CommandText = "select count(*) as count from LSD_RPA where RPA_LD_ID='" + ldid + "' and  RPA_VDATE is NULL ";

               nCount1 = ((int)cmd1.ExecuteScalar());*/
                nCount1 = clscommon.GetRPACount(ldid);

                int nCount2 = 0;
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandText = "select count(*) as count from LSD_CAM_SAMPLE where SL_LD_ID='" + ldid + "' and  SL_RAMT IS NULL ";

                nCount2 = ((int)cmd2.ExecuteScalar());


                int nCount3 = 0;
                SqlCommand cmd3 = con.CreateCommand();
                cmd3.CommandText = "select count(*) as count from LSD_VALUAR where LV_LD_ID='" + ldid + "' and  LV_RDATE IS NULL ";

                nCount3 = ((int)cmd3.ExecuteScalar());

                if (nCount != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage("" + nCount + " Query pending, To Continue Please Enter Comments...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                //else if (nCount1 != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "")
                else if (nCount1 != 0 && ddlApprv.SelectedItem.ToString() == "Approved")
                {
                    uscMsgBox1.AddMessage(" RPA pending,Credit approval can't proceed...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                else if (nCount2 != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "")
                {
                    uscMsgBox1.AddMessage(" Sampling pending,Credit approval can't proceed...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                else if (nCount3 != 0 && ddlApprv.SelectedItem.ToString() == "Approved" && txtComment.Text.Trim() == "" && txtProduct.Text.Contains("G"))
                {
                    uscMsgBox1.AddMessage(" Technical Initiation pending,Credit approval can't proceed...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
                //else if (ddlApprv.SelectedItem.Text == "Approved" && txtActIIR.Text == "")
                //{
                //    uscMsgBox1.AddMessage(" Please enter credit memo details...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //}
                else
                {

                    bool blStatus = true;
                    if (ddlApprv.SelectedItem.Text == "Approved")
                    {
                        if (Session["Leadno"].ToString().Contains("TWL"))
                        {
                            blStatus = InsertCamMemo_TWL(con);
                        }
                        else
                        {
                            if (!Session["Leadno"].ToString().Contains("BL"))
                            {
                                blStatus = InsertCamMemo(con);
                            }
                        }
                    }
                    if (blStatus == true)
                    {
                        SqlCommand cmdinsert = new SqlCommand("RTS_SP_Update_Credit_Approval", con);
                        cmdinsert.CommandType = CommandType.StoredProcedure;
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_APRL", ddlApprv.SelectedIndex.ToString());
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_AMT", txtApprvamt.Text != "" ? txtApprvamt.Text : "0");
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_CMTS", txtComment.Text);
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_MBY", Session["ID"].ToString());
                        cmdinsert.Parameters.AddWithValue("@LD_ID", ldid);
                        cmdinsert.Parameters.AddWithValue("@LD_CRAP_RSN_ID", ddlReason.SelectedValue.ToString());
                        cmdinsert.Parameters.AddWithValue("@LD_RCARDNO", txt_Ration_card_no.Text.ToUpper());

                        cmdinsert.ExecuteNonQuery();

                        //BALA Changes starts 21/01/2017
                        if (ddlOffineEmployees.SelectedValue != "0")
                        {
                            clscommon.UpdateCreditManualApproval(ldid, Convert.ToInt32(ddlOffineEmployees.SelectedValue));
                        }

                        if (!Session["Leadno"].ToString().Contains("BL"))
                        {
                            sendMail(con);
                        }
                        else
                        {
                            blMailStatus = true;
                        }

                        SqlCommand cmdMediIns = new SqlCommand("RTS_SP_FETCH_MEDDETS", con);
                        cmdMediIns.CommandType = CommandType.StoredProcedure;
                        cmdMediIns.Parameters.AddWithValue("@LD_ID", ldid);
                        SqlDataAdapter daMedInit = new SqlDataAdapter(cmdMediIns);
                        DataSet dsMedInit = new DataSet();
                        daMedInit.Fill(dsMedInit);
                        if (dsMedInit.Tables[0] != null && dsMedInit.Tables[0].Rows.Count > 0)
                        {
                            double dblAmount = dsMedInit.Tables[0].Rows[0]["LD_CRAP_AMT"] != DBNull.Value ? Convert.ToDouble(dsMedInit.Tables[0].Rows[0]["LD_CRAP_AMT"]) : 0.0;
                            int age = dsMedInit.Tables[0].Rows[0]["CI_AGE"] != DBNull.Value ? Convert.ToInt32(dsMedInit.Tables[0].Rows[0]["CI_AGE"]) : 0;
                            int Tenure = dsMedInit.Tables[0].Rows[0]["CAM_TENURE"] != DBNull.Value ? Convert.ToInt32(dsMedInit.Tables[0].Rows[0]["CAM_TENURE"]) : 0;
                            string Name = dsMedInit.Tables[0].Rows[0]["CI_NAME"] != DBNull.Value ? Convert.ToString(dsMedInit.Tables[0].Rows[0]["CI_NAME"]) : "";
                            string ContactNumber = dsMedInit.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? Convert.ToString(dsMedInit.Tables[0].Rows[0]["LD_ACNO"]) : "";

                            bool blStatusVal = false;
                            if (dblAmount > 500000 && dblAmount <= 750000 && age > 55)
                            {
                                blStatusVal = true;
                            }
                            else if (dblAmount > 750000 && dblAmount <= 1000000 && age > 50)
                            {
                                blStatusVal = true;
                            }
                            else if (dblAmount > 1000000 && dblAmount <= 1500000 && age > 40)
                            {
                                blStatusVal = true;
                            }
                            else if (dblAmount > 1500000)
                            {
                                blStatusVal = true;
                            }
                            if (blStatusVal)
                            {
                                sendMedcInitmail(Name, dblAmount.ToString(), Tenure.ToString(), age.ToString(), ContactNumber.ToString());
                            }
                        }

                        string strMailStatus = "";
                        string strSuccessMsg = "";
                        if (blMailStatus == true)
                        {
                            strMailStatus = "Successfully";
                        }
                        else
                        {
                            strMailStatus = "Failed";
                        }
                        strSuccessMsg = Session["Leadno"].ToString() + " " + ddlApprv.SelectedItem.ToString() + " Successfully" + " <br/> Mail Sent " + strMailStatus + "  ";
                        strSuccessMsg += "<br/> Mail To: " + toID + " ; CC To: " + ccID + " ";
                        if (txtApprvamt.Text != "")
                        {
                            strSuccessMsg += "<br/>Credit Approved Amount : " + txtApprvamt.Text + " ";
                        }
                        if (txtComment.Text != "")
                        {
                            strSuccessMsg += "<br/>Credit Comments :" + txtComment.Text + "";
                        }


                        uscMsgBox1.AddMessage(strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        //  ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('MailStatusPopup.aspx?ApprvSt=" + ddlApprv.SelectedItem.ToString() + "&MailStatus=" + blMailStatus + "&from=" + fromID + "&To=" + toID + "&cc=" + ccID + ",&bcc=" + bcc2ID + "&body=" + strMailBody + "', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
                        if (ChkVacantLand.Checked)
                        {
                            //bool blStatus =   
                            InsertRPA(con);
                        }


                        tbSubmit.Visible = false;
                        ddlOffineEmployees.SelectedValue = "0";
                        BindqueryGrid();
                        lbLeadno.Text = "";
                        lbAppname.Text = "";
                        lbPDdate.Text = "";
                        lbLoanamt.Text = "";
                        txtApprvamt.Text = "";
                        txtComment.Text = "";
                        ddlApprv.SelectedIndex = 0;
                        ddlReason.SelectedIndex = 0;
                        ddlApprv.Enabled = false;
                        ddlReason.Enabled = false;
                        btnSubmit.Enabled = false;
                        btnCancel.Enabled = false;
                        gvQuerypop.Visible = false;
                        gvSampleData.Visible = false;
                        gvRPA.Visible = false;
                        clearCreditMemoDatas();
                        trCreditMemo.Visible = false;
                        trTWLCreditMemo.Visible = false;
                        Panel1.Visible = false;
                    }

                }
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Credit_Approval.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_NAME";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
        txtLeadno.Enabled = false;
    }
    protected void ddlApprv_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlReason.SelectedIndex = 0;
        if (ddlApprv.SelectedValue.ToString() == "Rejected")
        {
            //  bind();
            ddlReason.Enabled = true;
            txtApprvamt.Text = "";
            txtApprvamt.Enabled = false;
        }
        else
        {
            //  bind();
            ddlReason.Enabled = false;
            txtApprvamt.Text = "";
            txtApprvamt.Enabled = true;
        }
    }
    protected void btn_MICR_Click(object sender, EventArgs e)
    {
        MICR_NO.Visible = true;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_GET_MICR", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MICR_NO", txt_MICR.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            gv_MICR.DataSource = ds.Tables[0];
            gv_MICR.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gv_MICR.HeaderRow.Font.Bold = true;
                gv_MICR.HeaderRow.Cells[0].Text = "MICR No";
                gv_MICR.HeaderRow.Cells[1].Text = "Bank Name";
                gv_MICR.HeaderRow.Cells[2].Text = "Bank Branch";
                gv_MICR.HeaderRow.Cells[3].Text = "Location";
            }
            else
            {
                uscMsgBox1.AddMessage("Invalid MICR No", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnEmpAprvAmount_Click(object sender, EventArgs e)
    {
        try
        {
            Page.Validate("ValGrp");

            if (Page.IsValid)
            {
                if (ddlAprvEmployee.SelectedValue != "0")
                {
                    SqlConnection con = new SqlConnection(strcon);
                    // if (ddlApprv.SelectedItem.Text == "Approved")
                    //{
                    if (Session["Leadno"].ToString().Contains("TWL"))
                    {
                        InsertCamMemo_TWL(con);
                    }
                    else
                    {
                        InsertCamMemo(con);
                    }
                    //}
                    DataSet ds = new DataSet();
                    con.Open();
                    SqlCommand cmd = new SqlCommand("select EMP_NAME,EMP_EMAILID,EMP_CODE,USR_EMP_ID,B.USR_UTP_ID from MR_EMPLOYEE A JOIN MR_USER B ON A.EMP_ID=B.USR_EMP_ID WHERE EMP_ID=" + ddlAprvEmployee.SelectedValue + " AND B.USR_STAT = 1 ", con);
                    SqlDataAdapter showdata = new SqlDataAdapter(cmd);
                    showdata.Fill(ds);

                    con.Close();

                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        int EMPID = Convert.ToInt32(ds.Tables[0].Rows[0]["USR_EMP_ID"]);
                        string from, to, subject;
                        con.Open();
                        Session["R_USR_UTP_ID"] = ds.Tables[0].Rows[0]["USR_EMP_ID"].ToString();
                        subject = "Lead No : " + Session["Leadno"].ToString() + " has been assigned to you for the credit approval.";
                        from = "RTS <donotreply@equitasbank.com>";

                        to = ds.Tables[0].Rows[0]["EMP_EMAILID"].ToString();


                        con.Close();
                        System.Threading.Thread threadSendMails;
                        string BodyTxt = "";

                        threadSendMails = new System.Threading.Thread(delegate()
                        {
                            //Cash Memo Report Written by BALA
                            #region CashMemo


                            SqlCommand cmddd = new SqlCommand("RTS_SP_FetchCredit_Approval_Memo", con);
                            cmddd.Parameters.AddWithValue("@LeadID", Session["LeadId"].ToString() != "--Select--" ? Session["LeadId"].ToString() : "");
                            //cmddd.Parameters.AddWithValue("@Lead_Type", "");
                            cmddd.CommandType = CommandType.StoredProcedure;
                            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
                            DataSet dsdd = new DataSet();
                            dadd.Fill(dsdd);
                            DataSet dsMemo = new DataSet();
                            DataSet dsMemo1 = new DataSet();
                            dsMemo1 = clscommon.Get_RTS_SP_CAMFULLDETAILS(Session["Leadno"].ToString(), "C");
                            dsMemo = clscommon.Get_RTS_SP_Fetch_Credit_Memo_Detail_mailer(Session["Leadno"].ToString(), "");

                            //if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
                            if (dsMemo.Tables[0] != null && dsMemo.Tables[0].Rows.Count > 0)
                            {
                                /*bala changes Start*/
                                if (!Session["Leadno"].ToString().Contains("TWL"))
                                {

                                    BodyTxt = BodyTxt + "<table width='100%' border='0' cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri; font-size:12px'><tr><td width='50%'>";
                                    BodyTxt = BodyTxt + "<table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri; font-size:12px'>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#1061B0' ><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>CREDIT APPROVAL </td></tr>";
                                    BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: calibri;font-size:12px'>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Product.</td><td><strong>" + dsdd.Tables[0].Rows[0]["PR_CODE"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Customer Name.</td><td><strong>" + dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() + "</strong></td></tr>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'>Area/Branch.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["LOCATION"].ToString() + " </strong></td></tr></table></td></tr>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#1061B0'><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>ELIGIBLITY WORKING</td></tr>";
                                    BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: calibri; font-size:12px'>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF' style='font-weight:bold;'><td width='40%'>Applicant.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_APL"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_APL"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant1.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL1"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL1"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant2.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL2"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL2"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant3.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL3"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL3"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant4.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL4"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL4"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold; '>Co-Applicant5.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL5"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL5"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Rental Income - if any.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_RINC"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_RINC"].ToString().ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Total Clubbed Income.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_CINC"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Other Personnel Oblication in total.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_OBLIG"].ToString() + "</strong></td></tr></table></td></tr>";


                                    BodyTxt = BodyTxt + "<tr bgcolor='#1061B0'><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>ELIGIBLITY DETAILS</td></tr>";
                                    BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family:calibri; font-size:12px'>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Insurance Property Value.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_IPV"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Building Value.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_BV"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold; '>Land Value.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LV"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold; '>Total Property Value.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_TPV"].ToString() + "</strong></td></tr></table></td></tr>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#1061B0'><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>FINAL RECOMENDATION</td></tr>";
                                    BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family:calibri; font-size:12px'>";

                                    // BodyTxt = BodyTxt + "<tr bgcolor='#FDF5E6'><td width='40%' style=' font-size: small; font-weight: bold; border: thin solid #4d4d4d;'>Tenor in months.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CAM_TENURE"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Tenor in months.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_TNR"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>ROI.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_ROI"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'>Loan Amount.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LMNT"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>EMI.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_EMI"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Actual IIR / FOIR.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_IIR"].ToString() + " / " + dsMemo.Tables[0].Rows[0]["CM_FOIR"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'>LAP Property LTV%.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LLTV"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Credit Condition.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold;'>Remarks.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_REMARKS"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_REMARKS"].ToString() : "") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Approved  By/ Date.</td><td><strong>" + txtApprovedBy.Text + " / " + DateTime.Now.ToString("dd MMM yyyy") + " </strong></td></tr>";


                                    BodyTxt = BodyTxt + "</table></td></tr></table></td>";
                                    BodyTxt = BodyTxt + "<td width='50%' style='float:left;margin-left:20px;vertical-align:top;'><table width='30%' border='1' cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri; font-size:12px'><tr bgcolor='#1061B0' ><td colspan='2' style='font-size:16px;color:#ffffff;font-weight:bold;'>Eligibility</td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;font-size:12px; '>IIR</td><td><strong>" + (dsMemo1.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsMemo1.Tables[0].Rows[0]["CAM_IIR"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;font-size:12px; '>FOIR</td><td><strong>" + (dsMemo1.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsMemo1.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;font-size:12px; '>LCR/LTV</td><td><strong>" + (dsMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "</table></td></tr></table><br/><br/>";
                                }
                                else
                                {
                                    /*end*/

                                    BodyTxt = BodyTxt + "<table width='100%' border='0' cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri; font-size:12px'><tr><td width='50%'>";
                                    BodyTxt = BodyTxt + "<table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri; font-size:12px'>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#1061B0' ><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>CREDIT APPROVAL </td></tr>";
                                    BodyTxt = BodyTxt + "<tr><td width='100%' colspan='4'><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: calibri;font-size:12px'>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Product.</td><td><strong>" + dsdd.Tables[0].Rows[0]["PR_CODE"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Customer Name.</td><td><strong>" + dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() + "</strong></td></tr>";


                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Source Of Income</td><td><strong>" + dsMemo1.Tables[0].Rows[0]["APPLICANT SOURCE OF INCOME"].ToString().Replace(",", "") + "</strong></td></tr>";


                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight:bold;'>Member Type.</td><td><strong>" + dsMemo1.Tables[0].Rows[0]["RELATIONSHIP WITH EQUITASIN"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'>Area/Branch.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["LOCATION"].ToString() + " </strong></td></tr></table></td></tr>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#1061B0'><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>ELIGIBLITY WORKING</td></tr>";
                                    BodyTxt = BodyTxt + "<tr><td width='100%' colspan='4'><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: calibri; font-size:12px'>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF' style='font-weight:bold;'><td width='40%'>Applicant.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_APL"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_APL"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant1.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL1"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL1"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant2.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL2"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL2"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant3.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL3"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL3"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Co-Applicant4.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL4"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL4"].ToString() : "0.00") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold; '>Co-Applicant5.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CAPL5"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL5"].ToString() : "0.00") + "</strong></td></tr>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Total Clubbed Income.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_CINC"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Other Personnel Oblication in total.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_OBLIG"].ToString() + "</strong></td></tr>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold; '>Manufacturer Name - Model</td><td><strong>" + dsMemo1.Tables[0].Rows[0]["LVH_NAME"].ToString() + "/" + dsMemo1.Tables[0].Rows[0]["LVH_MODEL"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold; '>Vehicle cost.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LVH_RATE"].ToString() + "</strong></td></tr></table></td></tr>";

                                    BodyTxt = BodyTxt + "<tr bgcolor='#1061B0'><td width='100%' colspan='4' style='font-size:16px;color:#ffffff;font-weight:bold;'>FINAL RECOMENDATION</td></tr>";
                                    BodyTxt = BodyTxt + "<tr><td><table width='100%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family:calibri; font-size:12px'>";


                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Tenor in months.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_TNR"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>ROI.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_ROI"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'>Loan Amount.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LMNT"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>EMI.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_EMI"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Actual IIR / FOIR.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_IIR"].ToString() + " / " + dsMemo.Tables[0].Rows[0]["CM_FOIR"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style=' font-weight: bold;'> LTV%.</td><td><strong>" + dsMemo.Tables[0].Rows[0]["CM_LLTV"].ToString() + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold;'>Credit Condition.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='font-weight: bold;'>Remarks.</td><td><strong>" + (dsMemo.Tables[0].Rows[0]["CM_REMARKS"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_REMARKS"].ToString() : "") + "</strong></td></tr>";
                                    BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='40%' style='  font-weight: bold; '>Approved  By/ Date.</td><td><strong>" + txtTWLApprovedBy.Text + " / " + DateTime.Now.ToString("dd MMM yyyy") + " </strong></td></tr>";

                                    BodyTxt = BodyTxt + "</table></td></tr></table></td>";
                                    BodyTxt = BodyTxt + "<td width='50%' style='float:left;margin-left:20px;vertical-align:top;display:none;'><table style='display:none;' width='30%'  cellpadding='4' cellspacing='1' bgcolor='White' style='font-family: calibri;display:none; font-size:12px'><tr ><td colspan='2' style='font-size:16px;color:#ffffff;font-weight:bold;'></td></tr>";
                                    BodyTxt = BodyTxt + "</table></td></tr></table><br/><br/>";

                                }
                            }





                            #endregion CashMemo
                            EmailManager.sendemail(to, from, "", "", subject, BodyTxt, "", true);

                            // blMailStatus = sendemail(to, "RTS Alerts", "", cc, "Lead No. : " + Session["Leadno"].ToString() + " - Applicant Name : " + Session["Appname"].ToString() + " - Product: " + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + " - Credit " + ddlApprv.SelectedItem.ToString() + "", BodyTxt, "", true);


                        });
                        threadSendMails.IsBackground = true;
                        threadSendMails.Start();


                        if (threadSendMails.IsAlive) { Thread.Sleep(7000); }

                        string[] strDatasourceArr = strcon.Split(';');
                        string strDSource = strDatasourceArr[0].ToString();

                        // ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('Lead No has been assigned successfully.');", true);
                        uscMsgBox1.AddMessage("Lead No : " + Session["Leadno"].ToString() + " has been assigned successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        ddlAprvEmployee.SelectedValue = "0";
                        // clear();
                        // clearCreditMemoDatas();

                    }
                    else
                    {
                        //ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('User ID Not Exists');", true);
                        uscMsgBox1.AddMessage("User ID Not Exists", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
                    }
                }
                else
                {
                    //ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('Please select the employee');", true);

                    uscMsgBox1.AddMessage("Please select the employee", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }




    }
    protected void gvApprv_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    RadioButton rb_select = gvApprv.FindControl("rb_select") as RadioButton;
        //    if (rb_select.Checked==true)
        //    {
        //       e.Row.BackColor = System.Drawing.Color.Red;
        //        //e.Row.Attributes["style"] = "background-color: #28b779";
        //    }
        //}

    }
}