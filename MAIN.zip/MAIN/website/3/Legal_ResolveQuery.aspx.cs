﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Text.RegularExpressions;
using Tracker;

public partial class Legal_ResolveQuery : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string sa;
    int ldid;
    int qryldid;
    int j;
    int b;
    int selectedcnt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();


    DateTime dtd;
    int docscnt, id;
    string strVald;

    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter dappre = new SqlDataAdapter();
    DataSet dspre = new DataSet();
    DataTable dtpre = new DataTable();

    Regex Rx = new Regex("^[0-9]+$");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {

            if (!IsPostBack)
            {
                
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bindArea();

                this.lstdocs.Visible = false;
                this.lstdocs1.Visible = false;
            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    // Shankar_Nov_14_01 
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    // Shankar_Nov_14_01 
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

        }
        else
        {
            BindSendReceiveGrid();


            foreach (GridViewRow grow in gvQuery.Rows)
            {
                Label PreOpinion = (Label)grow.FindControl("lblPreOpinion");
                int index = grow.RowIndex;
                if (PreOpinion.Text == "F")
                {
                    gvQuery.Rows[index].Cells[1].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[2].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[3].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[4].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[5].ForeColor = Color.Red;


                }
            }
            this.qrydets.Visible = false;
            this.lstdocs.Visible = false;
            this.lstdocs1.Visible = false;
        }
    }
    public void BindSendReceiveGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Query_Resolve", con);
            cmd.CommandType = CommandType.StoredProcedure;
           
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@QRY_RSD_BY", "L");
            
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvQuery.Visible = true;
                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_ResolveQuery.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
  

    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        foreach (GridViewRow grow in gvQuery.Rows)
        {
            Label lblLeadID = grow.FindControl("lblLeadID") as Label;
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                Session["LeadID"] = lblLeadID.Text;

                leadno = lnbtn.Text;
                appname = gvQuery.Rows[index].Cells[3].Text;
                pddt = gvQuery.Rows[index].Cells[4].Text;
                lnamt = gvQuery.Rows[index].Cells[5].Text;
                Session["StatusLGLRSL"] = "New";
                Session["MDIDRSL"] = null;
                BindAllGrid("All");
                Bind_Doc_Type();
                this.lstdocs.Visible = false;
                this.lstdocs1.Visible = false;
                break;
            }
        }
        Session["Leadno"] = leadno;

        qrydetsbind();
        this.qrydets.Visible = true;
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;

        con.Close();
    }

    private void CLear()
    {
        txtbxdocdate.Text = "";
        txtbxdocs.Text = "";
        txtbxsurvey.Text = "";
        ddlstdoctype.SelectedIndex = 0;
       
        ddlstdocct.SelectedIndex = 0;
        txtbxdocno.Text = "";

        btnadd.Text = "Add";
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Legal_QueryPopUp.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
    }
    public void qrydetsbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        qryldid = Session["LeadID"] != null ? Convert.ToInt32(Session["LeadID"]) : 0;

        SqlCommand cmdqry = new SqlCommand("SELECT QRY_ID,QRY_QUERY,QRY_RESPONSE FROM LSD_QUERY where QRY_LD_ID='" + qryldid + "' and isnull(QRY_RESP_DATE,'')<>'' AND isnull(QRY_RSL_DATE,'')='' AND QRY_RSD_BY='L'", con);
        SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
        DataSet dsqry = new DataSet();
        daqry.Fill(dsqry);
        gvQuerydets.DataSource = dsqry.Tables[0];
        gvQuerydets.DataBind();
        gvQuerydets.Visible = true;
        con.Close();
    }
    public void InsertUpdateCreditResolve()
    {
        foreach (GridViewRow grow1 in gvQuerydets.Rows)
        {
            CheckBox chkStat1 = grow1.FindControl("cb_select") as CheckBox;
            int index1 = grow1.RowIndex;
            int count = Convert.ToInt32(chkStat1.Checked);
            if (count != 0)
            {
                selectedcnt = 0;
                foreach (GridViewRow grow in gvQuerydets.Rows)
                {

                    CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                    int index = grow.RowIndex;
                   
                    if (chkStat.Checked)
                    {
                        selectedcnt++;
                        SqlConnection con = new SqlConnection(strcon);
                        try
                        {
                            Label lbquery = grow.FindControl("lblname") as Label;
                            Label lbrsp = grow.FindControl("lblrsp") as Label;
                            Label lbqueryid = grow.FindControl("lblqryid") as Label;
                            string resp = lbrsp.Text;
                            string qry = lbquery.Text;
                            int qryid = Convert.ToInt32(lbqueryid.Text);
                            con.Open();

                            ldid = Session["LEADID"] != null ? Convert.ToInt32(Session["LeadID"].ToString()) : 0;

                            SqlCommand cmdupdate = new SqlCommand("update LSD_QUERY set QRY_RSL_DATE=getdate(),QRY_MBY='" + Session["ID"].ToString() + "',QRY_MDATE=getdate() where QRY_LD_ID='" + ldid + "' AND QRY_ID='" + qryid + "' AND QRY_RSD_BY='L'", con);
                            cmdupdate.ExecuteNonQuery();
                           
                            gvQuerydets.Visible = false;
                            lbLeadno.Text = "";
                            lbAppname.Text = "";
                            lbPDdate.Text = "";
                            lbLoanamt.Text = "";
                            
                            btnSubmit.Enabled = false;
                        }
                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_ResolveQuery.aspx"); }
                            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
                        }
                        finally
                        {
                            con.Close();
                        }
                    }
                   
                }
            }
          
        }
        if (selectedcnt == 0)
        {
            
            uscMsgBox1.AddMessage("Please Select Query To Resolve", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            gvQuery.DataSource = null;
            gvQuery.DataBind();
            BindSendReceiveGrid();

            foreach (GridViewRow grow in gvQuery.Rows)
            {
                Label PreOpinion = (Label)grow.FindControl("lblPreOpinion");
                int index = grow.RowIndex;
                if (PreOpinion.Text == "F")
                {
                    gvQuery.Rows[index].Cells[1].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[2].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[3].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[4].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[5].ForeColor = Color.Red;


                }
            }

            Session["MDIDRSL"] = null;
            Session["LeadID"] = null;
           // BindAllGrid("All");
            this.qrydets.Visible = false;
            this.lstdocs.Visible = false;
            this.lstdocs1.Visible = false;



            uscMsgBox1.AddMessage("Query Resolved Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }
    

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertUpdateCreditResolve();
        
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Legal_ResolveQuery.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";

    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["StatusLGLRSL"].ToString() == "New")
            {

                if (txtbxdocdate.Text.Trim() != "" && txtbxsurvey.Text.Trim() != "--Select--" && txtbxdocs.Text.Trim() != "" && ddlstdoctype.SelectedItem.Text != "--Select--" && ddlstdocct.SelectedItem.Text != "--Select--" && txtbxdocno.Text.Trim() != "")
                {
                    try
                    {

                        dtd = DateTime.ParseExact(txtbxdocdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
                    }

                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                        uscMsgBox1.AddMessage("Invalid Date format. Please check the date (dd/mm/yyyy)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                        return;
                    }


                    using (SqlConnection connection = new SqlConnection(strcon))
                    {
                        connection.Open();
                        

                        cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection);
                        dtpre = new DataTable();
                        dappre = new SqlDataAdapter(cmd);
                        dappre.Fill(dtpre);

                        Session["MDIDRSL"] = dtpre.Rows[0]["MD_ID"] != DBNull.Value ? dtpre.Rows[0]["MD_ID"].ToString() : "";

                   

                        if (gvdocs.Rows.Count > 0)
                        {
                            List<int> cnt = new List<int>();
                            cnt.Clear();
                            foreach (GridViewRow grow in gvdocs.Rows)
                            {
                                Label lblPSCH = grow.FindControl("lblslno") as Label;
                                cnt.Add(Convert.ToInt32(lblPSCH.Text));
                            }
                            docscnt = cnt.Max() + 1;

                        }
                        else
                            docscnt = 1;

                        try
                        {
                            
                            string sql = " INSERT INTO LSD_MOTD_DOCX (MDX_MD_ID,MDX_SLNO,MDX_DATE,MDX_DOC,MDX_DOCNO,MDX_SURVEY,MDX_DTYPE,MDX_DT_ID,MDX_RSTAT) values(" + Convert.ToInt32(Session["MDIDRSL"].ToString()) + "," + docscnt + ",'" + dtd + "','" +
                                          txtbxdocs.Text.Replace("'", "''").ToString() + "','" + txtbxdocno.Text.Replace("'", "''").ToString() + "','" + txtbxsurvey.Text.Replace("'", "''").ToString() + "','" + ddlstdoctype.SelectedItem.Text + "'," + Convert.ToInt32(ddlstdocct.SelectedValue.ToString()) + ",'Required')";
                            cmd = new SqlCommand(sql, connection);

                            int r = cmd.ExecuteNonQuery();
                            if (r > 0)
                            {
                                CLear();
                                BindAllGrid("D");
                              
                            }
                            else
                            {
                                uscMsgBox1.AddMessage("Document not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_ResolveQuery.aspx"); }
                            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
                        }
                        finally
                        {
                            cmd.Dispose();
                        }
                    }


                }
                else
                {
                    if (txtbxdocdate.Text == "")
                    {
                        txtbxdocdate.Focus();

                    }
                    else if (ddlstdoctype.SelectedItem.Text == "--Select--")
                    {
                        ddlstdoctype.Focus();
                    }
                    else if (txtbxsurvey.Text == "")
                    {
                        txtbxsurvey.Focus();

                    }
                    else if (txtbxdocs.Text == "")
                    {
                        txtbxdocs.Focus();
                    }
                    else if (ddlstdocct.SelectedItem.Text == "--Select--")
                    {
                        ddlstdocct.Focus();
                    }
                    else if (txtbxdocno.Text.Trim() == "")
                    {
                        txtbxdocno.Focus();
                    }
                    uscMsgBox1.AddMessage("Please Give corresponding Inputs for List of Documents", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    BindAllGrid("D");
                }
            }
            else if (Session["StatusLGLRSL"].ToString() == "Edit")
            {
                if (txtbxdocdate.Text.Trim() != "" && txtbxsurvey.Text.Trim() != "--Select--" && txtbxdocs.Text.Trim() != "" && ddlstdoctype.SelectedItem.Text != "--Select--" && ddlstdocct.SelectedItem.Text != "--Select--" && txtbxdocno.Text.Trim() != "")
                {

                    using (SqlConnection connection = new SqlConnection(strcon))
                    {
                        connection.Open();
                        try
                        {

                            dtd = DateTime.ParseExact(txtbxdocdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
                        }

                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            uscMsgBox1.AddMessage("Invalid Date format. Please check the date", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                            return;
                        }


                        try
                        {
                            string sql = "Update  LSD_MOTD_DOCX set " +

                                           " MDX_DATE='" + dtd + "'," +
                                           " MDX_DOC='" + txtbxdocs.Text.Replace("'", "''").ToString() + "'," +
                                           " MDX_DOCNO='" + txtbxdocno.Text.Replace("'", "''").ToString() + "'," +
                                           " MDX_SURVEY='" + txtbxsurvey.Text.Replace("'", "''").ToString() + "'," +
                                           " MDX_DTYPE='" + ddlstdoctype.SelectedItem.Text + "'," +
                                           " MDX_DT_ID=" + Convert.ToInt32(ddlstdocct.SelectedValue.ToString()) + "," +
                                           " MDX_RSTAT='Required' " +
                                            " Where MDX_SLNO =" + Convert.ToInt32(Session["SLNORSL"].ToString()) +
                                            " and MDX_MD_ID=" + Convert.ToInt32(Session["MDIDRSL"].ToString());



                            cmd = new SqlCommand(sql, connection);

                            int r = cmd.ExecuteNonQuery();
                            if (r > 0)
                            {
                                CLear();
                                BindAllGrid("D");
                                Session["StatusLGLRSL"] = "New";
                                //uscMsgBox1.AddMessage("Please check the age", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }
                            else
                            {
                                uscMsgBox1.AddMessage("Document not updated...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_ResolveQuery.aspx"); }
                            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
                        }
                        finally
                        {
                            cmd.Dispose();
                        }
                    }
                }
                else
                {
                    if (txtbxdocdate.Text == "")
                    {
                        txtbxdocdate.Focus();

                    }
                    else if (ddlstdoctype.SelectedItem.Text == "--Select--")
                    {
                        ddlstdoctype.Focus();
                    }
                    else if (txtbxsurvey.Text == "")
                    {
                        txtbxsurvey.Focus();

                    }
                    else if (txtbxdocs.Text == "")
                    {
                        txtbxdocs.Focus();
                    }
                    else if (ddlstdocct.SelectedItem.Text == "--Select--")
                    {
                        ddlstdocct.Focus();
                    }
                    else if (txtbxdocno.Text.Trim() == "")
                    {
                        txtbxdocno.Focus();
                    }
                    uscMsgBox1.AddMessage("Please Give corresponding Inputs for List of Documents", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    BindAllGrid("D");
                }

            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_ResolveQuery.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
    }
    protected void gvdocs_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "Delete")
        {

            strVald = e.CommandArgument.ToString();
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();

                try
                {
                    string sql = "DELETE FROM  LSD_MOTD_DOCX WHERE MDX_MD_ID=" + Convert.ToInt32(Session["MDIDRSL"].ToString()) + " and MDX_SLNO=" + Convert.ToInt32(strVald);


                    cmd = new SqlCommand(sql, connection);

                    int r = cmd.ExecuteNonQuery();
                    if (r > 0)
                    {
                        BindAllGrid("D");
                        CLear();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Document not deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    try { Response.Redirect("ErrorPage.aspx?parameter=Legal_ResolveQuery.aspx"); }
                    catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
                }
                finally
                {
                    cmd.Dispose();
                }
            }


        }
        if (e.CommandName == "Edit")
        {
            strVald = e.CommandArgument.ToString();

            Session["StatusLGLRSL"] = "Edit";
            Session["SLNORSL"] = strVald;


            foreach (GridViewRow grow in gvdocs.Rows)
            {
                Label lblPSCH = grow.FindControl("lblslno") as Label;
                if (strVald == lblPSCH.Text)
                {
                    string[] dbarr = (grow.FindControl("lbldate") as Label).Text.Split('-');

                    txtbxdocdate.Text = dbarr[0].ToString() + "/" + dbarr[1].ToString() + "/" + dbarr[2].ToString();
                    txtbxdocs.Text = (grow.FindControl("lbldocs") as Label).Text;
                    txtbxsurvey.Text = (grow.FindControl("lblsurvey") as Label).Text;
                    ddlstdoctype.SelectedValue = (grow.FindControl("lbldoctype") as Label).Text;
                    ddlstdocct.SelectedValue = (grow.FindControl("lbldoct") as Label).Text;
                    txtbxdocno.Text = (grow.FindControl("lbldocno") as Label).Text;

                    break;
                }
            }

            btnadd.Text = "Update";
            BindAllGrid("D");

        }
    }
    protected void gvdocs_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void gvdocs_RowEditing(object sender, GridViewEditEventArgs e)
    {
        // gvdocs.EditIndex = e.NewEditIndex;
        BindAllGrid("D");
    }


    protected void gvdocs_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        //gvdocs.EditIndex = -1;

        BindAllGrid("D");
    }
    protected void gvdocs_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindAllGrid("D");
    }
    protected void cb_select_CheckedChanged(object sender, EventArgs e)
    {
        int cntsel = 0;
        Object val;
        foreach (GridViewRow grow in gvQuerydets.Rows)
        {
            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                cntsel++;
            }
        }
        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();
            cmd = new SqlCommand("SELECT MD_ID FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection);
            val = cmd.ExecuteScalar();

        }
        if (cntsel == gvQuerydets.Rows.Count && (val != DBNull.Value && val != null))
        {
            this.lstdocs.Visible = true;
            this.lstdocs1.Visible = true;
        }
        else
        {
            this.lstdocs.Visible = false;
            this.lstdocs1.Visible = false;
        }
    }
    protected void gvdocs_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Char dateSplitter = new Char();
            string tempdate = DataBinder.Eval(e.Row.DataItem, "MDX_DATE").ToString();
            Label lbdate = (Label)e.Row.FindControl("lbldate");


            if (tempdate.Contains(".")) { dateSplitter = '.'; }
            else if (tempdate.Contains("/")) { dateSplitter = '/'; }
            else if (tempdate.Contains("-")) { dateSplitter = '-'; }

            //string[] dbarr = tempdate.Split('/');
            string[] dbarr = tempdate.Split(dateSplitter);
            (e.Row.FindControl("lbldate") as Label).Text = dbarr[1].ToString() + "-" + dbarr[0].ToString() + "-" + dbarr[2].ToString();
        }
    }
    protected void BindAllGrid(string Type)
    {
        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                cmd = new SqlCommand("RTS_SP_BIND_LGL_PREOPINION", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@LDID", Convert.ToInt32(Session["LeadID"].ToString()));
                cmd.CommandTimeout = 120000;
                dspre = new DataSet();
                dappre = new SqlDataAdapter(cmd);
                dappre.Fill(dspre);
                if (Type == "All")
                {

                    if (dspre.Tables.Count > 0)
                    {

                        if (dspre.Tables[0].Rows.Count > 0)
                        {
                            Session["MDIDRSL"] = dspre.Tables[0].Rows[0]["MD_ID"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_ID"].ToString() : null;
                        }
                        else Session["MDIDRSL"] = null;
                       

                        gvdocs.DataSource = dspre.Tables[3];
                        gvdocs.DataBind();
                    }
                    else Session["MDIDRSL"] = null;
                }
                else
                {
                    if (Type == "C")
                    {

                        if (dspre.Tables.Count > 0)
                        {
                           
                        }
                    }
                    else if (Type == "P")
                    {

                        

                    }
                    else if (Type == "D")
                    {
                        gvdocs.DataSource = dspre.Tables[3];
                        gvdocs.DataBind();

                    }
                    else
                    {
                        if (dspre.Tables[0] != null)
                        {
                            if (dspre.Tables[0].Rows.Count > 0)
                            {
                                Session["MDIDRSL"] = dspre.Tables[0].Rows[0]["MD_ID"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_ID"].ToString() : null;
                            }
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                try { Response.Redirect("ErrorPage.aspx?parameter=Legal_ResolveQuery.aspx"); }
                catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
            }
        }
    }
    public void Bind_Doc_Type()
    {
        //

        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                cmd = new SqlCommand("RTS_SP_BIND_LGL_DOC_TYPE", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandTimeout = 120000;
                dtpre = new DataTable();
                dappre = new SqlDataAdapter(cmd);
                dappre.Fill(dtpre);

                ddlstdocct.DataSource = dtpre;

                ddlstdocct.DataTextField = "DT_DESC";
                ddlstdocct.DataValueField = "DT_ID";
                ddlstdocct.DataBind();
                ddlstdocct.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlstdocct.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                try { Response.Redirect("ErrorPage.aspx?parameter=Legal_ResolveQuery.aspx"); }
                catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
            }
        }
    }
}