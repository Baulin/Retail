﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class LegalACK_Send : System.Web.UI.Page
{

    #region Common
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    int ldid, s;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    CreateLogFiles Err = new CreateLogFiles();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                    bind();
                    BindCourierName();
                }

            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }


    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindAck()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_ReceiveDoc", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PR_ID", "0");
            cmd.Parameters.AddWithValue("@LD_BR_ID", ddlBranch.SelectedIndex > 0 ? ddlBranch.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@LD_AR_ID", ddlArea.SelectedIndex > 0 ? ddlArea.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@ReceiveType", "LACKS");
            cmd.Parameters.AddWithValue("@LoanNo", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@Type", "P");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    Session["Leadno"] = ds.Tables[0].Rows[0]["LD_NO"];
            //    getLeadID(con);
            //    btnSubmit.Enabled = true;
            //}
            //else
            //{
            //    btnSubmit.Enabled = false;
            //    uscMsgBox1.AddMessage("Pre-closure document not Hand overd", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            gvLegalSendPreAck.DataSource = ds.Tables[0];
            gvLegalSendPreAck.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvLegalSendPreAck.HeaderRow.Font.Bold = true;
                gvLegalSendPreAck.HeaderRow.Cells[1].Text = "LOAN NO";
                gvLegalSendPreAck.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvLegalSendPreAck.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvLegalSendPreAck.HeaderRow.Cells[4].Text = "PD DATE";
                gvLegalSendPreAck.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvLegalSendPreAck.HeaderRow.Cells[6].Text = "BRANCH NAME";


                gvLegalSendPreAck.HeaderRow.Cells[1].Wrap = false;
                gvLegalSendPreAck.HeaderRow.Cells[2].Wrap = false;
                gvLegalSendPreAck.HeaderRow.Cells[3].Wrap = false;
                gvLegalSendPreAck.HeaderRow.Cells[4].Wrap = false;
                gvLegalSendPreAck.HeaderRow.Cells[5].Wrap = false;
                gvLegalSendPreAck.HeaderRow.Cells[6].Wrap = false;

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        BindAck();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(strcon);

        //SqlCommand cmdAck = new SqlCommand("RTS_SP_Update_MODT_DOc_Values", con);
        try
        {
            foreach (GridViewRow grow in gvLegalSendPreAck.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    leadno = lnbtn.Text;
                    Session["Leadno"] = leadno;
                    break;
                }
            }
            //getLead(con);
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Leadno"])) && fup_Acknwlg.HasFile == true)
            {
                string fileName = string.Empty;
                string fileExt = string.Empty;
                string fileUploadPath = string.Empty;
                con.Open();
                SqlCommand cmd = new SqlCommand("select LD_LOAN_NO from LSD_LEAD where LD_NO ='" + Session["Leadno"] + "' ", con);
                string loanno = Convert.ToString(cmd.ExecuteScalar());
                cmd.Dispose();
                con.Close();
                leadno = Convert.ToString(Session["Leadno"]);
                fileExt = Path.GetExtension(fup_Acknwlg.FileName);
                fileName = leadno.Substring(leadno.Length - 5) + loanno + fileExt;
                fileUploadPath = ConfigurationManager.AppSettings[AppConstants.FileUploadPath] + AppConstants.Directory_Acknowledgement + fileName;
                fup_Acknwlg.SaveAs(Server.MapPath(fileUploadPath));
                getLeadID(con);
                con.Open();
                SqlCommand cmdAck = new SqlCommand("RTS_SP_Update_MODT_DOc_Values", con);
                cmdAck.CommandType = CommandType.StoredProcedure;
                cmdAck.Parameters.AddWithValue("@MD_LD_ID", Session["LeadId"].ToString());
                cmdAck.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                //cmd.Parameters.AddWithValue("@SendBy", "C");
                cmdAck.Parameters.AddWithValue("@CR_ID", ddlName.SelectedIndex > 0 ? ddlName.SelectedValue.ToString() : "");
                cmdAck.Parameters.AddWithValue("@PODorCOntatcNo", txtNumber.Text);
                cmdAck.Parameters.AddWithValue("@TranStatus", "LACKS");
                int n = cmdAck.ExecuteNonQuery();
                if (n > 0)
                {
                    Panel2.Visible = false;
                    Panel3.Visible = false;
                    txtLeadno.Text = "";
                    uscMsgBox1.AddMessage("Acknowlegement Send Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    BindAck();
                }
            }
            else
            {
                if (fup_Acknwlg.HasFile == false)
                    uscMsgBox1.AddMessage("Please upload the Acknowledgement", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
            //cmdAck.Dispose();
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("LegalACK_Send.aspx");
    }

    //protected void rb_select_CheckedChanged(object sender,EventArgs e)
    //{

    //}

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
    }

    public void getLeadID(SqlConnection con)
    {
        try
        {
            SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
            cmdbr.CommandType = CommandType.StoredProcedure;
            cmdbr.Parameters.AddWithValue("@LeadNo", Session["Leadno"].ToString());
            SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
            DataSet dsbr = new DataSet();
            dabr.Fill(dsbr);
            if (dsbr.Tables[0].Rows.Count > 0)
            {
                Session["LeadId"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
            SqlConnection.ClearPool(con);
        }
    }

    public void BindCourierName()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CourierListas", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlName.DataSource = dsdd;
        ddlName.DataTextField = "CR_NAME";
        ddlName.DataValueField = "CR_ID";
        ddlName.DataBind();
        ddlName.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        //panelAddDoc.Visible = false;
        //Panel2.Visible = false;
        //Panel3.Visible = false;
        DataTable dtpre = new DataTable();
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        using (SqlCommand cmdGetLoanDet = new SqlCommand("SP_UNO_BIND_LOAN1", con))
        {
            try
            {
                cmdGetLoanDet.CommandType = CommandType.StoredProcedure;
                cmdGetLoanDet.CommandTimeout = 24000000;
                cmdGetLoanDet.Parameters.AddWithValue("@PTYPE", "LHAS");
                cmdGetLoanDet.Parameters.AddWithValue("@LOANNO", txtLeadno.Text.Trim());
                dtpre.Load(cmdGetLoanDet.ExecuteReader());
                gvLegalRecvDoc.DataSource = dtpre;
                gvLegalRecvDoc.DataBind();
                this.mpPre.Show();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmdGetLoanDet.Dispose();
                con.Close();
                SqlConnection.ClearPool(con);
            }
        }
    }

    protected void lnkname_OnClick(object sender, EventArgs e)
    {
        string loanno = ((LinkButton)sender).Text;
        txtLeadno.Text = loanno;
        BindAck();
    }

    public void getLead(SqlConnection con)
    {
        using (SqlCommand cmdbr = new SqlCommand("SP_UNO_BIND_LOAN", con))
        {
            try
            {
                con.Open();
                cmdbr.CommandType = CommandType.StoredProcedure;
                cmdbr.CommandTimeout = 2400000;
                cmdbr.Parameters.AddWithValue("@LOANNO", txtLeadno.Text.Trim());
                cmdbr.Parameters.AddWithValue("@PTYPE", "GETLEADID");
                Session["Lead"] = Convert.ToString(cmdbr.ExecuteScalar());
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmdbr.Dispose();
                con.Close();
                SqlConnection.ClearPool(con);
            }
        }

    }
}