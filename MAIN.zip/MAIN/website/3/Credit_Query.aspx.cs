﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Tracker;

public partial class Credit_Query : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    //string sa;
    int ldid;
    //int j;
    //int b;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    ClsCommon clscommon = new ClsCommon();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    string[] stringArray = new string[100];


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            bind();
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

        //SqlCommand cmdqry = new SqlCommand("SELECT * FROM LSD_QUERY_GRID", con);
        //SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
        //DataSet dsqry = new DataSet();
        //daqry.Fill(dsqry);
        //gvQueryEntry.DataSource = dsqry.Tables[0];
        //gvQueryEntry.DataBind();

    }
    //Bind the KYC Applicants based on the selected lead no
    public void KYC_details()
    {
        try
        {
            int ld_id = Convert.ToInt32(Session["LeadID"]);
            DataSet dsdd = new DataSet();
            dsdd = clscommon.Bind_KYCApplicats(ld_id);
            DDLkycName.DataSource = dsdd;
            DDLkycName.DataTextField = "KYC_NAME";
            DDLkycName.DataValueField = "KYC_APP_TYPE";
            DDLkycName.DataBind();
            DDLkycName.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    //Load the related Queries main list
    public void LoadRelatedQueryList()
    {
        try
        {

            DataSet ds = new DataSet();
            ds = clscommon.Bind_MRQuery_By_PRSTYPE("PRCREDIT");
            ddlRelatedQry.DataSource = ds;
            ddlRelatedQry.DataTextField = "QY_QUERY";
            ddlRelatedQry.DataValueField = "QY_PRS_ID";
            ddlRelatedQry.DataBind();
            ddlRelatedQry.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    //Bind the list of queries from master query table for credit.
    protected void bindQuery()
    {
        try
        {
            DataSet ds = new DataSet();
            ds = clscommon.Bind_MRQuery_By_PRSTYPE("PRCREDIT");
            gvUserInfo.DataSource = ds;
            gvUserInfo.DataBind();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    //Bind the list of queries from master query table for credit.
    protected void bindQuery_ByProcessID()
    {
        try
        {
            int PRS_ID = Convert.ToInt32(ddlRelatedQry.SelectedValue);
            DataSet ds = new DataSet();
            if (ddlRelatedQry.SelectedItem.Text != "--Select--")
            {
                ds = clscommon.Bind_MRQuery_By_PRSID(PRS_ID);
            }
            else
            {
                ds = clscommon.Bind_MRQuery_By_PRSTYPE("PRCREDIT");
            }
            gvUserInfo.DataSource = ds;
            gvUserInfo.DataBind();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        lbLeadno.Text = "";
        lbAppname.Text = "";
        lbPDdate.Text = "";
        lbLoanamt.Text = "";
        TextBox[] TextBox = pnl.Controls.OfType<TextBox>().ToArray();
        string query = "";
        for (int i = 0; i < TextBox.Length; i++)
        {
            TextBox[i].Text = "";
        }

        bool _passValidation = false;

        pnl.Visible = false;
        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            //Session["View"] = "All";
            //    gridbindall();
            _passValidation = false;
            uscMsgBox1.AddMessage("Please Select Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--" )
        {
            Session["View"] = "F";
            //ddlArea.Enabled = false;
            //  gridbind();
            _passValidation = true;
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";
            //  gridbind();
            _passValidation = true;
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            //  gridbind();
            _passValidation = true;
        }
        //else if (txtLeadno.Text == "" &&ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        //{
        //    uscMsgBox1.AddMessage("Please select Area and Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        //}
        //else if (ddlBranch.SelectedItem.Text == "--Select--")
        //{
        //    uscMsgBox1.AddMessage("Please Select Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        //}
        //else if (txtLeadno.Text == "")
        //{
        //    uscMsgBox1.AddMessage("Please Enter Lead No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

        if (_passValidation)
        {
            BindqueryGrid();
        }
    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_CreatedQuery", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "C");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvQuery.Visible = true;
                //Panel1.Visible = true;
                gvQuery.DataSource = ds1.Tables[0];
                gvQuery.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvQuery.HeaderRow.Font.Bold = true;
                    gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                    gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                    gvQuery.HeaderRow.Cells[1].Wrap = false;
                    gvQuery.HeaderRow.Cells[2].Wrap = false;
                    gvQuery.HeaderRow.Cells[3].Wrap = false;
                    gvQuery.HeaderRow.Cells[4].Wrap = false;
                    gvQuery.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvQuery.Visible = false;
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select distinct LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID LEFT JOIN LSD_QUERY E ON A.LD_ID=E.QRY_LD_ID WHERE FT_SENTBY<>'C' AND FT_SENTBY='B' AND FT_SENTTO='C' AND isnull(FT_RDATE,'')<>'' AND isnull(LD_CRAP_MBY,'')='' AND ISNULL(LD_LC_DATE,'')=''", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows.Count != 0)
            {
                //Panel1.Visible = true;
                gvQuery.DataSource = ds1.Tables[0];
                gvQuery.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvQuery.HeaderRow.Font.Bold = true;
                    gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                    gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                    gvQuery.HeaderRow.Cells[1].Wrap = false;
                    gvQuery.HeaderRow.Cells[2].Wrap = false;
                    gvQuery.HeaderRow.Cells[3].Wrap = false;
                    gvQuery.HeaderRow.Cells[4].Wrap = false;
                    gvQuery.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    public void gridbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select DISTINCT LD_NO,convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_QUERY B ON A.LD_ID=B.QRY_LD_ID LEFT JOIN LSD_FILE_TRANS C ON  C.FT_LD_ID=A.LD_ID LEFT JOIN MR_BRANCH D ON A.LD_BR_ID=D.BR_ID LEFT JOIN MR_AREA E ON E.AR_ID=D.BR_AR_ID WHERE FT_SENTTO='C' AND ISNULL(FT_RDATE,'')<>'' AND LD_NO='" + txtLeadno.Text + "' AND ISNULL(LD_LC_DATE,'')='' OR FT_SENTTO='C' AND ISNULL(FT_RDATE,'')<>'' AND AR_NAME='" + ddlArea.SelectedItem.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedItem.ToString() + "' AND ISNULL(LD_LC_DATE,'')='' ORDER BY LD_NO DESC", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count != 0)
            {
                //Panel1.Visible = true;
                gvQuery.DataSource = ds.Tables[0];
                gvQuery.DataBind();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    gvQuery.HeaderRow.Font.Bold = true;
                    gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                    gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                    gvQuery.HeaderRow.Cells[1].Wrap = false;
                    gvQuery.HeaderRow.Cells[2].Wrap = false;
                    gvQuery.HeaderRow.Cells[3].Wrap = false;
                    gvQuery.HeaderRow.Cells[4].Wrap = false;
                    gvQuery.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            con.Open();
            var ddl = (CheckBoxList)e.Row.FindControl("ddlCity");
            //var txtremarks = (CheckBoxList)e.Row.FindControl("txtRemarks");
            string CountryId = e.Row.Cells[1].Text.ToString();
            SqlCommand cmd = new SqlCommand("select QY_QUERY,QY_SQUERY from MR_QUERY  where QY_QUERY='" + CountryId + "' ORDER BY QY_QUERY,QY_SQUERY ASC", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            ddl.DataSource = ds;
            ddl.DataTextField = "QY_SQUERY";
            ddl.DataValueField = "QY_QUERY";
            ddl.DataBind();

            //GridView gvOrders = e.Row.FindControl("gvOrders") as GridView;
            //SqlCommand cmd1 = new SqlCommand("select QY_QUERY,QY_SQUERY from MR_QUERY  where QY_QUERY='" + CountryId + "' ORDER BY QY_QUERY,QY_SQUERY ASC", con);
            //SqlDataAdapter da1 = new SqlDataAdapter(cmd);
            //DataSet ds1 = new DataSet();
            //da1.Fill(ds1);
            //con.Close();
            //gvOrders.DataSource = ds1;
            //gvOrders.DataBind();

            GridView gvQueries = (GridView)e.Row.FindControl("gvQueries");
            DataSet dsqry = new DataSet();

            dsqry = clscommon.Bind_Queries_By_QY_QUERY(CountryId);

            gvQueries.DataSource = dsqry;
            gvQueries.DataBind();

            //ddl.Items.Insert(0, new ListItem("--Select--", "0"));



        }
    }
    protected void cb_select_CheckedChanged(object sender, EventArgs e)
    {
        foreach (GridViewRow grow in gvUserInfo.Rows)
        {
            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
            int index = grow.RowIndex;
            GridView gvQueries = (GridView)grow.FindControl("gvQueries");


            if (chkStat.Checked)
            {
                CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                chkStat1.Enabled = true;
                //txtRemarks.Enabled = true ;
                foreach (GridViewRow growQuery in gvQueries.Rows)
                {

                    CheckBox chkQuery = growQuery.FindControl("chkQuery") as CheckBox;
                    TextBox txtRemarks1 = growQuery.FindControl("txtRemarks1") as TextBox;
                    chkQuery.Enabled = true;
                    txtRemarks1.Enabled = true;
                }
            }
            else
            {
                CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                int index1 = grow.RowIndex;
                foreach (ListItem i in chkStat1.Items)
                {
                    i.Selected = false;

                }
                foreach (GridViewRow growQuery in gvQueries.Rows)
                {

                    CheckBox chkQuery = growQuery.FindControl("chkQuery") as CheckBox;
                    TextBox txtRemarks1 = growQuery.FindControl("txtRemarks1") as TextBox;
                    chkQuery.Enabled = false;
                    chkQuery.Checked = false;
                    txtRemarks1.Visible = false;
                }
                chkStat1.Enabled = false;
                txtRemarks.Enabled = true;
            }
        }
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        TextBox[] TextBox = pnl.Controls.OfType<TextBox>().ToArray();
        string query = "";
        for (int i = 0; i < TextBox.Length; i++)
        {
            TextBox[i].Text = "";
        }

        foreach (GridViewRow grow in gvQuery.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
            Label lblLeadID = grow.FindControl("lblLeadID") as Label;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                leadno = lnbtn.Text;
                appname = gvQuery.Rows[index].Cells[3].Text;
                pddt = gvQuery.Rows[index].Cells[4].Text;
                lnamt = gvQuery.Rows[index].Cells[5].Text;
                Session["LeadID"] = lblLeadID.Text;
                KYC_details();
                LoadRelatedQueryList();
            }
        }
        /* Bala changes 31/03/2018
        pnl.Visible = false;
        bindQuery();
        gvUserInfo.Visible = true;
 tdApplicant.Visible = true;
        tdRelatedType.Visible = true;
        tdRelatedType1.Visible = true;
        tdKYC.Visible = true;
        */
        pnl.Visible = true;
        bindQuery();
        gvUserInfo.Visible = false;
        tdApplicant.Visible = false;
        tdRelatedType.Visible = false;
        tdRelatedType1.Visible = false;
        tdKYC.Visible = false;

        //gvQueryEntry.Visible = true;
        lbLeadno.Visible = true;
        lbAppname.Visible = true;
        lbPDdate.Visible = true;
        lbLoanamt.Visible = true;
        //Label1.Visible = true;
        //TextBox10.Visible = true;
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;


        lbLeadno.Text = leadno.ToString();
        lbAppname.Text = appname;
        lbPDdate.Text = pddt;
        lbLoanamt.Text = lnamt;
        con.Close();
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Credit_QueryPopUp.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
    }
    public void InsertQueries()
    {

        if (TextBox1.Text.Trim() == "" && TextBox2.Text.Trim() == "" && TextBox3.Text.Trim() == "" && TextBox4.Text.Trim() == "" &&
              TextBox5.Text.Trim() == "" && TextBox6.Text.Trim() == "" && TextBox7.Text.Trim() == "" && TextBox8.Text.Trim() == "" &&
              TextBox9.Text.Trim() == "" && TextBox10.Text.Trim() == "")
        {
            uscMsgBox1.AddMessage("Please Enter Query", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            SqlConnection con = new SqlConnection(strcon);
            try
            {
                con.Open();
                Label lblLeadID = null;
                foreach (GridViewRow grow in gvQuery.Rows)
                {
                    CheckBox chkStat = grow.FindControl("rb_select") as CheckBox;
                    int index = grow.RowIndex;
                    if (chkStat.Checked)
                    {
                        lblLeadID = (Label)gvQuery.Rows[index].Cells[0].FindControl("lblLeadID");
                    }
                }
                TextBox[] TextBox = pnl.Controls.OfType<TextBox>().ToArray();
                string query = "";
                for (int i = 0; i < TextBox.Length; i++)
                {

                    if (i == 0)
                    {
                        query = TextBox[i].Text;
                    }
                    if (i >= 1)
                    {
                        if (TextBox[i].Text.Trim() != "")
                        {
                            query += "|" + TextBox[i].Text;
                            TextBox[i].Text = "";
                        }
                    }

                    // TextBox[i].Text = query;

                    //if (query != "")
                    //{
                    //    SqlCommand cmdinsert = new SqlCommand("insert into LSD_QUERY(QRY_DATE,QRY_LD_ID,QRY_RSD_BY,QRY_QUERY,QRY_CBY,QRY_CDATE) values (getdate(),'" + ldid + "','C','" + TextBox[i].Text.Replace("'","''") + "','" + Session["ID"].ToString() + "',getdate())", con);
                    //    cmdinsert.ExecuteNonQuery();
                    //}
                    //TextBox[i].Text = "";
                }

                string strVal = query;
                if (query != "")
                {
                    SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertQuery", con);
                    cmdinsert.CommandType = CommandType.StoredProcedure;
                    cmdinsert.Parameters.AddWithValue("@Queries", query);
                    cmdinsert.Parameters.AddWithValue("@QRY_LD_ID", lblLeadID.Text);
                    cmdinsert.Parameters.AddWithValue("@QRY_RSD_BY", "C");
                    cmdinsert.Parameters.AddWithValue("@QRY_CBY", Session["ID"].ToString());
                    cmdinsert.ExecuteNonQuery();
                    BindqueryGrid();
                    lbLeadno.Text = "";
                    lbAppname.Text = "";
                    lbPDdate.Text = "";
                    lbLoanamt.Text = "";
                    pnl.Visible = false;
                    //TextBox10.Text = "";
                    uscMsgBox1.AddMessage("Query Raised Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                }

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                uscMsgBox1.AddMessage("Special characters will not be Allowed in Query", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            finally
            {
                con.Close();
            }
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertQueries();

        /* int i1 = 0, i3 = 0;
         SqlConnection con = new SqlConnection(strcon);
         try
         {
             con.Open();
             SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + lbLeadno.Text + "'", con);
             SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
             DataSet dsbr = new DataSet();
             dabr.Fill(dsbr);
             ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
             string a;

             foreach (GridViewRow grow in gvUserInfo.Rows)
             {
                 CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                 int index = grow.RowIndex;
                 GridView gvQueries = (GridView)grow.FindControl("gvQueries");
                 if (chkStat.Checked)
                 {
                     i1++;
                     a = gvUserInfo.Rows[index].Cells[1].Text.ToString();
                     chkStat.Enabled = false;
                     CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                     TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
                     int index1 = grow.RowIndex;
                     foreach (GridViewRow growQuery in gvQueries.Rows)
                     {

                         CheckBox chkQuery = growQuery.FindControl("chkQuery") as CheckBox;
                         Label lblSquery = growQuery.FindControl("lblSquery") as Label;
                         TextBox txtRemarks1 = growQuery.FindControl("txtRemarks1") as TextBox;
                        // foreach (ListItem i2 in chkStat1.Items)
                        // {
                            // if (i2.Selected)
                          if (chkQuery.Checked)
                         {
                                 i3++;
                                 string b;
                                 b = DDLkycName.SelectedValue + "|" + DDLkycName.SelectedItem.Text + "|" + lblSquery.Text.ToString();
                                 
                                 if (txtRemarks1.Text != "")
                                 {
                                     b = b + "|" + txtRemarks1.Text;
                                 }
                                 SqlCommand cmdsqry = new SqlCommand("select QRY_SQUERY from LSD_QUERY where QRY_RSD_BY='C' and QRY_LD_ID='" + ldid + "' and QRY_SQUERY='" + b + "'", con);
                                 SqlDataAdapter dasqry = new SqlDataAdapter(cmdsqry);
                                 DataSet dssqry = new DataSet();
                                 dasqry.Fill(dssqry);
                                 int count = dssqry.Tables[0].Rows.Count;
                                 if (count == 0)
                                 {
                                     SqlCommand cmdinsert = new SqlCommand("insert into LSD_QUERY(QRY_DATE,QRY_LD_ID,QRY_RSD_BY,QRY_QUERY,QRY_SQUERY,QRY_CBY,QRY_CDATE) values (getdate(),'" + ldid + "','C','" + a + "','" + b + "','" + Session["ID"].ToString() + "',getdate())", con);
                                     cmdinsert.ExecuteNonQuery();
                                 }
                                 else
                                 {
                                     uscMsgBox1.AddMessage("Selected Query is Already Exist", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                                 }
                             }
                         //}
                     }
                 }
             }

             ///////// mail ///////////
             SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + lbLeadno.Text + "'", con);
             SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
             DataSet dsdet = new DataSet();
             dadet.Fill(dsdet);

             SqlCommand cmdmail = new SqlCommand("select QRY_SQUERY 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + lbLeadno.Text + "' AND QRY_RSD_BY='H'", con);
             SqlDataAdapter damail = new SqlDataAdapter(cmdmail);
             DataSet dsmail = new DataSet();
             damail.Fill(dsmail);

              
             lbLeadno.Text = "";
             lbAppname.Text = "";
             lbPDdate.Text = "";
             lbLoanamt.Text = "";
             gvUserInfo.Visible = false;
             btnSubmit.Enabled = false;
             tdApplicant.Visible = false;
             tdRelatedType.Visible = false;
             tdRelatedType1.Visible = false;
             tdKYC.Visible = false;
             if ((i1 > 0) && (i3 > 0))
             {
                 uscMsgBox1.AddMessage("Query Raised Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
             }
             else
             {
                 uscMsgBox1.AddMessage("Please select any one of the query.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
             }
                
         }
         catch (Exception ex)
         {
             ErrorLog.WriteError(ex);
             uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
         }
         finally
         {
             con.Close();
         }*/
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Credit_Query.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
        txtLeadno.Enabled = false;
    }
    protected void ddlCity_SelectedIndexChanged(object sender, EventArgs e)
    {

        foreach (GridViewRow grow in gvUserInfo.Rows)
        {
            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {

                // a = gvUserInfo.Rows[index].Cells[1].Text.ToString();
                chkStat.Enabled = false;
                CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
                int index1 = grow.RowIndex;
                foreach (ListItem i2 in chkStat1.Items)
                {
                    if (i2.Selected)
                    {
                        txtRemarks.Visible = true;
                    }
                    else
                    {
                        txtRemarks.Visible = false;
                    }
                }
            }
        }

    }
    protected void ddlRelatedQry_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            bindQuery_ByProcessID();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void chkQuery_CheckedChanged(object sender, EventArgs e)
    {

        foreach (GridViewRow grow in gvUserInfo.Rows)
        {
            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            TextBox txtRemarks = grow.FindControl("txtRemarks") as TextBox;
            int index = grow.RowIndex;
            GridView gvQueries = (GridView)grow.FindControl("gvQueries");


            if (chkStat.Checked)
            {
                CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                chkStat1.Enabled = true;
                //txtRemarks.Enabled = true ;
                foreach (GridViewRow growQuery in gvQueries.Rows)
                {

                    CheckBox chkQuery = growQuery.FindControl("chkQuery") as CheckBox;
                    TextBox txtRemarks1 = growQuery.FindControl("txtRemarks1") as TextBox;
                    chkQuery.Enabled = true;
                    if (chkQuery.Checked)
                    {
                        txtRemarks1.Visible = true;
                    }
                    else
                    {
                        txtRemarks1.Visible = false;
                    }
                }
            }
            else
            {
                CheckBoxList chkStat1 = grow.FindControl("ddlCity") as CheckBoxList;
                int index1 = grow.RowIndex;
                foreach (ListItem i in chkStat1.Items)
                {
                    i.Selected = false;

                }
                foreach (GridViewRow growQuery in gvQueries.Rows)
                {

                    CheckBox chkQuery = growQuery.FindControl("chkQuery") as CheckBox;
                    TextBox txtRemarks1 = growQuery.FindControl("txtRemarks1") as TextBox;
                    chkQuery.Enabled = false;
                    if (!chkQuery.Checked)
                    {
                        txtRemarks1.Visible = false;
                    }

                    //txtRemarks1.Enabled = true;



                }
                chkStat1.Enabled = false;
                txtRemarks.Enabled = true;
            }
        }
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
    }
    protected void gvQueries_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

        }
    }
}