﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Credit_DM_Resolve_Query : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string sa;
    int ldid;
    int qryldid;
    int j;
    int b;
    int selectedcnt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            bind();
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("select AR_NAME from MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_NAME";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));        
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        gvQuerydets.Visible = false;
        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "All";            
        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            ddlArea.Enabled = false;            
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";            
        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";            
        }
        BindSendReceiveGrid();
    }
    public void BindSendReceiveGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_DMCApprvList_Query", con);
            cmd.CommandType = CommandType.StoredProcedure;
          //  cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@STAGE", "RESOLVE");
           // cmd.Parameters.AddWithValue("@QRY_RSD_BY", "D");     
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);            
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvQuery.Visible = true;
                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {            
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        foreach (GridViewRow grow in gvQuery.Rows)
        {
            Label lblLeadID = grow.FindControl("lblLeadID") as Label;
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                Session["LeadID"] = lblLeadID.Text;
                leadno = lnbtn.Text;
                appname = gvQuery.Rows[index].Cells[3].Text;
                pddt = gvQuery.Rows[index].Cells[4].Text;
                lnamt = gvQuery.Rows[index].Cells[5].Text;
            }
        }
        Session["Leadno"] = leadno;
        qrydetsbind();

        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;

        con.Close();
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Credit_QueryPopUp.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
    }
    public void qrydetsbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        qryldid = Session["LeadID"] != null ? Convert.ToInt32(Session["LeadID"]) : 0;

        SqlCommand cmdqry = new SqlCommand("SELECT QRY_ID,QRY_QUERY,QRY_RESPONSE FROM LSD_QUERY where QRY_LD_ID='" + qryldid + "' and isnull(QRY_RESP_DATE,'')<>'' AND isnull(QRY_RSL_DATE,'')='' AND QRY_RSD_BY='D'", con);
        SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
        DataSet dsqry = new DataSet();
        daqry.Fill(dsqry);
        gvQuerydets.DataSource = dsqry.Tables[0];
        gvQuerydets.DataBind();
        gvQuerydets.Visible = true;
        con.Close();
    }
    public void InsertUpdateCreditResolve()
    {
        foreach (GridViewRow grow1 in gvQuerydets.Rows)
        {
            CheckBox chkStat1 = grow1.FindControl("cb_select") as CheckBox;
            int index1 = grow1.RowIndex;
            int count = Convert.ToInt32(chkStat1.Checked);
            if (count != 0)
            {
                selectedcnt = 0;
                foreach (GridViewRow grow in gvQuerydets.Rows)
                {

                    CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                    int index = grow.RowIndex;
                    //int cnt = grow.
                    //if (count != 0)
                    //{
                    if (chkStat.Checked)
                    {
                        selectedcnt++;
                        SqlConnection con = new SqlConnection(strcon);
                        try
                        {
                            Label lbquery = grow.FindControl("lblname") as Label;
                            Label lbrsp = grow.FindControl("lblrsp") as Label;
                            Label lbqueryid = grow.FindControl("lblqryid") as Label;
                            string resp = lbrsp.Text;
                            string qry = lbquery.Text;
                            int qryid = Convert.ToInt32(lbqueryid.Text);
                            con.Open();

                            ldid = Session["LeadID"] != null ? Convert.ToInt32(Session["LeadID"].ToString()) : 0;

                            SqlCommand cmdupdate = new SqlCommand("update LSD_QUERY set QRY_RSL_DATE=getdate(),QRY_MBY='" + Session["ID"].ToString() + "',QRY_MDATE=getdate() where QRY_LD_ID='" + ldid + "' AND QRY_ID='" + qryid + "' AND QRY_RSD_BY='D'", con);
                            cmdupdate.ExecuteNonQuery();
                            //qrydetsbind();
                            gvQuerydets.Visible = false;
                            lbLeadno.Text = "";
                            lbAppname.Text = "";
                            lbPDdate.Text = "";
                            lbLoanamt.Text = "";
                            //txtResolve.Text = "";
                            btnSubmit.Enabled = false;
                        }
                        catch (Exception ex)
                        {
                            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            ErrorLog.WriteError(ex);
                        }
                        finally
                        {
                            con.Close();
                        }
                    }
                   
                }
            }           
        }
        if (selectedcnt == 0)
        {
            gvQuerydets.Visible = false;
            uscMsgBox1.AddMessage("Please Select Query To Resolve", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            gvQuery.DataSource = null;
            gvQuery.DataBind();
            BindSendReceiveGrid();
            uscMsgBox1.AddMessage("Query Resolved Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }      
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertUpdateCreditResolve();       
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Credit_DM_Resolve_Query.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_NAME";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Enabled = false;
    }
}