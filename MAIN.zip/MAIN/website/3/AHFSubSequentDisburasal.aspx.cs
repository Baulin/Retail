﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using System.Net.Mail;
using Utilities;
using Tracker;
public partial class AHFSubSequentDisburasal : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    //string sa;
    int ldid;
    //int j;
    //int b;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    DateTime dt = DateTime.Now;
    string[] stringArray = new string[100];
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    public static bool blMailStatus = false;
    public static double dblSubSeqAMount = 0;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {

            if (!IsPostBack)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);

                txtSancDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                txtCustCatgry.Text = "NON MEMBER";
                bind();
                //if (Session["TYPEID"].ToString() == "2")
                //{

                ddlArea.SelectedValue = Session["AREA_ID"].ToString();
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
                cmdrsn.CommandType = CommandType.StoredProcedure;
                cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
                SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
                DataSet dsrsn = new DataSet();
                darsn.Fill(dsrsn);
                con.Close();

                ddlBranch.DataSource = dsrsn;
                ddlBranch.DataTextField = "BR_NAME";
                ddlBranch.DataValueField = "BR_ID";
                ddlBranch.DataBind();
                ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));

                ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
                //}
                //else
                //{
                //    tblAprove.Visible = true;
                //    trAprove.Visible = true;
                //}


            }
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_NAME";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

        //SqlCommand cmdqry = new SqlCommand("SELECT * FROM LSD_QUERY_GRID", con);
        //SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
        //DataSet dsqry = new DataSet();
        //daqry.Fill(dsqry);
        //gvQueryEntry.DataSource = dsqry.Tables[0];
        //gvQueryEntry.DataBind();
    }
    protected void txtLeadNo_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnGenerate_Click(object sender, EventArgs e)
    {
        int n;
        bindConsStage();
        if (Session["TYPEID"].ToString() == "2")
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("select COUNT( *) from LSD_SUB_DISB_MEMO where DM_LOAN_NO='" + txtLoanNo.Text + "' AND (DM_APRL <> 'HOLD' OR DM_APRL IS NULL)", con);
            n = Convert.ToInt32(cmddd.ExecuteScalar());
            if (n == 0)
            {
                FetchDMCValues();
            }
            else
            {
                uscMsgBox1.AddMessage("Invalid Loan No  OR Already DM generate for given Loan No Please check..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
        }
        else
        {
            FetchDMCValues();
        }


    }
    public void bindConsStage()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("Select * from MR_CON_TYPE", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlConstrTye.DataSource = dsdd;
        ddlConstrTye.DataTextField = "CE_DESC";
        ddlConstrTye.DataValueField = "CE_RATE";
        ddlConstrTye.DataBind();
        ddlConstrTye.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void FetchDMCValues()
    {
        try
        {
            DataTable dtCam = null;
            DataTable dtDMCDetail = null;
            if (txtLoanNo.Text != "")
            {
                DataTable dtSource = null;
                dtDMCDetail = fetchDisbursementDetails().Tables[1];
                DataTable dtLastStages = fetchDisbursementDetails().Tables[2];
                //if( dtDMCDetail != null && dtDMCDetail.Rows.Count >0)
                //{
                //    dtCam = fetchCamDetail().Tables[0];
                //    dtSource = fetchCamDetail().Tables[1];
                //    if (dtSource != null && dtSource.Rows.Count > 0)
                //    {
                //        gvIncomeDetail.DataSource = dtSource;
                //        gvIncomeDetail.DataBind();

                //    }
                if (dtDMCDetail != null && dtDMCDetail.Rows.Count > 0)
                {
                    txtLoanNUmber.Text = txtLoanNo.Text;
                    gvBuildType.DataSource = dtDMCDetail;
                    gvBuildType.DataBind();
                    gvConstrStage.DataSource = dtLastStages;
                    gvConstrStage.DataBind();
                    //bala changes 13/02/2018
                    string strSancNO = dtDMCDetail.Rows[0]["SANCPROCNO"] != DBNull.Value ? dtDMCDetail.Rows[0]["SANCPROCNO"].ToString() : "";
                   // string strSancNO = "SKMBKM0008633";
                    dblSubSeqAMount = 0;
                    for (int nCount = 0; nCount < dtDMCDetail.Rows.Count; nCount++)
                    {
                        double dblTempSubSeqAMount = 0;
                        dblTempSubSeqAMount = Convert.ToString(dtDMCDetail.Rows[nCount]["Amount"]) != "" ? Convert.ToDouble(dtDMCDetail.Rows[nCount]["Amount"]) : 0.0;
                        dblSubSeqAMount = dblSubSeqAMount + dblTempSubSeqAMount;
                        txtPreTotal.Text = dblSubSeqAMount.ToString();
                    }
                    if (strSancNO != "")
                    {
                        DataTable dtSanc = null;
                        dtSanc = fetchSanction(strSancNO);

                        if (dtSanc != null && dtSanc.Rows.Count > 0)
                        {
                            //
                            tblDMC.Visible = true;
                            txtLeadNo1.Text = dtSanc.Rows[0]["LD_NO"] != DBNull.Value ? dtSanc.Rows[0]["LD_NO"].ToString() : "";
                            // txtLeadNo1.Text = Session["LeadNo"].ToString();
                            //txtAreaName.Text = dtCam.Rows[0]["AR_NAME"] != DBNull.Value ? dtCam.Rows[0]["AR_NAME"].ToString() : "";
                            //txtBranchName.Text = dtCam.Rows[0]["BR_NAME"] != DBNull.Value ? dtCam.Rows[0]["BR_NAME"].ToString() : "";
                            //txtMemberID.Text = dtCam.Rows[0]["LD_MID"] != DBNull.Value ? dtCam.Rows[0]["LD_MID"].ToString() : "";
                            //txtAreType.Text = dtCam.Rows[0]["CAM_ATYPE"] != DBNull.Value ? dtCam.Rows[0]["CAM_ATYPE"].ToString() : "";

                            //txtLandSqft.Text = dtCam.Rows[0]["CAM_LAREA"] != DBNull.Value ? dtCam.Rows[0]["CAM_LAREA"].ToString() : "";
                            //txtGudLine.Text = dtCam.Rows[0]["CAM_GLV"] != DBNull.Value ? dtCam.Rows[0]["CAM_GLV"].ToString() : "";
                            //txtMrktVal.Text = dtCam.Rows[0]["CAM_MV"] != DBNull.Value ? dtCam.Rows[0]["CAM_MV"].ToString() : "";
                            //txtLanVal.Text = dtCam.Rows[0]["CAM_CLV"] != DBNull.Value ? dtCam.Rows[0]["CAM_CLV"].ToString() : "";

                            //txtConstrCost.Text = dtCam.Rows[0]["CAM_CBV"] != DBNull.Value ? dtCam.Rows[0]["CAM_CBV"].ToString() : "";

                            //txtConstrType.Text = dtCam.Rows[0]["CE_DESC"] != DBNull.Value ? dtCam.Rows[0]["CE_DESC"].ToString() : "";
                            //txtVal.Text = dtCam.Rows[0]["CE_RATE"] != DBNull.Value ? dtCam.Rows[0]["CE_RATE"].ToString() : "";
                            //txtconstArea.Text = dtCam.Rows[0]["CAM_BAREA"] != DBNull.Value ? dtCam.Rows[0]["CAM_BAREA"].ToString() : "";
                            //txtConstrCost1.Text = dtCam.Rows[0]["CAM_CBV"] != DBNull.Value ? dtCam.Rows[0]["CAM_CBV"].ToString() : "";
                            //txtLCRPer.Text = dtCam.Rows[0]["CAM_LCR_PER"] != DBNull.Value ? dtCam.Rows[0]["CAM_LCR_PER"].ToString() : "";
                            //txtMFHFLCR.Text = dtCam.Rows[0]["CAM_LCR_PER"] != DBNull.Value ? dtCam.Rows[0]["CAM_LCR_PER"].ToString() : "";
                            //txtLCRValue.Text = dtCam.Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dtCam.Rows[0]["CAM_LTV_LCR"].ToString() : "";
                            txtProposalNo.Text = strSancNO;
                            //txtTotPropVal.Text = dtCam.Rows[0]["CAM_TPV"] != DBNull.Value ? dtCam.Rows[0]["CAM_TPV"].ToString() : "";
                            //dtSanc.Rows[0]["PROPOSAL NO"] != DBNull.Value ? dtSanc.Rows[0]["PROPOSAL NO"].ToString() : "";
                            //txtExtendArea.Text = dtCam.Rows[0]["MD_EXTENT"] != DBNull.Value ? dtCam.Rows[0]["MD_EXTENT"].ToString() : "";


                            txtLoanAMount.Text = dtSanc.Rows[0]["LNAMT"] != DBNull.Value ? dtSanc.Rows[0]["LNAMT"].ToString() : "";
                            txtLoanAMount1.Text = dtSanc.Rows[0]["LNAMT"] != DBNull.Value ? dtSanc.Rows[0]["LNAMT"].ToString() : "";
                            //txtROI.Text = dtSanc.Rows[0]["RATE_OF_INTEREST"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["RATE_OF_INTEREST"]).ToString() : "";
                            txtROI.Text = dtSanc.Rows[0]["Interest Rate During Fixed Interest Period"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["Interest Rate During Fixed Interest Period"]).ToString() : "";
                            txtEMI.Text = dtSanc.Rows[0]["EMIAMOUNT"] != DBNull.Value ? dtSanc.Rows[0]["EMIAMOUNT"].ToString() : "";
                            txtTenor.Text = dtSanc.Rows[0]["CUSTTNRMNTHS"] != DBNull.Value ? dtSanc.Rows[0]["CUSTTNRMNTHS"].ToString() : "";

                            txtKLI.Text = dtSanc.Rows[0]["CSINSPREUM"] != DBNull.Value ? dtSanc.Rows[0]["CSINSPREUM"].ToString() : "";
                            txNIA.Text = dtSanc.Rows[0]["GENINSPREUM"] != DBNull.Value ? dtSanc.Rows[0]["GENINSPREUM"].ToString() : "";


                            //if (txtTotPropVal.Text != "" && txtLoanAMount.Text != "")
                            //{
                            //    double dblLTV = (Convert.ToDouble(txtLoanAMount.Text) / Convert.ToDouble(txtTotPropVal.Text)) * 100;
                            //    txtMFHFLTV.Text = Math.Round(dblLTV).ToString();
                            //}
                            txtMFHFLCR.Text = dtSanc.Rows[0]["LCR"] != DBNull.Value ? dtSanc.Rows[0]["LCR"].ToString() : "";
                            txtMFHFLTV.Text = dtSanc.Rows[0]["LTV"] != DBNull.Value ? dtSanc.Rows[0]["LTV"].ToString() : "";
                            double processFee = dtSanc.Rows[0]["PF"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["PF"]) : 0.0;
                            double TechCharge = dtSanc.Rows[0]["TECH_PF"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["TECH_PF"]) : 0.0;
                            double AdminCharge = dtSanc.Rows[0]["ADMIN_FEE"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["ADMIN_FEE"]) : 0.0;
                            double Cersal = dtSanc.Rows[0]["CERSAI"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["CERSAI"]) : 0.0;
                            Session["PF"] = processFee;
                            Session["TechCharge"] = TechCharge;
                            Session["AdminCharge"] = AdminCharge;
                            Session["Cersal"] = Cersal;

                            double lgnfee = dtSanc.Rows[0]["LD_LGN_FEE"] != DBNull.Value ? Convert.ToDouble(dtSanc.Rows[0]["LD_LGN_FEE"]) : 0.0;
                            double actProcessFee = Convert.ToDouble(processFee) != 0 ? Convert.ToDouble(processFee) - Convert.ToDouble(lgnfee) : 0.0;
                            //txtlgnfee.Text = Convert.ToString(lgnfee);
                            double Charge = Math.Round(actProcessFee + TechCharge + AdminCharge + Cersal);
                            double Charge1 = Convert.ToDouble(txtPreTotal.Text) + Charge;
                            txtCharge.Text = Charge.ToString();
                            //Bala changes Starts 17/03/2016
                            //txtPreTotal.Text = Charge1.ToString();
                            txtPreTotal.Text = dtSanc.Rows[0]["DISBAMT"] != DBNull.Value ? dtSanc.Rows[0]["DISBAMT"].ToString() : "0";
                            // txtCrdAprvDate.Text = dtCam.Rows[0]["LD_CRAP_DATE"] != DBNull.Value ? Convert.ToDateTime(dtCam.Rows[0]["LD_CRAP_DATE"]).ToString("dd/MM/yyyy") : "";
                            txtSanDate.Text = dtSanc.Rows[0]["DATE"] != DBNull.Value ? Convert.ToDateTime(dtSanc.Rows[0]["DATE"]).ToString("dd/MM/yyyy") : "";

                            ddlArea.SelectedItem.Text = dtSanc.Rows[0]["AR_NAME"] != DBNull.Value ? dtSanc.Rows[0]["AR_NAME"].ToString() : "--Select--";
                            ddlBranch.SelectedItem.Text = dtSanc.Rows[0]["BR_NAME"] != DBNull.Value ? dtSanc.Rows[0]["BR_NAME"].ToString() : "--Select--";

                            if (Convert.ToString(dtSanc.Rows[0]["DMD_AR_TYPE_ID"]) == "1")
                            {
                                rdnRural.Checked = true;
                            }
                            else
                            {
                                rdnUrban.Checked = true;
                            }

                            DataSet ds = fetchDMCDetail();


                            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                            {
                                txtDate.Text = ds.Tables[0].Rows[0]["DM_DATE"] != DBNull.Value ? Convert.ToDateTime(ds.Tables[0].Rows[0]["DM_DATE"]).ToString("dd MMM yyyy") : "";
                                txtLoanNUmber.Text = ds.Tables[0].Rows[0]["DM_LOAN_NO"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_LOAN_NO"].ToString() : "";
                                ddlBuldType.SelectedValue = ds.Tables[0].Rows[0]["DM_BLD_TYPE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_BLD_TYPE"].ToString() : "";
                                txtAmount.Text = ds.Tables[0].Rows[0]["DM_NET_AMT"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_NET_AMT"].ToString() : "";

                                //   ddlArea.SelectedValue = ds.Tables[0].Rows[0]["DM_AREA"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_AREA"].ToString() : "";
                                //  ddlBranch.SelectedValue = ds.Tables[0].Rows[0]["DM_BRANCH"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_BRANCH"].ToString() : "";
                                txtMemberID.Text = ds.Tables[0].Rows[0]["DM_MID"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_MID"].ToString() : "";


                                if (txtMemberID.Text == "")
                                {
                                    txtCustCatgry.Text = "NON MEMBER";
                                }
                                else
                                {
                                    txtCustCatgry.Text = "MEMBER";
                                }

                                txtLandSqft.Text = ds.Tables[0].Rows[0]["DM_LAREA"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_LAREA"].ToString() : "";
                                txtGudLine.Text = ds.Tables[0].Rows[0]["DM_GV"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_GV"].ToString() : "";
                                txtMrktVal.Text = ds.Tables[0].Rows[0]["DM_MV"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_MV"].ToString() : "";
                                txtLanVal.Text = ds.Tables[0].Rows[0]["DM_LV"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_LV"].ToString() : "";

                                ddlConstrTye.SelectedItem.Text = ds.Tables[0].Rows[0]["DM_CON_TYPE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CON_TYPE"].ToString() : "";
                                txtconstArea.Text = ds.Tables[0].Rows[0]["DM_CON_AREA"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CON_AREA"].ToString() : "";
                                txtVal.Text = ds.Tables[0].Rows[0]["DM_VALUE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_VALUE"].ToString() : "";
                                txtConstrCost.Text = ds.Tables[0].Rows[0]["DM_CON_COST"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CON_COST"].ToString() : "";
                                txtConstrCost1.Text = ds.Tables[0].Rows[0]["DM_CON_COST"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CON_COST"].ToString() : "";
                                if (txtConstrCost.Text != "" && txtLoanAMount.Text != "")
                                {
                                    double dblCnstrCost = Convert.ToDouble(txtConstrCost.Text) - Convert.ToDouble(txtLoanAMount.Text);
                                    txtMarginAmount.Text = Math.Round(dblCnstrCost).ToString();
                                }

                                txtLCRPer.Text = ds.Tables[0].Rows[0]["DM_LCR_PER"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_LCR_PER"].ToString() : "";
                                txtLCRValue.Text = ds.Tables[0].Rows[0]["DM_LCR_AMT"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_LCR_AMT"].ToString() : "";
                                txtTotPropVal.Text = ds.Tables[0].Rows[0]["DM_PV"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PV"].ToString() : "";

                                ddlBuldType.Enabled = false;
                                if (ddlBuldType.SelectedIndex > 0)
                                {
                                    string strStage = "";
                                    strStage = ds.Tables[0].Rows[0]["DM_CON_STAGE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CON_STAGE"].ToString() : "";

                                    if (ddlBuldType.SelectedValue == "GF")
                                    {
                                        ddlBuldType0.Items.Clear();
                                        ddlBuldType0.Items.Add(new ListItem("--Select--", ""));

                                        ddlBuldType0.Items.Add(new ListItem("Basement", "50"));
                                        ddlBuldType0.Items.Add(new ListItem("Lintel", "65"));
                                        ddlBuldType0.Items.Add(new ListItem("Roof", "85"));
                                        ddlBuldType0.Items.Add(new ListItem("Plastering (Internal+External) & Flooring", "100"));


                                    }

                                    if (ddlBuldType.SelectedValue == "GF+1")
                                    {
                                        ddlBuldType0.Items.Clear();
                                        ddlBuldType0.Items.Add(new ListItem("--Select--", ""));
                                        ddlBuldType0.Items.Add(new ListItem("Roofing Level - GF", "60"));
                                        ddlBuldType0.Items.Add(new ListItem("Roofing Level - FF", "80"));
                                        ddlBuldType0.Items.Add(new ListItem("Plastering (Internal+External) & Flooring", "100"));


                                    }

                                    if (ddlBuldType.SelectedValue == "GF+2")
                                    {
                                        ddlBuldType0.Items.Clear();
                                        ddlBuldType0.Items.Add(new ListItem("--Select--", ""));
                                        ddlBuldType0.Items.Add(new ListItem("Lintel Level - GF", "60"));
                                        ddlBuldType0.Items.Add(new ListItem("Roofing Level - FF", "80"));
                                        ddlBuldType0.Items.Add(new ListItem("Roofing Level - SF", "90"));
                                        ddlBuldType0.Items.Add(new ListItem("Plastering (Internal+External) & Flooring(GF,FF & SF)", "100"));


                                    }
                                }

                                //if ( Session["TYPEID"].ToString() == "3")
                                //{

                                if (ddlBuldType.SelectedIndex > 0)
                                {
                                    if (ddlBuldType.SelectedValue == "GF")
                                    {
                                        ddlBuldType0.Items.Clear();
                                        ddlBuldType0.Items.Add(new ListItem("--Select--", ""));
                                        ddlBuldType0.Items.Add(new ListItem("Basement", "50"));
                                        ddlBuldType0.Items.Add(new ListItem("Lintel", "65"));
                                        ddlBuldType0.Items.Add(new ListItem("Roof", "85"));
                                        ddlBuldType0.Items.Add(new ListItem("Plastering (Internal+External) & Flooring", "100"));
                                    }

                                    if (ddlBuldType.SelectedValue == "GF+1")
                                    {
                                        ddlBuldType0.Items.Clear();
                                        ddlBuldType0.Items.Add(new ListItem("--Select--", ""));
                                        ddlBuldType0.Items.Add(new ListItem("Roofing Level - GF", "60"));
                                        ddlBuldType0.Items.Add(new ListItem("Roofing Level - FF", "80"));
                                        ddlBuldType0.Items.Add(new ListItem("Plastering (Internal+External) & Flooring", "100"));
                                    }

                                    if (ddlBuldType.SelectedValue == "GF+2")
                                    {
                                        ddlBuldType0.Items.Clear();
                                        ddlBuldType0.Items.Add(new ListItem("--Select--", ""));
                                        ddlBuldType0.Items.Add(new ListItem("Lintel Level - GF", "60"));
                                        ddlBuldType0.Items.Add(new ListItem("Roofing Level - FF", "80"));
                                        ddlBuldType0.Items.Add(new ListItem("Roofing Level - SF", "90"));
                                        ddlBuldType0.Items.Add(new ListItem("Plastering (Internal+External) & Flooring(GF,FF & SF)", "100"));
                                    }
                                }
                                txtSancDate.Text = ds.Tables[0].Rows[0]["DM_CON_DATE"] != DBNull.Value ? Convert.ToDateTime(ds.Tables[0].Rows[0]["DM_CON_DATE"]).ToString("dd MMM yyyy") : "";
                                double dbl = ds.Tables[0].Rows[0]["DM_CON_PER"] != DBNull.Value ? Convert.ToDouble(ds.Tables[0].Rows[0]["DM_CON_PER"]) : 0;
                                ddlBuldType0.SelectedValue = ds.Tables[0].Rows[0]["DM_CON_PER"] != DBNull.Value ? Math.Round(dbl).ToString() : "";
                                txtCOnstCostPer.Text = ds.Tables[0].Rows[0]["DM_CON_PER"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CON_PER"].ToString() : "";
                                txtDeviation.Text = ds.Tables[0].Rows[0]["DM_CON_DEV"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CON_DEV"].ToString() : "";
                                //    txtAmount.Text = ds.Tables[0].Rows[0]["DM_NET_DISB"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_NET_DISB"].ToString() : "";
                                txtTotAMnt.Text = txtAmount.Text;
                                // txtPrptyOwner.Text = ds.Tables[0].Rows[0]["DM_PRPTY_OWNER"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PRPTY_OWNER"].ToString() : "";
                                // txtPrptyAddr.Text = ds.Tables[0].Rows[0]["DM_PRPTY_ADDR"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PRPTY_ADDR"].ToString() : "";
                                //  txtSurvey.Text = ds.Tables[0].Rows[0]["DM_PRPTY_SURVEY"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PRPTY_SURVEY"].ToString() : "";
                                // txtPurpose.Text = ds.Tables[0].Rows[0]["DM_PURPOSE"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PURPOSE"].ToString() : "";
                                //  txtInsurancePer.Text = ds.Tables[0].Rows[0]["DM_INSURANCE_PERSON"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_INSURANCE_PERSON"].ToString() : "";
                                txtRemarks.Text = ds.Tables[0].Rows[0]["DM_REMARKS"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_REMARKS"].ToString() : "";
                                txtDmApproveDate.Text = ds.Tables[0].Rows[0]["DM_APRL_DATE"] != DBNull.Value ? Convert.ToDateTime(ds.Tables[0].Rows[0]["DM_APRL_DATE"]).ToString("dd/MM/yyyy") : DateTime.Now.ToString("dd/MM/yyyy");

                                ddlAppCase.SelectedValue = ds.Tables[0].Rows[0]["DM_APRL"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_APRL"].ToString() : "";
                                if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                                {
                                    int ncount = ds.Tables[1].Rows.Count;
                                    txtFavDetail1.Text = ds.Tables[1].Rows[0]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_FAVOR"].ToString() : "";
                                    ttxBankName1.Text = ds.Tables[1].Rows[0]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_BANK"].ToString() : "";
                                    txtAccno1.Text = ds.Tables[1].Rows[0]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_AC_NO"].ToString() : "";
                                    txtTotal1.Text = ds.Tables[1].Rows[0]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_AMOUNT"].ToString() : "";

                                    if (ncount >= 2)
                                    {
                                        txtFavDetail2.Text = ds.Tables[1].Rows[1]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_FAVOR"].ToString() : "";
                                        ttxBankName2.Text = ds.Tables[1].Rows[1]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_BANK"].ToString() : "";
                                        txtAccno2.Text = ds.Tables[1].Rows[1]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_AC_NO"].ToString() : "";
                                        txtTotal2.Text = ds.Tables[1].Rows[1]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_AMOUNT"].ToString() : "";
                                    }

                                    if (ncount >= 3)
                                    {
                                        txtFavDetail3.Text = ds.Tables[1].Rows[2]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_FAVOR"].ToString() : "";
                                        ttxBankName3.Text = ds.Tables[1].Rows[2]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_BANK"].ToString() : "";
                                        txtAccno3.Text = ds.Tables[1].Rows[2]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_AC_NO"].ToString() : "";
                                        txtTotal3.Text = ds.Tables[1].Rows[2]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_AMOUNT"].ToString() : "";
                                    }
                                }
                                if (ds.Tables[2] != null && ds.Tables[2].Rows.Count > 0)
                                {
                                    int ncount = ds.Tables[2].Rows.Count;
                                    txtCoApp1.Text = ds.Tables[2].Rows[0]["DMA_NAME"] != DBNull.Value ? ds.Tables[2].Rows[0]["DMA_NAME"].ToString() : "";
                                    txtRel1.Text = ds.Tables[2].Rows[0]["DMA_REL"] != DBNull.Value ? ds.Tables[2].Rows[0]["DMA_REL"].ToString() : "";
                                    txtAge1.Text = ds.Tables[2].Rows[0]["DMA_AGE"] != DBNull.Value ? ds.Tables[2].Rows[0]["DMA_AGE"].ToString() : "";


                                    if (ncount >= 2)
                                    {
                                        txtCoApp2.Text = ds.Tables[2].Rows[1]["DMA_NAME"] != DBNull.Value ? ds.Tables[2].Rows[1]["DMA_NAME"].ToString() : "";
                                        txtRel2.Text = ds.Tables[2].Rows[1]["DMA_REL"] != DBNull.Value ? ds.Tables[2].Rows[1]["DMA_REL"].ToString() : "";
                                        txtAge2.Text = ds.Tables[2].Rows[1]["DMA_AGE"] != DBNull.Value ? ds.Tables[2].Rows[1]["DMA_AGE"].ToString() : "";
                                    }

                                    if (ncount >= 3)
                                    {
                                        txtCoApp3.Text = ds.Tables[2].Rows[2]["DMA_NAME"] != DBNull.Value ? ds.Tables[2].Rows[2]["DMA_NAME"].ToString() : "";
                                        txtRel3.Text = ds.Tables[2].Rows[2]["DMA_REL"] != DBNull.Value ? ds.Tables[2].Rows[2]["DMA_REL"].ToString() : "";
                                        txtAge3.Text = ds.Tables[2].Rows[2]["DMA_AGE"] != DBNull.Value ? ds.Tables[2].Rows[2]["DMA_AGE"].ToString() : "";
                                    }
                                    if (ncount >= 4)
                                    {
                                        txtCoApp3.Text = ds.Tables[2].Rows[3]["DMA_NAME"] != DBNull.Value ? ds.Tables[2].Rows[3]["DMA_NAME"].ToString() : "";
                                        txtRel3.Text = ds.Tables[2].Rows[3]["DMA_REL"] != DBNull.Value ? ds.Tables[2].Rows[3]["DMA_REL"].ToString() : "";
                                        txtAge3.Text = ds.Tables[2].Rows[3]["DMA_AGE"] != DBNull.Value ? ds.Tables[2].Rows[3]["DMA_AGE"].ToString() : "";
                                    }
                                    if (ncount >= 5)
                                    {
                                        txtCoApp3.Text = ds.Tables[2].Rows[4]["DMA_NAME"] != DBNull.Value ? ds.Tables[2].Rows[4]["DMA_NAME"].ToString() : "";
                                        txtRel3.Text = ds.Tables[2].Rows[4]["DMA_REL"] != DBNull.Value ? ds.Tables[2].Rows[4]["DMA_REL"].ToString() : "";
                                        txtAge3.Text = ds.Tables[2].Rows[4]["DMA_AGE"] != DBNull.Value ? ds.Tables[2].Rows[4]["DMA_AGE"].ToString() : "";
                                    }
                                }
                                // }
                            }
                            else
                            {
                                txtLandSqft.Text = dtSanc.Rows[0]["DMD_LAREA_SQFT"] != DBNull.Value ? dtSanc.Rows[0]["DMD_LAREA_SQFT"].ToString() : "";
                                txtGudLine.Text = dtSanc.Rows[0]["DMD_GVALUE"] != DBNull.Value ? dtSanc.Rows[0]["DMD_GVALUE"].ToString() : "";
                                txtMrktVal.Text = dtSanc.Rows[0]["DMD_MVALUE"] != DBNull.Value ? dtSanc.Rows[0]["DMD_MVALUE"].ToString() : "";
                                txtLanVal.Text = dtSanc.Rows[0]["DMD_TOT_LVALUE"] != DBNull.Value ? dtSanc.Rows[0]["DMD_TOT_LVALUE"].ToString() : "";

                            }

                        }
                        else
                        {
                            tblDMC.Visible = false;
                            uscMsgBox1.AddMessage("Invalid Sanction NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        }
                    }
                }
                else
                {
                    tblDMC.Visible = false;
                    uscMsgBox1.AddMessage("Invalid Loan NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
                //}
                //else
                //{
                //    uscMsgBox1.AddMessage("Please Enter the Lead NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                //}
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public DataSet fetchDisbursementDetails()
    {

        DataSet dsdd = null;

        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_DISBURSEMENT_DETS_DM", con);
            cmddd.Parameters.AddWithValue("@LNNO", txtLoanNo.Text);

            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);
            // dtCam = dsdd.Tables[nIndex];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dsdd;
    }
    public DataSet fetchCamDetail()
    {
        DataTable dtCam = null;
        DataSet dsdd = null;

        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_PR_Fetch_CAM", con);
            cmddd.Parameters.AddWithValue("@LD_NO", Session["LeadNo"] != null ? Session["LeadNo"].ToString() : "");

            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);
            // dtCam = dsdd.Tables[nIndex];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dsdd;
    }
    public DataSet fetchDMCDetailByBuild(string strBuildType)
    {
        DataTable dtCam = null;
        DataSet dsdd = null;

        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_DMC_SUBSEQ_DETAILS1", con);
            cmddd.Parameters.AddWithValue("@LOAN", txtLoanNo.Text);
            cmddd.Parameters.AddWithValue("@BUILDTYPE", strBuildType);
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);
            // dtCam = dsdd.Tables[nIndex];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dsdd;
    }
    public DataSet fetchDMCDetail()
    {
        DataTable dtCam = null;
        DataSet dsdd = null;

        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_DMC_SUB_DETAILS", con);
            cmddd.Parameters.AddWithValue("@LOANNO", txtLoanNo.Text);

            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);
            // dtCam = dsdd.Tables[nIndex];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dsdd;
    }
    public DataTable fetchSanction(string strSanNO)
    {
        DataTable dtSan = null;

        try
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            //bala changes 15/03/2016
            //SqlCommand mycomm = new SqlCommand("HF_SANC_LTR", con);
            SqlCommand mycomm = new SqlCommand("HF_SANC_LTR_DM_AHF ", con);
           
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@SANCPROCNO", SqlDbType.VarChar).Value = strSanNO;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            showdata.Fill(ds);
            con.Close();
            dtSan = ds.Tables[0];
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dtSan;
    }
    protected void ddlBuldType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlBuldType.SelectedValue == "GF")
        {
            ddlBuldType0.Items.Clear();
            ddlBuldType0.Items.Add(new ListItem("--Select--", ""));
            ddlBuldType0.Items.Add(new ListItem("Basement", "50"));
            ddlBuldType0.Items.Add(new ListItem("Lintel", "65"));
            ddlBuldType0.Items.Add(new ListItem("Roof", "85"));
            ddlBuldType0.Items.Add(new ListItem("Plastering (Internal+External) & Flooring", "100"));
        }

        if (ddlBuldType.SelectedValue == "GF+1")
        {
            ddlBuldType0.Items.Clear();
            ddlBuldType0.Items.Add(new ListItem("--Select--", ""));
            ddlBuldType0.Items.Add(new ListItem("Roofing Level - GF", "60"));
            ddlBuldType0.Items.Add(new ListItem("Roofing Level - FF", "80"));
            ddlBuldType0.Items.Add(new ListItem("Plastering (Internal+External) & Flooring", "100"));
        }

        if (ddlBuldType.SelectedValue == "GF+2")
        {
            ddlBuldType0.Items.Clear();
            ddlBuldType0.Items.Add(new ListItem("--Select--", ""));
            ddlBuldType0.Items.Add(new ListItem("Lintel Level - GF", "60"));
            ddlBuldType0.Items.Add(new ListItem("Roofing Level - FF", "80"));
            ddlBuldType0.Items.Add(new ListItem("Roofing Level - SF", "90"));
            ddlBuldType0.Items.Add(new ListItem("Plastering (Internal+External) & Flooring(GF,FF & SF)", "100"));
        }

    }



    protected void ddlBuldType0_SelectedIndexChanged(object sender, EventArgs e)
    {
       /* txtCOnstCostPer.Text = ddlBuldType0.SelectedValue;
        CalculateTotal();
        */
    }
    protected void txtCOnstCostPer_TextChanged(object sender, EventArgs e)
    {
        CalculateTotal();
    }
    protected void txtDeviation_TextChanged(object sender, EventArgs e)
    {
        CalculateTotal();
    }
    public void CalculateTotal()
    {

        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select  SUM(DM_NET_AMT)  from LSD_SUB_DISB_MEMO where DM_LOAN_NO='" + txtLoanNo.Text.ToString() + "'", con);

        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        if (txtCOnstCostPer.Text != "")
        {
            double dblAmount = dsrsn.Tables[0].Rows[0][0].ToString() != "" ? Convert.ToDouble(dsrsn.Tables[0].Rows[0][0].ToString()) : 0;
            if (txtDeviation.Text != "")
            {

                //double dblTotal = (((Convert.ToDouble(txtDeviation.Text) + Convert.ToDouble(txtCOnstCostPer.Text)) / 100) * Convert.ToDouble(txtConstrCost1.Text)) - (Convert.ToDouble(txtMarginAmount.Text) + Convert.ToDouble(txtCharge.Text) + dblAmount);
                double dblTotal = (((Convert.ToDouble(txtDeviation.Text) + Convert.ToDouble(txtCOnstCostPer.Text)) / 100) * Convert.ToDouble(txtConstrCost1.Text)) - (Convert.ToDouble(txtMarginAmount.Text) + Convert.ToDouble(txtPreTotal.Text));
                txtAmount.Text = dblTotal.ToString();
            }
            else
            {
                double dblTotal = (((Convert.ToDouble(txtCOnstCostPer.Text)) / 100) * Convert.ToDouble(txtConstrCost1.Text)) - (Convert.ToDouble(txtMarginAmount.Text) + Convert.ToDouble(txtPreTotal.Text));
                txtAmount.Text = dblTotal.ToString();
            }

            txtTotal1.Text = txtAmount.Text;

            txtTotAMnt.Text = txtAmount.Text;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (txtAmount.Text == "")
        {
            uscMsgBox1.AddMessage("Please Calculate Net Disbursement Amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ddlBuldType.Focus();
        }
        else if (ddlArea.SelectedItem.Text == "--Select--" || ddlBranch.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please Select Area/Branch names", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        else if (txtFavDetail1.Text == "" || ttxBankName1.Text == "" || txtAccno1.Text == "")
        {
            uscMsgBox1.AddMessage("Please give corresponding input for cheque details", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        else if (Convert.ToDouble(txtTotAMnt.Text) != Convert.ToDouble(txtAmount.Text))
        {
            uscMsgBox1.AddMessage("Net disburse amount mis match with cheque amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        //else if (ddlAppCase.SelectedItem.Text == "--Select--" && Session["TYPEID"].ToString() == "3")
        //{
        //    uscMsgBox1.AddMessage("Please Select Approve Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        //    ddlAppCase.Focus();
        //}
        else if (rdnUrban.Checked == false && rdnRural.Checked == false)
        {
            rdnUrban.Focus();
            uscMsgBox1.AddMessage("Please select the area type", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }

        else
        {

            InsertDMCvalues();

        }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("AHFSubSequentDisburasal.aspx");
    }
    public void InsertDMCvalues()
    {
        try
        {
            string strAreaType = "";
            if (rdnUrban.Checked == true)
            {
                strAreaType = "URBAN";
            }
            else if (rdnRural.Checked == true)
            {
                strAreaType = "RURAL";
            }


            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_Insert_SUB_DCM", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@DM_DATE", Convert.ToDateTime(txtDate.Text));
            cmdinsert.Parameters.AddWithValue("@DM_SANTD_NO", txtProposalNo.Text);
            cmdinsert.Parameters.AddWithValue("@DM_LOAN_NO", txtLoanNUmber.Text);
            cmdinsert.Parameters.AddWithValue("@DM_LOAN_AMT", Convert.ToDouble(txtLoanAMount.Text));
            cmdinsert.Parameters.AddWithValue("@DM_AREA", ddlArea.SelectedItem.Text);
            cmdinsert.Parameters.AddWithValue("@DM_BRANCH ", ddlBranch.SelectedItem.Text);
            cmdinsert.Parameters.AddWithValue("@DM_MID", txtMemberID.Text);
            cmdinsert.Parameters.AddWithValue("@DM_AREA_TYPE", strAreaType);
            cmdinsert.Parameters.AddWithValue("@DM_LAREA", txtLandSqft.Text != "" ? Convert.ToDouble(txtLandSqft.Text) : 0);
            cmdinsert.Parameters.AddWithValue("@DM_GV", txtGudLine.Text != "" ? Convert.ToDouble(txtGudLine.Text) : 0);
            cmdinsert.Parameters.AddWithValue("@DM_MV", txtMrktVal.Text != "" ? Convert.ToDouble(txtMrktVal.Text) : 0);
            cmdinsert.Parameters.AddWithValue("@DM_LV", Convert.ToDouble(txtLanVal.Text));
            cmdinsert.Parameters.AddWithValue("@DM_CON_TYPE", ddlConstrTye.SelectedItem.Text);
            cmdinsert.Parameters.AddWithValue("@DM_CON_AREA", Convert.ToDouble(txtconstArea.Text));
            cmdinsert.Parameters.AddWithValue("@DM_VALUE", txtVal.Text != "" ? Convert.ToDouble(txtVal.Text) : 0);
            cmdinsert.Parameters.AddWithValue("@DM_CON_COST", Convert.ToDouble(txtConstrCost1.Text));
            cmdinsert.Parameters.AddWithValue("@DM_LCR_PER", Convert.ToDouble(txtLCRPer.Text));
            cmdinsert.Parameters.AddWithValue("@DM_LCR_AMT ", Convert.ToDouble(txtLCRValue.Text));
            cmdinsert.Parameters.AddWithValue("@DM_PV ", Convert.ToDouble(txtTotPropVal.Text));
            cmdinsert.Parameters.AddWithValue("@DM_BLD_TYPE", ddlBuldType.SelectedItem.Text);
            cmdinsert.Parameters.AddWithValue("@DM_MARGIN", Convert.ToDouble(txtMarginAmount.Text));
            cmdinsert.Parameters.AddWithValue("@DM_CHARGES", Convert.ToDouble(txtCharge.Text));
            cmdinsert.Parameters.AddWithValue("@DM_CON_DATE", Convert.ToDateTime(txtSancDate.Text));
            cmdinsert.Parameters.AddWithValue("@DM_CON_STAGE", ddlBuldType0.SelectedItem.Text);
            cmdinsert.Parameters.AddWithValue("@DM_CON_PER", Convert.ToDouble(txtCOnstCostPer.Text));
            cmdinsert.Parameters.AddWithValue("@DM_CON_DEV", txtDeviation.Text != "" ? Convert.ToDouble(txtDeviation.Text) : 0);
            cmdinsert.Parameters.AddWithValue("@DM_TENOR", Convert.ToDouble(txtTenor.Text));
            cmdinsert.Parameters.AddWithValue("@DM_ROI", Convert.ToDouble(txtROI.Text));
            cmdinsert.Parameters.AddWithValue("@DM_EMI", Convert.ToDouble(txtEMI.Text));
            cmdinsert.Parameters.AddWithValue("@DM_LTV", Convert.ToDouble(txtMFHFLTV.Text));
            cmdinsert.Parameters.AddWithValue("@DM_LCR", Convert.ToDouble(txtMFHFLCR.Text));
            cmdinsert.Parameters.AddWithValue("@DM_CSP", Convert.ToDouble(txtKLI.Text));
            cmdinsert.Parameters.AddWithValue("@DM_PIP", Convert.ToDouble(txNIA.Text));
            cmdinsert.Parameters.AddWithValue("@DM_NET_AMT", Convert.ToDouble(txtAmount.Text));


            cmdinsert.Parameters.AddWithValue("@DM_Type", "C");
            cmdinsert.Parameters.AddWithValue("@DM_APRL", ddlAppCase.SelectedItem.Text);
            cmdinsert.Parameters.AddWithValue("@DM_APRL_BY", Convert.ToInt32(Session["ID"].ToString()));
            cmdinsert.Parameters.AddWithValue("@DM_APRL_DATE", DateTime.Now);
            cmdinsert.Parameters.AddWithValue("@DM_REMARKS", txtRemarks.Text);

            //if (Session["TYPEID"].ToString() == "3")
            //{
            //    cmdinsert.Parameters.AddWithValue("@DM_Type", "C");
            //    cmdinsert.Parameters.AddWithValue("@DM_APRL", ddlAppCase.SelectedItem.Text);
            //    cmdinsert.Parameters.AddWithValue("@DM_APRL_BY",Convert.ToInt32( Session["ID"].ToString()));
            //    cmdinsert.Parameters.AddWithValue("@DM_APRL_DATE", DateTime.Now);
            //    cmdinsert.Parameters.AddWithValue("@DM_REMARKS", txtRemarks.Text);
            //}
            //else
            //{
            //    cmdinsert.Parameters.AddWithValue("@DM_Type", "B");
            //    cmdinsert.Parameters.AddWithValue("@DM_APRL", DBNull.Value);
            //    cmdinsert.Parameters.AddWithValue("@DM_APRL_BY", DBNull.Value);
            //    cmdinsert.Parameters.AddWithValue("@DM_APRL_DATE", DBNull.Value);
            //    cmdinsert.Parameters.AddWithValue("@DM_REMARKS", DBNull.Value);
            //}

            //if (Session["TYPEID"].ToString() == "3" || ddlAppCase.SelectedValue == "HOLD")
            //{
            //    cmdinsert.Parameters.AddWithValue("@QTYPE", "UPDATE");
            //}
            //else
            //{
            cmdinsert.Parameters.AddWithValue("@QTYPE", "INSERT");
            // }

            //double tAmount = 0;
            //if (txtLoanAMount.Text != "" && txtCharge.Text != "")
            //{
            //    tAmount = Convert.ToDouble(txtLoanAMount.Text) - Convert.ToDouble(txtCharge.Text);
            //}

            cmdinsert.Parameters.AddWithValue("@ID", Convert.ToInt32(Session["ID"].ToString()));



            int n = cmdinsert.ExecuteNonQuery();
            con.Close();
            if (n > 0)
            {
                InsertCheque();
                InsertEligiblityWrking();

                uscMsgBox1.AddMessage("Disbursal Memo Sub sequent Value Saved Sucessfully ", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                tblDMC.Visible = false;

                clearDatas();

            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Disbursal Memo Sub sequent Value Failed to save ", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
    }
    public void InsertEligiblityWrking()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        int nValue = 0;
        SqlCommand cmd = new SqlCommand("Select count(*) as count from  LSD_SUB_DISB_MEMO_APL where DMA_DM_ID IN (select top 1 DM_ID FROM  LSD_SUB_DISB_MEMO WHERE DM_LOAN_NO='" + txtLoanNo.Text.ToString() + "' order by DM_ID DESC)", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0] != null)
        {
            nValue = ds.Tables[0].Rows[0][0] != DBNull.Value ? Convert.ToInt32(ds.Tables[0].Rows[0][0]) : 0;
        }
        if (txtCoApp1.Text != "")
        {
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMSUBWRKELIGIBLITY", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_NAME", txtCoApp1.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_REL", txtRel1.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_AGE", txtAge1.Text);

            if (nValue >= 1)
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
            }
            int n = cmdinsert.ExecuteNonQuery();

        }
        if (txtCoApp2.Text != "")
        {
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMSUBWRKELIGIBLITY", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_NAME", txtCoApp2.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_REL", txtRel2.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_AGE", txtAge2.Text);
            if (nValue >= 2)
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
            }

            int n = cmdinsert.ExecuteNonQuery();

        }



        if (txtCoApp3.Text != "")
        {
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMSUBWRKELIGIBLITY", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_NAME", txtCoApp3.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_REL", txtRel3.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_AGE", txtAge3.Text);
            if (nValue >= 3)
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
            }

            int n = cmdinsert.ExecuteNonQuery();

        }
        if (txtCoApp4.Text != "")
        {
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMSUBWRKELIGIBLITY", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_NAME", txtCoApp4.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_REL", txtRel4.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_AGE", txtAge4.Text);
            if (nValue >= 3)
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
            }

            int n = cmdinsert.ExecuteNonQuery();

        }
        if (txtCoApp5.Text != "")
        {
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMSUBWRKELIGIBLITY", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_NAME", txtCoApp5.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_REL", txtRel5.Text);
            cmdinsert.Parameters.AddWithValue("@DMA_AGE", txtAge5.Text);
            if (nValue >= 3)
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
            }

            int n = cmdinsert.ExecuteNonQuery();

        }
        if (Session["TYPEID"].ToString() == "3")
        {
            sendMail(con);
        }
        con.Close();
    }
    public void InsertCheque()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        int nValue = 0;
        SqlCommand cmd = new SqlCommand("Select count(*) as count from  LSD_SUB_DISB_MEMO_CHQ where DMC_DM_ID IN (select top 1 DM_ID FROM  LSD_SUB_DISB_MEMO WHERE DM_LOAN_NO='" + txtLoanNo.Text.ToString() + "' order by DM_ID DESC)", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0] != null)
        {
            nValue = ds.Tables[0].Rows[0][0] != DBNull.Value ? Convert.ToInt32(ds.Tables[0].Rows[0][0]) : 0;
        }
        if (txtFavDetail1.Text != "")
        {
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMSUBCheque", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_CHEQUE", "CHEQUE1");
            cmdinsert.Parameters.AddWithValue("@DMC_BANK", ttxBankName1.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_FAVOR", txtFavDetail1.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_AC_NO", txtAccno1.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_AMOUNT", txtTotal1.Text);
            if (nValue >= 1)
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
            }
            int n = cmdinsert.ExecuteNonQuery();

        }
        if (txtFavDetail2.Text != "")
        {
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMSUBCheque", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_CHEQUE", "CHEQUE2");
            cmdinsert.Parameters.AddWithValue("@DMC_BANK", ttxBankName2.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_FAVOR", txtFavDetail2.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_AC_NO", txtAccno2.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_AMOUNT", txtTotal2.Text);
            if (nValue >= 2)
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
            }

            int n = cmdinsert.ExecuteNonQuery();

        }



        if (txtFavDetail3.Text != "")
        {
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMSUBCheque", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@LOAN_NO", txtLoanNo.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_CHEQUE", "CHEQUE3");
            cmdinsert.Parameters.AddWithValue("@DMC_BANK", ttxBankName3.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_FAVOR", txtFavDetail3.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_AC_NO", txtAccno3.Text);
            cmdinsert.Parameters.AddWithValue("@DMC_AMOUNT", txtTotal3.Text);
            if (nValue >= 3)
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
            }

            int n = cmdinsert.ExecuteNonQuery();

        }

        //if (Session["TYPEID"].ToString() == "3")
        //{
        //    sendMail(con);
        //}
        con.Close();
    }
    protected void ddlAppCase_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = true;
    }
    public void sendMail(SqlConnection con)
    {
        try
        {
            /////// mail ///////////
            //  strMailDetail = "";

            SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "'", con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);

            SqlCommand cmdmail = new SqlCommand("select CASE WHEN ISNULL(QRY_SQUERY,'')='' THEN QRY_QUERY ELSE QRY_SQUERY END 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "' AND QRY_RSD_BY='C'", con);
            SqlDataAdapter damail = new SqlDataAdapter(cmdmail);
            DataSet dsmail = new DataSet();
            damail.Fill(dsmail);

            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["LD_BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["LD_BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT EM_BM,EM_AM,EM_CM,EM_BCC FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
                cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
            }

            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            //to = "ManimaranK@equitasbank.com";
            //bcc2 = "ManimaranK@equitasbank.com";
            //cc = "rts-helpdesk@equitasbank.com";
            fromID = "RTS Alerts";
            toID = to;
            bcc2ID = bcc2;
            ccID = cc;
            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{

            String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Disbursal Memo - " + ddlAppCase.SelectedItem.ToString() + "<br/><br/>";
            BodyTxt = BodyTxt + "<table width='40%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td></tr>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Applicant Name</td><td><strong>" + Session["Appname"].ToString() + "</strong></td></tr>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Building Type</td><td><strong>" + ddlBuldType.SelectedItem.ToString() + "</strong></td></tr>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Building Stage</td><td><strong>" + ddlBuldType0.SelectedItem.ToString() + "</strong></td></tr>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Status</td><td><strong>" + ddlAppCase.SelectedItem.ToString() + "(RS. " + txtAmount.Text + ")</strong></td></tr>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Remarks</td><td><strong>" + txtRemarks.Text + "</strong></td></tr></table><br/><br/>";
            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Address </td><td align='center'>:</td><td><strong>" + cusaddr + "</strong></td></tr>";
            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Mobile No.</td><td align='center'>:</td><td><strong>" + mobile + "</strong></td></tr></table><br/><br/>";


            BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>Credit Team</td></tr>";
            BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
            //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

            blMailStatus = EmailManager.sendemail(to, "RTS Alerts", bcc2, cc, "Lead No. : " + Session["Leadno"].ToString() + " - Applicant Name : " + Session["Appname"].ToString() + " - Area : " + Session["ANAME"].ToString() + "- Branch : " + Session["BNAME"].ToString() + " - Disbursal Memo " + ddlAppCase.SelectedItem.ToString() + "", BodyTxt, "", true);
            //sendemail("SurendharR@equitasbank.com;PrabhakaranA@equitasbank.com;Tamilalagand@equitasbank.com", "surendharr@equitasbank.com", "Test", BodyTxt, "", true);

            strMailBody = BodyTxt.Replace("<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Disbursal " + ddlAppCase.SelectedItem.ToString() + "<br/><br/>", "");
            strMailBody = BodyTxt.Replace("</html>", " ");


            //});
            //// strMailDetail = to + "," + bcc2 + "," + cc;
            //threadSendMails.IsBackground = true;

            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(5000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    public void clearDatas()
    {
        txtLeadNo1.Text = "";
        txtProposalNo.Text = "";
        txtLoanNUmber.Text = "";
        //txtAreaName.Text = "";
        //txtBranchName.Text = "";

        txtDate.Text = "";
        txtCustCatgry.Text = "";
        txtMemberID.Text = "";
        rdnRural.Checked = false;
        rdnUrban.Checked = false;


        txtLandSqft.Text = "";
        txtGudLine.Text = "";
        txtMrktVal.Text = "";
        txtLanVal.Text = "";


        //txtConstrType.Text = "";
        txtconstArea.Text = "";
        txtVal.Text = "";
        txtConstrCost.Text = "";
        txtLCRPer.Text = "";
        txtLCRValue.Text = "";
        txtTotPropVal.Text = "";


        txtConstrCost1.Text = "";
        txtLoanAMount.Text = "";
        txtMarginAmount.Text = "";
        txtCharge.Text = "";
        txtSancDate.Text = "";
        txtCOnstCostPer.Text = "";
        txtDeviation.Text = "";
        txtAmount.Text = "";
        //txtlgnfee.Text = "";


        txtTenor.Text = "";
        txtLoanAMount1.Text = "";
        txtROI.Text = "";
        txtEMI.Text = "";

        txtMFHFLTV.Text = "";
        txtMFHFLCR.Text = "";
        txtKLI.Text = "";
        txNIA.Text = "";

        txtFavDetail1.Text = "";
        ttxBankName1.Text = "";
        txtAccno1.Text = "";
        txtTotal1.Text = "";

        txtFavDetail2.Text = "";
        ttxBankName2.Text = "";
        txtAccno2.Text = "";
        txtTotal2.Text = "";

        txtFavDetail3.Text = "";
        ttxBankName3.Text = "";
        txtAccno3.Text = "";
        txtTotal3.Text = "";

        txtCrdAprvDate.Text = "";
        txtSanDate.Text = "";
        txtExtendArea.Text = "";
        txtLegalStatus.Text = "";
        txtDmApproveDate.Text = "";
        txtRemarks.Text = "";

        ddlBuldType.SelectedIndex = 0;
        ddlBuldType0.SelectedIndex = 0;
        ddlAppCase.SelectedIndex = 0;
        ddlArea.SelectedIndex = 0;
        ddlBranch.SelectedIndex = 0;
    }

    protected void ddlConstrTye_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtVal.Text = ddlConstrTye.SelectedValue.ToString();
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME,BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_NAME";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //    txtLeadno.Enabled = false;
    }
    protected void txtPreTotal_TextChanged(object sender, EventArgs e)
    {
        CalculateTotal();
    }
    
}