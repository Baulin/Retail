﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Branch_LeadClose : System.Web.UI.Page
{
    int rsnid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UNITNAME"] != null)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                txtBranch.Text = Session["UNITNAME"].ToString();
                bindArea();
                bind();
            }
            else
            {
                Response.Redirect("expire.aspx");
            }
        }
    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        ddlProduct.SelectedIndex = 0;

    }

    protected void ddlbranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlProduct.SelectedIndex = 0;
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_Fetch_MR_REASON", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();
        ddlProduct.DataSource = dsdd;
        ddlProduct.DataTextField = "PR_CODE";
        ddlProduct.DataValueField = "PRD";
        ddlProduct.DataBind();
        ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlReason.DataSource = dsrsn;
        ddlReason.DataTextField = "RSN_REASON";
        ddlReason.DataValueField = "RSN_ID";
        ddlReason.DataBind();
        ddlReason.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        if (ddlProduct.SelectedItem.Text == "--Select--" && txtLeadno.Text == "")
        {
            uscMsgBox1.AddMessage("Please select Product and Enter Lead No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            gridbind();
        }
    }
    public void gridbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmd = new SqlCommand("select LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD where LD_PR_ID='" + ddlProduct.SelectedIndex + "' AND isnull(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' and LD_BR_ID='" + Session["BRANCHID"] + "' OR LD_NO='" + txtLeadno.Text + "' AND isnull(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' and LD_BR_ID='" + Session["BRANCHID"] + "'", con);
            SqlCommand cmd = new SqlCommand("RTS_SP_Fetch_LeadColoseDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            string[] PRARR = ddlProduct.SelectedIndex > 0 ? ddlProduct.SelectedValue.ToString().Split('-') : null;
            cmd.Parameters.AddWithValue("@LD_PR_ID", PRARR[0].ToString());
            
            //cmd.Parameters.AddWithValue("@LD_PR_ID", ddlProduct.SelectedValue);
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            //Bala changes 24/02/2016
            //cmd.Parameters.AddWithValue("@LD_BR_ID", Session["BRANCHID"].ToString());
            cmd.Parameters.AddWithValue("@LD_BR_ID", ddlBranch.SelectedValue);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count != 0)
            {
                //Panel1.Visible = true;
                gvLeadclose.DataSource = ds.Tables[0];
                gvLeadclose.DataBind();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    gvLeadclose.HeaderRow.Font.Bold = true;
                    gvLeadclose.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvLeadclose.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvLeadclose.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    gvLeadclose.HeaderRow.Cells[4].Text = "PD DATE";
                    gvLeadclose.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                    gvLeadclose.HeaderRow.Cells[1].Wrap = false;
                    gvLeadclose.HeaderRow.Cells[2].Wrap = false;
                    gvLeadclose.HeaderRow.Cells[3].Wrap = false;
                    gvLeadclose.HeaderRow.Cells[4].Wrap = false;
                    gvLeadclose.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Invalid Lead No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        //Assumes the Price column is at index 4
        if (e.Row.RowType == DataControlRowType.DataRow)
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            foreach (GridViewRow grow in gvLeadclose.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    leadno = gvLeadclose.Rows[index].Cells[1].Text;
                    appname = gvLeadclose.Rows[index].Cells[3].Text;
                    pddt = gvLeadclose.Rows[index].Cells[4].Text;
                    lnamt = gvLeadclose.Rows[index].Cells[5].Text;
                    Label lblLD_ID = grow.FindControl("lblLD_ID") as Label;
                    int ld_stat = clscommon.Is_Lead_Close_Status(lblLD_ID.Text);

                    if (ld_stat > 0 && Session["TYPEID"].ToString() != "1" & Session["TYPEID"].ToString() != "42")
                    {
                        uscMsgBox1.AddMessage("You are selected lead no - " + leadno + " ready for disbursement already done. So You can't able to close the lead.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        chkStat.Checked = false;
                        btnSubmit.Enabled = false;
                        return;
                    }
                }
            }
            lbLeadno.Visible = true;
            lbAppname.Visible = true;
            lbPDdate.Visible = true;
            lbLoanamt.Visible = true;
            ddlReason.Enabled = true;
            txtRemarks.Enabled = true;
            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;


            lbLeadno.Text = leadno;
            lbAppname.Text = appname;
            lbPDdate.Text = pddt;
            lbLoanamt.Text = lnamt;
            con.Close();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (ddlReason.SelectedItem.Text == "--Select--" || txtRemarks.Text == "")
        {
            uscMsgBox1.AddMessage("Please Select Reason And Enter Remarks", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            SqlConnection con = new SqlConnection(strcon);
            try
            {
                con.Open();
              
                rsnid = Convert.ToInt32(ddlReason.SelectedValue.ToString());

                SqlCommand cmdupdate = new SqlCommand("RTS_SP_Update_LeadCloseDetails", con);
                cmdupdate.CommandType = CommandType.StoredProcedure;
                cmdupdate.Parameters.AddWithValue("@LD_LC_RSN_ID", rsnid);
                cmdupdate.Parameters.AddWithValue("@LD_LC_RMKS", txtRemarks.Text);
                cmdupdate.Parameters.AddWithValue("@LD_LC_MBY", Session["ID"].ToString());
                cmdupdate.Parameters.AddWithValue("@LD_NO",lbLeadno.Text);
                cmdupdate.ExecuteNonQuery();
                txtLeadno.Text = "";
                gridbind();
                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
                uscMsgBox1.AddMessage("Lead Closed Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            finally
            {
                ddlReason.SelectedIndex = 0;
                txtRemarks.Text = "";
                con.Close();
            }
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_LeadClose.aspx");
    }
}