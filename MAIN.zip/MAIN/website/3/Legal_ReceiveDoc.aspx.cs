﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;
public partial class Legal_ReceiveDoc : System.Web.UI.Page
{
    public static DataTable dtLawyerName = null;
    int ldid, s;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
            }
            else
            {
                Response.Redirect("expire.aspx");
            }
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));


    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        bool _passValidation = false;
        try
        {
            if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--" && txtLeadno.Text == "")
            {
                //gvLegalRecvDoc.Visible = true;
                //Session["View"] = "All";
                //    gridbindall();
                //BindegalReceiveDoc();
                _passValidation = false;
                uscMsgBox1.AddMessage("Please Select Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--" && txtLeadno.Text == "")
            {
                _passValidation = true;
                Session["View"] = "F";
            }
            else if (ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--" && txtLeadno.Text == "")
            {
                _passValidation = true;
                Session["View"] = "F";
            }
            else if (ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--" && txtLeadno.Text != "")
            {
                _passValidation = true;
                Session["View"] = "F";
            }
            else if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--" && txtLeadno.Text != "")
            {
                _passValidation = true;
                Session["View"] = "F";
            }

            if (_passValidation)
            {
                gvLegalRecvDoc.Visible = true;
                BindegalReceiveDoc();
            }

            //else if (txtLeadno.Text == "" )
            //{
            //    gvLegalRecvDoc.Visible = false;
            //    uscMsgBox1.AddMessage("Please Enter Lead No. and Select Process", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            //else
            //{
            //    gvLegalRecvDoc.Visible = true;
            //    Session["View"] = "F";
            //    gridbind();
            //    BindegalReceiveDoc();
            //}
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }

    public void BindegalReceiveDoc()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_ReceiveDoc", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PR_ID", "0");
            cmd.Parameters.AddWithValue("@LD_BR_ID", ddlBranch.SelectedIndex > 0 ?ddlBranch.SelectedValue.ToString():"");
            cmd.Parameters.AddWithValue("@LD_AR_ID", ddlArea.SelectedIndex > 0 ? ddlArea.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@ReceiveType", "BR");
            cmd.Parameters.AddWithValue("@LeadNo", !string.IsNullOrEmpty(txtLeadno.Text) ? txtLeadno.Text : string.Empty);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //Panel1.Visible = true;
            gvLegalRecvDoc.DataSource = ds.Tables[0];
            gvLegalRecvDoc.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvLegalRecvDoc.HeaderRow.Font.Bold = true;
                gvLegalRecvDoc.HeaderRow.Cells[1].Text = "LEAD NO";
                gvLegalRecvDoc.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvLegalRecvDoc.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvLegalRecvDoc.HeaderRow.Cells[4].Text = "PD DATE";
                gvLegalRecvDoc.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvLegalRecvDoc.HeaderRow.Cells[6].Text = "BRANCH NAME";
                //gvResolve.HeaderRow.Cells[6].Text = "QUERY";

                gvLegalRecvDoc.HeaderRow.Cells[1].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[2].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[3].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[4].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[5].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[6].Wrap = false;
                //gvResolve.HeaderRow.Cells[6].Wrap = false;
            }

            //Hide MOTD Grid if Master Grid is reloaded
            if (Panel2 != null && Panel2.Visible)
            {
                gvMODTDDoc.DataSource = null;
                Panel2.Visible = false;
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Right;
        }
    }

    public void InsertLegalRecDocumntUpdate()
    {
        SqlConnection con = new SqlConnection(strcon);
        int ncount = 0;
        try
        {
            foreach (GridViewRow grow in gvMODTDDoc.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    ncount = ncount + 1;
                }
                else
                {
                    ncount = 0;
                }
            }
            if (ncount == 0)
            {
                uscMsgBox1.AddMessage("Document/s are missing, Can't be proceed", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
                if (txtMOTDDocNo.Text =="")
            {
                uscMsgBox1.AddMessage("Please enter the MOTD Document No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
                    if (txtMOTDRcptNo.Text == "")
            {
                uscMsgBox1.AddMessage("Please enter the MOTD Receipt No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("RTS_SP_Update_MODT_DOc_Values", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MD_LD_ID", Session["LeadId"].ToString());
                cmd.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                cmd.Parameters.AddWithValue("@TranStatus", "LR");
                cmd.Parameters.AddWithValue("@MD_DOC_NO", txtMOTDDocNo.Text);
                cmd.Parameters.AddWithValue("@MD_RCPT_NO", txtMOTDRcptNo.Text);

                int n = cmd.ExecuteNonQuery();
                if (n > 0)
                {

                    uscMsgBox1.AddMessage("Documents Received Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    BindegalReceiveDoc();
                    Panel2.Visible = false;
                    txtMOTDRcptNo.Text = "";
                    txtMOTDDocNo.Text = "";
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertLegalRecDocumntUpdate();

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Legal_ReceiveDoc.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
        txtLeadno.Enabled = false;
    }

    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            //if (ddlQuery.SelectedValue.ToString() == "QC")
            //{    
            int ncount = 0;
            foreach (GridViewRow grow in gvLegalRecvDoc.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                //DropDownList ddrsp = grow.FindControl("Editdd") as DropDownList;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    leadno = lnbtn.Text;
                    appname = gvLegalRecvDoc.Rows[index].Cells[3].Text;
                    pddt = gvLegalRecvDoc.Rows[index].Cells[4].Text;
                    lnamt = gvLegalRecvDoc.Rows[index].Cells[5].Text;
                    //lQuery = gvResolve.Rows[index].Cells[7].Text;
                    ncount = ncount + 1;
                    //rcvquery = gvResolve.Rows[index].Cells[6].Text;
                    Session["Leadno"] = leadno;
                    getLeadID(con);
                    BindDocGid(con);
                }

                if (ncount == 0)
                {
                    Panel2.Visible = false;
                }
            }


            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;

            con.Close();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void BindDocGid(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("Select MDX_DOC,MDX_DTYPE from LSD_MOTD_DOCX LMD LEFT JOIN  LSD_MOTD  LM ON LMD.MDX_MD_ID =LM.MD_ID  where MD_LD_ID =" + Session["LeadId"].ToString() + "", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0 && ds.Tables[0] != null)
        {
            Panel2.Visible = true;
            gvMODTDDoc.Visible = true;
            gvMODTDDoc.DataSource = ds;
            gvMODTDDoc.DataBind();
        }
        else
        {
            Panel2.Visible = false;
        }


    }
    public void getLeadID(SqlConnection con)
    {
        SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
        cmdbr.CommandType = CommandType.StoredProcedure;
        cmdbr.Parameters.AddWithValue("@LeadNo", Session["Leadno"].ToString());
        SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        DataSet dsbr = new DataSet();
        dabr.Fill(dsbr);
        Session["LeadId"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
    }
}