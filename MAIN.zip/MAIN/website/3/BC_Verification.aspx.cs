﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using System.Net.Mail;
using Tracker;
using Utilities;

public partial class BC_Verification : System.Web.UI.Page
{
    string to="";
    string cc="";
    string bcc="";
    string bcc1="";
    string bcc2="";
    string bcc3="";
    public static DataTable dtSourceOfIncome = null;
    public static string strLanguagesIDS = "", BCA_CODE = "";
    ClsCommon clscommon = new ClsCommon();
    DataSet ds_obj = new DataSet();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            if (Session["ID"] != null)
            {
                bind();
               // bindBCAList();
                //if (Session["EMP_ET_ID"].ToString() == "14" || Session["EMP_ET_ID"].ToString() == "17" || Session["EMP_ET_ID"].ToString() == "8")
                //{
                  
                //}
                if (Session["EMP_ET_ID"].ToString() == "13")
                {
                    btnSubmit.Text = "Draft";
                }
                else
                {
                    btnSubmit.Text = "Submit";
                }
            }
            else
            {
                Response.Redirect("expire.aspx", false);
            }


        }
       
    }
    //Test Git Merge
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            DataSet ds_obj = new DataSet();
            //Check if the resolve query is pending for resolve
            ds_obj = clscommon.GetUnResolvedQueries_Count(Convert.ToInt32(ddlBCACODE.SelectedValue), "R");

            if (ds_obj.Tables[0].Rows.Count > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Query pending, you are not able to submit the application.');", true);

            }
            else
            {
                UpdateBCApplicationForm();
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void UpdateBCApplicationForm()
    {
        DateTime dtd;
        SqlConnection con = new SqlConnection(strcon);

        try
        {
            if (rbFullName.SelectedIndex==-1)
            {
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);
       
            }
            else
                if (rbFatherHusbandName.SelectedIndex == -1)
                {
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                }
                     else
                    if (rbResidencePhNo.SelectedIndex == -1)
                        {
                            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                        }
                    else
                        if (rbOfficePhNo.SelectedIndex == -1)
                        {
                            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                        }
                        else
                            if (rbMobileNo.SelectedIndex == -1)
                            {
                                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                            }
                else
                    if (rblRCNo.SelectedIndex == -1)
                    {
                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                    }
                        
                    else
                        if (rblACNo.SelectedIndex == -1)
                        {
                            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                        }
                        else
                            if (rblVINo.SelectedIndex == -1)
                            {
                                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                            }
                            else
                                if (rblPPNo.SelectedIndex == -1)
                                {
                                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                }
                                else
                                    if (rblPCNo.SelectedIndex == -1)
                                    {
                                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                    }
                                    else
                                        if (rblDOB.SelectedIndex == -1)
                                        {
                                            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                        }
                                        else
                                            if (rblEducation.SelectedIndex == -1)
                                            {
                                                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                            }
                                            else
                                                if (rblOccupation.SelectedIndex == -1)
                                                {
                                                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                                }
                                                else
                                                    if (rblIncomePerMonth.SelectedIndex == -1)
                                                    {
                                                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                                    }
                                                    else
                                                        if (rblLanguagesKnown.SelectedIndex == -1)
                                                        {
                                                            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                                        }
                                                        else
                                                            if (rblStayingStablility.SelectedIndex == -1)
                                                            {
                                                                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                                            }
                                                            //else
                                                            //    if (rblPoliceRecordStat.SelectedIndex == -1)
                                                            //    {
                                                            //        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                                            //    }
                                                                else
                                                                    if (rblRefStatus.SelectedIndex == -1)
                                                                    {
                                                                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                                                    }
                                                                    else
                                                                        if (rblPropertyStatus.SelectedIndex == -1)
                                                                        {
                                                                            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                                                        }
                                                                        else
                                                                            if (rbApplicationStatus.SelectedIndex == -1)
                                                                            {
                                                                                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Yes/No');", true);

                                                                            }
                                                                            else
                                                                                if ((rbApplicationStatus.SelectedValue == "Rejected")&&(ddlRiskStatus.SelectedValue=="0"))
                                                                                {
                                                                                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select risk reason');", true);

                                                                                }
            else{
            BCA_CODE = ddlBCACODE.SelectedItem.Text;
            /*strLanguagesIDS = "";

            for (int n = 0; n < lstLanguagesKnown.Items.Count; n++)
            {

                if (lstLanguagesKnown.Items[n].Selected)
                {
                    if (strLanguagesIDS == "")
                    {
                        strLanguagesIDS = lstLanguagesKnown.Items[n].Value;
                    }
                    else
                    {
                        strLanguagesIDS = strLanguagesIDS + "," + lstLanguagesKnown.Items[n].Value;
                    }
                }

            }*/

            con.Open();
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_UPDATE_BC_APP_VERFICATION", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@BCA_ID", ddlBCACODE.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_NAME", rbFullName.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_NAME_RMKS", txtFullNameRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_FHNAME", rbFatherHusbandName.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_FHNAME_RMKS", txtFatherHusbandText.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_ADDRESS", rblAddress.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_ADDRESS_RMKS", txtAddressRemarks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_RES_PHNO", rbResidencePhNo.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_RES_PHNO_RMKS", txtResidencePhNoRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_OFF_PHNO", rbOfficePhNo.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_OFF_PHNO_RMKS", txtOfficePhNoRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_MBL_NO", rbMobileNo.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_MBL_NO_RMKS", txtMobileNoRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_RC_NO", rblRCNo.SelectedValue);    
            cmdinsert.Parameters.AddWithValue("@VBCA_RC_NO_RMKS", txtRationCardNumberRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_AC_NO", rblACNo.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_AC_NO_RMKS", txtAadharCardNumberRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_VI_NO", rblVINo.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_VI_NO_RMKS", txtVoterIDRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_PP_NO", rblPPNo.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_PP_NO_RMKS", txtPassportNoRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_PC_NO", rblPCNo.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_PC_NO_RMKS", txtPANCardNumberRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_DL_NO", rblDLNo.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_DL_NO_RMKS", txtDLNoRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_DOB", rblDOB.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_DOB_RMKS", txtDOBRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_EDUCATION", rblEducation.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_EDUCATION_RMKS", txtEducationRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_OCCUPATION", rblOccupation.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_OCCUPATION_RMKS", txtOccupationRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_MON_INC", rblIncomePerMonth.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_MON_INC_RMKS", txtIncomePerMonthRmks.Text);
           /* cmdinsert.Parameters.AddWithValue("@BCA_LANG_KNW", strLanguagesIDS);*/
            cmdinsert.Parameters.AddWithValue("@VBCA_LANG_KNW", rblLanguagesKnown.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_LANG_KNW_RMKS", txtLanguageKnownRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_YRS_STAY", rblStayingStablility.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_YRS_STAY_RMKS", txtStayingStabilityRmks.Text);
            //cmdinsert.Parameters.AddWithValue("@VBCA_POLICE_REC", rblPoliceRecordStat.SelectedValue);
            //cmdinsert.Parameters.AddWithValue("@VBCA_POLICE_REC_RMKS", txtPolicRecordStatusRmks.Text);
            cmdinsert.Parameters.AddWithValue("@VBCA_REF", rblRefStatus.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_REF_RMKS", txtReferenceStatusRmks.Text);
           // cmdinsert.Parameters.AddWithValue("@BCA_OWN_PROP", ddlPropertyStatus.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_OWN_PROP", rblPropertyStatus.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@VBCA_OWN_PROP_RMKS", txtPropertyStatusRmks.Text);
            cmdinsert.Parameters.AddWithValue("@BCA_APP_STAT", rbApplicationStatus.SelectedValue);
            //cmdinsert.Parameters.AddWithValue("@BCA_RISK_STAT", ddlRiskStatusReason.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@BCA_RISK_STAT", "Recommended");
            cmdinsert.Parameters.AddWithValue("@BCA_RISK_STAT_RSN", ddlRiskStatus.Text);
            cmdinsert.Parameters.AddWithValue("@BCA_RISK_OVAL_RMKS", txtRiskOvlRmks.Text);
            cmdinsert.Parameters.AddWithValue("@BCA_VBY", Convert.ToInt32(Session["ID"].ToString()));
             //bala changes 06/04/2016    
             //TRM Verification Submission                                                                    
            if (Session["EMP_ET_ID"].ToString() == "13")
            {
                // cmdinsert.Parameters.AddWithValue("@BCA_VDATE", DateTime.Now);
                cmdinsert.ExecuteNonQuery();

                sendBCMail(ddlBCACODE.SelectedItem.Text);

                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('" + BCA_CODE + " verfication has been drafted successfully for TRM Approval.');window.location.reload()", true);

            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@BCA_VDATE", DateTime.Now);
                cmdinsert.ExecuteNonQuery();
              
                 ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('" + BCA_CODE + " verfication has been submitted successfully');window.location.reload()", true);
           
            }
           
                                                                                    
            con.Close();
            clear();
            bind();
           // bindBCAList();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void sendBCMail(string BC_CODE)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            DataSet ds = new DataSet();
            con.Open();
            SqlCommand cmd = new SqlCommand("select EMP_EMAILID from MR_EMPLOYEE EM LEFT JOIN MR_BRANCH BR ON BR.BR_ID=EM.EMP_BR_ID LEFT JOIN MR_AREA AR ON AR.AR_ID=BR.BR_AR_ID  where  EMP_ET_ID=" + Convert.ToInt32(Session["EMP_ET_ID"].ToString()) + " AND AR.AR_ID =" + Convert.ToInt32(ddlArea.SelectedValue), con);
            SqlDataAdapter showdata = new SqlDataAdapter(cmd);
            showdata.Fill(ds);


           // SqlCommand cmdmailto = new SqlCommand("SELECT EM_RPA FROM MR_EMAIL where EM_BR_ID='" + ddlBranch.SelectedValue.ToString() + "'", con);
            SqlCommand cmdmailto = new SqlCommand("select EMP_EMAILID from MR_EMPLOYEE EM LEFT JOIN MR_BRANCH BR ON BR.BR_ID=EM.EMP_BR_ID LEFT JOIN MR_AREA AR ON AR.AR_ID=BR.BR_AR_ID  where  EMP_ET_ID=14 AND AR.AR_ID =" + Convert.ToInt32(ddlArea.SelectedValue), con);

            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
              //  to = dsmailto.Tables[0].Rows[0]["EMP_EMAILID"].ToString();
                to = dsmailto.Tables[0].Rows[0]["EMP_EMAILID"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EMP_EMAILID"].ToString() : "rts-helpdesk@equitasbank.com";

                //cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() + ";" + dsmailto.Tables[0].Rows[0]["EM_CM"].ToString() + ";" + dsmailto.Tables[0].Rows[0]["EM_HO"].ToString();
                cc = "";

                cc = cc.Replace("\n", "");
                bcc = "";// dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = "";
                bcc3 = "";
            }
            //int EMPID = Convert.ToInt32(ds.Tables[0].Rows[0]["USR_EMP_ID"]);
            string from, subject;

            // Session["R_USR_UTP_ID"] = ds.Tables[0].Rows[0]["USR_EMP_ID"].ToString();
            subject = "Connectors Code : " + BC_CODE.ToString() + " .";
            from = "RTS <donotreply@equitasbank.com>";

            //to = ds.Tables[0].Rows[0]["EM_RPA"].ToString();

            // to = "balasubramanind@equitasbank.com";





            System.Threading.Thread threadSendMails;
            string BodyTxt = "";
          /*  threadSendMails = new System.Threading.Thread(delegate()
            {*/

            BodyTxt = "<html><body><basefont face='Calibri'> Dear TRM,<br/><br/> Connectors Code has been verified in " + ddlBranch.SelectedItem.Text + " Branch<br/><br/>";
                BodyTxt = BodyTxt + "<table width='40%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Policy No **</b></td><td style='whiteSpace:nowrap;' ></td></tr>";
                BodyTxt = BodyTxt + "<tr ><td ><b>Branch ID.</b></td><td style='whiteSpace:nowrap;' >" + Session["BRANCHID"].ToString() + "</td></tr>";
                BodyTxt = BodyTxt + "<tr><td ><b>Area Name</b></td><td >" + ddlArea.SelectedItem.Text + "</td></tr>";
                BodyTxt = BodyTxt + "<tr><td ><b>Branch Name</b></td><td >" + ddlBranch.SelectedItem.Text + "</td></tr>";
                BodyTxt = BodyTxt + "<tr ><td ><b>Reference ID</b></td><td style='whiteSpace:nowrap;' >" + BC_CODE + "</td></tr>";

                string strURL = "";

                strURL = "http://rts.equitasbank.com/rts/BC_Verification.aspx?BCAID=" + ddlBCACODE.SelectedValue + "&BCA_CODE=" + ddlBCACODE.SelectedItem.Text + "&USR_TYPE=14";
                //strURL = " http://localhost:49476/BC_Verification.aspx?BCAID=" + ddlBCACODE.SelectedValue + "&BCA_CODE=" + ddlBCACODE.SelectedItem.Text + "&USR_TYPE=14";

           

                 //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Created By</b></td><td style='whiteSpace:nowrap;' >" + Session["User"].ToString() + "</td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Verified Date</b></td><td style='whiteSpace:nowrap;' >" + DateTime.Now.ToString("dd/MM/yyyy") + "</td></tr>";
                BodyTxt = BodyTxt + "</table><br/>";
                 string tmpEmailContent = "";
                 tmpEmailContent += "<tr><td align='left' colspan='2'>Please <a href='<TRACKINGURL>'>click here</a> to login and submit the verfication.<br/></td></tr>";
                   tmpEmailContent = tmpEmailContent.Replace("<TRACKINGURL>", strURL);
                BodyTxt=BodyTxt + tmpEmailContent;
                
               // BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'>Please click the following <a href='http://172.16.2.95/RTS/BCVerification.aspx?BCAID=' + ddlBCACODE.SelectedValue + '&BCA_CODE=" + ddlBCACODE.SelectedItem.Text+ "&USR_TYPE=14"></a>link to submit the verification.</td></tr>";

              
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/>Thanks and Regards,<br/>RTS Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";


                EmailManager.sendemail(to, from, "", "", "Connectors Code " + BC_CODE + " - FRO verification has been completed in " + ddlBranch.SelectedItem.Text, BodyTxt, "", true);


          /*  });

            threadSendMails.IsBackground = true;

            threadSendMails.Start();

            if (threadSendMails.IsAlive) { Thread.Sleep(7000); }
                */
        }

        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally { con.Close(); }
    }
    protected void clear()
    {
        try
        {
            rbFatherHusbandName.SelectedIndex = -1;
            txtFatherHusbandText.Text = "";
            rblAddress.SelectedIndex = -1;
            txtAddressRemarks.Text = "";
            rblRCNo.SelectedIndex=-1;
            txtRationCardNumberRmks.Text = "";
            rblACNo.SelectedIndex = -1;
            txtAadharCardNumberRmks.Text = "";
            rblVINo.SelectedIndex = -1;
            txtVoterIDRmks.Text = "";
            rblPPNo.SelectedIndex = -1;
            txtPassportNoRmks.Text = "";
            rblPCNo.SelectedIndex = -1;
            txtPANCardNumberRmks.Text = "";
            rblDLNo.SelectedIndex = -1;
            txtDLNoRmks.Text = "";
            rblDOB.SelectedIndex = -1;
            txtDOBRmks.Text = "";
            rblEducation.SelectedIndex = -1;
            txtEducationRmks.Text = "";
            rblOccupation.SelectedIndex = -1;
            txtOccupationRmks.Text = "";
            rblIncomePerMonth.SelectedIndex = -1;
            txtIncomePerMonthRmks.Text = "";
            rblLanguagesKnown.SelectedIndex = -1;
            txtLanguageKnownRmks.Text = "";
            rblStayingStablility.SelectedIndex = -1;
            txtStayingStabilityRmks.Text = "";
            rblPoliceRecordStat.SelectedIndex = -1;
            txtPolicRecordStatusRmks.Text = "";
            rblRefStatus.SelectedIndex = -1;
            txtReferenceStatusRmks.Text = "";
          //  ddlPropertyStatus.SelectedValue = "0";
            txtPropertyStatusRmks.Text = "";
            rbApplicationStatus.SelectedIndex = -1;
            ddlRiskStatusReason.SelectedValue = "0";
            ddlRiskStatus.SelectedValue = "0";
            txtRiskOvlRmks.Text = "";
            lblFullName.Text = "";
            lblFatherHusbandText.Text = "";
            lblAddress.Text = "";
            lblRationCardNumber.Text = "";
            lblAadharNo.Text = "";
            lblVoterIDNo.Text = "";
            lblPassportNo.Text = "";
            lblPANCardNumber.Text = "";
            lblDLNo.Text = "";
            lblDOB.Text = "";
            lblEducation.Text = "";
            lblOccupation.Text = "";
            lblIncomePerMonth.Text = "";
            lblLanguagesKnown.Text = "";
            lblStayingStability.Text = "";
            lblPoliceRecordStatus.Text = "";
            lblReferenceStatus.Text = "";
            lblPropertyStatus.Text = "";
            rbFullName.SelectedIndex = -1;
            txtFullNameRmks.Text = "";
            rblPropertyStatus.SelectedIndex = -1;
            ddlRiskStatus.Enabled = false;
            lblResidencePhNo.Text = "";
            lblOfficePhNo.Text = "";
            lblMobilePhNo.Text = "";
           // ddlBCACODE.SelectedValue = "0";
            rbResidencePhNo.SelectedIndex = -1;
            rbOfficePhNo.SelectedIndex = -1;
            rbMobileNo.SelectedIndex = -1;
            txtResidencePhNoRmks.Text = "";
            txtOfficePhNoRmks.Text = "";
            txtMobileNoRmks.Text = "";

        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clear();
        bind();
       
        //bindBCAList();
    }
    public void bind()
    {
        /*SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        */
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();
     

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
        if (Session["USR_ACS"].ToString() == "1")
        {

            ddlBranch.Enabled = true;
            ddlArea.Enabled = true;
        }
        if (Session["USR_ACS"].ToString() == "7")
        {
            
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
        if (Session["USR_ACS"].ToString() == "5")
        {

            ddlBranch.Enabled = true;
            ddlArea.Enabled = false;
        }
        if (Session["USR_ACS"].ToString() == "4")
        {

            ddlBranch.Enabled = true;
            ddlArea.Enabled = true;
        }
        bindBCAList();
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        ddlBCACODE.Items.Clear();
        ddlBCACODE.Items.Insert(0, new ListItem("--Select--", "0"));
        clear();
        //bind();
       
    }
    public void bindBCAList()
    {
        try
        {
          //  ds_obj = clscommon.Get_BCACODE_List_ByBranch(Convert.ToInt32(ddlBranch.SelectedValue));
            ds_obj = clscommon.Get_BCACODE_List_ByBranch(Convert.ToInt32(ddlBranch.SelectedValue), Session["EMP_ET_ID"].ToString());
            ddlBCACODE.DataSource = ds_obj;
            ddlBCACODE.DataTextField = "BCA_CODE";
            ddlBCACODE.DataValueField = "BCA_ID";
            ddlBCACODE.DataBind();
            ddlBCACODE.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
           // ds_obj = clscommon.Get_BCACODE_List_ByBranch(Convert.ToInt32(ddlBranch.SelectedValue));
            ds_obj = clscommon.Get_BCACODE_List_ByBranch(Convert.ToInt32(ddlBranch.SelectedValue), Session["EMP_ET_ID"].ToString());
            ddlBCACODE.DataSource = ds_obj;
            ddlBCACODE.DataTextField = "BCA_CODE";
            ddlBCACODE.DataValueField = "BCA_ID";
            ddlBCACODE.DataBind();
            ddlBCACODE.Items.Insert(0, new ListItem("--Select--", "0"));

            //clear();
            //bind();
            //bindBCAList();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);

        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        try
        {
            clear();
           
            bind();
          
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
       
    }
    protected void ddlBCACODE_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            clear();
            if (ddlBCACODE.SelectedIndex > 0)
            {
                DataSet dsBCA = clscommon.GetBCApplicationForm_Details(Convert.ToInt32(ddlBCACODE.SelectedValue),"");

                if (dsBCA != null && dsBCA.Tables[0].Rows.Count > 0)
                {

                    string strAddress = "";

                    //lblFullName.Text = dsBCA.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsBCA.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
                    lblFullName.Text = dsBCA.Tables[0].Rows[0]["BCA_NAME"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_NAME"].ToString() : "";
                    lblFatherHusbandText.Text = dsBCA.Tables[0].Rows[0]["BCA_FHNAME"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_FHNAME"].ToString() : "";
                    strAddress += dsBCA.Tables[0].Rows[0]["BCA_PA_DNO"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_PA_DNO"].ToString() + "," : "";
                    strAddress += ((dsBCA.Tables[0].Rows[0]["BCA_PA_LOC"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_PA_LOC"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_PA_LOC"].ToString() + ",<br/>" : "");
                    strAddress += ((dsBCA.Tables[0].Rows[0]["BCA_PA_PO"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_PA_PO"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_PA_PO"].ToString() + ",<br/>" : "");
                    strAddress += ((dsBCA.Tables[0].Rows[0]["BCA_PA_TALUK"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_PA_TALUK"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_PA_TALUK"].ToString() + ",<br/>" : "");
                    strAddress += ((dsBCA.Tables[0].Rows[0]["BCA_PA_DIST"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_PA_DIST"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_PA_DIST"].ToString() + ",<br/>" : "");
                    strAddress += ( dsBCA.Tables[0].Rows[0]["BCA_PA_STATE"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_PA_STATE"].ToString()+ ".<br/>" : "");
                    strAddress += (dsBCA.Tables[0].Rows[0]["BCA_PA_PINCODE"] != DBNull.Value ? "Pincode - "+ dsBCA.Tables[0].Rows[0]["BCA_PA_PINCODE"].ToString() + "" : "");
                    lblAddress.Text = strAddress;
                    lblResidencePhNo.Text = ((dsBCA.Tables[0].Rows[0]["BCA_RES_PHNO"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_RES_PHNO"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_RES_PHNO"].ToString() : "Nil");
                    lblOfficePhNo.Text = ((dsBCA.Tables[0].Rows[0]["BCA_OFF_PHNO"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_OFF_PHNO"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_OFF_PHNO"].ToString() : "Nil");
                    lblMobilePhNo.Text = ((dsBCA.Tables[0].Rows[0]["BCA_MBL_NO"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_MBL_NO"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_MBL_NO"].ToString() : "Nil");
                    lblRationCardNumber.Text = (dsBCA.Tables[0].Rows[0]["BCA_RC_No"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_RC_No"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_RC_No"].ToString() : "Nil";
                    lblAadharNo.Text = (dsBCA.Tables[0].Rows[0]["BCA_AC_No"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_AC_No"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_AC_No"].ToString() : "Nil";
                    lblVoterIDNo.Text = (dsBCA.Tables[0].Rows[0]["BCA_VI_No"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_VI_No"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_VI_No"].ToString() : "Nil";
                    lblPassportNo.Text = (dsBCA.Tables[0].Rows[0]["BCA_PP_No"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_PP_No"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_PP_No"].ToString() : "Nil";
                    lblPANCardNumber.Text = (dsBCA.Tables[0].Rows[0]["BCA_PC_No"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_PC_No"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_PC_No"].ToString() : "Nil";
                    lblDLNo.Text = (dsBCA.Tables[0].Rows[0]["BCA_DL_No"] != DBNull.Value) && (dsBCA.Tables[0].Rows[0]["BCA_DL_No"] != "") ? dsBCA.Tables[0].Rows[0]["BCA_DL_No"].ToString() : "Nil";
                    lblDOB.Text = dsBCA.Tables[0].Rows[0]["BCA_DOB"] != DBNull.Value ? Convert.ToDateTime(dsBCA.Tables[0].Rows[0]["BCA_DOB"]).ToString("dd/MMM/yyyy") : "";
                    lblEducation.Text = dsBCA.Tables[0].Rows[0]["BCA_DL_No"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_DL_No"].ToString() : "Nil";
                    lblEducation.Text = dsBCA.Tables[0].Rows[0]["BCA_EDUCATION"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_EDUCATION"].ToString() : "Nil";
                    lblOccupation.Text = dsBCA.Tables[0].Rows[0]["BCA_OCCUPATION"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_OCCUPATION"].ToString() : "Nil";
                    lblIncomePerMonth.Text = dsBCA.Tables[0].Rows[0]["BCA_MON_INC"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_MON_INC"].ToString() : "Nil";
                    lblLanguagesKnown.Text = dsBCA.Tables[0].Rows[0]["BCA_LANG_KNW"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_LANG_KNW"].ToString() : "Nil";
                    lblStayingStability.Text = dsBCA.Tables[0].Rows[0]["BCA_YRS_STAY"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_YRS_STAY"].ToString() : "Nil";
                    lblPoliceRecordStatus.Text = dsBCA.Tables[0].Rows[0]["BCA_POLICE_REC"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_POLICE_REC"].ToString() : "Nil";
                    lblReferenceStatus.Text = dsBCA.Tables[0].Rows[0]["BCA_REF1_NAME"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_REF1_NAME"].ToString() : "Nil";
                    lblPropertyStatus.Text = dsBCA.Tables[0].Rows[0]["BCA_OWN_PROP"] != DBNull.Value ? dsBCA.Tables[0].Rows[0]["BCA_OWN_PROP"].ToString() : "Nil";
                
                if(dsBCA.Tables[0].Rows[0]["BCA_VBY"] != DBNull.Value)
                {
                    rbFullName.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_NAME"]).ToString();
                    rbFatherHusbandName.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_FHNAME"]).ToString();
                    rblDOB.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_DOB"]).ToString();
                    rblEducation.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_EDUCATION"]).ToString();
                    rblAddress.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_ADDRESS"]).ToString();
                    rblPropertyStatus.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_OWN_PROP"]).ToString();
                    rblStayingStablility.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_YRS_STAY"]).ToString();
                    rbResidencePhNo.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_RES_PHNO"]).ToString();
                    rbOfficePhNo.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_OFF_PHNO"]).ToString();
                    rbMobileNo.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_MBL_NO"]).ToString();
                    rblRCNo.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_RC_NO"]).ToString();
                    rblACNo.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_AC_NO"]).ToString();
                    rblVINo.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_VI_NO"]).ToString();
                    rblPPNo.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_PP_NO"]).ToString();
                    rblPCNo.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_PC_NO"]).ToString();
                    rblDLNo.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_DL_NO"]).ToString();
                    rblOccupation.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_OCCUPATION"]).ToString();
                    rblIncomePerMonth.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_MON_INC"]).ToString();
                    rblLanguagesKnown.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_LANG_KNW"]).ToString();
                   // rblPoliceRecordStat.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_POLICE_REC"]).ToString();
                    rblRefStatus.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_REF"]).ToString();
                  //  rblPropertyStatus.SelectedValue = Convert.ToInt32(dsBCA.Tables[0].Rows[0]["VBCA_REF"]).ToString();

                    rbApplicationStatus.SelectedValue = dsBCA.Tables[0].Rows[0]["BCA_APP_STAT"].ToString();
                    ddlRiskStatus.SelectedValue = dsBCA.Tables[0].Rows[0]["BCA_RISK_STAT_RSN"].ToString();
                    txtRiskOvlRmks.Text = dsBCA.Tables[0].Rows[0]["BCA_RISK_OVAL_RMKS"].ToString();

                    txtFullNameRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_NAME_RMKS"].ToString();
                    txtFatherHusbandText.Text = dsBCA.Tables[0].Rows[0]["VBCA_FHNAME_RMKS"].ToString();
                    txtAddressRemarks.Text = dsBCA.Tables[0].Rows[0]["VBCA_ADDRESS_RMKS"].ToString();
                    txtResidencePhNoRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_RES_PHNO_RMKS"].ToString();
                    txtOfficePhNoRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_OFF_PHNO_RMKS"].ToString();
                    txtMobileNoRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_MBL_NO_RMKS"].ToString();
                    txtRationCardNumberRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_RC_NO_RMKS"].ToString();
                    txtAadharCardNumberRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_AC_NO_RMKS"].ToString();
                    txtVoterIDRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_VI_NO_RMKS"].ToString();
                   // txtVoterIDRmks.Text = dsBCA.Tables[0].Rows[0]["BCA_RISK_OVAL_RMKS"].ToString();
                    txtPassportNoRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_PP_NO_RMKS"].ToString();
                    txtPANCardNumberRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_PC_NO_RMKS"].ToString();
                    txtDLNoRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_DL_NO_RMKS"].ToString();
                    txtDOBRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_DOB_RMKS"].ToString();
                    txtEducationRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_EDUCATION_RMKS"].ToString();
                   txtOccupationRmks.Text= dsBCA.Tables[0].Rows[0]["VBCA_OCCUPATION_RMKS"].ToString();
                   txtIncomePerMonthRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_MON_INC_RMKS"].ToString();
                   txtLanguageKnownRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_LANG_KNW_RMKS"].ToString();
                   txtStayingStabilityRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_YRS_STAY_RMKS"].ToString();
                   txtPropertyStatusRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_OWN_PROP_RMKS"].ToString();
                   txtReferenceStatusRmks.Text = dsBCA.Tables[0].Rows[0]["VBCA_REF_RMKS"].ToString();
                   ddlRiskStatus.Enabled = true;
                  
                }
                
                
                }
            }
            else
            {
                ddlBCACODE.Items.Clear();
                ddlBCACODE.Items.Insert(0, new ListItem("--Select--", "0"));
               // cam_clear();

            }
           
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }



    }

    protected void rbApplicationStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (rbApplicationStatus.SelectedItem.Text == "Negative")
            {
                ddlRiskStatus.Enabled = true;
                
            }
            else
            {
                ddlRiskStatus.Enabled = false;
                ddlRiskStatus.SelectedValue = "0";
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}