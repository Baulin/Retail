﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using Tracker;

public partial class LeadHistory : System.Web.UI.Page
{
    //int leadid;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    string strServer = "";
    DataSet ds = new DataSet();
    DataSet dsdd = new DataSet();

    static string ldno = "";


    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.bt_print);

        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                pnlpdf0.Visible = false;
                CreditPanel.Visible = false;
                LegalPanel.Visible = false;
                HOOPS.Visible = false;
                //pnlHeader.Visible = false;        
                PanelQuery.Visible = false;
                pnlPhysicalFile.Visible = false;
                bt_print.Visible = false;
                pnldisbdets.Visible = false;
                gvQuery.Dispose();
                GV_Legalquery.Dispose();
                GV_HO_OPS.Dispose();
                GVFTStatus.Dispose();
            }

            else
            {
                Response.Redirect("default.aspx");
            }
        }
        
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //base.VerifyRenderingInServerForm(control);
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (txtlead.Text != "")
        {
            Clear();
            pnlpdf0.Visible = true;
            CreditPanel.Visible = true;
            LegalPanel.Visible = true;
            HOOPS.Visible = true;
            bt_print.Visible = true;
            tblHead.Visible = true;
            PanelQuery.Visible = true;
            pnlPhysicalFile.Visible = true;
            pnldisbdets.Visible = true;
            GenerateReport();
            if (lblStatus.Text.Contains("LIVE"))
            {
                this.live.Visible = true;
                this.close.Visible = false;
                this.live.BgColor = "Green";
                this.live_c1.Style.Add("color", "White");
                this.live_c2.Style.Add("color", "White");
            }
            else
            {
                this.live.Visible = false;
                this.close.Visible = true;
                this.close.BgColor = "Red";
                this.close_c1.Style.Add("color", "White");
                this.close_c2.Style.Add("color", "White");
                this.close_c3.Style.Add("color", "White");
                this.close_c4.Style.Add("color", "White");

            }
            //lblHeader.Text = "LEAD HISTORY - " + lblLeadNo.Text;
        }
        else
        {
            string msg = "";
            if (rbtnldno.Checked == true)
            {
                msg = "Please enter Lead No...";
            }
            else if (rbtnlnno.Checked == true)
            {
                msg = "Please enter  Loan No...";
            }
            else
            {//
                msg = "Please enter  Sanction No...";
            }

            uscMsgBox1.AddMessage(msg, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
           // ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", "alert('" + msg + "');", true);
        }
    }

    protected void bt_print_Click(object sender, EventArgs e)
    {
        try
        {
            pnlpdf0.Visible = true;
            CreditPanel.Visible = true;
            LegalPanel.Visible = true;
            HOOPS.Visible = true;
            PanelQuery.Visible = true;
            pnlPhysicalFile.Visible = true;
            pnldisbdets.Visible = true;
            System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();

            img.ImageUrl = Server.MapPath("~/Images/JPG/MIFLogo.JPG");
            tdLogo.Controls.Add(img);

            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=Lead_History_of_" + ldno + ".pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            StringWriter sw0 = new StringWriter();
            HtmlTextWriter hw0 = new HtmlTextWriter(sw0);
            pnlHeader.RenderControl(hw0);

            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            CreditPanel.RenderControl(hw);

            StringWriter sw1 = new StringWriter();
            HtmlTextWriter hw1 = new HtmlTextWriter(sw1);
            LegalPanel.RenderControl(hw1);

            StringWriter sw3 = new StringWriter();
            HtmlTextWriter hw3 = new HtmlTextWriter(sw3);
            HOOPS.RenderControl(hw3);

            StringWriter sw4 = new StringWriter();
            HtmlTextWriter hw4 = new HtmlTextWriter(sw4);
            PanelQuery.RenderControl(hw4);

            StringWriter sw5 = new StringWriter();
            HtmlTextWriter hw5 = new HtmlTextWriter(sw5);
            pnldisbdets.RenderControl(hw5);

            StringWriter sw6 = new StringWriter();
            HtmlTextWriter hw6 = new HtmlTextWriter(sw6);
            pnlPhysicalFile.RenderControl(hw6);

            StringWriter sw2 = new StringWriter();
            HtmlTextWriter hw2 = new HtmlTextWriter(sw2);
            pnlpdf0.RenderControl(hw2);

            StringReader sr = new StringReader(sw0.ToString() + "<br/>" + sw2.ToString() + sw.ToString());
            //StringReader sr1 = new StringReader(sw0.ToString() + "<br/>" + sw.ToString());
            StringReader sr2 = new StringReader(sw0.ToString() + "<br/>" + sw1.ToString());
            StringReader sr3 = new StringReader(sw0.ToString() + "<br/>" + sw3.ToString());
            StringReader sr4 = new StringReader(sw0.ToString() + "<br/>" + sw4.ToString());
            StringReader sr5 = new StringReader(sw0.ToString() + "<br/>" + sw5.ToString());
            StringReader sr6 = new StringReader(sw0.ToString() + "<br/>" + sw6.ToString());

            Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            //  Document pdfDoc = new Document();
            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);

            pdfDoc.Open();
            pdfDoc.NewPage();

            pdfDoc.HtmlStyleClass = "PdfClass";
            htmlparser.Parse(sr);

            pdfDoc.NewPage();
            pdfDoc.HtmlStyleClass = "PdfClass";
            htmlparser.Parse(sr2);

            pdfDoc.NewPage();
            pdfDoc.HtmlStyleClass = "PdfClass";
            htmlparser.Parse(sr3);

            pdfDoc.NewPage();
            pdfDoc.HtmlStyleClass = "PdfClass";
            htmlparser.Parse(sr4);


            pdfDoc.NewPage();
            pdfDoc.HtmlStyleClass = "PdfClass";
            htmlparser.Parse(sr5);

            pdfDoc.NewPage();
            pdfDoc.HtmlStyleClass = "PdfClass";
            htmlparser.Parse(sr6);


            pdfDoc.Close();
            Response.Write(pdfDoc);

            Response.End();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void GenerateReport()
    {
        try
        {

            string passval = "";
            if (rbtnldno.Checked == true)
            {
                passval = "LDNO";
            }
            else if (rbtnlnno.Checked == true)
            {
                passval = "LNNO";
            }
            else
            {//
                passval = "SANCNO";
            }



            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_LeadHistory_Report", con);
            cmddd.Parameters.AddWithValue("@LEADNO", txtlead.Text.Trim());
            cmddd.Parameters.AddWithValue("@PTYPE", passval);
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            dadd.Fill(dsdd);

            if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
            {
                pnlpdf0.Visible = true;
                // Search creteria
                ldno = dsdd.Tables[0].Rows[0]["LD_NO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_NO"].ToString() : "NIL";
                lblHeader.Text = "LEAD HISTORY - " + ldno;

                lblStatus.Text = dsdd.Tables[0].Rows[0]["STATUS"].ToString();
                //lblstat
                lblstat.Text = dsdd.Tables[0].Rows[0]["STATUS"].ToString();
                lblState.Text = dsdd.Tables[0].Rows[0]["ST_NAME"].ToString();
                lblDivision.Text = dsdd.Tables[0].Rows[0]["DV_NAME"].ToString();
                lblBranchname.Text = dsdd.Tables[0].Rows[0]["BR_NAME"].ToString();
                lblArea.Text = dsdd.Tables[0].Rows[0]["AR_NAME"].ToString();
                lblPDDate.Text = dsdd.Tables[0].Rows[0]["PD_DATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PD_DATE"].ToString() : "NIL";
                lblAppDate.Text = dsdd.Tables[0].Rows[0]["CREDITAPPROVEDDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CREDITAPPROVEDDATE"].ToString() : "NIL";
                lblAppBy.Text = dsdd.Tables[0].Rows[0]["CREDITAPPROVAL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CREDITAPPROVAL"].ToString() : "Approval Status";
                LbllegalAppDate.Text = dsdd.Tables[0].Rows[0]["LEGALAPPROVEDDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LEGALAPPROVEDDATE"].ToString() : "NIL";
                lblLegalAppBy.Text = dsdd.Tables[0].Rows[0]["LEGALAPPROVAL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LEGALAPPROVAL"].ToString() : "Approval Status";
                lblLegalApproAmt.Text = dsdd.Tables[0].Rows[0]["LD_LG_AMT"] != DBNull.Value ? "Rs. " + Convert.ToDecimal(dsdd.Tables[0].Rows[0]["LD_LG_AMT"].ToString()).ToString("F") : "NIL";
                lblLDcreateddate.Text = dsdd.Tables[0].Rows[0]["LDCREATEDDATE"].ToString();
                lblProduct.Text = dsdd.Tables[0].Rows[0]["PR_CODE"].ToString();
                lblAppName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString();

                lblLoanAmt.Text = dsdd.Tables[0].Rows[0]["LD_PD_AMT"] != DBNull.Value ? "Rs. " + Convert.ToDecimal(dsdd.Tables[0].Rows[0]["LD_PD_AMT"].ToString()).ToString("F") : "NIL";
                lblApproveAmt.Text = dsdd.Tables[0].Rows[0]["LD_CRAP_AMT"] != DBNull.Value ? "Rs. " + Convert.ToDecimal(dsdd.Tables[0].Rows[0]["LD_CRAP_AMT"].ToString()).ToString("F") : "NIL";
                lbllglpreopinion.Text = dsdd.Tables[0].Rows[0]["MD_PDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_PDATE"].ToString() : "NIL";


                lbllnno.Text = dsdd.Tables[0].Rows[0]["LD_LOAN_NO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_LOAN_NO"].ToString() : "NIL";
                lbllndt.Text = dsdd.Tables[0].Rows[0]["LD_LOAN_DATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_LOAN_DATE"].ToString() : "NIL";
                lbllnamt.Text = dsdd.Tables[0].Rows[0]["LD_LOAN_AMT"] != DBNull.Value ? "Rs. " + dsdd.Tables[0].Rows[0]["LD_LOAN_AMT"].ToString() : "NIL";
                /*Bala changes for New changes added*/
                lblCRInitDate.Text = dsdd.Tables[0].Rows[0]["LD_CPD_INIT_DATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_CPD_INIT_DATE"].ToString() : "NIL";
                lblCR_PD_Completion.Text = dsdd.Tables[0].Rows[0]["LD_CPD_MDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_CPD_MDATE"].ToString() : "NIL";
                lbl_CR_Tech_INIT_Date.Text = dsdd.Tables[0].Rows[0]["TECH_INIT_DATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["TECH_INIT_DATE"].ToString() : "NIL";
                lbl_CR_Resp_INIT_Date.Text = dsdd.Tables[0].Rows[0]["RESP_TECH_INIT_DATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["RESP_TECH_INIT_DATE"].ToString() : "NIL";
                if (dsdd.Tables[24].Rows.Count > 0)
                {
                    lbl_CR_FinalCAM_Date.Text = dsdd.Tables[24].Rows[0]["CAM_FINAL_DATE"] != DBNull.Value ? dsdd.Tables[24].Rows[0]["CAM_FINAL_DATE"].ToString() : "NIL";
                }
                if (dsdd.Tables[25].Rows.Count > 0)
                {
                    lblSVSPmtMethod.Text = dsdd.Tables[25].Rows[0]["InstrShrtDescr"] != DBNull.Value ? dsdd.Tables[25].Rows[0]["InstrShrtDescr"].ToString() : "NIL";
                    lblUTRNumber.Text = dsdd.Tables[25].Rows[0]["InstrNo"] != DBNull.Value ? dsdd.Tables[25].Rows[0]["InstrNo"].ToString() : "NIL";
                    lblInstruDate.Text = dsdd.Tables[25].Rows[0]["InstrDt"] != DBNull.Value ? dsdd.Tables[25].Rows[0]["InstrDt"].ToString() : "NIL";
                }
                lbl_CR_UPLCAM_Date.Text = dsdd.Tables[0].Rows[0]["LD_CAM_UPD_SDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_CAM_UPD_SDATE"].ToString() : "NIL";
                /*Bala changes for New changes added*/

                lbldmapprovdt.Text = dsdd.Tables[0].Rows[0]["DMADATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["DMADATE"].ToString() : "NIL";
                lbldmrqtdt.Text = dsdd.Tables[0].Rows[0]["DMDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["DMDATE"].ToString() : "NIL";
                lbldmapprvby.Text = dsdd.Tables[0].Rows[0]["DMAPPROV"] != DBNull.Value ?  dsdd.Tables[0].Rows[0]["DMAPPROV"].ToString() : "Approval Status";
                //
                lblbrnchov.Text = dsdd.Tables[0].Rows[0]["OVSTAT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["OVSTAT"].ToString() : "NIL";
                lblmodtddate.Text = dsdd.Tables[0].Rows[0]["MODTDSTAT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MODTDSTAT"].ToString() : "NIL";
                //RFD Details
                lblRFDBy.Text = dsdd.Tables[0].Rows[0]["LD_RDY_MBY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_RDY_MBY"].ToString() : "NIL";
                lblrfddate.Text = dsdd.Tables[0].Rows[0]["LD_RDY_MDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_RDY_MDATE"].ToString() : "NIL";
              //Bala changes 15112016
                // lblrfdholddate.Text = dsdd.Tables[0].Rows[0]["LD_RDY_RMKS_MDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_RDY_RMKS_MDATE"].ToString() : "NIL";
               // lblrfdholdrmks.Text = dsdd.Tables[0].Rows[0]["LD_RDY_RMKS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_RDY_RMKS"].ToString() : "NIL";


                /*PDD DETAILS */

                //BRANCH RECVD PDD
                lbl_md_br_rby.Text = dsdd.Tables[0].Rows[0]["MD_BR_RBY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_BR_RBY"].ToString() : "NIL";
                lbl_md_br_rdate.Text = dsdd.Tables[0].Rows[0]["MD_BR_RDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_BR_RDATE"].ToString() : "NIL";

                //BRANCH SENT PDD

                lbl_md_br_sby.Text = dsdd.Tables[0].Rows[0]["MD_BR_SBY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_BR_SBY"].ToString() : "NIL";
                lbl_md_sdate.Text = dsdd.Tables[0].Rows[0]["MD_BR_SDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_BR_SDATE"].ToString() : "NIL";
                lbl_md_br_stype.Text = dsdd.Tables[0].Rows[0]["BR_STYPE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_STYPE"].ToString() : "NIL";

                if (lbl_md_sdate.Text == "NIL")
                    lbl_md_br_stype.Text = "NIL";

                //LEGAL RECVD PDD

                lbl_md_lg_rby.Text = dsdd.Tables[0].Rows[0]["MD_LG_RBY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_LG_RBY"].ToString() : "NIL";
                lbl_md_lg_rdate.Text = dsdd.Tables[0].Rows[0]["MD_LG_RDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_LG_RDATE"].ToString() : "NIL";


                //LEGAL SENT PDD

                lbl_md_lg_sby.Text = dsdd.Tables[0].Rows[0]["MD_LG_SBY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_LG_SBY"].ToString() : "NIL";
                lbl_md_lg_sdate.Text = dsdd.Tables[0].Rows[0]["MD_LG_SDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_LG_SDATE"].ToString() : "NIL";
                lbl_md_lg_stype.Text = dsdd.Tables[0].Rows[0]["LG_STYPE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LG_STYPE"].ToString() : "NIL";

                if (lbl_md_lg_sdate.Text == "NIL")
                    lbl_md_lg_stype.Text = "NIL";

                //DO-HO RECVD PDD

                lbl_md_hlg_rby.Text = dsdd.Tables[0].Rows[0]["MD_HLG_RBY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_HLG_RBY"].ToString() : "NIL";
                lbl_md_hlg_rdate.Text = dsdd.Tables[0].Rows[0]["MD_HLG_RDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_HLG_RDATE"].ToString() : "NIL";


                //DO-HO SENT PDD

                lbl_md_hlg_sby.Text = dsdd.Tables[0].Rows[0]["MD_HLG_SBY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_HLG_SBY"].ToString() : "NIL";
                lbl_md_hlg_sdate.Text = dsdd.Tables[0].Rows[0]["MD_HLG_SDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_HLG_SDATE"].ToString() : "NIL";

                //HO-OPS RECVD PDD

                lbl_md_ho_rby.Text = dsdd.Tables[0].Rows[0]["MD_HO_RBY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_HO_RBY"].ToString() : "NIL";
                lbl_md_ho_rdate.Text = dsdd.Tables[0].Rows[0]["MD_HO_RDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MD_HO_RDATE"].ToString() : "NIL";


                if (dsdd.Tables[2] != null && dsdd.Tables[2].Rows.Count > 0)
                {

                    if (dsdd.Tables[0].Rows[0]["CREDITAPPROVAL"] != DBNull.Value)
                    {
                        string crdapp = "";
                        crdapp = dsdd.Tables[2].Rows[0]["EMP_CODE"] != DBNull.Value ? dsdd.Tables[2].Rows[0]["EMP_CODE"].ToString() : " ";
                        if (dsdd.Tables[2].Rows[0]["EMP_NAME"] != DBNull.Value)
                        {

                            crdapp = crdapp + " / " + dsdd.Tables[2].Rows[0]["EMP_NAME"].ToString();
                        }
                        else
                        {
                            crdapp = crdapp + " / " + " ";
                        }

                        lblApprovedBy.Text = crdapp;

                    }

                    lblLegalApproAmt.Text = dsdd.Tables[0].Rows[0]["LD_LG_AMT"] != DBNull.Value ? "Rs. " + Convert.ToDecimal(dsdd.Tables[0].Rows[0]["LD_LG_AMT"].ToString()).ToString("F") : "NIL";
                }
                else
                {

                    lblApprovedBy.Text = "NIL";
                }
                lblCreditComment.Text = dsdd.Tables[0].Rows[0]["LD_CRAP_CMTS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_CRAP_CMTS"].ToString() : "NIL";


                lblOfflineAprv.Text = dsdd.Tables[0].Rows[0]["MAN_EMP_CODE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MAN_EMP_CODE"].ToString() : "NIL";

                if (dsdd.Tables[4] != null && dsdd.Tables[4].Rows.Count > 0)
                {
                    string LGLapp = "";
                    LGLapp = dsdd.Tables[4].Rows[0]["EMP_CODE"] != DBNull.Value ? dsdd.Tables[4].Rows[0]["EMP_CODE"].ToString() : " ";
                    if (dsdd.Tables[4].Rows[0]["EMP_NAME"] != DBNull.Value)
                    {

                        LGLapp = LGLapp + " / " + dsdd.Tables[4].Rows[0]["EMP_NAME"].ToString();
                    }
                    else
                    {
                        LGLapp = LGLapp + " / " + " ";
                    }

                    lblLegalReject.Text = LGLapp;
                }
                else
                {
                    lblLegalReject.Text = dsdd.Tables[0].Rows[0]["FOSTAT"].ToString();
                }
                lblLegalComment.Text = dsdd.Tables[0].Rows[0]["LD_LG_CMTS"].ToString();
                lblHOApprove.Text = dsdd.Tables[0].Rows[0]["LD_SANTD_AMT"] != DBNull.Value ? "Rs. " + Convert.ToDouble(dsdd.Tables[0].Rows[0]["LD_SANTD_AMT"].ToString()).ToString("F") : "NIL";

                lblHOComments.Text = dsdd.Tables[0].Rows[0]["LD_SANTD_CMTS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_SANTD_CMTS"].ToString() : "NIL";
                lblRemarks.Text = dsdd.Tables[0].Rows[0]["LD_LC_RMKS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_LC_RMKS"].ToString() : "NIL";

                lblSantNo.Text = dsdd.Tables[0].Rows[0]["LD_SANTD_NO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_SANTD_NO"].ToString() : "NIL";
                lblSancDate.Text = dsdd.Tables[0].Rows[0]["LD_SANTD_DATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_SANTD_DATE"].ToString() : "NIL";

                if (dsdd.Tables[9] != null && dsdd.Tables[9].Rows.Count > 0)
                {
                    lblSentToCreditDate.Text = dsdd.Tables[9].Rows[0]["BC_SDATE"] != DBNull.Value ? dsdd.Tables[9].Rows[0]["BC_SDATE"].ToString() : "NIL";
                    lblCreditReceivedate.Text = dsdd.Tables[9].Rows[0]["BC_RDATE"] != DBNull.Value ? dsdd.Tables[9].Rows[0]["BC_RDATE"].ToString() : "NIL";
                    lbl_credit_recv_by.Text = dsdd.Tables[9].Rows[0]["CREDIT_RECV_BY"] != DBNull.Value ? dsdd.Tables[9].Rows[0]["CREDIT_RECV_BY"].ToString() : "NIL";
                }
                else
                {
                    lblSentToCreditDate.Text= "NIL";
                    lblCreditReceivedate.Text = "NIL";
                    lbl_credit_recv_by.Text = "NIL";
                }

                if (dsdd.Tables[10] != null && dsdd.Tables[10].Rows.Count > 0)
                {
                    lblSentToLegalDate.Text = dsdd.Tables[10].Rows[0]["BL_SDATE"] != DBNull.Value ? dsdd.Tables[10].Rows[0]["BL_SDATE"].ToString() : "NIL";
                    lblReceiveDate.Text = dsdd.Tables[10].Rows[0]["BL_RDATE"] != DBNull.Value ? dsdd.Tables[10].Rows[0]["BL_RDATE"].ToString() : "NIL";
                    lbl_lgl_recv_by.Text = dsdd.Tables[10].Rows[0]["LGL_RECV_BY"] != DBNull.Value ? dsdd.Tables[10].Rows[0]["LGL_RECV_BY"].ToString() : "NIL";
                }
                else
                {
                    lblSentToLegalDate.Text = "NIL";
                    lblReceiveDate.Text = "NIL";
                    lbl_lgl_recv_by.Text = "NIL";
                }
                if (dsdd.Tables[11] != null && dsdd.Tables[11].Rows.Count > 0)
                {

                    lblCreditSentDate.Text = dsdd.Tables[11].Rows[0]["CH_SDATE"] != DBNull.Value ? dsdd.Tables[11].Rows[0]["CH_SDATE"].ToString() : "NIL";
                    lblHOopsReceiveDate.Text = dsdd.Tables[11].Rows[0]["CH_RDATE"] != DBNull.Value ? dsdd.Tables[11].Rows[0]["CH_RDATE"].ToString() : "NIL";
                    lbl_credit_sent_hoops_by.Text = dsdd.Tables[11].Rows[0]["CREDIT_HOOPS_SENT_BY"] != DBNull.Value ? dsdd.Tables[11].Rows[0]["CREDIT_HOOPS_SENT_BY"].ToString() : "NIL";
                    lbl_hoops_recv_by.Text = dsdd.Tables[11].Rows[0]["HOOPS_RECV_BY"] != DBNull.Value ? dsdd.Tables[11].Rows[0]["HOOPS_RECV_BY"].ToString() : "NIL";

                    //HOOPS_RECV_BY
                }

                else
                {
                    lblCreditSentDate.Text = "NIL";
                    lblHOopsReceiveDate.Text = "NIL";
                    lbl_credit_sent_hoops_by.Text = "NIL";
                    lbl_hoops_recv_by.Text = "NIL";
                }
                if (dsdd.Tables[12] != null && dsdd.Tables[12].Rows.Count > 0)
                {
                    lblCAMDate.Text = dsdd.Tables[12].Rows[0]["CAMDATE"] != DBNull.Value ? dsdd.Tables[12].Rows[0]["CAMDATE"].ToString() : "NIL";
                }
                else
                {
                    lblCAMDate.Text = "NIL";
                }
                if (dsdd.Tables[13] != null && dsdd.Tables[13].Rows.Count > 0)
                {
                    lblRPAInitiatedDate.Text = dsdd.Tables[13].Rows[0]["RPADATE"] != DBNull.Value ? dsdd.Tables[13].Rows[0]["RPADATE"].ToString() : "NIL";
                    lblRPACompletedDate.Text = dsdd.Tables[13].Rows[0]["RPAMDATE"] != DBNull.Value ? dsdd.Tables[13].Rows[0]["RPAMDATE"].ToString() : "NIL";
                    lblrpaentrycomp.Text = dsdd.Tables[13].Rows[0]["RPACDATE"] != DBNull.Value ? dsdd.Tables[13].Rows[0]["RPACDATE"].ToString() : "NIL";
                    lbl_rpa_visited_by.Text = dsdd.Tables[13].Rows[0]["RPA_VISITED_BY"] != DBNull.Value ? dsdd.Tables[13].Rows[0]["RPA_VISITED_BY"].ToString() : "NIL";
                }
                else
                {
                    lblRPAInitiatedDate.Text = "NIL";
                    lblRPACompletedDate.Text = "NIL";
                    lblrpaentrycomp.Text = "NIL";
                    lbl_rpa_visited_by.Text = "NIL";
                }
                if (dsdd.Tables[14] != null)
                {

                    lblsammarking.Text = "NIL";
                    lblSamDscn.Text = "NIL";
                    lblSamSDate.Text = "NIL";
                    lblRecomAmount1.Text = "NIL";

                    lblSamAppealDate.Text = "NIL";
                    lblSCIDesn.Text = "NIL";
                    lblSCISDate.Text = "NIL";
                    lblRecomAmount2.Text = "NIL";

                    lblApprovaldate.Text = "NIL";
                    lblACIDesicion.Text = "NIL";
                    lblACIDate.Text = "NIL";
                    lblRecomAmount3.Text = "NIL";
                    lblsampociallocateddt.Text = "NIL";

                }
                if (dsdd.Tables[14] != null && dsdd.Tables[14].Rows.Count > 0)
                {
                    TblSampling.Visible = true;
                    lblsammarking.Text = dsdd.Tables[14].Rows[0]["SLDATE"] != DBNull.Value ? dsdd.Tables[14].Rows[0]["SLDATE"].ToString() : "NIL";
                    lblSamDscn.Text = dsdd.Tables[14].Rows[0]["SL_DECSN"] != DBNull.Value ? dsdd.Tables[14].Rows[0]["SL_DECSN"].ToString() : "NIL";
                    lblSamSDate.Text = dsdd.Tables[14].Rows[0]["STATUSDATE"] != DBNull.Value ? dsdd.Tables[14].Rows[0]["STATUSDATE"].ToString() : "NIL";
                    lblRecomAmount1.Text = dsdd.Tables[14].Rows[0]["SL_RAMT"] != DBNull.Value ? "Rs. " + Convert.ToDecimal(dsdd.Tables[14].Rows[0]["SL_RAMT"].ToString()).ToString("F") : "NIL";

                    lblSamAppealDate.Text = dsdd.Tables[14].Rows[0]["SAPLDATE"] != DBNull.Value ? dsdd.Tables[14].Rows[0]["SAPLDATE"].ToString() : "NIL";
                    lblSCIDesn.Text = dsdd.Tables[14].Rows[0]["SL_SCI_DESCN"] != DBNull.Value ? dsdd.Tables[14].Rows[0]["SL_SCI_DESCN"].ToString() : "NIL";
                    lblSCISDate.Text = dsdd.Tables[14].Rows[0]["SCI_SDATE"] != DBNull.Value ? dsdd.Tables[14].Rows[0]["SCI_SDATE"].ToString() : "NIL";

                    if (dsdd.Tables[14].Rows.Count > 1)
                    {
                        lblRecomAmount2.Text = dsdd.Tables[14].Rows[1]["SL_RAMT"] != DBNull.Value ? "Rs. " + Convert.ToDecimal(dsdd.Tables[14].Rows[1]["SL_RAMT"].ToString()).ToString("F") : "NIL";
                    }
                    else
                    {
                        lblRecomAmount2.Text = "NIL";
                    }
                    lblApprovaldate.Text = dsdd.Tables[14].Rows[0]["AAPLDATE"] != DBNull.Value ? dsdd.Tables[14].Rows[0]["AAPLDATE"].ToString() : "NIL";
                    lblACIDesicion.Text = dsdd.Tables[14].Rows[0]["SL_ACI_DESCN"] != DBNull.Value ? dsdd.Tables[14].Rows[0]["SL_ACI_DESCN"].ToString() : "NIL";
                    lblACIDate.Text = dsdd.Tables[14].Rows[0]["SL_ACI_SDATE"] != DBNull.Value ? dsdd.Tables[14].Rows[0]["SL_ACI_SDATE"].ToString() : "NIL";
                    
                    lblsampociallocateddt.Text = dsdd.Tables[14].Rows[0]["MDATE"] != DBNull.Value ? dsdd.Tables[14].Rows[0]["MDATE"].ToString() : "NIL";

                    if (dsdd.Tables[14].Rows.Count > 2)
                    {
                        lblRecomAmount3.Text = dsdd.Tables[14].Rows[2]["SL_RAMT"] != DBNull.Value ? "Rs. " + Convert.ToDecimal(dsdd.Tables[14].Rows[2]["SL_RAMT"].ToString()).ToString("F") : "NIL";
                    }
                    else
                    {
                        lblRecomAmount3.Text = "NIL";
                    }
                }

                if (dsdd.Tables[1] != null)
                {
                    gvQuery.DataSource = dsdd.Tables[1];
                    gvQuery.DataBind();
                }
                if (dsdd.Tables[3] != null)
                {
                    GV_Legalquery.DataSource = dsdd.Tables[3];
                    GV_Legalquery.DataBind();
                }
                if (dsdd.Tables[5] != null)
                {
                    GV_HO_OPS.DataSource = dsdd.Tables[5];
                    GV_HO_OPS.DataBind();
                }
                if (dsdd.Tables[7] != null)
                {
                    GVPRDD.DataSource = dsdd.Tables[7];
                    GVPRDD.DataBind();
                }
                if (dsdd.Tables[23] != null)
                {
                    gvPhysicalQry.DataSource = dsdd.Tables[23];
                    gvPhysicalQry.DataBind();
                }

                if (dsdd.Tables[8] != null)
                {
                    GVFTStatus.DataSource = dsdd.Tables[8];
                    GVFTStatus.DataBind();
                }

                if (dsdd.Tables[15] != null && dsdd.Tables[15].Rows.Count > 0)
                {
                    string Dmapp = "";
                    Dmapp = dsdd.Tables[15].Rows[0]["EMP_CODE"] != DBNull.Value ? dsdd.Tables[15].Rows[0]["EMP_CODE"].ToString() : "NIL";
                    if (dsdd.Tables[15].Rows[0]["EMP_NAME"] != DBNull.Value)
                    {

                        Dmapp = Dmapp + " / " + dsdd.Tables[15].Rows[0]["EMP_NAME"].ToString();
                    }
                    else
                    {
                        Dmapp = Dmapp + " / " + " ";
                    }


                    lbldmapprov.Text = Dmapp;

                }
                else
                {

                    lbldmapprov.Text = "NIL";
                }

                //OCI CAM DATE
                if (dsdd.Tables[16] != null && dsdd.Tables[16].Rows.Count > 0)
                {
                    lblSamOCICAMDate.Text = dsdd.Tables[16].Rows[0]["OCICAMDATE"] != DBNull.Value ? dsdd.Tables[16].Rows[0]["OCICAMDATE"].ToString() : "NIL";

                }
                else
                {

                    lblSamOCICAMDate.Text = "NIL";
                }   /* CHEQUE TRANSACTION */
                if (dsdd.Tables[17] != null)
                {
                    gvchequetrans.DataSource = dsdd.Tables[17];
                    gvchequetrans.DataBind();
                }
                //LOad BC Details
                if (dsdd.Tables[18] != null && dsdd.Tables[18].Rows.Count > 0)
                {
                    trBCDetails.Visible = true;
                    trBCInformation1.Visible = true;
                    trBCInformation2.Visible = true;
                    lblBCID.Text = dsdd.Tables[18].Rows[0]["BCA ID"] != DBNull.Value ? dsdd.Tables[18].Rows[0]["BCA ID"].ToString() : "NIL";
                    lblBCNAME.Text = dsdd.Tables[18].Rows[0]["BCA NAME"] != DBNull.Value ? dsdd.Tables[18].Rows[0]["BCA NAME"].ToString() : "NIL";
                    lblBCBNKBRName.Text = dsdd.Tables[18].Rows[0]["PANCARD NO"] != DBNull.Value ? dsdd.Tables[18].Rows[0]["PANCARD NO"].ToString() : "NIL";
                    lblBankACNo.Text = dsdd.Tables[18].Rows[0]["BANK ACCOUNT NUMBER"] != DBNull.Value ? dsdd.Tables[18].Rows[0]["BANK ACCOUNT NUMBER"].ToString() : "NIL";
                    lblBankName.Text = dsdd.Tables[18].Rows[0]["BANK NAME"] != DBNull.Value ? dsdd.Tables[18].Rows[0]["BANK NAME"].ToString() : "NIL";
                    lblBankBranch.Text = dsdd.Tables[18].Rows[0]["BRANCH NAME"] != DBNull.Value ? dsdd.Tables[18].Rows[0]["BRANCH NAME"].ToString() : "NIL";
                
                }
                else
                {
                    trBCDetails.Visible = false;
                    trBCInformation1.Visible = false;
                    trBCInformation2.Visible = false;
                }
                 //LOad Pre-Closure Details
                if (dsdd.Tables[19] != null && dsdd.Tables[19].Rows.Count > 0)
                {
                    lblPreReqDate.Text = dsdd.Tables[19].Rows[0]["Request Date"] != DBNull.Value ? dsdd.Tables[19].Rows[0]["Request Date"].ToString() : "";
                    
                    lblHOSentDate.Text = dsdd.Tables[19].Rows[0]["HO Sent Date"] != DBNull.Value ? dsdd.Tables[19].Rows[0]["HO Sent Date"].ToString() : "";
                    lblLegalReceiveDate.Text = dsdd.Tables[19].Rows[0]["Legal Receive Date"] != DBNull.Value ? dsdd.Tables[19].Rows[0]["Legal Receive Date"].ToString() : "";
                    lblLGLSentDOCToBranch.Text = dsdd.Tables[19].Rows[0]["Legal sent document to Branch"] != DBNull.Value ? dsdd.Tables[19].Rows[0]["Legal sent document to Branch"].ToString() : "";

                    lblLGLAckBRResp.Text = dsdd.Tables[19].Rows[0]["Legal Ack For Branch Resp"] != DBNull.Value ? dsdd.Tables[19].Rows[0]["Legal Ack For Branch Resp"].ToString() : "";
                    lblAckHOReceiveDate.Text = dsdd.Tables[19].Rows[0]["ACK HO Receive Date"] != DBNull.Value ? dsdd.Tables[19].Rows[0]["ACK HO Receive Date"].ToString() : "";
                

                }

                //LOad RFD Hold Remarks
               /* if (dsdd.Tables[21] != null && dsdd.Tables[21].Rows.Count > 0)
                {
                    lblHLD_OPS_RMKS.Text = dsdd.Tables[21].Rows[0]["HLD_OPS_RMKS"] != DBNull.Value ? dsdd.Tables[21].Rows[0]["HLD_OPS_RMKS"].ToString() : "";

                    lblHLD_OPS_DATE.Text = dsdd.Tables[21].Rows[0]["HLD_OPS_DATE"] != DBNull.Value ? dsdd.Tables[21].Rows[0]["HLD_OPS_DATE"].ToString() : "";
                    lblHLD_BR_RMKS.Text = dsdd.Tables[21].Rows[0]["HLD_BR_RMKS"] != DBNull.Value ? dsdd.Tables[21].Rows[0]["HLD_BR_RMKS"].ToString() : "";
                    lblHLD_BR_DATE.Text = dsdd.Tables[21].Rows[0]["HLD_BR_DATE"] != DBNull.Value ? dsdd.Tables[21].Rows[0]["HLD_BR_DATE"].ToString() : "";

                    lblHLD_HDK_DATE.Text = dsdd.Tables[21].Rows[0]["HLD_HDK_DATE"] != DBNull.Value ? dsdd.Tables[21].Rows[0]["HLD_HDK_DATE"].ToString() : "";
                    //lblAckHOReceiveDate.Text = dsdd.Tables[19].Rows[0]["ACK HO Receive Date"] != DBNull.Value ? dsdd.Tables[19].Rows[0]["ACK HO Receive Date"].ToString() : "";


                }*/
                if (dsdd.Tables[21] != null)
                {
                    gvRFDHold.DataSource = dsdd.Tables[21];
                    gvRFDHold.DataBind();
                }

                //Load Post PRDD Details
                if (dsdd.Tables[22] != null && dsdd.Tables[22].Rows.Count > 0)
                {
                    lblPhysicalBRSDate.Text = dsdd.Tables[22].Rows[0]["PRD_BR_SDATE"] != DBNull.Value ? dsdd.Tables[22].Rows[0]["PRD_BR_SDATE"].ToString() : "";
                    lblPhysicalBRSentBy.Text = dsdd.Tables[22].Rows[0]["PRD_BR_SBY"] != DBNull.Value ? dsdd.Tables[22].Rows[0]["PRD_BR_SBY"].ToString() : "";
                    lblPhysicalBRRevDate.Text = dsdd.Tables[22].Rows[0]["PRD_BR_HD_RDATE"] != DBNull.Value ? dsdd.Tables[22].Rows[0]["PRD_BR_HD_RDATE"].ToString() : "";
                    lblPhysicalBRRevBy.Text = dsdd.Tables[22].Rows[0]["PRD_BR_HD_RBY"] != DBNull.Value ? dsdd.Tables[22].Rows[0]["PRD_BR_HD_RBY"].ToString() : "";

                    lblPhysicalCRSDate.Text = dsdd.Tables[22].Rows[0]["PRD_CR_SDATE"] != DBNull.Value ? dsdd.Tables[22].Rows[0]["PRD_CR_SDATE"].ToString() : "";
                    lblPhysicalSentBy.Text = dsdd.Tables[22].Rows[0]["PRD_CR_SBY"] != DBNull.Value ? dsdd.Tables[22].Rows[0]["PRD_CR_SBY"].ToString() : "";
                    lblPhysicalRevDate.Text = dsdd.Tables[22].Rows[0]["PRD_CR_HD_RDATE"] != DBNull.Value ? dsdd.Tables[22].Rows[0]["PRD_CR_HD_RDATE"].ToString() : "";
                    lblPhysicalRevBy.Text = dsdd.Tables[22].Rows[0]["PRD_CR_HD_RBY"] != DBNull.Value ? dsdd.Tables[22].Rows[0]["PRD_CR_HD_RBY"].ToString() : "";
                    lblReadyToCheque.Text = dsdd.Tables[22].Rows[0]["PRD_HOVER_DATE"] != DBNull.Value ? dsdd.Tables[22].Rows[0]["PRD_HOVER_DATE"].ToString() : "";
                    lblRdyToCheqBy.Text = dsdd.Tables[22].Rows[0]["PRD_HOVER_BY"] != DBNull.Value ? dsdd.Tables[22].Rows[0]["PRD_HOVER_BY"].ToString() : "";
                
                }

                }
            else
            {


                string msg = "";
                if (rbtnldno.Checked == true)
                {
                    msg = "Invalid Lead No...";
                }
                else if (rbtnlnno.Checked == true)
                {
                    msg = "Invalid Loan No...";
                }
                else
                {//
                    msg = "Invalid Sanction No...";
                }

                uscMsgBox1.AddMessage(msg, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                pnlpdf0.Visible = false;
                CreditPanel.Visible = false;
                LegalPanel.Visible = false;
                HOOPS.Visible = false;
                pnldisbdets.Visible = false;
                PanelQuery.Visible = false;
                bt_print.Visible = false;
            }
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void Clear()
    {
        //lblLeadNo.Text="";
        lblStatus.Text = "";
        lblRemarks.Text = "";
        lblState.Text = "";
        lblDivision.Text = "";
        lblArea.Text = "";
        lblBranchname.Text = "";
        lblLDcreateddate.Text = "";
        lblProduct.Text = "";
        lblAppName.Text = "";
        lblPDDate.Text = "";
        lblLoanAmt.Text = "";
        lblCAMDate.Text = "";
        lblSentToCreditDate.Text = "";
        lblSentToLegalDate.Text = "";
        lblstat.Text = "";

        //Credit
        lblCreditReceivedate.Text = "";
        lblCreditSentDate.Text = "";
        lblRPAInitiatedDate.Text = "";
        lblRPACompletedDate.Text = "";
        lblSamOCICAMDate.Text = "";
        lblSamDscn.Text = "";
        lblSamSDate.Text = "";
        lblRecomAmount1.Text = "";
        lblSamAppealDate.Text = "";
        lblSCIDesn.Text = "";
        lblSCISDate.Text = "";
        lblRecomAmount2.Text = "";
        lblApprovaldate.Text = "";
        lblACIDesicion.Text = "";
        lblACIDate.Text = "";
        lblRecomAmount3.Text = "";
        lblApproveAmt.Text = "";
        lblAppDate.Text = "";
        lblApprovedBy.Text = "";
        lblCreditComment.Text = "";
        lblOfflineAprv.Text = "";
        lbldmrqtdt.Text = "";
        lbldmapprovdt.Text = "";
        lbldmapprvby.Text = "";
        lbldmapprov.Text = "";
        lblsampociallocateddt.Text = "";
        lblsammarking.Text = "";
        lblSamOCICAMDate.Text = "";
        lblrpaentrycomp.Text = "";

        lbl_credit_recv_by.Text = "";
        lbl_credit_sent_hoops_by.Text = "";

        lbl_rpa_visited_by.Text = "";
        

        //Legal
        lblReceiveDate.Text = "";
        lbllglpreopinion.Text = "";
        lblbrnchov.Text = "";
        lblLegalApproAmt.Text = "";
        LbllegalAppDate.Text = "";
        lblLegalAppBy.Text = "";
        lblLegalReject.Text = "";
        lblLegalComment.Text = "";
        lbl_lgl_recv_by.Text = "";
        
        lblmodtddate.Text = "";

        //HO OPS
        lblHOopsReceiveDate.Text = "";
        lblSantNo.Text = "";
        lblSancDate.Text = "";
        lblHOApprove.Text = "";
        lblHOComments.Text = "";

        lbl_hoops_recv_by.Text = "";


        //lblrfdholdrmks.Text = "";
        lblrfddate.Text = "";
        //lblrfdholddate.Text = "";

        //DISBURSEMENT DETS
        lbllnno.Text = "";
        lbllndt.Text = "";
        lbllnamt.Text = "";



        /* PDD */

        lbl_md_br_rdate.Text = "";
        lbl_md_br_rby.Text = "";
        lbl_md_sdate.Text = "";
        lbl_md_br_sby.Text = "";
        lbl_md_br_stype.Text = "";
        lbl_md_hlg_rdate.Text = "";
        lbl_md_hlg_rby.Text = "";
        lbl_md_hlg_sdate.Text = "";
        lbl_md_hlg_sby.Text = "";
        lbl_md_ho_rdate.Text = "";
        lbl_md_ho_rby.Text = "";


        gvQuery.DataSource = null;
        gvQuery.DataBind();


        GVPRDD.DataSource = null;
        GVPRDD.DataBind();

        gvPhysicalQry.DataSource = null;
        gvPhysicalQry.DataBind();

        GVFTStatus.DataSource = null;
        GVFTStatus.DataBind();

        GV_Legalquery.DataSource = null;
        GV_Legalquery.DataBind();

        GV_HO_OPS.DataSource = null;
        GV_HO_OPS.DataBind();

        gvchequetrans.DataSource = null;
        gvchequetrans.DataBind();

        gvRFDHold.DataSource = null;
        gvRFDHold.DataBind();

    }
    protected void rbtnldno_CheckedChanged(object sender, EventArgs e)
    {
       
        lblHeader.Text = "LEAD HISTORY";
        txtlead.Text = "";
        txtlead_TextBoxWatermarkExtender.WatermarkText = "Enter the Lead Number";
    }
    protected void rbtnsancno_CheckedChanged(object sender, EventArgs e)
    {
       
        lblHeader.Text = "LEAD HISTORY";
        txtlead.Text = "";
        txtlead_TextBoxWatermarkExtender.WatermarkText = "Enter the Sanction Number";

    }
    protected void rbtnlnno_CheckedChanged(object sender, EventArgs e)
    {
       
        lblHeader.Text = "LEAD HISTORY";
        txtlead.Text = "";
        txtlead_TextBoxWatermarkExtender.WatermarkText = "Enter the Loan Number";
    }
}