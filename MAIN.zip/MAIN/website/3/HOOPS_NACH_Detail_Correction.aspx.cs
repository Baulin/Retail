﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using System.Net.Mail;
using Tracker;

public partial class HOOPS_NACH_Detail_Correction : System.Web.UI.Page
{
   // string leadno="";
    string appname="";
    string pddt;
    string lnamt;
    string loanno = "";
    //string sa;
    int ldid;
    //int j;
    //int b;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    DateTime dt = DateTime.Now;
    string[] stringArray = new string[100];
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    public static bool blMailStatus = false;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    // DataSet dt = new DataSet();
    ClsCommon clscommon = new ClsCommon();
  protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                bind();
                BindCourierName();
                if (Session["TYPEID"].ToString() == "2")
                {
                    ddlArea.Enabled = false;
                    ddlArea.SelectedValue = Session["AREA_ID"].ToString();
                    SqlConnection con = new SqlConnection(strcon);
                    con.Open();
                    SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
                    cmdrsn.CommandType = CommandType.StoredProcedure;
                    cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
                    SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
                    DataSet dsrsn = new DataSet();
                    darsn.Fill(dsrsn);
                    con.Close();

                    ddlBranch.DataSource = dsrsn;
                    ddlBranch.DataTextField = "BR_NAME";
                    ddlBranch.DataValueField = "BR_ID";
                    ddlBranch.DataBind();
                    ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
                    ddlBranch.Enabled = false;
                    ddlBranch.SelectedValue = Session["BRANCHID"].ToString();


                }

                txtDate.Text = String.Format("{0:dd MMM yyyy}", DateTime.Now);
            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }

    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));


    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Enabled = false;
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";

            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "All";

            }
            else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                ddlArea.Enabled = false;

            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";

            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";

            }
            else if (txtLeadno.Text.Trim() != "")
            {
                Session["View"] = "F";

            }

            BindqueryGrid();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_NACH_DETAILS", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", ddlSearchBY.SelectedValue.ToString() == "Lead No" ? txtLeadno.Text : "");
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@TYPE", "BEFORECORRECTION");
            /*  if (Session["TYPEID"].ToString() == "3" || Session["TYPEID"].ToString() == "8" || Session["TYPEID"].ToString() == "14")
              {
                  cmd.Parameters.AddWithValue("@USERTYPE", "C");
                  btnSubmit.Enabled = true;
              }
              else if (Session["TYPEID"].ToString() == "2")
              {
                  cmd.Parameters.AddWithValue("@USERTYPE", "B");
              }*/
            //cmd.Parameters.AddWithValue("@PRODUCT", "SMELAP");
            cmd.Parameters.AddWithValue("@LOAN_NO", ddlSearchBY.SelectedValue.ToString() == "LOAN NO" ? txtLeadno.Text : "");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows.Count != null)
            {
                gvQuery.Visible = true;
                //Panel1.Visible = true;
                gvQuery.DataSource = ds1.Tables[0];
                gvQuery.DataBind();
              
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvQuery.Visible = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {

        //clear();
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            foreach (GridViewRow grow in gvQuery.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                Label lblNAID = grow.FindControl("lblNAID") as Label;
                //Label lblQryResult = grow.FindControl("lblQryResult") as Label;
                Label lblArea = grow.FindControl("lblArea") as Label;
                Label lblBranch = grow.FindControl("lblBranch") as Label;
                LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                HiddenField hdnLoanNo = grow.FindControl("hdnLoanNo") as HiddenField;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                  
                    loanno = hdnLoanNo.Value.ToString();
                   // Session["LeadNo"] = leadno;
                   
                    Session["NA_ID"] = lblNAID.Text;
                    // Session["QryType"] = lblQryResult.Text;
                    Session["ANAME"] = lblArea.Text;
                    Session["BNAME"] = lblBranch.Text;
                    // FetchDMCValues();
                    BankList();
                }
            }

           
           
            tblNACH.Visible = true;
            GetFetchBankInformation(Convert.ToInt32(Session["NA_ID"]));
           

            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlBank1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet dt = new DataSet();
            dt = clscommon.BindBankDetails_ByBankCode(ddlBank1.SelectedValue);
            ddlBankBranch.DataSource = dt;
            ddlBankBranch.DataTextField = "BK_BRANCH";
            ddlBankBranch.DataValueField = "BK_ID";
            ddlBankBranch.DataBind();
            ddlBankBranch.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", ""));



        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void bindbankbranch(string Branch_code)
    {
        try
        {
            DataSet dt = new DataSet();
            dt = clscommon.BindBankDetails_ByBankCode(Branch_code);
            ddlBankBranch.DataSource = dt;
            ddlBankBranch.DataTextField = "BK_BRANCH";
            ddlBankBranch.DataValueField = "BK_ID";
            ddlBankBranch.DataBind();
            ddlBankBranch.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", ""));
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void GetFetchBankInformation(int NA_ID)
    {
        try
        {
            DataSet dtNA = new DataSet();
            dtNA=clscommon.GetNACHDETAILS_By_NAID(Convert.ToInt32(Session["NA_ID"]));

            txtLeadNumber.Text = dtNA.Tables[0].Rows[0]["LD_NO"] != DBNull.Value ? dtNA.Tables[0].Rows[0]["LD_NO"].ToString() : "";
            txtLoanNo.Text = dtNA.Tables[0].Rows[0]["Loan Agreement No"] != DBNull.Value ? dtNA.Tables[0].Rows[0]["Loan Agreement No"].ToString() : "";
            

            DataSet dtBank = new DataSet();
            dtBank = clscommon.GetBankInformation_ByBankID(Convert.ToInt32(dtNA.Tables[0].Rows[0]["NA_BK_ID"]));
            bindbankbranch(dtBank.Tables[0].Rows[0]["BK_CODE"].ToString());
            txtIFSCCode.Text = dtBank.Tables[0].Rows[0]["BK_IFSC"] != DBNull.Value ? dtBank.Tables[0].Rows[0]["BK_IFSC"].ToString() : "";
            //ddlBankBranch.SelectedItem.Text = dtBank.Tables[0].Rows[0]["BK_BRANCH"] != DBNull.Value ? dtBank.Tables[0].Rows[0]["BK_BRANCH"].ToString() : "";
           // ddlBank1.SelectedItem.Text = dtBank.Tables[0].Rows[0]["BK_NAME"] != DBNull.Value ? dtBank.Tables[0].Rows[0]["BK_NAME"].ToString() : "";
            ddlBank1.SelectedValue = dtBank.Tables[0].Rows[0]["BK_CODE"] != DBNull.Value ? dtBank.Tables[0].Rows[0]["BK_CODE"].ToString() : "";
            ddlAccountType.SelectedValue = dtNA.Tables[0].Rows[0]["NA_ACC_TYPE"] != DBNull.Value ? dtNA.Tables[0].Rows[0]["NA_ACC_TYPE"].ToString() : "";
            txtEMI.Text = dtNA.Tables[0].Rows[0]["EMI Amount"] != DBNull.Value ? dtNA.Tables[0].Rows[0]["EMI Amount"].ToString() : "";
            txtPhoneNo.Text = dtNA.Tables[0].Rows[0]["Phone No"] != DBNull.Value ? dtNA.Tables[0].Rows[0]["Phone No"].ToString() : "";
            txtACHolderName.Text = dtNA.Tables[0].Rows[0]["NA_ACC_HOLDER"] != DBNull.Value ? dtNA.Tables[0].Rows[0]["NA_ACC_HOLDER"].ToString() : "";
            txtACNo.Text = dtNA.Tables[0].Rows[0]["NA_ACC_NO"] != DBNull.Value ? dtNA.Tables[0].Rows[0]["NA_ACC_NO"].ToString() : "";
            ddlBankBranch.SelectedValue = dtBank.Tables[0].Rows[0]["BK_ID"] != DBNull.Value ? dtBank.Tables[0].Rows[0]["BK_ID"].ToString() : "";
            txtPOD.Text = dtNA.Tables[0].Rows[0]["NA_POD_NO"] != DBNull.Value ? dtNA.Tables[0].Rows[0]["NA_POD_NO"].ToString() : "";
            ddlCourier.SelectedValue = dtNA.Tables[0].Rows[0]["NA_COURIER"] != DBNull.Value ? dtNA.Tables[0].Rows[0]["NA_COURIER"].ToString() : "";
            txtCourierDate.Text = dtNA.Tables[0].Rows[0]["NA_COURIER_DATE"] != DBNull.Value ? Convert.ToDateTime(dtNA.Tables[0].Rows[0]["NA_COURIER_DATE"]).ToString("dd/MM/yyyy") : "";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void GetBankInformation()
    {
        try
        {
            DataSet dtBank = new DataSet();
            dtBank = clscommon.GetBankInformation_ByBankID(Convert.ToInt32(ddlBankBranch.SelectedValue));
            txtIFSCCode.Text = dtBank.Tables[0].Rows[0]["BK_IFSC"] != DBNull.Value ? dtBank.Tables[0].Rows[0]["BK_IFSC"].ToString() : "";
            ddlBankBranch.SelectedValue = dtBank.Tables[0].Rows[0]["BK_BRANCH"] != DBNull.Value ? dtBank.Tables[0].Rows[0]["BK_BRANCH"].ToString() : "";
            ddlBank1.SelectedValue = dtBank.Tables[0].Rows[0]["BK_NAME"] != DBNull.Value ? dtBank.Tables[0].Rows[0]["BK_NAME"].ToString() : "";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BankList()
    {

        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_NACH_BIND_BANK", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        //cmddd.Parameters.AddWithValue("@BankName", "");
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        Session["Bank"] = dsdd.Tables[0];
        con.Close();
        ddlBank1.DataSource = dsdd;
        ddlBank1.DataTextField = "BK_NAME";
        ddlBank1.DataValueField = "BK_CODE";
        ddlBank1.DataBind();
        ddlBank1.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", ""));

    }
    protected void BindCourierName()
    {

        DataSet dsdd = new DataSet();
        dsdd = clscommon.Bind_Courier_Details();
        ddlCourier.DataSource = dsdd;
        ddlCourier.DataTextField = "CR_NAME";
        ddlCourier.DataValueField = "CR_NAME";
        ddlCourier.DataBind();
        ddlCourier.Items.Insert(0, new ListItem("--Select--", "0"));

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        DateTime dtd;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            dtd = DateTime.ParseExact(txtCourierDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            SqlCommand cmdinsert = new SqlCommand("RTS_SP_NACH_UPDATE_DETAILS", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;

            cmdinsert.Parameters.AddWithValue("@NA_ID", Convert.ToInt32(Session["NA_ID"]));
            cmdinsert.Parameters.AddWithValue("@NA_BK_ID", Convert.ToInt32(ddlBankBranch.SelectedValue));
            cmdinsert.Parameters.AddWithValue("@NA_ACC_TYPE", ddlAccountType.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@NA_ACC_NO", txtACNo.Text);
            cmdinsert.Parameters.AddWithValue("@NA_ACC_HOLDER", txtACHolderName.Text);
            cmdinsert.Parameters.AddWithValue("@NA_ACC_PHNO", txtPhoneNo.Text);
            cmdinsert.Parameters.AddWithValue("@NA_EMI", txtEMI.Text);
            cmdinsert.Parameters.AddWithValue("@NA_POD_NO", txtPOD.Text);
            cmdinsert.Parameters.AddWithValue("@NA_COURIER", ddlCourier.SelectedItem.Text);
            cmdinsert.Parameters.AddWithValue("@NA_COURIER_DATE", dtd);
            cmdinsert.Parameters.AddWithValue("@NA_MBY", Convert.ToInt32(Session["ID"]));
            cmdinsert.Parameters.AddWithValue("@NA_MDATE", DateTime.Now);
            //cmdinsert.Parameters.AddWithValue("@NA_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
            cmdinsert.ExecuteNonQuery();
           

            // ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('" + leadno + "'s NACH Details has been Saved Successfully.');window.location.reload()", true);
            // uscMsgBox1.AddMessage("NACH Details has been Saved Successfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('NACH Details has been updated successfully.');window.location.reload()", true);

            con.Close();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    protected void ddlBankBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            GetBankInformation();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}