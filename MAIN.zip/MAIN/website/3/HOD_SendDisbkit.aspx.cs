﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class HOD_SendDisbkit : System.Web.UI.Page
{
    int ldid, s;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            bind();
        }
    }

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
      //  ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    //public void bind()
    //{
    //    SqlConnection con = new SqlConnection(strcon);
    //    con.Open();
    //    SqlCommand cmddd = new SqlCommand("select AR_NAME,AR_ID from MR_AREA", con);
    //    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //    DataSet dsdd = new DataSet();
    //    dadd.Fill(dsdd);

    //    con.Close();
    //    ddlArea.DataSource = dsdd;
    //    ddlArea.DataTextField = "AR_NAME";
    //    ddlArea.DataValueField = "AR_ID";
    //    ddlArea.DataBind();
    //    ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

    //}

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME,BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //txtLeadno.Enabled = false;
        txtLeadno.Text = "";
    }


    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            s = 0;



            DataTable dtLead = new DataTable();
            DataRow dr = null;
            dtLead.Columns.Add("FT_LD_ID", typeof(string));
            dtLead.Columns.Add("FT_SENTTO", typeof(string));
            dtLead.Columns.Add("FT_CBY", typeof(string));
            dtLead.Columns.Add("FT_MBY", typeof(string));
            foreach (GridViewRow grow in gvBranchSF.Rows)
            {

                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    //Write some code if checkbox is checked
                    //SqlConnection con = new SqlConnection(strcon);              
                    s += 1;
                    Label lblLeadId = (Label)gvBranchSF.Rows[index].Cells[0].FindControl("lblLeadID");
                    dr = dtLead.NewRow();

                    dr["FT_LD_ID"] = lblLeadId.Text;
                    dr["FT_SENTTO"] = "H";
                    dr["FT_CBY"] = Session["ID"].ToString();
                    dr["FT_MBY"] = Session["ID"].ToString();
                    DataRow[] drTemp = dtLead.Select("FT_SENTTO ='D' AND FT_LD_ID = '" + lblLeadId.Text + "'");
                    if (drTemp.Length == 0)
                    {
                        dtLead.Rows.Add(dr);
                    }

                }
            }
            SqlCommand cmdinsert = new SqlCommand("RTS_DISP_Insert_LSD_FILE_TRANS", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@tblLeadDteails", dtLead);
            cmdinsert.Parameters.AddWithValue("@SentFrom", "D");
            cmdinsert.ExecuteNonQuery();

            gridbind();
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
            btnSubmit.Enabled = false;
            uscMsgBox1.AddMessage(s + " File/s Marked as Sent Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HOD_SendDisbKit.aspx");
    }
    public void gridbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_DISP_LeadDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@LD_PR_ID", SqlDbType.VarChar).Value = "0";
            cmd.Parameters.Add("@FT_SENTBY", SqlDbType.VarChar).Value = "D";
            cmd.Parameters.Add("@FT_SENTTO", SqlDbType.VarChar).Value = "H";   
            cmd.Parameters.Add("@LD_BR_ID", SqlDbType.VarChar).Value = ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue:"";
            cmd.Parameters.Add("@LD_AR_ID", SqlDbType.VarChar).Value = ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue : "";
            cmd.Parameters.Add("@LEADNO", SqlDbType.VarChar).Value = txtLeadno.Text;         
            cmd.Parameters.AddWithValue("@INPUTType", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                cmd.Parameters.AddWithValue("@INPUTVAL", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                cmd.Parameters.AddWithValue("@INPUTVAL", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                cmd.Parameters.AddWithValue("@INPUTVAL", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
            }          
            else
            {
                cmd.Parameters.AddWithValue("@INPUTVAL", 0);
            }

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //Panel1.Visible = true;
            gvBranchSF.DataSource = ds.Tables[0];
            gvBranchSF.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvBranchSF.HeaderRow.Font.Bold = true;
                gvBranchSF.HeaderRow.Cells[1].Text = "LEAD NO";
                gvBranchSF.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvBranchSF.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvBranchSF.HeaderRow.Cells[4].Text = "SANCTION NO";
                gvBranchSF.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvBranchSF.HeaderRow.Cells[1].Wrap = false;
                gvBranchSF.HeaderRow.Cells[2].Wrap = false;
                gvBranchSF.HeaderRow.Cells[3].Wrap = false;
                gvBranchSF.HeaderRow.Cells[4].Wrap = false;
                gvBranchSF.HeaderRow.Cells[5].Wrap = false;
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
       
        gridbind();
       
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }    
}