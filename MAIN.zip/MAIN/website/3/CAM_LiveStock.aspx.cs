﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using System.Net.Mail;
using Tracker;
using Utilities;

public partial class CAM_LiveStock : System.Web.UI.Page
{
    public static DataTable dtSourceOfIncome = null;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    public static bool blMailStatus = false;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    ClsCommon clscommon = new ClsCommon();
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;

    /*Mail id variables*/
    string ldno, area, brnch, apname, apmobile, propaddr, gv, landarea;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                VisibleFalse();
                clear();
                ddlTenure.SelectedValue = "5";
                txtBranchName.Text = Session["UNITNAME"].ToString();
                BindDropdownList();
                FirstGridViewRow();
                //Changes for IR-535
                SetTextForLabels();
                //End of Changes for IR-535
                End_use();
                //Mangalore Tiles
                txtDepreciation.Enabled = true;
            }
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
    }

    private void VisibleFalse()
    {
        row1.Visible = false;
        row2.Visible = false;
        row3.Visible = false;
        row4.Visible = false;
        row5.Visible = false;
        row6.Visible = false;
        row7.Visible = false;
        // row8.Visible = false;
        trRow9.Visible = false;
        row11.Visible = false;
    }

    protected void BindDropdownList()
    {
        BindLeadNo();
        BindRelationship();
        BindIncomeSource();
        //BindVintage();
        BindLoanPurpose();
        BindCreditHistory();
        BindCustRelation();
        BindProperty();
        BindOccupancy();
        BindUsage();
        BindBDAge();
        BindCategory();
        //  BindTenor();
        BindIntrest();
        BindCattle();
        // BindLawyerName();
    }

    // __________BIND DROP DOWN LIST START_____________//


    public void BindLeadNo()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_Lead_Details", con);
        cmddd.Parameters.AddWithValue("@LD_NO", "");
        cmddd.Parameters.AddWithValue("@Lead_Type", "IBSL");
        cmddd.Parameters.AddWithValue("@BranchName", txtBranchName.Text);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLeadNo.DataSource = dsdd;
        ddlLeadNo.DataTextField = "LD_NO";
        ddlLeadNo.DataValueField = "LD_ID";
        ddlLeadNo.DataBind();
        ddlLeadNo.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindBankStmt()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("SP_RTS_Fetch_BankSTmt", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlBnkSTmt.DataSource = dsdd;
        ddlBnkSTmt.DataTextField = "DS_DESC";
        ddlBnkSTmt.DataValueField = "DS_ID";
        ddlBnkSTmt.DataBind();
        ddlBnkSTmt.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindRelationship()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Relation", con);
        cmddd.Parameters.AddWithValue("@ER_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlRelationShip.DataSource = dsdd;
        ddlRelationShip.DataTextField = "ER_DESC";
        ddlRelationShip.DataValueField = "ER_ID";
        ddlRelationShip.DataBind();
        ddlRelationShip.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindIncomeSource()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_IN_SOURCE", con);
        cmddd.Parameters.AddWithValue("@INS_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlMainApplicant.DataSource = dsdd;
        ddlMainApplicant.DataTextField = "INS_DESC";
        ddlMainApplicant.DataValueField = "INS_ID";
        ddlMainApplicant.DataBind();
        ddlMainApplicant.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindVintage()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);
        cmddd.Parameters.AddWithValue("@VN_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlVintage.DataSource = dsdd;
        ddlVintage.DataTextField = "VN_DESC";
        ddlVintage.DataValueField = "VN_ID";
        ddlVintage.DataBind();
        ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindLoanPurpose()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PURPOSE", con);
        cmddd.Parameters.AddWithValue("@PP_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLoanPurpose.DataSource = dsdd;
        ddlLoanPurpose.DataTextField = "PP_DESC";
        ddlLoanPurpose.DataValueField = "PP_ID";
        ddlLoanPurpose.DataBind();
        ddlLoanPurpose.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindCreditHistory()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CR_HISTORY", con);
        cmddd.Parameters.AddWithValue("@CH_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlCreditHistory.DataSource = dsdd;
        ddlCreditHistory.DataTextField = "CH_DESC";
        ddlCreditHistory.DataValueField = "CH_ID";
        ddlCreditHistory.DataBind();
        ddlCreditHistory.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindCustRelation()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_RELATION", con);
        cmddd.Parameters.AddWithValue("@RL_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlCustRelation.DataSource = dsdd;
        ddlCustRelation.DataTextField = "RL_DESC";
        ddlCustRelation.DataValueField = "Rl_ID";
        ddlCustRelation.DataBind();
        ddlCustRelation.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindProperty()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY", con);
        cmddd.Parameters.AddWithValue("@PT_ID", "");
        cmddd.Parameters.AddWithValue("@PT_TYPE", "R");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlPropType.DataSource = dsdd;
        ddlPropType.DataTextField = "PT_DESC";
        ddlPropType.DataValueField = "PT_DESC";
        //ddlPropType.DataValueField = "PT_RSQRT";
        ddlPropType.DataBind();
        ddlPropType.Items.Insert(0, new ListItem("--Select--", ""));
    }
    public void BindOccupancy()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_OCCUPANCY", con);
        cmddd.Parameters.AddWithValue("@OC_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlOccupancyStatus.DataSource = dsdd;
        ddlOccupancyStatus.DataTextField = "OC_DESC";
        ddlOccupancyStatus.DataValueField = "OC_ID";
        ddlOccupancyStatus.DataBind();
        ddlOccupancyStatus.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindUsage()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_USAGE", con);
        cmddd.Parameters.AddWithValue("@UG_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlUsage.DataSource = dsdd;
        ddlUsage.DataTextField = "UG_DESC";
        ddlUsage.DataValueField = "UG_ID";
        ddlUsage.DataBind();
        ddlUsage.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindBDAge()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_BD_AGE", con);
        cmddd.Parameters.AddWithValue("@BA_ID", "");
        ///Mangalore Tiles  
        if (ddlPropType.SelectedItem.Text != "--Select--" && ddlPropType.SelectedItem.Text == "Mangalore tiled roofing")
        {
            cmddd.Parameters.AddWithValue("@BA_PTYP", "M");
        }
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();
        ddlAgeOfBuilding.DataSource = dsdd;
        ddlAgeOfBuilding.DataTextField = "BA_DESC";
        ddlAgeOfBuilding.DataValueField = "BA_DESC";
        ddlAgeOfBuilding.DataBind();
        ddlAgeOfBuilding.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindCategory()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
        cmddd.Parameters.AddWithValue("@CT_ID", "");
        cmddd.Parameters.AddWithValue("@CT_TYPE", "R");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        dtSourceOfIncome = dsdd.Tables[0];
        con.Close();
        ddlCustSource.DataSource = dsdd;
        ddlCustSource.DataTextField = "CT_DESC";
        ddlCustSource.DataValueField = "CT_DESC";
        ddlCustSource.DataBind();
        ddlCustSource.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindTenor()
    {
        string strFileName = "LSTTenor.xml";
        if (ddlLeadNo.SelectedItem.Text.Contains("ELP"))
        {
            strFileName = "EMPTenor.xml";
        }
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("XML/" + strFileName + ""));

        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();

        if (ds.Tables[0].Rows.Count != 0)
        {
            ddlTenure.DataSource = ds.Tables[0];

            ddlTenure.DataTextField = "Tenor";

            ddlTenure.DataValueField = "Tenor";

            ddlTenure.DataBind();
            ddlTenure.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        else
        {
            ddlTenure.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }
    public void BindCattle()
    {
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("XML/LSTCattle.xml"));

        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();

        if (ds.Tables.Count != 0)
        {
            hdnCattleRate.Value = ds.Tables[0].Rows[0][0].ToString();
        }
    }
    
    public void BindIntrest()
    {
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("XML/LSTIntrestRate.xml"));

        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();

        if (ds.Tables.Count != 0)
        {
            ddlIntrest.DataSource = ds;

            ddlIntrest.DataTextField = "Intrest";

            ddlIntrest.DataValueField = "Intrest";

            ddlIntrest.DataBind();

            ddlIntrest.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }

    public DataSet fetchLeadDetails(string strLeadNo)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Lead_Details", con);
        cmddd.Parameters.AddWithValue("@LD_NO", strLeadNo);
        cmddd.Parameters.AddWithValue("@Lead_Type", "IBSL");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        return dsdd;
    }
    // __________BIND DROP DOWN LIST END_____________//


    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            btnSubmit.Enabled = false;
            if (DDLkycName.SelectedIndex != 0 && ddlCustSource.SelectedItem.Text != "--Select--" && txtCustAge.Text != "" && ddlCustRelation.SelectedItem.Text != "--Select--"
                                   && txtIncome.Text != "")
            {
                AddNewRow();
            }
            else
            {
                if (DDLkycName.SelectedIndex == 0)
                {
                    DDLkycName.Focus();

                }
                else if (ddlCustSource.SelectedItem.Text == "--Select--")
                {
                    ddlCustSource.Focus();
                }
                else if (txtCustAge.Text == "")
                {
                    txtCustAge.Focus();

                }
                else if (ddlCustRelation.SelectedItem.Text == "--Select--")
                {
                    ddlCustSource.Focus();
                }
                else if (txtIncome.Text == "")
                {
                    txtCustAge.Focus();

                }
                uscMsgBox1.AddMessage("Please Give corresponding Inputs for Income details", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    private void FirstGridViewRow()
    {


        DataTable dt = new DataTable();
        DataRow dr = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("NAME", typeof(string)));
        dt.Columns.Add(new DataColumn("APP_TYPE", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_SOURCE", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_SOURCEID", typeof(string)));
        dt.Columns.Add(new DataColumn("AGE", typeof(string)));
        dt.Columns.Add(new DataColumn("RELATIONSHIP", typeof(string)));
        dt.Columns.Add(new DataColumn("RELATIONSHIPID", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_TAKEN", typeof(string)));
        dt.Columns.Add(new DataColumn("FACTORED_INCOME", typeof(string)));

        dr = dt.NewRow();
        //dr["RowNumber"] = 1;

        dr["NAME"] = string.Empty;
        dr["APP_TYPE"] = string.Empty;
        dr["INCOME_SOURCE"] = string.Empty;
        dr["INCOME_SOURCEID"] = string.Empty;
        dr["AGE"] = string.Empty;
        dr["RELATIONSHIP"] = string.Empty;
        dr["RELATIONSHIPID"] = string.Empty;
        dr["INCOME"] = string.Empty;
        dr["INCOME_TAKEN"] = string.Empty;
        dr["FACTORED_INCOME"] = string.Empty;
        dt.Rows.Add(dr);

        ViewState["CurrentTable"] = dt;

        gvIncomeDetail.DataSource = dt;
        gvIncomeDetail.DataBind();


    }
    private void AddNewRow()
    {
        int rowIndex = 0;

        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;



            if (dtCurrentTable.Rows.Count > 0 && dtCurrentTable.Rows[0][0].ToString() == "")
            {
                dtCurrentTable.Rows.RemoveAt(0);
            }
            drCurrentRow = dtCurrentTable.NewRow();
            drCurrentRow["NAME"] = DDLkycName.SelectedItem.Text;
            drCurrentRow["APP_TYPE"] = TBAppType.Text;

            //DDLkycName.Items.RemoveAt(DDLkycName.SelectedIndex);
            //DDLkycName.DataBind();
            drCurrentRow["INCOME_SOURCE"] = ddlCustSource.SelectedItem.Text != "--Select--" ? ddlCustSource.SelectedItem.Text : "";
            int INCOME_SOURCEID = FetchINCOME_SOURCEID(ddlCustSource.SelectedItem.Text);
            drCurrentRow["INCOME_SOURCEID"] = INCOME_SOURCEID;
            drCurrentRow["AGE"] = txtCustAge.Text;
            drCurrentRow["RELATIONSHIP"] = ddlCustRelation.SelectedItem.Text != "--Select--" ? ddlCustRelation.SelectedItem.Text : "";
            drCurrentRow["RELATIONSHIPID"] = ddlCustRelation.SelectedItem.Text != "--Select--" ? ddlCustRelation.SelectedValue.ToString() : "";
            drCurrentRow["INCOME"] = txtIncome.Text;
            drCurrentRow["INCOME_TAKEN"] = txtIncomeTaken.Text;
            drCurrentRow["FACTORED_INCOME"] = Convert.ToString(Convert.ToDouble(txtIncome.Text) * (Convert.ToDouble(txtIncomeTaken.Text) / 100));

            //  rowIndex++;
            // }
            dtCurrentTable.Rows.Add(drCurrentRow);
            ViewState["CurrentTable"] = dtCurrentTable;

            gvIncomeDetail.DataSource = dtCurrentTable;
            gvIncomeDetail.DataBind();
            Clear();

            /* double dblOldIncome = 0.0;
             foreach (GridViewRow grow in gvIncomeDetail.Rows)
             {
                 int index = grow.RowIndex;
                 double dblIncome = Convert.ToDouble(gvIncomeDetail.Rows[index].Cells[5].Text);
                 if (Convert.ToInt32(gvIncomeDetail.Rows[index].Cells[3].Text) < 60)
                 {


                     if (dblIncome > dblOldIncome)
                     {
                         txtNameofInsuredPerson.Text = gvIncomeDetail.Rows[index].Cells[0].Text;
                         dblOldIncome = dblIncome;
                     }
                 }

             }*/
            //bala changes 05112016
            string strOldname = "", strNewname = "";
            double Amount = 0.0;
            int nvalue = 0;
            DataTable dt1 = new DataTable();
            dt1.Columns.AddRange(new DataColumn[2] { 
                            new DataColumn("Name", typeof(string)),
                            new DataColumn("Amount", typeof(int)) });
            //DataTable dtTempData = dtCurrentTable.Select("AGE < 60").CopyToDataTable();
            DataRow[] drTemp = dtCurrentTable.Select("AGE < 60");
            if (drTemp.Length > 0)
            {
                DataTable dtTempData = drTemp.CopyToDataTable();
                if (dtTempData != null && dtTempData.Rows.Count > 0)
                {
                    for (int ncount = 0; ncount < dtTempData.Rows.Count; ncount++)
                    {
                        strNewname = dtTempData.Rows[ncount]["NAME"] != DBNull.Value ? dtTempData.Rows[ncount]["NAME"].ToString() : "";
                        Amount = dtTempData.Rows[ncount]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtTempData.Rows[ncount]["FACTORED_INCOME"]) : 0.0;
                        if (strOldname == "")
                        {
                            dt1.Rows.Add(strNewname, Amount);

                        }
                        else if (strOldname == strNewname)
                        {

                            dt1.Rows[nvalue]["Amount"] = Convert.ToDouble(dt1.Rows[nvalue]["Amount"]) + Amount;
                        }
                        else
                        {
                            dt1.Rows.Add(strNewname, Amount);
                            nvalue = nvalue + 1;
                        }
                        strOldname = strNewname;
                    }
                }
                if (dt1 != null && dt1.Rows.Count > 0)
                {
                    double dblTempAmount = 0.0;
                    for (int n = 0; n < dt1.Rows.Count; n++)
                    {

                        double dblAmont = dt1.Rows[n]["Amount"] != DBNull.Value ? Convert.ToDouble(dt1.Rows[n]["Amount"]) : 0.0;
                        if (dblAmont > dblTempAmount)
                        {
                            txtNameofInsuredPerson.Text = dt1.Rows[n]["Name"] != DBNull.Value ? dt1.Rows[n]["Name"].ToString() : "";
                            dblTempAmount = dblAmont;
                        }

                    }
                }
            }
            //bala changes end 05112016
            if (dtCurrentTable != null && dtCurrentTable.Rows.Count > 0)
            {
                double nTotalLoanEligibility = 0.0;

                for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                {
                    double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                    nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;
                }
                txtTotalLoanEligibility.Text = nTotalLoanEligibility.ToString();

                BindBorrower(dtCurrentTable);
            }
            //  }
        }
        else
        {
            Response.Write("ViewState is null");
        }
        //  SetPreviousData();
    }
    public void BindBorrower(DataTable dt)
    {
        /// NAME

        string strBrwname1 = "", strBrwname2 = "", strBrwname3 = "", strBrwname4 = "", strBrwname5 = "";

        if (drpName1.Items.Count > 0)
        {
            strBrwname1 = drpName1.SelectedValue;
        }
        if (drpName2.Items.Count > 0)
        {
            strBrwname2 = drpName2.SelectedValue;
        }
        if (drpName3.Items.Count > 0)
        {
            strBrwname3 = drpName3.SelectedValue;
        }
        if (drpName4.Items.Count > 0)
        {
            strBrwname4 = drpName4.SelectedValue;
        }
        if (drpName5.Items.Count > 0)
        {
            strBrwname5 = drpName5.SelectedValue;
        }

        drpName1.Items.Clear();
        drpName2.Items.Clear();
        drpName3.Items.Clear();
        drpName4.Items.Clear();
        drpName5.Items.Clear();

        drpName1.DataSource = dt;
        drpName2.DataSource = dt;
        drpName3.DataSource = dt;
        drpName4.DataSource = dt;
        drpName5.DataSource = dt;

        drpName1.DataTextField = "NAME";
        drpName1.DataValueField = "NAME";

        drpName2.DataTextField = "NAME";
        drpName2.DataValueField = "NAME";

        drpName3.DataTextField = "NAME";
        drpName3.DataValueField = "NAME";

        drpName4.DataTextField = "NAME";
        drpName4.DataValueField = "NAME";

        drpName5.DataTextField = "NAME";
        drpName5.DataValueField = "NAME";

        drpName1.DataBind();
        drpName2.DataBind();
        drpName3.DataBind();
        drpName4.DataBind();
        drpName5.DataBind();

        drpName1.Items.Insert(0, "--Select--");
        drpName2.Items.Insert(0, "--Select--");
        drpName3.Items.Insert(0, "--Select--");
        drpName4.Items.Insert(0, "--Select--");
        drpName5.Items.Insert(0, "--Select--");
        if (strBrwname1 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname1 + "'");
            if (dr.Length > 0)
            {
                drpName1.SelectedValue = strBrwname1;
            }
            else
            {
                txtFinanciear1.Text = "";
                txtEMIAmount1.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }

        }
        if (strBrwname2 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname2 + "'");
            if (dr.Length > 0)
            {
                drpName2.SelectedValue = strBrwname2;
            }
            else
            {
                txtFinanciear2.Text = "";
                txtEMIAmount2.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname3 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname3 + "'");
            if (dr.Length > 0)
            {

                drpName3.SelectedValue = strBrwname3;
            }
            else
            {
                txtFinanciear3.Text = "";
                txtEMIAmount3.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname4 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname4 + "'");
            if (dr.Length > 0)
            {
                drpName4.SelectedValue = strBrwname4;
            }
            else
            {
                txtFinanciear4.Text = "";
                txtEMIAmount4.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname5 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname5 + "'");
            if (dr.Length > 0)
            {
                drpName5.SelectedValue = strBrwname5;
            }
            else
            {
                txtFinanciear5.Text = "";
                txtEMIAmount5.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }

    }
    public int FetchINCOME_SOURCEID(string strDesc)
    {
        int INCOME_SOURCEID = 0;
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("Select CT_ID from MR_CATEGORY where  CT_PR_TYPE='R' and CT_DESC='" + strDesc + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        INCOME_SOURCEID = Convert.ToInt32(dsdd.Tables[0].Rows[0][0]);
        con.Close();
        return INCOME_SOURCEID;
    }
    public void Clear()
    {
        DDLkycName.SelectedIndex = 0;
        ddlCustSource.SelectedIndex = 0;
        txtCustAge.Text = "";
        ddlCustRelation.SelectedIndex = 0;
        txtIncome.Text = "";
        txtIncomeTaken.Text = "";
        txtFactor.Text = "";
    }
    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    DropDownList DDLkycName =
                      (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[1].FindControl("DDLkycName");
                    TextBox txtCustName =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[1].FindControl("txtCustName");
                    DropDownList ddlCustSource =
                     (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[2].FindControl("ddlCustSource");
                    TextBox txtCustAge =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[3].FindControl("txtCustAge");
                    DropDownList ddlCustRelation =
                       (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[4].FindControl("ddlCustRelation");
                    TextBox txtIncome =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[5].FindControl("txtIncome");
                    DropDownList ddlIncomeTaken =
                      (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[6].FindControl("ddlIncomeTaken");
                    DropDownList ddlFactor =
                     (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[7].FindControl("ddlFactor");

                    DDLkycName.SelectedItem.Text = dt.Rows[i]["Col1"].ToString();
                    txtCustName.Text = dt.Rows[i]["Col1"].ToString();
                    ddlCustSource.SelectedItem.Text = dt.Rows[i]["Col2"].ToString();
                    txtCustAge.Text = dt.Rows[i]["Col3"].ToString();
                    ddlCustRelation.SelectedItem.Text = dt.Rows[i]["Col4"].ToString();
                    txtIncome.Text = dt.Rows[i]["Col5"].ToString();
                    ddlIncomeTaken.SelectedItem.Text = dt.Rows[i]["Col6"].ToString();
                    ddlFactor.SelectedItem.Text = dt.Rows[i]["Col7"].ToString();
                    rowIndex++;
                }
            }
        }
    }


    protected void gvIncomeDetail_RowCommand1(object sender, GridViewCommandEventArgs e)
    {
        //DataTable dtTempTable=null;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];

            if (e.CommandName == "Delete")
            {
                btnSubmit.Enabled = false;
                string strVal = e.CommandArgument.ToString();
                DataRow[] dr = dtCurrentTable.Select("NAME <> '" + strVal + "'");
                // DDLkycName.Items.Add(strVal);
                if (dr.Length > 0)
                {
                    dtCurrentTable = dr.CopyToDataTable();


                    ViewState["CurrentTable"] = dtCurrentTable;
                    gvIncomeDetail.DataSource = dtCurrentTable;
                    gvIncomeDetail.DataBind();
                    double dblOldIncome = 0.0;
                    if (dtCurrentTable != null && dtCurrentTable.Rows.Count > 0)
                    {
                        double nTotalLoanEligibility = 0.0;

                        for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                        {

                            double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                            int nAge = dtCurrentTable.Rows[n]["AGE"] != DBNull.Value ? Convert.ToInt32(dtCurrentTable.Rows[n]["AGE"]) : 0;
                            nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;
                            double dblIncome = nTempVal;
                            if (nAge < 60)
                            {
                                if (dblIncome > dblOldIncome)
                                {
                                    txtNameofInsuredPerson.Text = dtCurrentTable.Rows[n]["NAME"] != DBNull.Value ? Convert.ToString(dtCurrentTable.Rows[n]["NAME"]) : "";
                                    dblOldIncome = dblIncome;
                                }
                            }

                        }


                        //bala changes 05112016
                        string strOldname = "", strNewname = "";
                        double Amount = 0.0;
                        int nvalue = 0;
                        DataTable dt1 = new DataTable();
                        dt1.Columns.AddRange(new DataColumn[2] { 
                            new DataColumn("Name", typeof(string)),
                            new DataColumn("Amount", typeof(int)) });
                        //DataTable dtTempData = dtCurrentTable.Select("AGE < 60").CopyToDataTable();
                        DataRow[] drTemp = dtCurrentTable.Select("AGE < 60");
                        if (drTemp.Length > 0)
                        {
                            DataTable dtTempData = drTemp.CopyToDataTable();
                            if (dtTempData != null && dtTempData.Rows.Count > 0)
                            {
                                for (int ncount = 0; ncount < dtTempData.Rows.Count; ncount++)
                                {
                                    strNewname = dtTempData.Rows[ncount]["NAME"] != DBNull.Value ? dtTempData.Rows[ncount]["NAME"].ToString() : "";
                                    Amount = dtTempData.Rows[ncount]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtTempData.Rows[ncount]["FACTORED_INCOME"]) : 0.0;
                                    if (strOldname == "")
                                    {
                                        dt1.Rows.Add(strNewname, Amount);

                                    }
                                    else if (strOldname == strNewname)
                                    {

                                        dt1.Rows[nvalue]["Amount"] = Convert.ToDouble(dt1.Rows[nvalue]["Amount"]) + Amount;
                                    }
                                    else
                                    {
                                        dt1.Rows.Add(strNewname, Amount);
                                        nvalue = nvalue + 1;
                                    }
                                    strOldname = strNewname;
                                }
                            }
                            if (dt1 != null && dt1.Rows.Count > 0)
                            {
                                double dblTempAmount = 0.0;
                                for (int n = 0; n < dt1.Rows.Count; n++)
                                {

                                    double dblAmont = dt1.Rows[n]["Amount"] != DBNull.Value ? Convert.ToDouble(dt1.Rows[n]["Amount"]) : 0.0;
                                    if (dblAmont > dblTempAmount)
                                    {
                                        txtNameofInsuredPerson.Text = dt1.Rows[n]["Name"] != DBNull.Value ? dt1.Rows[n]["Name"].ToString() : "";
                                        dblTempAmount = dblAmont;
                                    }

                                }
                            }
                        }
                        //bala changes end 05112016
                        txtTotalLoanEligibility.Text = nTotalLoanEligibility.ToString();
                        BindBorrower(dtCurrentTable);

                    }

                }
                else
                {
                    FirstGridViewRow();
                    txtTotalLoanEligibility.Text = "";
                    drpName1.Items.Clear();
                    drpName2.Items.Clear();
                    drpName3.Items.Clear();
                    drpName4.Items.Clear();
                    drpName5.Items.Clear();
                    txtFinanciear1.Text = "";
                    txtFinanciear2.Text = "";
                    txtFinanciear3.Text = "";
                    txtFinanciear4.Text = "";
                    txtFinanciear5.Text = "";

                    txtEMIAmount1.Text = "";
                    txtEMIAmount2.Text = "";
                    txtEMIAmount3.Text = "";
                    txtEMIAmount4.Text = "";
                    txtEMIAmount5.Text = "";
                    txtTotalEMIAmount.Text = "";

                }


            }
        }
    }

    protected void gvIncomeDetail_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void gvIncomeDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void ddlLeadNo_SelectedIndexChanged(object sender, EventArgs e)
    {
            if (ddlLeadNo.SelectedIndex > 0)
        {
            BindTenor();
            if (ddlLeadNo.SelectedItem.Text.Contains("ELP"))
            {
                trEmp1.Visible = true;
                trEmp2.Visible = true;
                trEmp3.Visible = true;
            }
            else
            {
                trEmp1.Visible = false;
                trEmp2.Visible = false;
                trEmp3.Visible = false;
            }

            txtCAMDATE.Text = DateTime.Now.ToString("dd/MMM/yyyy");
            DataSet dsLead = fetchLeadDetails(ddlLeadNo.SelectedItem.Text.Trim());
            if (dsLead != null && dsLead.Tables[0].Rows.Count > 0)
            {
                KYC_details();
                KYC_APP_details();
                FetchCam();
                txtLoanAmountRequested.Text = dsLead.Tables[0].Rows[0]["LD_PD_AMT"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_PD_AMT"].ToString() : "";
                txtPDDate.Text = dsLead.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsLead.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
                txtApplnName.Text = dsLead.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                txtContactNo.Text = dsLead.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
                txtMemberID.Text = dsLead.Tables[0].Rows[0]["LD_MID"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_MID"].ToString() : "";
                txtAddress.Text = dsLead.Tables[0].Rows[0]["LD_RADDRESS"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_RADDRESS"].ToString() : "";
                txt_enduse.Text = dsLead.Tables[0].Rows[0]["LD_PD_USE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_PD_USE"].ToString() : "";
                Session["PROPADDR"] = dsLead.Tables[0].Rows[0]["LD_ADDRESS"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_ADDRESS"].ToString() : "";
                string empName = dsLead.Tables[0].Rows[0]["EMP_CODE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["EMP_CODE"].ToString() : "";
                if (empName != "")
                    empName += "-";
                empName += dsLead.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
                string empDesignation = dsLead.Tables[0].Rows[0]["ET_DESC"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["ET_DESC"].ToString() : "";
                if (empName != "" && empDesignation != "")
                    txtEmpDetailes.Text = empName + " " + "(" + empDesignation + ")";
                ddlRelationShip.Focus();
            }
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Age", con);
        cmddd.Parameters.AddWithValue("@KYC_Name", DDLkycName.SelectedIndex != 0 ? DDLkycName.SelectedItem.Text : "");
        cmddd.Parameters.AddWithValue("@KYC_LD_ID", ddlLeadNo.SelectedIndex != 0 ? ddlLeadNo.SelectedValue : "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();

        if (dsdd.Tables[0].Rows.Count > 0)
        {
            txtCustAge.Text = dsdd.Tables[0].Rows[0][0].ToString();
            TBAppType.Text = dsdd.Tables[0].Rows[0][1] != null ? dsdd.Tables[0].Rows[0][1].ToString() : "0";
        }
        if (DDLkycName.SelectedIndex == 0)
        {
            txtCustAge.Text = "";
        }
    }
    public void clear()
    {
        // ddlLeadNo.SelectedIndex = 0;
        txtCAMDATE.Text = "";
        FirstGridViewRow();
    }
    protected void ddlMainApplicant_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindDepndsMainAppln();
    }
    protected void ddlPropType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            RadioBtnGV_No.Checked = false;
            RadioBtnGV_Yes.Checked = false;
            VisibleFalse();
            enable();
            btnSubmit.Enabled = false;
            
            //bala changes 10.11.2016
            if (ddlPropType.SelectedItem.Text == "Vacant plot")
            {
                // ddlOccupancyStatus.SelectedItem.Text = "NA";
                ddlOccupancyStatus.SelectedValue = "4";
                ddlOccupancyStatus.Enabled = false;
                // ddlUsage.SelectedItem.Text = "NA";
                ddlUsage.SelectedValue = "4";
                ddlUsage.Enabled = false;
            }
            else
            {
                BindOccupancy();
                BindUsage();
                ddlOccupancyStatus.Enabled = true;
                ddlUsage.Enabled = true;

            }
            //Bala changes ends 10.11.2016


            ///Mangalore Tiles
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd1 = new SqlCommand("RTS_SP_FETCH_BVSQFT", con);

            if (ddlPropType.SelectedItem.Text != "--Select--" && ddlPropType.SelectedItem.Text == "Mangalore tiled roofing")
            {
                cmddd1.Parameters.AddWithValue("@BA_PTYP", "M");
                if (ddlAgeOfBuilding.SelectedItem.Text != "--Select--")
                {
                    cmddd1.Parameters.AddWithValue("@BA_DESC", ddlAgeOfBuilding.SelectedItem.Text);
                }

            }
            else
            {
                cmddd1.Parameters.AddWithValue("@PT_DESC", ddlPropType.SelectedItem.Text);
                cmddd1.Parameters.AddWithValue("@PT_TYPE", "R");
            }
            cmddd1.CommandType = CommandType.StoredProcedure;
            var sqft = cmddd1.ExecuteScalar();

            con.Close();
            if (sqft != null)
            { lblSqrft.Text = " @ " + sqft + " / Sqft "; }
            else { lblSqrft.Text = ""; }

            ddlPropType.Focus();

            BindBDAge();    /// CR Mangalore Tile roofing

            if (ddlPropType.SelectedItem.Text == "Mangalore tiled roofing")
            {
                txtDepreciation.Enabled = false;
            }
            else
            {
                txtDepreciation.Enabled = true;
            }

            ///Mangalore Tiles
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlCustSource_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtIncome.Text = "";
        txtFactor.Text = "";
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
        cmddd.Parameters.AddWithValue("@CT_ID", "");
        cmddd.Parameters.AddWithValue("@CT_TYPE", "R");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        dtSourceOfIncome = dsdd.Tables[0];
        con.Close();

        if (ddlCustSource.SelectedItem.Text != "--Select--")
        {

            DataRow[] dr = dtSourceOfIncome.Select("CT_DESC='" + ddlCustSource.SelectedItem.Text + "'");

            txtIncomeTaken.Text = dr[0].ItemArray[3].ToString();
        }
    }
    //PMT Calculation
    public static double GetEMI(double presentValue, double financingPeriod, double interestRatePerYear)
    {
        //interestRatePerYear = 26.00;
        //financingPeriod = 60;
        //presentValue = 100000;
        double a, b, x;
        double monthlyPayment;
        a = (1 + interestRatePerYear / 1200);
        b = financingPeriod;
        x = Math.Pow(a, b);
        x = 1 / x;
        x = 1 - x;
        monthlyPayment = (presentValue) * (interestRatePerYear / 1200) / x;
        return (monthlyPayment);
    }
    public void CalculateLoadELigibility()
    {
        try
        {
            string strval = this.txtTotalEMIAmount.Text;
            double presentValue = 100000;
            double financingPeriod = 0.0;
            double interestRatePerYear = 0.0;
            double IIREligibilit = 0.0;
            double FOIREligibility = 0.0;
            double AgriIncome = 0.0;

            double dblNoofCattle = Convert.ToDouble(txtNoofcatlle.Text);
            double dblCattlerate = Convert.ToDouble(hdnCattleRate.Value);
            txtLoanEligibility.Text = Convert.ToString(dblNoofCattle * dblCattlerate);
            //if (txtAgriIncome.Text != "")
            //{
            //    AgriIncome = Convert.ToDouble(txtAgriIncome.Text);
            //}
            //if (ddlTenure.SelectedItem.Text != "")
            //{
            //    financingPeriod = Convert.ToDouble(ddlTenure.SelectedItem.Text) * 12;
            //}
            //if (ddlIntrest.SelectedItem.Text != "--Select--")
            //{
            //    interestRatePerYear = Convert.ToDouble(ddlIntrest.SelectedItem.Text);
            //}
            //txtEMIperLakh.Text = Math.Round(GetEMI(presentValue, financingPeriod, interestRatePerYear)).ToString();
            //IIREligibilit = (((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 40 / 100) / (Convert.ToDouble(txtEMIperLakh.Text != "" ? txtEMIperLakh.Text : "0.0"))) * 100000;
            //FOIREligibility = ((((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 50 / 100) - Convert.ToDouble(txtTotalEMIAmount.Text != "" ? txtTotalEMIAmount.Text : "0.0")) / Convert.ToDouble(txtEMIperLakh.Text != "" ? txtEMIperLakh.Text : "0.0")) * 100000;
            ////FOIREligibility =((Convert.ToDouble(txtTotalLoanEligibility.Text) * 50 / 100)- (Convert.ToDouble(txtTotalEMIAmount.Text))/ (GetEMI(presentValue, financingPeriod, interestRatePerYear))) * 100000;

            ////IIREligibilit = IIREligibilit + AgriIncome;
            ////FOIREligibility = FOIREligibility + AgriIncome;

            //txtIIREligibility.Text = Convert.ToInt32(IIREligibilit).ToString();
            //txtFOIREligibility.Text = Convert.ToInt32(FOIREligibility).ToString();

            //if (IIREligibilit <= FOIREligibility)
            //{
            //    txtLoanEligibility.Text = Convert.ToInt32(IIREligibilit).ToString();

            //}
            //else if (IIREligibilit > FOIREligibility)
            //{
            //    txtLoanEligibility.Text = Convert.ToInt32(FOIREligibility).ToString();
            //}


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtIntestRate_TextChanged(object sender, EventArgs e)
    {


    }
    protected void ddlAgeOfBuilding_SelectedIndexChanged(object sender, EventArgs e)
    {
        visible();
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_BD_AGE", con);
        cmddd.Parameters.AddWithValue("@BA_ID", "");
        ///Mangalore Tiles  
        if (ddlPropType.SelectedItem.Text != "--Select--" && ddlPropType.SelectedItem.Text == "Mangalore tiled roofing")
        {
            cmddd.Parameters.AddWithValue("@BA_PTYP", "M");
        }///Mangalore Tiles
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
       
        DataTable dtAge = dsdd.Tables[0];
        btnSubmit.Enabled = false;
        if (ddlAgeOfBuilding.SelectedItem.Text != "--Select--")
        {
            DataRow[] dr = dtAge.Select("BA_DESC='" + ddlAgeOfBuilding.SelectedItem.Text + "'");

            txtDepreciation.Text = dr[0].ItemArray[2].ToString();

        }
        else
        {
            ddlAgeOfBuilding.Focus();
        }

        ///Mangalore Tiles  
        SqlCommand cmddd1 = new SqlCommand("RTS_SP_FETCH_BVSQFT", con);
        cmddd1.Parameters.AddWithValue("@BA_DESC", ddlAgeOfBuilding.SelectedItem.Text);
        if (ddlPropType.SelectedItem.Text != "--Select--" && ddlPropType.SelectedItem.Text == "Mangalore tiled roofing")
        {
            cmddd1.Parameters.AddWithValue("@BA_PTYP", "M");
        }
        else
        {
            cmddd1.Parameters.AddWithValue("@PT_DESC", ddlPropType.SelectedItem.Text);
            cmddd1.Parameters.AddWithValue("@PT_TYPE", "R");
        }
        cmddd1.CommandType = CommandType.StoredProcedure;
        var sqft = cmddd1.ExecuteScalar();

        con.Close();
        lblSqrft.Text = " @ " + sqft + " / Sqft ";

        double nSqrftVal = 0;
        if (txtBuildUpArea.Text != "" && lblSqrft.Text != "")
        {
            nSqrftVal = Convert.ToDouble(txtBuildUpArea.Text) * Convert.ToDouble(lblSqrft.Text.Substring(2, lblSqrft.Text.IndexOf('/') - 2).Trim());
            txtBuildingValue.Text = Convert.ToInt32(nSqrftVal).ToString();
        }
        ddlAgeOfBuilding.Focus();
        ///Mangalore Tiles
    }
    protected void txtMarketValueSqrt_TextChanged(object sender, EventArgs e)
    {
        visible();
        try
        {
            btnSubmit.Enabled = false;
            double dGuidline = 0.0;
            double dMarketValue = 0.0;
            double dLandArea = 0.0;
            if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "" && txtLandArea.Text != "")
            {
                if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                {
                    dGuidline = 2.5 * Convert.ToDouble(txtGuideline.Text);
                }
                else
                {
                    dGuidline = 2.5 * Convert.ToDouble(txtGuideline.Text);
                }
                dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);
                dLandArea = Convert.ToDouble(txtLandArea.Text);
                if (dGuidline < dMarketValue && dGuidline > 0)
                {
                    txtConsidered.Text = Convert.ToInt32(dGuidline * dLandArea).ToString();
                }
                else if (dGuidline > dMarketValue && dMarketValue > 0)
                {
                    txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                }
                else if (dGuidline == dMarketValue && dGuidline > 0)
                {
                    txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                }
                else
                {
                    if (dGuidline > 0)
                    {
                        txtConsidered.Text = Convert.ToInt32(dGuidline * dLandArea).ToString();
                    }
                    else
                    {
                        txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                    }
                }
            }
            txtBuildUpArea.Focus();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtBuildUpArea_TextChanged(object sender, EventArgs e)
    {
        visible();
        btnSubmit.Enabled = false;
        double nSqrftVal = 0;
        if (txtBuildUpArea.Text != "" && lblSqrft.Text != "")
        {
            nSqrftVal = Convert.ToDouble(txtBuildUpArea.Text) * Convert.ToDouble(lblSqrft.Text.Substring(2, lblSqrft.Text.IndexOf('/') - 2).Trim());
            txtBuildingValue.Text = Convert.ToInt32(nSqrftVal).ToString();
        }
        ddlAgeOfBuilding.Focus();
    }
    public int RoundNum(int num)
    {
        int rem = num % 10;
        return rem >= 5 ? (num - rem + 10) : (num - rem);
    }
    public int RoundDown(int toRound)
    {
        int nValue = 0;

        if (toRound.ToString().Length < 4)
        {
            nValue = toRound - toRound % 10;
        }
        else if (toRound.ToString().Length < 6)
        {
            nValue = toRound - toRound % 100;
        }
        else
        {
            nValue = toRound - toRound % 1000;
        }
        return nValue;
    }

    protected void txtAgriIncome_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        if (ddlIntrest.SelectedItem.Text != "--Select--")
        {
            CalculateLoadELigibility();
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        // InsertCamLapValues();
        //InsertDraftCamLapValues("S");
        if (ddlLeadNo.SelectedItem.Text.Contains("ELP"))
        {
            if (txtEmpCode.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Code');", true);
            else if (txtEMpNAme.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Name');", true);
            else if (txtDesgn.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Designation');", true);
            else if (txtContact.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Contact Number');", true);
            else if (ttxEmailEmp.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Email');", true);
            else if (txtEmpCompany.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Company');", true);
            else if (txtDOJ.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Date Of Joining');", true);
            else if (txtGrade.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Grade');", true);
            else
                InsertDraftCamLapValues("S");
        }
        else
            InsertDraftCamLapValues("S");

        txtDepreciation.Enabled = true;
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("CAM_LAP.aspx");
    }
    protected void InsertCamLapValues()
    {
        try
        {
            if (ddlRelationShip.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Relation ship", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlMainApplicant.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Main Source of Income", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlVintage.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Vintage", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlNature.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Nature Of Bussiness/Job", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlIncomType.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Income Type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //else if (ddlLoanPurpose.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Loan Purpose", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else if (ddlCreditHistory.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Cedit History", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                DataTable dtIncomeDetails = new DataTable();
                dtIncomeDetails = (DataTable)ViewState["CurrentTable"];
                dtIncomeDetails.Columns.Remove("INCOME_SOURCE");
                dtIncomeDetails.Columns.Remove("RELATIONSHIP");
                dtIncomeDetails.Columns.Remove("APP_TYPE");
                DataTable dtObligation = new DataTable();
                dtObligation = BindObligationTable();

                DataTable dtColletral = new DataTable();
                dtColletral = BindCollateralTable();

                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertCAM", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@CAM_TYPE", "B");
                //cmdinsert.Parameters.AddWithValue("@CAM_PR_ID", "1");

                //cmdinsert.Parameters.AddWithValue("@CAM_BR_ID", txtBranchName.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LD_ID", ddlLeadNo.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_AP_ADD", txtAddress.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_ER_ID", ddlRelationShip.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_INS_ID", ddlMainApplicant.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_VN_ID", ddlVintage.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_NT_ID", ddlNature.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_IT_ID", ddlIncomType.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_PP_ID", ddlLoanPurpose.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_CH_ID", ddlCreditHistory.SelectedValue.ToString());

                cmdinsert.Parameters.AddWithValue("@CAM_AGL", txtAgriLandAcres.Text != "" ? Convert.ToDouble(txtAgriLandAcres.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_AGI", txtAgriIncome.Text != "" ? Convert.ToDouble(txtAgriIncome.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_IN", txtTotalLoanEligibility.Text != "" ? Convert.ToDouble(txtTotalLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_EMI", txtTotalEMIAmount.Text != "" ? Convert.ToDouble(txtTotalEMIAmount.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TENURE", ddlTenure.SelectedValue);
                cmdinsert.Parameters.AddWithValue("@CAM_INR", ddlIntrest.SelectedItem.Text != "--Select--" ? Convert.ToDouble(ddlIntrest.SelectedItem.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_EPL", txtEMIperLakh.Text != "" ? Convert.ToDouble(txtEMIperLakh.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_IRR", txtIIREligibility.Text != "" ? Convert.ToDouble(txtIIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_FOIR", txtFOIREligibility.Text != "" ? Convert.ToDouble(txtFOIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LAMT_REQ", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_ELG", txtLoanEligibility.Text != "" ? Convert.ToDouble(txtLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_PT_ID", ddlPropType.SelectedItem.Text.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_OC_ID", ddlOccupancyStatus.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_UG_ID", ddlUsage.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_NOT", txtNoOFtenents.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LAREA", txtLandArea.Text != "" ? Convert.ToDouble(txtLandArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_GLV", txtGuideline.Text != "" ? Convert.ToDouble(txtGuideline.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_MV", txtMarketValueSqrt.Text != "" ? Convert.ToDouble(txtMarketValueSqrt.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CLV", txtConsidered.Text != "" ? Convert.ToDouble(txtConsidered.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BAREA", txtBuildUpArea.Text != "" ? Convert.ToDouble(txtBuildUpArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BV", txtBuildingValue.Text != "" ? Convert.ToDouble(txtBuildingValue.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BA_ID", ddlAgeOfBuilding.SelectedItem.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_DEP", txtDepreciation.Text != "" ? Convert.ToDouble(txtDepreciation.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CBV", txtonsideredBuilding.Text != "" ? Convert.ToDouble(txtonsideredBuilding.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_TPV", txtTotalPropertyValue.Text != "" ? Convert.ToDouble(txtTotalPropertyValue.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_LTV", txtLTVonProperty.Text != "" ? Convert.ToDouble(txtLTVonProperty.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_RLA", txtRecommendedLoan.Text != "" ? Convert.ToDouble(txtRecommendedLoan.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_Deviation", txtDeviation.Text);

                cmdinsert.Parameters.AddWithValue("@CAM_PCS", txtNameofInsuredPerson.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_CBY", Session["ID"].ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_MBY", Session["ID"].ToString());


                cmdinsert.Parameters.AddWithValue("@tblIncome_Details", dtIncomeDetails);
                cmdinsert.Parameters.AddWithValue("@tblOBLIGATE", dtObligation);
                cmdinsert.Parameters.AddWithValue("@tblCOLLATERAL", dtColletral);
                string strReg = "";
                if (RadioBtnGV_No.Checked)
                {
                    strReg = "N";
                }
                else if (RadioBtnGV_Yes.Checked)
                {
                    strReg = "Y";
                }

                cmdinsert.Parameters.AddWithValue("@CAM_Regnet", strReg);


                int n = cmdinsert.ExecuteNonQuery();
                if (n > 0)
                {

                    if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "")
                    {
                        double dGuidline = 0.0;
                        if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                        {
                            dGuidline = 2.5 * Convert.ToDouble(txtGuideline.Text);
                        }
                        else
                        {
                            dGuidline = 2.5 * Convert.ToDouble(txtGuideline.Text);
                        }
                        //if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text) && RadioBtnGV_No.Checked)
                        //{
                        //    sendMail();
                        //}
                        if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text))
                        {
                            sendMail();
                        }
                    }
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Saved Successfully');window.location.reload()", true);
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Failed to Save');", true);
                }

                con.Close();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public DataTable BindObligationTable()
    {
        DataTable dtObligation = new DataTable();
        DataRow drObligation = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string))); -- IR/RL/SEP19/09/556_New Fields Required in RTS CAM Obligation details
        dtObligation.Columns.Add(new DataColumn("CO_TYPE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_FIN", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_TENURE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_LOAN_AMT", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_SOURCE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_BORW", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_AMOUNT", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_BAL_EMI", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_CIBIL", typeof(string)));

        if (txtFinanciear1.Text != "" && drpName1.SelectedItem != null && txtEMIAmount1.Text != "")
        {
            if (drpName1.SelectedItem.Text != "--Select--")
            {

                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear1.Text;
                drObligation["CO_TENURE"] = "";
                drObligation["CO_LOAN_AMT"] = "";
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName1.SelectedItem.Text;

                drObligation["CO_AMOUNT"] = txtEMIAmount1.Text;
                drObligation["CO_BAL_EMI"] = "0";
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }
        }
        if (txtFinanciear2.Text != "" && drpName2.SelectedItem != null && txtEMIAmount2.Text != "")
        {

            if (drpName2.SelectedItem.Text != "--Select--")
            {
                //drObligation = dtObligation.NewRow();
                //drObligation["CO_TYPE"] = "";
                //drObligation["CO_FIN"] = txtFinanciear2.Text;
                //drObligation["CO_BORW"] = drpName2.SelectedItem.Text;
                //drObligation["CO_AMOUNT"] = txtEMIAmount2.Text;

                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear2.Text;
                drObligation["CO_TENURE"] = "";
                drObligation["CO_LOAN_AMT"] = "";
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName2.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount2.Text;
                drObligation["CO_BAL_EMI"] = "0";
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }

        }
        if (txtFinanciear3.Text != "" && drpName3.SelectedItem != null && txtEMIAmount3.Text != "")
        {
            if (drpName3.SelectedItem.Text != "--Select--")
            {
                //drObligation = dtObligation.NewRow();
                //drObligation["CO_TYPE"] = "";
                //drObligation["CO_FIN"] = txtFinanciear3.Text;
                //drObligation["CO_BORW"] = drpName3.SelectedItem.Text;
                //drObligation["CO_AMOUNT"] = txtEMIAmount3.Text;
                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear3.Text;
                drObligation["CO_TENURE"] = "";
                drObligation["CO_LOAN_AMT"] = "";
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName3.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount3.Text;
                drObligation["CO_BAL_EMI"] = "0";
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }

        }
        if (txtFinanciear4.Text != "" && drpName4.SelectedItem != null && txtEMIAmount4.Text != "")
        {
            if (drpName4.SelectedItem.Text != "--Select--")
            {

                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear4.Text;
                drObligation["CO_TENURE"] = "";
                drObligation["CO_LOAN_AMT"] = "";
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName4.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount4.Text;
                drObligation["CO_BAL_EMI"] = "0";
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }
        }
        if (txtFinanciear5.Text != "" && drpName5.SelectedItem != null && txtEMIAmount5.Text != "")
        {
            if (drpName5.SelectedItem.Text != "--Select--")
            {


                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear5.Text;
                drObligation["CO_TENURE"] = "";
                drObligation["CO_LOAN_AMT"] = "";
                drObligation["CO_SOURCE"] = "";
                drObligation["CO_BORW"] = drpName5.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount5.Text;
                drObligation["CO_BAL_EMI"] = "0";
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }
        }
        return dtObligation;
    }

    public DataTable BindCollateralTable()
    {
        DataTable dtCollateral = new DataTable();
        DataRow drCollateral = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));     
        dtCollateral.Columns.Add(new DataColumn("CC_COLAT", typeof(string)));
        dtCollateral.Columns.Add(new DataColumn("CC_AMOUNT", typeof(string)));
        return dtCollateral;
    }
    protected void End_use()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_MR_ENDUSE", con);

            cmddd.CommandType = CommandType.StoredProcedure;
            cmddd.Parameters.AddWithValue("@EU_PRD_TYPE", "L");
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddl_Enduse.DataSource = dsdd;
            ddl_Enduse.DataTextField = "EU_DESC";
            ddl_Enduse.DataValueField = "EU_ID";
            ddl_Enduse.DataBind();
            ddl_Enduse.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void btnCalculate_Click(object sender, EventArgs e)
    {
        visible();
        try
        {
            //if (txtTotalLoanEligibility.Text == "")
            //{
            //    DDLkycName.Focus();
            //    uscMsgBox1.AddMessage("Please Add Income Details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            //}
            if (txtNoofcatlle.Text.ToString() == "")
            {
                uscMsgBox1.AddMessage("Please enter the no of cattle more than or equal to 2.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtNoofcatlle.Focus();
            }
            else

            if (Convert.ToInt32(txtNoofcatlle.Text) < 2)
            {
                uscMsgBox1.AddMessage("Please enter the no of cattle more than or equal to 2.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtNoofcatlle.Focus();
            }
            else
           if (ddlIntrest.SelectedItem.Text == "--Select--")
            {

                uscMsgBox1.AddMessage("Please Give Intrest Rate value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                ddlIntrest.Focus();
            }
            else if (txtLoanAmountRequested.Text == "")
            {
                uscMsgBox1.AddMessage("Please Give Loan Amount Requested value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtLoanAmountRequested.Focus();
            }
            else if (txtBuildingValue.Text == "")
            {
                uscMsgBox1.AddMessage("Please Give Building value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtBuildUpArea.Focus();
            }
            else if (txtDepreciation.Text == "")
            {
                uscMsgBox1.AddMessage("Please Select Age of Building", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                ddlAgeOfBuilding.Focus();
            }
           
          

            else
            {
                if (txtDepreciation.Text != "" && txtBuildingValue.Text != "" && txtLoanAmountRequested.Text != "")
                {
                    CalculateLoadELigibility();
                    double dGuidline = 0.0;
                    double dMarketValue = 0.0;
                    double dLandArea = 0.0;
                    if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "" && txtLandArea.Text != "")
                    {
                        if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                        {
                            dGuidline = 2.5 * Convert.ToDouble(txtGuideline.Text);
                        }
                        else
                        {
                            dGuidline = 2.5 * Convert.ToDouble(txtGuideline.Text);
                        }
                        dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);
                        dLandArea = Convert.ToDouble(txtLandArea.Text);
                        if (dGuidline < dMarketValue && dGuidline > 0)
                        {
                            txtConsidered.Text = Convert.ToInt32(dGuidline * dLandArea).ToString();
                        }
                        else if (dGuidline > dMarketValue && dMarketValue > 0)
                        {
                            txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                        }
                        else if (dGuidline == dMarketValue && dGuidline > 0)
                        {
                            txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                        }
                        else
                        {
                            if (dGuidline > 0)
                            {
                                txtConsidered.Text = Convert.ToInt32(dGuidline * dLandArea).ToString();
                            }
                            else
                            {
                                txtConsidered.Text = Convert.ToInt32(dMarketValue * dLandArea).ToString();
                            }
                        }
                    }

                    double nVal = 100 - Convert.ToDouble(txtDepreciation.Text);
                    txtonsideredBuilding.Text = Convert.ToString(Convert.ToDouble(txtBuildingValue.Text) * (nVal / 100));
                    if (txtConsidered.Text != "")
                    {
                        if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                        {
                            txtTotalPropertyValue.Text = Convert.ToDouble(txtConsidered.Text).ToString();
                        }
                        else
                        {
                            txtTotalPropertyValue.Text = Convert.ToString(Convert.ToDouble(txtonsideredBuilding.Text) + Convert.ToDouble(txtConsidered.Text));
                        }

                        // txtLTVonProperty.Text = Convert.ToString(Convert.ToDouble(txtTotalPropertyValue.Text) * 50 / 100);
                        if (ddlPropType.SelectedItem.Text == "Vacant plot")
                        {
                            txtLTVonProperty.Text = Convert.ToString(Convert.ToDouble(txtTotalPropertyValue.Text) * 50 / 100);
                        }
                        else
                        {
                            txtLTVonProperty.Text = Convert.ToString(Convert.ToDouble(txtTotalPropertyValue.Text) * 60 / 100);
                        }
                        double nMinVal = 0;
                        if (txtLoanAmountRequested.Text != "" && txtLoanEligibility.Text != "")
                        {
                            nMinVal = Math.Min(Convert.ToDouble(txtLoanAmountRequested.Text), Convert.ToDouble(txtLoanEligibility.Text));
                            nMinVal = Math.Min(Convert.ToDouble(nMinVal), Convert.ToDouble(txtLTVonProperty.Text));
                            int nAmount = Convert.ToInt32(Math.Round(nMinVal));
                            txtRecommendedLoan.Text = Convert.ToString(RoundDown(nAmount));
                            if (txtRecommendedLoan.Text != "")
                            {
                                btnSubmit.Enabled = true;
                            }
                        }

                    }
                    txtNameofInsuredPerson.Focus();
                }
                //  btnSubmit.Enabled = false;
            }
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
            cmddd.Parameters.AddWithValue("@CT_ID", "");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            dtSourceOfIncome = dsdd.Tables[0];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtLoanAmountRequested_TextChanged(object sender, EventArgs e)
    {
        visible();
        btnSubmit.Enabled = false;
    }
    public void KYC_details()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_KYC", con);
        cmddd.Parameters.AddWithValue("@LD_ID", ddlLeadNo.SelectedValue.ToString().Trim());
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        DDLkycName.DataSource = dsdd;
        DDLkycName.DataTextField = "KYC_NAME";
        DDLkycName.DataValueField = "KYC_ID";
        DDLkycName.DataBind();
        DDLkycName.Items.Insert(0, new ListItem("--Select--", "0"));
        TBAppType.Text = "";
    }
    public void KYC_APP_details()
    {
        try
        {
            DataSet ds = new DataSet();
            ds = clscommon.Bind_MR_KYC_APP_DETAILS(ddlLeadNo.SelectedValue != "--Select--" ? Convert.ToString(ddlLeadNo.SelectedValue).Trim() : "0");
            ddlNomineeName.DataSource = ds;
            ddlNomineeName.DataTextField = "KYC_NAME";
            ddlNomineeName.DataValueField = "APP_DESC";
            ddlNomineeName.DataBind();
            ddlNomineeName.Items.Add(new ListItem("Others", "Others"));
            ddlNomineeName.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlIntrest_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        if (ddlIntrest.SelectedItem.Text == "--Select--")
        {

            uscMsgBox1.AddMessage("Please Give Intrest Rate value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            ddlIntrest.Focus();
        }
        else if (txtNoofcatlle.Text.Trim() == "")
        {

            uscMsgBox1.AddMessage("Please Give Number of Cattle value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            ddlIntrest.Focus();
        }
        else
        {
            CalculateLoadELigibility();
           
        }
    }

    public void sendMail()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {

            area = Session["AREANAME"].ToString();
            brnch = txtBranchName.Text;
            ldno = ddlLeadNo.SelectedItem.Text;

            apname = txtApplnName.Text;
            apmobile = txtContactNo.Text;
            gv = Convert.ToDouble(txtGuideline.Text).ToString("F");
            landarea = Convert.ToDouble(txtLandArea.Text.Trim()).ToString("F");




            con.Open();
            /////// mail ///////////
            //  strMailDetail = "";

            SqlCommand cmddet = new SqlCommand("select * from MR_BRANCH where BR_NAME='" + Session["UNITNAME"].ToString() + "'", con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);




            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT * FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);

            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_RPA"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_RPA"].ToString() : "rts-helpdesk@equitasbank.com";
                //cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                //bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                //bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
            }

            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            fromID = "VF-ITSupport<VF-ITSupport@equitasbank.com>";
            toID = to;//"ManimaranK@equitasbank.com";
            //bcc2ID = "shankarg@equitasbank.com";
            //ccID = "rts-helpdesk@equitasbank.com";

            // toID = "shankarg@equitasbank.com";
            // To Auto mail ///////
            System.Threading.Thread threadSendMails;




         /*   threadSendMails = new System.Threading.Thread(delegate()
            {*/

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear TRM,<br/><br/> Please find the request for Risk Property Assessment of market value. <br/><br/>";
                BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='16%'><b>Lead No.</b></td><td style='whiteSpace:nowrap;' width='16%'>" + ldno + "</td>";
                BodyTxt = BodyTxt + "<td width='16%'><b>Area Name</b></td><td width='16%'>" + area + "</td>";
                BodyTxt = BodyTxt + "<td width='16%'><b>Branch Name</b></td><td width='16%'>" + brnch + "</td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='16%'><b>Product</b></td><td> LAP </td>";
                BodyTxt = BodyTxt + "<td width='16%'><b>Applicant Name</b></td><td width='16%'>" + apname + "</td><td width='16%'><b>Applicant Mobile No.</b></td><td width='16%'> " + apmobile + "</td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td  width='16%'><b>Property Address</b></td><td  width='16%'>" + Session["PROPADDR"].ToString().Trim() + "</td>";
                BodyTxt = BodyTxt + "<td  width='16%'><b>Guideline Value (Rate/sqft)</b></td><td  width='16%'>Rs." + gv + "</td  width='16%'><td><b>Land Area (sqft)</b></td><td  width='16%'> " + landarea + "</td></tr></table><br/>";

                BodyTxt = BodyTxt + "<br/>Please initiate and submit the report as per the prescribed TAT. <br/><br/><br/>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'>Thanks and Regards,<br/>Risk Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";

                blMailStatus = EmailManager.sendemailRPA(toID, "VF-ITSupport<VF-ITSupport@equitasbank.com>", "", "", "RPA Initiated for LEAD NO: " + ddlLeadNo.SelectedItem.Text + " " + txtBranchName.Text + " Branch", BodyTxt, "", true);


           /* });

            threadSendMails.IsBackground = true;

            threadSendMails.Start();
            System.Threading.Thread.Sleep(5000);
*/
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally { con.Close(); }
    }

   
    private void visible()
    {
        row1.Visible = true;
        row2.Visible = true;
        row3.Visible = true;
        row4.Visible = true;
        row5.Visible = true;
        row6.Visible = true;
        row7.Visible = true;
        row8.Visible = true;
        trRow9.Visible = true;
        row11.Visible = true;
    }

    private void enable()
    {
        txtLandArea.Text = "";
        txtGuideline.Text = "0";
        txtMarketValueSqrt.Text = "0";
        txtConsidered.Text = "";
        txtBuildUpArea.Text = "";
        txtBuildingValue.Text = "";
        ddlAgeOfBuilding.SelectedIndex = 0;
        txtDepreciation.Text = "";
        txtonsideredBuilding.Text = "";
        txtTotalPropertyValue.Text = "";
        txtLTVonProperty.Text = "";
        txtRecommendedLoan.Text = "";
        //  txtNameofInsuredPerson.Text = "";
        txtDeviation.Text = "";
    }

    protected void RadioBtnGV_Yes_CheckedChanged(object sender, EventArgs e)
    {
        visible();
        enable();
        txtGuideline.Text = "0";
        txtMarketValueSqrt.Text = "0";
        if (ddlPropType.SelectedItem.Text == "Self-occupied residence with RCC roofing" || ddlPropType.SelectedItem.Text == "Self-occupied commercial with RCC roofing" || ddlPropType.SelectedItem.Text == "Let out & RCC roofing")
        {
            txtGuideline.Enabled = true;
            txtMarketValueSqrt.Enabled = true;
        }
        else if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
        {
            txtGuideline.Enabled = true;
            txtMarketValueSqrt.Enabled = true;
        }
    }

    protected void RadioBtnGV_No_CheckedChanged(object sender, EventArgs e)
    {
        visible();
        enable();
        txtGuideline.Text = "0";
        txtMarketValueSqrt.Text = "0";

        if (ddlPropType.SelectedItem.Text == "Self-occupied residence with RCC roofing" || ddlPropType.SelectedItem.Text == "Self-occupied commercial with RCC roofing" || ddlPropType.SelectedItem.Text == "Let out & RCC roofing")
        {
            txtGuideline.Enabled = false;
            txtMarketValueSqrt.Enabled = true;

        }
        else if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
        {
            txtGuideline.Enabled = false;
            txtMarketValueSqrt.Enabled = true;
        }
    }

    protected void txtGuideline_Load(object sender, EventArgs e)
    {
        double dGuidline = 0.0;
        if (txtGuideline.Text != "" && txtMarketValueSqrt.Text == "0" && txtGuideline.Text != "0")
        {
            visible();

            if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
            {
                dGuidline = 2.5 * Convert.ToDouble(txtGuideline.Text);
            }
            else
            {
                dGuidline = 2.5 * Convert.ToDouble(txtGuideline.Text);
            }

            double dblCRate = Convert.ToDouble(txtLandArea.Text) * dGuidline;
            txtConsidered.Text = dblCRate.ToString();
        }
    }
    protected void btnDraft_Click(object sender, EventArgs e)
    {
        InsertDraftCamLapValues("D");
    }
    protected void InsertDraftCamLapValues(string strType)
    {
        try
        {
            if (ddlLeadNo.SelectedItem.Text == "--Select--")
            {
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select Lead No ');", true);
            }
            if (ddl_Enduse.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please select the end use", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                ddl_Enduse.Focus();
            }
            else
                if (txtNoofcatlle.Text.ToString() == "")
                {
                    uscMsgBox1.AddMessage("Please enter the no of cattle more than or equal to 2.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtNoofcatlle.Focus();
                }
                else

                    if (Convert.ToInt32(txtNoofcatlle.Text) < 2)
                    {
                        uscMsgBox1.AddMessage("Please enter the no of cattle more than or equal to 2.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        txtNoofcatlle.Focus();
                    }
                    else
                        if (ddlNomineeName.SelectedItem.Text == "--Select--")
                        {
                            uscMsgBox1.AddMessage("Please select the nominee name", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        }
                        else
                            if (ddlNomineeName.SelectedItem.Text == "Others" && string.IsNullOrWhiteSpace(txtNomineeName.Text))
                            {
                                uscMsgBox1.AddMessage("Please enter the nominee name", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            }
                            else
                                if (ddlNomineeName.SelectedItem.Text == "Others" && string.IsNullOrWhiteSpace(txtNomineeRelation.Text))
                                {
                                    uscMsgBox1.AddMessage("Please enter the nominee relation", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                                }
                                else
                                    if (ddlNomineeName.SelectedItem.Text != "Others" && string.IsNullOrWhiteSpace(txtRelationShip.Text))
                                    {
                                        uscMsgBox1.AddMessage("Please enter the nominee relationship type", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                                    }
            else
            {

                DataTable dtIncomeDetails = new DataTable();
                dtIncomeDetails = (DataTable)ViewState["CurrentTable"];
                if (dtIncomeDetails.Columns.Contains("INCOME_SOURCE"))
                {
                    dtIncomeDetails.Columns.Remove("INCOME_SOURCE");
                }
                if (dtIncomeDetails.Columns.Contains("RELATIONSHIP"))
                {
                    dtIncomeDetails.Columns.Remove("RELATIONSHIP");
                }
                if (dtIncomeDetails.Columns.Contains("APP_TYPE"))
                {
                    dtIncomeDetails.Columns.Remove("APP_TYPE");
                }
                DataTable dtObligation = new DataTable();
                dtObligation = BindObligationTable();

                DataTable dtColletral = new DataTable();
                dtColletral = BindCollateralTable();

                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertCAM_New", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@CAM_TYPE", "B");
                //cmdinsert.Parameters.AddWithValue("@CAM_PR_ID", "1");

                //cmdinsert.Parameters.AddWithValue("@CAM_BR_ID", txtBranchName.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LD_ID", ddlLeadNo.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_AP_ADD", txtAddress.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_ER_ID", ddlRelationShip.SelectedItem.Text != "--Select--" ? ddlRelationShip.SelectedValue.ToString() : (object)DBNull.Value);
                cmdinsert.Parameters.AddWithValue("@CAM_INS_ID", ddlMainApplicant.SelectedItem.Text != "--Select--" ? ddlMainApplicant.SelectedValue.ToString() : (object)DBNull.Value);
            //    cmdinsert.Parameters.AddWithValue("@CAM_VN_ID", ddlVintage.SelectedItem.Text != "--Select--" ? ddlVintage.SelectedValue.ToString() : (object)DBNull.Value);
                cmdinsert.Parameters.AddWithValue("@CAM_NT_ID", ddlNature.SelectedItem.Text != "--Select--" ? ddlNature.SelectedValue.ToString() : (object)DBNull.Value);
                cmdinsert.Parameters.AddWithValue("@CAM_IT_ID", ddlIncomType.SelectedItem.Text != "--Select--" ? ddlIncomType.SelectedValue.ToString() : (object)DBNull.Value);
                cmdinsert.Parameters.AddWithValue("@CAM_PP_ID", ddlLoanPurpose.SelectedItem.Text != "--Select--" ? ddlLoanPurpose.SelectedValue.ToString() : (object)DBNull.Value);
                cmdinsert.Parameters.AddWithValue("@CAM_CH_ID", ddlCreditHistory.SelectedItem.Text != "--Select--" ? ddlCreditHistory.SelectedValue.ToString() : (object)DBNull.Value);

                cmdinsert.Parameters.AddWithValue("@CAM_AGL", txtAgriLandAcres.Text != "" ? Convert.ToDouble(txtAgriLandAcres.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_AGI", txtAgriIncome.Text != "" ? Convert.ToDouble(txtAgriIncome.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_IN", txtTotalLoanEligibility.Text != "" ? Convert.ToDouble(txtTotalLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_EMI", txtTotalEMIAmount.Text != "" ? Convert.ToDouble(txtTotalEMIAmount.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TENURE", ddlTenure.SelectedItem.Text != "--Select--" ? ddlTenure.SelectedValue : "0");
                cmdinsert.Parameters.AddWithValue("@CAM_INR", ddlIntrest.SelectedItem.Text != "--Select--" ? Convert.ToDouble(ddlIntrest.SelectedItem.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_EPL", txtEMIperLakh.Text != "" ? Convert.ToDouble(txtEMIperLakh.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_IRR", txtIIREligibility.Text != "" ? Convert.ToDouble(txtIIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_FOIR", txtFOIREligibility.Text != "" ? Convert.ToDouble(txtFOIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LAMT_REQ", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_ELG", txtLoanEligibility.Text != "" ? Convert.ToDouble(txtLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_PT_ID", ddlPropType.SelectedItem.Text != "--Select--" ? ddlPropType.SelectedItem.Text.ToString() : (object)DBNull.Value);
                cmdinsert.Parameters.AddWithValue("@CAM_OC_ID", ddlOccupancyStatus.SelectedItem.Text != "--Select--" ? ddlOccupancyStatus.SelectedValue.ToString() : (object)DBNull.Value);
                cmdinsert.Parameters.AddWithValue("@CAM_UG_ID", ddlUsage.SelectedItem.Text != "--Select--" ? ddlUsage.SelectedValue.ToString() : (object)DBNull.Value);
                cmdinsert.Parameters.AddWithValue("@CAM_NOT", txtNoOFtenents.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LAREA", txtLandArea.Text != "" ? Convert.ToDouble(txtLandArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_GLV", txtGuideline.Text != "" ? Convert.ToDouble(txtGuideline.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_MV", txtMarketValueSqrt.Text != "" ? Convert.ToDouble(txtMarketValueSqrt.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CLV", txtConsidered.Text != "" ? Convert.ToDouble(txtConsidered.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BAREA", txtBuildUpArea.Text != "" ? Convert.ToDouble(txtBuildUpArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BV", txtBuildingValue.Text != "" ? Convert.ToDouble(txtBuildingValue.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BA_ID", ddlAgeOfBuilding.SelectedItem.Text != "--Select--" ? ddlAgeOfBuilding.SelectedItem.Text : (object)DBNull.Value);



                cmdinsert.Parameters.AddWithValue("@CAM_DEP", txtDepreciation.Text != "" ? Convert.ToDouble(txtDepreciation.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CBV", txtonsideredBuilding.Text != "" ? Convert.ToDouble(txtonsideredBuilding.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_TPV", txtTotalPropertyValue.Text != "" ? Convert.ToDouble(txtTotalPropertyValue.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_LTV", txtLTVonProperty.Text != "" ? Convert.ToDouble(txtLTVonProperty.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_RLA", txtRecommendedLoan.Text != "" ? Convert.ToDouble(txtRecommendedLoan.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_EMP_ID", txtEmpCode.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_Deviation", txtDeviation.Text);

                cmdinsert.Parameters.AddWithValue("@CAM_NO_CATRATE", txtNoofcatlle.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_PCS", txtNameofInsuredPerson.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_CBY", Session["ID"].ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_MBY", Session["ID"].ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_EUSE_ID", ddl_Enduse.SelectedItem.Text != "--Select--" ? Convert.ToInt32(ddl_Enduse.SelectedValue) : (object)DBNull.Value);
                if (dtIncomeDetails.Rows.Count > 0)
                {
                    if (dtIncomeDetails.Rows[0][0].ToString() == "")
                    {
                        dtIncomeDetails.Rows.RemoveAt(0);
                    }
                }

                cmdinsert.Parameters.AddWithValue("@tblIncome_Details", dtIncomeDetails);
                cmdinsert.Parameters.AddWithValue("@tblOBLIGATE", dtObligation);
                cmdinsert.Parameters.AddWithValue("@tblCOLLATERAL", dtColletral);
                string strReg = "";
                if (RadioBtnGV_No.Checked)
                {
                    strReg = "N";
                }
                else if (RadioBtnGV_Yes.Checked)
                {
                    strReg = "Y";
                }
                cmdinsert.Parameters.AddWithValue("@CAM_Regnet", strReg);
                cmdinsert.Parameters.AddWithValue("@CAM_NOMEE_NAME", ddlNomineeName.SelectedItem.Text != "Others" ? ddlNomineeName.SelectedItem.Text : ("Others-" + txtNomineeName.Text).ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_NOMEE_RELN", txtNomineeRelation.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_NOMEE_RELN_TYPE", txtRelationShip.Text);
                cmdinsert.Parameters.AddWithValue("@SAVETYPE", strType);

                int n = cmdinsert.ExecuteNonQuery();
                if (n > 0)
                {


                    if (strType == "S")
                    {
                        if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "")
                        {
                            double dGuidline = 0.0;
                            if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                            {
                                dGuidline = 2.5 * Convert.ToDouble(txtGuideline.Text);
                            }
                            else
                            {
                                dGuidline = 2.5 * Convert.ToDouble(txtGuideline.Text);
                            }
                            //if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text) && RadioBtnGV_No.Checked)
                            //{
                            //    sendMail();
                            //}
                            if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text))
                            {
                                sendMail();
                            }
                        }
                    }

                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Saved Successfully');window.location.reload()", true);
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Failed to Save');", true);
                }

                con.Close();
            }



        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void BindDepndsMainAppln()
    {
        if (ddlMainApplicant.SelectedIndex > 0)
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);

            cmddd.Parameters.AddWithValue("@VN_ID", "");
            cmddd.Parameters.AddWithValue("@VN_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlVintage.DataSource = dsdd;
            ddlVintage.DataTextField = "VN_DESC";
            ddlVintage.DataValueField = "VN_ID";
            ddlVintage.DataBind();
            ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));



            ddlNature.Items.Clear();
            con = new SqlConnection(strcon);
            con.Open();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_NATURE", con);
            cmddd.Parameters.AddWithValue("@NT_ID", "");
            cmddd.Parameters.AddWithValue("@NT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlNature.DataSource = dsdd;
            ddlNature.DataTextField = "NT_DESC";
            ddlNature.DataValueField = "NT_ID";
            ddlNature.DataBind();
            ddlNature.Items.Insert(0, new ListItem("--Select--", "0"));


            ddlIncomType.Items.Clear();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_INCOME_TYPE", con);
            cmddd.Parameters.AddWithValue("@IT_ID", "");
            //cmddd.Parameters.AddWithValue("@IT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.Parameters.AddWithValue("@IT_INS_ID", "");
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlIncomType.DataSource = dsdd;
            ddlIncomType.DataTextField = "IT_DESC";
            ddlIncomType.DataValueField = "IT_ID";
            ddlIncomType.DataBind();
            ddlIncomType.Items.Insert(0, new ListItem("--Select--", "0"));

            con.Close();
        }
    }
    public void FetchCam()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_To_Update", con);
        cmddd.Parameters.AddWithValue("@Lead_ID", ddlLeadNo.SelectedValue.ToString());
        cmddd.Parameters.AddWithValue("@CamType", "B");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        

        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            //// Search creteria
            txtBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
          
            //txtLeadNo.Text = dsdd.Tables[0].Rows[0]["LD_NO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_NO"].ToString() : "";
            txtPDDate.Text = dsdd.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
            txtCAMDATE.Text = dsdd.Tables[0].Rows[0]["CAM_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["CAM_DATE"]).ToString("dd/MMM/yyyy") : DateTime.Now.ToString("dd/MMM/yyyy");
            ddlRelationShip.SelectedValue = dsdd.Tables[0].Rows[0]["ER_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ER_ID"].ToString() : "0";
            ddlMainApplicant.SelectedValue = dsdd.Tables[0].Rows[0]["INS_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["INS_ID"].ToString() : "0";
            txtNoofcatlle.Text = dsdd.Tables[0].Rows[0]["CAM_NO_CATRATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NO_CATRATE"].ToString() : "";
            BindDepndsMainAppln();
            ddlVintage.SelectedValue = dsdd.Tables[0].Rows[0]["VN_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["VN_ID"].ToString() : "0";
            ddlNature.SelectedValue = dsdd.Tables[0].Rows[0]["NT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["NT_ID"].ToString() : "0";
            ddlIncomType.SelectedValue = dsdd.Tables[0].Rows[0]["IT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["IT_ID"].ToString() : "0";
           
            
            //ddlLoanPurpose.SelectedValue = dsdd.Tables[0].Rows[0]["PP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PP_ID"].ToString() : "0";
            ddlCreditHistory.SelectedValue = dsdd.Tables[0].Rows[0]["CH_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_ID"].ToString() : "0";
            txtApplnName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
            txtAddress.Text = dsdd.Tables[0].Rows[0]["CAM_AP_ADD"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AP_ADD"].ToString() : "";
            txtContactNo.Text = dsdd.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
            txtMemberID.Text = dsdd.Tables[0].Rows[0]["LD_MID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_MID"].ToString() : "";
            //   BindTenor();
            ddlTenure.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_TENURE"] != DBNull.Value ? Convert.ToInt32(dsdd.Tables[0].Rows[0]["CAM_TENURE"]).ToString() : "0";
            ddlIntrest.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_INR"] != DBNull.Value ? Convert.ToInt32(dsdd.Tables[0].Rows[0]["CAM_INR"]).ToString() : "0";
            txtEMIperLakh.Text = dsdd.Tables[0].Rows[0]["CAM_EPL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EPL"].ToString() : "";
            txtIIREligibility.Text = dsdd.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_IIR"].ToString() : "";
            txtFOIREligibility.Text = dsdd.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "";
            txtLoanAmountRequested.Text = dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"].ToString() : "";
            txtLoanEligibility.Text = dsdd.Tables[0].Rows[0]["CAM_LN_ELG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LN_ELG"].ToString() : "";

            txtTotalLoanEligibility.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";

            ddlPropType.SelectedValue = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "";
            ddl_Enduse.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_EUSE_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EUSE_ID"].ToString() : "0";

            RadioBtnGV_No.Checked = false;
            RadioBtnGV_Yes.Checked = false;
            VisibleFalse();
            enable();
            btnSubmit.Enabled = false;

           
            ddlOccupancyStatus.SelectedValue = dsdd.Tables[0].Rows[0]["OC_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["OC_ID"].ToString() : "0";
            ddlUsage.SelectedValue = dsdd.Tables[0].Rows[0]["UG_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["UG_ID"].ToString() : "0";
            txtNoOFtenents.Text = dsdd.Tables[0].Rows[0]["CAM_NOT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOT"].ToString() : "";

            string strCamReg = dsdd.Tables[0].Rows[0]["CAM_REGNET"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_REGNET"].ToString() : "";
            if (strCamReg == "Y")
            {
                RadioBtnGV_Yes.Checked = true;
                visible();
                enable();
                txtGuideline.Text = "0";
                txtMarketValueSqrt.Text = "0";
                if (ddlPropType.SelectedItem.Text == "Self-occupied residence with RCC roofing" || ddlPropType.SelectedItem.Text == "Self-occupied commercial with RCC roofing" || ddlPropType.SelectedItem.Text == "Let out & RCC roofing")
                {
                    txtGuideline.Enabled = true;
                    txtMarketValueSqrt.Enabled = true;
                }
                else if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                {
                    txtGuideline.Enabled = true;
                    txtMarketValueSqrt.Enabled = true;
                }
            }
            else if (strCamReg == "N")
            {
                RadioBtnGV_No.Checked = true;
                visible();
                enable();
                txtGuideline.Text = "0";
                txtMarketValueSqrt.Text = "0";

                if (ddlPropType.SelectedItem.Text == "Self-occupied residence with RCC roofing" || ddlPropType.SelectedItem.Text == "Self-occupied commercial with RCC roofing" || ddlPropType.SelectedItem.Text == "Let out & RCC roofing")
                {
                    txtGuideline.Enabled = false;
                    txtMarketValueSqrt.Enabled = true;

                }
                else if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                {
                    txtGuideline.Enabled = false;
                    txtMarketValueSqrt.Enabled = true;
                }
            }

            ///Mangalore Tiles 
            BindBDAge();
            ///Mangalore Tiles 
            ///
            txtLandArea.Text = dsdd.Tables[0].Rows[0]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAREA"].ToString() : "";
            txtGuideline.Text = dsdd.Tables[0].Rows[0]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_GLV"].ToString() : "";
            txtMarketValueSqrt.Text = dsdd.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
            txtConsidered.Text = dsdd.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CLV"].ToString() : "";
            txtBuildUpArea.Text = dsdd.Tables[0].Rows[0]["CAM_BAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BAREA"].ToString() : "";
            txtBuildingValue.Text = dsdd.Tables[0].Rows[0]["CAM_BV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BV"].ToString() : "";
            ddlAgeOfBuilding.SelectedValue = dsdd.Tables[0].Rows[0]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BA_DESC"].ToString() : "0";
            txtDepreciation.Text = dsdd.Tables[0].Rows[0]["CAM_DEP"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_DEP"].ToString() : "";
            txtonsideredBuilding.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
            txtTotalPropertyValue.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
            txtLTVonProperty.Text = dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
            txtRecommendedLoan.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
            txtNameofInsuredPerson.Text = dsdd.Tables[0].Rows[0]["CAM_PCS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_PCS"].ToString() : "";

            txtAgriLandAcres.Text = dsdd.Tables[0].Rows[0]["CAM_AGL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGL"].ToString() : "";
            txtAgriIncome.Text = dsdd.Tables[0].Rows[0]["CAM_AGI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGI"].ToString() : "";

            txtDeviation.Text = dsdd.Tables[0].Rows[0]["CAM_DEVIATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_DEVIATE"].ToString() : "";
            if (dsdd.Tables[1] != null && dsdd.Tables[1].Rows.Count > 0)
            {
                gvIncomeDetail.DataSource = dsdd.Tables[1];
                gvIncomeDetail.DataBind();
                BindBorrower(dsdd.Tables[1]);
                ViewState["CurrentTable"] = dsdd.Tables[1];
                for (int n = 0; n < dsdd.Tables[1].Rows.Count; n++)
                {
                    string strText = dsdd.Tables[1].Rows[n]["NAME"].ToString();
                    int nIndex = DDLkycName.Items.IndexOf(DDLkycName.Items.FindByText(strText));
                    //  DDLkycName.Items.RemoveAt(nIndex);
                }

                //   DDLkycName.DataBind();
            }

            ///Mangalore Tiles  
            SqlCommand cmddd1 = new SqlCommand("RTS_SP_FETCH_BVSQFT", con);
            cmddd1.Parameters.AddWithValue("@BA_DESC", ddlAgeOfBuilding.SelectedItem.Text);
            if (ddlPropType.SelectedItem.Text != "--Select--" && ddlPropType.SelectedItem.Text == "Mangalore tiled roofing")
            {
                cmddd1.Parameters.AddWithValue("@BA_PTYP", "M");
            }
            else
            {
                cmddd1.Parameters.AddWithValue("@PT_DESC", ddlPropType.SelectedItem.Text);
                cmddd1.Parameters.AddWithValue("@PT_TYPE", "R");
            }
            cmddd1.CommandType = CommandType.StoredProcedure;
            var sqft = cmddd1.ExecuteScalar();

            con.Close();
            lblSqrft.Text = " @ " + sqft + " / Sqft ";
            ddlPropType.Focus();
            ///Mangalore Tiles

            if (dsdd.Tables[2] != null && dsdd.Tables[2].Rows.Count > 0)
            {
                for (int i = 0; i < dsdd.Tables[2].Rows.Count; i++)
                {
                    switch (i)
                    {
                        case 0:
                            txtFinanciear1.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                            drpName1.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                            txtEMIAmount1.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                            break;
                        case 1:
                            txtFinanciear2.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                            drpName2.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                            txtEMIAmount2.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                            break;
                        case 2:
                            txtFinanciear3.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                            drpName3.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                            txtEMIAmount3.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                            break;
                        case 3:
                            txtFinanciear4.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                            drpName4.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                            txtEMIAmount4.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                            break;
                        case 4:
                            txtFinanciear4.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                            drpName5.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                            txtEMIAmount5.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                            break;
                    }
                }
            }

            txtTotalEMIAmount.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";
            txtEmpCode.Text = dsdd.Tables[0].Rows[0]["CAM_EMP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EMP_ID"].ToString() : "";

            if (dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"] != DBNull.Value)
            {
                if (Convert.ToString(dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"]).StartsWith("Others") == true)
                {
                    tdNomineeName.Visible = true;
                    tdNomineeName1.Visible = true;
                    string[] strOthers = Convert.ToString(dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"]).Split('-');
                    // ddlNomineeName.SelectedItem.Text = strOthers[0].ToString();
                    ddlNomineeName.Items.FindByText(strOthers[0].ToString()).Selected = true;
                    txtNomineeName.Text = strOthers[1].ToString();

                    txtNomineeName.Enabled = true;
                    //Bala changes 05042018
                    tdRelationType.Visible = false;
                    tdRelationType1.Visible = false;
                    txtNomineeRelation.Enabled = true;
                }
                else
                {
                    tdNomineeName.Visible = false;
                    tdNomineeName1.Visible = false;
                    //Bala changes 05042018
                    tdRelationType.Visible = true;
                    tdRelationType1.Visible = true;
                    // ddlNomineeName.SelectedItem.Text = dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"].ToString() : "0";
                    ddlNomineeName.Items.FindByText(dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOMEE_NAME"].ToString() : "0").Selected = true;


                }
            }

            txtNomineeRelation.Text = dsdd.Tables[0].Rows[0]["CAM_NOMEE_RELN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOMEE_RELN"].ToString() : "";
            txtRelationShip.Text = dsdd.Tables[0].Rows[0]["CAM_NOMEE_RELN_TYPE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOMEE_RELN_TYPE"].ToString() : "";


            BindEMpDets();




        }
        con.Close();
    }
    protected void txtEmpCode_TextChanged(object sender, EventArgs e)
    {
        BindEMpDets();
    }
    protected void BindEMpDets()
    {

        if (txtEmpCode.Text.Length == 4)
        {
            txtEmpCode.Text = "0" + txtEmpCode.Text;
        }
        else if (txtEmpCode.Text.Length == 4)
        {
            txtEmpCode.Text = "00" + txtEmpCode.Text;
        }
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("SELECT * from HR_EMP_DETS  WHERE EMP_CODE='" + txtEmpCode.Text + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            txtEMpID.Text = dsdd.Tables[0].Rows[0]["EMP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_ID"].ToString() : "";
            txtEMpNAme.Text = dsdd.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
            txtDesgn.Text = dsdd.Tables[0].Rows[0]["EMP_DESIGN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_DESIGN"].ToString() : "";
            txtContact.Text = dsdd.Tables[0].Rows[0]["EMP_PHNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_PHNO"].ToString() : "";

            ttxEmailEmp.Text = dsdd.Tables[0].Rows[0]["EMP_EMAIL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_EMAIL"].ToString() : "";
            txtEmpCompany.Text = dsdd.Tables[0].Rows[0]["EMP_COMPANY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_COMPANY"].ToString() : "";
            txtDOJ.Text = dsdd.Tables[0].Rows[0]["EMP_DOJ"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_DOJ"].ToString() : "";
            txtGrade.Text = dsdd.Tables[0].Rows[0]["EMP_GRADE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_GRADE"].ToString() : "";
            txtEMpNAme.Enabled = false;
            txtDesgn.Enabled = false;
            txtContact.Enabled = false;
            ttxEmailEmp.Enabled = false;
            txtEmpCompany.Enabled = false;
            txtDOJ.Enabled = false;
            txtGrade.Enabled = false;
        }
        else
        {
            txtEMpID.Text = "";
            txtEMpNAme.Text = "";
            txtDesgn.Text = "";
            txtContact.Text = "";
            ttxEmailEmp.Text = "";
            txtEmpCompany.Text = "";
            txtDOJ.Text = "";
            txtGrade.Text = "";

            txtEMpNAme.Enabled = true;
            txtDesgn.Enabled = true;
            txtContact.Enabled = true;
            ttxEmailEmp.Enabled = true;
            txtEmpCompany.Enabled = true;
            txtDOJ.Enabled = true;
            txtGrade.Enabled = true;
        }
    }

    protected void btnDraft_Click1(object sender, EventArgs e)
    {

    }
    protected void txtNoofcatlle_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (txtNoofcatlle.Text.ToString() == "")
            {
                uscMsgBox1.AddMessage("Please enter the no of cattle more than or equal to 2.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtNoofcatlle.Focus();
            }
            else

                if (Convert.ToInt32(txtNoofcatlle.Text) < 2)
                {
                    uscMsgBox1.AddMessage("Please enter the no of cattle more than or equal to 2.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    txtNoofcatlle.Focus();
                }
                
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlNomineeName_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlNomineeName.SelectedItem.Text != "--Select--" && ddlNomineeName.SelectedItem.Text != "Others")
            {
                txtNomineeRelation.Text = Convert.ToString(ddlNomineeName.SelectedValue);
                txtNomineeRelation.Enabled = false;
                tdNomineeName.Visible = false;
                tdNomineeName1.Visible = false;
                //bala changes
                tdRelationType.Visible = true;
                tdRelationType1.Visible = true;
                txtRelationShip.Text = "";
            }
            else
                if (ddlNomineeName.SelectedItem.Text == "Others")
                {
                    txtNomineeRelation.Text = "";
                    txtNomineeRelation.Enabled = true;
                    tdNomineeName.Visible = true;
                    tdNomineeName1.Visible = true;
                    txtNomineeName.Enabled = true;
                    //bala changes 05042018
                    tdRelationType.Visible = false;
                    tdRelationType1.Visible = false;
                    txtRelationShip.Text = "";
                }
                else
                {
                    txtNomineeRelation.Text = "";
                    txtNomineeRelation.Enabled = false;
                    tdNomineeName.Visible = false;
                    tdNomineeName1.Visible = false;
                    //bala changes 05042018
                    tdRelationType.Visible = true;
                    tdRelationType1.Visible = true;
                    txtRelationShip.Text = "";
                }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    //Changes for IR-535
    private void SetTextForLabels()
    {
        lblGuidelineVal.Text = GlobalClass.GuidelineValue;
    }
    //End of Changes for IR-535
}