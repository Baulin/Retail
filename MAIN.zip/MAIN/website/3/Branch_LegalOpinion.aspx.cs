﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Threading;
using System.Text;
using System.Net.Mail;
using Utilities;
using Tracker;

public partial class Branch_LegalOpinion : System.Web.UI.Page
{
    DateTime dt = DateTime.Now;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DataSet ds = new DataSet();
    DataSet dss = new DataSet();
    string leadno;
    string appname;
    string product;
    string lnamt;
    string brnch;
    string sa;
    int ldid;




    /*Mailing variables*/
    public static bool blMailStatus = false;
    public static string frmID = "", toID = "", bccID = "", ccID = "", strMailBody = "";
    public string area = "", bnch = "", ldno = "", prod = "", aname = "";
    public int arid, brid, dvid;
    Thread mail;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                bindArea();

                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);

                this.leadsel2.Visible = false;
                this.querylist.Visible = false;
                this.queryraised.Visible = false;
                btnlglbrnchSubmit.Enabled = false;
                btnlglbrnchCancel.Enabled = false;

            }
        }
        else Response.Redirect("Expire.aspx");

    }
    // Shankar_Nov_14_01 
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    // Shankar_Nov_14_01 
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }

    protected void View()
    {
        try
        {
            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please select Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
            else
            {

                SqlConnection con = new SqlConnection(strcon);
                try
                {
                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();
                    SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Legal_Opinion_OV", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    //cmd.Parameters.AddWithValue("@View", "");
                    cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
                    cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
                    cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
                    cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
                    cmd.Parameters.AddWithValue("@FT_SENTTO", "L");
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds1 = new DataSet();
                    da.Fill(ds1);
                    if (ds1.Tables.Count != 0 && ds1.Tables[0].Rows.Count != 0)
                    {
                        this.querylist.Visible = true;
                        this.queryraised.Visible = false;

                        gvlead.DataSource = ds1.Tables[0];
                        gvlead.DataBind();
                        if (ds1.Tables[0].Rows.Count > 0)
                        {
                            gvlead.HeaderRow.Font.Bold = true;
                            gvlead.HeaderRow.Cells[1].Text = "LEAD NO";
                            gvlead.HeaderRow.Cells[2].Text = "APPLICANT NAME";
                            gvlead.HeaderRow.Cells[3].Text = "PRODUCT";
                            gvlead.HeaderRow.Cells[4].Text = "LOAN AMOUNT";
                            gvlead.HeaderRow.Cells[5].Text = "BRANCH";

                            gvlead.HeaderRow.Cells[1].Wrap = false;
                            gvlead.HeaderRow.Cells[2].Wrap = false;
                            gvlead.HeaderRow.Cells[3].Wrap = false;
                            gvlead.HeaderRow.Cells[4].Wrap = false;
                            gvlead.HeaderRow.Cells[5].Wrap = false;
                        }
                    }
                    else
                    {
                        this.querylist.Visible = false;
                        this.queryraised.Visible = false;
                        this.leadsel2.Visible = false;
                        btnlglbrnchSubmit.Enabled = false;
                        btnlglbrnchCancel.Enabled = false;


                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    try { Response.Redirect("ErrorPage.aspx?parameter=Branch_LegalOpinion.aspx"); }
                    catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
                }
                finally
                {
                    con.Close();
                }

                btnlglbrnchSubmit.Enabled = false;

                btnlglbrnchCancel.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Branch_LegalOpinion.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }

    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {


            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please select Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
            else
            {


                BindqueryGrid();

                btnlglbrnchSubmit.Enabled = false;

                btnlglbrnchCancel.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Branch_LegalOpinion.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Legal_Opinion_OV", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "L");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables.Count != 0)
            {
                this.querylist.Visible = true;
                this.queryraised.Visible = false;

                gvlead.DataSource = ds1.Tables[0];
                gvlead.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvlead.HeaderRow.Font.Bold = true;
                    gvlead.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvlead.HeaderRow.Cells[2].Text = "APPLICANT NAME";
                    gvlead.HeaderRow.Cells[3].Text = "PRODUCT";
                    gvlead.HeaderRow.Cells[4].Text = "LOAN AMOUNT";
                    gvlead.HeaderRow.Cells[5].Text = "BRANCH";

                    gvlead.HeaderRow.Cells[1].Wrap = false;
                    gvlead.HeaderRow.Cells[2].Wrap = false;
                    gvlead.HeaderRow.Cells[3].Wrap = false;
                    gvlead.HeaderRow.Cells[4].Wrap = false;
                    gvlead.HeaderRow.Cells[5].Wrap = false;
                }
                else
                {
                    gvlead.DataSource = ds1.Tables[0];
                    gvlead.DataBind();
                    this.queryraised.Visible = false;
                    this.leadsel2.Visible = false;
                    btnlglbrnchSubmit.Enabled = false;
                    btnlglbrnchCancel.Enabled = false;


                }
            }
            else
            {

                this.querylist.Visible = false;
                this.queryraised.Visible = false;
                this.leadsel2.Visible = false;
                btnlglbrnchSubmit.Enabled = false;
                btnlglbrnchCancel.Enabled = false;

                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);



            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Branch_LegalOpinion.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }

    private void BindListofDocuments()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_FetchMODTDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LD_ID", Convert.ToInt32(Session["LDID"].ToString()));
            cmd.CommandTimeout = 60000;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            gvdocs.DataSource = ds.Tables[1];
            gvdocs.DataBind();
            if (ds.Tables[1].Rows.Count > 0)
            {
                this.leadsel2.Visible = true;
                btnlglbrnchSubmit.Enabled = true;
                btnlglbrnchCancel.Enabled = true;
            }
            else
            {
                this.leadsel2.Visible = false;
                btnlglbrnchSubmit.Enabled = false;
                btnlglbrnchCancel.Enabled = false;
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Branch_LegalOpinion.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }

    }

    protected void ddlstarea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";

    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            foreach (GridViewRow grow in gvlead.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                Label lblldid = grow.FindControl("lblLeadID") as Label;
                ldid = Convert.ToInt32(lblldid.Text);
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    leadno = gvlead.Rows[index].Cells[1].Text;
                    appname = gvlead.Rows[index].Cells[2].Text;
                    product = gvlead.Rows[index].Cells[3].Text;
                    lnamt = gvlead.Rows[index].Cells[4].Text;
                    brnch = gvlead.Rows[index].Cells[5].Text;
                    Session["LeadID"] = gvlead.Rows[index].Cells[1].Text;
                    Session["LDID"] = ldid;
                    gridbind1();
                    BindListofDocuments();



                    CheckQueryResolve();
                    break;
                }

            }

            con.Close();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void gridbind1()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_BindQueryRaised", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LD_NO", Session["LeadID"].ToString());
            cmd.Parameters.AddWithValue("@QRY_RSD_BY", "L");
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dss);

            gvQuerypop.DataSource = dss.Tables[0];
            gvQuerypop.DataBind();
            if (dss.Tables[0].Rows.Count > 0)
            {
                this.queryraised.Visible = true;
                gvQuerypop.HeaderRow.Font.Bold = true;
                gvQuerypop.HeaderRow.Cells[1].Text = "QUERY RAISED";
                gvQuerypop.HeaderRow.Cells[2].Text = "DATE";
                gvQuerypop.HeaderRow.Cells[3].Text = "RESPONSE";
                gvQuerypop.HeaderRow.Cells[4].Text = "RESPONSE DATE";
                gvQuerypop.HeaderRow.Cells[5].Text = "RESOLVE DATE";

                gvQuerypop.HeaderRow.Cells[1].Wrap = false;
                gvQuerypop.HeaderRow.Cells[2].Wrap = false;
                gvQuerypop.HeaderRow.Cells[3].Wrap = false;
                gvQuerypop.HeaderRow.Cells[4].Wrap = false;
                gvQuerypop.HeaderRow.Cells[5].Wrap = false;



            }
            else
            {
                this.queryraised.Visible = false;
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Branch_LegalOpinion.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnlglbrnchSubmit_Click(object sender, EventArgs e)
    {
        int cntsel = 0;
        int updcnt = 0;
        int updateres = 0;
        Label lbl_mdid = null;
        Label lbl_slno = null;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            foreach (GridViewRow grow in gvdocs.Rows)
            {
                DropDownList chkStat = grow.FindControl("ddlstlglbrnchdoctype") as DropDownList;
                int index = grow.RowIndex;
                if (chkStat.SelectedIndex > 0)
                {
                    cntsel++;
                }
            }
            if (cntsel == gvdocs.Rows.Count)
            {
                con.Open();
                cntsel = 0;
                foreach (GridViewRow grow in gvdocs.Rows)
                {
                    DropDownList chkStat = grow.FindControl("ddlstlglbrnchdoctype") as DropDownList;
                    int index = grow.RowIndex;
                    if (chkStat.SelectedIndex > 0)
                    {
                        cntsel++;
                        lbl_mdid = (Label)gvdocs.Rows[index].Cells[0].FindControl("lblmdid");
                        lbl_slno = (Label)gvdocs.Rows[index].Cells[0].FindControl("lblslno");

                        SqlCommand cmdbr = new SqlCommand("RTS_SP_UpdateMODT_DOCX", con);
                        cmdbr.CommandType = CommandType.StoredProcedure;
                        cmdbr.Parameters.AddWithValue("@MDX_MD_ID", Convert.ToInt32(lbl_mdid.Text));
                        cmdbr.Parameters.AddWithValue("@MDX_SLNO", Convert.ToInt32(lbl_slno.Text));
                        cmdbr.Parameters.AddWithValue("@MDX_BSTAT", chkStat.SelectedItem.Text);//@MD_MBY
                        cmdbr.Parameters.AddWithValue("@MD_MBY", Convert.ToInt32(Session["ID"].ToString()));
                        updateres = cmdbr.ExecuteNonQuery();
                        updcnt = updcnt + updateres;
                    }
                }

                if (updcnt == (gvdocs.Rows.Count * 2))
                {

                    sendMail(con);
                    //if (mail.IsAlive) { Thread.Sleep(5000); }


                    string strMailStatus = "";
                    string strSuccessMsg = "";

                    if (blMailStatus == true)
                    {
                        strMailStatus = "Successfully";
                    }
                    else
                    {
                        strMailStatus = "Failed";
                    }
                    strSuccessMsg = " <br/> Mail Sent " + strMailStatus + "  ";
                    strSuccessMsg += "<br/> Mail To: " + toID + " ; CC To: " + ccID + " ";



                    uscMsgBox1.AddMessage("Orignal documents verified successfully." + strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    Clear();
                    View();
                }
                else
                    uscMsgBox1.AddMessage("Orignal documents not verified", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
            {
                uscMsgBox1.AddMessage("Please select the document type provided in the list of documents", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();

        }
    }
    protected void btnlglbrnchCancel_Click(object sender, EventArgs e)
    {

        Response.Redirect("Branch_LegalOpinion.aspx");
    }
    public void Clear()
    {

        txtLeadno.Text = "";

        gvdocs.DataSource = null;
        gvdocs.DataBind();
        gvlead.DataSource = null;
        gvlead.DataBind();
        this.queryraised.Visible = false;
        this.querylist.Visible = false;

        this.leadsel2.Visible = false;
        btnlglbrnchSubmit.Enabled = true;
    }

    public void CheckQueryResolve()
    {
        int tmpcnt = 0;
        for (int w = 0; w < gvQuerypop.Rows.Count; w++)
        {
            if (gvQuerypop.Rows[w].Cells[5].Text != "" && gvQuerypop.Rows[w].Cells[5].Text != " " && !gvQuerypop.Rows[w].Cells[5].Text.Contains("&nbsp"))
            {
                tmpcnt++;
            }
        }

        if (tmpcnt == gvQuerypop.Rows.Count)
        {

            this.leadsel2.Visible = true;
            btnlglbrnchSubmit.Enabled = true;

            btnlglbrnchCancel.Enabled = true;
        }
        else
        {

            this.leadsel2.Visible = false;
            btnlglbrnchSubmit.Enabled = false;
            btnlglbrnchCancel.Enabled = false;
        }
    }
    
    public void sendMail(SqlConnection con)
    {
        try
        {
            StringBuilder cmd = new StringBuilder();

            Session["OVTOID"] = "";
            Session["OVCCID"] = "";
            Session["OVAID"] = "";
            Session["OVBID"] = "";


            Session["OVLEADNO"] = "";
            Session["OVAPPNAME"] = "";
            Session["OVPROD"] = "";
            Session["OVAREA"] = "";
            Session["OVBRANCH"] = "";

            cmd.Append("SELECT 	LD_NO 'LEADNO', LD_APNAME 'APPLICANT',(SELECT PR_NAME FROM MR_PRODUCT WHERE PR_ID=A.LD_PR_ID) 'PRODUCT',C.AR_ID 'AID',C.AR_NAME 'AREA',C.AR_DV_ID 'DID', B.BR_ID 'BID',B.BR_NAME 'BRANCH' FROM	LSD_LEAD A ");
            cmd.Append(" JOIN MR_BRANCH B ON B.BR_ID=A.LD_BR_ID ");
            cmd.Append(" JOIN MR_AREA  C ON C.AR_ID= B.BR_AR_ID ");
            cmd.Append(" WHERE A.LD_ID=");
            cmd.Append(Session["LDID"].ToString());


            SqlCommand cmddet = new SqlCommand(cmd.ToString(), con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataTable dtdet = new DataTable();
            dadet.Fill(dtdet);



            if (dtdet.Rows.Count > 0)
            {
                ldno = dtdet.Rows[0]["LEADNO"] != DBNull.Value ? dtdet.Rows[0]["LEADNO"].ToString() : "";
                Session["OVLEADNO"] = dtdet.Rows[0]["LEADNO"] != DBNull.Value ? dtdet.Rows[0]["LEADNO"].ToString() : "";

                aname = dtdet.Rows[0]["APPLICANT"] != DBNull.Value ? dtdet.Rows[0]["APPLICANT"].ToString() : "";
                Session["OVAPPNAME"] = dtdet.Rows[0]["APPLICANT"] != DBNull.Value ? dtdet.Rows[0]["APPLICANT"].ToString() : "";

                prod = dtdet.Rows[0]["PRODUCT"] != DBNull.Value ? dtdet.Rows[0]["PRODUCT"].ToString() : "";
                Session["OVPROD"] = dtdet.Rows[0]["PRODUCT"] != DBNull.Value ? dtdet.Rows[0]["PRODUCT"].ToString() : "";

                area = dtdet.Rows[0]["AREA"] != DBNull.Value ? dtdet.Rows[0]["AREA"].ToString() : "";

                Session["OVAREA"] = dtdet.Rows[0]["AREA"] != DBNull.Value ? dtdet.Rows[0]["AREA"].ToString() : "";

                bnch = dtdet.Rows[0]["BRANCH"] != DBNull.Value ? dtdet.Rows[0]["BRANCH"].ToString() : "";

                Session["OVBRANCH"] = dtdet.Rows[0]["BRANCH"] != DBNull.Value ? dtdet.Rows[0]["BRANCH"].ToString() : "";

                arid = dtdet.Rows[0]["AID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["AID"].ToString()) : 0;
                Session["OVAID"] = dtdet.Rows[0]["AID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["AID"].ToString()) : 0;

                brid = dtdet.Rows[0]["BID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["BID"].ToString()) : 0;
                Session["OVBID"] = dtdet.Rows[0]["BID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["BID"].ToString()) : 0;

                dvid = dtdet.Rows[0]["DID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["DID"].ToString()) : 0;
            }
            else
            {
                blMailStatus = false;
                return;
            }

            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_EMAIL WHERE EM_BR_ID=");
            cmd.Append(Session["OVBID"].ToString());

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtbrnch = new DataTable();
            dadet.Fill(dtbrnch);


            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_AREA_MANAGER WHERE AM_AR_ID=");
            cmd.Append(Session["OVAID"].ToString());

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtarm = new DataTable();
            dadet.Fill(dtarm);



            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_EMPLOYEE JOIN MR_USER ON USR_EMP_ID=EMP_ID WHERE USR_ID='" + Session["ID"].ToString() + "'");


            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            dtarm = new DataTable();
            dadet.Fill(dtarm);


            if (dtbrnch.Rows.Count > 0)
            {

                if (dtbrnch.Rows[0]["EM_BM"] != "" && dtbrnch.Rows[0]["EM_BM"] != DBNull.Value && dtbrnch.Rows[0]["EM_BM"].ToString() != "")
                {
                   
                    Session["OVTOID"] = dtbrnch.Rows[0]["EM_BM"].ToString();

                }
                else
                {

                    Session["OVTOID"] = "rts-helpdesk@equitasbank.com";
                }

                if (dtbrnch.Rows[0]["EM_AM"] != "" && dtbrnch.Rows[0]["EM_AM"] != DBNull.Value && dtbrnch.Rows[0]["EM_AM"].ToString() != "")
                {
                    
                    Session["OVCCID"] = dtbrnch.Rows[0]["EM_AM"].ToString();
                }
                if (dtarm.Rows[0]["EMP_EMAILID"] != "" && dtarm.Rows[0]["EMP_EMAILID"] != DBNull.Value && dtarm.Rows[0]["EMP_EMAILID"].ToString() != "")
                {
                    // ccID = dtbrnch.Rows[0]["EM_AM"].ToString();

                    if (Session["OVCCID"].ToString() != "")
                    {
                        Session["OVCCID"] = Session["OVCCID"].ToString() + ";" + dtarm.Rows[0]["EMP_EMAILID"].ToString();
                    }
                    else
                    {
                        Session["OVCCID"] = dtarm.Rows[0]["EMP_EMAILID"].ToString();
                    }
                }

  

                if (Session["OVCCID"].ToString().ToString().StartsWith(";"))
                {
                    Session["OVCCID"]= Session["OVCCID"].ToString().Substring(1, Session["OVCCID"].ToString().Length - 1);
                }
                if (Session["OVCCID"].ToString().EndsWith(";"))
                {
                    Session["OVCCID"] = Session["OVCCID"].ToString().Remove(Session["OVCCID"].ToString().ToString().Length - 1, 1);
                }

                if (Session["OVTOID"].ToString().StartsWith(";"))
                {
                    Session["OVTOID"] = Session["OVTOID"].ToString().Substring(1, toID.Length - 1);
                }
                if (Session["OVTOID"].ToString().EndsWith(";"))
                {
                    Session["OVTOID"] = Session["OVTOID"].ToString().Remove(Session["OVTOID"].ToString().Length - 1, 1);
                }

                
            }
            else
            {
                blMailStatus = false;
                return;
            }



            frmID = "RTS Alerts";


            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

          /*  threadSendMails = new System.Threading.Thread(delegate()
            {
            */
                String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Branch Original Verification. <br/><br/>";
                BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["OVLEADNO"].ToString() + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Area Name</td><td><strong>" + Session["OVAREA"].ToString() + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Branch Name</td><td><strong>" + Session["OVBRANCH"].ToString() + "</strong></td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + Session["OVPROD"].ToString() + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + Session["OVAPPNAME"].ToString() + "</strong></td><td>Branch Status</td><td><strong> OV Done </strong></td></tr></table><br/>";

                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/>Thanks and Regards,<br/>Legal Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is an auto-generated e-mail. Please Do not reply to this e-mail.</strong></span></td></tr></table></tr></table></html>";


                blMailStatus = EmailManager.sendemail(Session["OVTOID"].ToString(), "RTS Alerts", "", Session["OVCCID"].ToString(), "Lead No. : " + Session["OVLEADNO"].ToString() + " - Applicant Name : " + Session["OVAPPNAME"].ToString() + " - Product: " + Session["OVPROD"].ToString() + " - Original Verification", BodyTxt, "", true);


           /* });

            threadSendMails.IsBackground = true;
            mail = threadSendMails;
            threadSendMails.Start();
            System.Threading.Thread.Sleep(5000);
                */

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }

    protected void gvdocs_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Char dateSplitter = new Char();
                string tempdate = DataBinder.Eval(e.Row.DataItem, "MDX_DATE").ToString();
                Label lbdate = (Label)e.Row.FindControl("lbldate");

                if (tempdate.Contains(".")) { dateSplitter = '.'; }
                else if (tempdate.Contains("/")) { dateSplitter = '/'; }
                else if (tempdate.Contains("-")) { dateSplitter = '-'; }

                //string[] dbarr = tempdate.Split('/');
                string[] dbarr = tempdate.Split(dateSplitter);
                //(e.Row.FindControl("lbldate") as Label).Text = dbarr[1].ToString() + "-" + dbarr[0].ToString() + "-" + dbarr[2].ToString();
                lbdate.Text = dbarr[1].ToString() + "-" + dbarr[0].ToString() + "-" + dbarr[2].ToString();
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}