﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using Tracker;


public partial class CAM_TWL : System.Web.UI.Page
{
    public static DataTable dtSourceOfIncome = null;
    DataTable resdt = new DataTable();
    DataTable VILLAGE = new DataTable();
    ClsCommon clscomman = new ClsCommon();
    string SCHEMETYPE = "N";
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                // double dt = GetEMI(0.0, 0.0, 0.0);

                clear();

                txtBranchName.Text = Session["UNITNAME"].ToString();

                FirstGridViewRow();
                BindDropdownList();

                ddlTenure.SelectedValue = "7";
            }
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
    }

    protected void BindDropdownList()
    {

        BindLeadNo();
        BindRelationship();
        BindIncomeSource();       
        BindLoanPurpose();
        BindCreditHistory();
      
        BindCustRelation();       
        BindCategory();      
        BindTenor();
        BindIntrest();
        BindResidenceOwnership();
        
    }

    // __________BIND DROP DOWN LIST START_____________//
    public void BindLeadNo()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_Lead_Details", con);
        cmddd.Parameters.AddWithValue("@LD_NO", "");
        cmddd.Parameters.AddWithValue("@Lead_Type", "TWL");
        cmddd.Parameters.AddWithValue("@BranchName", txtBranchName.Text);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLeadNo.DataSource = dsdd;
        ddlLeadNo.DataTextField = "LD_NO";
        ddlLeadNo.DataValueField = "LD_ID";
        ddlLeadNo.DataBind();

        ddlLeadNo.Items.Insert(0, new ListItem("--Select--", "0"));



    }
    public void BindRelationship()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Relation", con);
        cmddd.Parameters.AddWithValue("@ER_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlRelationShip.DataSource = dsdd;
        ddlRelationShip.DataTextField = "ER_DESC";
        ddlRelationShip.DataValueField = "ER_ID";
        ddlRelationShip.DataBind();
        ddlRelationShip.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindIncomeSource()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_IN_SOURCE", con);
        cmddd.Parameters.AddWithValue("@INS_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlMainApplicant.DataSource = dsdd;
        ddlMainApplicant.DataTextField = "INS_DESC";
        ddlMainApplicant.DataValueField = "INS_ID";
        ddlMainApplicant.DataBind();
        ddlMainApplicant.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindVintage()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);
        cmddd.Parameters.AddWithValue("@VN_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlVintage.DataSource = dsdd;
        ddlVintage.DataTextField = "VN_DESC";
        ddlVintage.DataValueField = "VN_ID";
        ddlVintage.DataBind();
        ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindLoanPurpose()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PURPOSE", con);
        cmddd.Parameters.AddWithValue("@PP_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLoanPurpose.DataSource = dsdd;
        ddlLoanPurpose.DataTextField = "PP_DESC";
        ddlLoanPurpose.DataValueField = "PP_ID";
        ddlLoanPurpose.DataBind();
        ddlLoanPurpose.Items.Insert(0, new ListItem("--Select--", "0"));

        ddlLoanPurpose.SelectedValue = "6";
        
    }
    public void BindCreditHistory()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CR_HISTORY", con);
        cmddd.Parameters.AddWithValue("@CH_ID", "");
        cmddd.Parameters.AddWithValue("@CH_TYPE", "T");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlCreditHistory.DataSource = dsdd;
        ddlCreditHistory.DataTextField = "CH_DESC";
        ddlCreditHistory.DataValueField = "CH_ID";
        ddlCreditHistory.DataBind();
        ddlCreditHistory.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindResidenceOwnership()
    {

        DataSet dsdd = new DataSet();
        dsdd = clscomman.GetResidencyOwnership();
        ddlResiOwnership.DataSource = dsdd;
        ddlResiOwnership.DataTextField = "RO_DESC";
        ddlResiOwnership.DataValueField = "RO_ID";
        ddlResiOwnership.DataBind();
        ddlResiOwnership.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindCustRelation()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_RELATION", con);
        cmddd.Parameters.AddWithValue("@RL_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlCustRelation.DataSource = dsdd;
        ddlCustRelation.DataTextField = "RL_DESC";
        ddlCustRelation.DataValueField = "Rl_ID";
        ddlCustRelation.DataBind();
        ddlCustRelation.Items.Insert(0, new ListItem("--Select--", "0"));
    }
   
    public void BindCategory()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
        cmddd.Parameters.AddWithValue("@CT_ID", "");
        cmddd.Parameters.AddWithValue("@CT_TYPE", "T");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlCustSource.DataSource = dsdd;
        ddlCustSource.DataTextField = "CT_DESC";
        ddlCustSource.DataValueField = "CT_DESC";
        ddlCustSource.DataBind();
        ddlCustSource.Items.Insert(0, new ListItem("--Select--", "0"));
    }

 
 
    public void BindTenor()
    {
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("XML/TWLTenor.xml"));

        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();

        if (ds.Tables.Count != 0)
        {
            ddlTenure.DataSource = ds;

            ddlTenure.DataTextField = "Tenor";

            ddlTenure.DataValueField = "Tenor";

            ddlTenure.DataBind();
        }
        else
        {
            ddlTenure.Items.Insert(0, new ListItem("--Select--", "0"));
            Clear();
        }
    }
    public void BindIntrest()
    {
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("XML/TWLIntrest.xml"));

        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();

        if (ds.Tables.Count != 0)
        {
            ddlIntrest.DataSource = ds;

            ddlIntrest.DataTextField = "Intrest";

            ddlIntrest.DataValueField = "Intrest";

            ddlIntrest.DataBind();
            ddlIntrest.Enabled = false;
          //  ddlIntrest.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }
    public DataSet fetchLeadDetails(string strLeadNo)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Lead_Details", con);
        cmddd.Parameters.AddWithValue("@LD_NO", strLeadNo);
        cmddd.Parameters.AddWithValue("@Lead_Type", "TWL");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        return dsdd;
    }
    // __________BIND DROP DOWN LIST END_____________//


    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            btnSubmit.Enabled = false;
            if (DDLkycName.SelectedIndex != 0 && ddlCustSource.SelectedItem.Text != "--Select--" && txtCustAge.Text != "" && ddlCustRelation.SelectedItem.Text != "--Select--"
                                   && txtIncome.Text != "")
            {
                AddNewRow();
            }
            else
            {
                if (DDLkycName.SelectedIndex == 0)
                {
                    DDLkycName.Focus();
                }
                else if (ddlCustSource.SelectedItem.Text == "--Select--")
                {
                    ddlCustSource.Focus();
                }
                else if (txtCustAge.Text == "")
                {
                    txtCustAge.Focus();

                }
                else if (ddlCustRelation.SelectedItem.Text == "--Select--")
                {
                    ddlCustSource.Focus();
                }
                else if (txtIncome.Text == "")
                {
                    txtCustAge.Focus();

                }
                uscMsgBox1.AddMessage("Please Give corresponding Inputs for Income details", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    private void FirstGridViewRow()
    {
        DataTable dt = new DataTable();
        DataRow dr = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("NAME", typeof(string)));
        dt.Columns.Add(new DataColumn("APP_TYPE", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_SOURCE", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_SOURCEID", typeof(string)));
        dt.Columns.Add(new DataColumn("AGE", typeof(string)));
        dt.Columns.Add(new DataColumn("RELATIONSHIP", typeof(string)));
        dt.Columns.Add(new DataColumn("RELATIONSHIPID", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_TAKEN", typeof(string)));
        dt.Columns.Add(new DataColumn("FACTORED_INCOME", typeof(string)));

        dr = dt.NewRow();
        //dr["RowNumber"] = 1;

        dr["NAME"] = string.Empty;
        dr["APP_TYPE"] = string.Empty;
        dr["INCOME_SOURCE"] = string.Empty;
        dr["INCOME_SOURCEID"] = string.Empty;
        dr["AGE"] = string.Empty;
        dr["RELATIONSHIP"] = string.Empty;
        dr["RELATIONSHIPID"] = string.Empty;
        dr["INCOME"] = string.Empty;
        dr["INCOME_TAKEN"] = string.Empty;
        dr["FACTORED_INCOME"] = string.Empty;
        dt.Rows.Add(dr);

        ViewState["CurrentTable"] = dt;

        gvIncomeDetail.DataSource = dt;
        gvIncomeDetail.DataBind();

        //DropDownList ddlCustSource =
        //           (DropDownList)gvIncomeDetail.Rows[0].Cells[2].FindControl("ddlCustSource");

        //ddlCustSource.DataSource = dtLawyerName;
        //ddlCustSource.DataTextField = "LR_NAME";
        //ddlCustSource.DataValueField = "LR_ID";
        //ddlCustSource.DataBind();
        //ddlCustSource.Items.Insert(0, "--Select--");
    }
    private void AddNewRow()
    {
        int rowIndex = 0;

        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;



            if (dtCurrentTable.Rows.Count > 0 && dtCurrentTable.Rows[0][0].ToString() == "")
            {
                dtCurrentTable.Rows.RemoveAt(0);
            }
            drCurrentRow = dtCurrentTable.NewRow();
            drCurrentRow["NAME"] = DDLkycName.SelectedItem.Text;
            drCurrentRow["APP_TYPE"] = TBAppType.Text;
            //DDLkycName.Items.RemoveAt(DDLkycName.SelectedIndex);
            //DDLkycName.DataBind();
            drCurrentRow["INCOME_SOURCE"] = ddlCustSource.SelectedItem.Text != "--Select--" ? ddlCustSource.SelectedItem.Text : "";
            int INCOME_SOURCEID = FetchINCOME_SOURCEID(ddlCustSource.SelectedItem.Text);
            drCurrentRow["INCOME_SOURCEID"] = INCOME_SOURCEID;
            drCurrentRow["AGE"] = txtCustAge.Text;
            drCurrentRow["RELATIONSHIP"] = ddlCustRelation.SelectedItem.Text != "--Select--" ? ddlCustRelation.SelectedItem.Text : "";
            drCurrentRow["RELATIONSHIPID"] = ddlCustRelation.SelectedItem.Text != "--Select--" ? ddlCustRelation.SelectedValue.ToString() : "";
            drCurrentRow["INCOME"] = txtIncome.Text;
            drCurrentRow["INCOME_TAKEN"] = txtIncomeTaken.Text;
            drCurrentRow["FACTORED_INCOME"] = Convert.ToString(Convert.ToDouble(txtIncome.Text) * (Convert.ToDouble(txtIncomeTaken.Text) / 100));

            //  rowIndex++;
            // }
            dtCurrentTable.Rows.Add(drCurrentRow);
            ViewState["CurrentTable"] = dtCurrentTable;

            gvIncomeDetail.DataSource = dtCurrentTable;
            gvIncomeDetail.DataBind();
            Clear();
            double dblOldIncome = 0.0;
            foreach (GridViewRow grow in gvIncomeDetail.Rows)
            {
                int index = grow.RowIndex;
                double dblIncome = Convert.ToDouble(gvIncomeDetail.Rows[index].Cells[5].Text);
                if (Convert.ToInt32(gvIncomeDetail.Rows[index].Cells[3].Text) < 60)
                {


                    if (dblIncome > dblOldIncome)
                    {
                        txtNameofInsuredPerson.Text = gvIncomeDetail.Rows[index].Cells[0].Text;
                        dblOldIncome = dblIncome;
                    }
                }

            }
            if (dtCurrentTable != null && dtCurrentTable.Rows.Count > 0)
            {
                double nTotalLoanEligibility = 0.0;

                for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                {
                    double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                    nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;
                }
                txtTotalLoanEligibility.Text = nTotalLoanEligibility.ToString();
                BindBorrower(dtCurrentTable);
            }
            //  }
        }
        else
        {
            Response.Write("ViewState is null");
        }
        //  SetPreviousData();
    }
    public void BindBorrower(DataTable dt)
    {
        /// NAME
        string strBrwname1 = "", strBrwname2 = "", strBrwname3 = "", strBrwname4 = "", strBrwname5 = "";

        if (drpName1.Items.Count > 0)
        {
            strBrwname1 = drpName1.SelectedValue;
        }
        if (drpName2.Items.Count > 0)
        {
            strBrwname2 = drpName2.SelectedValue;
        }
        if (drpName3.Items.Count > 0)
        {
            strBrwname3 = drpName3.SelectedValue;
        }
        if (drpName4.Items.Count > 0)
        {
            strBrwname4 = drpName4.SelectedValue;
        }
        if (drpName5.Items.Count > 0)
        {
            strBrwname5 = drpName5.SelectedValue;
        }
        drpName1.Items.Clear();
        drpName2.Items.Clear();
        drpName3.Items.Clear();
        drpName4.Items.Clear();
        drpName5.Items.Clear();

        drpName1.DataSource = dt;
        drpName2.DataSource = dt;
        drpName3.DataSource = dt;
        drpName4.DataSource = dt;
        drpName5.DataSource = dt;

        drpName1.DataTextField = "NAME";
        drpName1.DataValueField = "NAME";

        drpName2.DataTextField = "NAME";
        drpName2.DataValueField = "NAME";

        drpName3.DataTextField = "NAME";
        drpName3.DataValueField = "NAME";

        drpName4.DataTextField = "NAME";
        drpName4.DataValueField = "NAME";

        drpName5.DataTextField = "NAME";
        drpName5.DataValueField = "NAME";

        drpName1.DataBind();
        drpName2.DataBind();
        drpName3.DataBind();
        drpName4.DataBind();
        drpName5.DataBind();

        drpName1.Items.Insert(0, "--Select--");
        drpName2.Items.Insert(0, "--Select--");
        drpName3.Items.Insert(0, "--Select--");
        drpName4.Items.Insert(0, "--Select--");
        drpName5.Items.Insert(0, "--Select--");
        if (strBrwname1 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname1 + "'");
            if (dr.Length > 0)
            {
                drpName1.SelectedValue = strBrwname1;
            }
            else
            {
                txtFinanciear1.Text = "";
                txtEMIAmount1.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }

        }
        if (strBrwname2 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname2 + "'");
            if (dr.Length > 0)
            {
                drpName2.SelectedValue = strBrwname2;
            }
            else
            {
                txtFinanciear2.Text = "";
                txtEMIAmount2.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname3 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname3 + "'");
            if (dr.Length > 0)
            {

                drpName3.SelectedValue = strBrwname3;
            }
            else
            {
                txtFinanciear3.Text = "";
                txtEMIAmount3.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname4 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname4 + "'");
            if (dr.Length > 0)
            {
                drpName4.SelectedValue = strBrwname4;
            }
            else
            {
                txtFinanciear4.Text = "";
                txtEMIAmount4.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname5 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname5 + "'");
            if (dr.Length > 0)
            {
                drpName5.SelectedValue = strBrwname5;
            }
            else
            {
                txtFinanciear5.Text = "";
                txtEMIAmount5.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }


    }
    public int FetchINCOME_SOURCEID(string strDesc)
    {
        int INCOME_SOURCEID = 0;
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("Select CT_ID from MR_CATEGORY where CT_PR_TYPE='T' and CT_DESC='" + strDesc + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        INCOME_SOURCEID = Convert.ToInt32(dsdd.Tables[0].Rows[0][0]);
        con.Close();
        return INCOME_SOURCEID;
    }
    public void Clear()
    {
        DDLkycName.SelectedIndex = 0;
        ddlCustSource.SelectedIndex = 0;
        txtCustAge.Text = "";
        ddlCustRelation.SelectedIndex = 0;
        txtIncome.Text = "";
        txtIncomeTaken.Text = "";
        txtFactor.Text = "";
    }
    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    TextBox txtCustName =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[1].FindControl("txtCustName");
                    DropDownList ddlCustSource =
                     (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[2].FindControl("ddlCustSource");
                    TextBox txtCustAge =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[3].FindControl("txtCustAge");
                    DropDownList ddlCustRelation =
                       (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[4].FindControl("ddlCustRelation");
                    TextBox txtIncome =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[5].FindControl("txtIncome");
                    DropDownList ddlIncomeTaken =
                      (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[6].FindControl("ddlIncomeTaken");
                    DropDownList ddlFactor =
                     (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[7].FindControl("ddlFactor");

                    txtCustName.Text = dt.Rows[i]["Col1"].ToString();
                    ddlCustSource.SelectedItem.Text = dt.Rows[i]["Col2"].ToString();
                    txtCustAge.Text = dt.Rows[i]["Col3"].ToString();
                    ddlCustRelation.SelectedItem.Text = dt.Rows[i]["Col4"].ToString();
                    txtIncome.Text = dt.Rows[i]["Col5"].ToString();
                    ddlIncomeTaken.SelectedItem.Text = dt.Rows[i]["Col6"].ToString();
                    ddlFactor.SelectedItem.Text = dt.Rows[i]["Col7"].ToString();
                    rowIndex++;
                }
            }
        }
    }


    protected void gvIncomeDetail_RowCommand1(object sender, GridViewCommandEventArgs e)
    {
        try
        {


            //DataTable dtTempTable=null;
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];

                if (e.CommandName == "Delete")
                {
                    btnSubmit.Enabled = false;
                    string strVal = e.CommandArgument.ToString();
                    DataRow[] dr = dtCurrentTable.Select("NAME <> '" + strVal + "'");
                    //DDLkycName.Items.Add(strVal);
                    if (dr.Length > 0)
                    {
                        dtCurrentTable = dr.CopyToDataTable();


                        ViewState["CurrentTable"] = dtCurrentTable;
                        gvIncomeDetail.DataSource = dtCurrentTable;
                        gvIncomeDetail.DataBind();
                        double dblOldIncome = 0.0;
                        if (dtCurrentTable != null && dtCurrentTable.Rows.Count > 0)
                        {
                            double nTotalLoanEligibility = 0.0;

                            for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                            {
                                double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                                int nAge = dtCurrentTable.Rows[n]["AGE"] != DBNull.Value ? Convert.ToInt32(dtCurrentTable.Rows[n]["AGE"]) : 0;
                                nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;
                                double dblIncome = nTempVal;
                                if (nAge < 60)
                                {
                                    if (dblIncome > dblOldIncome)
                                    {
                                        txtNameofInsuredPerson.Text = dtCurrentTable.Rows[n]["NAME"] != DBNull.Value ? Convert.ToString(dtCurrentTable.Rows[n]["NAME"]) : "";
                                        dblOldIncome = dblIncome;
                                    }
                                }
                            }
                            txtTotalLoanEligibility.Text = nTotalLoanEligibility.ToString();
                            BindBorrower(dtCurrentTable);
                        }
                    }
                    else
                    {
                        FirstGridViewRow();
                        txtTotalLoanEligibility.Text = "";
                        drpName1.Items.Clear();
                        drpName2.Items.Clear();
                        drpName3.Items.Clear();
                        drpName4.Items.Clear();
                        drpName5.Items.Clear();
                        txtFinanciear1.Text = "";
                        txtFinanciear2.Text = "";
                        txtFinanciear3.Text = "";
                        txtFinanciear4.Text = "";
                        txtFinanciear5.Text = "";

                        txtEMIAmount1.Text = "";
                        txtEMIAmount2.Text = "";
                        txtEMIAmount3.Text = "";
                        txtEMIAmount4.Text = "";
                        txtEMIAmount5.Text = "";
                        txtTotalEMIAmount.Text = "";


                    }

                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void gvIncomeDetail_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void gvIncomeDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void ddlLeadNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
           

            if (ddlLeadNo.SelectedIndex > 0)
            {
                txtCAMDATE.Text = DateTime.Now.ToString("dd/MMM/yyyy");

                string strnleadno = ddlLeadNo.SelectedItem.Text.Trim();

                DataSet dsLead = fetchLeadDetails(ddlLeadNo.SelectedItem.Text.Trim());

                if (dsLead != null && dsLead.Tables[0].Rows.Count > 0)
                {

                    KYC_details();
                    FetchCam();
                    txtPDDate.Text = dsLead.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsLead.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
                    txtApplnName.Text = dsLead.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";

                    txt_enduse.Text = dsLead.Tables[0].Rows[0]["LD_PD_USE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_PD_USE"].ToString() : "";
                    txtContactNo.Text = dsLead.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
                    txtMemberID.Text = dsLead.Tables[0].Rows[0]["LD_MID"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_MID"].ToString() : "";

                    txtAddress.Text = dsLead.Tables[0].Rows[0]["LD_RADDRESS"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_RADDRESS"].ToString() : "";
                    txtDealer.Text = dsLead.Tables[0].Rows[0]["LVH_NAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LVH_NAME"].ToString() : "";
                    txtModel.Text = dsLead.Tables[0].Rows[0]["LVH_MODEL"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LVH_MODEL"].ToString() : "";
                    txtVehCost.Text = dsLead.Tables[0].Rows[0]["LVH_RATE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LVH_RATE"].ToString() : "";
                  
                    /*bala changes 07/03/2016*/
                    string mfc_code = "";
                    string[] strTWL = dsLead.Tables[0].Rows[0]["LVH_NAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LVH_NAME"].ToString().Split('-') : null;
                    if (strTWL != null)
                    {
                        mfc_code = strTWL[0].ToString();
                    }
                    GetTWLDetails(mfc_code, txtModel.Text);

                    double dblMinAmn = Math.Min(Convert.ToDouble(txtLoanEligibility.Text), Convert.ToDouble(txtLoanAmountRequested.Text));
                    double dblMinAmn1 = Math.Min(dblMinAmn, Convert.ToDouble(txtmaxAmount.Text));
                    txtmarginMoney.Text = Convert.ToString(Convert.ToDouble(txtVehCost.Text) - dblMinAmn1);

                    if (txtmarginMoney.Text != "" && txtLoanEligibility.Text != "")
                    {
                        if (Convert.ToDouble(txtLoanEligibility.Text) >= 25000)
                        {
                            double dblMarginMoney = Convert.ToDouble(txtmarginMoney.Text);
                            double dblDownPayment = Convert.ToDouble(txtAdvEMI.Text) * Convert.ToDouble(txtEMIperLakh.Text) + dblMarginMoney;
                            txtTotDownpayment.Text = dblDownPayment.ToString();
                            

                            //double nLoanreques = Math.Min(Convert.ToDouble(txtLoanEligibility.Text), Convert.ToDouble(txtLoanAmountRequested.Text));
                            txtLoanEligibleLCR.Text = dblMinAmn1.ToString();

                        }
                    }
                    if (txtLTV.Text != "")
                    {
                        txtLoanAmountBasedLTV.Text = ((Convert.ToDouble(txtVehCost.Text) * Convert.ToDouble(txtLTV.Text)) / 100).ToString();
                    }
                    /*End*/


                    /*bala changes*/
                    string empName = dsLead.Tables[0].Rows[0]["EMP_CODE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["EMP_CODE"].ToString() : "";
                    if (empName != "")
                        empName += "-";
                    empName += dsLead.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
                    string empDesignation = dsLead.Tables[0].Rows[0]["ET_DESC"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["ET_DESC"].ToString() : "";
                    if (empName != "" && empDesignation != "")
                        txtEmpDetailes.Text = empName + " " + "(" + empDesignation + ")";
                    /*End*/

                    ddlRelationShip.Focus();
                }
            }
            else
            {
                ddlLeadNo.Items.Clear();
                ddlLeadNo.Items.Insert(0, new ListItem("--Select--", "0"));
                cam_clear();

            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
       


    }
    public void clear()
    {
        // ddlLeadNo.SelectedIndex = 0;
        txtCAMDATE.Text = "";
        FirstGridViewRow();
    }
    protected void ddlMainApplicant_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlMainApplicant.SelectedIndex > 0)
        {

            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);

            cmddd.Parameters.AddWithValue("@VN_ID", "");
            cmddd.Parameters.AddWithValue("@VN_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlVintage.DataSource = dsdd;
            ddlVintage.DataTextField = "VN_DESC";
            ddlVintage.DataValueField = "VN_ID";
            ddlVintage.DataBind();
            ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlNature.Items.Clear();

            con = new SqlConnection(strcon);
            con.Open();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_NATURE", con);
            cmddd.Parameters.AddWithValue("@NT_ID", "");
            //cmddd.Parameters.AddWithValue("@NT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.Parameters.AddWithValue("@NT_TYPE", "T");
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlNature.DataSource = dsdd;
            ddlNature.DataTextField = "NT_DESC";
            ddlNature.DataValueField = "NT_ID";
            ddlNature.DataBind();
            ddlNature.Items.Insert(0, new ListItem("--Select--", "0"));


            ddlIncomType.Items.Clear();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_INCOME_TYPE", con);
            cmddd.Parameters.AddWithValue("@IT_ID", "");
            cmddd.Parameters.AddWithValue("@IT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            //cmddd.Parameters.AddWithValue("@IT_INS_ID", "");
            cmddd.Parameters.AddWithValue("@IT_TYPE", "T");
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlIncomType.DataSource = dsdd;
            ddlIncomType.DataTextField = "IT_DESC";
            ddlIncomType.DataValueField = "IT_ID";
            ddlIncomType.DataBind();
            ddlIncomType.Items.Insert(0, new ListItem("--Select--", "0"));

            con.Close();
        }
    }
  
    protected void ddlCustSource_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtIncome.Text = "";
        txtFactor.Text = "";
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
        cmddd.Parameters.AddWithValue("@CT_ID", "");
        cmddd.Parameters.AddWithValue("@CT_TYPE", "T");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        dtSourceOfIncome = dsdd.Tables[0];
        con.Close();

        if (ddlCustSource.SelectedItem.Text != "--Select--")
        {

            DataRow[] dr = dtSourceOfIncome.Select("CT_DESC='" + ddlCustSource.SelectedItem.Text + "'");

            txtIncomeTaken.Text = dr[0].ItemArray[3].ToString();
        }
    }
    //PMT Calculation
    public static double GetEMI(double presentValue, double financingPeriod, double interestRatePerYear)
    {
        //double dblCal = (presentValue + (presentValue * (financingPeriod / 12) * interestRatePerYear / 100)) / financingPeriod;
        //return dblCal;
        double a, b, x;
        double monthlyPayment;
        a = (1 + interestRatePerYear / 1200);
        b = financingPeriod;
        x = Math.Pow(a, b);
        x = 1 / x;
        x = 1 - x;
        monthlyPayment = (presentValue) * (interestRatePerYear / 1200) / x;
        return (monthlyPayment);
    }
    public static double GetEMI1(double presentValue, double financingPeriod, double interestRatePerYear)
    {
        //interestRatePerYear = 26.00;
        //financingPeriod = 60;
        //presentValue = 100000;
        double a, b, x;
        double monthlyPayment;
        a = (1 + interestRatePerYear / 1200);
        b = financingPeriod;
        x = Math.Pow(a, b);
        x = 1 / x;
        x = 1 - x;
        monthlyPayment = (presentValue) * (interestRatePerYear / 1200) / x;
        return (monthlyPayment);
    }
    public void CalculateLoadELigibility()
    {
        try
        {
            string strval = this.txtTotalEMIAmount.Text;
            double presentValue = txtLoanAmountRequested.Text != "" ?Convert.ToDouble(txtLoanAmountRequested.Text):0.0;
           // presentValue = 100000;
            double financingPeriod = 0.0;
            double interestRatePerYear = 0.0;
            double IIREligibilit = 0.0;
            double FOIREligibility = 0.0;
            double AgriIncome = 0.0;
            int Score = 0;
            int LTV_Percentage = 0;
            if (txtAgriIncome.Text != "")
            {
                AgriIncome = Convert.ToDouble(txtAgriIncome.Text);
            }
            if (ddlTenure.SelectedItem.Text != "")
            {
                financingPeriod = Convert.ToDouble(ddlTenure.SelectedItem.Text) * 12;
            }
            if (ddlIntrest.SelectedItem.Text != "--Select--")
            {
                interestRatePerYear = Convert.ToDouble(ddlIntrest.SelectedItem.Text);
            }
            txtEMIperLakh.Text = Math.Round(GetEMI(presentValue, financingPeriod, interestRatePerYear)).ToString();
            //IIR Eligibilty must be 30% for two wheeler
            IIREligibilit = (((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 30 / 100) / (GetEMI(presentValue, financingPeriod, interestRatePerYear))) * presentValue;
            FOIREligibility = ((((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 50 / 100) - Convert.ToDouble(txtTotalEMIAmount.Text != "" ? txtTotalEMIAmount.Text : "0.0")) / GetEMI(presentValue, financingPeriod, interestRatePerYear)) * presentValue;
            //FOIREligibility =((Convert.ToDouble(txtTotalLoanEligibility.Text) * 50 / 100)- (Convert.ToDouble(txtTotalEMIAmount.Text))/ (GetEMI(presentValue, financingPeriod, interestRatePerYear))) * 100000;

            //IIREligibilit = IIREligibilit + AgriIncome;
            //FOIREligibility = FOIREligibility + AgriIncome;

            txtIIREligibility.Text = Convert.ToInt32(IIREligibilit).ToString();
            txtFOIREligibility.Text = Convert.ToInt32(FOIREligibility).ToString();

            if (IIREligibilit <= FOIREligibility)
            {
                txtLoanEligibility.Text = Convert.ToInt32(IIREligibilit).ToString();

            }
            else if (IIREligibilit > FOIREligibility)
            {
                txtLoanEligibility.Text = Convert.ToInt32(FOIREligibility).ToString();
            }
            else if (IIREligibilit == FOIREligibility)
            {
                txtLoanEligibility.Text = Convert.ToInt32(IIREligibilit).ToString();
            }

            double  dblMinAmn = Math.Min(Convert.ToDouble(txtLoanEligibility.Text), Convert.ToDouble(txtLoanAmountRequested.Text));
            double  dblMinAmn1 =  Math.Min(dblMinAmn, Convert.ToDouble(txtmaxAmount.Text));
            txtmarginMoney.Text = Convert.ToString(Convert.ToDouble(txtVehCost.Text) - dblMinAmn1);

            if (txtmarginMoney.Text != "" && txtLoanEligibility.Text != "")
            {
                if(Convert.ToDouble(txtLoanEligibility.Text) >= 25000)
                {
                    double dblMarginMoney = Convert.ToDouble(txtmarginMoney.Text);
                    double dblDownPayment = Convert.ToDouble(txtAdvEMI.Text) * Convert.ToDouble(txtEMIperLakh.Text) + dblMarginMoney;
                    txtTotDownpayment.Text = dblDownPayment.ToString();
                    btnSubmit.Enabled = true;

                    //double nLoanreques = Math.Min(Convert.ToDouble(txtLoanEligibility.Text), Convert.ToDouble(txtLoanAmountRequested.Text));
                    txtLoanEligibleLCR.Text = dblMinAmn1.ToString();
                   // txtLTV.Text = Convert.ToString(Math.Round(Convert.ToDouble(dblMinAmn1) / Convert.ToDouble(txtVehCost.Text) * 100));

                    Score = (Convert.ToInt32(Session["RO_SCORE"]) + Convert.ToInt32(Session["IT_SCR"]) + Convert.ToInt32(Session["CH_SCR"]));
                    //Score = 90;
                    if((Score>=91)&&(Score<=100))
                    {
                        LTV_Percentage = 80;
                    }
                    else
                        if ((Score >= 81) && (Score <= 90))
                        {
                            LTV_Percentage = 75;
                        }
                        else
                            if ((Score >= 71) && (Score <= 80))
                            {
                                LTV_Percentage = 70;
                            }
                            else
                                if ((Score >= 61) && (Score <= 70))
                                {
                                    LTV_Percentage = 65;
                                }
                                else
                                    if ((Score >= 51) && (Score <= 60))
                                    {
                                        LTV_Percentage = 60;
                                    }
                                    else                                        
                                        {
                                            LTV_Percentage = 0;
                                        }
                    txtLTV.Text = LTV_Percentage.ToString();
                    //IIR Percentage
                    txtIIRPercentage.Text = (Convert.ToDouble(txtEMIperLakh.Text) / Convert.ToDouble(txtTotalLoanEligibility.Text) * 100).ToString("0.00");
                    //FOIR Percentage
                    txtFOIRPercentage.Text = ((Convert.ToDouble(txtEMIperLakh.Text) + Convert.ToDouble(txtTotalEMIAmount.Text != "" ? txtTotalEMIAmount.Text : "0.0")) / Convert.ToDouble(txtTotalLoanEligibility.Text) * 100).ToString("0.00");
                    //Loan amount based on the suggested LTV%
                   //Bala changes txtLoanAmountBasedLTV.Text = ((Convert.ToDouble(txtLoanEligibleLCR.Text) * LTV_Percentage) / 100).ToString();
                    txtLoanAmountBasedLTV.Text = ((Convert.ToDouble(txtVehCost.Text) * LTV_Percentage) / 100).ToString();
                    //check minmum amount as per  loan eligibility and loan amount requested
                    double dblFinalLRAmount = Math.Min(Convert.ToDouble(txtLoanEligibility.Text), Convert.ToDouble(txtLoanAmountRequested.Text));
                    //check minmum amount as per dblFinalLRAmount and Loan Amount Based on Suggessted LTV
                    double dblFinalLRAmount1 = Math.Min(dblFinalLRAmount, Convert.ToDouble(txtLoanAmountBasedLTV.Text));
                    dblFinalLRAmount1 = Math.Min(Convert.ToDouble(txtLoanEligibleLCR.Text), dblFinalLRAmount1);

                    txtFinalLoanRecommend.Text =  Math.Round(dblFinalLRAmount1).ToString();
                   // txtFinalLoanRecommend.Text = ((Convert.ToDouble(txtLoanAmountRequested.Text) * LTV_Percentage) / 100).ToString();
                    
                }
               
            }
            else
            {
                uscMsgBox1.AddMessage("Loan Eligibility should be More than or equal to 25000 ", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtIntestRate_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        CalculateLoadELigibility();
        txtLoanAmountRequested.Focus();
    }
    //protected void ddlAgeOfBuilding_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    if (ddlAgeOfBuilding.SelectedItem.Text != "--Select--")
    //    {
    //        txtDepreciation.Text = ddlAgeOfBuilding.SelectedValue.ToString();
    //        if (txtDepreciation.Text != "" && txtBuildingValue.Text != "")
    //        {

    //            double nVal = 100 - Convert.ToDouble(txtDepreciation.Text);
    //            txtonsideredBuilding.Text = Convert.ToString(Convert.ToInt32(txtBuildingValue.Text) * (nVal / 100));
    //            if (txtConsidered.Text != "")
    //            {
    //                txtTotalPropertyValue.Text = Convert.ToString(Convert.ToInt32(txtonsideredBuilding.Text) + Convert.ToInt32(txtConsidered.Text));
    //                txtLTVonProperty.Text = Convert.ToString(Convert.ToInt32(txtTotalPropertyValue.Text) * 50 / 100);
    //                int nMinVal = 0;
    //                if (txtLoanAmountRequested.Text != "" && txtLoanEligibility.Text != "")
    //                {
    //                    nMinVal = Math.Min(Convert.ToInt32(txtLoanAmountRequested.Text), Convert.ToInt32(txtLoanEligibility.Text));
    //                    nMinVal = Math.Min(Convert.ToInt32(nMinVal), Convert.ToInt32(txtLTVonProperty.Text));
    //                    txtRecommendedLoan.Text = Convert.ToString(RoundDown(nMinVal));
    //                    if (txtRecommendedLoan.Text != "")
    //                    {
    //                        btnSubmit.Enabled = true;
    //                    }
    //                }

    //            }
    //            txtNameofInsuredPerson.Focus();
    //        }

    //    }
    //    else
    //    {
    //        btnSubmit.Enabled = false;
    //        ddlAgeOfBuilding.Focus();
    //    }
    //}
    protected void txtMarketValueSqrt_TextChanged(object sender, EventArgs e)
    {


    }

    public int RoundNum(int num)
    {
        int rem = num % 10;
        return rem >= 5 ? (num - rem + 10) : (num - rem);
    }
    public int RoundDown(int toRound)
    {
        int nValue = 0;

        if (toRound.ToString().Length < 4)
        {
            nValue = toRound - toRound % 10;
        }
        else if (toRound.ToString().Length < 6)
        {
            nValue = toRound - toRound % 100;
        }
        else
        {
            nValue = toRound - toRound % 1000;
        }
        return nValue;
    }




    protected void txtAgriIncome_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        if (ddlIntrest.SelectedItem.Text != "--Select--")
        {
            CalculateLoadELigibility();
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        // InsertCamLapValues();
        InsertDraftCamLapValues("S");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("CAM_TWL.aspx");
    }
 

    public DataTable BindObligationTable()
    {
        DataTable dtObligation = new DataTable();
        DataRow drObligation = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string))); - IR/RL/SEP19/09/556_New Fields Required in RTS CAM Obligation details
        dtObligation.Columns.Add(new DataColumn("CO_TYPE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_FIN", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_TENURE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_LOAN_AMT", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_SOURCE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_BORW", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_AMOUNT", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_BAL_EMI", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_CIBIL", typeof(string)));

        if (txtFinanciear1.Text != "" && drpName1.SelectedItem != null && txtEMIAmount1.Text != "")
        {
            if (drpName1.SelectedItem.Text != "--Select--")
            {

                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear1.Text;
                drObligation["CO_TENURE"] = txtTenure1.Text;
                drObligation["CO_LOAN_AMT"] = txtLoanAMnt1.Text;
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName1.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount1.Text;
                drObligation["CO_BAL_EMI"] = txtBALEMI1.Text;
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }
        }
        if (txtFinanciear2.Text != "" && drpName2.SelectedItem != null && txtEMIAmount2.Text != "")
        {

            if (drpName2.SelectedItem.Text != "--Select--")
            {


                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear2.Text;
                drObligation["CO_TENURE"] = txtTenure2.Text;
                drObligation["CO_LOAN_AMT"] = txtLoanAMnt2.Text;
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName2.SelectedItem.Text;
                /*bala changes 12/01/2016
                drObligation["CO_AMOUNT"] = txtEMIAmount1.Text;
                 End*/
                drObligation["CO_AMOUNT"] = txtEMIAmount2.Text;
                drObligation["CO_BAL_EMI"] = txtBALEMI2.Text;
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }

        }
        if (txtFinanciear3.Text != "" && drpName3.SelectedItem != null && txtEMIAmount3.Text != "")
        {
            if (drpName3.SelectedItem.Text != "--Select--")
            {

                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear3.Text;
                drObligation["CO_TENURE"] = txtTenure3.Text;
                drObligation["CO_LOAN_AMT"] = txtLoanAMnt3.Text;
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName3.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount3.Text;
                drObligation["CO_BAL_EMI"] = txtBALEMI3.Text;
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }

        }
        if (txtFinanciear4.Text != "" && drpName4.SelectedItem != null && txtEMIAmount4.Text != "")
        {
            if (drpName4.SelectedItem.Text != "--Select--")
            {

                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear4.Text;
                drObligation["CO_TENURE"] = txtTenure4.Text;
                drObligation["CO_LOAN_AMT"] = txtLoanAMnt4.Text;
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName4.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount4.Text;
                drObligation["CO_BAL_EMI"] = txtBALEMI4.Text;
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }
        }
        if (txtFinanciear5.Text != "" && drpName5.SelectedItem != null && txtEMIAmount5.Text != "")
        {
            if (drpName5.SelectedItem.Text != "--Select--")
            {


                drObligation = dtObligation.NewRow();
                drObligation["CO_TYPE"] = "";
                drObligation["CO_FIN"] = txtFinanciear5.Text;
                drObligation["CO_TENURE"] = txtTenure5.Text;
                drObligation["CO_LOAN_AMT"] = txtLoanAMnt5.Text;
                drObligation["CO_SOURCE"] = "";

                drObligation["CO_BORW"] = drpName5.SelectedItem.Text;
                drObligation["CO_AMOUNT"] = txtEMIAmount5.Text;
                drObligation["CO_BAL_EMI"] = txtBALEMI5.Text;
                drObligation["CO_CIBIL"] = "";
                dtObligation.Rows.Add(drObligation);
            }
        }
        return dtObligation;
    }
    public DataTable BindCollateralTable()
    {
        DataTable dtCollateral = new DataTable();
        DataRow drCollateral = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));     
        dtCollateral.Columns.Add(new DataColumn("CC_COLAT", typeof(string)));
        dtCollateral.Columns.Add(new DataColumn("CC_AMOUNT", typeof(string)));
        return dtCollateral;
    }
    protected void txtConstrArea_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
    }

  
    public void KYC_details()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_KYC", con);
        cmddd.Parameters.AddWithValue("@LD_ID", ddlLeadNo.SelectedValue.ToString().Trim());
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        DDLkycName.DataSource = dsdd;
        DDLkycName.DataTextField = "KYC_NAME";
        DDLkycName.DataValueField = "KYC_ID";
        DDLkycName.DataBind();
        DDLkycName.Items.Insert(0, new ListItem("--Select--", "0"));
        TBAppType.Text = "";
    }
    public void GetTWLDetails(string mfc_code, string mfc_model)
    {
        try
        {
            DataSet dsdd = new DataSet();
            dsdd = clscomman.Bind_Manufacturer_Details(mfc_code, mfc_model);
            txtMinAmount.Text = dsdd.Tables[0].Rows[0]["MIN AMOUNT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MIN AMOUNT"].ToString() : "";
            txtmaxAmount.Text = dsdd.Tables[0].Rows[0]["MAX AMOUNT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["MAX AMOUNT"].ToString() : "";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Age", con);
        cmddd.Parameters.AddWithValue("@KYC_Name", DDLkycName.SelectedIndex != 0 ? DDLkycName.SelectedItem.Text : "");
        cmddd.Parameters.AddWithValue("@KYC_LD_ID", ddlLeadNo.SelectedIndex != 0 ? ddlLeadNo.SelectedValue : "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();

        if (dsdd.Tables[0].Rows.Count > 0)
        {
            txtCustAge.Text = dsdd.Tables[0].Rows[0][0].ToString();
            TBAppType.Text = dsdd.Tables[0].Rows[0][1] != null ? dsdd.Tables[0].Rows[0][1].ToString() : "0";
        }
        if (DDLkycName.SelectedIndex == 0)
        {
            txtCustAge.Text = "";
        }
    }
    protected void btnCalculate_Click(object sender, EventArgs e)
    {
        try
        {
            double dGuidline = 0.0;
            double dMarketValue = 0.0;
            double dLandArea = 0.0;
            if (txtTotalLoanEligibility.Text == "")
            {
                DDLkycName.Focus();
                uscMsgBox1.AddMessage("Please Add Income Details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
            else if (ddlIntrest.SelectedItem.Text == "--Select--")
            {

                uscMsgBox1.AddMessage("Please Give Intrest Rate value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                ddlIntrest.Focus();
            }
            else
            {
                CalculateLoadELigibility();
              
            }
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
            cmddd.Parameters.AddWithValue("@CT_ID", "");
            cmddd.Parameters.AddWithValue("@CT_TYPE", "T");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            dtSourceOfIncome = dsdd.Tables[0];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtLoanAmountRequested_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
       
    }
    protected void ddlIntrest_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlIntrest.SelectedItem.Text != "--Select--")
        {
            btnSubmit.Enabled = false;
            CalculateLoadELigibility();
            txtLoanAmountRequested.Focus();
        }
        else
        {
            ddlIntrest.Focus();
        }
    }
    protected void btnDraft_Click(object sender, EventArgs e)
    {
        InsertDraftCamLapValues("D");
    }
    protected void InsertDraftCamLapValues(string strType)
    {
        try
        {
            //if (ddlRelationShip.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Relation ship", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            //else 
            //if (ddlMainApplicant.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Main Source of Income", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            //else if (ddlVintage.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Vintage", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
           // else 
            if (ddlLeadNo.SelectedItem.Text == "--Select--")
            {
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select Lead No ');", true);
            }
            //else
            //if (ddlNature.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Nature Of Bussiness/Job", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else if (ddlIncomType.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Income Type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //else if (ddlLoanPurpose.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Loan Purpose", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else if (ddlCreditHistory.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Credit History", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            if (ddlResiOwnership.SelectedItem.Text == "--Select--")
            {
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select residence ownership ');", true);
            }
            else
            {
                DataTable dtIncomeDetails = new DataTable();
                dtIncomeDetails = (DataTable)ViewState["CurrentTable"];
                if (dtIncomeDetails.Columns.Contains("INCOME_SOURCE"))
                {
                    dtIncomeDetails.Columns.Remove("INCOME_SOURCE");
                }
                if (dtIncomeDetails.Columns.Contains("RELATIONSHIP"))
                {
                    dtIncomeDetails.Columns.Remove("RELATIONSHIP");
                }
                if (dtIncomeDetails.Columns.Contains("APP_TYPE"))
                {
                    dtIncomeDetails.Columns.Remove("APP_TYPE");
                }

                DataTable dtObligation = new DataTable();
                dtObligation = BindObligationTable();

                DataTable dtColletral = new DataTable();
                dtColletral = BindCollateralTable();

                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertCAM_New", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@CAM_TYPE", "B");
                //cmdinsert.Parameters.AddWithValue("@CAM_PR_ID", "3");

                //cmdinsert.Parameters.AddWithValue("@CAM_BR_ID", txtBranchName.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LD_ID", ddlLeadNo.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_AP_ADD", txtAddress.Text);
             //   cmdinsert.Parameters.AddWithValue("@CAM_VG_ID", Convert.ToInt32(ddl_village.SelectedValue));
                // cmdinsert.Parameters.AddWithValue("@CAM_VG_ID", ddl_village.SelectedValue.ToString());
              //  cmdinsert.Parameters.AddWithValue("@CAM_SCHEME", ddl_scheme.SelectedValue);
                cmdinsert.Parameters.AddWithValue("@CAM_ER_ID", ddlRelationShip.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_INS_ID", ddlMainApplicant.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_VN_ID", DBNull.Value);
                //cmdinsert.Parameters.AddWithValue("@CAM_NT_ID", ddlNature.SelectedValue.ToString());
                //Bala changes 28/12/2015
                cmdinsert.Parameters.AddWithValue("@CAM_NT_ID", "11");
                cmdinsert.Parameters.AddWithValue("@CAM_IT_ID", ddlIncomType.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_PP_ID", ddlLoanPurpose.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_CH_ID", ddlCreditHistory.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_RO_ID", ddlResiOwnership.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_AGL", txtAgriLandAcres.Text != "" ? Convert.ToDouble(txtAgriLandAcres.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_AGI", txtAgriIncome.Text != "" ? Convert.ToDouble(txtAgriIncome.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_IN", txtTotalLoanEligibility.Text != "" ? Convert.ToDouble(txtTotalLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_EMI", txtTotalEMIAmount.Text != "" ? Convert.ToDouble(txtTotalEMIAmount.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TENURE", ddlTenure.SelectedItem.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_INR", ddlIntrest.SelectedItem.Text != "--Select--" ? Convert.ToDouble(ddlIntrest.SelectedItem.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_EPL", txtEMIperLakh.Text != "" ? Convert.ToDouble(txtEMIperLakh.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_IRR", txtIIREligibility.Text != "" ? Convert.ToDouble(txtIIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_FOIR", txtFOIREligibility.Text != "" ? Convert.ToDouble(txtFOIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LAMT_REQ", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_ELG", txtLoanEligibility.Text != "" ? Convert.ToDouble(txtLoanEligibility.Text) : 0.0);

             //   cmdinsert.Parameters.AddWithValue("@CAM_PT_ID", ddlPropType.SelectedItem.Text.ToString());

                //cmdinsert.Parameters.AddWithValue("@CAM_CS_ID", ddlConstructionStage.SelectedItem.Text.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_CE_ID", ddlConstrType.SelectedItem.Text.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_OC_ID", ddlOccupancyStatus.SelectedValue.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_UG_ID", ddlUsage.SelectedValue.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_NOT", txtNoOFtenents.Text);
                //cmdinsert.Parameters.AddWithValue("@CAM_LAREA", txtLandArea.Text != "" ? Convert.ToDouble(txtLandArea.Text) : 0.0);
                //cmdinsert.Parameters.AddWithValue("@CAM_GLV", txtGuideline.Text != "" ? Convert.ToDouble(txtGuideline.Text) : 0.0);
                //cmdinsert.Parameters.AddWithValue("@CAM_MV", txtMarketValueSqrt.Text != "" ? Convert.ToDouble(txtMarketValueSqrt.Text) : 0.0);
                //cmdinsert.Parameters.AddWithValue("@CAM_CLV", txtConsidered.Text != "" ? Convert.ToDouble(txtConsidered.Text) : 0.0);
                //cmdinsert.Parameters.AddWithValue("@CAM_BAREA", txtConstrArea.Text != "" ? Convert.ToDouble(txtConstrArea.Text) : 0.0);
                //cmdinsert.Parameters.AddWithValue("@CAM_BV", txtBuildingValue.Text != "" ? Convert.ToDouble(txtBuildingValue.Text) : 0.0);
                //cmdinsert.Parameters.AddWithValue("@CAM_BA_ID", ddlAgeOfBuilding.SelectedItem.Text);
                //cmdinsert.Parameters.AddWithValue("@CAM_DEP", txtDepreciation.Text != "" ? Convert.ToDouble(txtDepreciation.Text) : 0.0);
                //cmdinsert.Parameters.AddWithValue("@CAM_CBV", txtConstrCost.Text != "" ? Convert.ToDouble(txtConstrCost.Text) : 0.0);
                //cmdinsert.Parameters.AddWithValue("@CAM_TPV", txtTotalPropCost.Text != "" ? Convert.ToDouble(txtTotalPropCost.Text) : 0.0);

               /*Bala changes 07/01/2016
                * cmdinsert.Parameters.AddWithValue("@CAM_RLA", txtLoanEligibleLCR.Text != "" ? Convert.ToDouble(txtLoanEligibleLCR.Text) : 0.0);*/
                cmdinsert.Parameters.AddWithValue("@CAM_RLA", txtFinalLoanRecommend.Text != "" ? Convert.ToDouble(txtFinalLoanRecommend.Text) : 0.0);

                 cmdinsert.Parameters.AddWithValue("@CAM_LN_LTV", txtLTV.Text != "" ? Convert.ToDouble(txtLTV.Text) : 0.0);
               
                //cmdinsert.Parameters.AddWithValue("@CAM_RLA", txtFinancialLoanAmt.Text != "" ? Convert.ToDouble(txtFinancialLoanAmt.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_IIR_PER", txtIIRPercentage.Text != "" ? Convert.ToDouble(txtIIRPercentage.Text) : 0);
                //cmdinsert.Parameters.AddWithValue("@CAM_LCR_PER", txtFOIRPercentage.Text != "" ? Convert.ToDouble(txtLCRAsPerLoan.Text) : 0.0);
                //cmdinsert.Parameters.AddWithValue("@CAM_IIR_LCR", txtIIRLCR.Text != "" ? Convert.ToDouble(txtIIRLCR.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_Deviation", txtDeviation.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_AEMI", txtAdvEMI.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_PCS", txtNameofInsuredPerson.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_CBY", Session["ID"].ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_MBY", Session["ID"].ToString());

                //if (rdnUrban.Checked == true)
                //{
                //    cmdinsert.Parameters.AddWithValue("@CAM_ATYPE", "Urban");
                //}
                //else if (rdnRural.Checked == true)
                //{
                //    cmdinsert.Parameters.AddWithValue("@CAM_ATYPE", "Rural");
                //}

                if (dtIncomeDetails.Rows.Count > 0)
                {
                    if (dtIncomeDetails.Rows[0][0].ToString() == "")
                    {
                        dtIncomeDetails.Rows.RemoveAt(0);
                    }
                }
                cmdinsert.Parameters.AddWithValue("@tblIncome_Details", dtIncomeDetails);
                cmdinsert.Parameters.AddWithValue("@tblOBLIGATE", dtObligation);
                cmdinsert.Parameters.AddWithValue("@tblCOLLATERAL", dtColletral);
                string strReg = "";
                //if (RadioBtnGV_No.Checked)
                //{
                //    strReg = "N";
                //}
                //else if (RadioBtnGV_Yes.Checked)
                //{
                //    strReg = "Y";
                //}
                cmdinsert.Parameters.AddWithValue("@CAM_Regnet", strReg);
                cmdinsert.Parameters.AddWithValue("@SAVETYPE", strType);

                int n = cmdinsert.ExecuteNonQuery();
                if (n > 0)
                {

                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Saved Successfully');window.location.reload()", true);
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Failed to Save');", true);
                }

                con.Close();
            }



        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void BindDepndsMainAppln()
    {
        if (ddlMainApplicant.SelectedIndex > 0)
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);

            cmddd.Parameters.AddWithValue("@VN_ID", "");
            cmddd.Parameters.AddWithValue("@VN_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlVintage.DataSource = dsdd;
            ddlVintage.DataTextField = "VN_DESC";
            ddlVintage.DataValueField = "VN_ID";
            ddlVintage.DataBind();
            ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));



            ddlNature.Items.Clear();
            con = new SqlConnection(strcon);
            con.Open();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_NATURE", con);
            cmddd.Parameters.AddWithValue("@NT_ID", "");
           // cmddd.Parameters.AddWithValue("@NT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.Parameters.AddWithValue("@NT_TYPE", "T");
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlNature.DataSource = dsdd;
            ddlNature.DataTextField = "NT_DESC";
            ddlNature.DataValueField = "NT_ID";
            ddlNature.DataBind();
            ddlNature.Items.Insert(0, new ListItem("--Select--", "0"));


            ddlIncomType.Items.Clear();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_INCOME_TYPE", con);
            cmddd.Parameters.AddWithValue("@IT_ID", "");
            cmddd.Parameters.AddWithValue("@IT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            //cmddd.Parameters.AddWithValue("@IT_INS_ID", "");
            cmddd.Parameters.AddWithValue("@IT_TYPE", "T");
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlIncomType.DataSource = dsdd;
            ddlIncomType.DataTextField = "IT_DESC";
            ddlIncomType.DataValueField = "IT_ID";
            ddlIncomType.DataBind();
            ddlIncomType.Items.Insert(0, new ListItem("--Select--", "0"));

            con.Close();
        }
    }
    public void FetchCam()
    {
        try
        {
            btnSubmit.Enabled = false;
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_To_Update", con);
            cmddd.Parameters.AddWithValue("@Lead_ID", ddlLeadNo.SelectedValue.ToString());
            cmddd.Parameters.AddWithValue("@CamType", "B");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
            {
                //// Search creteria
                txtBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                //txtLeadNo.Text = dsdd.Tables[0].Rows[0]["LD_NO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_NO"].ToString() : "";
                txtPDDate.Text = dsdd.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
                txt_enduse.Text = dsdd.Tables[0].Rows[0]["LD_PD_USE"] != DBNull.Value ? Convert.ToString(dsdd.Tables[0].Rows[0]["LD_PD_USE"]).ToString() : "";
                txtCAMDATE.Text = dsdd.Tables[0].Rows[0]["CAM_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["CAM_DATE"]).ToString("dd/MMM/yyyy") : DateTime.Now.ToString("dd/MMM/yyyy");
                ddlRelationShip.SelectedValue = dsdd.Tables[0].Rows[0]["ER_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ER_ID"].ToString() : "";
                ddlMainApplicant.SelectedValue = dsdd.Tables[0].Rows[0]["INS_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["INS_ID"].ToString() : "";
                BindDepndsMainAppln();
               // ddlVintage.SelectedValue = dsdd.Tables[0].Rows[0]["VN_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["VN_ID"].ToString() : "";
                //ddlNature.SelectedValue = dsdd.Tables[0].Rows[0]["NT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["NT_ID"].ToString() : "";
                //ddlIncomType.SelectedValue = dsdd.Tables[0].Rows[0]["IT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["IT_ID"].ToString() : "";
               // if (ddlIncomType.Items.Contains(new ListItem("IT_DESC", "IT_ID")))
               // if (ddlIncomType.Items.Contains(new ListItem(Convert.ToString(dsdd.Tables[0].Rows[0]["IT_ID"]))))
                ddlIncomType.SelectedValue = "0";
                if (ddlIncomType.Items.FindByValue(Convert.ToString(dsdd.Tables[0].Rows[0]["IT_ID"]))!=null && ddlIncomType.Items.FindByValue(Convert.ToString(dsdd.Tables[0].Rows[0]["IT_ID"])).Value!="")
                {
                    ddlIncomType.SelectedValue = dsdd.Tables[0].Rows[0]["IT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["IT_ID"].ToString() : "0";
                }
                ddlLoanPurpose.SelectedValue = dsdd.Tables[0].Rows[0]["PP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PP_ID"].ToString() : "0";
                //Bala changes 21/12/2015
                //ddlCreditHistory.SelectedValue = dsdd.Tables[0].Rows[0]["PP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PP_ID"].ToString() : "";
                //ddlCreditHistory.SelectedValue = dsdd.Tables[0].Rows[0]["CH_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_ID"].ToString() : "0";V
                ddlCreditHistory.SelectedValue = "0";
                if (ddlCreditHistory.Items.FindByValue(Convert.ToString(dsdd.Tables[0].Rows[0]["CH_ID"])) != null && ddlCreditHistory.Items.FindByValue(Convert.ToString(dsdd.Tables[0].Rows[0]["CH_ID"])).Value != "")
                //{
               // if (ddlCreditHistory.Items.Contains(new ListItem("CH_DESC", "CH_ID")))
               // if (ddlCreditHistory.Items.Contains(new ListItem(Convert.ToString(dsdd.Tables[0].Rows[0]["CH_ID"]))))
                {
                    ddlCreditHistory.SelectedValue = dsdd.Tables[0].Rows[0]["CH_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_ID"].ToString() : "0";
                }
                txtApplnName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                txtAddress.Text = dsdd.Tables[0].Rows[0]["CAM_AP_ADD"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AP_ADD"].ToString() : "";
                ddlResiOwnership.SelectedValue = dsdd.Tables[0].Rows[0]["RO_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["RO_ID"].ToString() : "0";

                txtContactNo.Text = dsdd.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
                txtMemberID.Text = dsdd.Tables[0].Rows[0]["LD_MID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_MID"].ToString() : "";
                //ddlResiOwnership.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_RO_ID"] != DBNull.Value ? Convert.ToDouble(dsdd.Tables[0].Rows[0]["CAM_RO_ID"]).ToString() : "0";
                ddlTenure.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_TENURE"] != DBNull.Value ? Convert.ToDouble(dsdd.Tables[0].Rows[0]["CAM_TENURE"]).ToString() : "";
                string strIntrest = dsdd.Tables[0].Rows[0]["CAM_INR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_INR"].ToString() : "0";
                //if (strIntrest == "16")
                //{
                //    strIntrest = "16.5";
                //}
                if (strIntrest.Contains("."))
                {
                    ddlIntrest.SelectedValue = strIntrest;
                }
                else
                {
                    ddlIntrest.SelectedValue = Convert.ToInt32(strIntrest).ToString();
                }

                txtLTV.Text = dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
                txtLoanEligibleLCR.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
                //Loan amount based on the LTV%  
               // txtLoanAmountBasedLTV.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
                
                txtFinalLoanRecommend.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";

               /* DataSet dsRO = new DataSet();
                dsRO = clscomman.GetResidencyOwnershipByID(Convert.ToInt32(ddlResiOwnership.SelectedValue));
                Session["RO_SCORE"] = dsRO.Tables[0].Rows[0]["RO_SCORE"] != DBNull.Value ? dsRO.Tables[0].Rows[0]["RO_SCORE"].ToString() : "0";

                DataSet dsIT = new DataSet();
                dsIT = clscomman.GetIncomeTypeByID(Convert.ToInt32(ddlIncomType.SelectedValue));
                Session["IT_SCR"] = dsIT.Tables[0].Rows[0]["IT_SCR"] != DBNull.Value ? dsIT.Tables[0].Rows[0]["IT_SCR"].ToString() : "0";

                DataSet dsCH = new DataSet();
                dsCH = clscomman.GetCreditHistoryByID(Convert.ToInt32(ddlCreditHistory.SelectedValue));
                Session["CH_SCR"] = dsCH.Tables[0].Rows[0]["CH_SCR"] != DBNull.Value ? dsCH.Tables[0].Rows[0]["CH_SCR"].ToString() : "0";*/
                Session["IT_SCR"] =0;
                Session["RO_SCORE"]=0;
                Session["CH_SCR"] = 0;

                DataSet dsRO = new DataSet();
                if (ddlResiOwnership.SelectedIndex > 0)
                {
                    dsRO = clscomman.GetResidencyOwnershipByID(Convert.ToInt32(ddlResiOwnership.SelectedValue));
                    Session["RO_SCORE"] = dsRO.Tables[0].Rows[0]["RO_SCORE"] != DBNull.Value ? dsRO.Tables[0].Rows[0]["RO_SCORE"].ToString() : "0";
                }


                DataSet dsIT = new DataSet();
                if (ddlIncomType.SelectedIndex > 0)
                {
                    dsIT = clscomman.GetIncomeTypeByID(Convert.ToInt32(ddlIncomType.SelectedValue));
                    Session["IT_SCR"] = dsIT.Tables[0].Rows[0]["IT_SCR"] != DBNull.Value ? dsIT.Tables[0].Rows[0]["IT_SCR"].ToString() : "0";
                }

                DataSet dsCH = new DataSet();
                if (ddlCreditHistory.SelectedIndex > 0)
                {
                    dsCH = clscomman.GetCreditHistoryByID(Convert.ToInt32(ddlCreditHistory.SelectedValue));
                    Session["CH_SCR"] = dsCH.Tables[0].Rows[0]["CH_SCR"] != DBNull.Value ? dsCH.Tables[0].Rows[0]["CH_SCR"].ToString() : "0";
                }


                txtEMIperLakh.Text = dsdd.Tables[0].Rows[0]["CAM_EPL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EPL"].ToString() : "";
                txtIIREligibility.Text = dsdd.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_IIR"].ToString() : "";
                txtFOIREligibility.Text = dsdd.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "";
                txtLoanAmountRequested.Text = dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"].ToString() : "";
                txtLoanEligibility.Text = dsdd.Tables[0].Rows[0]["CAM_LN_ELG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LN_ELG"].ToString() : "";

                txtTotalLoanEligibility.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";


                btnSubmit.Enabled = false;

                SqlCommand cmddd1 = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY", con);
                cmddd1.Parameters.AddWithValue("@PT_ID", "");
                cmddd1.Parameters.AddWithValue("@PT_TYPE", "R");
                cmddd1.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter dadd1 = new SqlDataAdapter(cmddd1);
                DataSet dsdd1 = new DataSet();
                dadd1.Fill(dsdd1);




                txtNameofInsuredPerson.Text = dsdd.Tables[0].Rows[0]["CAM_PCS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_PCS"].ToString() : "";

                txtAgriLandAcres.Text = dsdd.Tables[0].Rows[0]["CAM_AGL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGL"].ToString() : "";
                txtAgriIncome.Text = dsdd.Tables[0].Rows[0]["CAM_AGI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGI"].ToString() : "";

                txtDeviation.Text = dsdd.Tables[0].Rows[0]["CAM_DEVIATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_DEVIATE"].ToString() : "";
                if (dsdd.Tables[1] != null && dsdd.Tables[1].Rows.Count > 0)
                {
                    gvIncomeDetail.DataSource = dsdd.Tables[1];
                    gvIncomeDetail.DataBind();
                    BindBorrower(dsdd.Tables[1]);
                    ViewState["CurrentTable"] = dsdd.Tables[1];
                    for (int n = 0; n < dsdd.Tables[1].Rows.Count; n++)
                    {
                        string strText = dsdd.Tables[1].Rows[n]["NAME"].ToString();
                        int nIndex = DDLkycName.Items.IndexOf(DDLkycName.Items.FindByText(strText));

                    }


                }


                if (dsdd.Tables[2] != null && dsdd.Tables[2].Rows.Count > 0)
                {
                    for (int i = 0; i < dsdd.Tables[2].Rows.Count; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                txtFinanciear1.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName1.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                txtEMIAmount1.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtTenure1.Text = dsdd.Tables[2].Rows[i]["CO_TENURE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TENURE"].ToString() : "";
                                txtLoanAMnt1.Text = dsdd.Tables[2].Rows[i]["CO_LOAN_AMT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_LOAN_AMT"].ToString() : "";
                                txtBALEMI1.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                break;
                            case 1:
                                txtFinanciear2.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName2.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                txtEMIAmount2.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtTenure2.Text = dsdd.Tables[2].Rows[i]["CO_TENURE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TENURE"].ToString() : "";
                                txtLoanAMnt2.Text = dsdd.Tables[2].Rows[i]["CO_LOAN_AMT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_LOAN_AMT"].ToString() : "";
                                txtBALEMI2.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                break;
                            case 2:
                                txtFinanciear3.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName3.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                txtEMIAmount3.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtTenure3.Text = dsdd.Tables[2].Rows[i]["CO_TENURE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TENURE"].ToString() : "";
                                txtLoanAMnt3.Text = dsdd.Tables[2].Rows[i]["CO_LOAN_AMT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_LOAN_AMT"].ToString() : "";
                                txtBALEMI3.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                break;
                            case 3:
                                txtFinanciear4.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName4.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                txtEMIAmount4.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtTenure4.Text = dsdd.Tables[2].Rows[i]["CO_TENURE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TENURE"].ToString() : "";
                                txtLoanAMnt4.Text = dsdd.Tables[2].Rows[i]["CO_LOAN_AMT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_LOAN_AMT"].ToString() : "";
                                txtBALEMI4.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                break;
                            case 4:
                                txtFinanciear5.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName5.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                txtEMIAmount5.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtTenure5.Text = dsdd.Tables[2].Rows[i]["CO_TENURE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_TENURE"].ToString() : "";
                                txtLoanAMnt5.Text = dsdd.Tables[2].Rows[i]["CO_LOAN_AMT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_LOAN_AMT"].ToString() : "";
                                txtBALEMI5.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                break;
                        }
                    }
                }

                txtTotalEMIAmount.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";


            }
            con.Close();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void cam_clear()
    {

        txtPDDate.Text = "";
        txtCAMDATE.Text = ""; txtApplnName.Text = ""; txtAddress.Text = ""; txtContactNo.Text = "";
        txtIIRPercentage.Text = "0";
        txtFOIRPercentage.Text = "0";

    }
    protected void ddlResiOwnership_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet dsdd = new DataSet();
            if (ddlResiOwnership.SelectedIndex > 0)
            {
                dsdd = clscomman.GetResidencyOwnershipByID(Convert.ToInt32(ddlResiOwnership.SelectedValue));
                Session["RO_SCORE"] = dsdd.Tables[0].Rows[0]["RO_SCORE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["RO_SCORE"].ToString() : "0";
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlIncomType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet dsdd = new DataSet();
            if (ddlIncomType.SelectedIndex > 0)
            {
                dsdd = clscomman.GetIncomeTypeByID(Convert.ToInt32(ddlIncomType.SelectedValue));
                Session["IT_SCR"] = dsdd.Tables[0].Rows[0]["IT_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["IT_SCR"].ToString() : "0";
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlCreditHistory_SelectedIndexChanged(object sender, EventArgs e)
    {
         try
        {
        DataSet dsdd = new DataSet();
        if (ddlCreditHistory.SelectedIndex > 0)
        {
            dsdd = clscomman.GetCreditHistoryByID(Convert.ToInt32(ddlCreditHistory.SelectedValue));
            Session["CH_SCR"] = dsdd.Tables[0].Rows[0]["CH_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_SCR"].ToString() : "0";
        }
        }
         catch (Exception ex)
         {
             ErrorLog.WriteError(ex);
         }
    }
}