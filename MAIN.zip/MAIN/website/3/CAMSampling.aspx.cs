﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using System.Text;
using Utilities;
using Tracker;


public partial class CAmSampling : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    //string sa;
    int ldid;
    //int j;
    //int b;

    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    string[] stringArray = new string[100];

    public static bool blMailStatus = false;
    public static string frmID = "", toID = "", bccID = "", ccID = "", strMailBody = "";
    public string area = "", brnch = "", ldno = "", prod = "", aname = "";
    int arid;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
            bind();
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        lbLeadno.Text = "";
        lbAppname.Text = "";
        lbPDdate.Text = "";
        lbLoanamt.Text = "";
        string query = "";

        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "All";

        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            ddlArea.Enabled = false;

        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";

        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";

        }
        BindqueryGrid();
        div_position.Value = "0";
        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "method", "ScrollPosition();", true);
    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Sampling", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "C");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvRcvfile.Visible = true;
                //Panel1.Visible = true;
                gvRcvfile.DataSource = ds1.Tables[0];
                gvRcvfile.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvRcvfile.HeaderRow.Font.Bold = true;
                    gvRcvfile.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvRcvfile.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvRcvfile.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    gvRcvfile.HeaderRow.Cells[4].Text = "PD DATE";
                    gvRcvfile.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                    gvRcvfile.HeaderRow.Cells[1].Wrap = false;
                    gvRcvfile.HeaderRow.Cells[2].Wrap = false;
                    gvRcvfile.HeaderRow.Cells[3].Wrap = false;
                    gvRcvfile.HeaderRow.Cells[4].Wrap = false;
                    gvRcvfile.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvRcvfile.Visible = false;
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        //Assumes the Price column is at index 4
        if (e.Row.RowType == DataControlRowType.DataRow)
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();



        foreach (GridViewRow grow in gvRcvfile.Rows)
        {
            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
            LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                leadno = lnbtn.Text;
                appname = gvRcvfile.Rows[index].Cells[3].Text;
                pddt = gvRcvfile.Rows[index].Cells[4].Text;
                lnamt = gvRcvfile.Rows[index].Cells[5].Text;
            }
        }


        lbLeadno.Visible = true;
        lbAppname.Visible = true;
        lbPDdate.Visible = true;
        lbLoanamt.Visible = true;
        //Label1.Visible = true;
        //TextBox10.Visible = true;
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;


        lbLeadno.Text = leadno.ToString();
        lbAppname.Text = appname;
        lbPDdate.Text = pddt;
        lbLoanamt.Text = lnamt;
        con.Close();
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Credit_QueryPopUp.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertUpdateSampling();

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("CAMSampling.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Enabled = false;
    }
    public void InsertUpdateSampling()
    {
        int nCheckStatus = 0;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            string s = "";
            con.Open();
            foreach (GridViewRow grow in gvRcvfile.Rows)
            {
                RadioButton chkStat = grow.FindControl("cb_select") as RadioButton;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    //s += 1;
                    nCheckStatus = 1;
                    Label lblLeadID = (Label)gvRcvfile.Rows[index].Cells[0].FindControl("lblLeadID");

                    ldid = lblLeadID.Text != "" ? Convert.ToInt32(lblLeadID.Text) : 0;
                    Session["CSLDID"] = ldid;
                    s = (gvRcvfile.Rows[index].Cells[0].FindControl("lblldno") as Label).Text;
                    SqlCommand cmdupdate = new SqlCommand("RTS_SP_UpdateSampling", con);
                    cmdupdate.CommandType = CommandType.StoredProcedure;
                    cmdupdate.Parameters.AddWithValue("@SL_LD_ID", ldid);
                    cmdupdate.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                    cmdupdate.ExecuteNonQuery();
                    break;
                }
            }
            if (nCheckStatus != 0)
            {
                //Bala changes 22/12/2015
                sendMail(con);

                string strMailStatus = "";
                string strSuccessMsg = "";
                if (blMailStatus == true)
                {
                    strMailStatus = "Successfully";
                }
                else
                {
                    strMailStatus = "Failed";
                }
                strSuccessMsg = " <br/> Mail Sent " + strMailStatus + "  ";
                strSuccessMsg += "<br/> Mail To: " + toID + " ; CC To: " + ccID + " ";

                BindqueryGrid();
                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
                ddlArea.Enabled = true;
                ddlBranch.Enabled = true;
                txtLeadno.Enabled = true;
                //   btnSubmit.Enabled = false;
                Session["CSLDID"] = null;
                uscMsgBox1.AddMessage(s.ToString() + " Marked for Sampling Successfully " + strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
            else
            {
                uscMsgBox1.AddMessage(s + " Please Select One Input Value to Send/Receive", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("ErrorTo save Sampling Datas", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    public void sendMail(SqlConnection con)
    {
        try
        {
            StringBuilder cmd = new StringBuilder();
            cmd.Append("SELECT 	LD_NO 'LEADNO', LD_APNAME 'APPLICANT',(SELECT PR_NAME FROM MR_PRODUCT WHERE PR_ID=A.LD_PR_ID) 'PRODUCT',C.AR_ID 'AID',C.AR_NAME 'AREA', B.BR_ID 'BID',B.BR_NAME 'BRANCH',(SELECT CONVERT(VARCHAR,SL_DATE,106) FROM LSD_CAM_SAMPLE WHERE A.LD_ID=SL_LD_ID) 'INITIATED DATE' FROM	LSD_LEAD A ");
            cmd.Append(" JOIN MR_BRANCH B ON B.BR_ID=A.LD_BR_ID ");
            cmd.Append(" JOIN MR_AREA  C ON C.AR_ID= B.BR_AR_ID ");
            cmd.Append(" WHERE A.LD_ID=");
            cmd.Append(Session["CSLDID"] != null ? Convert.ToInt32(Session["CSLDID"].ToString()) : 0);


            SqlCommand cmddet = new SqlCommand(cmd.ToString(), con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataTable dtdet = new DataTable();
            dadet.Fill(dtdet);



            if (dtdet.Rows.Count > 0)
            {
                ldno = dtdet.Rows[0]["LEADNO"] != DBNull.Value ? dtdet.Rows[0]["LEADNO"].ToString() : "";
                aname = dtdet.Rows[0]["APPLICANT"] != DBNull.Value ? dtdet.Rows[0]["APPLICANT"].ToString() : "";

                prod = dtdet.Rows[0]["PRODUCT"] != DBNull.Value ? dtdet.Rows[0]["PRODUCT"].ToString() : "";
                area = dtdet.Rows[0]["AREA"] != DBNull.Value ? dtdet.Rows[0]["AREA"].ToString() : "";
                brnch = dtdet.Rows[0]["BRANCH"] != DBNull.Value ? dtdet.Rows[0]["BRANCH"].ToString() : "";
                arid = dtdet.Rows[0]["AID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["AID"].ToString()) : 0;
            }

            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_AREA_MANAGER WHERE AM_AR_ID=");
            cmd.Append(arid);

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtemail = new DataTable();
            dadet.Fill(dtemail);

            toID = "";
            ccID = "";

            if (dtemail.Rows.Count > 0)
            {
                if (dtemail.Rows[0]["AM_OCI"] != "" && dtemail.Rows[0]["AM_OCI"] != DBNull.Value && dtemail.Rows[0]["AM_OCI"].ToString() != "")
                    toID = dtemail.Rows[0]["AM_OCI"].ToString();


                if (dtemail.Rows[0]["AM_SCI"] != "" && dtemail.Rows[0]["AM_SCI"] != DBNull.Value && dtemail.Rows[0]["AM_SCI"].ToString() != "")
                    toID = toID+";" + dtemail.Rows[0]["AM_SCI"].ToString();

                if (dtemail.Rows[0]["AM_CREDIT"] != "" && dtemail.Rows[0]["AM_CREDIT"] != DBNull.Value && dtemail.Rows[0]["AM_CREDIT"].ToString() != "")
                    ccID =dtemail.Rows[0]["AM_CREDIT"].ToString();
               
                if (toID.ToString().StartsWith(";"))
                {
                    toID = toID.Substring(1, toID.Length - 1);
                }
                if (toID.EndsWith(";"))
                {
                    toID = toID.Remove(toID.ToString().Length - 1, 1);
                }

                if (toID == "")
                    toID = "rts-helpdesk@equitasbank.com";

            }
            else
            {
                blMailStatus = false;
                return;
            }



            frmID = "RTS Alerts";


            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

           /* threadSendMails = new System.Threading.Thread(delegate()
            {*/

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Credit Sampling Marked. <br/><br/>";
                BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + ldno + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Area Name</td><td><strong>" + area + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Branch Name</td><td><strong>" + brnch + "</strong></td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + prod + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + aname + "</strong></td><td>Status</td><td><strong> Sampling Marked </strong></td></tr></table><br/>";

                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'>Thanks and Regards,<br/>Credit Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";


                blMailStatus = EmailManager.sendemail(toID, "RTS Alerts", "", ccID, "Lead No. : " + ldno + " - Applicant Name : " + aname + " - Product: " + prod + " - Credit Sampling Marked", BodyTxt, "", true);


           /* });

            threadSendMails.IsBackground = true;

            threadSendMails.Start();
            System.Threading.Thread.Sleep(5000);
*/
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }

    }


}