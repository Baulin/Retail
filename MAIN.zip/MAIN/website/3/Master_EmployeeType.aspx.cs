﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_EmployeeType : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmd = new SqlCommand("select ET_CODE 'EMP. TYPE CODE',ET_DESC 'EMP. TYPE DESCRIPTION' from MR_EMP_TYPE", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvEmptype.DataSource = ds;
        gvEmptype.DataBind();
        if (gvEmptype.Rows.Count > 0)
        {
            gvEmptype.HeaderRow.Font.Bold = true;
            gvEmptype.HeaderRow.Cells[0].Text = "EMP. TYPE CODE";
            gvEmptype.HeaderRow.Cells[1].Text = "EMP. TYPE DESCRIPTION";

            gvEmptype.HeaderRow.Cells[0].Wrap = false;
            gvEmptype.HeaderRow.Cells[1].Wrap = false;
        }
    }
    protected void gvUserInfo_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand insertcmd = new SqlCommand("insert into MR_EMP_TYPE values ('" + txtEmpcode.Text + "','" + txtEmpDescp.Text + "','" + ddlstsourcingtype.SelectedValue + "','" + Session["ID"].ToString() + "',getdate(),'" + Session["ID"].ToString() + "',getdate())", con);
            insertcmd.ExecuteNonQuery();
            bind();
            txtEmpcode.Text = "";
            txtEmpDescp.Text = "";
            uscMsgBox1.AddMessage("Employee Type Added Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_EmployeeType.aspx");
    }
}