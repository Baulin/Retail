﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;
public partial class Branch_NACH_Details_Upload : System.Web.UI.Page
{

    #region Common
    SqlConnection con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_Obj = new SqlCommand();
    DataTable dt_obj = new DataTable();
    CreateLogFiles Err = new CreateLogFiles();
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {


                if (Session["ID"] != null)
                {

                }
                else Response.Redirect("~/Default.aspx");
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnImport_Click(object sender, EventArgs e)
    {

        CSV();
    }


    protected void CSV()
    {
        try
        {
            Page.Validate("ValGroup");
            if (Page.IsValid)
            {
                DataTable dtPck = new DataTable();
                dtPck.Columns.Add("NA_LD_NO", typeof(string));
                dtPck.Columns.Add("NA_BK_CODE", typeof(string));
                dtPck.Columns.Add("NA_ACC_TYPE", typeof(string));
                dtPck.Columns.Add("NA_ACC_NO", typeof(string));
                dtPck.Columns.Add("NA_ACC_HOLDER", typeof(string));
                dtPck.Columns.Add("NA_ACC_PHNO", typeof(string));
                dtPck.Columns.Add("NA_EMI", typeof(string));
                dtPck.Columns.Add("NA_POD_NO", typeof(string));
                dtPck.Columns.Add("NA_COURIER", typeof(string));
                dtPck.Columns.Add("NA_COURIER_DATE", typeof(string));
                dtPck.Columns.Add("NA_CBY", typeof(string));
                dtPck.Columns.Add("NA_CDATE", typeof(string));

                string fileExt = Path.GetExtension(fUpxlRad.PostedFile.FileName);
                string fileName = AppConstants.FileNamePrefix_NACH + DateTime.Now.ToString("dd-MM-yyyy hhmmss") + fileExt;
                string fileUploadPath = ConfigurationManager.AppSettings[AppConstants.FileUploadPath] + "\\" + fileName;
                fUpxlRad.SaveAs(Server.MapPath(fileUploadPath));

                string filePath = Server.MapPath(fileUploadPath);
                StreamReader sr = new StreamReader(filePath);
                string rdLine = sr.ReadLine();
                int i = 0;
                while (!sr.EndOfStream)
                {
                    i++;
                    string content = sr.ReadLine();
                    string[] values = content.Split(new char[] { ',' });
                    DataRow drw = dtPck.NewRow();
                    drw["NA_LD_NO"] = values[0];
                    drw["NA_BK_CODE"] = values[1];
                    drw["NA_ACC_TYPE"] = values[2];
                    drw["NA_ACC_NO"] = values[3];
                    drw["NA_ACC_HOLDER"] = values[4];
                    drw["NA_ACC_PHNO"] = values[5];
                    drw["NA_EMI"] = values[6];
                    drw["NA_POD_NO"] = values[7];
                    drw["NA_COURIER"] = values[8];
                    drw["NA_COURIER_DATE"] = values[9];
                    drw["NA_CBY"] = Convert.ToInt32(Session["ID"]);
                    drw["NA_CDATE"] = DateTime.Now;

                    dtPck.Rows.Add(drw);
                }
                if (dtPck.Rows.Count > 0)
                {                    
                    //string dtes = string.Empty;
                    //for (int j = 0; j <= dtPck.Rows.Count - 1; j++)
                    //{
                    //    string[] dte = dtPck.Rows[j][0].ToString().Split('/');
                    //    dtes = dte[1] + "/" + dte[0] + "/" + dte[2];
                    //    dtPck.Rows[j][0] = dtes;
                    //    dtPck.AcceptChanges();
                    //}
                    con_Obj.Open();
                    cmd_Obj = new SqlCommand("RTS_SP_NACH_INSERT_DETAILS", con_Obj);
                    cmd_Obj.CommandType = CommandType.StoredProcedure;
                    cmd_Obj.CommandTimeout = 240000000;
                    cmd_Obj.Parameters.AddWithValue("@UDT_NA", dtPck);
                    // cmd_Obj.Parameters.AddWithValue("@PKUP_CBY", Convert.ToString(Session["EMPID"]));
                    cmd_Obj.Parameters.AddWithValue("@TYPE", "NAUPLOAD");
                    int res = cmd_Obj.ExecuteNonQuery();
                    // int NA_ID = Convert.ToInt32(cmd_Obj.Parameters["@NA_ID"].Value);
                    if (res > 0)
                    {
                        uscMsgBox1.AddMessage(" Inserted Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else
                    {
                        uscMsgBox1.AddMessage(" Insertion Failed", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    public void CheckType(object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
    {
        bool isValid = true;
        if (fUpxlRad.FileName.Length > 0)
        {
            isValid = false;
            //string iconName = "";
            if (fUpxlRad.Visible & fUpxlRad.HasFile)
            {
                string origName = fUpxlRad.FileName;
                string ext = origName.Substring(origName.LastIndexOf(".")).Replace(".", "");
                if (ext.ToLower() == "csv")
                {
                    isValid = true;
                }
            }
            //else
            //    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('File upload is not an acceptable csv file.');", true);
        }
        args.IsValid = isValid;
    }
    protected void lnkbutton_Click(object sender, EventArgs e)
    {

        try
        {
            // string filePath = (sender as LinkButton).CommandArgument;

            //Response.ContentType = ContentType;
            //Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
            //Response.WriteFile(filePath);
            //Response.End();
            string filename = "~/Images/NA_Upload.csv";
            if (filename != "")
            {
                string path = Server.MapPath(filename);
                System.IO.FileInfo file = new System.IO.FileInfo(path);
                if (file.Exists)
                {
                    Response.Clear();
                    Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
                    Response.AddHeader("Content-Length", file.Length.ToString());
                    Response.ContentType = "application/octet-stream";
                    Response.WriteFile(file.FullName);
                    Response.End();
                }
                else
                {
                    Response.Write("This file does not exist.");
                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}