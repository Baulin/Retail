﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Tracker;

public partial class OCIAllocate : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    //string sa;
    int ldid;
    //int j;
    //int b;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;

    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    string[] stringArray = new string[100];
    public static DataTable dtOCI = null;
 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["AREANAME"] != null)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
                dtOCI = GetOCIList(string.Empty,0.0);
                //if (Session["EMPTYPEID"] != null)
                //{
                //    if (Session["EMPTYPEID"].ToString() == "18")
                //    {
                //        ddlArea.Enabled = false;
                //    }
                //    else
                //    {
                //        ddlArea.Enabled = true;
                //    }
                //}
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }
    }
    public void bind()
    {
       
        //ddlArea.Items.Add(new ListItem(Session["AREANAME"].ToString(), Session["AREA_ID"].ToString()));
     
        //ddlArea.DataBind();
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_State", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@StateID", Session["STATEID"] != null ? Convert.ToInt32( Session["STATEID"]) : 0);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();
      //  SqlConnection con = new SqlConnection(strcon);
        con.Open();

        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
   

    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        lbLeadno.Text = "";
        lbAppname.Text = "";
        lbPDdate.Text = "";
        lbLoanamt.Text = "";
        string query = "";

        if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "All";

        }
        else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";
            ddlArea.Enabled = false;

        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
        {
            Session["View"] = "F";

        }
        else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
        {
            Session["View"] = "F";

        }
        BindqueryGrid();
    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_OCI_Allocation", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "C");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            string strEmpType = Session["TYPE"].ToString();
            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvRcvfile.Visible = true;
                //Panel1.Visible = true
                //DataTable dtTemp = new DataTable();
                //if (strEmpType == "SCI")
                //{
                //    DataRow[] dr = ds1.Tables[0].Select("LD_NO NOT LIKE '%G%'  AND  CASE  SUBSTRING(LD_NO,1,3) WHEN  'EHF' THEN LOAN AMOUNT <=50000  AND CASE  SUBSTRING(LD_NO,1,3) WHEN  'ELP' THEN LOAN AMOUNT <=50000   ");
                //    dtTemp = dr.CopyToDataTable();
                //}
                //else
                //{
                //    dtTemp = ds1.Tables[0];
                //}
              
                
                gvRcvfile.DataSource = ds1.Tables[0];
                gvRcvfile.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvRcvfile.HeaderRow.Font.Bold = true;
                    gvRcvfile.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvRcvfile.HeaderRow.Cells[2].Text = "LEAD DATE";
                    gvRcvfile.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                    gvRcvfile.HeaderRow.Cells[4].Text = "PD DATE";
                    gvRcvfile.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                    gvRcvfile.HeaderRow.Cells[1].Wrap = false;
                    gvRcvfile.HeaderRow.Cells[2].Wrap = false;
                    gvRcvfile.HeaderRow.Cells[3].Wrap = false;
                    gvRcvfile.HeaderRow.Cells[4].Wrap = false;
                    gvRcvfile.HeaderRow.Cells[5].Wrap = false;
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvRcvfile.Visible = false;
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }

    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        //Assumes the Price column is at index 4
        if (e.Row.RowType == DataControlRowType.DataRow)
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
        e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow grow in gvRcvfile.Rows)
            {
                string strLeadNo   =        grow.Cells[1].Text;
                double dblAmount =    Convert.ToDouble(grow.Cells[5].Text);
                dtOCI = GetOCIList(strLeadNo, dblAmount);
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                Label lblBranchID = grow.FindControl("lblBranchID") as Label;
                Label lblLeadID = grow.FindControl("lblLeadID") as Label;
                DropDownList ddlOCIName = grow.FindControl("ddlOCIName") as DropDownList;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    GetAreaID(lblLeadID.Text);
                    if (Session["AREAID"] != null)
                    {
                        DataRow[] dr=null;
                        if (Session["USR_ACS"].ToString() == "4")
                        {

                             dr = dtOCI.Select("AR_DV_ID=" + Session["DIVID"].ToString() + "");
                        }
                        else if (Session["USR_ACS"].ToString() == "5")
                        {
                            dr = dtOCI.Select("BR_AR_ID=" + Session["AREAID"].ToString() + "");
                        }
                        else if (Session["USR_ACS"].ToString() == "3")
                        {
                            dr = dtOCI.Select("DV_ST_ID=" + Session["STATEID"].ToString() + "");
                        }
                        else
                        {
                            dr = dtOCI.Select("BR_AR_ID=" + Session["AREAID"].ToString() + "");
                        }
                       
                      

                       // DataRow[] dr = dtOCI.Select("BR_AR_ID=" + Session["AREAID"].ToString() + "");
                        ddlOCIName.Items.Clear();
                        ddlOCIName.Visible = true;
                        if (dr.Length > 0)
                        {

                            ddlOCIName.DataSource = dr.CopyToDataTable();
                            ddlOCIName.DataTextField = "EMP_NAME";
                            ddlOCIName.DataValueField = "EMP_ID";
                            ddlOCIName.DataBind();
                        }
                        ddlOCIName.Items.Insert(0, "--Select--");

                    }
                    else
                    {
                        Response.Redirect("Default.aspx");
                    }
                }
                else
                {

                    ddlOCIName.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Credit_QueryPopUp.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertUpdateSampling();

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("OCIAllocate.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Enabled = false;
    }
    public void InsertUpdateSampling()
    {
        int nCheckStatus = 0;
        int nUpdateError = 0;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            int s = 0;
            con.Open();
            foreach (GridViewRow grow in gvRcvfile.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    DropDownList ddlOCIName = grow.FindControl("ddlOCIName") as DropDownList;
                    if (ddlOCIName.SelectedItem.Text == "--Select--")
                    {
                        nUpdateError = 1;
                    }
                }
            }
            if(nUpdateError == 0)
            {
                foreach (GridViewRow grow in gvRcvfile.Rows)
                {
                    CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                    int index = grow.RowIndex;
                    if (chkStat.Checked)
                    {
                        s += 1;
                        nCheckStatus = 1;
                        Label lblLeadID = (Label)gvRcvfile.Rows[index].Cells[0].FindControl("lblLeadID");
                        ldid = lblLeadID.Text != "" ? Convert.ToInt32(lblLeadID.Text) : 0;
                        DropDownList ddlOCIName = grow.FindControl("ddlOCIName") as DropDownList;
                        SqlCommand cmdupdate = new SqlCommand("RTS_SP_UpdateOCIAllocate", con);
                        cmdupdate.CommandType = CommandType.StoredProcedure;
                        cmdupdate.Parameters.AddWithValue("@SL_LD_ID", ldid);
                        cmdupdate.Parameters.AddWithValue("@ID", ddlOCIName.SelectedItem.Text != "--Select--" ? ddlOCIName.SelectedValue.ToString() : "");
                        cmdupdate.Parameters.AddWithValue("@SL_MBY",Convert.ToInt32(Session["ID"].ToString()));
                        cmdupdate.ExecuteNonQuery();

                    }
                }
            }
            if (nCheckStatus != 0 )
            {
                BindqueryGrid();
                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
                ddlArea.Enabled = true;
                ddlBranch.Enabled = true;
                txtLeadno.Enabled = true;
                //   btnSubmit.Enabled = false;
                uscMsgBox1.AddMessage(s.ToString() + " Lead/s Booked for Sampling Successfully ", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
            else
            {
                uscMsgBox1.AddMessage( " Please Select  Input Value/s properly for Sample Booking ", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Fail To save Sampling Datas,Please check", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    public DataTable GetOCIList(string strLeadNo,double amount)
    {
       DataTable dt=null;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            string strUsrType = "";
            if (strLeadNo.Contains("G") || (strLeadNo.Contains("EHF") && amount > 500000) || (strLeadNo.Contains("ELP") && amount > 500000))
            {
                strUsrType = "SCI";
            }
            else
            {
                 strUsrType = "OCI";
            }
           
            con.Open();
          //  SqlDataAdapter da = new SqlDataAdapter("select *,MB.BR_AR_ID from MR_EMPLOYEE ME left JOin MR_EMP_TYPE  MET ON MET.ET_ID  =ME.EMP_ET_ID  Left JOIN  MR_BRANCH MB ON ME.EMP_BR_ID =  MB.BR_ID  where MET.ET_DESC='OCI' and ME.EMP_STAT=1 ", con);
            SqlDataAdapter da = new SqlDataAdapter("select *,MB.BR_AR_ID from MR_EMPLOYEE ME left JOin MR_EMP_TYPE  MET ON MET.ET_ID  =ME.EMP_ET_ID  Left JOIN  MR_BRANCH MB ON ME.EMP_BR_ID =  MB.BR_ID   Left JOIN  MR_AREA MA ON MB.BR_AR_ID =  MA.AR_ID  Left JOIN  MR_DIVISION MD  ON MA.AR_DV_ID =  MD.DV_ID where MET.ET_DESC='" + strUsrType + "' and ME.EMP_STAT=1 ", con);
            //SqlDataAdapter da = new SqlDataAdapter("select * from MR_EMPLOYEE where EMP_ET_ID=14 ", con);
            DataSet ds = new DataSet(); 
            da.Fill(ds);
            dt =ds.Tables[0];
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
       
        return dt;
      
    }
    public void GetAreaID(string strLeadID)
    {
        DataTable dt = null;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select MB.BR_AR_ID, MA.AR_DV_ID,MS.ST_ID from LSD_LEAD  LD  left join MR_BRANCH MB ON LD.LD_BR_ID = MB.BR_ID left join MR_AREA MA ON MA.AR_ID = MB.BR_AR_ID  left join MR_STATE MS ON MS.ST_ID = MA.AR_ST_ID  where LD_ID ='" + strLeadID + "' ", con);
            //SqlDataAdapter da = new SqlDataAdapter("select * from MR_EMPLOYEE where EMP_ET_ID=14 ", con);
            DataSet ds = new DataSet(); da.Fill(ds);
            dt = ds.Tables[0];
            Session["AREAID"] = ds.Tables[0].Rows[0][0].ToString();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

       

    }
}