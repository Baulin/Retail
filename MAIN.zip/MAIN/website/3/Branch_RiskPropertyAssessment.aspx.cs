﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Configuration;
using CrystalDecisions.Shared;
using CrystalDecisions.CrystalReports.Engine;
using System.Net.Mail;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Utilities;
using Tracker;
public partial class Branch_RiskPropertyAssessment : System.Web.UI.Page
{
    SqlConnection conObj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmdObj = new SqlCommand();
    SqlDataAdapter dataadap = new SqlDataAdapter();
    DataTable resdt = new DataTable();
    DataTable resdt1 = new DataTable();
    DataTable resdt2 = new DataTable();
    string arid = "";
    string rpa = "";
    static string res,type;

    public static bool blMailStatus = false;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";

    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (Session["TYPE"].ToString() == "FRO")
                {


                    btnsubmitrpa.Visible = false;
                    rfvemp.Enabled = false;
                    txbxdateofvisit.Enabled = false;
                }

                else
                {
                    btnsubmitrpa.Visible = true;
                    rfvemp.Enabled = true;

                    txbxdateofvisit.Enabled = true;
                }

                if (!IsPostBack)
                {


                    Bind_Area();
                    ddlstBranch.Enabled = false;
                    ddlstleadno.Enabled = false;
                    ddlstleadno.Focus();

                    resdt = Get_LeadNo_VisitedBy_ServerDate("SERVDATE");
                    if (resdt.Rows.Count > 0)
                    {

                        hfdservdate.Value = resdt.Rows[0]["SERVER_DATE"] == DBNull.Value ? " " : resdt.Rows[0]["SERVER_DATE"].ToString();
                    }

                 

                    ddlstArea.SelectedValue = arid;
                    ddlstArea_SelectedIndexChanged(sender, e);
                    


                    GetVisitedBy();

                }
            }
            else Response.Redirect("~/Default.aspx");
        }
        catch { }
        finally { }

    }

    protected void btnsubmitrpa_Click(object sender, EventArgs e)
    {
        rpa_click("S");
    }
    protected void btnDraftrpa_Click(object sender, EventArgs e)
    {
        rpa_click("D");

    }
    protected void rpa_click(string type)
    {
        string identifyval = string.Empty;
        string developval = string.Empty;
        string residentialval = string.Empty;
        string unapprovedval = string.Empty;


        try
        {

            System.DateTime serdate = Convert.ToDateTime(hfdservdate.Value);

            DateTime dtdue = Convert.ToDateTime(txtbxrpadate.Text);

            System.DateTime gndate = Convert.ToDateTime(txtbxrpadate.Text);

            if (gndate >= dtdue && gndate <= serdate)
            {
                if (rbtnIdentifyyes.Checked == true)
                    identifyval = "YES";
                else if (rbtnIdentifyno.Checked == true)
                    identifyval = "NO";

                if (rbtndevelopyes.Checked == true)
                    developval = "YES";
                else if (rbtndevelopno.Checked == true)
                    developval = "NO";

                if (rbtnresidentialyes.Checked == true)
                    residentialval = "YES";
                else if (rbtnresidentialno.Checked == true)
                    residentialval = "NO";

                if (rbtnunapprovedyes.Checked == true)
                    unapprovedval = "YES";
                else if (rbtnunapprovedno.Checked == true)
                    unapprovedval = "NO";
                else if (rdounapprovedUnknown.Checked == true)
                    unapprovedval = "NA";

                string landval = "";
                double landarea = 0.0, markval = 0.0,landgval=0.0;
                landgval = txtbxlandgval.Text.Trim() != "" ? Convert.ToDouble(txtbxlandgval.Text) : 0;
                landarea = txtbxlandarea.Text.Trim() != "" ? Convert.ToDouble(txtbxlandarea.Text) : 0;

                markval = txtbxmarketvalue.Text.Trim() != "" ? Convert.ToDouble(txtbxmarketvalue.Text) : 0;
                landval = Convert.ToDouble(landarea * markval).ToString();
                hflandval.Value = landval;



                res = Insert_RPA(Convert.ToInt32(ddlstleadno.SelectedValue), txtbxrpadate.Text.Trim(), txtbxpropertyowner.Text.Trim(), txtbxpropertyaddr.Text.Trim(), ddlstpropertytype.SelectedItem.Text,
                               Convert.ToDouble(landgval), markval, Convert.ToDouble(landarea), Convert.ToDouble(hflandval.Value), identifyval, developval,
                               residentialval, unapprovedval, txtbxref1name.Text.Trim(), txtbxref1addr.Text.Trim(),
                               txtbxref1contactno.Text.Trim(), txtbxref1feedback.Text.Trim(), txtbxref2name.Text.Trim(), txtbxref2addr.Text.Trim(),
                               txtbxref2contactno.Text.Trim(), txtbxref2feedback.Text.Trim(), txtbxrpacomments.Text.Trim(), Convert.ToInt32(ddlstsitevisitedby.SelectedValue), txbxdateofvisit.Text.Trim(), Convert.ToInt32(Session["ID"].ToString()), type);
                if (res.Equals("S") && type == "S")
                {

                    //sendMail();
                    uscMsgBox1.AddMessage("RPA done sucessfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    ClearValuesRPA();
                }
                else if (res.Equals("S") && type == "D")
                {

                    sendMail();
                    uscMsgBox1.AddMessage("RPA drafted sucessfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    ClearValuesRPA();
                }

                else if (res.Equals("F") && type == "S")
                {
                    uscMsgBox1.AddMessage("RPA not done", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                }
                else
                    if (res.Equals("F") && type == "D")
                    {
                        uscMsgBox1.AddMessage("RPA not drfafted please Select site visited by", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                    }
            }

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {


        }
    }

    protected void ClearValuesRPA()
    {
        txtbxpropertyowner.Text = "";
        txtbxpropertyaddr.Text = "";
        ddlstpropertytype.SelectedIndex = 0;

        txtbxlandgval.Text = "";
        txtbxlandarea.Text = "";
        txtbxmarketvalue.Text = "";
        txtbxlandvalue.Text = "";

        rbtnIdentifyyes.Checked = false;
        rbtnIdentifyno.Checked = false;


        rbtnresidentialyes.Checked = false;
        rbtnresidentialno.Checked = false;


        rbtndevelopyes.Checked = false;
        rbtndevelopno.Checked = false;


        rbtnunapprovedyes.Checked = false;
        rbtnunapprovedno.Checked = false;
        rdounapprovedUnknown.Checked = false;

        txbxdateofvisit.Text = "";

        txtbxref1name.Text = "";
        txtbxref1addr.Text = "";
        txtbxref1contactno.Text = "";
        txtbxref1feedback.Text = "";

        txtbxref2name.Text = "";
        txtbxref2addr.Text = "";
        txtbxref2contactno.Text = "";
        txtbxref2feedback.Text = "";
        txtbxrpacomments.Text = "";
        if (ddlstleadno.Items.Count > 0)
            ddlstleadno.SelectedIndex = 0;

        ddlstsitevisitedby.SelectedIndex = 0;
        txtbxapplicantname.Text = "";

        hflandval.Value = "0";

        if (ddlstBranch.Items.Count > 0)
            ddlstBranch.SelectedIndex = 0;
        gv_historyrpa.DataSource = null;
        gv_historyrpa.DataBind();

        // Get_LeadNo();
        Bind_Area();
        GetVisitedBy();
        ddlstArea.Focus();

        txtbxrpadate.Text = "";

    }

    protected DataTable Get_LeadNo_VisitedBy_ServerDate(string passval)
    {
        resdt = new DataTable();
        try
        {

            cmdObj = new SqlCommand("RTS_SP_RPA_LEADNO_VISITED_SERVDATE", conObj);
            cmdObj.CommandType = CommandType.StoredProcedure;
            cmdObj.Parameters.AddWithValue("@PTYPE", passval);
            //if (passval == "FETCHFRO") {
            //    if (ddlstArea.Items.Count > 0)
            //        cmdObj.Parameters.AddWithValue("@BranchName", ddlstArea.SelectedItem.Text != "--Select--" ? ddlstArea.SelectedItem.Text : "");
            //    else
            //        cmdObj.Parameters.AddWithValue("@BranchName", "");

            //}
            //else
            //{

            if (ddlstBranch.Items.Count > 0)
                cmdObj.Parameters.AddWithValue("@BranchName", ddlstBranch.SelectedItem.Text != "--Select--" ? ddlstBranch.SelectedItem.Text : "");
            else
                cmdObj.Parameters.AddWithValue("@BranchName", "");
            // }
            cmdObj.CommandTimeout = 180000;
            if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
                conObj.Open();
            dataadap = new SqlDataAdapter(cmdObj);
            dataadap.Fill(resdt);
            if (resdt.Rows.Count > 0)
                return resdt;
            else
                return resdt;
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Error in Leadno / visitedby retrieval", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
            return resdt;
        }
        finally { conObj.Close(); }
    }
    protected void Get_LeadNo()
    {
        //DataTable tempdt = new DataTable();
        //DataColumn dc = new DataColumn("LEAD_NO");
        //DataColumn dc1 = new DataColumn("LD_ID");
        //dc.DataType = typeof(string);
        //dc1.DataType = typeof(int);
        //tempdt.Columns.Add(dc);
        //tempdt.Columns.Add(dc1);
        //DataRow dr;

        if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
            conObj.Open();
        resdt1 = Get_LeadNo_VisitedBy_ServerDate("FETCHLEADNO");

        //dr = tempdt.NewRow();
        //dr["LEAD_NO"] = "---Select---";
        //dr["LD_ID"] = 0;
        //tempdt.Rows.Add(dr);

        if (resdt1.Rows.Count > 0)
        {


            //foreach (DataRow dtr in resdt1.Rows)
            //{
            //    dr = tempdt.NewRow();
            //    dr["LEAD_NO"] = dtr["LEAD_NO"] == DBNull.Value ? "" : dtr["LEAD_NO"].ToString();
            //    dr["LD_ID"] = dtr["LD_ID"] == DBNull.Value ? 0 : Convert.ToInt32(dtr["LD_ID"].ToString());
            //    tempdt.Rows.Add(dr);
            //}

            ddlstleadno.DataSource = resdt1;
            ddlstleadno.DataTextField = "LEAD_NO";
            ddlstleadno.DataValueField = "LD_ID";


        }
        else
        {
            ddlstleadno.Items.Clear();
        }
        ddlstleadno.DataBind();
        ddlstleadno.Items.Insert(0, new ListItem("--Select--", "0"));

    }

    protected void GetVisitedBy()
    {
        DataTable tempdt = new DataTable();

        DataColumn dc = new DataColumn("EMPLOYEE_NAME");
        DataColumn dc1 = new DataColumn("EMP_ID");
        dc.DataType = typeof(string);
        dc1.DataType = typeof(int);
        tempdt.Columns.Add(dc);
        tempdt.Columns.Add(dc1);

        DataRow dr;
        dr = tempdt.NewRow();
        dr["EMPLOYEE_NAME"] = "---Select---";
        dr["EMP_ID"] = 0;

        tempdt.Rows.Add(dr);
        resdt2 = new DataTable();
        if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
            conObj.Open();
        resdt2 = Get_LeadNo_VisitedBy_ServerDate("FETCHFRO");
        if (resdt2.Rows.Count > 0)
        {
            foreach (DataRow dtr in resdt2.Rows)
            {
                dr = tempdt.NewRow();
                dr["EMPLOYEE_NAME"] = dtr["EMPLOYEE_NAME"] == DBNull.Value ? "" : dtr["EMPLOYEE_NAME"].ToString();
                dr["EMP_ID"] = dtr["EMP_ID"] == DBNull.Value ? 0 : Convert.ToInt32(dtr["EMP_ID"].ToString());
                Session["empid"] = dr["EMP_ID"];
                tempdt.Rows.Add(dr);
            }

            ddlstsitevisitedby.DataSource = tempdt;

            ddlstsitevisitedby.DataBind();
            //if (Session["TYPE"].ToString() == "FRO")
            //{
            //    ddlstsitevisitedby.SelectedValue = Session["EMPID"].ToString();
            //}
        }
    }
    protected DataTable GetBranchDetails(int id)
    {
        resdt = new DataTable();
        try
        {

            cmdObj = new SqlCommand("RTS_SP_EMPLOYEE_BRANCH_NAME", conObj);
            cmdObj.CommandType = CommandType.StoredProcedure;
            cmdObj.Parameters.AddWithValue("@ID", id);
            cmdObj.CommandTimeout = 180000;
            if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
                conObj.Open();
            dataadap = new SqlDataAdapter(cmdObj);
            dataadap.Fill(resdt);
            if (resdt.Rows.Count > 0)
                return resdt;
            else
                return resdt;
        }
        catch
        {
            uscMsgBox1.AddMessage("Error in Branch  Detials retrieval", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            return resdt;
        }
        finally { conObj.Close(); }

    }


    protected DataTable GetApplicantName(string id)
    {
        resdt = new DataTable();
        try
        {

            cmdObj = new SqlCommand("RTS_SP_APPLICANT_NAME", conObj);
            cmdObj.CommandType = CommandType.StoredProcedure;
            
            cmdObj.Parameters.AddWithValue("@LDNO", id);
            dataadap = new SqlDataAdapter(cmdObj);
            dataadap.Fill(resdt);
            if (resdt.Rows.Count > 0)
                return resdt;
            else
                return resdt;
        }
        catch
        {
            uscMsgBox1.AddMessage("Error in Applicant detials retrieval", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            return resdt;
        }
        finally { conObj.Close(); }

    }

    protected string Insert_RPA(int LDID, string RPADATE, string PROPOWNERNAME, string PROPOWNERADDR, string PROPTYPE,
                                double PROPGV, double PROPMV, double PROPAREA, double PROPVALUE,
                                string PLOTIDENTIFY, string PLOTDEVELOP, string PLOTRESIDENT, string PLOTGOVERN,
                                string REF1NAME, string REF1ADDR, string REF1CONTACT, string REF1FBACK,
                                string REF2NAME, string REF2ADDR, string REF2CONTACT, string REF2FBACK, string RMKS,
                                int EMPID, string VDATE, int CID, string type)
    {

        try
        {
            Session["empid"] = EMPID;
            if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
                conObj.Open();

            cmdObj = new SqlCommand("RTS_SP_INSERT_RPA", conObj);
            cmdObj.CommandType = CommandType.StoredProcedure;
            cmdObj.Parameters.AddWithValue("@LDID", LDID);
            cmdObj.Parameters.AddWithValue("@RPADATE", RPADATE);
            cmdObj.Parameters.AddWithValue("@PROPOWNERNAME", PROPOWNERNAME);
            cmdObj.Parameters.AddWithValue("@PROPOWNERADDR ", PROPOWNERADDR);
            cmdObj.Parameters.AddWithValue("@PROPTYPE", PROPTYPE);
            cmdObj.Parameters.AddWithValue("@PROPGV", PROPGV);
            cmdObj.Parameters.AddWithValue("@PROPMV", PROPMV);
            cmdObj.Parameters.AddWithValue("@PROPAREA", PROPAREA);
            cmdObj.Parameters.AddWithValue("@PROPVALUE", PROPVALUE);
            cmdObj.Parameters.AddWithValue("@PLOTIDENTIFY", PLOTIDENTIFY);
            cmdObj.Parameters.AddWithValue("@PLOTDEVELOP", PLOTDEVELOP);
            cmdObj.Parameters.AddWithValue("@PLOTRESIDENT", PLOTRESIDENT);
            cmdObj.Parameters.AddWithValue("@PLOTGOVERN ", PLOTGOVERN);
            cmdObj.Parameters.AddWithValue("@REF1NAME", REF1NAME);
            cmdObj.Parameters.AddWithValue("@REF1ADDR", REF1ADDR);
            cmdObj.Parameters.AddWithValue("@REF1CONTACT", REF1CONTACT);
            cmdObj.Parameters.AddWithValue("@REF1FBACK", REF1FBACK);
            cmdObj.Parameters.AddWithValue("@REF2NAME", REF2NAME);
            cmdObj.Parameters.AddWithValue("@REF2ADDR", REF2ADDR);
            cmdObj.Parameters.AddWithValue("@REF2CONTACT", REF2CONTACT);
            cmdObj.Parameters.AddWithValue("@REF2FBACK", REF2FBACK);
            cmdObj.Parameters.AddWithValue("@RMKS", RMKS);
            cmdObj.Parameters.AddWithValue("@EMPID", EMPID);
            cmdObj.Parameters.AddWithValue("@VDATE", VDATE);
            cmdObj.Parameters.AddWithValue("@CID", CID);
            cmdObj.Parameters.AddWithValue("@RPA", type);
            cmdObj.CommandTimeout = 180000;


            int i = cmdObj.ExecuteNonQuery();
            if (i > 0)
                return "S";
            else
                return "F";
        }
        catch
        {

            return "F";
        }
        finally { conObj.Close(); }
    }
    protected void ddlstsitevisitedby_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlstsitevisitedby.SelectedItem.Text == "---select---") { }
    }

    protected void ddlstleadno_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (ddlstleadno.SelectedIndex > 0)
        {
            if(ddlstleadno.SelectedItem.Text .Contains("MSE"))
            {
                ddlstpropertytype.Items.Remove("Vacant Land");
            }
            else
            {
                if (ddlstpropertytype.Items.FindByText("Vacant Land") == null)
                {
                    ddlstpropertytype.Items.Add("Vacant Land");
                }
                    
            }
            resdt1 = new DataTable();
            if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
                conObj.Open();
            string[] strLeadNO = ddlstleadno.SelectedItem.Text.Split('|');
            resdt1 = GetApplicantName(strLeadNO[0].ToString());
            
             bind_gvIncomeDetail();
            if (resdt1.Rows.Count > 0)
            {
                txtbxapplicantname.Text = resdt1.Rows[0]["APPLICANT_NAME"] == DBNull.Value ? " " : resdt1.Rows[0]["APPLICANT_NAME"].ToString();
                txtbxpropertyaddr.Text = resdt1.Rows[0]["LD_ADDRESS"] == DBNull.Value ? " " : resdt1.Rows[0]["LD_ADDRESS"].ToString();

                txtbxrpadate.Text = resdt1.Rows[0]["RPADATE"] == DBNull.Value ? " " : resdt1.Rows[0]["RPADATE"].ToString();

                txtbxapplicantname.Text = resdt1.Rows[0]["APPLICANT_NAME"] == DBNull.Value ? " " : resdt1.Rows[0]["APPLICANT_NAME"].ToString();
                txtbxpropertyaddr.Text = resdt1.Rows[0]["LD_ADDRESS"] == DBNull.Value ? " " : resdt1.Rows[0]["LD_ADDRESS"].ToString();
                // LEDID = resdt1.Rows[0]["LEAD_ID"] == DBNull.Value ? 0 : Convert.ToInt32(resdt1.Rows[0]["LEAD_ID"].ToString());
                txtbxrpadate.Text = resdt1.Rows[0]["RPADATE"] == DBNull.Value ? " " : resdt1.Rows[0]["RPADATE"].ToString();
                txtbxpropertyowner.Text = resdt1.Rows[0]["RPA_PONAME"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_PONAME"].ToString();
                ddlstpropertytype.SelectedValue = resdt1.Rows[0]["RPA_PTYPE"] == DBNull.Value ? "---Select---" : resdt1.Rows[0]["RPA_PTYPE"].ToString();
                txtbxlandgval.Text = resdt1.Rows[0]["RPA_GV"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_GV"].ToString();
                txtbxmarketvalue.Text = resdt1.Rows[0]["RPA_MV"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_MV"].ToString();
                txtbxlandarea.Text = resdt1.Rows[0]["RPA_LAREA"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_LAREA"].ToString();
                txtbxlandvalue.Text = resdt1.Rows[0]["RPA_LV"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_LV"].ToString();

                if (resdt1.Rows[0]["RPA_IDENTIFY"].ToString() == "YES")
                {
                    rbtnIdentifyyes.Checked = true;
                    rbtnIdentifyyes.Text = "YES";
                    rbtnIdentifyno.Checked = false;
                }
                else if (resdt1.Rows[0]["RPA_IDENTIFY"].ToString() == "NO")
                {
                    rbtnIdentifyno.Text = "NO";
                    rbtnIdentifyno.Checked = true;
                    rbtnIdentifyyes.Checked = false;
                }
                else
                {
                    rbtnIdentifyno.Checked = false;
                    rbtnIdentifyyes.Checked = false;
                }


                if (resdt1.Rows[0]["RPA_DEVELOP"].ToString() == "YES")
                {
                    rbtndevelopyes.Text = "YES";
                    rbtndevelopyes.Checked = true; rbtndevelopno.Checked = false;
                }
                else if (resdt1.Rows[0]["RPA_DEVELOP"].ToString() == "NO")
                {
                    rbtndevelopno.Text = "NO";
                    rbtndevelopno.Checked = true;
                    rbtndevelopyes.Checked = false;
                }
                else
                {
                    rbtndevelopno.Checked = false;
                    rbtndevelopyes.Checked = false;
                }


                if (resdt1.Rows[0]["RPA_RESIDENT"].ToString() == "YES") { rbtnresidentialyes.Checked = true; rbtnresidentialno.Checked = false; }
                else if (resdt1.Rows[0]["RPA_RESIDENT"].ToString() == "NO")
                {
                    rbtnresidentialno.Checked = true;
                    rbtnresidentialyes.Checked = false;
                }
                else
                {
                    rbtnresidentialno.Checked = false;
                    rbtnresidentialyes.Checked = false;
                }


                if (resdt1.Rows[0]["RPA_GOVERN"].ToString() == "YES") { rbtnunapprovedyes.Checked = true; rbtnunapprovedno.Checked = false; rdounapprovedUnknown.Checked = false; } else if (resdt1.Rows[0]["RPA_GOVERN"].ToString() == "NO") { rbtnunapprovedno.Checked = true; rbtnunapprovedyes.Checked = false; rdounapprovedUnknown.Checked = false; } else if (resdt1.Rows[0]["RPA_GOVERN"].ToString() == "NA") { rdounapprovedUnknown.Checked = true; rbtnunapprovedno.Checked = false; rbtnunapprovedyes.Checked = false; } else { rbtnunapprovedyes.Checked = false; rbtnunapprovedno.Checked = false; rdounapprovedUnknown.Checked = false; }


                txtbxref1name.Text = resdt1.Rows[0]["RPA_R1_NAME"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_R1_NAME"].ToString();
                txtbxref1contactno.Text = resdt1.Rows[0]["RPA_R1_CONTACT"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_R1_CONTACT"].ToString();
                txtbxref2name.Text = resdt1.Rows[0]["RPA_R2_NAME"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_R2_NAME"].ToString();
                txtbxref2contactno.Text = resdt1.Rows[0]["RPA_R2_CONTACT"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_R2_CONTACT"].ToString();

                txtbxref1addr.Text = resdt1.Rows[0]["RPA_R1_ADDRESS"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_R1_ADDRESS"].ToString();
                txtbxref1feedback.Text = resdt1.Rows[0]["RPA_R1_FBACK"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_R1_FBACK"].ToString();
                txtbxref2addr.Text = resdt1.Rows[0]["RPA_R2_ADDRESS"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_R2_ADDRESS"].ToString();
                txtbxref2feedback.Text = resdt1.Rows[0]["RPA_R2_FBACK"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_R2_FBACK"].ToString();


                ddlstsitevisitedby.SelectedValue = resdt1.Rows[0]["RPA_EMP_ID"] == DBNull.Value ? "0" : resdt1.Rows[0]["RPA_EMP_ID"].ToString();

                txtbxrpacomments.Text = resdt1.Rows[0]["RPA_REMARKS"] == DBNull.Value ? " " : resdt1.Rows[0]["RPA_REMARKS"].ToString();
            }



        }
        else
        {
            txtbxapplicantname.Text = "";
            txtbxpropertyaddr.Text = "";
            txtbxrpadate.Text = "";
            txtbxrpacomments.Text = "";

        }
    }


    protected void btncancelrpa_Click(object sender, EventArgs e)
    {
        ClearValuesRPA();
        ddlstArea.Focus();
        //  Response.Redirect("Branch_RiskPropertyAssessment.aspx");
    }
    protected void btncancelrpa0_Click(object sender, EventArgs e)
    {

    }
    public void sendMail()
    {
        try
        {
            if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
                conObj.Open();

            /////// mail ///////////
            //  strMailDetail = "";

            SqlCommand cmddet = new SqlCommand("select * from MR_BRANCH where BR_NAME='" + Session["UNITNAME"].ToString() + "'", conObj);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);


            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT * FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", conObj);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                
                to= dsmailto.Tables[0].Rows[0]["EM_RPA"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_RPA"].ToString() : "rts-helpdesk@equitasbank.com";
               //to = "rts-helpdesk@equitasbank.com";
                //cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                //bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                //bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
            }

            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            fromID = "RTS Alerts";
            toID = to;//"ManimaranK@equitasbank.com";
            //bcc2ID = "shankarg@equitasbank.com";
            //ccID = "PalanikumarA@equitasbank.com";
            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

          /*  threadSendMails = new System.Threading.Thread(delegate()
            {*/

                string[] leadno = ddlstleadno.SelectedItem.Text.Split('|');
                //String BodyTxt = "<html><body><basefont face='Calibri'> Dear TRM,<br/><br/> Request for Risk Property Assessment of market value has been made by " + ddlstBranch.SelectedItem.Text + " Branch," + ddlstArea.SelectedItem.Text + " Area <br/>";
                //BodyTxt = BodyTxt + "Please initiate and submit the report as per the prescribed TAT. <br/> Lead No:" + ddlstleadno.SelectedItem.Text + "<br/><br/>Thanks and Regards,<br/>Risk Team<br/><br/> <span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></body></html>";
                string BodyTxt = "<html><body><basefont face='Calibri'> Dear TRM,<br/><br/> <table width='70%' border='1' cellpadding='4' cellspacing='1' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
               BodyTxt = BodyTxt + "<tr><td width='25%'>Lead No:</td><td>" + leadno[0].ToString() + "</td></tr>";
                BodyTxt = BodyTxt + "<tr><td width='25%'>Applicant Name:</td><td>" + txtbxapplicantname.Text + "</td></tr>";
                BodyTxt = BodyTxt + "<tr><td width='25%'>Applicant Property Address</td><td>" + txtbxpropertyaddr.Text + "<br><br></td></tr>";
                BodyTxt = BodyTxt + "<tr><td width='25%'>Field Risk Officer</td><td>" + ddlstsitevisitedby.SelectedItem.Text + "</td></tr> </table><br/>";

                if (res.Equals("S") && type == "S")
                {
                    BodyTxt = BodyTxt + "Please initiate and Submitted the report as per the prescribed TAT. <br/> Lead No:" + leadno[0].ToString() + "<br/><br/>Thanks and Regards,<br/>Risk Team<br/><br/> <span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></body></html>";
                }
                //else if (res.Equals("S") && type == "D")
                else
                {
                   // BodyTxt = BodyTxt + " Drafted by Name  Mr /Mrs ." + ddlstsitevisitedby.SelectedItem.Text + " So please following the RPA case  <br/> Lead No:" + leadno[0].ToString() + "<br/><br/>Thanks and Regards,<br/>Risk Team<br/><br/> <span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></body></html>";
                    BodyTxt = BodyTxt + " Request the TRM to check the correctness <br> and submit for further process.   <br/> <br/><br/>Thanks and Regards,<br/>Risk Team<br/><br/> <span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></body></html>";
                }
                blMailStatus = EmailManager.sendemail(toID, "RTS Alerts", "", "", "RPA done by FRO for LEAD NO: " + leadno[0].ToString() + " " + ddlstBranch.SelectedItem.Text + " Branch", BodyTxt, "", true);


          /*  });

            threadSendMails.IsBackground = true;

            threadSendMails.Start();
            System.Threading.Thread.Sleep(5000);
*/
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }

    }
   
    protected void Bind_Area()
    {
        try
        {

            cmdObj = new SqlCommand("RTS_SP_FETCH_MR_AREA", conObj);
            cmdObj.CommandType = CommandType.StoredProcedure;

            cmdObj.CommandTimeout = 180000;

            resdt = new DataTable();
            if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
                conObj.Open();
            dataadap = new SqlDataAdapter(cmdObj);
            dataadap.Fill(resdt);

            conObj.Close();
            ddlstArea.DataSource = resdt;
            ddlstArea.DataTextField = "AR_NAME";
            ddlstArea.DataValueField = "AR_ID";
            ddlstArea.DataBind();
            ddlstArea.Items.Insert(0, new ListItem("--Select--", "0"));

            DataView tempview = resdt.AsDataView();
            tempview.RowFilter = "AR_NAME = '" + Session["AREANAME"].ToString() + "'";
            arid = tempview.ToTable().Rows[0]["AR_ID"].ToString();
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Error in Area retrieval", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally { }
    }

    protected void ddlstArea_SelectedIndexChanged(object sender, EventArgs e)
    {


        try
        {
            resdt = new DataTable();
            cmdObj = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", conObj);
            cmdObj.CommandType = CommandType.StoredProcedure;
            cmdObj.Parameters.AddWithValue("@AR_NAME", ddlstArea.SelectedItem.ToString() != "--Select--" ? ddlstArea.SelectedItem.ToString() : "");

            cmdObj.CommandTimeout = 180000;

            if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
                conObj.Open();
            dataadap = new SqlDataAdapter(cmdObj);
            dataadap.Fill(resdt);


            ddlstBranch.DataSource = resdt;
            ddlstBranch.DataTextField = "BR_NAME";
            ddlstBranch.DataValueField = "BR_NAME";
            ddlstBranch.DataBind();
            ddlstBranch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlstBranch.Enabled = true;

            if (ddlstArea.SelectedItem.Text == "--Select--")
            {

                ddlstBranch.Enabled = false;
                ddlstleadno.Enabled = false;

                ddlstleadno.SelectedIndex = 0;
                txtbxapplicantname.Text = "";
                txtbxpropertyaddr.Text = "";
                txtbxrpadate.Text = "";
            }
            txtbxapplicantname.Text = "";
            txtbxpropertyaddr.Text = "";
            txtbxrpadate.Text = "";
            ddlstpropertytype.SelectedIndex = 0;

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Error in Branch retrieval", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally { conObj.Close(); }


    }
    protected void ddlstBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        Get_LeadNo();
        GetVisitedBy();
        ddlstleadno.Enabled = true;
        if (ddlstBranch.SelectedItem.Text == "--Select--")
        {
            ddlstleadno.Enabled = false;
            ddlstleadno.SelectedIndex = 0;
            txtbxapplicantname.Text = "";
            txtbxpropertyaddr.Text = "";
            txtbxrpadate.Text = "";
            ddlstpropertytype.SelectedIndex = 0;

        }
        else
        {

        }
        txtbxapplicantname.Text = "";
        txtbxpropertyaddr.Text = "";
        txtbxrpadate.Text = "";
    }

    //senthil

    protected void bind_gvIncomeDetail()
    {

        cmdObj = new SqlCommand("RTS_SP_DE_DUPEMECHANISM", conObj);
        cmdObj.CommandType = CommandType.StoredProcedure;
        cmdObj.Parameters.AddWithValue("@KYC_LD_ID",ddlstleadno.SelectedValue);
        dataadap = new SqlDataAdapter(cmdObj);
        
        DataSet dsdd = new DataSet();
        dataadap.Fill(dsdd);

        gv_historyrpa.DataSource = dsdd;
        gv_historyrpa.DataBind();
        



    }
}