﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class Mobile_Rslvd_Rpt : System.Web.UI.Page
{
    SqlConnection conObj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmdObj = new SqlCommand();
    SqlDataAdapter ap = new SqlDataAdapter();
    DataTable resdt = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            txtbxfrmdt.Attributes.Add("readonly", "readonly");
            txtbxtodt.Attributes.Add("readonly", "readonly");
        }
        else Response.Redirect("Default.aspx");
    }

    protected void btnrparpt_Click(object sender, EventArgs e)
    {
        if (txtbxfrmdt.Text == "")
        {
            uscMsgBox1.AddMessage("Please select the from date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtbxfrmdt.Focus();
            return;
        }
        else if (txtbxtodt.Text == "")
        {
            uscMsgBox1.AddMessage("Please select the to date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtbxtodt.Focus();
            return;
        }
        else if (txtbxfrmdt.Text == "" && txtbxtodt.Text == "")
        {
            uscMsgBox1.AddMessage("Please select the from and to date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtbxfrmdt.Focus();
            return;
        }
        else
        {
            try
            {
                cmdObj = new SqlCommand("LSD_RESOLVED_DETAILS_REP", conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@from", txtbxfrmdt.Text);
                cmdObj.Parameters.AddWithValue("@to", txtbxtodt.Text);
                cmdObj.CommandTimeout = 180000;
                if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
                    conObj.Open();
                ap = new SqlDataAdapter(cmdObj);
                ap.Fill(resdt);
                if (resdt.Rows.Count > 0)
                {
                    //grdvw.DataSource = resdt;
                    //grdvw.DataBind();
                    GenerateExcel(resdt);

                }
                else
                {
                    uscMsgBox1.AddMessage("No Records Found between " + txtbxfrmdt.Text + " and " + txtbxtodt.Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

                    return;
                }

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmdObj.Dispose();
                conObj.Close();

            }
        }

    }

    protected void GenerateExcel(DataTable passdt)
    {
        try
        {
            System.IO.StringWriter tw = new System.IO.StringWriter();
            //System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
            GridView dgGrid = new GridView();
            dgGrid.DataSource = passdt;
            Response.Clear();
            Response.Buffer = true;

            Response.Charset = "";
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("content-disposition", "attachment;filename=Mobile Complaint Resolved Details.xls");
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            dgGrid.AllowPaging = false;
            dgGrid.DataBind();
            //Change the Header Row back to white color
            dgGrid.HeaderRow.Style.Add("background-color", "#FFFFFF");
            dgGrid.HeaderRow.ForeColor = System.Drawing.Color.White;
            DataGrid dg = new DataGrid();
            dg.DataSource = passdt;
            dg.DataBind();
            dgGrid.BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
            for (int z = 0; z < dg.Items[0].Cells.Count; z++)
            {
                //Apply style to Individual Cells
                dgGrid.HeaderRow.Cells[z].Style.Add("background-color", "#7F7F7F");
                dgGrid.HeaderRow.Cells[z].BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                //dgGrid.HeaderRow.Cells[z].Height = 30;
            }
            for (int i = 0; i < dgGrid.Rows.Count; i++)
            {
                GridViewRow row = dgGrid.Rows[i];

                //Change Color back to white
                row.BackColor = System.Drawing.Color.White;

                //Apply text style to each Row
                row.Attributes.Add("class", "textmode");

                //Apply style to Individual Cells of Alternating Row
                for (int s = 0; s < dg.Items[0].Cells.Count; s++)
                {

                    if (i % 2 != 0)
                    {
                        row.Cells[s].Style.Add("background-color", "#f2f2f2");
                        row.Cells[s].BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                        row.Cells[s].ForeColor = System.Drawing.Color.Black;
                        row.Cells[s].Font.Bold = true;
                        row.Cells[s].Font.Size = 10;
                    }
                    else
                    {
                        row.Cells[s].Style.Add("background-color", "#DDD9C3");
                        row.Cells[s].BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                        row.Cells[s].ForeColor = System.Drawing.Color.Black;
                        row.Cells[s].Font.Bold = true;
                        row.Cells[s].Font.Size = 10;
                    }
                }
            }
            dgGrid.RenderControl(hw);
            //style to format numbers to string
            //string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            //Response.Write(style);
            string year = DateTime.Now.AddYears(0).ToString("yyyy");
            string headerTable = @"<Table><tr><th colspan=19 align=left><font face=Calibri size=5 color=#974807> Mobile Complaint Resolved Dettail Report between " + txtbxfrmdt.Text + " and " + txtbxtodt.Text + " </font></th></tr></Table>";
            Response.Write(headerTable);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
}