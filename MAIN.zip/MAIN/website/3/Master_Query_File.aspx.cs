﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_Query_File : System.Web.UI.Page
{
    int areaid;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
               

            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
       
        try{
           con.Open();
            string qry = txtAddress.Text.Trim();
            SqlCommand insertcmd = new SqlCommand(qry, con);
            insertcmd.ExecuteNonQuery();

                btnSubmit.Text = "Submit";
                uscMsgBox1.AddMessage("Success", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
           

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
             con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_Query_File.aspx");
    }
  
}