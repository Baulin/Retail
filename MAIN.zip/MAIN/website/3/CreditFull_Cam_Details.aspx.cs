﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Configuration;
using Tracker;

public partial class CreditFull_Cam_Details : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    DataSet ds = new DataSet();


    string Reportname = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.bt_print);

        if (Session["ID"] != null)
        {
            txtFromDate.Attributes.Add("readonly", "readonly");
            txtToDate.Attributes.Add("readonly", "readonly");
        }
        else Response.Redirect("Default.aspx");
    }
    protected void bt_print_Click(object sender, EventArgs e)
    {
        if (txtFromDate.Text == "")
        {
            uscMsgBox1.AddMessage("Please select the from date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtFromDate.Focus();
            return;
        }
        else if (txtToDate.Text == "")
        {
            uscMsgBox1.AddMessage("Please select the to date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtToDate.Focus();
            return;
        }
        else if (txtFromDate.Text == "" && txtToDate.Text == "")
        {
            uscMsgBox1.AddMessage("Please select the from and to date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtFromDate.Focus();
            return;
        }

        DateTime frm, to;
        frm = DateTime.ParseExact(txtFromDate.Text, "dd MMM yyyy", CultureInfo.InvariantCulture);
        to = DateTime.ParseExact(txtToDate.Text, "dd MMM yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(strcon);
        TimeSpan j = to.Subtract(frm);
        if (j.Days <= 31 && j.Days >= 0)
        {

            try
            {
                con.Open();
                Reportname = ddlmfhfscheme.SelectedItem.Text;
                if (ddlmfhfscheme.SelectedValue == "B")
                {
                    SqlCommand cmd = new SqlCommand("RTS_SP_CREDT_CAMFULLDETAILS", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 300000000;
                    cmd.Parameters.Add("@FROM", DateTime.ParseExact(txtFromDate.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
                    cmd.Parameters.Add("@TO", DateTime.ParseExact(txtToDate.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
                  
                    cmd.Parameters.Add("@CAMTYPE", "B");
                    SqlDataAdapter showdata = new SqlDataAdapter(cmd);

                    showdata.Fill(ds);
                }
                else
                    if (ddlmfhfscheme.SelectedValue == "C")
                    {
                        SqlCommand cmd = new SqlCommand("RTS_SP_CREDT_CAMFULLDETAILS", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 300000000;
                        cmd.Parameters.Add("@FROM", DateTime.ParseExact(txtFromDate.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
                        cmd.Parameters.Add("@TO", DateTime.ParseExact(txtToDate.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
                  
                        cmd.Parameters.Add("@CAMTYPE", "C");
                        SqlDataAdapter showdata = new SqlDataAdapter(cmd);

                        showdata.Fill(ds);
                    }
                    else
                        if (ddlmfhfscheme.SelectedValue == "S")
                        {
                            SqlCommand cmd = new SqlCommand("RTS_SP_CREDT_CAMFULLDETAILS", con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandTimeout = 300000000;
                            cmd.Parameters.Add("@FROM", DateTime.ParseExact(txtFromDate.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
                            cmd.Parameters.Add("@TO", DateTime.ParseExact(txtToDate.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
                  
                            cmd.Parameters.Add("@CAMTYPE", "S");
                            SqlDataAdapter showdata = new SqlDataAdapter(cmd);

                            showdata.Fill(ds);
                        }
                        else
                        {
                            uscMsgBox1.AddMessage("Please select Report", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            ddlmfhfscheme.Focus();
                        }

                if (ds.Tables[0].Rows.Count > 0)
                {
                    GenerateExcel(ds.Tables[0]);
                }
                else
                {
                    uscMsgBox1.AddMessage("No Records Found between " + txtFromDate.Text + " and " + txtToDate.Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    return;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Dispose();
                con.Close();
            }
        }
        else
        {
            uscMsgBox1.AddMessage("You can generate only one month details...", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            return;
        }
    }

    protected void GenerateExcel(DataTable passdt)
    {
        try
        {
            System.IO.StringWriter tw = new System.IO.StringWriter();
            //System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
            GridView dgGrid = new GridView();
            dgGrid.DataSource = passdt;
            Response.Clear();
            Response.Buffer = true;

            Response.Charset = "";
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("content-disposition", "attachment;filename=CAM Details Report.xls");
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            dgGrid.AllowPaging = false;
            dgGrid.DataBind();
            //Change the Header Row back to white color
            dgGrid.HeaderRow.Style.Add("background-color", "#FFFFFF");
            dgGrid.HeaderRow.ForeColor = System.Drawing.Color.White;
            DataGrid dg = new DataGrid();
            dg.DataSource = passdt;
            dg.DataBind();
            dgGrid.BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
            for (int z = 0; z < dg.Items[0].Cells.Count; z++)
            {
                //Apply style to Individual Cells
                dgGrid.HeaderRow.Cells[z].Style.Add("background-color", "#7F7F7F");
                dgGrid.HeaderRow.Cells[z].BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                //dgGrid.HeaderRow.Cells[z].Height = 30;
            }
            for (int i = 0; i < dgGrid.Rows.Count; i++)
            {
                GridViewRow row = dgGrid.Rows[i];

                //Change Color back to white
                row.BackColor = System.Drawing.Color.White;

                //Apply text style to each Row
                row.Attributes.Add("class", "textmode");

                //Apply style to Individual Cells of Alternating Row
                for (int s = 0; s < dg.Items[0].Cells.Count; s++)
                {

                    if (i % 2 != 0)
                    {
                        //  row.Cells[s].Style.Add("background-color", "#f2f2f2");
                        row.Cells[s].BorderColor = System.Drawing.Color.Black;
                        row.Cells[s].ForeColor = System.Drawing.Color.Black;
                        row.Cells[s].Font.Bold = true;
                        row.Cells[s].Font.Size = 10;
                    }
                    else
                    {
                        //row.Cells[s].Style.Add("background-color", "#DDD9C3");
                        row.Cells[s].BorderColor = System.Drawing.Color.Black;
                        row.Cells[s].ForeColor = System.Drawing.Color.Black;
                        row.Cells[s].Font.Bold = true;
                        row.Cells[s].Font.Size = 10;
                    }
                }
            }
            dgGrid.RenderControl(hw);
            //style to format numbers to string
            //string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            //Response.Write(style);
            string year = DateTime.Now.AddYears(0).ToString("yyyy");
            string headerTable = @"<Table><tr><th colspan=19 align=left><font face=Calibri size=5 color=#974807> MFHF Special Scheme between " + txtFromDate.Text + " and " + txtToDate.Text + " </font></th></tr></Table>";
            Response.Write(headerTable);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void btn_Cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("CreditFull_Cam_Details.aspx");
    }
}