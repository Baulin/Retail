﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using System.Net.Mail;
using Tracker;
using Utilities;
public partial class BC_ApplicationForm : System.Web.UI.Page
{  
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string bcc3;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    public static bool blMailStatus = false;
    public static DataTable dtSourceOfIncome = null;
    public static string strLanguagesIDS = "",BCA_CODE="";
    ClsCommon clscommon = new ClsCommon();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                bindArea();
                bindChannels();
            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
    }
    
    public void bindArea()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
            cmddd.CommandType = CommandType.StoredProcedure;
            cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
            {
                cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
            }
            else
            {
                cmddd.Parameters.AddWithValue("@InputVal", 0);
            }
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            con.Close();
            ddlArea.DataSource = dsdd;
            ddlArea.DataTextField = "AR_NAME";
            ddlArea.DataValueField = "AR_ID";
            ddlArea.DataBind();
            ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlArea.SelectedValue = Session["AREA_ID"].ToString();
            bindBranch();

        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    public void bindChannels()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_CHANNELS", con);
            cmddd.CommandType = CommandType.StoredProcedure;
            cmddd.Parameters.AddWithValue("@Type",'C');  // C For Connector D For  DSA
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            con.Close();
            ddlBCSelection.DataSource = dsdd;
            ddlBCSelection.DataTextField = "CHNL_CODE";
            ddlBCSelection.DataValueField = "CHNL_ID";
            ddlBCSelection.DataBind();
           // ddlBCSelection.Items.Insert(0, new ListItem("--Select--", "0"));
           
            //bindBranch();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        

    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
        if (Session["USR_ACS"].ToString() == "5" || Session["USR_ACS"].ToString() == "4" || Session["USR_ACS"].ToString() == "3")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = true;
            ddlArea.Enabled = true;
        }
        if (Session["USR_ACS"].ToString() == "1")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
          
           
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertBCApplicationForm();
    }

    protected void InsertBCApplicationForm()
    {
        DateTime dtd;
        SqlConnection con = new SqlConnection(strcon);   
      
        try
        {

            strLanguagesIDS = "";

            for (int n = 0; n < chkLanguagesKnown.Items.Count; n++)
            {

                if (chkLanguagesKnown.Items[n].Selected)
                {
                    if (strLanguagesIDS == "")
                    {
                        strLanguagesIDS = chkLanguagesKnown.Items[n].Value;
                    }
                    else
                    {
                        if (chkLanguagesKnown.Items[n].Value != "Others")
                        {
                            strLanguagesIDS = strLanguagesIDS + "," + chkLanguagesKnown.Items[n].Value;
                        }
                    }
                }

            }
            //if other languages not equal to blanks
            if (txtOtherlanguages.Text!="")
            {
                strLanguagesIDS = strLanguagesIDS + "," + txtOtherlanguages.Text;
            }
          
            if (rblGender.SelectedIndex == -1)
            {
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Gender');", true);

            }
            else
                if (rblMaritalStatus.SelectedIndex == -1)
                {
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Marital status');", true);

                }
                else
                    if (rblEducation.SelectedIndex == -1)
                    {
                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select educational qualification');", true);

                    }
                    else
                        if (rblProofOfName.SelectedIndex == -1)
                        {
                            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select proof of name');", true);

                        }
                        //else
                        //    if (rbProofOfAddress.SelectedIndex == -1)
                        //    {
                        //        if (chkProofOfAddress.Checked == false)
                        //        {
                        //            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select proof of address');", true);
                        //        }
                        //    }
                            else
                                if (rbPresentOccupation.SelectedIndex == -1)
                                {
                                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select present occupation');", true);

                                }
                                else
                                    if (rbIncomePerMonth.SelectedIndex == -1)
                                    {
                                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select income per month');", true);

                                    }
                                    else
                                        if (rbCompLiteracy.SelectedIndex == -1)
                                        {
                                            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select computer literacy');", true);

                                        }
                                        else

                                            if (rbExpinSelling.SelectedIndex == -1)
                                            {
                                                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select any experience in selling financial products');", true);

                                            }
                                        else

                                            if (chkLanguagesKnown.SelectedIndex == -1)
                                            {
                                                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select languages known');", true);

                                            }
                                            else
                                                if (rbPoliceRecords.SelectedIndex == -1)
                                                {
                                                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select have you any police records');", true);

                                                }
                                        else
                                            if (rbResidentcyOwnProperty.SelectedIndex == -1)
                                            {
                                                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select residence-own property');", true);

                                            }
                                           
                                                
            else
            {
                //else
                //if (rbProofOfAddress.SelectedIndex == -1)
                if ((rbProofOfAddress.SelectedIndex == -1)&&(chkProofOfAddress.Checked == false))
                {
                   
                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select proof of address');", true);
                    
                }
                else
                {

                    con.Open();
                    SqlCommand cmdinsert = new SqlCommand("RTS_SP_Insert_BC_Application", con);
                    cmdinsert.CommandType = CommandType.StoredProcedure;
                    //cmdinsert.Parameters.AddWithValue("@BCA_CODE",txtFullName.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_NAME", txtFullName.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_FHNAME", txtFatherHusbandName.Text);
                    //cmdinsert.Parameters.AddWithValue("@BCA_DOB",Convert.ToDateTime(txtDOB.Text));
                    dtd = DateTime.ParseExact(txtDOB.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    cmdinsert.Parameters.AddWithValue("@BCA_DOB", dtd);
                    // cmdinsert.Parameters.AddWithValue("@BCA_BR_ID", Session["BRANCHID"] != null ? Session["BRANCHID"].ToString() : "0");
                    cmdinsert.Parameters.AddWithValue("@BCA_BR_ID", ddlBranch.SelectedValue);
                    cmdinsert.Parameters.AddWithValue("@BCA_GENDER", rblGender.SelectedItem.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_MARITAL", rblMaritalStatus.SelectedItem.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_EDUCATION", rblEducation.SelectedItem.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_PA_DNO", txtPermanenDoorNo.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_PA_LOC", txtPermanenctLoc.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_PA_PO", txtPermntPO.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_PA_TALUK", txtPermntTehsil.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_PA_DIST", txtPermntDist.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_PA_STATE", txtPermntState.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_PA_PINCODE", txtPermntPinCode.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_CA_DNO", txtCommDoorNo.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_CA_LOC", txtCommnLoc.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_CA_PO", txtCommnPO.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_CA_TALUK", txtCommnTehsil.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_CA_DIST", txtCommnDist.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_CA_STATE", txtCommnState.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_CA_PINCODE", txtCommnPin.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_OWN_PROP", rbResidentcyOwnProperty.SelectedItem.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_YRS_STAY", txtNoofYrsStayInTown.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_RES_PHNO", txtResidenceTelephone.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_OFF_PHNO", txtOfficeTelephone.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_MBL_NO", txtMobileNumber.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_EMAIL_ID", txtEmailId.Text);
                    //Check proof name is if same as proof of address and its number
                    if (txtSameAdRCNumber.Text != "")
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_RC_NO", txtSameAdRCNumber.Text);
                    }
                    else
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_RC_NO", txtRCNumber.Text);
                    }
                   
                   // cmdinsert.Parameters.AddWithValue("@BCA_AC_NO", txtAadharCardNumber.Text);
                    if (txtSameAdAadharCardNumber.Text != "")
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_AC_NO", txtSameAdAadharCardNumber.Text);
                    }
                    else
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_AC_NO", txtAadharCardNumber.Text);
                    }
                    //cmdinsert.Parameters.AddWithValue("@BCA_VI_NO", txtVoterIDNumber.Text);
                    if (txtSameAdVoterIDNumber.Text != "")
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_VI_NO", txtSameAdVoterIDNumber.Text);
                    }
                    else
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_VI_NO", txtVoterIDNumber.Text);
                    }
                   // cmdinsert.Parameters.AddWithValue("@BCA_PP_NO", txtPassportNumber.Text);
                    if (txtSameAdPassportNumber.Text != "")
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_PP_NO", txtSameAdPassportNumber.Text);
                    }
                    else
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_PP_NO", txtPassportNumber.Text);
                    }
                    cmdinsert.Parameters.AddWithValue("@BCA_PC_NO", txtPANCardNumber.Text);

                    //cmdinsert.Parameters.AddWithValue("@BCA_DL_NO", txtDLNumber.Text);
                    if (txtSameAdDLNumber.Text != "")
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_DL_NO", txtSameAdDLNumber.Text);
                    }
                    else
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_DL_NO", txtDLNumber.Text);
                    }
                    cmdinsert.Parameters.AddWithValue("@BCA_IFSC", txtIFSCMICR.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_MICR", txtIFSCMICR.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_BANK", txtCurrentBankWith.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_BANK_BR", txtCurrentBankWith.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_BANK_AC_NO", txtBankAccNo.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_NAME_PROFF", rblProofOfName.SelectedItem.Text);
                    //Check proof name is if same as proof of address 
                    if (chkProofOfAddress.Checked)
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_ADD_PROFF", rbSameProofOfName.SelectedItem.Text);
                    }
                    else
                    {
                        cmdinsert.Parameters.AddWithValue("@BCA_ADD_PROFF", rbProofOfAddress.SelectedItem.Text);
                    }
                    cmdinsert.Parameters.AddWithValue("@BCA_OCCUPATION", rbPresentOccupation.SelectedItem.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_MON_INC", rbIncomePerMonth.SelectedItem.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_COMP_LIT", rbCompLiteracy.SelectedItem.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_SEL_EXPR", rbExpinSelling.SelectedItem.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_SEL_PROD", txtSellingProductDetails.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_LANG_KNW", strLanguagesIDS);
                    cmdinsert.Parameters.AddWithValue("@BCA_POLICE_REC", rbPoliceRecords.SelectedItem.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_POLICE_DET", txtPoliceRecordDetails.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_REF1_NAME", txtReferenceName1.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_REF1_ADDR", txtReferenceAddress1.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_REF1_OCCP", txtRefOccupation1.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_REF1_PHNO", txtRefMobileNo1.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_REF2_NAME", txtReferenceName2.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_REF2_ADDR", txtReferenceAddress2.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_REF2_OCCP", txtRefOccupation2.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_REF2_PHNO", txtRefMobileNo2.Text);
                    cmdinsert.Parameters.AddWithValue("@BCA_CBY", Convert.ToInt32(Session["ID"]));
                    cmdinsert.Parameters.AddWithValue("@BCA_CDATE", DateTime.Now);
                    cmdinsert.Parameters.AddWithValue("@BCA_CHNL_ID",Convert.ToInt32(ddlBCSelection.SelectedValue));
                    cmdinsert.Parameters.AddWithValue("@BCA_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
                    cmdinsert.ExecuteNonQuery();
                    int BCA_ID = Convert.ToInt32(cmdinsert.Parameters["@BCA_ID"].Value);
                    if (BCA_ID != -1 && BCA_ID !=0)
                    {
                       // BCA_CODE = "BC" + BCA_ID.ToString("00000");
                        BCA_CODE = ddlBCSelection.SelectedItem.Text + BCA_ID.ToString("00000");
                            
                        clscommon.UpdateApplicationBCA_CODE(BCA_ID, BCA_CODE);

                         sendBCMail(BCA_CODE);

                       // ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('" + BCA_CODE + " Details has been Saved Successfully.Please note that BC code for your reference.');window.location.reload()", true);


                         uscMsgBox1.AddMessage(BCA_CODE + " Details has been Saved Successfully.Please note that " + ddlBCSelection.SelectedItem.Text + " code for your reference.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

                         clear();
                    }
                    else
                    {
                        //ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('User is already exists in the system. ');", true);
                        uscMsgBox1.AddMessage("User is already exists in the system.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

                    }
                        con.Close();
                    // Response.Redirect(Request.Url.ToString());
                   // clear();
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
  
    public void sendBCMail(string BC_CODE)
     {
         SqlConnection con = new SqlConnection(strcon);
         try
         {
             //DataSet ds = new DataSet();
             //con.Open();
             //SqlCommand cmd = new SqlCommand("select EMP_NAME,EMP_EMAILID,EMP_CODE,USR_EMP_ID,B.USR_UTP_ID from MR_EMPLOYEE A JOIN MR_USER B ON A.EMP_ID=B.USR_EMP_ID WHERE EMP_ID=" + Convert.ToInt32(Session["EMP_ID"]) + " AND B.USR_STAT = 1 ", con);
             //SqlDataAdapter showdata = new SqlDataAdapter(cmd);
             //showdata.Fill(ds);


             SqlCommand cmdmailto = new SqlCommand("SELECT EM_RPA FROM MR_EMAIL where EM_BR_ID='" + ddlBranch.SelectedValue.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
               //to = dsmailto.Tables[0].Rows[0]["EM_RPA"].ToString();
               to = dsmailto.Tables[0].Rows[0]["EM_RPA"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_RPA"].ToString() : "rts-helpdesk@equitasbank.com";

               // to = "balasubramanind@equitasbank.com";
                //cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() + ";" + dsmailto.Tables[0].Rows[0]["EM_CM"].ToString() + ";" + dsmailto.Tables[0].Rows[0]["EM_HO"].ToString();
                cc = "";
               
                cc = cc.Replace("\n", "");
                bcc = "";// dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = "";
                bcc3 ="";
            }
                 //int EMPID = Convert.ToInt32(ds.Tables[0].Rows[0]["USR_EMP_ID"]);
                 string from, subject;
                 
                // Session["R_USR_UTP_ID"] = ds.Tables[0].Rows[0]["USR_EMP_ID"].ToString();
                 subject = "Connectors Code : " + BC_CODE.ToString() + " .";
                 from = "RTS <donotreply@equitasbank.com>";

                 //to = ds.Tables[0].Rows[0]["EM_RPA"].ToString();

                // to = "balasubramanind@equitasbank.com";


                


                 System.Threading.Thread threadSendMails;
                 string BodyTxt = "";
                 //threadSendMails = new System.Threading.Thread(delegate()
                 //{
                     string bcaddress = "";
                     if(txtPermanenDoorNo.Text !="")
                     {
                         bcaddress += txtPermanenDoorNo.Text + ",";
                     }
                     if (txtPermanenctLoc.Text != "")
                     {
                         bcaddress += txtPermanenctLoc.Text + ",";
                     }
                     if (txtPermntPO.Text != "")
                     {
                         bcaddress += txtPermntPO.Text + ",";
                     }
                     if (txtPermntTehsil.Text != "")
                     {
                         bcaddress += txtPermntTehsil.Text + ",";
                     }
                     if (txtPermntDist.Text != "")
                     {
                         bcaddress += txtPermntDist.Text + ",";
                     } 
                     if (txtPermntState.Text != "")
                     {
                         bcaddress += txtPermntState.Text + ",";
                     }
                     if (txtPermntPinCode.Text != "")
                     {
                         bcaddress += txtPermntPinCode.Text + ".";
                     }
                     BodyTxt = "<html><body><basefont face='Calibri'> Dear TRM/FRO,<br/><br/> New Connectors Code has been created for" + ddlBranch.SelectedItem.Text + " Branch<br/><br/>";
                     BodyTxt = BodyTxt + "<table width='40%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                     //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Policy No **</b></td><td style='whiteSpace:nowrap;' ></td></tr>";
                     BodyTxt = BodyTxt + "<tr ><td ><b>Branch ID.</b></td><td style='whiteSpace:nowrap;' >" + Session["BRANCHID"].ToString() + "</td></tr>";
                     BodyTxt = BodyTxt + "<tr><td ><b>Area Name</b></td><td >" + ddlArea.SelectedItem.Text + "</td></tr>";
                     BodyTxt = BodyTxt + "<tr><td ><b>Branch Name</b></td><td >" + ddlBranch.SelectedItem.Text + "</td></tr>";
                     BodyTxt = BodyTxt + "<tr ><td ><b>Reference ID</b></td><td style='whiteSpace:nowrap;' >" + BC_CODE + "</td></tr>";
                     
                     BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Connector Name</b></td><td style='whiteSpace:nowrap;' >"+txtFullName.Text+"</td></tr>";

                     BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Address</b></td><td style='whiteSpace:nowrap;' >" + bcaddress + "</td></tr>";
                     
                     
                     BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Residence Phone</b></td><td style='whiteSpace:nowrap;' >" + txtResidenceTelephone.Text + "</td></tr>";
                     BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Office Phone</b></td><td style='whiteSpace:nowrap;' >" + txtOfficeTelephone.Text + "</td></tr>";
                     //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Created By</b></td><td style='whiteSpace:nowrap;' >" + Session["User"].ToString() + "</td></tr>";
                     BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Created Date</b></td><td style='whiteSpace:nowrap;' >" + DateTime.Now.ToString("dd/MM/yyyy") + "</td></tr>";
                     BodyTxt = BodyTxt + "</table><br/>";

                     BodyTxt = BodyTxt + "<br/>Please do the necessary verification and update in RTS.<br/><br/><br/>";
                     BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'>Thanks and Regards,<br/>RTS Team</td></tr>";
                     BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";


                   EmailManager.sendemail(to, from, "", "", "New Connector Code " + BC_CODE + " has been created in " + ddlBranch.SelectedItem.Text, BodyTxt, "", true);


                 //});

               //  threadSendMails.IsBackground = true;

                //threadSendMails.Start();

                //if (threadSendMails.IsAlive) { Thread.Sleep(7000); }

             }
         
         catch (Exception ex)
         {
             ErrorLog.WriteError(ex);
             // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
         }
         finally { con.Close(); }
     }
    protected void clear()
    {

        try
        {
            txtFullName.Text = "";
            txtFatherHusbandName.Text = "";
            txtDOB.Text = "";
            rblGender.SelectedIndex = -1;
            rblMaritalStatus.SelectedIndex = -1;
            rblEducation.SelectedIndex = -1;
            txtPermanenDoorNo.Text = "";
            txtPermanenctLoc.Text = "";
            txtPermntPO.Text = "";
            txtPermntTehsil.Text = "";
            txtPermntDist.Text = "";
            txtPermntState.Text = "";
            txtPermntPinCode.Text = "";
            txtCommDoorNo.Text = "";
            txtCommnLoc.Text = "";
            txtCommnTehsil.Text = "";
            txtCommnPO.Text = "";
            txtCommnDist.Text = "";
            txtCommnState.Text="";
            txtCommnPin.Text = "";
            rbResidentcyOwnProperty.SelectedIndex = -1;
            txtNoofYrsStayInTown.Text = "";
            txtResidenceTelephone.Text = "";
            txtOfficeTelephone.Text = "";
            txtMobileNumber.Text = "";         
            txtEmailId.Text = "";
            txtRCNumber.Text = "";
            txtAadharCardNumber.Text = "";
            txtVoterIDNumber.Text = "";
            txtPassportNumber.Text = "";
            txtPANCardNumber.Text = "";
            txtDLNumber.Text = "";
            txtIFSCMICR.Text = "";
            txtCurrentBankWith.Text = "";
            txtCurrentBankWith.Text = "";
            txtBankAccNo.Text = "";
            rbProofOfAddress.SelectedIndex = -1;
            rbPresentOccupation.SelectedIndex = -1;
            rbIncomePerMonth.SelectedIndex = -1;
            rbCompLiteracy.SelectedIndex = -1;
            rbExpinSelling.SelectedIndex = -1;
            txtSellingProductDetails.Text = "";           
           // rbPoliceRecords.SelectedValue = "";
            txtPoliceRecordDetails.Text = "";
            txtReferenceName1.Text = "";
            txtReferenceAddress1.Text = "";
            txtRefOccupation1.Text = "";
            txtRefMobileNo1.Text = "";
            txtReferenceName2.Text = "";
            txtReferenceAddress2.Text = "";
            txtRefOccupation2.Text = "";
            txtRefMobileNo2.Text = "";
            txtSellingProductDetails.Text = "";
            txtOtherlanguages.Text = "";
            rbProofOfAddress.SelectedIndex = -1;
            rbPoliceRecords.SelectedIndex = -1;
            chkLanguagesKnown.SelectedIndex = -1;
            rblProofOfName.SelectedIndex = -1;
            dvtxtDLNumber.Visible = false;
            dvtxtPANCardNumber.Visible = false;
            dvtxtPassportNumber.Visible = false;
            dvtxtRCNumber.Visible = false;
            dvtxtVoterIDNumber.Visible = false;
            dvtxtAadharCardNumber.Visible = false;
            txtDLNumber.Text = "";
            txtPANCardNumber.Text = "";
            txtPassportNumber.Text = "";
            txtRCNumber.Text = "";
            txtVoterIDNumber.Text = "";
            txtAadharCardNumber.Text = "";
            reqDLNumber.Enabled = false;
            reqtxtPANCardNumber.Enabled = false;
            reqtxtPassportNumber.Enabled = false;
            reqtxtRCNumber.Enabled = false;
            reqtxtVoterIDNumber.Enabled = false;
            reqtxtAadharCardNumber.Enabled = false;
            chkaddress.Checked = false;
            txtCommDoorNo.Enabled = true;
            txtCommnLoc.Enabled = true;
            txtCommnPO.Enabled = true;
            txtCommnTehsil.Enabled = true;
            txtCommnState.Enabled = true;
            txtCommnDist.Enabled = true;
            txtCommnPin.Enabled = true;
            bindArea();

            chkProofOfAddress.Checked = false;
            chkProofOfAddress.Enabled = true;
            rbSameProofOfName.Visible = false;
            rbProofOfAddress.Enabled = true;

            dvSameAdtxtDLNumber.Visible = false;
            dvSameAdtxtPassportNumber.Visible = false;
            dvtxtSameAdRCNumber.Visible = false;
            dvSameAdtxtVoterIDNumber.Visible = false;
            dvSameAdtxtAadharCardNumber.Visible = false;

            reqSameAdDLNumber.Enabled = false;
            reqtxtSameAdPassportNumber.Enabled = false;
            reqSameAdtxtRCNumber.Enabled = false;
            reqSameAdtxtVoterIDNumber.Enabled = false;
            reqtxtSameAdAadharCardNumber.Enabled = false;
            bindChannels();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            //Check if permanent address is same as communication address
            if (chkaddress.Checked)
            {
                txtCommDoorNo.Text = txtPermanenDoorNo.Text;
                txtCommnLoc.Text = txtPermanenctLoc.Text;
                txtCommnPO.Text = txtPermntPO.Text;
                txtCommnTehsil.Text = txtPermntTehsil.Text;
                txtCommnDist.Text = txtPermntDist.Text;
                txtCommnState.Text = txtPermntState.Text;
                txtCommnPin.Text = txtPermntPinCode.Text;
                txtCommDoorNo.Enabled = false;
                txtCommnLoc.Enabled = false;
                txtCommnPO.Enabled = false;
                txtCommnTehsil.Enabled = false;
                txtCommnState.Enabled = false;
                txtCommnDist.Enabled = false;
                txtCommnPin.Enabled = false;

            }
            else
            {
                txtCommDoorNo.Text = "";
                txtCommnLoc.Text ="";
                txtCommnPO.Text ="";
                txtCommnTehsil.Text = "";
                txtCommnDist.Text = "";
                txtCommnState.Text = "";
                txtCommnPin.Text = "";
                txtCommDoorNo.Enabled = true;
                txtCommnLoc.Enabled = true;
                txtCommnPO.Enabled = true;
                txtCommnTehsil.Enabled = true;
                txtCommnState.Enabled = true;
                txtCommnDist.Enabled = true;
                txtCommnPin.Enabled = true;
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void chkLanguagesKnown_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
           
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    
  
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clear();
    }
    protected void rblProofOfName_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtDLNumber.Text = "";
        txtPANCardNumber.Text = "";
        txtPassportNumber.Text = "";
        txtRCNumber.Text = "";
        txtVoterIDNumber.Text = "";
        txtAadharCardNumber.Text = "";
        chkProofOfAddress.Checked = false;
        chkProofOfAddress.Enabled = true;
        rbSameProofOfName.Visible = false;
        rbProofOfAddress.Enabled = true;

        dvSameAdtxtDLNumber.Visible = false;
        dvSameAdtxtPassportNumber.Visible = false;
        dvtxtSameAdRCNumber.Visible = false;
        dvSameAdtxtVoterIDNumber.Visible = false;
        dvSameAdtxtAadharCardNumber.Visible = false;

        reqSameAdDLNumber.Enabled = false;
        reqtxtSameAdPassportNumber.Enabled = false;
        reqSameAdtxtRCNumber.Enabled = false;
        reqSameAdtxtVoterIDNumber.Enabled = false;
        reqtxtSameAdAadharCardNumber.Enabled = false;

        txtSameAdDLNumber.Text = "";
        txtSameAdPassportNumber.Text = "";
        txtSameAdRCNumber.Text = "";
        txtSameAdVoterIDNumber.Text = "";
        txtSameAdAadharCardNumber.Text = "";
        if(rblProofOfName.SelectedItem.Text=="Driving License")
        {
            dvtxtDLNumber.Visible = true;
            dvtxtPANCardNumber.Visible=false;
                dvtxtPassportNumber.Visible=false;
                dvtxtRCNumber.Visible=false;
                    dvtxtVoterIDNumber.Visible=false;
                    dvtxtAadharCardNumber.Visible = false;

                    reqDLNumber.Enabled = true;
                    reqtxtPANCardNumber.Enabled = false;
                    reqtxtPassportNumber.Enabled = false;
                    reqtxtRCNumber.Enabled = false;
                    reqtxtVoterIDNumber.Enabled = false;
                    reqtxtAadharCardNumber.Enabled = false;

        }
        if (rblProofOfName.SelectedItem.Text == "PAN Card")
        {
            dvtxtDLNumber.Visible = false;
            dvtxtPANCardNumber.Visible = true;
            dvtxtPassportNumber.Visible = false;
            dvtxtRCNumber.Visible = false;
            dvtxtVoterIDNumber.Visible = false;
            dvtxtAadharCardNumber.Visible = false;
            reqDLNumber.Enabled = false;
            reqtxtPANCardNumber.Enabled = true;
            regexPANCardNumber.Enabled = true;
            reqtxtPassportNumber.Enabled = false;
            reqtxtRCNumber.Enabled = false;
            reqtxtVoterIDNumber.Enabled = false;
            reqtxtAadharCardNumber.Enabled = false;
            chkProofOfAddress.Enabled = false;
            rbProofOfAddress.Enabled = true;

        }
        if (rblProofOfName.SelectedItem.Text == "Passport")
        {
            dvtxtDLNumber.Visible = false;
            dvtxtPANCardNumber.Visible = false;
            dvtxtPassportNumber.Visible = true;
            dvtxtRCNumber.Visible = false;
            dvtxtVoterIDNumber.Visible = false;
            dvtxtAadharCardNumber.Visible = false;

            reqDLNumber.Enabled = false;
            reqtxtPANCardNumber.Enabled = false;
            reqtxtPassportNumber.Enabled = true;
            regexPassportNumber.Enabled = true;
            reqtxtRCNumber.Enabled = false;
            reqtxtVoterIDNumber.Enabled = false;
            reqtxtAadharCardNumber.Enabled = false;

        }
        if (rblProofOfName.SelectedItem.Text == "Ration Card")
        {
            dvtxtDLNumber.Visible = false;
            dvtxtPANCardNumber.Visible = false;
            dvtxtPassportNumber.Visible = false;
            dvtxtRCNumber.Visible = true;
            dvtxtVoterIDNumber.Visible = false;
            dvtxtAadharCardNumber.Visible = false;

            reqDLNumber.Enabled = false;
            reqtxtPANCardNumber.Enabled = false;
            reqtxtPassportNumber.Enabled = false;
            reqtxtRCNumber.Enabled = true;
            reqtxtVoterIDNumber.Enabled = false;
            reqtxtAadharCardNumber.Enabled = false;

        }
        if (rblProofOfName.SelectedItem.Text == "Voter's ID")
        {
            dvtxtDLNumber.Visible = false;
            dvtxtPANCardNumber.Visible = false;
            dvtxtPassportNumber.Visible = false;
            dvtxtRCNumber.Visible = false;
            dvtxtVoterIDNumber.Visible = true;
            dvtxtAadharCardNumber.Visible = false;

            reqDLNumber.Enabled = false;
            reqtxtPANCardNumber.Enabled = false;
            reqtxtPassportNumber.Enabled = false;
            reqtxtRCNumber.Enabled = false;
            reqtxtVoterIDNumber.Enabled = true;
            reqtxtAadharCardNumber.Enabled = false;

        }
        if (rblProofOfName.SelectedItem.Text == "Aadhar Card")
        {
            dvtxtDLNumber.Visible = false;
            dvtxtPANCardNumber.Visible = false;
            dvtxtPassportNumber.Visible = false;
            dvtxtRCNumber.Visible = false;
            dvtxtVoterIDNumber.Visible = false;
            dvtxtAadharCardNumber.Visible = true;

            reqDLNumber.Enabled = false;
            regexAadharcardnumber.Enabled = true;
            reqtxtPANCardNumber.Enabled = false;
            reqtxtPassportNumber.Enabled = false;
            reqtxtRCNumber.Enabled = false;
            reqtxtVoterIDNumber.Enabled = false;
            reqtxtAadharCardNumber.Enabled = true;
        }
    }
    protected void rbExpinSelling_SelectedIndexChanged(object sender, EventArgs e)
    {
        if(rbExpinSelling.SelectedValue=="Yes")
        {
            txtSellingProductDetails.Enabled = true;
        }
        else
        {
            txtSellingProductDetails.Enabled = false;
        }
    }
    protected void rbPoliceRecords_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rbPoliceRecords.SelectedValue == "Yes")
        {
            txtPoliceRecordDetails.Enabled = true;
        }
        else
        {
            txtPoliceRecordDetails.Enabled = false;
        }
    }
    protected void chkLanguagesKnown_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string chkLanguage = string.Empty;
            //chkLanguage = chkLanguagesKnown.SelectedItem.Text;
            strLanguagesIDS = "";

            for (int n = 0; n < chkLanguagesKnown.Items.Count; n++)
            {

                if (chkLanguagesKnown.Items[n].Selected)
                {
                    if (strLanguagesIDS == "")
                    {
                        strLanguagesIDS = chkLanguagesKnown.Items[n].Value;
                    }
                    else
                    {
                        strLanguagesIDS = strLanguagesIDS + "," + chkLanguagesKnown.Items[n].Value;
                    }
                }

            }

            //Check if languages selected others
            if (strLanguagesIDS.Contains("Others"))
            {
                dvOtherLanguages.Visible = true;
                reqtxtOtherlanguages.Enabled = true;
            }
            else
            {
                dvOtherLanguages.Visible = false;
                reqtxtOtherlanguages.Enabled = false;
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
           
    }
    protected void txtPassportNumber_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtPANCardNumber_TextChanged(object sender, EventArgs e)
    {

    }
    protected void chkProofOfAddress_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            //Check if proof of address same as the proof of the name

            if (rblProofOfName.SelectedIndex != -1)
            {
                if (chkProofOfAddress.Checked)
                {
                    rbProofOfAddress.Enabled = false;
                    rbSameProofOfName.Visible = true;
                  //  rbSameProofOfName.Enabled = false;
                    //Bala changes 07042016
                    rbSameProofOfName.Enabled = true;
                    rbProofOfAddress.SelectedIndex = -1;


                    txtSameAdDLNumber.Text = "";
                    txtSameAdPassportNumber.Text = "";
                    txtSameAdRCNumber.Text = "";
                    txtSameAdVoterIDNumber.Text = "";
                    txtSameAdAadharCardNumber.Text = "";

                    if (rblProofOfName.SelectedItem.Text == "Driving License")
                    {

                        rbSameProofOfName.SelectedValue = "Driving License";
                        dvSameAdtxtDLNumber.Visible = true;
                        dvSameAdtxtPassportNumber.Visible = false;
                        dvtxtSameAdRCNumber.Visible = false;
                        dvSameAdtxtVoterIDNumber.Visible = false;
                        dvSameAdtxtAadharCardNumber.Visible = false;

                        reqSameAdDLNumber.Enabled = true;
                        reqtxtSameAdPassportNumber.Enabled = false;
                        reqSameAdtxtRCNumber.Enabled = false;
                        reqSameAdtxtVoterIDNumber.Enabled = false;
                        reqtxtSameAdAadharCardNumber.Enabled = false;

                       // txtSameAdDLNumber.Text = txtDLNumber.Text;
                       // if (rblProofOfName.SelectedItem.Text == "Driving License")
                      //  {
                            txtSameAdDLNumber.Text = txtDLNumber.Text;
                            //txtSameAdDLNumber.Enabled = false;
                        //}

                    }
                   
                    if (rblProofOfName.SelectedItem.Text == "Passport")
                    {

                        rbSameProofOfName.SelectedValue = "Passport";
                        dvSameAdtxtDLNumber.Visible = false;
                        dvSameAdtxtPassportNumber.Visible = true;
                        dvtxtSameAdRCNumber.Visible = false;
                        dvSameAdtxtVoterIDNumber.Visible = false;
                        dvSameAdtxtAadharCardNumber.Visible = false;

                        reqSameAdDLNumber.Enabled = false;
                        reqtxtSameAdPassportNumber.Enabled = true;
                        reqSameAdtxtRCNumber.Enabled = false;
                        reqSameAdtxtVoterIDNumber.Enabled = false;
                        reqtxtSameAdAadharCardNumber.Enabled = false;

                        txtSameAdPassportNumber.Text = txtPassportNumber.Text;

                       // txtSameAdPassportNumber.Enabled = false;

                    }
                    if (rblProofOfName.SelectedItem.Text == "Ration Card")
                    {
                        rbSameProofOfName.SelectedValue = "Ration Card";

                        dvSameAdtxtDLNumber.Visible = false;
                        dvSameAdtxtPassportNumber.Visible = false;
                        dvtxtSameAdRCNumber.Visible = true;
                        dvSameAdtxtVoterIDNumber.Visible = false;
                        dvSameAdtxtAadharCardNumber.Visible = false;

                        reqSameAdDLNumber.Enabled = false;
                        reqtxtSameAdPassportNumber.Enabled = false;
                        reqSameAdtxtRCNumber.Enabled = true;
                        reqSameAdtxtVoterIDNumber.Enabled = false;
                        reqtxtSameAdAadharCardNumber.Enabled = false;

                        txtSameAdRCNumber.Text = txtRCNumber.Text;

                     //   txtSameAdRCNumber.Enabled = false;

                    }
                    if (rblProofOfName.SelectedItem.Text == "Voter's ID")
                    {

                        rbSameProofOfName.SelectedValue = "Voter's ID";
                        dvSameAdtxtDLNumber.Visible = false;
                        dvSameAdtxtPassportNumber.Visible = false;
                        dvtxtSameAdRCNumber.Visible = false;
                        dvSameAdtxtVoterIDNumber.Visible = true;
                        dvSameAdtxtAadharCardNumber.Visible = false;

                        reqSameAdDLNumber.Enabled = false;
                        reqtxtSameAdPassportNumber.Enabled = false;
                        reqSameAdtxtRCNumber.Enabled = false;
                        reqSameAdtxtVoterIDNumber.Enabled = true;
                        reqtxtSameAdAadharCardNumber.Enabled = false;

                        txtSameAdVoterIDNumber.Text = txtVoterIDNumber.Text;
                       // txtSameAdVoterIDNumber.Enabled = false;
                    }
                    if (rblProofOfName.SelectedItem.Text == "Aadhar Card")
                    {
                        rbSameProofOfName.SelectedValue = "Aadhar Card";
                        dvSameAdtxtDLNumber.Visible = false;
                        dvSameAdtxtPassportNumber.Visible = false;
                        dvtxtSameAdRCNumber.Visible = false;
                        dvSameAdtxtVoterIDNumber.Visible = false;
                        dvSameAdtxtAadharCardNumber.Visible = true;

                        reqSameAdDLNumber.Enabled = false;
                        reqtxtSameAdPassportNumber.Enabled = false;
                        reqSameAdtxtRCNumber.Enabled = false;
                        reqSameAdtxtVoterIDNumber.Enabled = false;
                        reqtxtSameAdAadharCardNumber.Enabled = true;

                        txtSameAdAadharCardNumber.Text = txtAadharCardNumber.Text;
                       // txtSameAdAadharCardNumber.Enabled = false;
                    }

                }
                else
                {
                    rbProofOfAddress.Enabled = true;
                    rbSameProofOfName.Visible = false;
                    rbSameProofOfName.Enabled = false;

                    dvSameAdtxtDLNumber.Visible = false;
                    dvSameAdtxtPassportNumber.Visible = false;
                    dvtxtSameAdRCNumber.Visible = false;
                    dvSameAdtxtVoterIDNumber.Visible = false;
                    dvSameAdtxtAadharCardNumber.Visible = false;

                    reqSameAdDLNumber.Enabled = false;
                    reqtxtSameAdPassportNumber.Enabled = false;
                    reqSameAdtxtRCNumber.Enabled = false;
                    reqSameAdtxtVoterIDNumber.Enabled = false;
                    reqtxtSameAdAadharCardNumber.Enabled = false;

                    txtSameAdDLNumber.Text = "";
                    txtSameAdPassportNumber.Text = "";
                    txtSameAdRCNumber.Text = "";
                    txtSameAdVoterIDNumber.Text = "";
                    txtSameAdAadharCardNumber.Text = "";
                }
            }
            else
            {
                chkProofOfAddress.Checked = false;
                ScriptManager.RegisterClientScriptBlock(this.rblProofOfName, this.GetType(), "alert", "alert('Please select proof of name first');", true);

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void rbSameProofOfName_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            //rbProofOfAddress.Enabled = false;
            //rbSameProofOfName.Visible = true;
            ////  rbSameProofOfName.Enabled = false;
            ////Bala changes 07042016
            //rbSameProofOfName.Enabled = true;
            //rbProofOfAddress.SelectedIndex = -1;

            txtSameAdDLNumber.Text = "";
            txtSameAdPassportNumber.Text = "";
            txtSameAdRCNumber.Text = "";
            txtSameAdVoterIDNumber.Text = "";
            txtSameAdAadharCardNumber.Text = "";

            if (rbSameProofOfName.SelectedItem.Text == "Driving License")
            {

                rbSameProofOfName.SelectedValue = "Driving License";
                dvSameAdtxtDLNumber.Visible = true;
                dvSameAdtxtPassportNumber.Visible = false;
                dvtxtSameAdRCNumber.Visible = false;
                dvSameAdtxtVoterIDNumber.Visible = false;
                dvSameAdtxtAadharCardNumber.Visible = false;

                reqSameAdDLNumber.Enabled = true;
                reqtxtSameAdPassportNumber.Enabled = false;
                reqSameAdtxtRCNumber.Enabled = false;
                reqSameAdtxtVoterIDNumber.Enabled = false;
                reqtxtSameAdAadharCardNumber.Enabled = false;

                if (rblProofOfName.SelectedItem.Text == "Driving License")
                {
                txtSameAdDLNumber.Text = txtDLNumber.Text;
                //txtSameAdDLNumber.Enabled = false;
                }
            }

            if (rbSameProofOfName.SelectedItem.Text == "Passport")
            {

                rbSameProofOfName.SelectedValue = "Passport";
                dvSameAdtxtDLNumber.Visible = false;
                dvSameAdtxtPassportNumber.Visible = true;
                dvtxtSameAdRCNumber.Visible = false;
                dvSameAdtxtVoterIDNumber.Visible = false;
                dvSameAdtxtAadharCardNumber.Visible = false;

                reqSameAdDLNumber.Enabled = false;
                reqtxtSameAdPassportNumber.Enabled = true;
                reqSameAdtxtRCNumber.Enabled = false;
                reqSameAdtxtVoterIDNumber.Enabled = false;
                reqtxtSameAdAadharCardNumber.Enabled = false;
                if (rblProofOfName.SelectedItem.Text == "Passport")
                {
                    txtSameAdPassportNumber.Text = txtPassportNumber.Text;
                   // txtSameAdPassportNumber.Enabled = false;
                }
            }
            if (rbSameProofOfName.SelectedItem.Text == "Ration Card")
            {
                rbSameProofOfName.SelectedValue = "Ration Card";

                dvSameAdtxtDLNumber.Visible = false;
                dvSameAdtxtPassportNumber.Visible = false;
                dvtxtSameAdRCNumber.Visible = true;
                dvSameAdtxtVoterIDNumber.Visible = false;
                dvSameAdtxtAadharCardNumber.Visible = false;

                reqSameAdDLNumber.Enabled = false;
                reqtxtSameAdPassportNumber.Enabled = false;
                reqSameAdtxtRCNumber.Enabled = true;
                reqSameAdtxtVoterIDNumber.Enabled = false;
                reqtxtSameAdAadharCardNumber.Enabled = false;

              //  txtSameAdRCNumber.Text = txtRCNumber.Text;
                if (rblProofOfName.SelectedItem.Text == "Ration Card")
                {
                    txtSameAdRCNumber.Text = txtRCNumber.Text;
                  //  txtSameAdRCNumber.Enabled = false;
                }
              

            }
            if (rbSameProofOfName.SelectedItem.Text == "Voter's ID")
            {

                rbSameProofOfName.SelectedValue = "Voter's ID";
                dvSameAdtxtDLNumber.Visible = false;
                dvSameAdtxtPassportNumber.Visible = false;
                dvtxtSameAdRCNumber.Visible = false;
                dvSameAdtxtVoterIDNumber.Visible = true;
                dvSameAdtxtAadharCardNumber.Visible = false;

                reqSameAdDLNumber.Enabled = false;
                reqtxtSameAdPassportNumber.Enabled = false;
                reqSameAdtxtRCNumber.Enabled = false;
                reqSameAdtxtVoterIDNumber.Enabled = true;
                reqtxtSameAdAadharCardNumber.Enabled = false;

               // txtSameAdVoterIDNumber.Text = txtVoterIDNumber.Text;
                if (rblProofOfName.SelectedItem.Text == "Voter's ID")
                {
                    txtSameAdVoterIDNumber.Text = txtVoterIDNumber.Text;
                  //  txtSameAdVoterIDNumber.Enabled = false;
                }
              
                
            }
            if (rbSameProofOfName.SelectedItem.Text == "Aadhar Card")
            {
                rbSameProofOfName.SelectedValue = "Aadhar Card";
                dvSameAdtxtDLNumber.Visible = false;
                dvSameAdtxtPassportNumber.Visible = false;
                dvtxtSameAdRCNumber.Visible = false;
                dvSameAdtxtVoterIDNumber.Visible = false;
                dvSameAdtxtAadharCardNumber.Visible = true;

                reqSameAdDLNumber.Enabled = false;
                reqtxtSameAdPassportNumber.Enabled = false;
                reqSameAdtxtRCNumber.Enabled = false;
                reqSameAdtxtVoterIDNumber.Enabled = false;
                reqtxtSameAdAadharCardNumber.Enabled = true;

                txtSameAdAadharCardNumber.Text = txtAadharCardNumber.Text;

                if (rblProofOfName.SelectedItem.Text == "Aadhar Card")
                {
                    txtSameAdAadharCardNumber.Text = txtAadharCardNumber.Text;
                //    txtSameAdAadharCardNumber.Enabled = false;
                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    //Random Comment
}