﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
public partial class MailStatusPopup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblFrom.Text = Request.QueryString["from"] != null ? Request.QueryString["from"].ToString() : "";
            lblTo.Text = Request.QueryString["To"] != null ? Request.QueryString["To"].ToString() : "";
            lblCC.Text = Request.QueryString["cc"] != null ? Request.QueryString["cc"].ToString() : "";
            lblBCC.Text = Request.QueryString["bcc"] != null ? Request.QueryString["bcc"].ToString() : "";


            lblApprovedStatus.Text = Request.QueryString["ApprvSt"] != null ? Request.QueryString["ApprvSt"].ToString() : "";
             bool blMailStatus= Request.QueryString["MailStatus"] != null ? Convert.ToBoolean( Request.QueryString["MailStatus"] ): false;

             if (blMailStatus == true)
             {
                 lblMailStatus.Text = "Mail sent Successfully";
                 lblMailStatus.ForeColor = Color.Green;
             }
             else
             {
                 lblMailStatus.Text = "Mail sent Failed";
                 lblMailStatus.ForeColor = Color.Red;
             }

            divMail.InnerHtml = Request.QueryString["body"] != null ? Request.QueryString["body"].ToString() : "";





        }
    }
    protected void btnCOlse_Click(object sender, EventArgs e)
    {
        Response.Close();
    }
}