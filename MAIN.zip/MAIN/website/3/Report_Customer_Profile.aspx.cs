﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Drawing;
using System.Globalization;
using Tracker;

public partial class Report_Customer_Profile : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime date;
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.bt_print);

        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {


            }
            else
            {
                Response.Redirect("expire.aspx");
            }
        }
    }

    protected void bt_print_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            DateTime compareFrom = DateTime.ParseExact(txtFromDate.Text, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            DateTime to = DateTime.ParseExact(txtToDate.Text, "dd-MM-yyyy", CultureInfo.InvariantCulture);

            int m1 = (to.Month - compareFrom.Month);//for years
            int m2 = (to.Year - compareFrom.Year) * 12; //for months
            int months = m1 + m2;

            if (months > 3)
            {
                uscMsgBox1.AddMessage("Please Select the date range between 3 Months.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }            
             
            string lblAccess = string.Empty;
            con.Open();
            SqlCommand cmd = new SqlCommand("RPT_CUSTOMER_PROFILE_REPORT", con);
            cmd.CommandType = CommandType.StoredProcedure;             
            cmd.Parameters.Add("@STDT", DateTime.ParseExact(txtFromDate.Text, "dd-MM-yyyy", CultureInfo.InvariantCulture));
            cmd.Parameters.Add("@ENDDT", DateTime.ParseExact(txtToDate.Text, "dd-MM-yyyy", CultureInfo.InvariantCulture));
        
            cmd.Parameters.Add("@Type", SqlDbType.NVarChar).Value = Session["USR_ACS"].ToString();
            if (Session["USR_ACS"].ToString() == "7")
            {

                cmd.Parameters.Add("@Unit", SqlDbType.NVarChar).Value = Session["UNITNAME"].ToString();

                lblAccess = " - " + Session["UNITNAME"].ToString() + " Branch";

            }
            else if (Session["USR_ACS"].ToString() == "3")
            {
                cmd.Parameters.Add("@STNAME", SqlDbType.NVarChar).Value = Session["STATENAME"].ToString();

                lblAccess = " - " + Session["STATENAME"].ToString() + " State";
            }
            else if (Session["USR_ACS"].ToString() == "5")
            {
                cmd.Parameters.Add("@ARNAME", SqlDbType.NVarChar).Value = Session["AREANAME"].ToString();
                lblAccess = " - " + Session["AREANAME"].ToString() + " Area";
            }
            else if (Session["USR_ACS"].ToString() == "4")
            {
                cmd.Parameters.Add("@DVNAME", SqlDbType.NVarChar).Value = Session["DIVISIONNAME"].ToString();
                lblAccess = " - " + Session["DIVISIONNAME"].ToString() + " Division";
            }

            SqlDataAdapter showdata = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            showdata.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {

                System.IO.StringWriter tw = new System.IO.StringWriter();

                GridView dgGrid = new GridView();
                dgGrid.DataSource = ds;
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=Customer Profile Report.xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                dgGrid.AllowPaging = false;
                dgGrid.DataBind();
                //Change the Header Row back to white color
                dgGrid.HeaderRow.Style.Add("background-color", "#334FFF");
                dgGrid.HeaderRow.ForeColor = Color.White;
                DataGrid dg = new DataGrid();
                dg.DataSource = ds;
                dg.DataBind();
                dgGrid.BorderColor = Color.FromArgb(211, 211, 211);
                for (int z = 0; z < dg.Items[0].Cells.Count; z++)
                {
                    //Apply style to Individual Cells
                    dgGrid.HeaderRow.Cells[z].Style.Add("background-color", "#334FFF");
                    dgGrid.HeaderRow.Cells[z].BorderColor = Color.FromArgb(211, 211, 211);
                    //dgGrid.HeaderRow.Cells[z].Height = 30;
                }
                for (int i = 0; i < dgGrid.Rows.Count; i++)
                {
                    GridViewRow row = dgGrid.Rows[i];

                    //Change Color back to white
                    row.BackColor = System.Drawing.Color.White;

                    //Apply text style to each Row
                    row.Attributes.Add("class", "textmode");


                }
                dgGrid.RenderControl(hw);
                string year = DateTime.Now.AddYears(0).ToString("yyyy");
                string headerTable = @"<Table><tr><th colspan=3 align=left><font face=Calibri size=3 color=#974807>Cusomer Profile Report" + lblAccess + " </font></th></tr></Table>";
                Response.Write(headerTable);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                uscMsgBox1.AddMessage("No Data Found.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
}