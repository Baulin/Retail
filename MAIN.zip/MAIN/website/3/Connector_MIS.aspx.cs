﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;

public partial class Connector_MIS : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    ClsCommon clscommon = new ClsCommon();
    ReportDocument rpt = new ReportDocument();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime date;
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.bt_print);
        if (!IsPostBack)
        {
            lasttwomonth();
        }
    }
    public void lasttwomonth()
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_lAST_TWOMONTH1", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlMonth.DataSource = dsdd;
        ddlMonth.DataTextField = "MonthYear";
        ddlMonth.DataValueField = "MonthYear";
        ddlMonth.DataBind();
        ddlMonth.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    protected void bt_print_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        SqlCommand cmd = new SqlCommand("RTS_SP_CONNECTOR_MIS", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@FROMDATE", SqlDbType.VarChar).Value = ddlMonth.SelectedItem.Text;        
        SqlDataAdapter showdata = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        showdata.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            StringWriter tw = new StringWriter();
            GridView dgGrid = new GridView();
            dgGrid.DataSource = ds;
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=Connector_MIS_Report.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            dgGrid.AllowPaging = false;
            dgGrid.DataBind();

            DataGrid dg = new DataGrid();
            dg.DataSource = ds;
            dg.DataBind();
            dgGrid.BorderColor = Color.FromArgb(211, 211, 211);

            dgGrid.RenderControl(hw);
            string year = DateTime.Now.AddYears(0).ToString("yyyy");
            string headerTable = @"<Table><tr><th colspan=3 align=left><font face=Calibri size=13 color=#974807>Connector MIS Report </font></th></tr></Table>";
            Response.Write(headerTable);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
        else
        {
            uscMsgBox1.AddMessage("No Data Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);
        }
        con.Close();
    }
}