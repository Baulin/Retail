﻿using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using System.Net.Mail;
using System;
using System.Collections;
using System.Text;
using System.Data.Linq;
using System.Data.Common;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using Tracker;

public partial class Branch_RCA : System.Web.UI.Page
{
    public static DataTable dtSourceOfIncome = null;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    ClsCommon clscommon = new ClsCommon();
    ReportDocument rpt = new ReportDocument();

    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnPrint);
        if (!IsPostBack)
        {           
            bind();
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    lasttwomonth();                                  
                }
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }
    }
    public void lasttwomonth()
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_lAST_TWOMONTH", con);        
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlMonth.DataSource = dsdd;
        ddlMonth.DataTextField = "MonthYear";
        ddlMonth.DataValueField = "MonthYear";
        ddlMonth.DataBind();
        ddlMonth.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void bind()
    {        
        DataSet dsdd = new DataSet();
        dsdd = clscommon.GetArea();     
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ClearText();
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {       
        DataSet ds = new DataSet();
        ds = GetLoanNo("BRANCH");

        ddlBranch.DataSource = ds;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();

        ddlBranch.Items.Insert(0, "--Select--");
    }

    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {        
        DataSet ds = new DataSet();
        ds = GetLoanNo("LOAN NUMBER");

        ddlApplicantid.DataSource = ds;
        ddlApplicantid.DataTextField = "LD_LOAN_NO";
        ddlApplicantid.DataValueField = "LOAN_NO";
        ddlApplicantid.DataBind();

        ddlArea.Items.Insert(0, "--Select--");
        ddlBranch.Items.Insert(0, "--Select--");
        ddlApplicantid.Items.Insert(0, "--Select--");
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            
            string TYPEOFAUDIT = ddlTypeofaudit.SelectedItem.Text != "--Select--" ? Convert.ToString(ddlTypeofaudit.SelectedItem.Text) : "";
            string AREANAME = ddlArea.SelectedItem.Text != "--Select--" ? Convert.ToString(ddlArea.SelectedItem.Text) : "";
            string BRANCHNAME = ddlBranch.SelectedItem.Text != "--Select--" ? Convert.ToString(ddlBranch.SelectedItem.Text) : "";
            string LD_LOAN_NO = ddlApplicantid.SelectedItem.Value != "--Select--" ? Convert.ToString(ddlApplicantid.SelectedItem.Value) : "";
            //string[] LD_LOAN_NO = ddlApplicantid.SelectedItem.Text.Split('|');  
            //LD_LOAN_NO[0].ToString();

            string APPLICANT_NAME = txtApplicantname.Text != "" ? Convert.ToString(txtApplicantname.Text) : "";
            string PHONENUMBER = txtPhonenumber.Text != "" ? Convert.ToString(txtPhonenumber.Text) : "";
            string LOAN_DISB_DATE = txtLoandisburseddate.Text != "" ? Convert.ToString(txtLoandisburseddate.Text) : "";
            double LOAN_AMOUNT = txtLoanamount.Text != "" ? Convert.ToDouble(txtLoanamount.Text) : 0.0;
            double TOTAL_LOANTENOR = txtTotalloantenor.Text != "" ? Convert.ToDouble(txtTotalloantenor.Text) : 0.0;
            string Interest = txtInterestrate.Text;
            Interest = Interest.Replace("%", "");
            double INTREST_RATE = txtInterestrate.Text != "" ? Convert.ToDouble(Interest) : 0.0;
            double PROCESSING_FEE = txtProcessingfee.Text != "" ? Convert.ToDouble(txtProcessingfee.Text) : 0.0;
            double ADMIN_FEE = txtAdminfee.Text != "" ? Convert.ToDouble(txtAdminfee.Text) : 0.0;
            double CREDIT_LIFE_INS = txtCreditlifeins.Text != "" ? Convert.ToDouble(txtCreditlifeins.Text) : 0.0;
            double PROPERTY_INS = txtPropertyins.Text != "" ? Convert.ToDouble(txtPropertyins.Text) : 0.0;
            double TECH_PROCESSING_FEE = txtTechprocessingfee.Text != "" ? Convert.ToDouble(txtTechprocessingfee.Text) : 0.0;
            string APPLICANT_ADDRESS = txtAddress.Text != "" ? Convert.ToString(txtAddress.Text) : "";
            double QUESTION_1 = txtLoanamountdisbursed.Text != "" ? Convert.ToDouble(txtLoanamountdisbursed.Text) : 0.0;
            string QUESTION_2 = rbChargesbefore.SelectedItem.Text!=""? Convert.ToString(rbChargesbefore.SelectedItem.Text) : "";
            string QUESTION_3 = rbProcessingfeeconfirm.SelectedItem.Text!=""? Convert.ToString(rbProcessingfeeconfirm.SelectedItem.Text) : "";
            string QUESTION_4 = rbAnyonewithoutpay.SelectedItem.Text!=""? Convert.ToString(rbAnyonewithoutpay.SelectedItem.Text) : "";
            double QUESTION_5 = txtWithoutreceipt.Text != "" ? Convert.ToDouble(txtWithoutreceipt.Text) : 0.0;
            string QUESTION_6 = rbInformedcreditconditionofloan.SelectedItem.Text!=""? Convert.ToString(rbInformedcreditconditionofloan.SelectedItem.Text) : "";
            string QUESTION_7 = rbAwareinstallmentduedate.SelectedItem.Text!=""? Convert.ToString(rbAwareinstallmentduedate.SelectedItem.Text) : "";
            double QUESTION_8 = txtTenorofloaninmonth.Text != "" ? Convert.ToDouble(txtTenorofloaninmonth.Text) : 0.0;
            double QUESTION_9 = txtInterestrateavailed.Text != "" ? Convert.ToDouble(txtInterestrateavailed.Text) : 0.0;
            string QUESTION_10 = rbAcknowledgement.SelectedItem.Text!=""? Convert.ToString(rbAcknowledgement.SelectedItem.Text) : "";
            string QUESTION_11 = rbOverallequitasrate.SelectedItem.Text!=""? Convert.ToString(rbOverallequitasrate.SelectedItem.Text) : "";
            string QUESTION_12 = txtCustomerresponse.Text != "" ? Convert.ToString(txtCustomerresponse.Text) : "";
            string QUESTION_13 = rbEmployedorbuisness.SelectedItem.Text!=""? Convert.ToString(rbEmployedorbuisness.SelectedItem.Text) : "";
            string QUESTION_14 = txtIncometypeofbuisness.Text != "" ? Convert.ToString(txtIncometypeofbuisness.Text) : "";
            string QUESTION_15 = txtVintageofbuisness.Text != "" ? Convert.ToString(txtVintageofbuisness.Text) : "";
            double QUESTION_16 = txtAveragedailyincome.Text != "" ? Convert.ToDouble(txtAveragedailyincome.Text) : 0.0;
            string QUESTION_17 = txtIncomenameofcompanyemploy.Text != "" ? Convert.ToString(txtIncomenameofcompanyemploy.Text) : "";
            string QUESTION_18 = txtNoofyearsemployment.Text != "" ? Convert.ToString(txtNoofyearsemployment.Text) : "";
            double QUESTION_19 = txtIncomegrosssalary.Text != "" ? Convert.ToDouble(txtIncomegrosssalary.Text) : 0.0;
            string QUESTION_20 = ddlEnduseofloan.SelectedItem.Text != "--Select--" ? Convert.ToString(ddlEnduseofloan.SelectedItem.Text) : "";
            string QUESTION_21 = txtCurrentstageofconstruction.Text != "" ? Convert.ToString(txtCurrentstageofconstruction.Text) : "";
            string QUESTION_22 = rbLocalmoneylendors.SelectedItem.Text!=""? Convert.ToString(rbLocalmoneylendors.SelectedItem.Text) : "";
            double QUESTION_23 = txtPreviousinstallment.Text != "" ? Convert.ToDouble(txtPreviousinstallment.Text) : 0.0;
            string QUESTION_24 = txtMarketvalueofpropertyfro.Text != "" ? Convert.ToString(txtMarketvalueofpropertyfro.Text) : "";
            string QUESTION_25 = txtInstallmentduedate.Text != "" ? Convert.ToString(txtInstallmentduedate.Text) : "";
            string QUESTION_26 = txtAlternatemobileno.Text != "" ? Convert.ToString(txtAlternatemobileno.Text) : "";
            string QUESTION_27 = txtEnduseofloan.Text != "" ? Convert.ToString(txtEnduseofloan.Text) : "";
            string QUESTION_28 = rbAreyouamember.SelectedItem.Text != "" ? Convert.ToString(rbAreyouamember.SelectedItem.Text) : "";
            string QUESTION_29 = ddlBuisnesstypedesc.SelectedItem.Text != "--Select--" ? Convert.ToString(ddlBuisnesstypedesc.SelectedItem.Text) : "";
            string Remarks = txtBox_obser.Text != "" ? Convert.ToString(txtBox_obser.Text) : "";
            string QUESTION_30 = "";
            string CREATEDBY = Session["EMP_CODE"].ToString();
            string CREATEDON = "";
            string UPDATEDBY = "";
            string UPDATEDON = "";

            clscommon.RTS_SP_INSERT_RETAILAUDITFORM
            (TYPEOFAUDIT, AREANAME, BRANCHNAME, LD_LOAN_NO, APPLICANT_NAME, PHONENUMBER, LOAN_DISB_DATE,
            LOAN_AMOUNT, TOTAL_LOANTENOR, INTREST_RATE, PROCESSING_FEE, ADMIN_FEE, CREDIT_LIFE_INS,
            PROPERTY_INS, TECH_PROCESSING_FEE, APPLICANT_ADDRESS, QUESTION_1, QUESTION_2, QUESTION_3,
            QUESTION_4, QUESTION_5, QUESTION_6, QUESTION_7, QUESTION_8, QUESTION_9, QUESTION_10,
            QUESTION_11, QUESTION_12, QUESTION_13, QUESTION_14, QUESTION_15, QUESTION_16, QUESTION_17,
            QUESTION_18, QUESTION_19, QUESTION_20, QUESTION_21, QUESTION_22, QUESTION_23, QUESTION_24,
            QUESTION_25, QUESTION_26, QUESTION_27, QUESTION_28, QUESTION_29, QUESTION_30, CREATEDBY,
            CREATEDON, UPDATEDBY, UPDATEDON,Remarks);
            string answer = "Retail Customer Audit Done Successfully";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect","alert('" + answer + "'); window.location.href='Branch_RCA.aspx';", true);
           
            //Response.Redirect("Branch_RCA.aspx");

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Branch_RCA.aspx"); }
            catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }  
    }

    private void ClearText()
    {
        txtApplicantname.Text = "";
        txtPhonenumber.Text = "";
        txtLoandisburseddate.Text = "";
        txtLoanamount.Text = "";
        txtTotalloantenor.Text = "";
        txtInterestrate.Text = "";
        txtProcessingfee.Text = "";
        txtAdminfee.Text = "";
        txtCreditlifeins.Text = "";
        txtPropertyins.Text = "";
        txtTechprocessingfee.Text = "";
        txtAddress.Text = "";
        txtInstallmentduedate.Text = "";
        txtResAddrs.Text = "";
    }

    protected void ddlApplicantid_SelectedIndexChanged(object sender, EventArgs e)
    {
        string[] ApplicantID = ddlApplicantid.SelectedItem.Text.Split('|');
        DataTable dt = new DataTable();

        if (ApplicantID[0].ToString() != "--Select--")
        {
            btnPrint.Enabled = true;
            dt = clscommon.RTS_SP_GETLOANNOWISE_RCA(ApplicantID[0].ToString());
            if (dt.Rows.Count != 0)
            {
                txtApplicantname.Text = Convert.ToString(dt.Rows[0]["APPLICANT_NAME"].ToString());
                txtPhonenumber.Text = Convert.ToString(dt.Rows[0]["MOBNO"].ToString());
                txtLoandisburseddate.Text = Convert.ToString(dt.Rows[0]["DISBURSEMENT_DATE"].ToString());
                txtLoanamount.Text = Convert.ToString(dt.Rows[0]["DISBURSEMENT_AMOUNT"]);
                txtTotalloantenor.Text = Convert.ToString(dt.Rows[0]["LOAN_TENURE"]);
                txtInterestrate.Text = Convert.ToString(dt.Rows[0]["INTEREST_RATE"]);
                txtProcessingfee.Text = Convert.ToString(dt.Rows[0]["PROCESSING_FEE"]);
                txtAdminfee.Text = Convert.ToString(dt.Rows[0]["ADMIN_FEE"]);
                txtCreditlifeins.Text = Convert.ToString(dt.Rows[0]["CREDIT_LIFE_INS"]);
                txtPropertyins.Text = Convert.ToString(dt.Rows[0]["PROPERTY_INS"]);
                txtTechprocessingfee.Text = Convert.ToString(dt.Rows[0]["TECH_FEE"]);
                txtAddress.Text = Convert.ToString(dt.Rows[0]["APPLICANT_ADDRESS"].ToString());
                txtInstallmentduedate.Text = Convert.ToString(dt.Rows[0]["INSTALLMENT_DUE_DATE"].ToString());
                txtBusinesstype.Text = Convert.ToString(dt.Rows[0]["Busniess Type"].ToString());
                txtSalaried.Text = Convert.ToString(dt.Rows[0]["Salaried/Self Employed"].ToString());
                txtResAddrs.Text = Convert.ToString(dt.Rows[0]["RESIDENTIAL_ADDRESS"].ToString());
                txtPDDoneBy.Text = Convert.ToString(dt.Rows[0]["PD_EMP_NAME"].ToString());
                txtPDDate.Text = Convert.ToString(dt.Rows[0]["PD_DONE_DATE"].ToString());
                if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["EMP_NAME"])))
                {
                    //trConnector.Visible = true;
                    //tdConn1.Visible = true;
                    //tdConn2.Visible = true;
                    //txtConnName.Text = Convert.ToString(dt.Rows[0]["EMP_NAME"]);
                    spConn.InnerText = " - " + Convert.ToString(dt.Rows[0]["EMP_NAME"]);
                }
                else
                {
                    //txtConnName.Text = "";
                    //trConnector.Visible = false;
                    //tdConn1.Visible = false;
                    //tdConn2.Visible = false;
                    spConn.InnerText = "";
                }
            }
        }
        else
            btnPrint.Enabled = false;
        SetFocus(txtLoanamountdisbursed);
    }

    protected void rbEmployedorbuisness_SelectedIndexChanged(object sender, EventArgs e)
    {
        trSmallbuisness.Visible = false;
        trSmalltypeofbuisness.Visible = false;
        trSmallvintageofbuisness.Visible = false;
        trSmalldailyincomeofbuisness.Visible = false;
        trEmployed.Visible = false;
        trEmployedcompany.Visible = false;
        trEmployednoofyears.Visible = false;
        trEmployedincomesalary.Visible = false;
        trBuisnesstypedesc.Visible = false;

        txtVintageofbuisness.Text = "";
        txtIncomegrosssalary.Text = "";
        txtIncomenameofcompanyemploy.Text = "";
        txtIncometypeofbuisness.Text = "";
        txtNoofyearsemployment.Text = "";
        txtAveragedailyincome.Text = "";

        if (rbEmployedorbuisness.SelectedItem.Text !="")
        {
            string Buisnesstype = rbEmployedorbuisness.SelectedItem.Text;
            if (Buisnesstype != "Employed")
            {
                trSmallbuisness.Visible = true;
                trSmalltypeofbuisness.Visible = true;
                trSmallvintageofbuisness.Visible = true;
                trSmalldailyincomeofbuisness.Visible = true;
                trBuisnesstypedesc.Visible = true;
            }
            else
            {
                trEmployed.Visible = true;
                trEmployedcompany.Visible = true;
                trEmployednoofyears.Visible = true;
                trEmployedincomesalary.Visible = true;
                
            }
        }
        
    }
    protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        ds = GetLoanNo("PRODUCT");       

        ddlTypeofaudit.DataSource = ds;
        ddlTypeofaudit.DataTextField = "PR_CODE";
        ddlTypeofaudit.DataValueField = "PR_ID";
        ddlTypeofaudit.DataBind();

        ddlTypeofaudit.Items.Insert(0, "--Select--");

        ClearText();
        
        ddlTypeofaudit.SelectedIndex = 0;        
        ddlArea.SelectedIndex = 0;
        ddlBranch.SelectedIndex = 0;
        ddlApplicantid.SelectedIndex = 0;
    }

    private DataSet GetLoanNo(string product)
    {        
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("SP_RTS_FETCH_RISK_AUDIT", con);
            cmdrsn.CommandType = CommandType.StoredProcedure;

            cmdrsn.Parameters.AddWithValue("@PTYPE",product);
            cmdrsn.Parameters.AddWithValue("@DISB_MONTH", ddlMonth.SelectedItem.Text != "--Select--" ? ddlMonth.SelectedValue : "");
            cmdrsn.Parameters.AddWithValue("@PR_ID", ddlTypeofaudit.SelectedItem.Text != "--Select--" ? ddlTypeofaudit.SelectedValue : "");
            cmdrsn.Parameters.AddWithValue("@AR_ID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue : "");
            cmdrsn.Parameters.AddWithValue("@BR_ID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue : "");
            cmdrsn.Parameters.AddWithValue("@LOAN_NO", ddlApplicantid.SelectedItem.Text != "--Select--" ? ddlApplicantid.SelectedItem.Text : "");
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

            return dsrsn;
    }
    protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        ClearText();
        ddlTypeofaudit.SelectedIndex = 0;
        ddlArea.SelectedIndex = 0;
        ddlBranch.SelectedIndex = 0;
        ddlApplicantid.SelectedIndex = 0;
    }
    protected void ddlTypeofaudit_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        ds = GetLoanNo("AREA");

        ddlArea.DataSource = ds;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();

        ddlArea.Items.Insert(0, "--Select--");

        ClearText();      
        ddlArea.SelectedIndex = 0;
        ddlBranch.SelectedIndex = 0;
        ddlApplicantid.SelectedIndex = 0;
        if (ddlTypeofaudit.SelectedIndex == 2)
        {
            txtCurrentstageofconstruction.Enabled = true;
        }
        else
        {
            txtCurrentstageofconstruction.Enabled = false;
        }
        
    }
    protected void ddlEnduseofloan_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtEnduseofloan.Visible = false;
        txtEnduseofloan.Text = "";
        if (ddlEnduseofloan.SelectedItem.Text == "Others")
        {
            txtEnduseofloan.Visible = true;
        }
        else
        {
            txtEnduseofloan.Visible = false;
        }

    }
    protected void rbAnyonewithoutpay_SelectedIndexChanged(object sender, EventArgs e)
    {
        trWithoutreceipt.Visible = false;
        txtWithoutreceipt.Text = "";
        if (rbAnyonewithoutpay.SelectedItem.Text =="Yes")
        {
            trWithoutreceipt.Visible = true;
        }

    }

    protected void btnPrint_Click(object sender, EventArgs e)
    {
        try
        {
            string[] ApplicantLdID = ddlApplicantid.SelectedItem.Text.Split('|');
            rpt = new ReportDocument();
            //set a ReportPath and assign the dataset to reportdocument object
            rpt.Load(Server.MapPath("Reports/RCA_Print.rpt"));

            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
            rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

            //assign the values to crystal report viewer
            rpt.SetParameterValue(0, ApplicantLdID[0].ToString());
            rpt.SetParameterValue(1, ddlMonth.SelectedItem.Text.Trim() != "" ? ddlMonth.SelectedItem.Text.Trim() : "");
            rpt.SetParameterValue(2, Convert.ToString(Session["EMP_CODE"]));
            rpt.SetParameterValue(3, Convert.ToString(Session["EMPNAME"]));
            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Retail Customer Audit");
            //Clear();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}