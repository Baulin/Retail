﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using System.Net.Mail;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using Tracker;
using Utilities;
using System.Text;
using System.Text.RegularExpressions;
using Utilities.SessionKeys;
using Resources;
using Utilities.Enums;


public partial class LapDisbursalMemo : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    //string sa;
    int ldid;
    //int j;
    //int b;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string dmmby = "";
    Int64 _userRoleId = 0;
    String _userRoleGroup = String.Empty;
    DateTime dt = DateTime.Now;
    string[] stringArray = new string[100];
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    public static bool blMailStatus = false;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    ClsCommon clscommon = new ClsCommon();

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.lnkBtnPrint);
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                txtViewDate.Text = String.Format("{0:dd MMM yyyy}", dt);

                //User Role based authorization for DM processing
                if (Session[SessionKeys.TYPEID] != null) { Int64.TryParse(Session[SessionKeys.TYPEID].ToString(), out _userRoleId); }
                _userRoleGroup = clscommon.IdentifyUserRoleGroup(_userRoleId);

                if (!String.IsNullOrEmpty(_userRoleGroup) && !String.IsNullOrWhiteSpace(_userRoleGroup)) { Session[SessionKeys.USER_ROLE_GROUP] = _userRoleGroup; }

                bind();
                if (Session["TYPEID"].ToString() == "2")
                {
                    ddlArea.Enabled = false;
                    ddlArea.SelectedValue = Session["AREA_ID"].ToString();
                    SqlConnection con = new SqlConnection(strcon);
                    con.Open();
                    SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
                    cmdrsn.CommandType = CommandType.StoredProcedure;
                    cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
                    SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
                    DataSet dsrsn = new DataSet();
                    darsn.Fill(dsrsn);
                    con.Close();

                    ddlBranch.DataSource = dsrsn;
                    ddlBranch.DataTextField = "BR_NAME";
                    ddlBranch.DataValueField = "BR_ID";
                    ddlBranch.DataBind();
                    ddlBranch.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));
                    ddlBranch.Enabled = false;
                    ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
                    //Bala changes 07/07/2017
                    tblAprove.Visible = true;  

                }
                else
                {
                    tblAprove.Visible = true;                    
                }
            }
        }
        else
        {
            Response.Redirect("expire.aspx");
        }
    }
    public void bind()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlArea.DataSource = dsdd;
            ddlArea.DataTextField = "AR_NAME";
            ddlArea.DataValueField = "AR_ID";
            ddlArea.DataBind();
            ddlArea.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));

            //SqlCommand cmdqry = new SqlCommand("SELECT * FROM LSD_QUERY_GRID", con);
            //SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
            //DataSet dsqry = new DataSet();
            //daqry.Fill(dsqry);
            //gvQueryEntry.DataSource = dsqry.Tables[0];
            //gvQueryEntry.DataBind();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void bindPaymentMode()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_PAYMENT_MODE", con);
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            rblPaymentMode.DataSource = dsdd;
            rblPaymentMode.DataTextField = "PM_DESC";
            rblPaymentMode.DataValueField = "PM_ID";
            rblPaymentMode.DataBind();
          //  ddlArea.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));
        
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void FetchDMCValues()
    {
        try
        {
           
            DataTable dtCam = null;
            if (Session["LeadNo"].ToString() != "")
            {
                dtCam = fetchCamDetail();
                if (dtCam != null && dtCam.Rows.Count > 0)
                {
                    string strSancNO = dtCam.Rows[0]["LD_SANTD_NO"] != DBNull.Value ? dtCam.Rows[0]["LD_SANTD_NO"].ToString() : "";
                    txtLeadNo1.Text = Session["LeadNo"].ToString();
                    txtAreaName.Text = dtCam.Rows[0]["AR_NAME"] != DBNull.Value ? dtCam.Rows[0]["AR_NAME"].ToString() : "";
                    txtBranchName.Text = dtCam.Rows[0]["BR_NAME"] != DBNull.Value ? dtCam.Rows[0]["BR_NAME"].ToString() : "";
                    // txtBranchName.Text = dtCam.Rows[0]["BR_NAME"] != DBNull.Value ? dtCam.Rows[0]["BR_NAME"].ToString() : "";

                    StringBuilder sb = new StringBuilder();
                    sb.Append(dtCam.Rows[0]["MP_PROP"] != DBNull.Value ? dtCam.Rows[0]["MP_PROP"].ToString() : "");
                    sb.Append(dtCam.Rows[0]["MP_NORTH"] != DBNull.Value ? "North By" + dtCam.Rows[0]["MP_NORTH"].ToString() + ", " : "");
                    sb.Append(dtCam.Rows[0]["MP_SOUTH"] != DBNull.Value ? "South By" + dtCam.Rows[0]["MP_SOUTH"].ToString() + ", " : "");
                    sb.Append(dtCam.Rows[0]["MP_EAST"] != DBNull.Value ? "East By" + dtCam.Rows[0]["MP_EAST"].ToString() + ", " : "");
                    sb.Append(dtCam.Rows[0]["MP_WEST"] != DBNull.Value ? "West By" + dtCam.Rows[0]["MP_WEST"].ToString() + ". " : "");
                    sb.Append(dtCam.Rows[0]["MP_MEASURE"] != DBNull.Value ? "Measurement :" + dtCam.Rows[0]["MP_MEASURE"].ToString() + ". " : "");
                    sb.Append(dtCam.Rows[0]["MP_REGISTR"] != DBNull.Value ? dtCam.Rows[0]["MP_REGISTR"].ToString() + ". " : "");
                    txtLglProDetails.Text =sb.ToString();

                    FetchCreditConditions();

                    if (strSancNO != "")
                    {
                        DataTable dtSanc = null;
                        dtSanc = fetchSanction(strSancNO);

                        if (dtSanc != null && dtSanc.Rows.Count > 0)
                        {
                            //
                            tblDMC.Visible = true;
                            txtProposalNo.Text = dtSanc.Rows[0]["PROPOSAL NO"] != DBNull.Value ? dtSanc.Rows[0]["PROPOSAL NO"].ToString() : "";
                            txtScheme.Text = dtSanc.Rows[0]["SCHEME DESCR"] != DBNull.Value ? dtSanc.Rows[0]["SCHEME DESCR"].ToString() : "";
                            txtProposalNo.Text = dtSanc.Rows[0]["PROPOSAL NO"] != DBNull.Value ? dtSanc.Rows[0]["PROPOSAL NO"].ToString() : "";
                            txtAppName.Text = dtSanc.Rows[0]["CUSTOMER NAME"] != DBNull.Value ? dtSanc.Rows[0]["CUSTOMER NAME"].ToString() : "";
                            txtCoAppName.Text = dtSanc.Rows[0]["CO-APPLICANT NAME"] != DBNull.Value ? dtSanc.Rows[0]["CO-APPLICANT NAME"].ToString() : "";
                            txtLandSqft.Text = dtCam.Rows[0]["CAM_LAREA"] != DBNull.Value ? dtCam.Rows[0]["CAM_LAREA"].ToString() : "";
                            txtLoanAMount.Text = dtSanc.Rows[0]["SANCTION AMOUNT"] != DBNull.Value ? dtSanc.Rows[0]["SANCTION AMOUNT"].ToString() : "";
                            txtROI.Text = dtSanc.Rows[0]["RATE OF INTEREST"] != DBNull.Value ? dtSanc.Rows[0]["RATE OF INTEREST"].ToString() : "";
                            txtProcessFee.Text = dtSanc.Rows[0]["PROCESSING FEE"] != DBNull.Value ? dtSanc.Rows[0]["PROCESSING FEE"].ToString() : "0";
                            txtEMI.Text = dtSanc.Rows[0]["INDICATIVE EMI"] != DBNull.Value ? dtSanc.Rows[0]["INDICATIVE EMI"].ToString() : "";
                            txtTenor.Text = dtSanc.Rows[0]["TERM IN MONTHS"] != DBNull.Value ? dtSanc.Rows[0]["TERM IN MONTHS"].ToString() : "";
                            txtCSPM.Text = dtSanc.Rows[0]["CREDIT SHIELD PREMIUM"] != DBNull.Value ? dtSanc.Rows[0]["CREDIT SHIELD PREMIUM"].ToString() : "0";
                            txtPIPM.Text = dtSanc.Rows[0]["PROPERTY INSURANCE PREMIUM"] != DBNull.Value ? dtSanc.Rows[0]["PROPERTY INSURANCE PREMIUM"].ToString() : "0";
                            txtCersai.Text = dtSanc.Rows[0]["CERSAI"] != DBNull.Value ? dtSanc.Rows[0]["CERSAI"].ToString() : "0";
                            txtAdminFee.Text = dtSanc.Rows[0]["ADMIN FEE"] != DBNull.Value ? dtSanc.Rows[0]["ADMIN FEE"].ToString() : "0";
                            //txtTechFee.Text = dtSanc.Rows[0]["TECHNICAL PROCESSING FEE"] != DBNull.Value ? dtSanc.Rows[0]["TECHNICAL PROCESSING FEE"].ToString() : "0";
                            txtLegalFee.Text = dtSanc.Rows[0]["LEGAL PROCESSING FEE"] != DBNull.Value ? dtSanc.Rows[0]["LEGAL PROCESSING FEE"].ToString() : "0";
                            txtCattleIns.Text = dtSanc.Rows[0]["CATTLE INSURANCE"] != DBNull.Value ? dtSanc.Rows[0]["CATTLE INSURANCE"].ToString() : "0";
                            txtAccidentalInsur.Text = dtSanc.Rows[0]["ACCIDENTAL_INSURANCE"] != DBNull.Value ? dtSanc.Rows[0]["ACCIDENTAL_INSURANCE"].ToString() : "0";
                            txtDocumentCharges.Text = dtSanc.Rows[0]["DOCUMENDATION_CHARGES"] != DBNull.Value ? dtSanc.Rows[0]["DOCUMENDATION_CHARGES"].ToString() : "0";
                            txtlgnfee.Text = dtSanc.Rows[0]["LD_LGN_FEE"] != DBNull.Value ? dtSanc.Rows[0]["LD_LGN_FEE"].ToString() : "0";
                            
                            txtactProcessFee.Text = Convert.ToDouble(txtProcessFee.Text) != 0 ? Convert.ToString(Convert.ToDouble(txtProcessFee.Text) - Convert.ToDouble(txtlgnfee.Text)) : "0";
                            double dbnNetDisbursalAmt = 0;
                            //dbnNetDisbursalAmt = Convert.ToDouble(txtLoanAMount.Text) - (Convert.ToDouble(txtProcessFee.Text) + Convert.ToDouble(txtCSPM.Text) + Convert.ToDouble(txtPIPM.Text) + Convert.ToDouble(txtCersai.Text) + Convert.ToDouble(txtAdminFee.Text) + Convert.ToDouble(txtTechFee.Text) + Convert.ToDouble(txtCattleIns.Text) + Convert.ToDouble(txtAccidentalInsur.Text) + +Convert.ToDouble(txtDocumentCharges.Text));
                            dbnNetDisbursalAmt = Convert.ToDouble(txtLoanAMount.Text) - (Convert.ToDouble(txtactProcessFee.Text) + Convert.ToDouble(txtCSPM.Text) + Convert.ToDouble(txtPIPM.Text) + Convert.ToDouble(txtCersai.Text) + Convert.ToDouble(txtAdminFee.Text) + Convert.ToDouble(txtLegalFee.Text) + Convert.ToDouble(txtCattleIns.Text) + Convert.ToDouble(txtAccidentalInsur.Text) + +Convert.ToDouble(txtDocumentCharges.Text));
                            //dbnNetDisbursalAmt = Convert.ToDouble(txtLoanAMount.Text) - (Convert.ToDouble(txtProcessFee.Text) + Convert.ToDouble(txtCSPM.Text) + Convert.ToDouble(txtPIPM.Text) + Convert.ToDouble(txtCersai.Text) + Convert.ToDouble(txtAdminFee.Text) + Convert.ToDouble(txtTechFee.Text));

                            txtNetAmt.Text = dbnNetDisbursalAmt.ToString();
                            txtTotal1.Text = txtNetAmt.Text;
                            txtTotAMnt.Text = txtNetAmt.Text;

                            txtCrdAprvDate.Text = dtCam.Rows[0]["LD_CRAP_DATE"] != DBNull.Value ? Convert.ToDateTime(dtCam.Rows[0]["LD_CRAP_DATE"]).ToString("dd MMM yyyy") : "";
                            string strDate = dtSanc.Rows[0]["SANCTION DATE"] != DBNull.Value ? dtSanc.Rows[0]["SANCTION DATE"].ToString() : "";
                            if (strDate != "")
                            {
                                txtSanDate.Text = Convert.ToDateTime(strDate).ToString("dd MMM yyyy");
                            }
                          
                            txtExtendArea.Text = dtCam.Rows[0]["MD_EXTENT"] != DBNull.Value ? dtCam.Rows[0]["MD_EXTENT"].ToString() : "";
                            string strLgAprv = dtCam.Rows[0]["LD_LG_APRL"] != DBNull.Value ? dtCam.Rows[0]["LD_LG_APRL"].ToString() : "";
                            txtLglConclusion.Text = dtCam.Rows[0]["MR_CONCL"] != DBNull.Value ? dtCam.Rows[0]["MR_CONCL"].ToString() : "";
                            if (strLgAprv == "1")
                            {
                                txtLegalStatus.Text = "Approved";
                                ddlAppCase.Enabled = true;
                                txtDmApproveDate.Enabled = true;
                                txtDmApproveDate.Text = DateTime.Now.ToString("dd MMM yyyy");
                                txtRemarks.Enabled = true;
                            }
                            else
                            {
                                txtLegalStatus.Text = "Un-Approved";
                                /*ddlAppCase.Enabled = false;
                                txtDmApproveDate.Enabled = false;
                                txtDmApproveDate.Text = "";
                                txtRemarks.Enabled = false;*/
                                ddlAppCase.Enabled = true;
                                txtDmApproveDate.Enabled = true;
                                txtDmApproveDate.Text = DateTime.Now.ToString("dd MMM yyyy");
                                txtRemarks.Enabled = true;
                            }
                            string strLandVal = dtCam.Rows[0]["CAM_LAREA"] != DBNull.Value ? dtCam.Rows[0]["CAM_LAREA"].ToString() : "";
                            if (strLandVal != txtExtendArea.Text && Session["TYPEID"].ToString() == "3")
                            {
                                if (txtLegalStatus.Text != "Un-Approved")
                                {
                                    ddlAppCase.SelectedValue = "Manual";
                                }
                                ddlAppCase.Enabled = false;
                                uscMsgBox1.AddMessage("Legal Extent Area  is not Matching with CAM Land Area..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            }
                            else if (strLandVal != txtExtendArea.Text && Session["TYPEID"].ToString() == "8")
                            {
                                if (txtLegalStatus.Text != "Un-Approved")
                                {
                                    ddlAppCase.SelectedValue = "Manual";
                                }
                                ddlAppCase.Enabled = false;
                                uscMsgBox1.AddMessage("Legal Extent Area  is not Matching with CAM Land Area..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            }
                            else if (strLandVal != txtExtendArea.Text && Session["TYPEID"].ToString() == "14")
                            {
                                if (txtLegalStatus.Text != "Un-Approved")
                                {
                                    ddlAppCase.SelectedValue = "Manual";
                                }
                                ddlAppCase.Enabled = false;
                                uscMsgBox1.AddMessage("Legal Extent Area  is not Matching with CAM Land Area..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            }
                            else if (strLandVal != txtExtendArea.Text && Session["TYPEID"].ToString() == "5")
                            {
                                if (txtLegalStatus.Text != "Un-Approved")
                                {
                                    ddlAppCase.SelectedValue = "Manual";
                                }
                                ddlAppCase.Enabled = false;
                                uscMsgBox1.AddMessage("Legal Extent Area  is not Matching with CAM Land Area..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            }
                            else if (strLandVal != txtExtendArea.Text && Session["TYPEID"].ToString() == "6")
                            {
                                if (txtLegalStatus.Text != "Un-Approved")
                                {
                                    ddlAppCase.SelectedValue = "Manual";
                                }
                                ddlAppCase.Enabled = false;
                                uscMsgBox1.AddMessage("Legal Extent Area  is not Matching with CAM Land Area..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            }
                            else if (strLandVal != txtExtendArea.Text && Session["TYPEID"].ToString() == "7")
                            {
                                if (txtLegalStatus.Text != "Un-Approved")
                                {
                                    ddlAppCase.SelectedValue = "Manual";
                                }
                                ddlAppCase.Enabled = false;
                                uscMsgBox1.AddMessage("Legal Extent Area  is not Matching with CAM Land Area..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            }
                            else if (strLandVal != txtExtendArea.Text && Session["TYPEID"].ToString() == "1")
                            {
                                if (txtLegalStatus.Text != "Un-Approved")
                                {
                                    ddlAppCase.SelectedValue = "Manual";
                                }
                                ddlAppCase.Enabled = false;
                                uscMsgBox1.AddMessage("Legal Extent Area  is not Matching with CAM Land Area..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            }
                            txtDmApproveDate.Text = DateTime.Now.ToString("dd MMM yyyy");

                            //if (Session["QryType"].ToString() == "T" || Session["TYPEID"].ToString() == "3" || Session["TYPEID"].ToString() == "8" || Session["TYPEID"].ToString() == "14" || Session["TYPEID"].ToString() == "5" || Session["TYPEID"].ToString() == "6" || Session["TYPEID"].ToString() == "7" || Session["TYPEID"].ToString() == "1")
                            //{
                                DataSet ds = fetchDMCDetail();
                                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                                {
                                    txtLoanNUmber.Text = ds.Tables[0].Rows[0]["DM_LOAN_NO"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_LOAN_NO"].ToString() : "";

                                    rblPaymentMode.SelectedValue = ds.Tables[0].Rows[0]["DM_PAYMENT_TYPE"] != DBNull.Value ?  ds.Tables[0].Rows[0]["DM_PAYMENT_TYPE"].ToString() : "-1";

                                    if (ds.Tables[0].Rows[0]["DM_PAYMENT_TYPE"].ToString() == "2")
                                    {
                                        tdlblPayment.Visible = true;
                                        tdlblIFSC.Visible = true;
                                        txtPTIFSC.Text = ds.Tables[0].Rows[0]["DM_PT_IFSC"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PT_IFSC"].ToString() : "";
                                        //txtPTIFSC.Enabled = false;
                                        dvNEFT.Visible = true;
                                        dvCheque.Visible = false;
                                    }
                                    if (ds.Tables[0].Rows[0]["DM_PAYMENT_TYPE"].ToString() == "1")
                                    {
                                        tdlblPayment.Visible = false;
                                        tdlblIFSC.Visible = false;
                                        dvNEFT.Visible = false;
                                        dvCheque.Visible = true;
                                        txtChequeReason.Text = ds.Tables[0].Rows[0]["DM_CHQ_RSN"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CHQ_RSN"].ToString() : "";
                                        
                                    }
                                   
                                    txtRemarks.Text = ds.Tables[0].Rows[0]["DM_REMARKS"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_REMARKS"].ToString() : "";
                                    txtDmApproveDate.Text = DateTime.Now.ToString("dd MMM yyyy");
                                   /* if (ddlAppCase.SelectedValue != "Manual")
                                    {
                                        ddlAppCase.SelectedValue = ds.Tables[0].Rows[0]["DM_APRL"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_APRL"].ToString() : "";
                                    }*/
                                    if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                                    {
                                        int ncount = ds.Tables[1].Rows.Count;
                                        txtFavDetail1.Text = ds.Tables[1].Rows[0]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_FAVOR"].ToString() : "";
                                        //   ttxBankName1.Text = ds.Tables[1].Rows[0]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_BANK"].ToString() : "";
                                        string strBank = ds.Tables[1].Rows[0]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_BANK"].ToString() : "";
                                        BankList();
                                        if (strBank != "")
                                        {

                                            string[] strBankArr = strBank.Split('|');

                                            ddlBank1.SelectedValue = strBankArr[0].ToString();
                                           
                                            txtBranch1.Text = strBankArr[1].ToString();
                                        }
                                        txtAccno1.Text = ds.Tables[1].Rows[0]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_AC_NO"].ToString() : "";
                                        txtTotal1.Text = ds.Tables[1].Rows[0]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_AMOUNT"].ToString() : "";

                                        if (ncount >= 2)
                                        {
                                            txtFavDetail2.Text = ds.Tables[1].Rows[1]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_FAVOR"].ToString() : "";
                                            //  ttxBankName2.Text = ds.Tables[1].Rows[1]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_BANK"].ToString() : "";
                                            string strBank1 = ds.Tables[1].Rows[1]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_BANK"].ToString() : "";
                                            if (strBank1 != "")
                                            {

                                                string[] strBankArr = strBank1.Split('|');

                                                ddlBank2.SelectedValue = strBankArr[0].ToString();
                                              
                                                txtBranch2.Text = strBankArr[1].ToString();
                                            }
                                            txtAccno2.Text = ds.Tables[1].Rows[1]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_AC_NO"].ToString() : "";
                                            txtTotal2.Text = ds.Tables[1].Rows[1]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_AMOUNT"].ToString() : "";
                                        }

                                        if (ncount >= 3)
                                        {
                                            txtFavDetail3.Text = ds.Tables[1].Rows[2]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_FAVOR"].ToString() : "";
                                            //  ttxBankName3.Text = ds.Tables[1].Rows[2]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_BANK"].ToString() : "";
                                            string strBank1 = ds.Tables[1].Rows[2]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_BANK"].ToString() : "";
                                            if (strBank1 != "")
                                            {

                                                string[] strBankArr = strBank1.Split('|');

                                                ddlBank3.SelectedValue = strBankArr[0].ToString();
                                             
                                                txtBranch3.Text = strBankArr[1].ToString();
                                            }
                                            txtAccno3.Text = ds.Tables[1].Rows[2]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_AC_NO"].ToString() : "";
                                            txtTotal3.Text = ds.Tables[1].Rows[2]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_AMOUNT"].ToString() : "";
                                        }

                                        if (ncount >= 4)
                                        {
                                            txtFavDetail4.Text = ds.Tables[1].Rows[3]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_FAVOR"].ToString() : "";
                                            //  ttxBankName3.Text = ds.Tables[1].Rows[2]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_BANK"].ToString() : "";
                                            string strBank1 = ds.Tables[1].Rows[3]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_BANK"].ToString() : "";
                                            if (strBank1 != "")
                                            {

                                                string[] strBankArr = strBank1.Split('|');

                                                ddlBank4.SelectedValue = strBankArr[0].ToString();
                                               
                                                txtBranch4.Text = strBankArr[1].ToString();
                                            }
                                            txtAccno4.Text = ds.Tables[1].Rows[3]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_AC_NO"].ToString() : "";
                                            txtTotal4.Text = ds.Tables[1].Rows[3]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_AMOUNT"].ToString() : "";
                                        }

                                        if (ncount >= 5)
                                        {
                                            txtFavDetail5.Text = ds.Tables[1].Rows[4]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_FAVOR"].ToString() : "";
                                            //  ttxBankName3.Text = ds.Tables[1].Rows[2]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_BANK"].ToString() : "";
                                            string strBank1 = ds.Tables[1].Rows[4]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_BANK"].ToString() : "";
                                            if (strBank1 != "")
                                            {

                                                string[] strBankArr = strBank1.Split('|');

                                                ddlBank5.SelectedValue = strBankArr[0].ToString();

                                                txtBranch5.Text = strBankArr[1].ToString();
                                            }
                                            txtAccno5.Text = ds.Tables[1].Rows[4]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_AC_NO"].ToString() : "";
                                            txtTotal5.Text = ds.Tables[1].Rows[4]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_AMOUNT"].ToString() : "";
                                        }


                                    }

                                }

                                //  ttxName1.Text = Session["EMPNAME"] != null ? Session["EMPNAME"].ToString() : "";

                           // }
                        }
                        else
                        {
                            uscMsgBox1.AddMessage("Invalid Sanction NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        }
                    }
                }
                else
                {
                    uscMsgBox1.AddMessage("Invalid Lead NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Please Enter the Lead NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    public DataSet fetchDMCDetail()
    {
        DataTable dtCam = null;
        DataSet dsdd = null;

        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_DMC_DETAILS", con);
            cmddd.Parameters.AddWithValue("@LEADID", Session["LeadID"] != null ? Session["LeadID"].ToString() : "");

            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);
            // dtCam = dsdd.Tables[nIndex];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dsdd;
    }
    protected void txtLeadNo_TextChanged(object sender, EventArgs e)
    {

    }
    public DataTable fetchCamDetail()
    {
        DataTable dtCam = null;

        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            //  SqlCommand cmddd = new SqlCommand("RTS_PR_Fetch_CAM", con);
            SqlCommand cmddd = new SqlCommand("RTS_PR_Fetch_CAM", con);
            cmddd.Parameters.AddWithValue("@LD_NO", Session["LeadNo"].ToString());

            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            dtCam = dsdd.Tables[0];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dtCam;
    }
    public DataTable fetchSanction(string strSanNO)
    {
        DataTable dtSanc = null;

        try
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand mycomm = new SqlCommand("SANC_LETR_SME", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@PrpslNo", SqlDbType.VarChar).Value = strSanNO;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            showdata.Fill(ds);
            dtSanc = ds.Tables[0];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
        }
        return dtSanc;
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            tblDMC.Visible = false;
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";

            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "All";

            }
            else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";
                ddlArea.Enabled = false;

            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";

            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";

            }
            else if (txtLeadno.Text.Trim() != "")
            {
                Session["View"] = "F";

            }

            BindqueryGrid();
            foreach (GridViewRow grow in gvQuery.Rows)
            {
                Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                int index = grow.RowIndex;
                if (lblQryResult.Text == "T")
                {
                    gvQuery.Rows[index].Cells[1].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[2].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[3].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[4].ForeColor = Color.Red;
                    gvQuery.Rows[index].Cells[5].ForeColor = Color.Red;
                }

            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_DM_SME_LAP, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", Session["View"].ToString());
            cmd.Parameters.AddWithValue("@LD_NO", ddlSearchBY.SelectedValue.ToString() == "Lead No" ? txtLeadno.Text : "");
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            /*if (Session["TYPEID"].ToString() == "3" || Session["TYPEID"].ToString() == "8" || Session["TYPEID"].ToString() == "14" || Session["TYPEID"].ToString() == "5" || Session["TYPEID"].ToString() == "6" || Session["TYPEID"].ToString() == "7")
            {
                cmd.Parameters.AddWithValue("@USERTYPE", "C");
                btnSubmit.Enabled = true;
            }
            else if (Session["TYPEID"].ToString() == "2")
            {
                cmd.Parameters.AddWithValue("@USERTYPE", "B");
            }*/
            /*bala changes 24/08/2017 for admin access for DM Modification befor disbursement starts*/
            //cmd.Parameters.AddWithValue("@USERTYPE", Session["TYPEID"].ToString());
            /*END*/
            //cmd.Parameters.AddWithValue("@PRODUCT", "SMELAP");
            //Implement Role based processing for DM
            var _userRole = String.Empty;
            if (Session[SessionKeys.USER_ROLE_GROUP] != null) { _userRole = Convert.ToString(Session[SessionKeys.USER_ROLE_GROUP]); }
            cmd.Parameters.AddWithValue(AppConstants.Param_UserRoleGroup, _userRole);
            //END - Implement Role based processing for DM
            cmd.Parameters.AddWithValue("@SANC_NO", ddlSearchBY.SelectedValue.ToString() == "Sanction No" ? txtLeadno.Text : "");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);

            if (ds1.Tables[0] != null && (ds1.Tables[0].Rows.Count > 0))
            {
                gvQuery.Visible = true;
                gvQuery.DataSource = ds1.Tables[0];
                gvQuery.DataBind();

                gvQuery.HeaderRow.Font.Bold = true;
                gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvQuery.HeaderRow.Cells[4].Text = "SANCTION NO";
                gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                gvQuery.HeaderRow.Cells[1].Wrap = false;
                gvQuery.HeaderRow.Cells[2].Wrap = false;
                gvQuery.HeaderRow.Cells[3].Wrap = false;
                gvQuery.HeaderRow.Cells[4].Wrap = false;
                gvQuery.HeaderRow.Cells[5].Wrap = false;
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvQuery.Visible = true;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            clear();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            foreach (GridViewRow grow in gvQuery.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                Label lblLeadID = grow.FindControl("lblLeadID") as Label;
                Label lblQryResult = grow.FindControl("lblQryResult") as Label;
                Label lblArea = grow.FindControl("lblArea") as Label;
                Label lblBranch = grow.FindControl("lblBranch") as Label;
                LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                Label lblLGAprl = grow.FindControl("lblLGAprl") as Label;
                Label lblProdID = grow.FindControl("lblProdID") as Label;

                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    if (lblLGAprl.Text != "1")
                    {
                        uscMsgBox1.AddMessage("Please check, You have selected lead is not legally approved.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        tblDMC.Visible = false;
                        chkStat.Checked = false;
                    }
                    else
                    {
                        if (Session[SessionKeys.USER_ROLE_GROUP] != null) { _userRoleGroup = Convert.ToString(Session[SessionKeys.USER_ROLE_GROUP]); }

                        /* Validation DM processing based on User role
                         * Validate applicable only for Branch, Credit and HO Users
                         * Super Admin will bypass this validation*/
                        String _leadNo = lnbtn.Text;
                        if (!String.IsNullOrEmpty(_userRoleGroup)
                            && ((_userRoleGroup == Convert.ToString(UserRoleGroup.AHO))
                                || (clscommon.ValidateDisbursalMemoEligibleForProcessing(_leadNo, _userRoleGroup))))
                        {
                            BankList();
                            leadno = lnbtn.Text;
                            appname = gvQuery.Rows[index].Cells[3].Text;
                            pddt = gvQuery.Rows[index].Cells[4].Text;
                            lnamt = gvQuery.Rows[index].Cells[5].Text;
                            Session["LeadNo"] = leadno;
                            Session["Appname"] = appname;
                            Session["LeadID"] = lblLeadID.Text;
                            Session["QryType"] = lblQryResult.Text;
                            Session["ANAME"] = lblArea.Text;
                            Session["BNAME"] = lblBranch.Text;
                            Session[SessionKeys.PR_ID] = lblProdID.Text;
                            FetchDMCValues();
                            bindPaymentMode();
                            ValidateUserAuthorizedForDMApproval();
                        }
                        else
                        {
                            uscMsgBox1.AddMessage(Disbursal_Memo_BusinessMessages.MSG_ERR_DM_PROCESSING_USER_UAUTHORIZED, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }
                    }
                }
            }

            propetydetails();
            lbLeadno.Visible = true;
            lbAppname.Visible = true;
            lbPDdate.Visible = true;
            lbLoanamt.Visible = true;

            ////btnSubmit.Enabled = true;
            ////btnCancel.Enabled = true;


            lbLeadno.Text = leadno.ToString();
            lbAppname.Text = appname;
            lbPDdate.Text = pddt;
            lbLoanamt.Text = lnamt;
            //if (Session["TYPEID"].ToString() == "2")
            //{
            //    ddlAppCase.SelectedIndex = 0;
            //}
            //else
            //{
            //    ddlAppCase.SelectedIndex = 1;
            //}
            con.Close();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void propetydetails()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("RTS_SP_RPT_LGL_PROPERTY_DETAILS", con);
            cmdrsn.CommandType = CommandType.StoredProcedure;
            cmdrsn.Parameters.AddWithValue("@LDNO", Convert.ToString(Session["LeadNo"]));
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

           // GVPropertyDetails.DataSource = dsrsn;
           // GVPropertyDetails.DataBind();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
            cmdrsn.CommandType = CommandType.StoredProcedure;
            cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

            ddlBranch.DataSource = dsrsn;
            ddlBranch.DataTextField = "BR_NAME";
            ddlBranch.DataValueField = "BR_ID";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));
            ddlBranch.Enabled = true;
            txtLeadno.Enabled = false;
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            String _leadNo = String.Empty;
            if (Session[SessionKeys.Leadno] != null) { _leadNo = Convert.ToString(Session[SessionKeys.Leadno]); }

            if (txtFavDetail1.Text == "" || ddlBank1.SelectedItem.Text == "--Select--" || txtAccno1.Text == "")
            {
                uscMsgBox1.AddMessage("Please give corresponding input for cheque details", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else if (Convert.ToDouble(txtTotAMnt.Text) != Convert.ToDouble(txtNetAmt.Text))
            {
                uscMsgBox1.AddMessage("Net disburse amount mis match with cheque amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else if (ddlAppCase.SelectedItem.Text == "--Select--" && Session["TYPEID"].ToString() == "3")
            {
                uscMsgBox1.AddMessage("Please Select Approve Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ddlAppCase.Focus();
            }
            else if (ddlAppCase.SelectedItem.Text == "--Select--" && Session["TYPEID"].ToString() == "8")
            {
                uscMsgBox1.AddMessage("Please Select Approve Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ddlAppCase.Focus();
            }
            else if (ddlAppCase.SelectedItem.Text == "--Select--" && Session["TYPEID"].ToString() == "14")
            {
                uscMsgBox1.AddMessage("Please Select Approve Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ddlAppCase.Focus();
            }
            else if (ddlAppCase.SelectedItem.Text == "--Select--" && Session["TYPEID"].ToString() == "5")
            {
                uscMsgBox1.AddMessage("Please Select Approve Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ddlAppCase.Focus();
            }
            else if (ddlAppCase.SelectedItem.Text == "--Select--" && Session["TYPEID"].ToString() == "6")
            {
                uscMsgBox1.AddMessage("Please Select Approve Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ddlAppCase.Focus();
            }
            else if (ddlAppCase.SelectedItem.Text == "--Select--" && Session["TYPEID"].ToString() == "7")
            {
                uscMsgBox1.AddMessage("Please Select Approve Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ddlAppCase.Focus();
            }
            else if (rblPaymentMode.SelectedIndex == -1)
            {
                uscMsgBox1.AddMessage("Please select any on of the payment method.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ddlAppCase.Focus();
            }
            else if (rblPaymentMode.SelectedItem.Text == "NEFT" && txtPTIFSC.Text == "")
            {
                uscMsgBox1.AddMessage("Please enter the IFSC Code.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ddlAppCase.Focus();
            }
            else if (rblPaymentMode.SelectedItem.Text == "CHEQUE" && txtChequeReason.Text == "")
            {
                uscMsgBox1.AddMessage("Please enter the cheque reason.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ddlAppCase.Focus();
            }
            else if (ddlAppCase != null && ddlAppCase.SelectedValue == AppConstants.DropdownDefaultSelection)
            {
                uscMsgBox1.AddMessage(Disbursal_Memo_BusinessMessages.MSG_DM_APPROVAL_STATUS_MANDATORY, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ddlAppCase.Focus();
            }
            else if (!String.IsNullOrEmpty(_userRoleGroup)
                && ((_userRoleGroup != Convert.ToString(UserRoleGroup.AHO)) && (!clscommon.ValidateDisbursalMemoEligibleForProcessing(_leadNo, _userRoleGroup))))
            {
                uscMsgBox1.AddMessage(Disbursal_Memo_BusinessMessages.MSG_ERR_DM_PROCESSING_USER_UAUTHORIZED, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                ddlAppCase.Focus();
            }
            else
            {
                /* if (ddlAppCase.SelectedValue == "Approved" || ddlAppCase.SelectedValue == "Manual")
                {
                    bool status;
                    bool rfdChk;
                    string leadID = Session["LeadID"].ToString();
                    status = getSancId(leadID);
                    rfdChk = ChkRFD(leadID);
                     if (status == true && rfdChk == true)
                     {
                         InsertDMCvalues();
                     }
                    else if(status == false)
                     {
                         uscMsgBox1.AddMessage("MOTD not done", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                         return;
                     }



                    if (rfdChk == true)
                    {
                        InsertDMCvalues();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("RFD not done", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        return;
                    }
                    
                }
                else
                {*/
                    int cntIFSC = 0;
                    if (rblPaymentMode.SelectedItem.Text == "NEFT")
                    {
                        cntIFSC = clscommon.Is_Bank_By_IFSC(txtPTIFSC.Text.Trim());
                        if (cntIFSC <= 0)
                        {
                            uscMsgBox1.AddMessage("Please enter the valid IFSC Code.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            return;
                        }
                    }
                    InsertDMCvalues();
                //}
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    public bool getSancId(string leadId)
    {
      
            SqlConnection conApprove = new SqlConnection(strcon);
            conApprove.Open();
            SqlCommand cmdApprove = new SqlCommand("RTS_SP_RFDMOTD", conApprove);
            cmdApprove.CommandType = CommandType.StoredProcedure;
            cmdApprove.Parameters.AddWithValue("@MD_LD_ID", leadId);
            string sancId = Convert.ToString(cmdApprove.ExecuteScalar());
            if (!string.IsNullOrEmpty(sancId))
                return true;
            else
                return false;
      
    }
    public bool ChkRFD(string lead)
    {
       
            SqlConnection conRFD = new SqlConnection(strcon);
            conRFD.Open();
            SqlCommand cmdApprove = new SqlCommand("RTS_SP_CHECK_RFD_STATUS", conRFD);
            cmdApprove.CommandType = CommandType.StoredProcedure;
            cmdApprove.Parameters.AddWithValue("@leadID", lead);
            int count = Convert.ToInt16(cmdApprove.ExecuteScalar());
            if (count > 0)
                return true;
            else
                return false;
        
    }
    public void InsertDMCvalues()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdinsert = new SqlCommand(AppConstants.PROC_RTS_SP_INSERTDCM_SME, con);
            cmdinsert.CommandType = CommandType.StoredProcedure;

            cmdinsert.Parameters.AddWithValue("@DM_LD_ID", Session["LeadID"].ToString());
            cmdinsert.Parameters.AddWithValue("@DM_DATE", Convert.ToDateTime(txtDate.Text));
            cmdinsert.Parameters.AddWithValue("@DM_LOAN_NO", txtLoanNUmber.Text);
            cmdinsert.Parameters.AddWithValue("@DM_SCHEME", "");
            cmdinsert.Parameters.AddWithValue("@DM_ROI", Convert.ToDouble(txtROI.Text));
            cmdinsert.Parameters.AddWithValue("@DM_PF", Convert.ToDouble(txtProcessFee.Text));
            cmdinsert.Parameters.AddWithValue("@DM_EMI", Convert.ToDouble(txtEMI.Text));
            cmdinsert.Parameters.AddWithValue("@DM_CSP", Convert.ToDouble(0));
            cmdinsert.Parameters.AddWithValue("@DM_PIP", Convert.ToDouble(0));
            cmdinsert.Parameters.AddWithValue("@DM_DISP_BUILD_TYPE", DBNull.Value);
            cmdinsert.Parameters.AddWithValue("@DM_DISP_DATE", DBNull.Value);
            cmdinsert.Parameters.AddWithValue("@DM_DISP_CNSTR_STAGE", DBNull.Value);
            cmdinsert.Parameters.AddWithValue("@DM_DISP_CNSTR_PER", DBNull.Value);
            cmdinsert.Parameters.AddWithValue("@DM_DISP_DEVI_PER", DBNull.Value);
            cmdinsert.Parameters.AddWithValue("@DM_NET_DISB", Convert.ToDouble(txtNetAmt.Text));
            cmdinsert.Parameters.AddWithValue("@DM_TENOR", Convert.ToInt32(txtTenor.Text));
            cmdinsert.Parameters.AddWithValue("@DM_BSTRUCT ", DBNull.Value);
            cmdinsert.Parameters.AddWithValue("@DM_MARGIN ", DBNull.Value);
            cmdinsert.Parameters.AddWithValue("@DM_TFEE", DBNull.Value);
            cmdinsert.Parameters.AddWithValue("@DM_AFEE", DBNull.Value);
            cmdinsert.Parameters.AddWithValue("@DM_CERSAI", DBNull.Value);
            cmdinsert.Parameters.AddWithValue("@DM_PURPOSE", "");
            cmdinsert.Parameters.AddWithValue("@DM_INSURANCE_PERSON", "");
            cmdinsert.Parameters.AddWithValue("@DM_PRPTY_OWNER", "");
            cmdinsert.Parameters.AddWithValue("@DM_PRPTY_ADDR", "");
            cmdinsert.Parameters.AddWithValue("@DM_PRPTY_SURVEY", "");
            cmdinsert.Parameters.AddWithValue("@DM_APRL", ddlAppCase.SelectedItem.Text);
            cmdinsert.Parameters.AddWithValue("@DM_APRL_BY", Session["ID"].ToString());
            cmdinsert.Parameters.AddWithValue("@DM_APRL_DATE", DateTime.Now);
            cmdinsert.Parameters.AddWithValue("@DM_REMARKS",txtRemarks.Text);
            cmdinsert.Parameters.AddWithValue("@DM_PAYMENT_TYPE", rblPaymentMode.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@DM_PT_IFSC", txtPTIFSC.Text);
            cmdinsert.Parameters.AddWithValue("@DM_CHQ_RSN", txtChequeReason.Text);
            cmdinsert.Parameters.AddWithValue("@ID", Session["ID"].ToString());

            if (Session[SessionKeys.USER_ROLE_GROUP] != null) { _userRoleGroup = Convert.ToString(Session[SessionKeys.USER_ROLE_GROUP]); }
            cmdinsert.Parameters.AddWithValue(AppConstants.Param_DM_TYPE, _userRoleGroup);

            if (_userRoleGroup == Convert.ToString(UserRoleGroup.C)
                || _userRoleGroup == Convert.ToString(UserRoleGroup.A)
                || _userRoleGroup == Convert.ToString(UserRoleGroup.HO)
                || _userRoleGroup == Convert.ToString(UserRoleGroup.AHO))
            {
                cmdinsert.Parameters.AddWithValue("@QTYPE", "UPDATE");
            }
            else if (_userRoleGroup == Convert.ToString(UserRoleGroup.B))
            {
                cmdinsert.Parameters.AddWithValue("@QTYPE", "INSERT");
            }

            int n = cmdinsert.ExecuteNonQuery();
            con.Close();

            if (n > 0)
            {
                InsertCheque();
                uscMsgBox1.AddMessage("Disbursal Memo Value Saved Sucessfully ", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

                tblDMC.Visible = false;
                BindqueryGrid();

                foreach (GridViewRow grow in gvQuery.Rows)
                {
                    Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                    int index = grow.RowIndex;

                    if (lblQryResult.Text == "T")
                    {
                        gvQuery.Rows[index].Cells[1].ForeColor = Color.Red;
                        gvQuery.Rows[index].Cells[2].ForeColor = Color.Red;
                        gvQuery.Rows[index].Cells[3].ForeColor = Color.Red;
                        gvQuery.Rows[index].Cells[4].ForeColor = Color.Red;
                        gvQuery.Rows[index].Cells[5].ForeColor = Color.Red;
                    }
                }

                lnkBtnPrint.Visible = true;
                lnkBtnPrint.Text = "Click here to download DM for " + Convert.ToString(Session["LeadNo"]);                
                clearValues();
                btnView.Focus();
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Disbursal Memo Value Failed to save ", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
    }
    public void InsertCheque()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            int nValue = 0;
            SqlCommand cmd = new SqlCommand("Select count(*) as count from  LSD_DISB_MEMO_CHQ where DMC_DM_ID IN (select DM_ID FROM  LSD_DISB_MEMO WHERE DM_LD_ID='" + Session["LeadID"].ToString() + "')", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0] != null)
            {
                nValue = ds.Tables[0].Rows[0][0] != DBNull.Value ? Convert.ToInt32(ds.Tables[0].Rows[0][0]) : 0;
            }


            if (txtFavDetail1.Text != "")
            {
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMCheque", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@DM_LD_ID", Session["LeadID"].ToString());
                cmdinsert.Parameters.AddWithValue("@DMC_CHEQUE", "CHEQUE1");
                cmdinsert.Parameters.AddWithValue("@DMC_BANK", ddlBank1.SelectedValue + "|" + txtBranch1.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_FAVOR", txtFavDetail1.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_AC_NO", txtAccno1.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_AMOUNT", txtTotal1.Text);
                if (nValue >= 1)
                {
                    cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
                }
                else
                {
                    cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
                }
                int n = cmdinsert.ExecuteNonQuery();

            }
            if (txtFavDetail2.Text != "")
            {
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMCheque", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@DM_LD_ID", Session["LeadID"].ToString());
                cmdinsert.Parameters.AddWithValue("@DMC_CHEQUE", "CHEQUE2");
                cmdinsert.Parameters.AddWithValue("@DMC_BANK", ddlBank2.SelectedValue + "|" + txtBranch2.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_FAVOR", txtFavDetail2.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_AC_NO", txtAccno2.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_AMOUNT", txtTotal2.Text);
                if (nValue >= 2)
                {
                    cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
                }
                else
                {
                    cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
                }

                int n = cmdinsert.ExecuteNonQuery();

            }
            if (txtFavDetail3.Text != "")
            {
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMCheque", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@DM_LD_ID", Session["LeadID"].ToString());
                cmdinsert.Parameters.AddWithValue("@DMC_CHEQUE", "CHEQUE3");
                cmdinsert.Parameters.AddWithValue("@DMC_BANK", ddlBank3.SelectedValue + "|" + txtBranch3.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_FAVOR", txtFavDetail3.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_AC_NO", txtAccno3.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_AMOUNT", txtTotal3.Text);
                if (nValue >= 3)
                {
                    cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
                }
                else
                {
                    cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
                }

                int n = cmdinsert.ExecuteNonQuery();

            }
            if (txtFavDetail4.Text != "")
            {
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMCheque", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@DM_LD_ID", Session["LeadID"].ToString());
                cmdinsert.Parameters.AddWithValue("@DMC_CHEQUE", "CHEQUE4");
                cmdinsert.Parameters.AddWithValue("@DMC_BANK", ddlBank4.SelectedValue + "|" + txtBranch4.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_FAVOR", txtFavDetail4.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_AC_NO", txtAccno4.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_AMOUNT", txtTotal4.Text);
                if (nValue >= 4)
                {
                    cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
                }
                else
                {
                    cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
                }

                int n = cmdinsert.ExecuteNonQuery();

            }
            if (txtFavDetail5.Text != "")
            {
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertDCMCheque", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@DM_LD_ID", Session["LeadID"].ToString());
                cmdinsert.Parameters.AddWithValue("@DMC_CHEQUE", "CHEQUE5");
                cmdinsert.Parameters.AddWithValue("@DMC_BANK", ddlBank5.SelectedValue + "|" + txtBranch5.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_FAVOR", txtFavDetail5.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_AC_NO", txtAccno5.Text);
                cmdinsert.Parameters.AddWithValue("@DMC_AMOUNT", txtTotal5.Text);
                if (nValue >= 5)
                {
                    cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "UPDATE");
                }
                else
                {
                    cmdinsert.Parameters.AddWithValue("@QUERYTYPE", "INSERT");
                }

                int n = cmdinsert.ExecuteNonQuery();

            }
            //Bala changes for DM Approval and request only for branch side
            //if (Session["TYPEID"].ToString() == "3" || Session["TYPEID"].ToString() == "8" || Session["TYPEID"].ToString() == "14" || Session["TYPEID"].ToString() == "5" || Session["TYPEID"].ToString() == "6" || Session["TYPEID"].ToString() == "7")
           // {
                sendMail(con);
            //}
            con.Close();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("LapDisbursalMemo.aspx");
    }
    protected void ddlAppCase_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = true;
    }
    public void sendMail(SqlConnection con)
    {
        try
        {
            /////// mail ///////////
            //  strMailDetail = "";

            SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "'", con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataSet dsdet = new DataSet();
            dadet.Fill(dsdet);

            SqlCommand cmdmail = new SqlCommand("select CASE WHEN ISNULL(QRY_SQUERY,'')='' THEN QRY_QUERY ELSE QRY_SQUERY END 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + Session["Leadno"].ToString() + "' AND QRY_RSD_BY='C'", con);
            SqlDataAdapter damail = new SqlDataAdapter(cmdmail);
            DataSet dsmail = new DataSet();
            damail.Fill(dsmail);

            /// to whom//////
            int nBranch_ID = dsdet.Tables[0].Rows[0]["LD_BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["LD_BR_ID"]) : 0;
            SqlCommand cmdmailto = new SqlCommand("SELECT EM_BM,EM_AM,EM_CM,EM_BCC FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            damailto.Fill(dsmailto);
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
                cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString();
                bcc = dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
            }

            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            //to = "ManimaranK@equitasbank.com";
            //bcc2 = "ManimaranK@equitasbank.com";
            //cc = "rts-helpdesk@equitasbank.com";
            fromID = "RTS Alerts";
            toID = to;
            bcc2ID = bcc2;
            ccID = cc;
            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Disbursal Memo - " + ddlAppCase.SelectedValue.ToString() + "<br/><br/>";
                BodyTxt = BodyTxt + "<table width='40%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Applicant Name</td><td><strong>" + Session["Appname"].ToString() + "</strong></td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Status</td><td><strong>" + ddlAppCase.SelectedValue.ToString() + "(RS. " + txtNetAmt.Text + ")</strong></td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Remarks</td><td><strong>" + txtRemarks.Text + "</strong></td></tr></table><br/><br/>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Address </td><td align='center'>:</td><td><strong>" + cusaddr + "</strong></td></tr>";
                //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Mobile No.</td><td align='center'>:</td><td><strong>" + mobile + "</strong></td></tr></table><br/><br/>";


                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>Credit Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
                //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

                blMailStatus = EmailManager.sendemail(to, "RTS Alerts", bcc2, cc, "Lead No. : " + Session["Leadno"].ToString() + " - Applicant Name : " + Session["Appname"].ToString() + " - Area : " + Session["ANAME"].ToString() + "- Brancg : " + Session["BNAME"].ToString() + " - Disbursal " + ddlAppCase.SelectedValue.ToString() + "", BodyTxt, "", true);
                //sendemail("SurendharR@equitasbank.com;PrabhakaranA@equitasbank.com;Tamilalagand@equitasbank.com", "surendharr@equitasbank.com", "Test", BodyTxt, "", true);

                strMailBody = BodyTxt.Replace("<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Disbursal " + ddlAppCase.SelectedItem.ToString() + "<br/><br/>", "");
                strMailBody = BodyTxt.Replace("</html>", " ");


            //});
            //// strMailDetail = to + "," + bcc2 + "," + cc;
            //threadSendMails.IsBackground = true;

            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(5000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }

    }
    public void BankList()
    {
        try
        {
            ddlBank1.Items.Clear();
            ddlBank2.Items.Clear();
            ddlBank3.Items.Clear();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_BIND_BANK", con);
            cmddd.CommandType = CommandType.StoredProcedure;
            cmddd.Parameters.AddWithValue("@BankName", "");
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            Session["Bank"] = dsdd.Tables[0];
            con.Close();
            ddlBank1.DataSource = dsdd;
            ddlBank1.DataTextField = "BK_NAME";
            ddlBank1.DataValueField = "BK_CODE";
            ddlBank1.DataBind();
            ddlBank1.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", ""));

            ddlBank2.DataSource = dsdd;
            ddlBank2.DataTextField = "BK_NAME";
            ddlBank2.DataValueField = "BK_CODE";
            ddlBank2.DataBind();
            ddlBank2.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", ""));


            ddlBank3.DataSource = dsdd;
            ddlBank3.DataTextField = "BK_NAME";
            ddlBank3.DataValueField = "BK_CODE";
            ddlBank3.DataBind();
            ddlBank3.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", ""));

            ddlBank4.DataSource = dsdd;
            ddlBank4.DataTextField = "BK_NAME";
            ddlBank4.DataValueField = "BK_CODE";
            ddlBank4.DataBind();
            ddlBank4.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", ""));

            ddlBank5.DataSource = dsdd;
            ddlBank5.DataTextField = "BK_NAME";
            ddlBank5.DataValueField = "BK_CODE";
            ddlBank5.DataBind();
            ddlBank5.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", ""));
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlBank1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (Session["Bank"] != null)
        //{
        //    DataTable tempBank = (DataTable)Session["Bank"];
        //    DataRow[] dr = tempBank.Select("BK_CODE ='" + ddlBank1.SelectedItem.Text + "'");
        //    if (dr.Length > 0)
        //    {
        //        DataTable tempBank1 = dr.CopyToDataTable();

        //        ddlBranch1.DataSource = tempBank1;
        //        ddlBranch1.DataTextField = "BK_BRANCH";
        //        ddlBranch1.DataValueField = "BK_BRANCH";
        //        ddlBranch1.DataBind();
        //        ddlBranch1.Items.Insert(0, new ListItem("--Select--", ""));
        //    }
        //    else
        //    {
        //        ddlBranch1.Items.Clear();
        //    }

       // }
    }
    protected void ddlBank2_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (Session["Bank"] != null)
        //{
        //    DataTable tempBank = (DataTable)Session["Bank"];
        //    DataRow[] dr = tempBank.Select("BK_CODE ='" + ddlBank2.SelectedItem.Text + "'");
        //    if (dr.Length > 0)
        //    {
        //        DataTable tempBank1 = dr.CopyToDataTable();

        //        ddlBranch2.DataSource = tempBank1;
        //        ddlBranch2.DataTextField = "BK_BRANCH";
        //        ddlBranch2.DataValueField = "BK_BRANCH";
        //        ddlBranch2.DataBind();
        //        ddlBranch2.Items.Insert(0, new ListItem("--Select--", ""));
        //    }
        //    else
        //    {
        //        ddlBranch2.Items.Clear();
        //    }


        //}
    }
    protected void ddlBank3_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (Session["Bank"] != null)
        //{
        //    DataTable tempBank = (DataTable)Session["Bank"];
        //    DataRow[] dr = tempBank.Select("BK_CODE ='" + ddlBank3.SelectedItem.Text + "'");
        //    if (dr.Length > 0)
        //    {
        //        DataTable tempBank1 = dr.CopyToDataTable();

        //        ddlBranch3.DataSource = tempBank1;
        //        ddlBranch3.DataTextField = "BK_BRANCH";
        //        ddlBranch3.DataValueField = "BK_BRANCH";
        //        ddlBranch3.DataBind();
        //        ddlBranch3.Items.Insert(0, new ListItem("--Select--", ""));
        //    }
        //    else
        //    {
        //        ddlBranch3.Items.Clear();
        //    }


        //}
    }
    public void clear()
    {
        try
        {
            txtFavDetail1.Text = "";
            ddlBank1.SelectedIndex = -1;
            txtBranch1.Text = "";
            txtAccno1.Text = "";
            txtTotal1.Text = "";
            txtTotAMnt.Text = "";

            txtFavDetail2.Text = "";
            ddlBank2.SelectedIndex = -1;
            txtBranch2.Text = "";
            txtAccno2.Text = "";
            txtTotal2.Text = "";

            txtFavDetail3.Text = "";
            ddlBank3.SelectedIndex = -1;
            txtBranch3.Text = "";
            txtAccno3.Text = "";
            txtTotal3.Text = "";

            txtFavDetail4.Text = "";
            ddlBank4.SelectedIndex = -1;
            txtBranch4.Text = "";
            txtAccno4.Text = "";
            txtTotal4.Text = "";

            txtFavDetail5.Text = "";
            ddlBank5.SelectedIndex = -1;
            txtBranch5.Text = "";
            txtAccno5.Text = "";
            txtTotal5.Text = "";

            txtCrdAprvDate.Text = "";
            txtSanDate.Text = "";
            txtExtendArea.Text = "";
            txtLegalStatus.Text = "";
            txtDmApproveDate.Text = "";
            txtRemarks.Text = "";
            ddlAppCase.SelectedIndex = -1;
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void Print()
    {
        try
        {
            //txtFavDetail1.Text = "";
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "Disbursal Memo Value Saved Sucessfully", true);
            FetchDMCValuesprint();

            System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();

            img.ImageUrl = Server.MapPath("~/Images/JPG/LAP_LOGO.jpg");
            tdLogo.Controls.Add(img);

            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=DMC_" + Convert.ToString(Session["LeadNo"]) + ".pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            StringWriter sw0 = new StringWriter();
            HtmlTextWriter hw0 = new HtmlTextWriter(sw0);
            pnlHeader.RenderControl(hw0);

            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            pnlpdf0.RenderControl(hw);

            StringReader sr1 = new StringReader(sw0.ToString() + "<br/>" + sw.ToString());

            Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.Open();
            pdfDoc.NewPage();
            pdfDoc.HtmlStyleClass = "PdfClass";
            htmlparser.Parse(sr1);
            pdfDoc.Close();
            Response.Write(pdfDoc);
            Response.End();

        }
        catch (Exception ex)
        {
            //ErrorLog.WriteError(ex);
            //   clearValues();
        }
        finally
        {
            //clearValues();
        }
    }

    public void FetchDMCValuesprint()
    {
        try
        {

      
        propertDet();
        DataTable dtCam = null;
        if (Session["LeadNo"].ToString() != "")
        {
            dtCam = fetchCamDetail();
            if (dtCam != null && dtCam.Rows.Count > 0)
            {
                string strSancNOPrint = dtCam.Rows[0]["LD_SANTD_NO"] != DBNull.Value ? dtCam.Rows[0]["LD_SANTD_NO"].ToString() : "";
                lblLeadNo1.Text = Session["LeadNo"].ToString();
                lblAreaName.Text = dtCam.Rows[0]["AR_NAME"] != DBNull.Value ? dtCam.Rows[0]["AR_NAME"].ToString() : "";
                lblBranchName.Text = dtCam.Rows[0]["BR_NAME"] != DBNull.Value ? dtCam.Rows[0]["BR_NAME"].ToString() : "";
                lblLandarea.Text = dtCam.Rows[0]["CAM_LAREA"] != DBNull.Value ? dtCam.Rows[0]["CAM_LAREA"].ToString() : "";
                lblExtendArea.Text = dtCam.Rows[0]["MD_EXTENT"] != DBNull.Value ? dtCam.Rows[0]["MD_EXTENT"].ToString() : "";

                StringBuilder sb = new StringBuilder();
                sb.Append(dtCam.Rows[0]["MP_PROP"] != DBNull.Value ? dtCam.Rows[0]["MP_PROP"].ToString() : "");
                sb.Append(dtCam.Rows[0]["MP_NORTH"] != DBNull.Value ? "North By" + dtCam.Rows[0]["MP_NORTH"].ToString() + ", " : "");
                sb.Append(dtCam.Rows[0]["MP_SOUTH"] != DBNull.Value ? "South By" + dtCam.Rows[0]["MP_SOUTH"].ToString() + ", " : "");
                sb.Append(dtCam.Rows[0]["MP_EAST"] != DBNull.Value ? "East By" + dtCam.Rows[0]["MP_EAST"].ToString() + ", " : "");
                sb.Append(dtCam.Rows[0]["MP_WEST"] != DBNull.Value ? "West By" + dtCam.Rows[0]["MP_WEST"].ToString() + ". " : "");
                sb.Append(dtCam.Rows[0]["MP_MEASURE"] != DBNull.Value ? "Measurement :" + dtCam.Rows[0]["MP_MEASURE"].ToString() + ". " : "");
                sb.Append(dtCam.Rows[0]["MP_REGISTR"] != DBNull.Value ? dtCam.Rows[0]["MP_REGISTR"].ToString() + ". " : "");

                lblLglPropDetails.Text = sb.ToString();

                lblLglConclustion.Text = dtCam.Rows[0]["MR_CONCL"] != DBNull.Value ? dtCam.Rows[0]["MR_CONCL"].ToString() : "";

                tblDMC.Visible = true;
                if (strSancNOPrint != "")
                {
                    DataTable dtSanc = null;
                    dtSanc = fetchSanction(strSancNOPrint);

                    if (dtSanc != null && dtSanc.Rows.Count > 0)
                    {
                        //
                        tblDMC.Visible = true;
                        lblProposalNo.Text = dtSanc.Rows[0]["PROPOSAL NO"] != DBNull.Value ? dtSanc.Rows[0]["PROPOSAL NO"].ToString() : "";
                        lblScheme.Text = dtSanc.Rows[0]["SCHEME DESCR"] != DBNull.Value ? dtSanc.Rows[0]["SCHEME DESCR"].ToString() : "";
                        lblAppName.Text = dtSanc.Rows[0]["CUSTOMER NAME"] != DBNull.Value ? dtSanc.Rows[0]["CUSTOMER NAME"].ToString() : "";
                        lblCoAppName.Text = dtSanc.Rows[0]["CO-APPLICANT NAME"] != DBNull.Value ? dtSanc.Rows[0]["CO-APPLICANT NAME"].ToString() : "";
                        lblLoanAMount.Text = dtSanc.Rows[0]["SANCTION AMOUNT"] != DBNull.Value ? dtSanc.Rows[0]["SANCTION AMOUNT"].ToString() : "";
                        lblROI.Text = dtSanc.Rows[0]["RATE OF INTEREST"] != DBNull.Value ? dtSanc.Rows[0]["RATE OF INTEREST"].ToString() : "";
                        lblProcessFee.Text = dtSanc.Rows[0]["PROCESSING FEE"] != DBNull.Value ? dtSanc.Rows[0]["PROCESSING FEE"].ToString() : "0";
                        lblEMI.Text = dtSanc.Rows[0]["INDICATIVE EMI"] != DBNull.Value ? dtSanc.Rows[0]["INDICATIVE EMI"].ToString() : "";
                        lblTenor.Text = dtSanc.Rows[0]["TERM IN MONTHS"] != DBNull.Value ? dtSanc.Rows[0]["TERM IN MONTHS"].ToString() : "";
                        lblCSPM.Text = dtSanc.Rows[0]["CREDIT SHIELD PREMIUM"] != DBNull.Value ? dtSanc.Rows[0]["CREDIT SHIELD PREMIUM"].ToString() : "0";
                        lblPIPM.Text = dtSanc.Rows[0]["PROPERTY INSURANCE PREMIUM"] != DBNull.Value ? dtSanc.Rows[0]["PROPERTY INSURANCE PREMIUM"].ToString() : "0";
                        lblCersai.Text = dtSanc.Rows[0]["CERSAI"] != DBNull.Value ? dtSanc.Rows[0]["CERSAI"].ToString() : "0";
                        lblAdminFee.Text = dtSanc.Rows[0]["ADMIN FEE"] != DBNull.Value ? dtSanc.Rows[0]["ADMIN FEE"].ToString() : "0";
                        //lblTechFee.Text = dtSanc.Rows[0]["TECHNICAL PROCESSING FEE"] != DBNull.Value ? dtSanc.Rows[0]["TECHNICAL PROCESSING FEE"].ToString() : "0";
                        lblLegalFee.Text = dtSanc.Rows[0]["LEGAL PROCESSING FEE"] != DBNull.Value ? dtSanc.Rows[0]["LEGAL PROCESSING FEE"].ToString() : "0";
                        lblCattleIns.Text = dtSanc.Rows[0]["CATTLE INSURANCE"] != DBNull.Value ? dtSanc.Rows[0]["CATTLE INSURANCE"].ToString() : "0";
                        lblAccidentalInsur.Text = dtSanc.Rows[0]["ACCIDENTAL_INSURANCE"] != DBNull.Value ? dtSanc.Rows[0]["ACCIDENTAL_INSURANCE"].ToString() : "0";
                        lblDocumentCharges.Text = dtSanc.Rows[0]["DOCUMENDATION_CHARGES"] != DBNull.Value ? dtSanc.Rows[0]["DOCUMENDATION_CHARGES"].ToString() : "0";
                        double dbnNetDisbursalAmtPrint = 0;
                            //dbnNetDisbursalAmtPrint = Convert.ToDouble(lblLoanAMount.Text) - (Convert.ToDouble(lblProcessFee.Text) + Convert.ToDouble(lblCSPM.Text) + Convert.ToDouble(lblPIPM.Text) + Convert.ToDouble(lblCersai.Text) + Convert.ToDouble(lblAdminFee.Text) + Convert.ToDouble(lblTechFee.Text) + Convert.ToDouble(lblCattleIns.Text) + Convert.ToDouble(lblAccidentalInsur.Text) + Convert.ToDouble(lblDocumentCharges.Text));
                            dbnNetDisbursalAmtPrint = Convert.ToDouble(lblLoanAMount.Text) - (Convert.ToDouble(lblProcessFee.Text) + Convert.ToDouble(lblCSPM.Text) + Convert.ToDouble(lblPIPM.Text) + Convert.ToDouble(lblCersai.Text) + Convert.ToDouble(lblAdminFee.Text) + Convert.ToDouble(lblLegalFee.Text) + Convert.ToDouble(lblCattleIns.Text) + Convert.ToDouble(lblAccidentalInsur.Text) + Convert.ToDouble(lblDocumentCharges.Text));
                            //dbnNetDisbursalAmtPrint = Convert.ToDouble(lblLoanAMount.Text) - (Convert.ToDouble(lblProcessFee.Text) + Convert.ToDouble(lblCSPM.Text) + Convert.ToDouble(lblPIPM.Text) + Convert.ToDouble(lblCersai.Text) + Convert.ToDouble(lblAdminFee.Text) + Convert.ToDouble(lblTechFee.Text));
                            lblNetAmt.Text = Convert.ToString(dbnNetDisbursalAmtPrint);

                        lblCrdAprvDate.Text = dtCam.Rows[0]["LD_CRAP_DATE"] != DBNull.Value ? Convert.ToDateTime(dtCam.Rows[0]["LD_CRAP_DATE"]).ToString("dd/MM/yyyy") : "";

                        string strDatePrint = dtSanc.Rows[0]["SANCTION DATE"] != DBNull.Value ? dtSanc.Rows[0]["SANCTION DATE"].ToString() : "";
                        if (strDatePrint != "")
                        {
                            lblSanDate.Text = Convert.ToDateTime(strDatePrint).ToString("dd/MM/yyyy");
                        }



                        string strLgAprvPrint = dtCam.Rows[0]["LD_LG_APRL"] != DBNull.Value ? dtCam.Rows[0]["LD_LG_APRL"].ToString() : "";
                        if (strLgAprvPrint == "1")
                        {
                            lblLegalStatus.Text = "Approval";
                        }
                        else
                        {
                            lblLegalStatus.Text = "Un Approval";
                        }
                        string strLandValPrint = dtCam.Rows[0]["CAM_LAREA"] != DBNull.Value ? dtCam.Rows[0]["CAM_LAREA"].ToString() : "";




                        DataSet ds = fetchDMCDetail();
                        if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        {
                            lblLoanNUmber.Text = ds.Tables[0].Rows[0]["DM_LOAN_NO"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_LOAN_NO"].ToString() : "";
                            lblDate.Text = ds.Tables[0].Rows[0]["DM_DATE"] != DBNull.Value ? Convert.ToDateTime(ds.Tables[0].Rows[0]["DM_DATE"]).ToString("dd/MM/yyyy") : "";
                            lblRemarks.Text = ds.Tables[0].Rows[0]["DM_REMARKS"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_REMARKS"].ToString() : "";
                            //lblDmApproveDate.Text = ds.Tables[0].Rows[0]["DM_APRL_DATE"] != DBNull.Value ? Convert.ToDateTime(ds.Tables[0].Rows[0]["DM_APRL_DATE"].ToString()).ToString("dd/MM/yyyy") : "";
                            lblDmApproveDate.Text = ds.Tables[0].Rows[0]["DM_CDATE"] != DBNull.Value ? Convert.ToDateTime(ds.Tables[0].Rows[0]["DM_CDATE"].ToString()).ToString("dd/MM/yyyy") : "";
                            txtPTIFSC.Text = ds.Tables[0].Rows[0]["DM_PT_IFSC"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PT_IFSC"].ToString() : "";
                            if (ds.Tables[0].Rows[0]["DM_PAYMENT_TYPE"] != DBNull.Value)
                            {
                                if (ds.Tables[0].Rows[0]["DM_PAYMENT_TYPE"].ToString() == "2")
                                {

                                    lblPaymentMode.Text = "NEFT";
                                    tdlblPayment.Visible = true;
                                    tdlblPayment1.Visible = true;
                                    tdIFSC1.Visible = true;
                                    dvNEFTPrint.Visible = true;
                                    dvChequePrint.Visible = false;
                                    lblPTIFSC.Text = ds.Tables[0].Rows[0]["DM_PT_IFSC"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_PT_IFSC"].ToString() : "";
                                }
                                else
                                {
                                    lblPaymentMode.Text = "CHEQUE";
                                    dvNEFTPrint.Visible = false;
                                    dvChequePrint.Visible = true;
                                    lblChqRsn.Text = ds.Tables[0].Rows[0]["DM_CHQ_RSN"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CHQ_RSN"].ToString() : "";
                                }
                            }
                            dmmby = ds.Tables[0].Rows[0]["DM_MBY"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_MBY"].ToString() : "0";
                            DataTable dt = fetchUserDets(dmmby);

                            if (dt.Rows.Count > 0)
                            {
                               
                                lblName1.Text = dt.Rows[0]["EMP_NAME"] != DBNull.Value ? dt.Rows[0]["EMP_NAME"].ToString() : "";
                                lblCode1.Text = dt.Rows[0]["EMP_CODE"] != DBNull.Value ? dt.Rows[0]["EMP_CODE"].ToString() : "";
                                lblDate1.Text = dt.Rows[0]["DATE"] != DBNull.Value ? dt.Rows[0]["DATE"].ToString() : "";
                            }
                            else
                            {
                                lblName1.Text = "";
                                lblCode1.Text = "";
                                lblDate1.Text = "";
                            }

                            string dmmby1 = ds.Tables[0].Rows[0]["DM_CBY"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_CBY"].ToString() : "0";
                            DataTable dt1 = fetchUserDets(dmmby1);

                            if (dt1.Rows.Count > 0)
                            {

                                lblAppCase.Text = dt1.Rows[0]["EMP_NAME"] != DBNull.Value ? dt1.Rows[0]["EMP_NAME"].ToString() : "";
                            }
                            //bala changes 07/07/2017
                           // lblAppCase.Text = ds.Tables[0].Rows[0]["DM_APRL"] != DBNull.Value ? ds.Tables[0].Rows[0]["DM_APRL"].ToString() : "";
                            if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                            {
                                int ncount = ds.Tables[1].Rows.Count;
                                lblFavDetail1.Text = ds.Tables[1].Rows[0]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_FAVOR"].ToString() : "";

                                string[] dmcbnk = ds.Tables[1].Rows[0]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_BANK"].ToString().Split('|') : null;
                                string bnkNme1 = ds.Tables[1].Rows[0]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[0]["BK_NAME"].ToString() : "";
                                if (dmcbnk != null)
                                {
                                    bnkNme1 = bnkNme1 + " - " + dmcbnk[1].ToString();
                                }

                             
                                lblBankName1.Text = bnkNme1;
                                lblAccno1.Text = ds.Tables[1].Rows[0]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_AC_NO"].ToString() : "";
                                lblTotal1.Text = ds.Tables[1].Rows[0]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[0]["DMC_AMOUNT"].ToString() : "";

                                if (ncount >= 2)
                                {
                                    lblFavDetail2.Text = ds.Tables[1].Rows[1]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_FAVOR"].ToString() : "";

                                    string[] dmcbnk2 = ds.Tables[1].Rows[1]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_BANK"].ToString().Split('|') : null;
                                    string bnkNme2 = ds.Tables[1].Rows[1]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[1]["BK_NAME"].ToString() : "";
                                    if (dmcbnk2 != null)
                                    {
                                        bnkNme2 = bnkNme2 + " - " + dmcbnk2[1].ToString();
                                    }
                                 
                                    lblBankName2.Text = bnkNme2;
                                    lblAccno2.Text = ds.Tables[1].Rows[1]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_AC_NO"].ToString() : "";
                                    lblTotal2.Text = ds.Tables[1].Rows[1]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[1]["DMC_AMOUNT"].ToString() : "";
                                }

                                if (ncount >= 3)
                                {
                                    
                                    lblFavDetail3.Text = ds.Tables[1].Rows[2]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_FAVOR"].ToString() : "";
                                    string[] dmcbnk3 = ds.Tables[1].Rows[2]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_BANK"].ToString().Split('|') : null;
                                    string bnkNme3 = ds.Tables[1].Rows[2]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[2]["BK_NAME"].ToString() : "";
                                    if (dmcbnk3 != null)
                                    {
                                        bnkNme3 = bnkNme3 + " - " + dmcbnk3[1].ToString();
                                    }
                                    lblBankName3.Text = bnkNme3;
                                    lblAccno3.Text = ds.Tables[1].Rows[2]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_AC_NO"].ToString() : "";
                                    lblTotal3.Text = ds.Tables[1].Rows[2]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[2]["DMC_AMOUNT"].ToString() : "";
                                }

                                if (ncount >= 4)
                                {
                                   
                                    lblFavDetail4.Text = ds.Tables[1].Rows[3]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_FAVOR"].ToString() : "";
                                    string[] dmcbnk4 = ds.Tables[1].Rows[3]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_BANK"].ToString().Split('|') : null;
                                    string bnkNme4 = ds.Tables[1].Rows[3]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[3]["BK_NAME"].ToString() : "";
                                    if (dmcbnk4 != null)
                                    {
                                        bnkNme4 = bnkNme4 + " - " + dmcbnk4[1].ToString();
                                    }
                                    lblBankName4.Text = bnkNme4;
                                    lblAccno4.Text = ds.Tables[1].Rows[3]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_AC_NO"].ToString() : "";
                                    lblTotal4.Text = ds.Tables[1].Rows[3]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[3]["DMC_AMOUNT"].ToString() : "";
                                }


                                if (ncount >= 5)
                                {

                                    lblFavDetail5.Text = ds.Tables[1].Rows[4]["DMC_FAVOR"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_FAVOR"].ToString() : "";
                                    string[] dmcbnk5 = ds.Tables[1].Rows[4]["DMC_BANK"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_BANK"].ToString().Split('|') : null;
                                    string bnkNme5 = ds.Tables[1].Rows[4]["BK_NAME"] != DBNull.Value ? ds.Tables[1].Rows[4]["BK_NAME"].ToString() : "";
                                    if (dmcbnk5 != null)
                                    {
                                        bnkNme5 = bnkNme5 + " - " + dmcbnk5[1].ToString();
                                    }
                                    lblBankName5.Text = bnkNme5;
                                    lblAccno5.Text = ds.Tables[1].Rows[4]["DMC_AC_NO"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_AC_NO"].ToString() : "";
                                    lblTotal5.Text = ds.Tables[1].Rows[4]["DMC_AMOUNT"] != DBNull.Value ? ds.Tables[1].Rows[4]["DMC_AMOUNT"].ToString() : "";
                                }
                            }

                        }


                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Invalid Lead NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Invalid Lead NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
        }
        else
        {
            uscMsgBox1.AddMessage("Please Enter the Lead NO..", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        }
            catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }

    public DataTable fetchUserDets(string userid)
    {
        DataTable dtusr = null;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            DataSet ds = new DataSet();

            con.Open();
            SqlCommand mycomm = new SqlCommand("RTS_SP_GET_USER_DETAILS", con);
            mycomm.CommandType = CommandType.StoredProcedure;
            mycomm.Parameters.Add("@USRID", SqlDbType.VarChar).Value = userid;
            SqlDataAdapter showdata = new SqlDataAdapter(mycomm);
            showdata.Fill(ds);
            dtusr = ds.Tables[0];

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
        return dtusr;
    }

    public void propertDet()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("RTS_SP_RPT_LGL_PROPERTY_DETAILS", con);
            cmdrsn.CommandType = CommandType.StoredProcedure;
            cmdrsn.Parameters.AddWithValue("@LDNO", Convert.ToString(Session["LeadNo"]));
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

           // GridView1.DataSource = dsrsn;
           // GridView1.DataBind();

            //gvConclustion.DataSource = dsrsn;
            //gvConclustion.DataBind();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    
    protected void lnkBtnPrint_Click(object sender, EventArgs e)
    {
        Print();
    }

    protected void clearValues()
    {
        lbLeadno.Text = "";
        lbAppname.Text = "";
        lbPDdate.Text = "";

        txtLeadno.Text = "";
        txtProposalNo.Text = "";
        txtLoanNUmber.Text = "";
        txtAreaName.Text = "";
        txtBranchName.Text = "";
      //  txtDate.Text = "";
        txtScheme.Text = "";
        txtSchemePatern.Text = "";
        txtLandSqft.Text = "";
        txtAppName.Text = "";
        txtCoAppName.Text = ""; 

        txtLoanAMount.Text = "";
        txtROI.Text = "";
        txtProcessFee.Text = "";
        txtactProcessFee.Text = "";
        txtlgnfee.Text = "";
        txtEMI.Text = "";
        txtCSPM.Text = "";
        txtTenor.Text = "";
        txtPIPM.Text = "";
        txtCersai.Text = "";
        txtAdminFee.Text = "";
        //txtTechFee.Text = "";
        txtLegalFee.Text = "";
        txtCattleIns.Text = "";
        txtAccidentalInsur.Text = "";
        txtDocumentCharges.Text = "";
        txtFavDetail1.Text = "";
        ddlBank1.SelectedIndex = 0;
        txtBranch1.Text = "";
        txtAccno1.Text = "";
        txtTotal1.Text = "";
        txtFavDetail2.Text = "";
        ddlBank1.SelectedIndex = 0;
        txtBranch2.Text = "";
        txtAccno2.Text = "";
        txtTotal2.Text = "";
        txtFavDetail3.Text = "";
        ddlBank3.SelectedIndex = 0;
        txtBranch3.Text = "";
        txtAccno3.Text = "";
        txtTotal3.Text = "";

        txtCrdAprvDate.Text = "";
        txtSanDate.Text = "";
        txtExtendArea.Text = "";
        txtLegalStatus.Text = "";
        ddlAppCase.SelectedIndex = 0;
        txtDmApproveDate.Text = "";
        txtRemarks.Text = "";


        lblLeadNo1.Text = "";
        lblProposalNo.Text = "";
        lblLoanNUmber.Text = "";
        lblAreaName.Text = "";
        lblBranchName.Text = "";
        lblDate.Text = "";
        lblScheme.Text = "";
        lblSchemePatern.Text = "";
        //lblLandSqft.Text = "";
        lblAppName.Text = "";
        lblCoAppName.Text = "";

        lblLoanAMount.Text = "";
        lblROI.Text = "";
        lblProcessFee.Text = "";
        lblEMI.Text = "";
        lblCSPM.Text = "";
        lblTenor.Text = "";
        lblPIPM.Text = "";
        lblCersai.Text = "";
        lblAdminFee.Text = "";
        //lblTechFee.Text = "";
        lblLegalFee.Text = "";
        lblCattleIns.Text = "";
        lblAccidentalInsur.Text = "";
        lblDocumentCharges.Text = "";
        lblFavDetail1.Text = "";
        lblBankName1.Text = "";
        //lblBranch1.Text = "";
        lblAccno1.Text = "";
        lblTotal1.Text = "";

        lblFavDetail2.Text = "";
        lblBankName2.Text = "";
        //txtBranch2.Text = "";
        lblAccno2.Text = "";
        lblTotal2.Text = "";

        lblFavDetail3.Text = "";
        lblBankName3.Text = "";
        //txtBranch3.Text = "";
        lblAccno3.Text = "";
        lblTotal3.Text = "";

        lblFavDetail4.Text = "";
        lblBankName4.Text = "";
        //txtBranch3.Text = "";
        lblAccno4.Text = "";
        lblTotal4.Text = "";

        lblFavDetail5.Text = "";
        lblBankName5.Text = "";
        //txtBranch3.Text = "";
        lblAccno5.Text = "";
        lblTotal5.Text = "";

        lblCrdAprvDate.Text = "";
        lblSanDate.Text = "";
        lblExtendArea.Text = "";
        lblLegalStatus.Text = "";
        //ddlAppCase.SelectedIndex = 0;
        lblAppCase.Text = "";
        lblDmApproveDate.Text = "";
        lblRemarks.Text = "";

        lblName1.Text = "";
        lblCode1.Text = "";
        lblDate1.Text = "";
        lblName2.Text = "";
        lblCode2.Text = "";
        lblDate2.Text = "";

        //Session["LeadID"] = "";
        BindqueryGrid();
        //propetydetails();
    }
    protected void rblPaymentMode_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            
            if(rblPaymentMode.SelectedItem.Text=="NEFT")
            {
                tdlblPayment.Visible = true;
                tdlblIFSC.Visible = true;
                dvNEFT.Visible = true;
                dvCheque.Visible = false;
            }
            else
            if (rblPaymentMode.SelectedItem.Text == "CHEQUE")
            {
                tdlblPayment.Visible = false;
                tdlblIFSC.Visible = false;
                dvNEFT.Visible = false;
                dvCheque.Visible = true;
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlBank4_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlBank5_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void FetchCreditConditions()
    {
        DataTable dtCam = null;
        
        try
        {
            String creditConditionCmd = String.Empty;
            String creditConditionColumn = String.Empty;
            Int64 prodID = 0;

            if(Session[SessionKeys.PR_ID] != null) { Int64.TryParse(Convert.ToString(Session[SessionKeys.PR_ID]), out prodID); }

            if (prodID == Convert.ToInt64(Declared_Product_Program.IB_SME_Secured_D))
            {
                creditConditionCmd = "SELECT * FROM [dbo].[LSD_DECLARED_INCOME_SUMMARY] DIS JOIN LSD_LEAD LD ON DIS.DIS_LD_ID = LD.LD_ID WHERE DIS_LD_ID = " + Convert.ToInt32(Session["LeadID"].ToString());
                creditConditionColumn = AppConstants.Col_DIS_CRDT_COND;
            }
            else
            {
                creditConditionCmd = "SELECT * FROM LSD_CAM_MEMO CM JOIN LSD_LEAD LD ON CM.CM_LD_ID = LD.LD_ID WHERE CM_LD_ID = " + Convert.ToInt32(Session["LeadID"].ToString());
                creditConditionColumn = AppConstants.Col_CM_CREDIT;
            }

            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                using (SqlCommand cmddd = new SqlCommand(creditConditionCmd, con))
                {
                    cmddd.CommandType = CommandType.Text;
                    cmddd.CommandTimeout = 180000;
                    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
                    DataSet dsdd = new DataSet();
                    dadd.Fill(dsdd);

                    if(dsdd != null && dsdd.Tables.Count > 0)
                    {
                        dtCam = dsdd.Tables[0];
                        string newText = "";
                        string txtVal = "";
                        if (dtCam != null && dtCam.Rows.Count > 0)
                        {                            
                            txtVal = dtCam.Rows[0][creditConditionColumn] != DBNull.Value ? dtCam.Rows[0][creditConditionColumn].ToString() : "";

                            //Replace </br> tags with new line
                            Regex regex = new Regex(@"(<br />|<br/>|</ br>|</br>)");
                            newText = regex.Replace(txtVal, "\r\n");

                            //Replace &amp; tags with blank space
                            regex = new Regex(@"(&amp;)");
                            newText = regex.Replace(newText, "and");

                            txtBxCreditConditions.Text = newText;
                        }
                    }
                    
                    con.Close();
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    private void ValidateUserAuthorizedForDMApproval()
    {
        if (Session[SessionKeys.USER_ROLE_GROUP] != null)
        { _userRoleGroup = Convert.ToString(Session[SessionKeys.USER_ROLE_GROUP]); }

        //DM Approval status will be set as per business
        //Ho-Ops/Admin/Credit Users can modify the approval status and submit DM
        if ((_userRoleGroup == Convert.ToString(UserRoleGroup.HO))
            || (_userRoleGroup == Convert.ToString(UserRoleGroup.C))
            || (_userRoleGroup == Convert.ToString(UserRoleGroup.A))
            || (_userRoleGroup == Convert.ToString(UserRoleGroup.AHO)))
        {
            if (ddlAppCase.Enabled == false) { lnkDmApproval.Visible = true; }
            else { lnkDmApproval.Visible = false; }
        }

        //Branch Users
        if (_userRoleGroup == Convert.ToString(UserRoleGroup.B))
        {
            ddlAppCase.Enabled = false;
            ddlAppCase.SelectedValue = "Approved";
            lnkDmApproval.Visible = false;
        }
    }

    public void lnkDmApproval_Click(object sender, EventArgs e)
    {
        if (ddlAppCase != null
            && ddlAppCase.Visible == true
            && ddlAppCase.Enabled == false)
        {
            ddlAppCase.Enabled = true;
        }
    }
}