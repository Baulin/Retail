﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using Tracker;
using System.Web.UI.WebControls;
public partial class FIRCU_VALUER_SUMMARY : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    string ldid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnDownload);
        if (!IsPostBack)
        {
            ViewState["SampLDNO"] = null;
            BindCamType();
            bindInitType();
            //BindLeadNo();
        }
    }
    public void BindCamType()
    {
        string strUserType = Session["TYPEID"] != null ? Session["TYPEID"].ToString() : "";

        if (strUserType != "")
        {

        }
    }
    public void bindInitType()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("select PDITYPE_ID,PDITYPE_NAME from MR_PD_INIT_TYPE WHERE PDITYPE_ID NOT IN (1,2)", con);
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

            ddlInitType.DataSource = dsrsn;
            ddlInitType.DataTextField = "PDITYPE_NAME";
            ddlInitType.DataValueField = "PDITYPE_ID";
            ddlInitType.DataBind();
            ddlInitType.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnDownload_Click(object sender, EventArgs e)
    {
        try
        {
            // LinkButton lnlk = (LinkButton)sender;
            //string[] fileNames = Directory.GetFiles(Server.MapPath("~\\Upload\\File\\"));
            int i = 0;
            string[] fileNames = Directory.GetFiles(Server.MapPath("~\\Upload\\FIRCU\\"));
            foreach (var item in fileNames)
            {
                int nameIndex = item.LastIndexOf("\\") + 1;
                string f = item.Remove(0, nameIndex);
                if (f.Contains("."))
                {
                    f = f.Remove(f.Length - 4);
                }

                string[] stExtension = f.Split('.');
                string ext = Path.GetExtension(item);
                if (ddlInitType.SelectedItem.Text+"_"+ txtbxleadno.Text.ToUpper() == stExtension[0].ToString())
                {
                    Response.ContentType = ContentType;
                    Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(item));
                    //Response.AppendHeader("Content-Disposition", "attachment; filename=CAM_" + txtbxleadno.Text.ToUpper()+ext);
                    Response.WriteFile(item);
                    Response.End();
                    i = i + 1;
                }

            }
            if (i == 0)
            {

                uscMsgBox1.AddMessage("No records found.", YaBu.MessageBox.uscMsgBox.enmMessageType.Info);

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    /* private void RegisterPostBackControl()
     {
         foreach (GridViewRow row in gvLegalRecvDoc.Rows)
         {
             LinkButton lnkFull = row.FindControl("lnlLoanNo") as LinkButton;
             ScriptManager.GetCurrent(this).RegisterPostBackControl(lnkFull);
         }
     }

  */

}