﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class ACM_Emp_Allocation : System.Web.UI.Page
{
    SqlConnection con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_Obj = new SqlCommand();
    DataTable dt_obj = new DataTable();
    CreateLogFiles Err = new CreateLogFiles();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {
                    bindArea();
                }
            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void bindArea()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();

            cmd_Obj = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con_Obj);
            cmd_Obj.CommandType = CommandType.StoredProcedure;
            cmd_Obj.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

            if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
            }
            else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
            }
            else
            {
                cmd_Obj.Parameters.AddWithValue("@InputVal", 0);
            }
            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());




            ddlst_Area.DataSource = dt_obj;
            ddlst_Area.DataTextField = "AR_NAME";
            ddlst_Area.DataValueField = "AR_ID";
            ddlst_Area.DataBind();

            ddlst_Area.Items.Insert(0, new ListItem("--Select--", "0"));
            //ddlst_Area.SelectedValue = Session["AREA_ID"].ToString();

            bindBranch();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }
    }

    public void bindBranch()
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);

            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());



            ddlst_Branch.DataSource = dt_obj;
            ddlst_Branch.DataTextField = "BR_NAME";
            ddlst_Branch.DataValueField = "BR_ID";
            ddlst_Branch.DataBind();
            ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
            if (Session["USR_ACS"].ToString() == "7")
            {
                ddlst_Branch.SelectedValue = Session["BRANCHID"].ToString();
                ddlst_Branch.Enabled = false;
                ddlst_Area.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }

    }

    protected void ddlst_Area_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            //ClearValues();
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            cmd_Obj = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlst_Area.SelectedItem.Text.ToString() + "'", con_Obj);
            dt_obj = new DataTable();

            dt_obj.Load(cmd_Obj.ExecuteReader());

            ddlst_Branch.DataSource = dt_obj;
            ddlst_Branch.DataTextField = "BR_NAME";
            ddlst_Branch.DataValueField = "BR_ID";
            ddlst_Branch.DataBind();
            ddlst_Branch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlst_Branch.Enabled = true;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);

        }
    }

    protected void ddlst_Branch_SelectedIndexChanged(object sender, EventArgs e)
    {
        //ddlst_Action.SelectedIndex = 0;
        //ddlDate.SelectedIndex = 0;
        ClearValues();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                con_Obj.Open();
            string empId = string.Empty;
            foreach (GridViewRow gvRowChecked in gvACMAlloc.Rows)
            {
                CheckBox chkbxIns = (CheckBox)gvRowChecked.FindControl("chkbxDownCollection");
                if (chkbxIns.Checked)
                {
                    Label lbl_emp_id = (Label)gvRowChecked.FindControl("lbl_emp_id");
                    if (string.IsNullOrEmpty(empId))
                        empId = lbl_emp_id.Text.Trim();
                    else
                        empId += "," + lbl_emp_id.Text.Trim();
                }
            }
            string qry = "update MR_EMPLOYEE set EMP_ACM_STAT=1 where EMP_ID in (" + empId + ")";
            cmd_Obj = new SqlCommand(qry, con_Obj);
            int res = cmd_Obj.ExecuteNonQuery();
            if (res > 0)
                uscMsgBox1.AddMessage("Updated Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
            else
                uscMsgBox1.AddMessage("Updation Failed", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearValues();
        ddlst_Area.SelectedIndex = 0;
        //ddlst_Branch.
        Response.Redirect("ACM_Emp_Allocation.aspx");
    }

    protected void ClearValues()
    {
        //ddlst_Branch.SelectedIndex = 0;
        ddlst_Product.SelectedIndex = 0;
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
        if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
            con_Obj.Open();
        cmd_Obj = new SqlCommand("RTS_SP_FETCH_ACM_ALLOC_USERS", con_Obj);
        cmd_Obj.CommandTimeout = 240000;
        cmd_Obj.CommandType = CommandType.StoredProcedure;
        cmd_Obj.Parameters.AddWithValue("@AREAID", ddlst_Area.SelectedValue != "0" ? ddlst_Area.SelectedValue : null);
        cmd_Obj.Parameters.AddWithValue("@BRANCHID", ddlst_Branch.SelectedValue != "0" ? ddlst_Branch.SelectedValue.ToString() : null);
        cmd_Obj.Parameters.AddWithValue("@PTYPE", ddlst_Product.SelectedValue);
        cmd_Obj.Parameters.AddWithValue("@Amount", 0);
        dt_obj = new DataTable();
        dt_obj.Load(cmd_Obj.ExecuteReader());
        gvACMAlloc.DataSource = dt_obj;
        gvACMAlloc.DataBind();
    }
}