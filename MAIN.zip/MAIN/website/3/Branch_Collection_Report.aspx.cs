﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.IO;
using System.Globalization;
using System.Threading;
using Tracker;

public partial class Branch_Collection_Report : System.Web.UI.Page
{

    SqlConnection con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_Obj = new SqlCommand();
    DataTable dt_obj = new DataTable();
    CreateLogFiles Err = new CreateLogFiles();


    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {

                   // bindArea();
                }
                txtbx_frm_date.Attributes.Add("readonly", "readonly");
                txtbx_to_date.Attributes.Add("readonly", "readonly");

            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void GenerateExcel(DataTable passdt)
    {
        try
        {
            System.IO.StringWriter tw = new System.IO.StringWriter();
            //System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
            GridView dgGrid = new GridView();
            dgGrid.DataSource = passdt;
            Response.Clear();
            Response.Buffer = true;

            Response.Charset = "";
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("content-disposition", "attachment;filename=Collection Report.xls");
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            dgGrid.AllowPaging = false;
            dgGrid.DataBind();
            //Change the Header Row back to white color
            dgGrid.HeaderRow.Style.Add("background-color", "#FFFFFF");
            dgGrid.HeaderRow.ForeColor = System.Drawing.Color.White;
            DataGrid dg = new DataGrid();
            dg.DataSource = passdt;
            dg.DataBind();
            dgGrid.BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
            for (int z = 0; z < dg.Items[0].Cells.Count; z++)
            {
                //Apply style to Individual Cells
                dgGrid.HeaderRow.Cells[z].Style.Add("background-color", "#7F7F7F");
                dgGrid.HeaderRow.Cells[z].BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                //dgGrid.HeaderRow.Cells[z].Height = 30;
            }
            for (int i = 0; i < dgGrid.Rows.Count; i++)
            {
                GridViewRow row = dgGrid.Rows[i];

                //Change Color back to white
                row.BackColor = System.Drawing.Color.White;

                //Apply text style to each Row
                row.Attributes.Add("class", "textmode");

                ////Apply style to Individual Cells of Alternating Row
                //for (int s = 0; s < dg.Items[0].Cells.Count; s++)
                //{

                //    if (i % 2 != 0)
                //    {
                //        row.Cells[s].Style.Add("background-color", "#f2f2f2");
                //        row.Cells[s].BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                //        row.Cells[s].ForeColor = System.Drawing.Color.Black;
                //        row.Cells[s].Font.Bold = true;
                //        row.Cells[s].Font.Size = 10;
                //    }
                //    else
                //    {
                //        row.Cells[s].Style.Add("background-color", "#DDD9C3");
                //        row.Cells[s].BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                //        row.Cells[s].ForeColor = System.Drawing.Color.Black;
                //        row.Cells[s].Font.Bold = true;
                //        row.Cells[s].Font.Size = 10;
                //    }
                //}

                //Apply style to Individual Cells of Alternating Row


                row.Cells[dg.Items[0].Cells.Count - 2].HorizontalAlign = HorizontalAlign.Right;
               
            }
            dgGrid.RenderControl(hw);
            
            string style = @"<style> .textmode { mso-number-format:\@; } </style>";
            Response.Write(style);
            string type = rbtnRptType.SelectedItem.Text.Trim();
            string headerTable = @"<Table><tr><th colspan=19 align=left><font face=Calibri size=5 color=#974807> " + type + " Report between " + txtbx_frm_date.Text + " and " + txtbx_to_date.Text + " </font></th></tr></Table>";
            Response.Write(headerTable);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void btn_generate_Click(object sender, EventArgs e)
    {
        

         if (txtbx_frm_date.Text.Trim() == "")
        {
            uscMsgBox1.AddMessage("Please select the from date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtbx_frm_date.Focus();
            return;
        }
        else if (txtbx_to_date.Text.Trim() == "")
        {
            uscMsgBox1.AddMessage("Please select the to date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtbx_to_date.Focus();
            return;
        }
        else
        {


            try
            {
                con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

                if (con_Obj.State == ConnectionState.Broken || con_Obj.State == ConnectionState.Closed)
                    con_Obj.Open();
                if (rbtnRptType.SelectedValue == "COL")
                {
                    cmd_Obj = new SqlCommand("SP_RTS_RPT_COLLECTION", con_Obj);
                }
                else if (rbtnRptType.SelectedValue == "CAN")
                {
                    cmd_Obj = new SqlCommand("SP_RTS_RPT_CANCEL", con_Obj);
                }
                cmd_Obj.CommandTimeout = 240000;
                cmd_Obj.CommandType = CommandType.StoredProcedure;
                cmd_Obj.Parameters.AddWithValue("@FROM", DateTime.ParseExact(txtbx_frm_date.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                cmd_Obj.Parameters.AddWithValue("@TO", DateTime.ParseExact(txtbx_to_date.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));


                cmd_Obj.Parameters.AddWithValue("@RC_BR_ID",  Session["BRANCHID"].ToString());
                cmd_Obj.Parameters.AddWithValue("@AR_ID",  Session["AREA_ID"].ToString());
                
                cmd_Obj.Parameters.AddWithValue("@DV_ID", Session["DIVID"].ToString());
                cmd_Obj.Parameters.AddWithValue("@ST_ID", Session["STATEID"].ToString());
                cmd_Obj.Parameters.AddWithValue("@USR_ACS", Session["USR_ACS"].ToString());                

                dt_obj = new DataTable();
                dt_obj.Load(cmd_Obj.ExecuteReader());
                //DataTable dtTemp = new DataTable();
                if (dt_obj.Rows.Count > 0)
                {
                        GenerateExcel(dt_obj);
                }
                else
                {
                    uscMsgBox1.AddMessage("No Records Found...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    
                    return;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {

                cmd_Obj.Dispose();
                con_Obj.Close();
                con_Obj.Dispose();
                SqlConnection.ClearPool(con_Obj);

            }

        }
    }

   

    protected void ClearValues()
    {

        txtbx_frm_date.Text = "";
        txtbx_to_date.Text = "";
    }
    protected void btn_Cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_Collection_Report.aspx");
    }
}