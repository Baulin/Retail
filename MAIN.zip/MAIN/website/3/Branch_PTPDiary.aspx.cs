﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.IO;
using Tracker;

public partial class Branch_PTPDiary : System.Web.UI.Page
{
    SqlConnection conObj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmdObj = new SqlCommand();
    SqlDataAdapter ap = new SqlDataAdapter();
    DataTable resdt = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnptpreports);
    }
    protected void btnptpreports_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtbxptpdatefrm.Text == "")
            {
                uscMsgBox1.AddMessage("Please select the PTP Diary From Date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (txtbxptpdateto.Text == "")
            {
                uscMsgBox1.AddMessage("Please select the PTP Diary To Date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {

                cmdObj = new SqlCommand("RTS_SP_RPT_PTP_DIARY", conObj);
                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@FRM", txtbxptpdatefrm.Text);
                cmdObj.Parameters.AddWithValue("@TO", txtbxptpdateto.Text);
                cmdObj.Parameters.AddWithValue("@BRANCH", Session["UNITNAME"].ToString());
                cmdObj.CommandTimeout = 180000;
                if (conObj.State == ConnectionState.Broken || conObj.State == ConnectionState.Closed)
                    conObj.Open();
                ap = new SqlDataAdapter(cmdObj);
                ap.Fill(resdt);
                if (resdt.Rows.Count > 0)
                {

                    string date = String.Format("{0:dd-MMM-yyyy hh:mm:ss tt}", DateTime.Now);

                    string frm = Convert.ToDateTime(txtbxptpdatefrm.Text).ToString("dd-MMM-yyyy");
                    string to = Convert.ToDateTime(txtbxptpdateto.Text).ToString("dd-MMM-yyyy");

                    System.IO.StringWriter tw = new System.IO.StringWriter();
                    ////System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
                    //GridView dgGrid = new GridView();
                    //dgGrid.DataSource = ds.Tables[0];
                    Response.Clear();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment;filename=PTP Diary Report between " + frm + " and " + to + ".xls");
                    Response.Charset = "";
                    Response.ContentType = "application/vnd.ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter hw = new HtmlTextWriter(sw);

                    /*  Excel generation without design starts here */
                    int rowcount = resdt.Rows.Count;
                    int colcount = resdt.Columns.Count;
                    for (int i = 0; i < colcount; i++)
                    {
                        sw.Write(resdt.Columns[i].ColumnName.ToString() + "\t");
                    }
                    sw.WriteLine();
                    for (int i = 0; i < rowcount; i++)
                    {
                        for (int j = 0; j < colcount; j++)
                        {
                            sw.Write(resdt.Rows[i][j].ToString() + "\t");
                        }
                        sw.WriteLine();
                    }

                    /*  Excel generation without design ends here */


                    Response.Output.Write(sw.ToString());
                    Response.Flush();
                    Response.End();

                }
                else
                {
                    uscMsgBox1.AddMessage("No Records Found....", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmdObj.Dispose();
            conObj.Close();


        }

    }
}