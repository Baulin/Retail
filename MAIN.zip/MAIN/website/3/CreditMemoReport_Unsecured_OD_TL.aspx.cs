﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class CreditMemoReport_Unsecured_OD_TL : System.Web.UI.Page
{

    SqlConnection conObj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmdObj = new SqlCommand();
    SqlDataAdapter ap = new SqlDataAdapter();

    DataSet ds = new DataSet();
    string ReportName = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            txtbxfrmdt.Attributes.Add("readonly", "readonly");
            txtbxtodt.Attributes.Add("readonly", "readonly");
        }
        else Response.Redirect("Default.aspx");
    }


    protected void btnrparpt_Click(object sender, EventArgs e)
    {
        if (txtbxfrmdt.Text == "")
        {
            uscMsgBox1.AddMessage("Please select the from date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtbxfrmdt.Focus();
            return;
        }
        else if (txtbxtodt.Text == "")
        {
            uscMsgBox1.AddMessage("Please select the to date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtbxtodt.Focus();
            return;
        }
        else if (txtbxfrmdt.Text == "" && txtbxtodt.Text == "")
        {
            uscMsgBox1.AddMessage("Please select the from and to date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtbxfrmdt.Focus();
            return;
        }
        else
        {
            DateTime frm, to;
            frm = DateTime.ParseExact(txtbxfrmdt.Text, "dd MMM yyyy", CultureInfo.InvariantCulture);
            to = DateTime.ParseExact(txtbxtodt.Text, "dd MMM yyyy", CultureInfo.InvariantCulture);

            TimeSpan j = to.Subtract(frm);

            if (j.Days <= 31 && j.Days >= 0)
            {
                try
                {
                    ReportName = "Credit Login Unsecured OD/TL Products";

                    SqlCommand cmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_CREDIT_OD_TL_MEMO_REPORT, conObj);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1200000;

                    //cmd.Parameters.Add("@STDT", DateTime.ParseExact(txtbxfrmdt.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
                    //cmd.Parameters.Add("@ENDDT", DateTime.ParseExact(txtbxtodt.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));

                    cmd.Parameters.AddWithValue("@StartDate", DateTime.ParseExact(txtbxfrmdt.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
                    cmd.Parameters.AddWithValue("@EndDate", DateTime.ParseExact(txtbxtodt.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));

                    SqlDataAdapter showdata = new SqlDataAdapter(cmd);
                    showdata.Fill(ds);
                    conObj.Close();

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        GenerateExcel(ds.Tables[0]);
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("No Records Found between " + txtbxfrmdt.Text + " and " + txtbxtodt.Text, YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    uscMsgBox1.AddMessage("Unable to generate Report. Please try later..! ", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
                finally
                {
                    cmdObj.Dispose();
                    conObj.Close();
                }
            }
            else
            {
                uscMsgBox1.AddMessage("You can generate only one month details...", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                return;
            }
        }
    }

    protected void GenerateExcel(DataTable passdt)
    {
        try
        {
            System.IO.StringWriter tw = new System.IO.StringWriter();
            GridView dgGrid = new GridView();
            dgGrid.DataSource = passdt;
            Response.Clear();
            Response.Buffer = true;

            Response.Charset = "";
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("content-disposition", "attachment;filename='" + ReportName + "'_Report.xls");
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            dgGrid.AllowPaging = false;
            dgGrid.DataBind();

            //Change the Header Row back to white color
            dgGrid.HeaderRow.Style.Add("background-color", "#FFFFFF");
            dgGrid.HeaderRow.ForeColor = System.Drawing.Color.White;
            DataGrid dg = new DataGrid();
            dg.DataSource = passdt;
            dg.DataBind();
            dgGrid.BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);

            for (int z = 0; z < dg.Items[0].Cells.Count; z++)
            {
                //Apply style to Individual Cells
                dgGrid.HeaderRow.Cells[z].Style.Add("background-color", "#7F7F7F");
                dgGrid.HeaderRow.Cells[z].BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                dgGrid.HeaderRow.Cells[z].Height = 30;
                dgGrid.HeaderRow.Cells[z].BorderColor = System.Drawing.Color.Black;
            }
            for (int i = 0; i < dgGrid.Rows.Count; i++)
            {
                GridViewRow row = dgGrid.Rows[i];

                //Change Color back to white
                row.BackColor = System.Drawing.Color.White;
                row.BorderColor = System.Drawing.Color.Black;

                //Apply text style to each Row
                row.Attributes.Add("class", "textmode");

                //Apply style to Individual Cells of Alternating Row
                //for (int s = 0; s < dg.Items[0].Cells.Count; s++)
                //{

                //    if (i % 2 != 0)
                //    {
                //        row.Cells[s].Style.Add("background-color", "#f2f2f2");
                //        row.Cells[s].BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                //        row.Cells[s].ForeColor = System.Drawing.Color.Black;
                //        row.Cells[s].Font.Bold = true;
                //        row.Cells[s].Font.Size = 10;
                //    }
                //    else
                //    {
                //        row.Cells[s].Style.Add("background-color", "#DDD9C3");
                //        row.Cells[s].BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                //        row.Cells[s].ForeColor = System.Drawing.Color.Black;
                //        row.Cells[s].Font.Bold = true;
                //        row.Cells[s].Font.Size = 10;
                //    }
                //}
            }

            dgGrid.RenderControl(hw);
            string year = DateTime.Now.AddYears(0).ToString("yyyy");
            string headerTable = @"<Table><tr><th colspan=3 align=left><font face=Calibri size=5 color=#974807>'" + ReportName + "'_Report</font></th></tr></Table>";
            Response.Write(headerTable);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
}