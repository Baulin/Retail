﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;


public partial class Master_Employee_subcategoryaspx : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DataSet dss = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                //"SP_MAS_SEG_SUB_CATEGORY";
                Bindgrid();
                BindProfile();
            }
        }
    }

    #region"BindProfile"
    public void BindProfile()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmd = new SqlCommand("SP_MR_SEGSUB_CATEGORY", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@TYPE", 1);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            ddlprofilename.DataSource = ds;
            ddlprofilename.DataTextField = "PRF_DESC";
            ddlprofilename.DataValueField = "PRF_ID";
            ddlprofilename.DataBind();
            ddlprofilename.Items.Insert(0, new ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    #endregion

    #region "Bindgrid"
    public void Bindgrid()
    {

        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmd = new SqlCommand("SP_MR_SEGSUB_CATEGORY", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@TYPE", 2);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dss);

            gvsegment.DataSource = dss.Tables[0];
            gvsegment.DataBind();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    #endregion

    #region "Submit"
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlprofilename.SelectedIndex == 0)
            {
                uscMsgBox1.AddMessage("Please select the profile", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlsegment.SelectedIndex == 0)
            {
                uscMsgBox1.AddMessage("Please select the Segment", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlsubcatstatus.SelectedIndex == 0)
            {
                uscMsgBox1.AddMessage("Please select the Status", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                if (btnSubmit.Text == "Submit")
                {
                    InsertUpdate("INSERT");
                }
                else
                {
                    InsertUpdate("Update");
                }
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    #endregion

    #region"InsertUpdate"
    protected void InsertUpdate(string checkactivity)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmdinsert = new SqlCommand("SP_MR_SEGSUB_CATEGORY", con);
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.Parameters.AddWithValue("@SU_DESC", txtsubcategory.Text);
            cmdinsert.Parameters.AddWithValue("@SU_PRF_ID", ddlprofilename.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@SU_SEG_ID", ddlsegment.SelectedValue);
            cmdinsert.Parameters.AddWithValue("@SU_STAT", ddlsubcatstatus.SelectedValue);

            if (checkactivity == "Update")
            {
                cmdinsert.Parameters.AddWithValue("@SU_MBY", Session["ID"]);
                cmdinsert.Parameters.AddWithValue("@SU_ID", Session["SG_ID"]);
                cmdinsert.Parameters.AddWithValue("@TYPE", 4);
            }
            else
            {
                cmdinsert.Parameters.AddWithValue("@SU_CBY", Session["ID"]);
                cmdinsert.Parameters.AddWithValue("@TYPE", 3);
            }

            int r = cmdinsert.ExecuteNonQuery();
            Bindgrid();
            if (r > 0)
            {
                if (checkactivity == "Update")
                {
                    btnSubmit.Text = "Submit";
                }

                clear();
                uscMsgBox1.AddMessage("Records Saved Sucessfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                return;
            }
            else
            {
                uscMsgBox1.AddMessage("Records not saved or Already Exists.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    #endregion  

    #region "Cancel"
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            clear();
            btnSubmit.Text = "Submit";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    #endregion

    #region "Selectedcheckchanged"
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            Label lblSegmentId = null;

            foreach (GridViewRow grwrow in gvsegment.Rows)
            {
                RadioButton chkstat = grwrow.FindControl("rb_select") as RadioButton;
                int index = grwrow.RowIndex;

                if (chkstat.Checked)
                {
                    lblSegmentId = (Label)gvsegment.Rows[index].Cells[1].FindControl("lblSEGMENTID");

                    SqlCommand cmd = new SqlCommand("SP_MR_SEGSUB_CATEGORY", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SU_ID", lblSegmentId.Text);
                    cmd.Parameters.AddWithValue("@TYPE", 5);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    Session["SG_ID"] = lblSegmentId.Text;

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtsubcategory.Text = Convert.ToString(ds.Tables[0].Rows[0]["SU_DESC"]);

                                             
                       
                        if (ddlprofilename.Items.FindByValue(Convert.ToString(ds.Tables[0].Rows[0]["SU_PRF_ID"])) != null)
                        {
                            ddlprofilename.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["SU_PRF_ID"]);
                        }
                        else
                        {
                            ddlprofilename.SelectedIndex = 0;
                        }
                        if (Convert.ToString(ds.Tables[0].Rows[0]["SU_SEG_ID"]) != null)
                        {
                            BindSegment();
                            ddlsegment.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["SU_SEG_ID"]);
                        }
                        else
                        {
                            ddlsegment.SelectedIndex = 0;
                        }
                        if (ddlsubcatstatus.Items.FindByValue(Convert.ToString(ds.Tables[0].Rows[0]["SU_STAT"])) != null)
                        {
                            ddlsubcatstatus.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["SU_STAT"]);
                        }
                        else
                        {
                            ddlsubcatstatus.SelectedIndex = 0;
                        }
                    }

                    btnSubmit.Text = "Update";
                    break;

                }

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    #endregion

    #region "Clear"
    protected void clear()
    {
        txtsubcategory.Text = "";
        ddlprofilename.SelectedIndex = 0;
        ddlsegment.SelectedIndex = 0;
        ddlsubcatstatus.SelectedIndex = 0;
    }
    #endregion

    protected void gvsegment_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvsegment.PageIndex = e.NewPageIndex;
        Bindgrid();
    }

    protected void ddlprofilename_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindSegment();
    }

    protected void BindSegment()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        try
        {
            SqlCommand cmd = new SqlCommand("SP_MR_SEGSUB_CATEGORY", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@SU_PRF_ID", ddlprofilename.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@TYPE", 6);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            ddlsegment.DataSource = ds;
            ddlsegment.DataTextField = "SG_DESG";
            ddlsegment.DataValueField = "SG_ID";
            ddlsegment.DataBind();
            ddlsegment.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
}