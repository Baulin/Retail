﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Net.Mail;
using Tracker;
using Utilities;

public partial class Credit_DSA_Approval : System.Web.UI.Page
{
    int ldid;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string bcc3;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    ClsCommon clscommon = new ClsCommon();
   protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
            }
            else
            {
                Response.Redirect("expire.aspx");
            }
        }
    }
    //public void bind()
    //{
    //    SqlConnection con = new SqlConnection(strcon);
    //    con.Open();
    //    SqlCommand cmddd = new SqlCommand("select AR_NAME from MR_AREA", con);
    //    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //    DataSet dsdd = new DataSet();
    //    dadd.Fill(dsdd);

    //    //SqlCommand cmdquery = new SqlCommand("select QY_QUERY from MR_QUERY", con);
    //    //SqlDataAdapter daquery = new SqlDataAdapter(cmdquery);
    //    //DataSet dsquery = new DataSet();
    //    //daquery.Fill(dsquery);        
    //    //con.Close();

    //    ddlArea.DataSource = dsdd;
    //    ddlArea.DataTextField = "AR_NAME";
    //    ddlArea.DataValueField = "AR_NAME";
    //    ddlArea.DataBind();
    //    ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

    //    SqlCommand cmdquery = new SqlCommand("select DISTINCT QY_QUERY from MR_QUERY ORDER BY QY_QUERY ASC", con);
    //    SqlDataAdapter daquery = new SqlDataAdapter(cmdquery);
    //    DataSet dsquery = new DataSet();
    //    daquery.Fill(dsquery);
    //    con.Close();
    //    gvUserInfo.DataSource = dsquery;
    //    gvUserInfo.DataBind();

    //    //ddlQuery.DataSource = dsquery;
    //    //ddlQuery.DataTextField = "QY_QUERY";
    //    //ddlQuery.DataValueField = "QY_QUERY";
    //    //ddlQuery.DataBind();
    //    //ddlQuery.Items.Insert(0, new ListItem("--Select--", "0"));

    //}

    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        // ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

        //SqlCommand cmdquery = new SqlCommand("select DISTINCT QY_QUERY from MR_QUERY where QY_PRS_ID=10 ORDER BY QY_QUERY ASC", con);
        //SqlDataAdapter daquery = new SqlDataAdapter(cmdquery);
        //DataSet dsquery = new DataSet();
        //daquery.Fill(dsquery);
        //con.Close();
        //gvUserInfo.DataSource = dsquery;
        //gvUserInfo.DataBind();


    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void cb_select_CheckedChanged(object sender, EventArgs e)
    {

        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
            //gvUserInfo.Visible = false;


            gridbindall();

            // if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please select Area and Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            //else if (ddlBranch.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Branch", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            //else if (txtBCACODE.Text == "")
            //{
            //    uscMsgBox1.AddMessage("Please Enter Lead No.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void gridbindall()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            /* SqlCommand cmd = new SqlCommand("select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE isnull(LD_SANTD_DATE,'')='' AND (FT_SENTBY='C' OR FT_SENTBY='B') AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND ISNULL(LD_LC_DATE,'')='' ORDER BY LD_NO", con);
             SqlDataAdapter da = new SqlDataAdapter(cmd);
             da.Fill(ds);
           */
            SqlCommand cmd = new SqlCommand("RTS_SP_DSA_APPLICATION", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PTYPE", "GET_DSA_DATA");
            cmd.Parameters.AddWithValue("@DSA_TYPE", "CR_MRC_APPROVAL");
            cmd.Parameters.AddWithValue("@DSA_CODE", txtDSACODE.Text);
            cmd.Parameters.AddWithValue("@AR_ID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_ID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@DSA_CR_VSTAT", "Approved");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gvQuery.DataSource = ds.Tables[0];
            gvQuery.DataBind();
            /*  if (ds.Tables[0].Rows.Count > 0)
              {
                  gvQuery.HeaderRow.Font.Bold = true;
                  gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                  gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                  gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                  gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                  gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                  gvQuery.HeaderRow.Cells[1].Wrap = false;
                  gvQuery.HeaderRow.Cells[2].Wrap = false;
                  gvQuery.HeaderRow.Cells[3].Wrap = false;
                  gvQuery.HeaderRow.Cells[4].Wrap = false;
                  gvQuery.HeaderRow.Cells[5].Wrap = false;
              }*/
            //}
            //else
            //{
            //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            //}
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    /*  public void gridbind()
      {

          SqlConnection con = new SqlConnection(strcon);
          try
          {
              con.Open();
              SqlCommand cmd = new SqlCommand(" select DISTINCT LD_NO 'LEAD NO',convert(varchar(17),LD_DATE,106) 'LEAD DATE',LD_APNAME 'APPLICANT NAME',convert(varchar(17),LD_PD_DATE,106) 'PD DATE',LD_PD_AMT 'LOAN AMOUNT' from LSD_LEAD A LEFT JOIN LSD_FILE_TRANS B ON A.LD_ID=B.FT_LD_ID LEFT JOIN MR_BRANCH C ON A.LD_BR_ID=C.BR_ID LEFT JOIN MR_AREA D ON C.BR_AR_ID=D.AR_ID WHERE ( FT_SENTBY='C' OR FT_SENTBY='B')  AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND LD_NO='" + txtBCACODE.Text + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' OR ( FT_SENTBY='C' OR FT_SENTBY='B') AND FT_SENTTO='H' AND isnull(FT_RDATE,'')<>'' AND AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "' AND BR_NAME='" + ddlBranch.SelectedItem.Text.ToString() + "' AND ISNULL(LD_LC_DATE,'')='' AND isnull(LD_SANTD_DATE,'')='' ORDER BY LD_NO ", con);
              SqlDataAdapter da = new SqlDataAdapter(cmd);
              da.Fill(ds);
              //if (ds.Tables[0].Rows.Count != 0)
              //{
              //Panel1.Visible = true;
              gvQuery.DataSource = ds.Tables[0];
              gvQuery.DataBind();
              if (ds.Tables[0].Rows.Count > 0)
              {
                  gvQuery.HeaderRow.Font.Bold = true;
                  gvQuery.HeaderRow.Cells[1].Text = "LEAD NO";
                  gvQuery.HeaderRow.Cells[2].Text = "LEAD DATE";
                  gvQuery.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                  gvQuery.HeaderRow.Cells[4].Text = "PD DATE";
                  gvQuery.HeaderRow.Cells[5].Text = "LOAN AMOUNT";

                  gvQuery.HeaderRow.Cells[1].Wrap = false;
                  gvQuery.HeaderRow.Cells[2].Wrap = false;
                  gvQuery.HeaderRow.Cells[3].Wrap = false;
                  gvQuery.HeaderRow.Cells[4].Wrap = false;
                  gvQuery.HeaderRow.Cells[5].Wrap = false;
              }
              //}
              //else
              //{
              //    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
              //}
          }
          catch (Exception ex)
          {
              ErrorLog.WriteError(ex);
              uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
          }
          finally
          {
              con.Close();
          }
      }*/
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            con.Open();
            var ddl = (CheckBoxList)e.Row.FindControl("ddlCity");
            string CountryId = e.Row.Cells[1].Text.ToString();
            SqlCommand cmd = new SqlCommand("select QY_QUERY,QY_SQUERY from MR_QUERY  where QY_QUERY='" + CountryId + "' ORDER BY QY_QUERY,QY_SQUERY ASC", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            ddl.DataSource = ds;
            ddl.DataTextField = "QY_SQUERY";
            ddl.DataValueField = "QY_QUERY";
            ddl.DataBind();
            //ddl.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }
    protected void gvUserInfo_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            foreach (GridViewRow grow in gvQuery.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                Label lblDSA_ID = grow.FindControl("lblDSA_ID") as Label;
                Label lblDSA_FIRCU_ID = grow.FindControl("lblDSA_FIRCU_ID") as Label;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    leadno = lnbtn.Text;
                    appname = gvQuery.Rows[index].Cells[3].Text;
                    pddt = gvQuery.Rows[index].Cells[2].Text;
                    //lnamt = gvQuery.Rows[index].Cells[5].Text;
                    Session["DSA_ID"] = lblDSA_ID.Text;
                    Session["DSA_FIRCU_ID"] = lblDSA_FIRCU_ID.Text;
                    bind();
                    ddlStatus.SelectedValue = "0";
                    txtReceiveDate.Text = "";
                    txtRemarks.Text = "";
                }
            }
            //gvUserInfo.Visible = true;
            lbLeadno.Visible = true;
            lbAppname.Visible = true;
            lbPDdate.Visible = true;
            lbLoanamt.Visible = true;
            //ddlQuery.Enabled = true;
            //ddlSubquery.Enabled = true;
            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;

            tblSelection.Visible = true;

            lbLeadno.Text = leadno;
            lbAppname.Text = appname;
            lbPDdate.Text = pddt;
            lbLoanamt.Text = lnamt;

            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('HOOps_QCQuery_Popup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        try
        {
            using (SqlConnection conSub = new SqlConnection(strcon))
            {
                using (SqlCommand command = new SqlCommand("RTS_SP_DSA_APPLICATION", conSub))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    conSub.Open();
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PTYPE", "UPDATE_CR_APRV_STAT");
                    command.Parameters.AddWithValue("@DSA_ID", Session["DSA_ID"].ToString());
                    command.Parameters.AddWithValue("@DSA_CODE", txtDSACODE.Text);
                    command.Parameters.AddWithValue("@DSA_CR_APRV_STAT", ddlStatus.SelectedIndex != 0 ? ddlStatus.SelectedValue : "");
                    command.Parameters.AddWithValue("@DSA_CR_APRV_RMKS", txtRemarks.Text);
                    command.Parameters.AddWithValue("@DSA_CR_APRV_BY", Session["EMPID"].ToString());
                    command.Parameters.AddWithValue("@DSA_FIRCU_STAT", ddlCheckerStat.SelectedValue);
                    string[] AuDte = txtReceiveDate.Text.Split('/');
                     string  Adt = AuDte[2] + "-" + AuDte[1] + "-" + AuDte[0];
                    command.Parameters.AddWithValue("@DSA_FIRCU_RDATE", Adt);

                    command.ExecuteNonQuery();
                  //  sendFIRCUMail(Convert.ToInt32(Convert.ToInt32(Session["DSA_FIRCU_ID"].ToString())),Convert.ToInt32( Session["DSA_ID"].ToString()));
                    uscMsgBox1.AddMessage("DSA user status has been updated successfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    clear();
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Submission Failed.", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

        }

    }
    public void sendFIRCUMail(int valuer_id,int dsa_id)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            //DataSet ds = new DataSet();
            //con.Open();
            //SqlCommand cmd = new SqlCommand("select EMP_NAME,EMP_EMAILID,EMP_CODE,USR_EMP_ID,B.USR_UTP_ID from MR_EMPLOYEE A JOIN MR_USER B ON A.EMP_ID=B.USR_EMP_ID WHERE EMP_ID=" + Convert.ToInt32(Session["EMP_ID"]) + " AND B.USR_STAT = 1 ", con);
            //SqlDataAdapter showdata = new SqlDataAdapter(cmd);
            //showdata.Fill(ds);


            SqlCommand cmdmailto = new SqlCommand("SELECT * FROM MR_FIRCU where FIRCU_ID=" + valuer_id, con);
            SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
            DataSet dsmailto = new DataSet();
            string Checkername = "";
            string sname = "";
            string sOffPhone = "";
            string sResOPhone = "";
            string sOffAddres = "";
            string sResAddre = "";
            damailto.Fill(dsmailto);
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                //to = dsmailto.Tables[0].Rows[0]["EM_RPA"].ToString();
                to = dsmailto.Tables[0].Rows[0]["FIRCU_EMAIL"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["FIRCU_EMAIL"].ToString() : "rts-helpdesk@equitasbank.com";
                Checkername = dsmailto.Tables[0].Rows[0]["FIRCU_NAME"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["FIRCU_NAME"].ToString() : "FI-RCU";
                // to = "balasubramanind@equitasbank.com";
                //cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() + ";" + dsmailto.Tables[0].Rows[0]["EM_CM"].ToString() + ";" + dsmailto.Tables[0].Rows[0]["EM_HO"].ToString();
                cc = Session["EMP_EMAILID"].ToString();

                // cc = cc.Replace("\n", "");
                bcc = "";// dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = "";
                bcc3 = "";
            }
            //int EMPID = Convert.ToInt32(ds.Tables[0].Rows[0]["USR_EMP_ID"]);
            string from, subject;

            // Session["R_USR_UTP_ID"] = ds.Tables[0].Rows[0]["USR_EMP_ID"].ToString();
            subject = "";
            from = "RTS <donotreply@equitasbank.com>";

            //to = ds.Tables[0].Rows[0]["EM_RPA"].ToString();

            // to = "balasubramanind@equitasbank.com";

               DataSet ds_dsa = new DataSet();
             ds_dsa = clscommon.Get_DSA_Infomation(dsa_id);
             sname = ds_dsa.Tables[0].Rows[0]["DSA_NAME"] != DBNull.Value ? ds_dsa.Tables[0].Rows[0]["DSA_NAME"].ToString() : "";
             sOffPhone = ds_dsa.Tables[0].Rows[0]["DSA_OFF_PH"] != DBNull.Value ? ds_dsa.Tables[0].Rows[0]["DSA_OFF_PH"].ToString() : "";
             sResOPhone = ds_dsa.Tables[0].Rows[0]["DSA_NAME"] != DBNull.Value ? ds_dsa.Tables[0].Rows[0]["DSA_NAME"].ToString() : "";
             sOffAddres = ds_dsa.Tables[0].Rows[0]["DSA_OFF_ADDR"] != DBNull.Value ? ds_dsa.Tables[0].Rows[0]["DSA_OFF_ADDR"].ToString() : "";
             sResAddre = ds_dsa.Tables[0].Rows[0]["DSA_MOB_PH"] != DBNull.Value ? ds_dsa.Tables[0].Rows[0]["DSA_MOB_PH"].ToString() : "";
            System.Threading.Thread threadSendMails;
            string BodyTxt = "";
            //threadSendMails = new System.Threading.Thread(delegate()
            //{




            string bcaddress = "";

            BodyTxt = "<html><body><basefont face='Calibri'> Dear " + Checkername + ",<br/><br/> Your Verfication has been received for below DSA Member,<br/><br/>";
            BodyTxt = BodyTxt + "<table width='40%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Policy No **</b></td><td style='whiteSpace:nowrap;' ></td></tr>";
            // BodyTxt = BodyTxt + "<tr ><td ><b>Branch ID.</b></td><td style='whiteSpace:nowrap;' >" + Session["BRANCHID"].ToString() + "</td></tr>";
           // BodyTxt = BodyTxt + "<tr><td ><b>Area Name</b></td><td >" + lblArea.Text + "</td></tr>";
           // BodyTxt = BodyTxt + "<tr><td ><b>Branch Name</b></td><td >" + lblBranch.Text + "</td></tr>";
            //BodyTxt = BodyTxt + "<tr ><td ><b>Reference ID</b></td><td style='whiteSpace:nowrap;' >" + BC_CODE + "</td></tr>";

            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>DSA Name</b></td><td style='whiteSpace:nowrap;' >" + sname + "</td></tr>";

            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Office Address</b></td><td style='whiteSpace:nowrap;' >" + sOffAddres + "</td></tr>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Residence Address</b></td><td style='whiteSpace:nowrap;' >" + sResAddre + "</td></tr>";


            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Residence Phone</b></td><td style='whiteSpace:nowrap;' >" + sOffPhone + "</td></tr>";
            BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Office Phone</b></td><td style='whiteSpace:nowrap;' >" + sResOPhone + "</td></tr>";
            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Created By</b></td><td style='whiteSpace:nowrap;' >" + Session["User"].ToString() + "</td></tr>";
            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td ><b>Created Date</b></td><td style='whiteSpace:nowrap;' >" + DateTime.Now.ToString("dd/MM/yyyy") + "</td></tr>";
            BodyTxt = BodyTxt + "</table><br/>";

           // BodyTxt = BodyTxt + "<br/>Please do the necessary verification and update in RTS Team.<br/><br/><br/>";
            BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'>Thanks and Regards,<br/>RTS Team</td></tr>";
            BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";


            EmailManager.sendemail(to, from, "", cc, "FI-RCU Verification has been received by Credit Team", BodyTxt, "", true);


            //});

            //  threadSendMails.IsBackground = true;

            //threadSendMails.Start();

            //if (threadSendMails.IsAlive) { Thread.Sleep(7000); }

        }

        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally { con.Close(); }
    }
    protected void clear()
    {
        try
        {
            //bind();
            gridbindall();
            lbLeadno.Visible = false;
            lbAppname.Visible = false;
            lbPDdate.Visible = false;
            lbLoanamt.Visible = false;
            //ddlQuery.Enabled = true;
            //ddlSubquery.Enabled = true;
            btnSubmit.Enabled = false;
            btnCancel.Enabled = false;

            tblSelection.Visible = false;

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Credit_DSA_Approval.aspx");
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {


            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
            SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
            DataSet dsrsn = new DataSet();
            darsn.Fill(dsrsn);
            con.Close();

            ddlBranch.DataSource = dsrsn;
            ddlBranch.DataTextField = "BR_NAME";
            ddlBranch.DataValueField = "BR_ID";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlBranch.Enabled = true;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void ddlQuery_SelectedIndexChanged(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(strcon);
        //con.Open();
        //ddlSubquery.Enabled = true;
        //SqlCommand cmdsquery = new SqlCommand("select QY_SQUERY from MR_QUERY where QY_QUERY='" + ddlQuery.SelectedValue.ToString() + "'", con);
        //SqlDataAdapter dasquery = new SqlDataAdapter(cmdsquery);
        //DataSet dssquery = new DataSet();
        //dasquery.Fill(dssquery);
        //con.Close();

        //ddlSubquery.DataSource = dssquery;
        //ddlSubquery.DataTextField = "QY_SQUERY";
        //ddlSubquery.DataValueField = "QY_SQUERY";
        //ddlSubquery.DataBind();
        //ddlSubquery.Items.Insert(0, new ListItem("--Select--", "0"));

    }
    protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlStatus.SelectedValue == "Declined")
            {
                txtRemarks.Enabled = true;
            }
            else
            {
                txtRemarks.Enabled = false;
                txtRemarks.Text = "";
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
}