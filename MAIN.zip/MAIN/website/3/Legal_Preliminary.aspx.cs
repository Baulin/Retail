﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Text;
using System.Threading;
using System.Net.Mail;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using Tracker;
using Utilities;
public partial class Legal_Preliminary : System.Web.UI.Page
{
    DateTime dt = DateTime.Now;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    ClsCommon clscommon = new ClsCommon();
    string leadno;
    string appname;
    string product;
    string lnamt;
    string brnch;
    string sa;
    int ldid;
    DateTime dtd;
    int cbrwcnt, docscnt, propcnt, id;
    string strValb, strValp, strVald;

    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter dappre = new SqlDataAdapter();
    DataSet dspre = new DataSet();
    DataTable dtpre = new DataTable();

    Regex Rx = new Regex("^[0-9]+$");

    /*Mailing variables*/
    public static bool blMailStatus = false;
    public static string frmID = "", toID = "", bccID = "", ccID = "", strMailBody = "";
    public string area = "", bnch = "", ldno = "", prod = "", aname = "";
    public int arid, brid, dvid;
    Thread mail;


    /*Preview variables*/
    SqlCommand cmdp = new SqlCommand();
    DataSet ds = new DataSet();

    ReportDocument rpt = new ReportDocument();
    SqlConnection con = new SqlConnection();
    SqlDataAdapter dap = new SqlDataAdapter();

    string empname = "";
    string empid = "";
    string empdesgn = "";

    StringBuilder cusnames = new StringBuilder();


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            //txtbxdocdate.Attributes.Add("readonly", "readonly");
            if (!IsPostBack)
            {
                try
                {

                    txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                    Session["MDID"] = null;
                    bindArea();
                    BindPropType();
                    //Bind_Proof();
                    this.qry.Visible = false;

                    this.leadsel.Visible = false;

                    this.qrylist.Visible = false;


                    this.tbvw.Visible = false;
                    this.adr1.Visible = false;
                    this.adr2.Visible = false;
                    btnsubmit.Enabled = false;
                    btncancel.Enabled = false;
                    btnpreviewp.Enabled = false;
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Preliminary.aspx"); }
                    catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
                }

            }
        }
        else Response.Redirect("Expire.aspx");
    }
    // Shankar_Nov_14_01 
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    // Shankar_Nov_14_01 
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }

    protected void BindPropType()
    {
        string filePath = Server.MapPath("~/XML/PropertyTypeLGLPre.xml");
        using (DataSet ds = new DataSet())
        {
            ds.ReadXml(filePath);
            ddlstproptype.DataSource = ds;
            ddlstproptype.DataTextField = "Property";
            ddlstproptype.DataValueField = "Property";
            ddlstproptype.DataBind();
            ddlstproptype.Items.Insert(0, new ListItem("--Select--", "--Select--"));
        }

    }
    protected void btnview_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                //Session["View"] = "All";
                uscMsgBox1.AddMessage("Please Select the Area", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }
            //else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            //{
            //    Session["View"] = "F";


            //}
            //else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            //{
            //    Session["View"] = "F";

            //}
            //else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            //{
            //    Session["View"] = "F";

            //}

            BindqueryGrid();
            foreach (GridViewRow grow in gvlead.Rows)
            {
                Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                int index = grow.RowIndex;
                if (lblQryResult.Text == "T")
                {
                    gvlead.Rows[index].Cells[1].ForeColor = Color.Red;
                    gvlead.Rows[index].Cells[2].ForeColor = Color.Red;
                    gvlead.Rows[index].Cells[3].ForeColor = Color.Red;
                    gvlead.Rows[index].Cells[4].ForeColor = Color.Red;
                    gvlead.Rows[index].Cells[5].ForeColor = Color.Red;


                }
            }
            div_poslp.Value = "0";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Preliminary.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }

    }
    public void BindqueryGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Legal_Opinion", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@View", "");
            cmd.Parameters.AddWithValue("@LD_NO", txtLeadno.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@FT_SENTBY", "B");
            cmd.Parameters.AddWithValue("@FT_SENTTO", "L");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            da.Fill(ds1);
            if (ds1.Tables[0].Rows.Count != 0)
            {
                gvlead.Visible = true;
                Panel1.Visible = true;
                gvlead.DataSource = ds1.Tables[0];
                gvlead.DataBind();
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    gvlead.HeaderRow.Font.Bold = true;
                    gvlead.HeaderRow.Cells[1].Text = "LEAD NO";
                    gvlead.HeaderRow.Cells[2].Text = "APPLICANT NAME";
                    gvlead.HeaderRow.Cells[3].Text = "PRODUCT";
                    gvlead.HeaderRow.Cells[4].Text = "LOAN AMOUNT";
                    gvlead.HeaderRow.Cells[5].Text = "BRANCH";

                    gvlead.HeaderRow.Cells[1].Wrap = false;
                    gvlead.HeaderRow.Cells[2].Wrap = false;
                    gvlead.HeaderRow.Cells[3].Wrap = false;
                    gvlead.HeaderRow.Cells[4].Wrap = false;
                    gvlead.HeaderRow.Cells[5].Wrap = false;
                }

                this.qry.Visible = true;
                this.tbvw.Visible = false;


            }
            else
            {
                this.qry.Visible = false;
                this.tbvw.Visible = false;
                btnsubmit.Enabled = false;
                btncancel.Enabled = false;
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                gvlead.Visible = false;


            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Preliminary.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
        finally
        {
            con.Close();
        }
    }
    protected void View()
    {
        try
        {
            if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "All";

            }
            else if (txtLeadno.Text != "" && ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";

            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text != "--Select--")
            {
                Session["View"] = "F";

            }
            else if (txtLeadno.Text == "" && ddlArea.SelectedItem.Text != "--Select--" && ddlBranch.SelectedItem.Text == "--Select--")
            {
                Session["View"] = "F";

            }

            BindqueryGrid();
            foreach (GridViewRow grow in gvlead.Rows)
            {
                Label lblQryResult = (Label)grow.FindControl("lblQryResult");
                int index = grow.RowIndex;
                if (lblQryResult.Text == "T")
                {
                    gvlead.Rows[index].Cells[1].ForeColor = Color.Red;
                    gvlead.Rows[index].Cells[2].ForeColor = Color.Red;
                    gvlead.Rows[index].Cells[3].ForeColor = Color.Red;
                    gvlead.Rows[index].Cells[4].ForeColor = Color.Red;
                    gvlead.Rows[index].Cells[5].ForeColor = Color.Red;


                }
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Preliminary.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
    }

    protected void rbtnqueryyes_CheckedChanged(object sender, EventArgs e)
    {
        if (rbtnyes.Checked)
        {
            this.qrylist.Visible = true;
        }
        else this.qrylist.Visible = false;
    }
    protected void rbtnqueryno_CheckedChanged(object sender, EventArgs e)
    {
        if (rbtnno.Checked)
            this.qrylist.Visible = false;
    }
    protected void ddlstarea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        txtLeadno.Text = "";
        this.tbvw.Visible = false;
        this.qry.Visible = false;

    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();


            foreach (GridViewRow grow in gvlead.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                Label lblldid = grow.FindControl("lblLeadID") as Label;
                ldid = Convert.ToInt32(lblldid.Text);
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    leadno = gvlead.Rows[index].Cells[1].Text;
                    appname = gvlead.Rows[index].Cells[2].Text;
                    product = gvlead.Rows[index].Cells[3].Text;
                    lnamt = gvlead.Rows[index].Cells[4].Text;
                    brnch = gvlead.Rows[index].Cells[5].Text;

                    Label lldid = grow.FindControl("lblLeadID") as Label;


                    Session["LEADID"] = Convert.ToInt32(lldid.Text);
                    Session["StatusLGL"] = "New";
                    Session["StatusLGLCBRW"] = "New";
                    Session["StatusLGLSCHEDULE"] = "New";
                    Session["PreviewLDNOP"] = leadno;
                    Session["PF_PR_ID"] = (grow.FindControl("lbl_PF_PR_ID") as Label).Text;
                    Session["LeadNo"] = leadno;

                    ClearRSelect();

                    BindAllGrid("All");
                    Bind_Doc_Type();
                    Bind_Proof(Session["PF_PR_ID"].ToString());
                    KYC_details();

                    this.cbrw1.Visible = true;

                    this.leadsel.Visible = true;

                    this.leadsel2.Visible = true;
                    this.leadsel3.Visible = true;
                    btnsubmit.Enabled = true;
                    btncancel.Enabled = true;
                    btnpreviewp.Enabled = true;
                    tbvw.Visible = true;
                    this.adr1.Visible = false;
                    this.adr2.Visible = false;
                    ddlstcustype.Enabled = true;
                    ajmainview.ActiveTabIndex = 0;
                    break;
                }

            }

            con.Close();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Preliminary.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
    }
    protected void ClearRSelect()
    {
        CLear();
        CLearCBRW();
        ClearSch();

        rbtnyes.Checked = false;
        rbtnno.Checked = false;

        txtbxextent.Text = "";


        TextBox[] TBX = pnlquery.Controls.OfType<TextBox>().ToArray();

        for (int i = 0; i < TBX.Length; i++)
        {
            TBX[i].Text = "";
        }


    }

    protected void btnadd_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["StatusLGL"].ToString() == "New")
            {

                if (txtbxdocdate.Text.Trim() != "" && txtbxsurvey.Text.Trim() != "--Select--" && txtbxdocs.Text.Trim() != "" && ddlstdoctype.SelectedItem.Text != "--Select--" && ddlstdocCat.SelectedItem.Text != "--Select--" && txtbxdocno.Text.Trim() != "")
                {
                    try
                    {

                        dtd = DateTime.ParseExact(txtbxdocdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
                    }

                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                        uscMsgBox1.AddMessage("Invalid Date format. Please check the date (dd/mm/yyyy)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        return;
                    }


                    using (SqlConnection connection = new SqlConnection(strcon))
                    {
                        connection.Open();
                        if (Session["MDID"] == null)
                        {


                            try
                            {
                                id = Session["ID"] != null ? Convert.ToInt32(Session["ID"].ToString()) : 0;
                                if (Session["ID"] != null)
                                {
                                    id = Convert.ToInt32(Session["ID"].ToString());
                                }
                                else
                                {
                                    Response.Redirect("Expire.aspx");
                                    return;
                                }
                                cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection);
                                var obj = cmd.ExecuteScalar();
                                if (obj == null)
                                {
                                    cmd = new SqlCommand("Insert into LSD_MOTD (MD_LD_ID,MD_PDATE,MD_CBY,MD_CDATE) values( " + Convert.ToInt32(Session["LEADID"].ToString()) + ",getdate()," + id + ",getdate())", connection);
                                    cmd.ExecuteNonQuery();
                                }

                            }
                            catch (Exception ex)
                            {
                                ErrorLog.WriteError(ex);
                            }


                            cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection);
                            dtpre = new DataTable();
                            dappre = new SqlDataAdapter(cmd);
                            dappre.Fill(dtpre);

                            Session["MDID"] = dtpre.Rows[0]["MD_ID"] != DBNull.Value ? dtpre.Rows[0]["MD_ID"].ToString() : "";

                        }

                        if (gvdocs.Rows.Count > 0)
                        {
                            List<int> cnt = new List<int>();
                            cnt.Clear();
                            foreach (GridViewRow grow in gvdocs.Rows)
                            {
                                Label lblPSCH = grow.FindControl("lblslno") as Label;
                                cnt.Add(Convert.ToInt32(lblPSCH.Text));
                            }
                            docscnt = cnt.Max() + 1;

                        }
                        else
                            docscnt = 1;

                        try
                        {

                            string sql = " INSERT INTO LSD_MOTD_DOCX (MDX_MD_ID,MDX_SLNO,MDX_DATE,MDX_DOC,MDX_DOCNO,MDX_SURVEY,MDX_DTYPE,MDX_DT_ID,MDX_RSTAT,MDX_DSTAT) values(" + Convert.ToInt32(Session["MDID"].ToString()) + "," + docscnt + ",'" + dtd + "','" +
                                          txtbxdocs.Text.Replace("'", "''").ToString() + "','" + txtbxdocno.Text.Replace("'", "''").ToString() + "','" + txtbxsurvey.Text.Replace("'", "''").ToString() + "','" + ddlstdoctype.SelectedItem.Text + "'," + Convert.ToInt32(ddlstdocCat.SelectedValue.ToString()) + ",'Received','Y')";
                            cmd = new SqlCommand(sql, connection);

                            int r = cmd.ExecuteNonQuery();
                            if (r > 0)
                            {
                                CLear();
                                BindAllGrid("D");

                            }
                            else
                            {
                                uscMsgBox1.AddMessage("Document not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            uscMsgBox1.AddMessage("Document and Survey & Extent input fields should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }
                        finally
                        {
                            cmd.Dispose();
                        }
                    }


                }
                else
                {
                    if (txtbxdocdate.Text == "")
                    {
                        txtbxdocdate.Focus();

                    }
                    else if (ddlstdoctype.SelectedItem.Text == "--Select--")
                    {
                        ddlstdoctype.Focus();
                    }
                    else if (txtbxsurvey.Text == "")
                    {
                        txtbxsurvey.Focus();

                    }
                    else if (txtbxdocs.Text == "")
                    {
                        txtbxdocs.Focus();
                    }
                    else if (ddlstdocCat.SelectedItem.Text == "--Select--")
                    {
                        ddlstdocCat.Focus();
                    }
                    else if (txtbxdocno.Text.Trim() == "")
                    {
                        txtbxdocno.Focus();
                    }
                    uscMsgBox1.AddMessage("Please Give corresponding Inputs for List of Documents", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    BindAllGrid("D");
                }
            }
            else if (Session["StatusLGL"].ToString() == "Edit")
            {
                if (txtbxdocdate.Text.Trim() != "" && txtbxsurvey.Text.Trim() != "--Select--" && txtbxdocs.Text.Trim() != "" && ddlstdoctype.SelectedItem.Text != "--Select--" && ddlstdocCat.SelectedItem.Text != "--Select--" && txtbxdocno.Text.Trim() != "")
                {

                    using (SqlConnection connection = new SqlConnection(strcon))
                    {
                        connection.Open();
                        try
                        {

                            dtd = DateTime.ParseExact(txtbxdocdate.Text, "dd/M/yyyy", CultureInfo.InvariantCulture);
                        }

                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            uscMsgBox1.AddMessage("Invalid Date format. Please check the date", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                            return;
                        }


                        try
                        {
                            string sql = "Update  LSD_MOTD_DOCX set " +

                                           " MDX_DATE='" + dtd + "'," +
                                           " MDX_DOC='" + txtbxdocs.Text.Replace("'", "''").ToString() + "'," +
                                           " MDX_DOCNO='" + txtbxdocno.Text.Replace("'", "''").ToString() + "'," +
                                           " MDX_SURVEY='" + txtbxsurvey.Text.Replace("'", "''").ToString() + "'," +
                                           " MDX_DTYPE='" + ddlstdoctype.SelectedItem.Text + "'," +
                                           " MDX_DT_ID=" + Convert.ToInt32(ddlstdocCat.SelectedValue.ToString()) + "," +
                                           " MDX_RSTAT='Received' " +
                                            " Where MDX_SLNO =" + Convert.ToInt32(Session["SLNO"].ToString()) +
                                            " and MDX_MD_ID=" + Convert.ToInt32(Session["MDID"].ToString());



                            cmd = new SqlCommand(sql, connection);

                            int r = cmd.ExecuteNonQuery();
                            if (r > 0)
                            {
                                CLear();
                                BindAllGrid("D");
                                Session["StatusLGL"] = "New";

                            }
                            else
                            {
                                uscMsgBox1.AddMessage("Document not updated...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorLog.WriteError(ex);
                            uscMsgBox1.AddMessage("Document and Survey & Extent input fields should be less than 2000 characters...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }
                        finally
                        {
                            cmd.Dispose();
                        }
                    }
                }
                else
                {
                    if (txtbxdocdate.Text == "")
                    {
                        txtbxdocdate.Focus();

                    }
                    else if (ddlstdoctype.SelectedItem.Text == "--Select--")
                    {
                        ddlstdoctype.Focus();
                    }
                    else if (txtbxsurvey.Text == "")
                    {
                        txtbxsurvey.Focus();

                    }
                    else if (txtbxdocs.Text == "")
                    {
                        txtbxdocs.Focus();
                    }
                    else if (ddlstdocCat.SelectedItem.Text == "--Select--")
                    {
                        ddlstdocCat.Focus();
                    }
                    else if (txtbxdocno.Text.Trim() == "")
                    {
                        txtbxdocno.Focus();
                    }
                    uscMsgBox1.AddMessage("Please Give corresponding Inputs for List of Documents", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    BindAllGrid("D");
                }

            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Preliminary.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }
    }

    private void CLear()
    {
        txtbxdocdate.Text = "";
        txtbxdocs.Text = "";
        txtbxsurvey.Text = "";
        ddlstdoctype.SelectedIndex = 0;
        ddlstdocCat.SelectedIndex = 0;
        txtbxdocno.Text = "";
        btnadd.Text = "Add";

    }

    private void CLearCBRW()
    {
        ddlsttitle1.SelectedValue = "--Select--";
        txtbxname.Text = "";
        txtbxage.Text = "";
        ddlstsdf.SelectedValue = "--Select--";
        ddlstcustype.SelectedValue = "--Select--";


        ddlsttitle2.SelectedValue = "--Select--";
        txtbxSWFof.Text = "";
        if (ddlstidtype.Items.Count > 0)
            ddlstidtype.SelectedIndex = 0;
        txtbxidtype.Text = "";

        txtbxaddr1.Text = "";
        txtbxaddr2.Text = "";
        txtbxcity.Text = "";
        txtbxpincode.Text = "";
        lblrelationname.Text = "Name";
        btnaddcbrw.Text = "Add";

    }
    protected void gvdocs_RowCommand(object sender, GridViewCommandEventArgs e)
    {



        if (e.CommandName == "Delete")
        {

            strVald = e.CommandArgument.ToString();
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();

                try
                {
                    string sql = "DELETE FROM  LSD_MOTD_DOCX WHERE MDX_MD_ID=" + Convert.ToInt32(Session["MDID"].ToString()) + " and MDX_SLNO=" + Convert.ToInt32(strVald);


                    cmd = new SqlCommand(sql, connection);

                    int r = cmd.ExecuteNonQuery();
                    if (r > 0)
                    {
                        BindAllGrid("D");
                        CLear();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Document not deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);

                    return;
                }
                finally
                {
                    cmd.Dispose();
                }
            }


        }
        if (e.CommandName == "Edit")
        {
            strVald = e.CommandArgument.ToString();

            Session["StatusLGL"] = "Edit";
            Session["SLNO"] = strVald;


            foreach (GridViewRow grow in gvdocs.Rows)
            {
                Label lblPSCH = grow.FindControl("lblslno") as Label;
                if (strVald == lblPSCH.Text)
                {
                    string[] dbarr = (grow.FindControl("lbldate") as Label).Text.Split('-');

                    txtbxdocdate.Text = dbarr[0].ToString() + "/" + dbarr[1].ToString() + "/" + dbarr[2].ToString();
                    txtbxdocs.Text = (grow.FindControl("lbldocs") as Label).Text;
                    txtbxsurvey.Text = (grow.FindControl("lblsurvey") as Label).Text;
                    ddlstdoctype.SelectedValue = (grow.FindControl("lbldoctype") as Label).Text;
                    ddlstdocCat.SelectedValue = (grow.FindControl("lbldoccat") as Label).Text;
                    txtbxdocno.Text = (grow.FindControl("lbldocno") as Label).Text;
                    break;
                }
            }

            btnadd.Text = "Update";
            BindAllGrid("D");

        }
    }

    protected void gvdocs_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void ClearALL()
    {


        txtLeadno.Text = "";

        CLear();
        CLearCBRW();
        ClearSch();

        rbtnyes.Checked = false;
        rbtnno.Checked = false;

        txtbxextent.Text = "";


        TextBox[] TBX = pnlquery.Controls.OfType<TextBox>().ToArray();

        for (int i = 0; i < TBX.Length; i++)
        {
            TBX[i].Text = "";
        }


        this.qry.Visible = false;
        this.leadsel.Visible = false;

        this.leadsel2.Visible = false;
        this.leadsel3.Visible = false;
        this.qrylist.Visible = false;

    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        ClearALL();
        Response.Redirect("Legal_Preliminary.aspx");

    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        int rtnqry = 0;
        SqlConnection con = new SqlConnection(strcon);
        if (gvschedule.Rows.Count > 0 && gvdocs.Rows.Count > 0 && (rbtnyes.Checked || rbtnno.Checked) && txtbxextent.Text.Trim() != "" && gvcbrw.Rows.Count > 0)
        {

            try
            {

                if (gvcbrw.Rows.Count > 0)
                {
                    int cnt = 0;
                    foreach (GridViewRow rw in gvcbrw.Rows)
                    {
                        if ((rw.FindControl("lblatpe") as Label).Text == "A")
                        {
                            cnt++;
                            break;
                        }
                    }
                    if (cnt == 0)
                    {
                        uscMsgBox1.AddMessage("Please add main applicant...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        return;
                    }

                }
                char qry = 'Y';

                if (rbtnyes.Checked)
                {
                    qry = 'Y';
                    rtnqry = InsertQueries();
                }
                if (rbtnno.Checked)
                    qry = 'N';

                int id = 0;

                if (Session["ID"] != null)
                {
                    id = Convert.ToInt32(Session["ID"].ToString());
                }
                else
                {
                    Response.Redirect("Expire.aspx");
                }

                if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                    con.Open();

                SqlCommand cmdlglpre = new SqlCommand("Update LSD_MOTD set MD_EXTENT=" + Convert.ToDouble(txtbxextent.Text) + ", MD_QUERY='" + qry + "', MD_PDATE=getdate() WHERE MD_ID=" + Convert.ToInt32(Session["MDID"].ToString()), con);

                cmdlglpre.CommandTimeout = 120000;
                int isrt = cmdlglpre.ExecuteNonQuery();

                if (isrt > 0)
                {
                    if (rtnqry > 0 && qry == 'Y')
                    {
                        sendMail(con);
                        //if (mail.IsAlive) { Thread.Sleep(5000); }


                        string strMailStatus = "";
                        string strSuccessMsg = "";

                        if (blMailStatus == true)
                        {
                            strMailStatus = "Successfully";
                        }
                        else
                        {
                            strMailStatus = "Failed";
                        }
                        strSuccessMsg = " <br/> Mail Sent " + strMailStatus + "  ";
                        strSuccessMsg += "<br/> Mail To: " + Session["PTOID"].ToString() + " ; CC To: " + Session["PCCID"].ToString() + " ";

                        uscMsgBox1.AddMessage("Legal preliminary opinion done successfully." + strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

                        ClearALL();
                        View();
                    }
                    else if (qry == 'N')
                    {
                        sendMail(con);
                        //if (mail.IsAlive) { Thread.Sleep(5000); }


                        string strMailStatus = "";
                        string strSuccessMsg = "";

                        if (blMailStatus == true)
                        {
                            strMailStatus = "Successfully";
                        }
                        else
                        {
                            strMailStatus = "Failed";
                        }
                        strSuccessMsg = " <br/> Mail Sent " + strMailStatus + "  ";
                        strSuccessMsg += "<br/> Mail To: " + toID + " ; CC To: " + ccID + " ";

                        uscMsgBox1.AddMessage("Legal preliminary opinion done successfully." + strSuccessMsg, YaBu.MessageBox.uscMsgBox.enmMessageType.Success);


                        ClearALL();
                        View();
                    }
                    else uscMsgBox1.AddMessage("Legal preliminary opinion not done", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
            }

        }
        else
        {
            string res = "";

            if (txtbxextent.Text == "")
            {
                res = " Total extent(sqft)";
                txtbxextent.Focus();

                ajmainview.ActiveTab = PROPSDETS;
                ajmainview.Visible = true;
                ajmainview.ActiveTabIndex = 1;

            }
            else if (gvcbrw.Rows.Count <= 0)
            {
                res = "the applicant details";

                ajmainview.ActiveTab = brwdets;
                ajmainview.Visible = true;
                ajmainview.ActiveTabIndex = 0;
            }

            else if (gvschedule.Rows.Count <= 0)
            {
                res = "the property details";
                txtbxdocdate.Focus();

                ajmainview.ActiveTab = PROPSDETS;
                ajmainview.Visible = true;
                ajmainview.ActiveTabIndex = 1;
            }
            else if (gvdocs.Rows.Count <= 0)
            {
                res = "the list of documents";
                txtbxdocdate.Focus();

                ajmainview.ActiveTab = DOCSDEST;
                ajmainview.Visible = true;
                ajmainview.ActiveTabIndex = 2;
            }
            else if (!rbtnno.Checked && !rbtnyes.Checked)
            {
                res = "do you have any query";
                rbtnyes.Focus();

                ajmainview.ActiveTab = QRYDETS;
                ajmainview.Visible = true;
                ajmainview.ActiveTabIndex = 3;
            }


            uscMsgBox1.AddMessage("Please enter " + res, YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
    }

    protected int InsertQueries()
    {
        int rs = 0;


        SqlConnection con = new SqlConnection(strcon);
        try
        {

            con.Open();
            Label lblLeadID = null;
            foreach (GridViewRow grow in gvlead.Rows)
            {
                CheckBox chkStat = grow.FindControl("rb_select") as CheckBox;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    lblLeadID = (Label)gvlead.Rows[index].Cells[0].FindControl("lblLeadID");
                }
            }
            TextBox[] TextBox = pnlquery.Controls.OfType<TextBox>().ToArray();
            string query = "";
            for (int i = 0; i < TextBox.Length; i++)
            {

                if (i == 0)
                {
                    query = TextBox[i].Text;
                }
                if (i >= 1)
                {
                    if (TextBox[i].Text.Trim() != "")
                    {
                        query += "|" + TextBox[i].Text;
                        TextBox[i].Text = "";
                    }
                }
            }

            string strVal = query;
            if (query != "")
            {
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertQuery", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@Queries", query);
                cmdinsert.Parameters.AddWithValue("@QRY_LD_ID", lblLeadID.Text);
                cmdinsert.Parameters.AddWithValue("@QRY_RSD_BY", "L");
                cmdinsert.Parameters.AddWithValue("@QRY_CBY", Session["ID"].ToString());
                int i = cmdinsert.ExecuteNonQuery();
                rs = i;

            }
            return rs;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);

            return rs;
        }
        finally
        {
            con.Close();

        }

    }
    public string Queries()
    {
        string query = "";

        try
        {
            TextBox[] TextBox = pnlquery.Controls.OfType<TextBox>().ToArray();

            for (int i = 0; i < TextBox.Length; i++)
            {

                if (i == 0)
                {
                    query = TextBox[i].Text;
                }
                if (i >= 1)
                {
                    if (TextBox[i].Text.Trim() != "")
                    {
                        query += "|" + TextBox[i].Text;
                        TextBox[i].Text = "";
                    }
                }
            }

            string strVal = query;

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);

            return "";
        }

        return query;
    }

    protected void gvdocs_RowEditing(object sender, GridViewEditEventArgs e)
    {
        BindAllGrid("D");
    }


    protected void gvdocs_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        BindAllGrid("D");
    }
    protected void gvdocs_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindAllGrid("D");
    }
    protected void Insert_Borrower_Dets()
    {

        // process starts
        // NEED TO CHECK THE BORROWER DETAIS HAS MAIN APPLICANT
        if (gvcbrw.Rows.Count <= 0 && ddlstcustype.SelectedValue == "C")
        {
            uscMsgBox1.AddMessage("Please first add main applicant", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

        }
        else if (gvcbrw.Rows.Count > 0 && ddlstcustype.SelectedValue == "A")
        {
            int cnt = 0;
            foreach (GridViewRow rw in gvcbrw.Rows)
            {
                if ((rw.FindControl("lblatpe") as Label).Text == "A")
                {
                    cnt++;
                    break;
                }
            }
            if (cnt > 0)
            {
                uscMsgBox1.AddMessage("You can add only one main applicant...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }

        }
        else
        {


            if (Rx.IsMatch(txtbxage.Text.Trim()))
            {

                if (ddlstcustype.SelectedValue == "A")
                {
                    if (Rx.IsMatch(txtbxpincode.Text.Trim()))
                    {
                        Insert_Brw_Qry();
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Please check the pincode, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
                else
                {
                    Insert_Brw_Qry();
                }
                this.adr1.Visible = false;
                this.adr2.Visible = false;
            }
            else
            {
                if (!Rx.IsMatch(txtbxage.Text.Trim()))
                {
                    uscMsgBox1.AddMessage("Please check the age, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (!Rx.IsMatch(txtbxpincode.Text.Trim()))
                {
                    uscMsgBox1.AddMessage("Please check the pincode, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
            // process ends
        }
    }

    protected void Insert_Brw_Qry()
    {
        //S2
        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();
            if (Session["MDID"] == null)
            {
                try
                {

                    if (Session["ID"] != null)
                    {
                        id = Convert.ToInt32(Session["ID"].ToString());
                    }
                    else
                    {
                        Response.Redirect("Expire.aspx");
                        return;
                    }

                    cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection);
                    var obj = cmd.ExecuteScalar();
                    if (obj == null)
                    {
                        cmd = new SqlCommand("Insert into LSD_MOTD (MD_LD_ID,MD_PDATE,MD_CBY,MD_CDATE) values( " + Convert.ToInt32(Session["LEADID"].ToString()) + ",getdate()," + id + ",getdate())", connection);
                        cmd.ExecuteNonQuery();
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }


                cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection);
                dtpre = new DataTable();
                dappre = new SqlDataAdapter(cmd);
                dappre.Fill(dtpre);

                Session["MDID"] = dtpre.Rows[0]["MD_ID"] != DBNull.Value ? dtpre.Rows[0]["MD_ID"].ToString() : "";

            }

            if (gvcbrw.Rows.Count > 0)
            {
                List<int> cnt = new List<int>();
                cnt.Clear();
                foreach (GridViewRow grow in gvcbrw.Rows)
                {
                    Label lblPSCH = grow.FindControl("lblcbrwslno") as Label;


                    cnt.Add(Convert.ToInt32(lblPSCH.Text));
                }
                cbrwcnt = cnt.Max() + 1;
            }
            else
                cbrwcnt = 1;

            try
            {
                string sql = "INSERT INTO LSD_MOTD_CBRW (MCB_MD_ID,MCB_TYPE,MCB_SLNO,MCB_TITLE,MCB_NAME,MCB_RELATION,MCB_FTITLE,MCB_FNAME,MCB_PF_ID,MCB_PF_NO,MCB_AGE) values" +
                             "(" + Convert.ToInt32(Session["MDID"].ToString()) + ",'" + ddlstcustype.SelectedValue.ToString() + "'," + cbrwcnt + ",'" + ddlsttitle1.SelectedValue.ToString() + "','" + txtbxname.Text.Trim().ToUpper() + "','" +
                              ddlstsdf.SelectedValue.ToString() + "','" + ddlsttitle2.SelectedValue.ToString() + "','" + txtbxSWFof.Text.Trim().ToUpper() + "','" + ddlstidtype.SelectedValue + "','" + txtbxidtype.Text.Trim().ToUpper() + "'," + Convert.ToInt32(txtbxage.Text.Trim()) + ")";


                cmd = new SqlCommand(sql, connection);

                int r = cmd.ExecuteNonQuery();

                // NEED TO UPDATE ADDRESS IF MAIN APPLICANT
                if (ddlstcustype.SelectedValue == "A")
                {

                    sql = "UPDATE LSD_MOTD SET MD_BR1_NAME='" + txtbxname.Text.Trim().ToUpper() + "', " +
                        " MD_BR1_FNAME='" + txtbxSWFof.Text.Trim().ToUpper() + "', " +
                        " MD_BR1_AGE='" + txtbxage.Text.Trim() + "', " +
                        " MD_BR_ADD1='" + txtbxaddr1.Text.ToUpper() + "', " +
                        " MD_BR_ADD2='" + txtbxaddr2.Text.ToUpper() + "', " +
                        " MD_BR_ADD3='" + txtbxcity.Text.Trim().ToUpper() + " - " + txtbxpincode.Text.Trim() + "' " +
                        " WHERE MD_LD_ID='" + Convert.ToInt32(Session["LEADID"].ToString()) + "' ";

                    cmd = new SqlCommand(sql, connection);
                    r = r + cmd.ExecuteNonQuery();


                }

                if (r > 0)
                {
                    CLearCBRW();
                    //uscMsgBox1.AddMessage("Please check the age", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else
                {
                    uscMsgBox1.AddMessage("Applicant is not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmd.Dispose();
            }
        }
        //ends s2
    }
    protected void btnaddcbrw_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["StatusLGLCBRW"].ToString() == "New")
            {
                if (ddlstcustype.SelectedValue == "A")
                {
                    if (ddlsttitle1.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle1.Focus();
                        uscMsgBox1.AddMessage("please select the applicant title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxname.Text.Trim() == "")
                    {
                        txtbxname.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxage.Text.Trim() == "")
                    {
                        txtbxage.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant age.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstsdf.SelectedItem.Text == "--Select--")
                    {
                        ddlstsdf.Focus();
                        uscMsgBox1.AddMessage("please select the relation type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlsttitle2.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle2.Focus();
                        uscMsgBox1.AddMessage("please select the applicant's relation's title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxSWFof.Text.Trim() == "")
                    {
                        txtbxSWFof.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's relation name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstidtype.SelectedItem.Text == "--Select--")
                    {
                        ddlstidtype.Focus();
                        uscMsgBox1.AddMessage("please select the id type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxidtype.Text.Trim() == "")
                    {
                        txtbxidtype.Focus();
                        uscMsgBox1.AddMessage("please enter the ID number.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxaddr1.Text.Trim() == "")
                    {
                        txtbxaddr1.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's address 1.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxaddr2.Text.Trim() == "")
                    {
                        txtbxaddr2.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's address 2.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxcity.Text.Trim() == "")
                    {
                        txtbxcity.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's city.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxpincode.Text.Trim() == "")
                    {
                        txtbxpincode.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's pincode.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else
                    {
                        Insert_Borrower_Dets();
                    }


                }
                else if (ddlstcustype.SelectedValue == "C")
                {
                    if (ddlsttitle1.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle1.Focus();
                        uscMsgBox1.AddMessage("please select the co-applicant title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxname.Text.Trim() == "")
                    {
                        txtbxname.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxage.Text.Trim() == "")
                    {
                        txtbxage.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant age.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstsdf.SelectedItem.Text == "--Select--")
                    {
                        ddlstsdf.Focus();
                        uscMsgBox1.AddMessage("please select the relation type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlsttitle2.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle2.Focus();
                        uscMsgBox1.AddMessage("please select the co-applicant's relation's title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxSWFof.Text.Trim() == "")
                    {
                        txtbxSWFof.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant's relation name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstidtype.SelectedItem.Text == "--Select--")
                    {
                        ddlstidtype.Focus();
                        uscMsgBox1.AddMessage("please select the id type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxidtype.Text.Trim() == "")
                    {
                        txtbxidtype.Focus();
                        uscMsgBox1.AddMessage("please enter the ID number.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                    else
                    {
                        Insert_Borrower_Dets();
                    }
                }
                else
                {
                    ddlstcustype.Focus();
                    uscMsgBox1.AddMessage("please select the applicant type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

            }
            else if (Session["StatusLGLCBRW"].ToString() == "Edit")
            {
                if (ddlstcustype.SelectedValue == "A")
                {
                    if (ddlsttitle1.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle1.Focus();
                        uscMsgBox1.AddMessage("please select the applicant title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxname.Text.Trim() == "")
                    {
                        txtbxname.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxage.Text.Trim() == "")
                    {
                        txtbxage.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant age.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstsdf.SelectedItem.Text == "--Select--")
                    {
                        ddlstsdf.Focus();
                        uscMsgBox1.AddMessage("please select the relation type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlsttitle2.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle2.Focus();
                        uscMsgBox1.AddMessage("please select the applicant's relation's title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxSWFof.Text.Trim() == "")
                    {
                        txtbxSWFof.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's relation name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstidtype.SelectedItem.Text == "--Select--")
                    {
                        ddlstidtype.Focus();
                        uscMsgBox1.AddMessage("please select the id type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxidtype.Text.Trim() == "")
                    {
                        txtbxidtype.Focus();
                        uscMsgBox1.AddMessage("please enter the ID number.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxaddr1.Text.Trim() == "")
                    {
                        txtbxaddr1.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's address 1.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxaddr2.Text.Trim() == "")
                    {
                        txtbxaddr2.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's address 2.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxcity.Text.Trim() == "")
                    {
                        txtbxcity.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's city.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxpincode.Text.Trim() == "")
                    {
                        txtbxpincode.Focus();
                        uscMsgBox1.AddMessage("please enter the applicant's pincode.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else
                    {
                        Update_Borrower_Dets();
                    }


                }
                else if (ddlstcustype.SelectedValue == "C")
                {
                    if (ddlsttitle1.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle1.Focus();
                        uscMsgBox1.AddMessage("please select the co-applicant title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxname.Text.Trim() == "")
                    {
                        txtbxname.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxage.Text.Trim() == "")
                    {
                        txtbxage.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant age.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstsdf.SelectedItem.Text == "--Select--")
                    {
                        ddlstsdf.Focus();
                        uscMsgBox1.AddMessage("please select the relation type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlsttitle2.SelectedItem.Text == "--Select--")
                    {
                        ddlsttitle2.Focus();
                        uscMsgBox1.AddMessage("please select the co-applicant's relation's title.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxSWFof.Text.Trim() == "")
                    {
                        txtbxSWFof.Focus();
                        uscMsgBox1.AddMessage("please enter the co-applicant's relation name.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (ddlstidtype.SelectedItem.Text == "--Select--")
                    {
                        ddlstidtype.Focus();
                        uscMsgBox1.AddMessage("please select the id type.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                    else if (txtbxidtype.Text.Trim() == "")
                    {
                        txtbxidtype.Focus();
                        uscMsgBox1.AddMessage("please enter the ID number.", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                    else
                    {
                        Update_Borrower_Dets();
                    }
                }

            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Preliminary.aspx"); }
            catch (Exception innerEx) { ErrorLog.WriteError(innerEx); }
        }

        BindAllGrid("C");

        btnsubmit.Focus();

    }

    protected void Update_Borrower_Dets()
    {
        if (Rx.IsMatch(txtbxage.Text.Trim()))
        {

            if (ddlstcustype.SelectedValue == "A")
            {
                if (Rx.IsMatch(txtbxpincode.Text.Trim()))
                {
                    Update_Brw_Qry();
                }
                else
                {
                    uscMsgBox1.AddMessage("Please check the pincode, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
            else
            {
                Update_Brw_Qry();
            }

            this.adr1.Visible = false;
            this.adr2.Visible = false;

        }
        else
        {
            if (!Rx.IsMatch(txtbxage.Text.Trim()))
            {
                uscMsgBox1.AddMessage("Please check the age, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (!Rx.IsMatch(txtbxpincode.Text.Trim()))
            {
                uscMsgBox1.AddMessage("Please check the pincode, it should be numbers only", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
    }
    protected void Update_Brw_Qry()
    {
        //S1
        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                string sql = "Update  LSD_MOTD_CBRW set MCB_NAME='" + txtbxname.Text.Trim().ToUpper() + "'," +
                                " MCB_FNAME='" + txtbxSWFof.Text.Trim().ToUpper() + "'," +
                                " MCB_AGE=" + Convert.ToInt32(txtbxage.Text.Trim()) + ", " +
                                " MCB_TITLE='" + ddlsttitle1.SelectedValue + "', " +
                                " MCB_FTITLE='" + ddlsttitle2.SelectedValue + "', " +
                                " MCB_RELATION='" + ddlstsdf.SelectedValue + "', " + //MCB_PF_ID MCB_PF_NO
                                " MCB_PF_ID='" + ddlstidtype.SelectedValue + "', " +
                                " MCB_PF_NO='" + txtbxidtype.Text.Trim().ToUpper() + "' " +
                                " Where MCB_SLNO=" + Convert.ToInt32(Session["SLNOCBRW"].ToString()) +
                                " and MCB_MD_ID=" + Convert.ToInt32(Session["MDID"].ToString());



                cmd = new SqlCommand(sql, connection);

                int r = cmd.ExecuteNonQuery();

                // NEED TO UPDATE ADDRESS IF MAIN APPLICANT
                if (ddlstcustype.SelectedValue == "A")
                {

                    sql = "UPDATE LSD_MOTD SET MD_BR1_NAME='" + txtbxname.Text.Trim().ToUpper() + "', " +
                        " MD_BR1_FNAME='" + txtbxSWFof.Text.Trim().ToUpper() + "', " +
                        " MD_BR1_AGE='" + txtbxage.Text.Trim() + "', " +
                        " MD_BR_ADD1='" + txtbxaddr1.Text.ToUpper() + "', " +
                        " MD_BR_ADD2='" + txtbxaddr2.Text.ToUpper() + "', " +
                        " MD_BR_ADD3='" + txtbxcity.Text.Trim().ToUpper() + " - " + txtbxpincode.Text.Trim() + "' " +
                        " WHERE MD_LD_ID='" + Convert.ToInt32(Session["LEADID"].ToString()) + "' ";

                    cmd = new SqlCommand(sql, connection);
                    r = r + cmd.ExecuteNonQuery();


                }
                if (r > 0)
                {
                    CLearCBRW();
                    Session["StatusLGLCBRW"] = "New";
                    //uscMsgBox1.AddMessage("Please check the age", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else
                {
                    uscMsgBox1.AddMessage("Applicant is not updated...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmd.Dispose();
            }
        }

        //END S1
    }

    protected void gvcbrw_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Delete")
        {

            strValb = e.CommandArgument.ToString();
            using (SqlConnection connection = new SqlConnection(strcon))
            {
                connection.Open();


                try
                {
                    int cnt = 0;
                    string sln = "";
                    if (gvcbrw.Rows.Count > 0)
                    {
                        cnt = 0;

                        foreach (GridViewRow rw in gvcbrw.Rows)
                        {
                            if ((rw.FindControl("lblatpe") as Label).Text == "A")
                            {
                                sln =(rw.FindControl("lblcbrwslno") as Label).Text;

                                break;
                            }
                        }


                    }
                    string sql = "";
                      int r=0;
                    if (strValb!=sln)
                    {
                        sql = "DELETE FROM  LSD_MOTD_CBRW WHERE MCB_MD_ID=" + Convert.ToInt32(Session["MDID"].ToString()) + " and MCB_SLNO=" + Convert.ToInt32(strValb);
                        cmd = new SqlCommand(sql, connection);

                      r = cmd.ExecuteNonQuery();

                    }
                    else
                    {
                        uscMsgBox1.AddMessage("You can not delete the Main Applicant but you can modify", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        return;
                    }

                    
                    //// NEED TO UPDATE ADDRESS IF MAIN APPLICANT
                    //if (ddlstcustype.SelectedValue == "A")
                    //{

                    //    sql = "UPDATE LSD_MOTD SET MD_BR1_NAME='" + DBNull.Value + "', " +
                    //        " MD_BR1_FNAME='" + DBNull.Value + "', " +
                    //        " MD_BR1_AGE='" + DBNull.Value + "', " +
                    //        " MD_BR_ADD1='" + DBNull.Value + "', " +
                    //        " MD_BR_ADD2='" + DBNull.Value + "', " +
                    //        " MD_BR_ADD3='" + DBNull.Value + "' " +
                    //        " WHERE MD_LD_ID='" + Convert.ToInt32(Session["LEADID"].ToString()) + "' ";

                    //    cmd = new SqlCommand(sql, connection);
                    //    r = r + cmd.ExecuteNonQuery();
                    //}



                    if (r > 0)
                    {
                        BindAllGrid("C");
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Borrower / Co-Borrower not deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }

                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                    uscMsgBox1.AddMessage("Please check the entered data", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                finally
                {
                    cmd.Dispose();
                }
            }


        }
        if (e.CommandName == "Edit")
        {
            strValb = e.CommandArgument.ToString();

            Session["StatusLGLCBRW"] = "Edit";
            Session["SLNOCBRW"] = strValb;
            foreach (GridViewRow grow in gvcbrw.Rows)
            {
                Label lblcbrwsno = grow.FindControl("lblcbrwslno") as Label;
                if (strValb == lblcbrwsno.Text)
                {
                    string[] arrname = (grow.FindControl("lblcbrwname") as Label).Text.Split('.');
                    ddlsttitle1.SelectedValue = arrname[0].ToString() + ". ";
                    txtbxname.Text = arrname[1].ToString().Trim();

                    string[] arrname1 = (grow.FindControl("lblcbrwswf") as Label).Text.Split('.');
                    ddlsttitle2.SelectedValue = arrname1[0].ToString() + ". ";
                    txtbxSWFof.Text = arrname1[1].ToString().Trim();

                    ddlstsdf.SelectedValue = (grow.FindControl("lblrel") as Label).Text;
                    txtbxage.Text = (grow.FindControl("lblcbrwage") as Label).Text;
                    ddlstcustype.SelectedValue = (grow.FindControl("lblatpe") as Label).Text;
                    ddlstcustype.Enabled = false;

                    if (ddlstcustype.SelectedValue == "A")
                    {
                        BindAllGrid("All");
                        this.adr1.Visible = true;
                        this.adr2.Visible = true;
                    }
                    else
                    {
                        txtbxaddr1.Text = "";
                        txtbxaddr2.Text = "";
                        txtbxcity.Text = "";
                        txtbxpincode.Text = "";


                        this.adr1.Visible = false;
                        this.adr2.Visible = false;

                    }

                    ddlstidtype.SelectedValue = (grow.FindControl("lblidtype") as Label).Text;
                    txtbxidtype.Text = (grow.FindControl("lblIDNO") as Label).Text;

                    break;
                }
            }

            btnaddcbrw.Text = "Update";
            BindAllGrid("C");
        }

    }
    protected void gvcbrw_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void gvcbrw_RowEditing(object sender, GridViewEditEventArgs e)
    {
        BindAllGrid("C");
    }
    protected void gvcbrw_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        BindAllGrid("C");
    }
    protected void gvcbrw_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindAllGrid("C");
    }

    private void ClearSch()
    {
        txtbxpropschedule.Text = "";
        txtbxnorthby.Text = "";
        txtbxsouthby.Text = "";
        txtbxeastby.Text = "";
        txtbxwestby.Text = "";
        txtbxregoffice.Text = "";
        txtbxregdistrict.Text = "";
        ddlstproptype.SelectedIndex = 0;
        btnscheduleadd.Text = "Add Schedule";
        txtMeasurement.Text = "";
        lstPropOwner.SelectedIndex = -1;

    }
    protected void btnscheduleadd_Click(object sender, EventArgs e)
    {

        try
        {
            if (lstPropOwner.SelectedIndex != -1)
            {
                if (Session["StatusLGLSCHEDULE"].ToString() == "New")
                {

                    if (txtbxpropschedule.Text != "" && txtbxnorthby.Text != "" && txtbxsouthby.Text != "" && txtbxwestby.Text != "" && txtbxeastby.Text != "" && ddlstproptype.SelectedItem.Text != "--Select--" && txtbxregoffice.Text != "" && txtbxregdistrict.Text != "" && txtMeasurement.Text != "")//&& ddlstdocstatus.SelectedItem.Text != "--Select--")
                    {
                        using (SqlConnection connection = new SqlConnection(strcon))
                        {
                            connection.Open();
                            if (Session["MDID"] == null)
                            {
                                try
                                {
                                    // id = Session["ID"] != null ? Convert.ToInt32(Session["ID"].ToString()) : 0;
                                    if (Session["ID"] != null)
                                    {
                                        id = Convert.ToInt32(Session["ID"].ToString());
                                    }
                                    else
                                    {
                                        Response.Redirect("Expire.aspx");
                                        return;
                                    }


                                    cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection);
                                    var obj = cmd.ExecuteScalar();
                                    if (obj == null)
                                    {
                                        cmd = new SqlCommand("Insert into LSD_MOTD (MD_LD_ID,MD_PDATE,MD_CBY,MD_CDATE) values( " + Convert.ToInt32(Session["LEADID"].ToString()) + ",getdate()," + id + ",getdate())", connection);
                                        cmd.ExecuteNonQuery();
                                    }

                                }
                                catch (Exception ex)
                                {
                                    ErrorLog.WriteError(ex);
                                }


                                cmd = new SqlCommand("SELECT * FROM LSD_MOTD WHERE MD_LD_ID=" + Convert.ToInt32(Session["LEADID"].ToString()), connection);
                                dtpre = new DataTable();
                                dappre = new SqlDataAdapter(cmd);
                                dappre.Fill(dtpre);

                                Session["MDID"] = dtpre.Rows[0]["MD_ID"] != DBNull.Value ? dtpre.Rows[0]["MD_ID"].ToString() : "";

                            }

                            if (gvschedule.Rows.Count > 0)
                            {
                                List<int> cnt = new List<int>();
                                cnt.Clear();
                                foreach (GridViewRow grow in gvschedule.Rows)
                                {
                                    Label lblPSCH = grow.FindControl("LBLSNO") as Label;


                                    cnt.Add(Convert.ToInt32(lblPSCH.Text));
                                }
                                propcnt = cnt.Max() + 1;
                            }
                            else
                                propcnt = 1;

                            try
                            {
                                string selectedReference = ",";

                                foreach (ListItem li in lstPropOwner.Items)
                                {
                                    if (li.Selected)
                                    {
                                        selectedReference = selectedReference + li.Value + ",";

                                    }
                                }
                                string regstr = "Situated at within the Sub-Registration District of " + txtbxregoffice.Text.Trim() + " and Registration District of " + txtbxregdistrict.Text.Trim();
                              /*  string sql = "INSERT INTO LSD_MOTD_PROPERTY (MP_MD_ID,MP_SLNO,MP_PTYPE,MP_PROP,MP_NORTH,MP_SOUTH,MP_EAST,MP_WEST,MP_REGISTR,MP_MEASURE,MP_PROP_OWNER) values(" + Convert.ToInt32(Session["MDID"].ToString()) + "," + propcnt + ",'" + ddlstproptype.SelectedItem.Text + "','" +
                                              txtbxpropschedule.Text.Replace("'", "''").ToString() + "','" + txtbxnorthby.Text.Trim().Replace("'", "''").ToString() + "','" + txtbxsouthby.Text.Trim().Replace("'", "''").ToString() + "','" + txtbxeastby.Text.Trim().Replace("'", "''").ToString() + "','" + txtbxwestby.Text.Trim().Replace("'", "''").ToString() + "','" + regstr + "','" + txtMeasurement.Text.Trim().Replace("'", "''").ToString() + "','" + selectedReference.Trim().ToString() + "')";
                                cmd = new SqlCommand(sql, connection);
                                */
                                SqlCommand cmd = new SqlCommand("RTS_SP_BIND_MOTD_PROPERTY", connection);
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@MP_MD_ID", Convert.ToInt32(Session["MDID"].ToString()));
                                cmd.Parameters.AddWithValue("@MP_SLNO", propcnt);
                                cmd.Parameters.AddWithValue("@MP_PTYPE", ddlstproptype.SelectedItem.Text);
                                cmd.Parameters.AddWithValue("@MP_PROP", txtbxpropschedule.Text.ToString());
                                cmd.Parameters.AddWithValue("@MP_NORTH", txtbxnorthby.Text.Trim().ToString() );
                                cmd.Parameters.AddWithValue("@MP_SOUTH", txtbxsouthby.Text.Trim().ToString() );
                                cmd.Parameters.AddWithValue("@MP_EAST",  txtbxeastby.Text.Trim().ToString());
                                cmd.Parameters.AddWithValue("@MP_WEST", txtbxwestby.Text.Trim().ToString());
                                cmd.Parameters.AddWithValue("@MP_MEASURE", txtMeasurement.Text.Trim().ToString());
                                cmd.Parameters.AddWithValue("@MP_REGISTR", regstr);
                                cmd.Parameters.AddWithValue("@MP_PROP_OWNER", selectedReference.Trim().ToString());

                                int r = cmd.ExecuteNonQuery();
                                if (r > 0)
                                {
                                    ClearSch();
                                    BindAllGrid("P");
                                    //uscMsgBox1.AddMessage("Please check the age", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                                }
                                else
                                {
                                    uscMsgBox1.AddMessage("Property Schedule not added...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                                }

                            }
                            catch (Exception ex)
                            {
                                ErrorLog.WriteError(ex);
                                uscMsgBox1.AddMessage("Property Schedule input field should be less than 2000 characters... & Boundary Details and Reg.Office, District input field should be less than 50 characters each...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }
                            finally
                            {
                                cmd.Dispose();
                                //connection.Close();
                            }
                        }
                    }
                    else
                    {
                        if (txtbxpropschedule.Text == "")
                        {
                            txtbxpropschedule.Focus();

                        }
                        else if (ddlstproptype.SelectedItem.Text == "--Select--")
                        {
                            ddlstproptype.Focus();
                        }
                        else if (txtbxnorthby.Text == "")
                        {
                            txtbxnorthby.Focus();

                        }
                        else if (txtbxsouthby.Text == "")
                        {
                            txtbxsouthby.Focus();
                        }
                        else if (txtbxeastby.Text == "")
                        {
                            txtbxeastby.Focus();

                        }
                        else if (txtbxwestby.Text == "")
                        {
                            txtbxwestby.Focus();
                        }
                        else if (txtbxregoffice.Text == "")
                        {
                            txtbxregoffice.Focus();
                        }
                        else if (txtbxregdistrict.Text == "")
                        {
                            txtbxregdistrict.Focus();
                        }
                        else if (txtMeasurement.Text == "")
                        {
                            txtMeasurement.Focus();
                        }

                        uscMsgBox1.AddMessage("Please Give corresponding Inputs for Schedule List", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                    }
                }
                else if (Session["StatusLGLSCHEDULE"].ToString() == "Edit")
                {

                    if (txtbxpropschedule.Text != "" && txtbxnorthby.Text != "" && txtbxsouthby.Text != "" && txtbxwestby.Text != "" && txtbxeastby.Text != "" && ddlstproptype.SelectedItem.Text != "--Select--" && txtbxregoffice.Text != "" && txtbxregdistrict.Text != "")//&& ddlstdocstatus.SelectedItem.Text != "--Select--")
                    {
                        using (SqlConnection connection = new SqlConnection(strcon))
                        {
                            connection.Open();


                            try
                            {
                                string selectedReference = ",";

                                foreach (ListItem li in lstPropOwner.Items)
                                {
                                    if (li.Selected)
                                    {
                                        selectedReference = selectedReference + li.Value + ",";

                                    }
                                }
                                string regstr = "Situated at within the Sub-Registration District of " + txtbxregoffice.Text.Trim() + " and Registration District of " + txtbxregdistrict.Text.Trim();


                                string sql = "Update  LSD_MOTD_PROPERTY set " +
                                                        " MP_PTYPE='" + ddlstproptype.SelectedItem.Text + "'," +
                                                        " MP_PROP='" + txtbxpropschedule.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                        " MP_NORTH='" + txtbxnorthby.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                        " MP_SOUTH='" + txtbxsouthby.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                        " MP_EAST='" + txtbxeastby.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                        " MP_WEST='" + txtbxwestby.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                        " MP_REGISTR='" + regstr + "'," +
                                                        "MP_MEASURE='" + txtMeasurement.Text.Trim().Replace("'", "''").ToString() + "'," +
                                                         "MP_PROP_OWNER='" + selectedReference.Trim().ToString() + "'" +
                                               " Where MP_SLNO=" + Convert.ToInt32(Session["SLNOSCH"].ToString()) +
                                               " and MP_MD_ID=" + Convert.ToInt32(Session["MDID"].ToString());



                                cmd = new SqlCommand(sql, connection);

                                int r = cmd.ExecuteNonQuery();
                                if (r > 0)
                                {
                                    ClearSch();

                                    BindAllGrid("P");
                                    Session["StatusLGLSCHEDULE"] = "New";

                                }
                                else
                                {
                                    uscMsgBox1.AddMessage("Property Details not updated...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                                }

                            }
                            catch (Exception ex)
                            {
                                ErrorLog.WriteError(ex);
                                uscMsgBox1.AddMessage("Properthy Schedule input field should be less than 2000 characters... & Boundary Details and Reg.Office, District input field should be less than 50 characters each...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }
                            finally
                            {
                                cmd.Dispose();
                            }
                        }


                    }
                    else
                    {
                        if (txtbxpropschedule.Text == "")
                        {
                            txtbxpropschedule.Focus();

                        }
                        else if (ddlstproptype.SelectedItem.Text == "--Select--")
                        {
                            ddlstproptype.Focus();
                        }
                        else if (txtbxnorthby.Text == "")
                        {
                            txtbxnorthby.Focus();

                        }
                        else if (txtbxsouthby.Text == "")
                        {
                            txtbxsouthby.Focus();
                        }
                        else if (txtbxeastby.Text == "")
                        {
                            txtbxeastby.Focus();

                        }
                        else if (txtbxwestby.Text == "")
                        {
                            txtbxwestby.Focus();
                        }
                        else if (txtbxregoffice.Text == "")
                        {
                            txtbxregoffice.Focus();
                        }
                        else if (txtbxregdistrict.Text == "")
                        {
                            txtbxregdistrict.Focus();
                        }

                        uscMsgBox1.AddMessage("Please Give corresponding Inputs for Schedule List", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                    }
                }

            }
            else
            {
                uscMsgBox1.AddMessage("Please Select Property Owner(s)", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

                  
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void gvschedule_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Delete")
            {

                strValp = e.CommandArgument.ToString();
                using (SqlConnection connection = new SqlConnection(strcon))
                {
                    connection.Open();


                    try
                    {
                        string sql = "DELETE FROM  LSD_MOTD_PROPERTY WHERE MP_MD_ID=" + Convert.ToInt32(Session["MDID"].ToString()) + " and MP_SLNO=" + strValp + "";


                        cmd = new SqlCommand(sql, connection);

                        int r = cmd.ExecuteNonQuery();
                        if (r > 0)
                        {
                            BindAllGrid("P");
                        }
                        else
                        {
                            uscMsgBox1.AddMessage("Property Detail not deleted...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        }

                    }
                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);

                        return;
                    }
                    finally
                    {
                        cmd.Dispose();
                    }
                }


                ClearSch();

            }
            if (e.CommandName == "Edit")
            {
                strValp = e.CommandArgument.ToString();

                Session["StatusLGLSCHEDULE"] = "Edit";
                Session["SLNOSCH"] = strValp;
                foreach (GridViewRow grow in gvschedule.Rows)
                {
                    Label lblPSCH = grow.FindControl("LBLSNO") as Label;
                    Label lblPropOwner = grow.FindControl("lblPropOwner") as Label;
                    if (strValp == lblPSCH.Text)
                    {

                        txtbxpropschedule.Text = (grow.FindControl("lblsch") as Label).Text;
                        ddlstproptype.SelectedValue = (grow.FindControl("lblptype") as Label).Text;
                        txtbxnorthby.Text = (grow.FindControl("lblnrthby") as Label).Text;
                        txtbxsouthby.Text = (grow.FindControl("lblsthby") as Label).Text;
                        txtbxeastby.Text = (grow.FindControl("lblestby") as Label).Text;
                        txtbxwestby.Text = (grow.FindControl("lblwstby") as Label).Text;
                        txtbxregoffice.Text = (grow.FindControl("lblregoff") as Label).Text;
                        txtbxregdistrict.Text = (grow.FindControl("lblregDST") as Label).Text;
                        txtMeasurement.Text = (grow.FindControl("lblMeasurement") as Label).Text;
                        lblPropOwner.Text = (grow.FindControl("lblPropOwner") as Label).Text;
                        if (lblPropOwner.Text != "" && lblPropOwner.Text != null)
                        {
                            //trReference.Visible = true;

                            //ddlReference.SelectedValue = Convert.ToInt32(qrypromotion.ReferenceId).ToString();

                            string strReferenceID = lblPropOwner.Text;
                            string[] strRefer = strReferenceID.Split(new char[] { ',' });

                            for (int i = 0; i < strRefer.Length - 1; i++)
                            {
                                ListItem li = lstPropOwner.Items.FindByValue(strRefer[i]);
                                if (li != null)
                                {
                                    li.Selected = true;
                                }

                            }

                        }
                        break;
                    }
                }

                btnscheduleadd.Text = "Update Schedule";
                BindAllGrid("P");
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void gvschedule_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void gvschedule_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindAllGrid("P");
    }
    protected void gvschedule_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        BindAllGrid("P");
    }
    protected void gvschedule_RowEditing(object sender, GridViewEditEventArgs e)
    {
        BindAllGrid("P");
    }
    protected void gvdocs_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Char dateSplitter = new Char();
            string tempdate = DataBinder.Eval(e.Row.DataItem, "MDX_DATE").ToString();
            Label lbdate = (Label)e.Row.FindControl("lbldate");

            if (tempdate.Contains(".")) { dateSplitter = '.'; }
            else if (tempdate.Contains("/")) { dateSplitter = '/'; }
            else if (tempdate.Contains("-")) { dateSplitter = '-'; }

            //string[] dbarr = tempdate.Split('/');
            string[] dbarr = tempdate.Split(dateSplitter); 
            (e.Row.FindControl("lbldate") as Label).Text = dbarr[1].ToString() + "-" + dbarr[0].ToString() + "-" + dbarr[2].ToString();
        }
    }



    protected void BindAllGrid(string Type)
    {
        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                cmd = new SqlCommand("RTS_SP_BIND_LGL_PREOPINION", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@LDID", Convert.ToInt32(Session["LEADID"].ToString()));
                cmd.CommandTimeout = 120000;
                dspre = new DataSet();
                dappre = new SqlDataAdapter(cmd);
                dappre.Fill(dspre);
                if (Type == "All")
                {

                    if (dspre.Tables.Count > 0)
                    {

                        if (dspre.Tables[0].Rows.Count > 0)
                        {
                            Session["MDID"] = dspre.Tables[0].Rows[0]["MD_ID"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_ID"].ToString() : null;
                            txtbxaddr1.Text = dspre.Tables[0].Rows[0]["MD_BR_ADD1"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_BR_ADD1"].ToString() : "";
                            txtbxaddr2.Text = dspre.Tables[0].Rows[0]["MD_BR_ADD2"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_BR_ADD2"].ToString() : "";
                            string[] addrarr = dspre.Tables[0].Rows[0]["MD_BR_ADD3"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_BR_ADD3"].ToString().Split('-') : null;
                            if (addrarr != null && addrarr.Length > 1)
                            {
                                txtbxcity.Text = addrarr[0].ToString().Trim();
                                txtbxpincode.Text = addrarr[1].ToString().Trim();
                            }
                            else
                            {
                                txtbxcity.Text = "";
                                txtbxpincode.Text = "";
                            }
                        }
                        else Session["MDID"] = null;

                        gvcbrw.DataSource = dspre.Tables[1];
                        gvcbrw.DataBind();

                        gvschedule.DataSource = dspre.Tables[2];
                        gvschedule.DataBind();

                        gvdocs.DataSource = dspre.Tables[3];
                        gvdocs.DataBind();
                    }
                    else Session["MDID"] = null;
                }
                else
                {
                    if (Type == "C")
                    {

                        if (dspre.Tables.Count > 0)
                        {
                            gvcbrw.DataSource = dspre.Tables[1];
                            gvcbrw.DataBind();

                        }
                    }
                    else if (Type == "P")
                    {

                        gvschedule.DataSource = dspre.Tables[2];
                        gvschedule.DataBind();

                    }
                    else if (Type == "D")
                    {
                        gvdocs.DataSource = dspre.Tables[3];
                        gvdocs.DataBind();

                    }
                    else
                    {
                        if (dspre.Tables[0] != null)
                        {
                            if (dspre.Tables[0].Rows.Count > 0)
                            {
                                Session["MDID"] = dspre.Tables[0].Rows[0]["MD_ID"] != DBNull.Value ? dspre.Tables[0].Rows[0]["MD_ID"].ToString() : null;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
        }
    }
    protected void gvschedule_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string tempdate = DataBinder.Eval(e.Row.DataItem, "MP_REGISTR").ToString();
                Label lblrego = (Label)e.Row.FindControl("lblregoff");
                Label lblregd = (Label)e.Row.FindControl("lblregDST");
                Label lblPropertyOwner = (Label)e.Row.FindControl("lblPropOwner");
                Label lblOwnerName = (Label)e.Row.FindControl("lblOwnerName");
             
                int districtend = Convert.ToInt32(tempdate.IndexOf("and Registration"));
                int len = districtend - 52;
                string district = tempdate.Substring(52, len);
                (e.Row.FindControl("lblregoff") as Label).Text = district;
                (e.Row.FindControl("lblregDST") as Label).Text = tempdate.Substring(districtend + 29);
                e.Row.Cells[0].Attributes.Add("style", "word-break:break-all;word-wrap:break-word;");
                e.Row.Cells[1].Attributes.Add("style", "word-break:break-all;word-wrap:break-word;");
                if (lblPropertyOwner.Text != null && lblPropertyOwner.Text != "")
                {
                    string propOwner = "";
                    //lblPropertyOwner.Text = ((lblPropertyOwner.Text).TrimEnd(',')).TrimStart(',');

                    // string strReferenceID = lblPropertyOwner.Text;
                    //string[] strRefer = strReferenceID.Split(new char[] { ',' });

                    //foreach (string word in strRefer)
                    //{
                    //    string powner="";
                    //   // Console.WriteLine(word);
                    //    if (word!="")
                    //    { 
                    //    powner = clscommon.GetPropertyOwner(word);
                    //      propOwner+=powner;
                    //    }
                    //}
                    propOwner = clscommon.GetPropOwner(lblPropertyOwner.Text);
                    // lblOwnerName.Text = propOwner.Replace(',', '\n');


                    // string str = "The quick brown fox     jumps over the lazy dog";
                    string[] ab = propOwner.Split(' ');
                    if (ab != null && ab.Length > 0)
                    {
                        string de = ab[0].Trim();
                        for (int i = 1; i < ab.Length; i++)
                        {
                            de += ab[i] + "\n";
                        }

                        propOwner = de;
                    }
                    //propOwner = Regex.Replace(propOwner, @"\s+", Environment.NewLine);

                    lblOwnerName.Text = propOwner;
                    //for (int i = 0; i < strRefer.Length - 1; i++)
                    //{
                    //    ListItem li = lstPropOwner.Items.FindByValue(strRefer[i]);
                    //    if (li != null)
                    //    {
                    //       // li.Selected = true;
                    //        propOwner = clscommon.GetPropertyOwner(strRefer[i]);
                    //    }
                    //    lblOwnerName.Text = propOwner;
                    //}


                }

            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
  
    public void sendMail(SqlConnection con)
    {
        try
        {
            StringBuilder cmd = new StringBuilder();


            cmd.Append("SELECT 	LD_NO 'LEADNO', LD_APNAME 'APPLICANT',(SELECT PR_NAME FROM MR_PRODUCT WHERE PR_ID=A.LD_PR_ID) 'PRODUCT',C.AR_ID 'AID',C.AR_NAME 'AREA',C.AR_DV_ID 'DID', B.BR_ID 'BID',B.BR_NAME 'BRANCH' FROM	LSD_LEAD A ");
            cmd.Append(" JOIN MR_BRANCH B ON B.BR_ID=A.LD_BR_ID ");
            cmd.Append(" JOIN MR_AREA  C ON C.AR_ID= B.BR_AR_ID ");
            cmd.Append(" WHERE A.LD_ID=");
            cmd.Append(Session["LEADID"].ToString());


            SqlCommand cmddet = new SqlCommand(cmd.ToString(), con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataTable dtdet = new DataTable();
            dadet.Fill(dtdet);
            Session["LNO"] = "";
            Session["APNME"] = "";
            Session["PRDT"] = "";
            Session["ANME"] = "";
            Session["BNME"] = "";
            Session["ARID"] = "";
            Session["BRID"] = "";
            Session["DVID"] = "";


            if (dtdet.Rows.Count > 0)
            {

                Session["LNO"] = dtdet.Rows[0]["LEADNO"] != DBNull.Value ? dtdet.Rows[0]["LEADNO"].ToString() : "";
                Session["APNME"] = dtdet.Rows[0]["APPLICANT"] != DBNull.Value ? dtdet.Rows[0]["APPLICANT"].ToString() : "";

                Session["PRDT"] = dtdet.Rows[0]["PRODUCT"] != DBNull.Value ? dtdet.Rows[0]["PRODUCT"].ToString() : "";
                Session["ANME"] = dtdet.Rows[0]["AREA"] != DBNull.Value ? dtdet.Rows[0]["AREA"].ToString() : "";
                Session["BNME"] = dtdet.Rows[0]["BRANCH"] != DBNull.Value ? dtdet.Rows[0]["BRANCH"].ToString() : "";
                Session["ARID"] = dtdet.Rows[0]["AID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["AID"].ToString()) : 0;
                Session["BRID"] = dtdet.Rows[0]["BID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["BID"].ToString()) : 0;
                Session["DVID"] = dtdet.Rows[0]["DID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["DID"].ToString()) : 0;
            }
            else
            {
                blMailStatus = false;
                return;
            }

            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_EMAIL WHERE EM_BR_ID=");
            cmd.Append(Session["BRID"].ToString());

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtbrnch = new DataTable();
            dadet.Fill(dtbrnch);


            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_AREA_MANAGER WHERE AM_AR_ID=");
            cmd.Append(Session["ARID"].ToString());

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtarm = new DataTable();
            dadet.Fill(dtarm);


            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_EMPLOYEE JOIN MR_USER ON USR_EMP_ID=EMP_ID WHERE USR_ID='" + Session["ID"].ToString() + "'");


            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            dtarm = new DataTable();
            dadet.Fill(dtarm);

            Session["PTOID"] = "";
            Session["PCCID"] = "";



            toID = "";
            ccID = "";

            if (dtbrnch.Rows.Count > 0)
            {

                if (dtbrnch.Rows[0]["EM_BM"] != "" && dtbrnch.Rows[0]["EM_BM"] != DBNull.Value && dtbrnch.Rows[0]["EM_BM"].ToString() != "")
                {
                    //toID = dtbrnch.Rows[0]["EM_BM"].ToString();
                    Session["PTOID"] = dtbrnch.Rows[0]["EM_BM"].ToString();
                }
                else
                {

                    // toID = "rts-helpdesk@equitasbank.com";
                    Session["PTOID"] = "rts-helpdesk@equitasbank.com";

                }

                if (dtbrnch.Rows[0]["EM_AM"] != "" && dtbrnch.Rows[0]["EM_AM"] != DBNull.Value && dtbrnch.Rows[0]["EM_AM"].ToString() != "")
                {
                    // ccID = dtbrnch.Rows[0]["EM_AM"].ToString();
                    Session["PCCID"] = dtbrnch.Rows[0]["EM_AM"].ToString();
                }

                if (dtarm.Rows[0]["EMP_EMAILID"] != "" && dtarm.Rows[0]["EMP_EMAILID"] != DBNull.Value && dtarm.Rows[0]["EMP_EMAILID"].ToString() != "")
                {
                    // ccID = dtbrnch.Rows[0]["EM_AM"].ToString();

                    if (Session["PCCID"].ToString() != "")
                    {
                        Session["PCCID"] = Session["PCCID"].ToString() + ";" + dtarm.Rows[0]["EMP_EMAILID"].ToString();
                    }
                    else
                    {
                        Session["PCCID"] = dtarm.Rows[0]["EMP_EMAILID"].ToString();
                    }
                }

                //if (toID.ToString().StartsWith(";"))
                //{
                //    toID = toID.Substring(1, toID.Length - 1);
                //}
                //if (toID.EndsWith(";"))
                //{
                //    toID = toID.Remove(toID.ToString().Length - 1, 1);
                //}

                //if (ccID.ToString().StartsWith(";"))
                //{
                //    ccID = ccID.Substring(1, ccID.Length - 1);
                //}
                //if (ccID.EndsWith(";"))
                //{
                //    ccID = ccID.Remove(ccID.ToString().Length - 1, 1);
                //}


                if (Session["PTOID"].ToString().StartsWith(";"))
                {
                    Session["PTOID"] = Session["PTOID"].ToString().Substring(1, Session["PTOID"].ToString().Length - 1);
                }
                if (Session["PTOID"].ToString().EndsWith(";"))
                {
                    Session["PTOID"] = Session["PTOID"].ToString().Remove(Session["PTOID"].ToString().Length - 1, 1);
                }

                if (Session["PCCID"].ToString().StartsWith(";"))
                {
                    Session["PCCID"] = Session["PCCID"].ToString().Substring(1, Session["PCCID"].ToString().Length - 1);
                }
                if (Session["PCCID"].ToString().EndsWith(";"))
                {
                    Session["PCCID"] = Session["PCCID"].ToString().Remove(Session["PCCID"].ToString().Length - 1, 1);
                }

            }
            else
            {
                blMailStatus = false;
                return;
            }



            frmID = "RTS Alerts";

            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Legal Preliminary Opinion. <br/><br/>";
                BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["LNO"].ToString() + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Area Name</td><td><strong>" + Session["ANME"].ToString() + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Branch Name</td><td><strong>" + Session["BNME"].ToString() + "</strong></td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + Session["PRDT"].ToString() + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + Session["APNME"].ToString() + "</strong></td><td>Legal Status</td><td><strong> Pre-Opinion Done </strong></td></tr></table><br/>";

                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/>Thanks and Regards,<br/>Legal Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is an auto-generated e-mail. Please Do not reply to this e-mail.</strong></span></td></tr></table></tr></table></html>";


                blMailStatus = EmailManager.sendemail(Session["PTOID"].ToString(), "RTS Alerts", "", Session["PCCID"].ToString(), "Lead No. : " + Session["LNO"].ToString() + " - Applicant Name : " + Session["APNME"].ToString() + " - Product : " + Session["PRDT"].ToString() + " - Legal Preliminary Opinion", BodyTxt, "", true);


            //});

            //threadSendMails.IsBackground = true;
            //mail = threadSendMails;
            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(5000);


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }

    protected void btnpreviewp_Click(object sender, EventArgs e)
    {
        if (gvschedule.Rows.Count > 0 && gvdocs.Rows.Count > 0)
        {
            try
            {

                con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                    con.Open();
                cmdp = new SqlCommand("RTS_SP_PRELIMINARY", con);
                cmdp.CommandType = CommandType.StoredProcedure;
                cmdp.Parameters.AddWithValue("@LDNO", Session["PreviewLDNOP"].ToString());
                cmdp.CommandTimeout = 12000;
                dap = new SqlDataAdapter(cmdp);
                ds = new DataSet();
                dap.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    /*---Queries---*/

                    TextBox[] TextBox = pnlquery.Controls.OfType<TextBox>().ToArray();
                    StringBuilder qryp = new StringBuilder();
                    for (int i = 0; i < TextBox.Length; i++)
                    {

                        if (i == 0)
                        {
                            if (TextBox[i].Text.Trim() != "")
                            {
                                qryp.Append("1. " + TextBox[i].Text + ".");
                            }
                        }
                        if (i >= 1)
                        {
                            if (TextBox[i].Text.Trim() != "")
                            {
                                qryp.AppendLine();

                                qryp.Append((i + 1).ToString() + ". " + TextBox[i].Text + ".");
                                TextBox[i].Text = "";
                            }
                        }
                    }
                    if (qryp.ToString() == "")
                        qryp.Append("NIL");



                    cusnames = new StringBuilder();
                    //cusnames.Append("Mr/Ms. ");
                    //cusnames.Append(ds.Tables[0].Rows[0]["LD_APNAME"].ToString());
                    for (int k = 0; k < ds.Tables[1].Rows.Count; k++)
                    {
                        if (k != ds.Tables[1].Rows.Count - 1)
                        {
                            cusnames.Append(ds.Tables[1].Rows[k]["MCB_TITLE"].ToString().TrimEnd() + ds.Tables[1].Rows[k]["MCB_NAME"].ToString().TrimEnd());
                            cusnames.Append(", ");
                        }
                        else
                        {
                            cusnames.Append(ds.Tables[1].Rows[k]["MCB_TITLE"].ToString().TrimEnd() + ds.Tables[1].Rows[k]["MCB_NAME"].ToString().TrimEnd());
                        }
                    }
                    //LEGAL EMPLOYEE  CODE , NAME DESIGNATION BRANCH

                    empname = ds.Tables[2].Rows[0]["EMP_NAME"] != DBNull.Value ? ds.Tables[2].Rows[0]["EMP_NAME"].ToString().ToUpper() : "";
                    empid = ds.Tables[2].Rows[0]["EMP_CODE"] != DBNull.Value ? ds.Tables[2].Rows[0]["EMP_CODE"].ToString().ToUpper() : "";
                    empdesgn = ds.Tables[2].Rows[0]["ET_DESC"] != DBNull.Value ? ds.Tables[2].Rows[0]["ET_DESC"].ToString().ToUpper() : "";


                    rpt = new ReportDocument();
                    //set a ReportPath and assign the dataset to reportdocument object
                    rpt.Load(Server.MapPath("Reports/PreliminaryOpinionD.rpt"));

                    SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(strcon);
                    rpt.SetDatabaseLogon(builder.UserID, builder.Password, @builder.DataSource, builder.InitialCatalog);

                    //assign the values to crystal report viewer
                    rpt.SetParameterValue(0, Session["PreviewLDNOP"].ToString());
                    rpt.SetParameterValue(1, Session["EMPNAME"].ToString().ToUpper());
                    rpt.SetParameterValue(2, Session["USR_ID"].ToString());
                    rpt.SetParameterValue(3, Session["UNITNAME"].ToString());
                    rpt.SetParameterValue(4, cusnames.ToString());
                    rpt.SetParameterValue(5, empname);
                    rpt.SetParameterValue(6, empid);
                    rpt.SetParameterValue(7, empdesgn);
                    rpt.SetParameterValue(8, qryp.ToString());
                    rpt.SetParameterValue(9, Session["PreviewLDNOP"].ToString());
                    rpt.SetParameterValue(10, Session["PreviewLDNOP"].ToString());

                    rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, true, "Preliminary Opinion Draft For " + Session["PreviewLDNOP"].ToString() + "");
                }
                else
                {

                    //uscMsgBox1.AddMessage("Preliminary opinion not done...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
            catch(Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                rpt.Close();
                rpt.Dispose();
                rpt = null;
                con.Close();
                GC.Collect();
            }
        }
        else
        {
            // Menu.SelectedItem.Text = "PROPERTY SCHDEULE DETAILS";

            if (gvschedule.Rows.Count <= 0)
            {
                ajmainview.ActiveTab = PROPSDETS;
                ajmainview.Visible = true;
                ajmainview.ActiveTabIndex = 1;

                uscMsgBox1.AddMessage("Please add the property details ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                ajmainview.ActiveTab = DOCSDEST;
                ajmainview.Visible = true;
                ajmainview.ActiveTabIndex = 1;


                uscMsgBox1.AddMessage("Please add the list of documents details ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
        }
    }
    public void Bind_Doc_Type()
    {
        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                cmd = new SqlCommand("RTS_SP_BIND_LGL_DOC_TYPE", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandTimeout = 120000;
                dtpre = new DataTable();
                dappre = new SqlDataAdapter(cmd);
                dappre.Fill(dtpre);

                ddlstdocCat.DataSource = dtpre;

                ddlstdocCat.DataTextField = "DT_DESC";
                ddlstdocCat.DataValueField = "DT_ID";
                ddlstdocCat.DataBind();
                ddlstdocCat.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlstdocCat.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                try { Response.Redirect("ErrorPage.aspx?parameter=Legal_Preliminary.aspx"); }
                catch(Exception innerEx) { ErrorLog.WriteError(innerEx); }
            }
            finally
            {
                cmd.Dispose();
            }
        }
    }
    protected void Bind_Proof(string PF_PR_ID)
    {


        using (SqlConnection connection = new SqlConnection(strcon))
        {
            connection.Open();

            try
            {
                cmd = new SqlCommand("RTS_SP_BIND_MR_PROOF", connection);

                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@TYPE", "ID");

                //cmd.Parameters.AddWithValue("@PF_PR_ID", PF_PR_ID);
                string str_pr_id = PF_PR_ID;

                if (Convert.ToDouble(Session["LGL_PRE_LNAMT"]) > 500000 && PF_PR_ID == "6")
                {
                    str_pr_id = "5";

                }
                else if (Convert.ToDouble(Session["LGL_PRE_LNAMT"]) <= 500000 && PF_PR_ID == "6")
                {
                    str_pr_id = "1";

                }
                else if (Convert.ToDouble(Session["LGL_PRE_LNAMT"]) > 500000 && PF_PR_ID == "7")
                {
                    str_pr_id = "4";
                }
                else if (Convert.ToDouble(Session["LGL_PRE_LNAMT"]) <= 500000 && PF_PR_ID == "7")
                {
                    str_pr_id = "3";
                }
                cmd.Parameters.AddWithValue("@PF_PR_ID", str_pr_id);
                cmd.CommandTimeout = 120000;

                dtpre = new DataTable();
                dappre = new SqlDataAdapter(cmd);
                dappre.Fill(dtpre);



                ddlstidtype.Items.Clear();
                ddlstidtype.DataSource = dtpre;
                ddlstidtype.DataTextField = "PF_DESC";
                ddlstidtype.DataValueField = "PF_ID";
                ddlstidtype.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlstidtype.SelectedIndex = 0;
                ddlstidtype.DataBind();
             
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmd.Dispose();
            }
        }

    }


    protected void ddlstsdf_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlstsdf.SelectedItem.Text != "--Select")
        {

            lblrelationname.Text = ddlstsdf.SelectedItem.Text.ToString();
        }
        else

        { lblrelationname.Text = "Name"; }


    }
    protected void ddlstcustype_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlstcustype.SelectedValue == "A")
        {

            if (txtbxaddr1.Text.Trim() != "")
            {
                uscMsgBox1.AddMessage("You can add only one main applicant...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
            else
            {
                this.adr1.Visible = true;
                this.adr2.Visible = true;
            }
            btnsubmit.Focus();

        }
        else
        {
            this.adr1.Visible = false;
            this.adr2.Visible = false;
        }

    }
    public void KYC_details()
    {
        try
        {


            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_KYC", con);
            cmddd.Parameters.AddWithValue("@LD_ID", Session["LEADID"].ToString().Trim());
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            lstPropOwner.DataSource = dsdd;
            lstPropOwner.DataTextField = "KYC_NAME";
            lstPropOwner.DataValueField = "KYC_ID";
            lstPropOwner.DataBind();
            lstPropOwner.Items.Insert(0, new ListItem("--Select--", "0"));
            // TBAppType.Text = "";
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void gvcbrw_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            string name = DataBinder.Eval(e.Row.DataItem, "MCB_TITLE").ToString() + DataBinder.Eval(e.Row.DataItem, "MCB_NAME").ToString();

            (e.Row.FindControl("lblcbrwname") as Label).Text = name;

            string fname = DataBinder.Eval(e.Row.DataItem, "MCB_FTITLE").ToString() + DataBinder.Eval(e.Row.DataItem, "MCB_FNAME").ToString();

            (e.Row.FindControl("lblcbrwswf") as Label).Text = fname;

            string apptype = DataBinder.Eval(e.Row.DataItem, "MCB_TYPE").ToString();
            if (apptype == "A")
            {
                (e.Row.FindControl("lblapptype") as Label).Text = "Main Applicant";
            }
            else
            {
                (e.Row.FindControl("lblapptype") as Label).Text = "Co-Applicant";
            }

        }
    }

    protected void ddlstdocCat_OnSelectedIndexChanged(object sender, EventArgs e)
    {
        ddlstdoctype.Enabled = true;
        if (Convert.ToString(Session["LeadNo"]).Contains("MSE"))
        {
            if (ddlstdocCat.SelectedValue != "3")
            {
                ddlstdoctype.SelectedIndex = 2;
                ddlstdoctype.Enabled = false;
            }
            else
            {
                ddlstdoctype.SelectedIndex = 1;
                ddlstdoctype.Enabled = false;
            }
        }
        else
        {
            ddlstdoctype.Enabled = true;
        }
    }
}

