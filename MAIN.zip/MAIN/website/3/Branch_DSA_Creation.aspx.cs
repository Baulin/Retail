﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using System.Net.Mail;
using Tracker;
using Utilities;
public partial class Branch_DSA_Creation : System.Web.UI.Page
{
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string bcc3;
    int res = 0;
    string Adt = "";
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    public static bool blMailStatus = false;
    public static DataTable dtSourceOfIncome = null;
    public static string strLanguagesIDS = "", DSA_CODE = "";
    ClsCommon clscommon = new ClsCommon();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                bindArea();
                BankList();
                bindChannels();
            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
    }

    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;


    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
        if (Session["USR_ACS"].ToString() == "5" || Session["USR_ACS"].ToString() == "4" || Session["USR_ACS"].ToString() == "3")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = true;
            ddlArea.Enabled = true;
        }
        if (Session["USR_ACS"].ToString() == "1")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();


        }
    }

    public void bindChannels()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_CHANNELS", con);
            cmddd.CommandType = CommandType.StoredProcedure;
            cmddd.Parameters.AddWithValue("@Type", 'D');  // C For Connector D For  DSA
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            con.Close();
            ddlBCSelection.DataSource = dsdd;
            ddlBCSelection.DataTextField = "CHNL_CODE";
            ddlBCSelection.DataValueField = "CHNL_ID";
            ddlBCSelection.DataBind();
            // ddlBCSelection.Items.Insert(0, new ListItem("--Select--", "0"));

            //bindBranch();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection conSub = new SqlConnection(strcon))
            {
                using (SqlCommand command = new SqlCommand("RTS_SP_DSA_APPLICATION", conSub))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    conSub.Open();
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PTYPE", "INSERT");
                    command.Parameters.AddWithValue("@DSA_BR_ID", ddlBranch.SelectedIndex != 0 ? ddlBranch.SelectedValue : "");
                    string[] AuDte = txtIDDate.Text.Split('/');
                    Adt = AuDte[2] + "-" + AuDte[1] + "-" + AuDte[0];
                    command.Parameters.AddWithValue("@DSA_DATE", Adt);
                    command.Parameters.AddWithValue("@DSA_SERVICE_TYPE", string.Empty);
                    command.Parameters.AddWithValue("@DSA_NAME", txtNameProp.Text);
                    command.Parameters.AddWithValue("@DSA_OFF_ADDR", txtOfficeAddress.Text);
                    command.Parameters.AddWithValue("@DSA_RES_ADDR", txtResiAddresss.Text);
                    command.Parameters.AddWithValue("@DSA_OFF_PH",txtOfficePh.Text);
                    command.Parameters.AddWithValue("@DSA_MOB_PH", txtMobile.Text);
                    command.Parameters.AddWithValue("@DSA_BK_ID", Convert.ToInt32(ddlBankBranch.SelectedValue));
                    command.Parameters.AddWithValue("@DSA_BK_AC_NO", txtBankACNo.Text);
                    command.Parameters.AddWithValue("@DSA_PAN_NO", txtPanNo.Text);
                    command.Parameters.AddWithValue("@DSA_TIN_NO", txtTINSerNo.Text);
                    command.Parameters.AddWithValue("@DSA_CBY", Session["EMPID"].ToString());
                    command.Parameters.AddWithValue("@DSA_ID", SqlDbType.Int).Direction = ParameterDirection.Output;
                    command.Parameters.AddWithValue("@DSA_CHNL_ID", Convert.ToInt32(ddlBCSelection.SelectedValue));
                    command.ExecuteNonQuery();
                   // conSub.Close();
                    int DSA_ID = Convert.ToInt32(command.Parameters["@DSA_ID"].Value);
                    if (DSA_ID != -1 && DSA_ID != 0)
                    {
                        //   btnPrint.Enabled = true;
                        //DSA_CODE = "DSA" + DSA_ID.ToString("00000");

                        DSA_CODE = ddlBCSelection.SelectedItem.Text + DSA_ID.ToString("00000");

                        clscommon.UpdateApplicationDSA_CODE(DSA_ID, DSA_CODE);
                        uscMsgBox1.AddMessage(DSA_CODE + " DSA User has been added successfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        clear();
                    }
                    else
                    {
                        //  btnPrint.Enabled = false;
                        uscMsgBox1.AddMessage("Submission Failed", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void clear()
    {
        try
        {
            bindArea();
            BankList();
            //ddlServiceProv.SelectedValue = "0";
            txtNameProp.Text = "";
            txtOfficeAddress.Text = "";
            txtResiAddresss.Text = "";
            txtOfficePh.Text = "";
            txtMobile.Text = "";
            ddlBank1.SelectedValue = "0";
            txtBankACNo.Text = "";
            txtPanNo.Text = "";
            txtTINSerNo.Text = "";
            ddlBankBranch.SelectedValue = "0";
            txtIFSCCode.Text = "";
            txtIDDate.Text = "";


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlBank1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet dt = new DataSet();
            dt = clscommon.BindBankDetails_ByBankCode(ddlBank1.SelectedValue);
            ddlBankBranch.DataSource = dt;
            ddlBankBranch.DataTextField = "BK_BRANCH";
            ddlBankBranch.DataValueField = "BK_ID";
            ddlBankBranch.DataBind();
            ddlBankBranch.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
       
    }
    protected void ddlBankBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            GetBankInformation();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
 
    protected void GetBankInformation()
    {
        try
        {
            DataSet dtBank = new DataSet();
            dtBank = clscommon.GetBankInformation_ByBankID(Convert.ToInt32(ddlBankBranch.SelectedValue));
            txtIFSCCode.Text = dtBank.Tables[0].Rows[0]["BK_IFSC"] != DBNull.Value ? dtBank.Tables[0].Rows[0]["BK_IFSC"].ToString() : "";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BankList()
    {

        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_NACH_BIND_BANK", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        //cmddd.Parameters.AddWithValue("@BankName", "");
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        Session["Bank"] = dsdd.Tables[0];
        con.Close();
        ddlBank1.DataSource = dsdd;
        ddlBank1.DataTextField = "BK_NAME";
        ddlBank1.DataValueField = "BK_CODE";
        ddlBank1.DataBind();
        ddlBank1.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select--", "0"));

    }
    
    
 

   
   
}