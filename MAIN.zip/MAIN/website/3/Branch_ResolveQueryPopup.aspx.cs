﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Branch_ResolveQueryPopup : System.Web.UI.Page
{
    string sa;
    string sa2;
    int ldid;
    int Appby;
    int count;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
  //  DataSet ds = new DataSet();
    DataTable dtLeadQuery = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        
        FillDatas();                
      
      
    }
    public void FillDatas()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        sa = Session["Details"].ToString();
        sa2 = Session["sa2"].ToString();
        lbLeadheader.Text = sa;
       // SqlCommand cmd1 = new SqlCommand("select ST_NAME,AR_NAME,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + sa + "'", con);
        SqlCommand cmd = new SqlCommand("RTS_SP_FETCH_LSD_QUERY_POPUP", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@LD_NO", sa);
        cmd.Parameters.AddWithValue("@QRY_RSD_BY", sa2);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds1 = new DataSet();
        da.Fill(ds1);
        //count = ds.Tables[0].Rows.Count;

        //Panel1.Visible = true;
        lbState.Text = ds1.Tables[0].Rows[0]["ST_NAME"].ToString();
        lbArea.Text = ds1.Tables[0].Rows[0]["AR_NAME"].ToString();
        lbBranch.Text = ds1.Tables[0].Rows[0]["BR_NAME"].ToString();
        lbLeadno.Text = ds1.Tables[0].Rows[0]["LD_NO"].ToString();
        lbProduct.Text = ds1.Tables[0].Rows[0]["PR_NAME"].ToString();
        lbAppname.Text = ds1.Tables[0].Rows[0]["LD_APNAME"].ToString();
        lbLoanamt.Text = ds1.Tables[0].Rows[0]["LD_PD_AMT"].ToString();

        gridbind(ds1);
        con.Close();
    }
    public void gridbind(DataSet ds)
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmd = new SqlCommand("select QRY_QUERY 'Query Raised',convert(varchar(17),QRY_DATE,106)'Date',QRY_RESPONSE 'Response',convert(varchar(17),QRY_RESP_DATE,106) 'Response Date',convert(varchar(17),QRY_RSL_DATE,106) 'Resolve Date' from LSD_QUERY A JOIN LSD_LEAD B ON A.QRY_LD_ID=B.LD_ID WHERE LD_NO='" + sa + "' AND QRY_RSD_BY='" + sa2 + "'", con);
            //SqlDataAdapter da = new SqlDataAdapter(cmd);            
            //da.Fill(ds);
            dtLeadQuery = ds.Tables[1];
            if (ds.Tables[1].Rows.Count > 0)
            {
              
                //Panel1.Visible = true;
                gvQuerypop.DataSource = ds.Tables[1];
                gvQuerypop.DataBind();
                if (ds.Tables[1].Rows.Count > 0)
                {
                    //gvQuerypop.HeaderRow.Font.Bold = true;
                    //gvQuerypop.HeaderRow.Cells[1].Text = "Query Raised";
                    //gvQuerypop.HeaderRow.Cells[2].Text = "Date";
                    //gvQuerypop.HeaderRow.Cells[3].Text = "Response";
                    //gvQuerypop.HeaderRow.Cells[4].Text = "Response Date";
                    //gvQuerypop.HeaderRow.Cells[5].Text = "Resolve Date";
                   
                    //gvQuerypop.HeaderRow.Cells[1].Wrap = false;
                    //gvQuerypop.HeaderRow.Cells[2].Wrap = false;
                    //gvQuerypop.HeaderRow.Cells[3].Wrap = false;
                    //gvQuerypop.HeaderRow.Cells[4].Wrap = false;
                    //gvQuerypop.HeaderRow.Cells[5].Wrap = false;
                    
                }
            }
            else
            {
                uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }

        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (dtLeadQuery.Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Right;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    }
