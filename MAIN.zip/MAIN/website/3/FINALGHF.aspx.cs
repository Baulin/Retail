﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Xml;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;
using Tracker;


public partial class FINALGHF : System.Web.UI.Page
{
    public static DataTable dtSourceOfIncome = null;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    ClsCommon clscommon = new ClsCommon();
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    int cmrs;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {

            txtPDDate.Attributes.Add("readonly", "readonly");
            if (!IsPostBack)
            {
                // double dt = GetEMI(0.0, 0.0, 0.0);

                clear();

                txtBranchName.Text = Session["UNITNAME"].ToString();
                BindDropdownList();
                FirstGridViewRow();
                ddlTenure.SelectedValue = "7";
                hdnltv.Value = "0";
            }
        }
        else
        {
            Response.Redirect("Expire.aspx");
        }
    }
    protected void BindDropdownList()
    {
        BindLeadNo();
        BindFinalArea();
        BindRelationship();
        Bind_Loan_Process();
        BindIncomeSource();
        //BindVintage();
        BindLoanPurpose();
        BindCreditHistory();
        BindCustRelation();
        BindProperty();
        //BindOccupancy();
        //BindUsage();
        //BindBDAge();
        BindCategory();
        BindConstrStage();
        BindConstrType();
        BindTenor();
        BindConstrFloor();
        BindIntrest();
        BindLoanTYpe();
        BindLoanSource();
        // BindLawyerName();
    }

    // __________BIND DROP DOWN LIST START_____________//
    public void BindFinalArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_FINAL_CAM_Area", con);
        cmddd.Parameters.AddWithValue("@AreaID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue : "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindFinalBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_FINAL_CAM_Branch", con);
        cmddd.Parameters.AddWithValue("@AreaID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue : "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlBranch.DataSource = dsdd;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindLeadNo()
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_FINAL_CAM_Lead", con);
        cmddd.Parameters.AddWithValue("@LD_NO", "");
        cmddd.Parameters.AddWithValue("@Lead_Type", "GHF");
        cmddd.Parameters.AddWithValue("@BranchID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue : "");
        cmddd.Parameters.AddWithValue("@AreaID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue : "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLeadNo.DataSource = dsdd;
        ddlLeadNo.DataTextField = "LD_NO";
        ddlLeadNo.DataValueField = "LD_ID";
        ddlLeadNo.DataBind();
        ddlLeadNo.Items.Insert(0, new ListItem("--Select--", "0"));


    }
    public void BindLoanTYpe()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_PR_FETCH_LOAN_TYPE", con);
        //cmddd.Parameters.AddWithValue("@LD_NO", "");
        //cmddd.Parameters.AddWithValue("@Lead_Type", "GLP");
        //cmddd.Parameters.AddWithValue("@BranchName", txtBranchName.Text);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLoanType1.DataSource = dsdd;
        ddlLoanType1.DataTextField = "LT_DESC";
        ddlLoanType1.DataValueField = "LT_ID";
        ddlLoanType1.DataBind();
        ddlLoanType1.Items.Insert(0, new ListItem("--Select--", ""));

        ddlLoanType2.DataSource = dsdd;
        ddlLoanType2.DataTextField = "LT_DESC";
        ddlLoanType2.DataValueField = "LT_ID";
        ddlLoanType2.DataBind();
        ddlLoanType2.Items.Insert(0, new ListItem("--Select--", ""));


        ddlLoanType3.DataSource = dsdd;
        ddlLoanType3.DataTextField = "LT_DESC";
        ddlLoanType3.DataValueField = "LT_ID";
        ddlLoanType3.DataBind();
        ddlLoanType3.Items.Insert(0, new ListItem("--Select--", ""));


        ddlLoanType4.DataSource = dsdd;
        ddlLoanType4.DataTextField = "LT_DESC";
        ddlLoanType4.DataValueField = "LT_ID";
        ddlLoanType4.DataBind();
        ddlLoanType4.Items.Insert(0, new ListItem("--Select--", ""));


        ddlLoanType5.DataSource = dsdd;
        ddlLoanType5.DataTextField = "LT_DESC";
        ddlLoanType5.DataValueField = "LT_ID";
        ddlLoanType5.DataBind();
        ddlLoanType5.Items.Insert(0, new ListItem("--Select--", ""));
    }

    public void BindLoanSource()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_PR_FETCH_LOAN_SOURCE", con);
        //cmddd.Parameters.AddWithValue("@LD_NO", "");
        //cmddd.Parameters.AddWithValue("@Lead_Type", "GLP");
        //cmddd.Parameters.AddWithValue("@BranchName", txtBranchName.Text);
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlSource1.DataSource = dsdd;
        ddlSource1.DataTextField = "MLS_DESC";
        ddlSource1.DataValueField = "MLS_ID";
        ddlSource1.DataBind();
        ddlSource1.Items.Insert(0, new ListItem("--Select--", ""));

        ddlSource2.DataSource = dsdd;
        ddlSource2.DataTextField = "MLS_DESC";
        ddlSource2.DataValueField = "MLS_ID";
        ddlSource2.DataBind();
        ddlSource2.Items.Insert(0, new ListItem("--Select--", ""));


        ddlSource3.DataSource = dsdd;
        ddlSource3.DataTextField = "MLS_DESC";
        ddlSource3.DataValueField = "MLS_ID";
        ddlSource3.DataBind();
        ddlSource3.Items.Insert(0, new ListItem("--Select--", ""));


        ddlSource4.DataSource = dsdd;
        ddlSource4.DataTextField = "MLS_DESC";
        ddlSource4.DataValueField = "MLS_ID";
        ddlSource4.DataBind();
        ddlSource4.Items.Insert(0, new ListItem("--Select--", ""));

        ddlSource5.DataSource = dsdd;
        ddlSource5.DataTextField = "MLS_DESC";
        ddlSource5.DataValueField = "MLS_ID";
        ddlSource5.DataBind();
        ddlSource5.Items.Insert(0, new ListItem("--Select--", ""));
    }
    public void BindRelationship()
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Relation", con);
        cmddd.Parameters.AddWithValue("@ER_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlRelationShip.DataSource = dsdd;
        ddlRelationShip.DataTextField = "ER_DESC";
        ddlRelationShip.DataValueField = "ER_ID";
        ddlRelationShip.DataBind();
        ddlRelationShip.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindIncomeSource()
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_IN_SOURCE", con);
        cmddd.Parameters.AddWithValue("@INS_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlMainApplicant.DataSource = dsdd;
        ddlMainApplicant.DataTextField = "INS_DESC";
        ddlMainApplicant.DataValueField = "INS_ID";
        ddlMainApplicant.DataBind();
        ddlMainApplicant.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindVintage()
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);
        cmddd.Parameters.AddWithValue("@VN_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlVintage.DataSource = dsdd;
        ddlVintage.DataTextField = "VN_DESC";
        ddlVintage.DataValueField = "VN_ID";
        ddlVintage.DataBind();
        ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void Bind_Loan_Process()
    {
        try
        {
            con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_LOAN_PROCESS", con);
            cmddd.Parameters.AddWithValue("@LT_ID", "");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlLoanProType.DataSource = dsdd;
            ddlLoanProType.DataTextField = "LT_NAME";
            ddlLoanProType.DataValueField = "LT_ID";
            ddlLoanProType.DataBind();
            ddlLoanProType.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindLoanPurpose()
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PURPOSE", con);
        cmddd.Parameters.AddWithValue("@PP_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLoanPurpose.DataSource = dsdd;
        ddlLoanPurpose.DataTextField = "PP_DESC";
        ddlLoanPurpose.DataValueField = "PP_ID";
        ddlLoanPurpose.DataBind();
        ddlLoanPurpose.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindCreditHistory()
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CR_HISTORY", con);
        cmddd.Parameters.AddWithValue("@CH_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlCreditHistory.DataSource = dsdd;
        ddlCreditHistory.DataTextField = "CH_DESC";
        ddlCreditHistory.DataValueField = "CH_ID";
        ddlCreditHistory.DataBind();
        ddlCreditHistory.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindCustRelation()
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_RELATION", con);
        cmddd.Parameters.AddWithValue("@RL_ID", "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlCustRelation.DataSource = dsdd;
        ddlCustRelation.DataTextField = "RL_DESC";
        ddlCustRelation.DataValueField = "Rl_ID";
        ddlCustRelation.DataBind();
        ddlCustRelation.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void BindProperty()
    {
        try
        {
            con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY_GHF", con);
            cmddd.Parameters.AddWithValue("@PT_ID", "");
            cmddd.Parameters.AddWithValue("@PT_LT_ID", ddlLoanProType.SelectedItem.Text != "--Select--" ? ddlLoanProType.SelectedValue : "");
            if (ddlLeadNo.SelectedItem.Text.Contains("EHF"))
            {
                cmddd.Parameters.AddWithValue("@PT_TYPE", "E");
            }
            else
            {
                cmddd.Parameters.AddWithValue("@PT_TYPE", "G");
                cmddd.Parameters.AddWithValue("@PRODUCT", "G-HF");
            }
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlPropType.DataSource = dsdd;
            ddlPropType.DataTextField = "PT_DESC";
            ddlPropType.DataValueField = "PT_ID";
            //ddlPropType.DataValueField = "PT_RSQRT";
            ddlPropType.DataBind();
            ddlPropType.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    //public void BindOccupancy()
    //{
    //    con = new SqlConnection(strcon);
    //    con.Open();
    //    SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_OCCUPANCY", con);
    //    cmddd.Parameters.AddWithValue("@OC_ID", "");
    //    cmddd.CommandType = CommandType.StoredProcedure;
    //    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //    DataSet dsdd = new DataSet();
    //    dadd.Fill(dsdd);

    //    con.Close();
    //    ddlOccupancyStatus.DataSource = dsdd;
    //    ddlOccupancyStatus.DataTextField = "OC_DESC";
    //    ddlOccupancyStatus.DataValueField = "OC_ID";
    //    ddlOccupancyStatus.DataBind();
    //    ddlOccupancyStatus.Items.Insert(0, new ListItem("--Select--", "0"));
    //}
    //public void BindUsage()
    //{
    //    con = new SqlConnection(strcon);
    //    con.Open();
    //    SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_USAGE", con);
    //    cmddd.Parameters.AddWithValue("@UG_ID", "");
    //    cmddd.CommandType = CommandType.StoredProcedure;
    //    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //    DataSet dsdd = new DataSet();
    //    dadd.Fill(dsdd);

    //    con.Close();
    //    ddlUsage.DataSource = dsdd;
    //    ddlUsage.DataTextField = "UG_DESC";
    //    ddlUsage.DataValueField = "UG_ID";
    //    ddlUsage.DataBind();
    //    ddlUsage.Items.Insert(0, new ListItem("--Select--", "0"));
    //}
    //public void BindBDAge()
    //{
    //    con = new SqlConnection(strcon);
    //    con.Open();
    //    SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_BD_AGE", con);
    //    cmddd.Parameters.AddWithValue("@BA_ID", "");
    //    cmddd.CommandType = CommandType.StoredProcedure;
    //    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //    DataSet dsdd = new DataSet();
    //    dadd.Fill(dsdd);

    //    con.Close();
    //    ddlAgeOfBuilding.DataSource = dsdd;
    //    ddlAgeOfBuilding.DataTextField = "BA_DESC";
    //    ddlAgeOfBuilding.DataValueField = "BA_DEPR";
    //    ddlAgeOfBuilding.DataBind();
    //    ddlAgeOfBuilding.Items.Insert(0, new ListItem("--Select--", "0"));
    //}
    public void BindCategory()
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
        cmddd.Parameters.AddWithValue("@CT_ID", "");
        cmddd.Parameters.AddWithValue("@CT_TYPE", "G");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlCustSource.DataSource = dsdd;
        ddlCustSource.DataTextField = "CT_DESC";
        ddlCustSource.DataValueField = "CT_DESC";
        ddlCustSource.DataBind();
        ddlCustSource.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void BindConstrStage()
    {
        try
        {
            con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CON_STAGE_GHF", con);
            cmddd.Parameters.AddWithValue("@CS_ID", "");
            cmddd.Parameters.AddWithValue("@CS_LP_ID", ddlLoanProType.SelectedItem.Text != "--Select--" ? ddlLoanProType.SelectedValue : "");
            /*  if (ddlLeadNo.SelectedItem.Text.Contains("EHF") && ddlPropType.SelectedItem.Text.Contains("Vacant"))
              {
                  cmddd.Parameters.AddWithValue("@CS_TYPE", "V");
              }
              else if (ddlLeadNo.SelectedItem.Text.Contains("EHF") && ddlPropType.SelectedItem.Text.Contains("Vacant") == false)
              {
                  cmddd.Parameters.AddWithValue("@CS_TYPE", "N");
              }
              else
              {
                  cmddd.Parameters.AddWithValue("@CS_TYPE", "N");
              }*/
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlConstructionStage.DataSource = dsdd;
            ddlConstructionStage.DataTextField = "CS_DESC";
            ddlConstructionStage.DataValueField = "CS_ID";
            ddlConstructionStage.DataBind();
            ddlConstructionStage.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindConstrType()
    {
        try
        {


            con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CON_TYPE_GHF", con);
            cmddd.Parameters.AddWithValue("@CE_ID", "");
            cmddd.Parameters.AddWithValue("@CE_LP_ID", ddlLoanProType.SelectedItem.Text != "--Select--" ? ddlLoanProType.SelectedValue : "");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlConstrType.DataSource = dsdd;
            ddlConstrType.DataTextField = "CE_DESC";
            ddlConstrType.DataValueField = "CE_ID";
            ddlConstrType.DataBind();
            ddlConstrType.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindConstrFloor()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_BIND_MR_FLOOR_GHF", con);
            cmddd.Parameters.AddWithValue("@CF_LP_ID", ddlLoanProType.SelectedItem.Text != "--Select--" ? ddlLoanProType.SelectedValue : "");
            //cmddd.Parameters.AddWithValue("@CE_ID", "");
            //cmddd.Parameters.AddWithValue("@CE_TYPE", ddl_scheme.SelectedValue);
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            ViewState["ConFloor"] = dsdd.Tables[0];
            con.Close();
            ddlConstFloor.DataSource = dsdd;
            ddlConstFloor.DataTextField = "CF_DESC";
            //dlConstrType.DataValueField = "CE_RATE";
            ddlConstFloor.DataValueField = "CF_ID";
            ddlConstFloor.DataBind();
            ddlConstFloor.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindTenor()
    {
        string strFileName = "GHFTenure.xml";
        if (ddlLeadNo.SelectedItem.Text.Contains("EHF"))
        {
            strFileName = "EMPTenor.xml";
        }
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("XML/" + strFileName + ""));

        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();

        if (ds.Tables.Count != 0)
        {
            ddlTenure.DataSource = ds;

            ddlTenure.DataTextField = "Tenor";

            ddlTenure.DataValueField = "Tenor";

            ddlTenure.DataBind();
        }
    }
    public void BindIntrest()
    {
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("XML/GHFInterestRate.xml"));

        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();

        if (ds.Tables.Count != 0)
        {
            ddlIntrest.DataSource = ds;

            ddlIntrest.DataTextField = "Interest";

            ddlIntrest.DataValueField = "Interest";

            ddlIntrest.DataBind();

            ddlIntrest.Items.Insert(0, new ListItem("--Select--", "0"));
        }
    }
    public DataSet fetchLeadDetails(string strLeadNo)
    {
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Lead_Details", con);
        cmddd.Parameters.AddWithValue("@LD_NO", strLeadNo);
        cmddd.Parameters.AddWithValue("@Lead_Type", "GHF");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        return dsdd;
    }
    // __________BIND DROP DOWN LIST END_____________//


    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            btnSubmit.Enabled = false;
            if (DDLkycName.SelectedIndex != 0 && ddlCustSource.SelectedItem.Text != "--Select--" && txtCustAge.Text != "" && ddlCustRelation.SelectedItem.Text != "--Select--"
                                   && txtIncome.Text != "")
            {
                AddNewRow();
            }
            else
            {
                if (DDLkycName.SelectedIndex == 0)
                {
                    DDLkycName.Focus();

                }
                else if (ddlCustSource.SelectedItem.Text == "--Select--")
                {
                    ddlCustSource.Focus();
                }
                else if (txtCustAge.Text == "")
                {
                    txtCustAge.Focus();

                }
                else if (ddlCustRelation.SelectedItem.Text == "--Select--")
                {
                    ddlCustSource.Focus();
                }
                else if (txtIncome.Text == "")
                {
                    txtCustAge.Focus();

                }
                uscMsgBox1.AddMessage("Please Give corresponding Inputs for Income details", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    private void FirstGridViewRow()
    {


        DataTable dt = new DataTable();
        DataRow dr = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("NAME", typeof(string)));
        dt.Columns.Add(new DataColumn("APP_TYPE", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_SOURCE", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_SOURCEID", typeof(string)));
        dt.Columns.Add(new DataColumn("AGE", typeof(string)));
        dt.Columns.Add(new DataColumn("RELATIONSHIP", typeof(string)));
        dt.Columns.Add(new DataColumn("RELATIONSHIPID", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME", typeof(string)));
        dt.Columns.Add(new DataColumn("INCOME_TAKEN", typeof(string)));
        dt.Columns.Add(new DataColumn("FACTORED_INCOME", typeof(string)));

        dr = dt.NewRow();
        //dr["RowNumber"] = 1;

        dr["NAME"] = string.Empty;
        dr["APP_TYPE"] = string.Empty;
        dr["INCOME_SOURCE"] = string.Empty;
        dr["INCOME_SOURCEID"] = string.Empty;
        dr["AGE"] = string.Empty;
        dr["RELATIONSHIP"] = string.Empty;
        dr["RELATIONSHIPID"] = string.Empty;
        dr["INCOME"] = string.Empty;
        dr["INCOME_TAKEN"] = string.Empty;
        dr["FACTORED_INCOME"] = string.Empty;
        dt.Rows.Add(dr);

        ViewState["CurrentTable"] = dt;

        gvIncomeDetail.DataSource = dt;
        gvIncomeDetail.DataBind();


    }
    private void AddNewRow()
    {
        try
        {
            int rowIndex = 0;

            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                DataRow drCurrentRow = null;



                if (dtCurrentTable.Rows.Count > 0 && dtCurrentTable.Rows[0][0].ToString() == "")
                {
                    dtCurrentTable.Rows.RemoveAt(0);
                }
                drCurrentRow = dtCurrentTable.NewRow();
                drCurrentRow["NAME"] = DDLkycName.SelectedItem.Text;
                drCurrentRow["APP_TYPE"] = TBAppType.Text;
                drCurrentRow["INCOME_SOURCE"] = ddlCustSource.SelectedItem.Text != "--Select--" ? ddlCustSource.SelectedItem.Text : "";
                int INCOME_SOURCEID = FetchINCOME_SOURCEID(ddlCustSource.SelectedItem.Text);
                drCurrentRow["INCOME_SOURCEID"] = INCOME_SOURCEID;
                drCurrentRow["AGE"] = txtCustAge.Text;
                drCurrentRow["RELATIONSHIP"] = ddlCustRelation.SelectedItem.Text != "--Select--" ? ddlCustRelation.SelectedItem.Text : "";
                drCurrentRow["RELATIONSHIPID"] = ddlCustRelation.SelectedItem.Text != "--Select--" ? ddlCustRelation.SelectedValue.ToString() : "";
                drCurrentRow["INCOME"] = txtIncome.Text;
                drCurrentRow["INCOME_TAKEN"] = txtIncomeTaken.Text;
                drCurrentRow["FACTORED_INCOME"] = Convert.ToString(Convert.ToDouble(txtIncome.Text) * (Convert.ToDouble(txtIncomeTaken.Text) / 100));
                string strFactorIncome = drCurrentRow["FACTORED_INCOME"].ToString();
                //  rowIndex++;
                // }
                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["CurrentTable"] = dtCurrentTable;

                gvIncomeDetail.DataSource = dtCurrentTable;
                gvIncomeDetail.DataBind();




                Clear();





                if (dtCurrentTable != null && dtCurrentTable.Rows.Count > 0)
                {
                    BindCreditSheild(dtCurrentTable);
                    double nTotalLoanEligibility = 0.0;
                    txtbxotherincome.Text = "";
                    txtbxsumofrental.Text = "";
                    txtPensionIncome.Text = "";
                    for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                    {
                        double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                        string strIncomeSource = dtCurrentTable.Rows[n]["INCOME_SOURCE"] != DBNull.Value ? dtCurrentTable.Rows[n]["INCOME_SOURCE"].ToString() : "";
                        nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;

                        if (strIncomeSource.Contains("RENT"))
                        {
                            if (txtbxsumofrental.Text == "")
                            {
                                txtbxsumofrental.Text = Convert.ToDouble(nTempVal).ToString();
                            }
                            else
                            {

                                txtbxsumofrental.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxsumofrental.Text)).ToString();
                            }
                        }
                        else if (strIncomeSource.Contains("PENSION"))
                        {
                            if (txtPensionIncome.Text == "")
                            {
                                txtPensionIncome.Text = Convert.ToDouble(nTempVal).ToString();
                            }
                            else
                            {

                                txtPensionIncome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtPensionIncome.Text)).ToString();
                            }
                        }
                        else
                        {
                            if (txtbxotherincome.Text == "")
                            {
                                txtbxotherincome.Text = Convert.ToDouble(nTempVal).ToString();
                            }
                            else
                            {

                                txtbxotherincome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxotherincome.Text)).ToString();
                            }
                        }
                        double rent = 0.0;
                        double Pension = 0.0;
                        double other = 0.0;

                        if (txtbxsumofrental.Text != "")
                        {
                            rent = Convert.ToDouble(txtbxsumofrental.Text);
                        }
                        if (txtPensionIncome.Text != "")
                        {
                            Pension = Convert.ToDouble(txtPensionIncome.Text);
                        }
                        if (txtbxotherincome.Text != "")
                        {
                            other = Convert.ToDouble(txtbxotherincome.Text);
                        }

                        if (strIncomeSource.Contains("PENSION") && txtbxsumofrental.Text == "")
                        {
                            txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, other) + other);
                        }
                        else if (strIncomeSource.Contains("PENSION") && txtbxsumofrental.Text != "")
                        {
                            txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, Convert.ToDouble(txtTotalLoanEligibility.Text)) + Convert.ToDouble(txtTotalLoanEligibility.Text));
                        }
                        else if (strIncomeSource.Contains("RENT") && txtPensionIncome.Text == "")
                        {
                            txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(rent, other) + other);
                        }
                        else if (strIncomeSource.Contains("RENT") && txtPensionIncome.Text != "")
                        {
                            txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(rent, Convert.ToDouble(txtTotalLoanEligibility.Text)) + Convert.ToDouble(txtTotalLoanEligibility.Text));
                        }

                        else
                        {
                            if (txtPensionIncome.Text == "" && txtbxsumofrental.Text != "")
                            {
                                txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(rent, other) + other);
                            }
                            else if (txtPensionIncome.Text != "" && txtbxsumofrental.Text == "")
                            {
                                txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, other) + other);
                            }
                            else
                            {
                                txtTotalLoanEligibility.Text = Convert.ToString(other);
                            }

                        }
                    }

                    string rentalincome = txtbxsumofrental.Text == "" ? "0" : txtbxsumofrental.Text;
                    txtrentalloaneligibilityincome.Text = Convert.ToString(Math.Min(Convert.ToDecimal(rentalincome), Convert.ToDecimal(txtbxotherincome.Text)));
                    BindBorrower(dtCurrentTable);
                }
                //  }
            }
            else
            {
                Response.Write("ViewState is null");
            }
            //  SetPreviousData();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindCreditSheild(DataTable dtCreditSheild)
    {
        try
        {
            var result = from tab in dtCreditSheild.AsEnumerable()
                         where tab.Field<int>("AGE") <= 60
                         group tab by tab["NAME"]
                             into groupDt
                             select new
                             {
                                 Group = groupDt.Key,
                                 Sum = groupDt.Sum((r) => decimal.Parse(r["FACTORED_INCOME"].ToString()))
                             };


            DataTable dt = new DataTable();

            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Amount", typeof(int));

            foreach (var item in result)
            {
                DataRow dr = dt.NewRow();
                dr["Name"] = item.Group;
                dr["Amount"] = Convert.ToInt32(item.Sum);
                dt.Rows.Add(dr);
            }


            DataRow[] drTemp = dt.Select("Amount=  max(Amount)");
            if (drTemp.Length > 0)
            {
                txtNameofInsuredPerson.Text = drTemp[0].ItemArray[0].ToString();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindBorrower(DataTable dt)
    {
        /// NAME
        /// 
        string strBrwname1 = "", strBrwname2 = "", strBrwname3 = "", strBrwname4 = "", strBrwname5 = "";

        if (drpName1.Items.Count > 0)
        {
            strBrwname1 = drpName1.SelectedValue;
        }
        if (drpName2.Items.Count > 0)
        {
            strBrwname2 = drpName2.SelectedValue;
        }
        if (drpName3.Items.Count > 0)
        {
            strBrwname3 = drpName3.SelectedValue;
        }
        if (drpName4.Items.Count > 0)
        {
            strBrwname4 = drpName4.SelectedValue;
        }
        if (drpName5.Items.Count > 0)
        {
            strBrwname5 = drpName5.SelectedValue;
        }

        drpName1.Items.Clear();
        drpName2.Items.Clear();
        drpName3.Items.Clear();
        drpName4.Items.Clear();
        drpName5.Items.Clear();
        DataTable temNameDB = new DataTable();
        temNameDB = dt.Copy();
        for (int n = 1; n <= 9; n++)
        {
            temNameDB.Columns.RemoveAt(1);

        }

        temNameDB = temNameDB.DefaultView.ToTable(true);
        drpName1.DataSource = temNameDB;
        drpName2.DataSource = temNameDB;
        drpName3.DataSource = temNameDB;
        drpName4.DataSource = temNameDB;
        drpName5.DataSource = temNameDB;

        drpName1.DataTextField = "NAME";
        drpName1.DataValueField = "NAME";

        drpName2.DataTextField = "NAME";
        drpName2.DataValueField = "NAME";

        drpName3.DataTextField = "NAME";
        drpName3.DataValueField = "NAME";

        drpName4.DataTextField = "NAME";
        drpName4.DataValueField = "NAME";

        drpName5.DataTextField = "NAME";
        drpName5.DataValueField = "NAME";

        drpName1.DataBind();
        drpName2.DataBind();
        drpName3.DataBind();
        drpName4.DataBind();
        drpName5.DataBind();

        drpName1.Items.Insert(0, "--Select--");
        drpName2.Items.Insert(0, "--Select--");
        drpName3.Items.Insert(0, "--Select--");
        drpName4.Items.Insert(0, "--Select--");
        drpName5.Items.Insert(0, "--Select--");

        if (strBrwname1 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname1 + "'");
            if (dr.Length > 0)
            {
                drpName1.SelectedValue = strBrwname1;
            }
            else
            {
                txtFinanciear1.Text = "";
                txtEMIAmount1.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }

        }
        if (strBrwname2 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname2 + "'");
            if (dr.Length > 0)
            {
                drpName2.SelectedValue = strBrwname2;
            }
            else
            {
                txtFinanciear2.Text = "";
                txtEMIAmount2.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname3 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname3 + "'");
            if (dr.Length > 0)
            {

                drpName3.SelectedValue = strBrwname3;
            }
            else
            {
                txtFinanciear3.Text = "";
                txtEMIAmount3.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname4 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname4 + "'");
            if (dr.Length > 0)
            {
                drpName4.SelectedValue = strBrwname4;
            }
            else
            {
                txtFinanciear4.Text = "";
                txtEMIAmount4.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }
        if (strBrwname5 != "")
        {
            DataRow[] dr = dt.Select("NAME = '" + strBrwname5 + "'");
            if (dr.Length > 0)
            {
                drpName5.SelectedValue = strBrwname5;
            }
            else
            {
                txtFinanciear5.Text = "";
                txtEMIAmount5.Text = "";
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>GetTotalObligation();</script>", false);
            }
        }

    }
    public int FetchINCOME_SOURCEID(string strDesc)
    {
        int INCOME_SOURCEID = 0;
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("Select CT_ID from MR_CATEGORY where CT_PR_TYPE='G' AND CT_DESC='" + strDesc + "'", con);

        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        INCOME_SOURCEID = Convert.ToInt32(dsdd.Tables[0].Rows[0][0]);
        con.Close();
        return INCOME_SOURCEID;
    }
    public void Clear()
    {
        DDLkycName.SelectedIndex = 0;
        ddlCustSource.SelectedIndex = 0;
        txtCustAge.Text = "";
        ddlCustRelation.SelectedIndex = 0;
        txtIncome.Text = "";
        txtIncomeTaken.Text = "";
        txtFactor.Text = "";
    }
    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    TextBox txtCustName =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[1].FindControl("txtCustName");
                    DropDownList ddlCustSource =
                     (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[2].FindControl("ddlCustSource");
                    TextBox txtCustAge =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[3].FindControl("txtCustAge");
                    DropDownList ddlCustRelation =
                       (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[4].FindControl("ddlCustRelation");
                    TextBox txtIncome =
                      (TextBox)gvIncomeDetail.Rows[rowIndex].Cells[5].FindControl("txtIncome");
                    DropDownList ddlIncomeTaken =
                      (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[6].FindControl("ddlIncomeTaken");
                    DropDownList ddlFactor =
                     (DropDownList)gvIncomeDetail.Rows[rowIndex].Cells[7].FindControl("ddlFactor");

                    txtCustName.Text = dt.Rows[i]["Col1"].ToString();
                    ddlCustSource.SelectedItem.Text = dt.Rows[i]["Col2"].ToString();
                    txtCustAge.Text = dt.Rows[i]["Col3"].ToString();
                    ddlCustRelation.SelectedItem.Text = dt.Rows[i]["Col4"].ToString();
                    txtIncome.Text = dt.Rows[i]["Col5"].ToString();
                    ddlIncomeTaken.SelectedItem.Text = dt.Rows[i]["Col6"].ToString();
                    ddlFactor.SelectedItem.Text = dt.Rows[i]["Col7"].ToString();
                    rowIndex++;
                }
            }
        }
    }


    protected void gvIncomeDetail_RowCommand1(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            //DataTable dtTempTable=null;
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];

                if (e.CommandName == "Delete")
                {
                    btnSubmit.Enabled = false;
                    txtPensionIncome.Text = "";
                    txtbxotherincome.Text = "";
                    txtbxsumofrental.Text = "";
                    string[] strVal = e.CommandArgument.ToString().Split('|');

                    DataRow[] dr = dtCurrentTable.Select("NAME = '" + strVal[0].ToString() + "' AND INCOME_SOURCEID = '" + strVal[1].ToString() + "'");
                    if (dr.Length > 0)
                    {

                        // dtCurrentTable = dr.CopyToDataTable();
                        DataTable dtTempTable = dr.CopyToDataTable();
                        for (int i = 0; i < dtCurrentTable.Rows.Count; i++)
                        {

                            if (dtCurrentTable.Rows[i]["NAME"].ToString() == dtTempTable.Rows[0]["NAME"].ToString() && dtCurrentTable.Rows[i]["INCOME_SOURCEID"].ToString() == dtTempTable.Rows[0]["INCOME_SOURCEID"].ToString())
                            {
                                dtCurrentTable.Rows.RemoveAt(i);
                            }
                        }
                        dtCurrentTable.AcceptChanges();



                        ViewState["CurrentTable"] = dtCurrentTable;
                        gvIncomeDetail.DataSource = dtCurrentTable;
                        gvIncomeDetail.DataBind();

                        if (dtCurrentTable != null && dtCurrentTable.Rows.Count > 0)
                        {
                            double nTotalLoanEligibility = 0.0;
                            txtbxotherincome.Text = "";
                            txtbxsumofrental.Text = "";

                            for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                            {
                                double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                                string strIncomeSource = dtCurrentTable.Rows[n]["INCOME_SOURCE"] != DBNull.Value ? dtCurrentTable.Rows[n]["INCOME_SOURCE"].ToString() : "";
                                string strName = dtCurrentTable.Rows[n]["NAME"] != DBNull.Value ? dtCurrentTable.Rows[n]["NAME"].ToString() : "";
                                int nAge = dtCurrentTable.Rows[n]["AGE"] != DBNull.Value ? Convert.ToInt32(dtCurrentTable.Rows[n]["AGE"]) : 0;
                                nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;
                                BindCreditSheild(dtCurrentTable);
                                if (strIncomeSource.Contains("RENT"))
                                {
                                    if (txtbxsumofrental.Text == "")
                                    {
                                        txtbxsumofrental.Text = Convert.ToDouble(nTempVal).ToString();
                                    }
                                    else
                                    {

                                        txtbxsumofrental.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxsumofrental.Text)).ToString();
                                    }
                                }
                                else if (strIncomeSource.Contains("PENSION"))
                                {
                                    if (txtPensionIncome.Text == "")
                                    {
                                        txtPensionIncome.Text = Convert.ToDouble(nTempVal).ToString();
                                    }
                                    else
                                    {

                                        txtPensionIncome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtPensionIncome.Text)).ToString();
                                    }
                                }
                                else
                                {
                                    if (txtbxotherincome.Text == "")
                                    {
                                        txtbxotherincome.Text = Convert.ToDouble(nTempVal).ToString();
                                    }
                                    else
                                    {

                                        txtbxotherincome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxotherincome.Text)).ToString();
                                    }
                                }
                                double rent = 0.0;
                                double Pension = 0.0;
                                double other = 0.0;

                                if (txtbxsumofrental.Text != "")
                                {
                                    rent = Convert.ToDouble(txtbxsumofrental.Text);
                                }
                                if (txtPensionIncome.Text != "")
                                {
                                    Pension = Convert.ToDouble(txtPensionIncome.Text);
                                }
                                if (txtbxotherincome.Text != "")
                                {
                                    other = Convert.ToDouble(txtbxotherincome.Text);
                                }

                                if (strIncomeSource.Contains("PENSION") && txtbxsumofrental.Text == "")
                                {
                                    txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, other) + other);
                                }
                                else if (strIncomeSource.Contains("PENSION") && txtbxsumofrental.Text != "")
                                {
                                    txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, Convert.ToDouble(txtTotalLoanEligibility.Text)) + Convert.ToDouble(txtTotalLoanEligibility.Text));
                                }
                                else if (strIncomeSource.Contains("RENT") && txtPensionIncome.Text == "")
                                {
                                    txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(rent, other) + other);
                                }
                                else if (strIncomeSource.Contains("RENT") && txtPensionIncome.Text != "")
                                {
                                    txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, Convert.ToDouble(txtTotalLoanEligibility.Text)) + Convert.ToDouble(txtTotalLoanEligibility.Text));
                                }

                                else
                                {
                                    if (txtPensionIncome.Text == "" && txtbxsumofrental.Text != "")
                                    {
                                        txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(rent, other) + other);
                                    }
                                    else if (txtPensionIncome.Text != "" && txtbxsumofrental.Text == "")
                                    {
                                        txtTotalLoanEligibility.Text = Convert.ToString(Math.Min(Pension, other) + other);
                                    }
                                    else
                                    {
                                        txtTotalLoanEligibility.Text = Convert.ToString(other);
                                    }

                                }
                            }

                            string rentalincome = txtbxsumofrental.Text == "" ? "0" : txtbxsumofrental.Text;
                            txtrentalloaneligibilityincome.Text = Convert.ToString(Math.Min(Convert.ToDecimal(rentalincome), Convert.ToDecimal(txtbxotherincome.Text)));
                            BindBorrower(dtCurrentTable);
                        }

                    }
                    else
                    {
                        FirstGridViewRow();
                        txtbxotherincome.Text = "";
                        txtbxsumofrental.Text = "";
                        txtTotalLoanEligibility.Text = "";
                        drpName1.Items.Clear();
                        drpName2.Items.Clear();
                        drpName3.Items.Clear();
                        drpName4.Items.Clear();
                        drpName5.Items.Clear();
                        txtFinanciear1.Text = "";
                        txtFinanciear2.Text = "";
                        txtFinanciear3.Text = "";
                        txtFinanciear4.Text = "";
                        txtFinanciear5.Text = "";

                        txtEMIAmount1.Text = "";
                        txtEMIAmount2.Text = "";
                        txtEMIAmount3.Text = "";
                        txtEMIAmount4.Text = "";
                        txtEMIAmount5.Text = "";
                        txtTotalEMIAmount.Text = "";

                    }

                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }


    protected void gvIncomeDetail_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void gvIncomeDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void ddlLeadNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlLeadNo.SelectedIndex > 0)
            {
                if (ddlLeadNo.SelectedItem.Text.Contains("EHF"))
                {
                    trEmp1.Visible = true;
                    trEmp2.Visible = true;
                    trEmp3.Visible = true;
                }
                else
                {
                    trEmp1.Visible = false;
                    trEmp2.Visible = false;
                    trEmp3.Visible = false;
                }
                BindProperty();
                txtCAMDATE.Text = DateTime.Now.ToString("dd/MMM/yyyy");
                DataSet dsLead = fetchLeadDetails(ddlLeadNo.SelectedItem.Text.Trim());
                if (dsLead != null && dsLead.Tables[0].Rows.Count > 0)
                {
                    KYC_details();
                    FetchCam();
                    txtPDDate.Text = dsLead.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsLead.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
                    txtApplnName.Text = dsLead.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                    txtContactNo.Text = dsLead.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
                    txtMemberID.Text = dsLead.Tables[0].Rows[0]["LD_MID"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_MID"].ToString() : "";
                    txtAddress.Text = dsLead.Tables[0].Rows[0]["LD_RADDRESS"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_RADDRESS"].ToString() : "";
                    txt_enduse.Text = dsLead.Tables[0].Rows[0]["LD_CPD_USE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_CPD_USE"].ToString() : "";

                    hfdcrdtghf.Value = dsLead.Tables[0].Rows[0]["LD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsLead.Tables[0].Rows[0]["LD_DATE"]).ToString("dd/MM/yyyy") : "";
                    string empName = dsLead.Tables[0].Rows[0]["EMP_CODE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["EMP_CODE"].ToString() : "";
                    if (empName != "")
                        empName += "-";
                    empName += dsLead.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
                    string empDesignation = dsLead.Tables[0].Rows[0]["ET_DESC"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["ET_DESC"].ToString() : "";
                    if (empName != "" && empDesignation != "")
                        txtEmpDetailes.Text = empName + " " + "(" + empDesignation + ")";
                    ddlRelationShip.Focus();
                }
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void clear()
    {
        // ddlLeadNo.SelectedIndex = 0;
        txtCAMDATE.Text = "";
        FirstGridViewRow();
    }
    protected void ddlMainApplicant_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlMainApplicant.SelectedIndex > 0)
        {

            con = new SqlConnection(strcon);
            con.Open();

            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);

            cmddd.Parameters.AddWithValue("@VN_ID", "");
            cmddd.Parameters.AddWithValue("@VN_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlVintage.DataSource = dsdd;
            ddlVintage.DataTextField = "VN_DESC";
            ddlVintage.DataValueField = "VN_ID";
            ddlVintage.DataBind();
            ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlNature.Items.Clear();

            con = new SqlConnection(strcon);
            con.Open();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_NATURE", con);
            cmddd.Parameters.AddWithValue("@NT_ID", "");
            cmddd.Parameters.AddWithValue("@NT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlNature.DataSource = dsdd;
            ddlNature.DataTextField = "NT_DESC";
            ddlNature.DataValueField = "NT_ID";
            ddlNature.DataBind();
            ddlNature.Items.Insert(0, new ListItem("--Select--", "0"));


            ddlIncomType.Items.Clear();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_INCOME_TYPE", con);
            cmddd.Parameters.AddWithValue("@IT_ID", "");
            //   cmddd.Parameters.AddWithValue("@IT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.Parameters.AddWithValue("@IT_INS_ID", "");
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlIncomType.DataSource = dsdd;
            ddlIncomType.DataTextField = "IT_DESC";
            ddlIncomType.DataValueField = "IT_ID";
            ddlIncomType.DataBind();
            ddlIncomType.Items.Insert(0, new ListItem("--Select--", "0"));

            con.Close();
        }
    }
    protected void ddlPropType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlPropType.SelectedItem.Text != "--Select--")
        {
            // lblSqrft.Text = " @ " + ddlPropType.SelectedValue.ToString() + " / Sqft ";
            BindConstrStage();
        }
        ddlPropType.Focus();
    }
    protected void ddlCustSource_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtIncome.Text = "";
        txtFactor.Text = "";
        con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
        cmddd.Parameters.AddWithValue("@CT_ID", "");
        cmddd.Parameters.AddWithValue("@CT_TYPE", "G");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        dtSourceOfIncome = dsdd.Tables[0];
        con.Close();

        if (ddlCustSource.SelectedItem.Text != "--Select--")
        {

            DataRow[] dr = dtSourceOfIncome.Select("CT_DESC='" + ddlCustSource.SelectedItem.Text + "'");

            txtIncomeTaken.Text = dr[0].ItemArray[3].ToString();
            Session["CategoryType"] = dr[0].ItemArray[4].ToString();
        }
    }
    //PMT Calculation
    public static double GetEMI(double presentValue, double financingPeriod, double interestRatePerYear)
    {
        //interestRatePerYear = 26.00;
        //financingPeriod = 60;
        //presentValue = 100000;
        double a, b, x;
        double monthlyPayment;
        a = (1 + interestRatePerYear / 1200);
        b = financingPeriod;
        x = Math.Pow(a, b);
        x = 1 / x;
        x = 1 - x;
        monthlyPayment = (presentValue) * (interestRatePerYear / 1200) / x;
        return (monthlyPayment);
    }
    public void CalculateLoadELigibility()
    {
        try
        {
            string strval = this.txtTotalEMIAmount.Text;
            double presentValue = 100000;
            double financingPeriod = 0.0;
            double interestRatePerYear = 0.0;
            double IIREligibilit = 0.0;
            double FOIREligibility = 0.0;
            double AgriIncome = 0.0;
            double assumeobligation = 0.0;
            if (txtAgriIncome.Text != "")
            {
                AgriIncome = Convert.ToDouble(txtAgriIncome.Text);
            }
            if (ddlTenure.SelectedItem.Text != "")
            {
                financingPeriod = Convert.ToDouble(ddlTenure.SelectedItem.Text) * 12;
            }
            if (ddlIntrest.SelectedItem.Text != "--Select--")
            {
                interestRatePerYear = Convert.ToDouble(ddlIntrest.SelectedItem.Text);
            }

            if (txtLoanAmountRequested.Text != "")
            {
                if (Convert.ToDouble(txtLoanAmountRequested.Text) > Convert.ToDouble(1500000))
                {
                    txtAssumdHLoan.Text = Convert.ToString(Convert.ToDouble(txtLoanAmountRequested.Text) * 10 / 100);

                    //txtbassumedobligation.Text = Convert.ToString((Convert.ToDouble(txtLoanAmountRequested.Text) - Convert.ToDouble(1500000)) * 3 / 100);
                    txtbassumedobligation.Text = Convert.ToString((Convert.ToDouble(txtAssumdHLoan.Text)) * 3 / 100);


                }

            }


            if (txtbassumedobligation.Text.Trim() != "")
            {
                assumeobligation = Convert.ToDouble(txtbassumedobligation.Text);
            }

            txtEMIperLakh.Text = Math.Round(GetEMI(presentValue, financingPeriod, interestRatePerYear)).ToString();
            //IIREligibilit = (((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 40 / 100) / (GetEMI(presentValue, financingPeriod, interestRatePerYear))) * 100000;
            IIREligibilit = (((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 50 / 100) / (GetEMI(presentValue, financingPeriod, interestRatePerYear))) * 100000;
            //FOIREligibility = ((((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome + assumeobligation) * 50 / 100) - Convert.ToDouble(txtTotalEMIAmount.Text != "" ? txtTotalEMIAmount.Text : "0.0")) / GetEMI(presentValue, financingPeriod, interestRatePerYear)) * 100000;

            if (hdnltv.Value == "0")
            {
                //FOIREligibility = ((((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome + assumeobligation) * 50 / 100) - Convert.ToDouble(txtTotalEMIAmount.Text != "" ? txtTotalEMIAmount.Text : "0.0")) / GetEMI(presentValue, financingPeriod, interestRatePerYear)) * 100000;
                FOIREligibility = ((((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 50 / 100) - (Convert.ToDouble(txtTotalEMIAmount.Text != "" ? txtTotalEMIAmount.Text : "0.0") + assumeobligation)) / GetEMI(presentValue, financingPeriod, interestRatePerYear)) * 100000;
            }
            else
            {
                FOIREligibility = ((((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 50 / 100) - Convert.ToDouble(txtTotalEMIAmount.Text != "" ? txtTotalEMIAmount.Text : "0.0")) / GetEMI(presentValue, financingPeriod, interestRatePerYear)) * 100000;
                txtbassumedobligation.Text = "0";
            }

            //IIREligibilit = IIREligibilit + AgriIncome;
            //FOIREligibility = FOIREligibility + AgriIncome;

            txtIIREligibility.Text = Convert.ToInt32(IIREligibilit).ToString();
            txtFOIREligibility.Text = Convert.ToInt32(FOIREligibility).ToString();

            if (IIREligibilit <= FOIREligibility)
            {
                txtLoanEligibility.Text = Convert.ToInt32(IIREligibilit).ToString();

            }
            else if (IIREligibilit > FOIREligibility)
            {
                txtLoanEligibility.Text = Convert.ToInt32(FOIREligibility).ToString();
            }
            else if (IIREligibilit == FOIREligibility)
            {
                txtLoanEligibility.Text = Convert.ToInt32(IIREligibilit).ToString();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtIntestRate_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        CalculateLoadELigibility();
        txtLoanAmountRequested.Focus();
    }
    //protected void ddlAgeOfBuilding_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    if (ddlAgeOfBuilding.SelectedItem.Text != "--Select--")
    //    {
    //        txtDepreciation.Text = ddlAgeOfBuilding.SelectedValue.ToString();
    //        if (txtDepreciation.Text != "" && txtBuildingValue.Text != "")
    //        {

    //            double nVal = 100 - Convert.ToDouble(txtDepreciation.Text);
    //            txtonsideredBuilding.Text = Convert.ToString(Convert.ToInt32(txtBuildingValue.Text) * (nVal / 100));
    //            if (txtConsidered.Text != "")
    //            {
    //                txtTotalPropertyValue.Text = Convert.ToString(Convert.ToInt32(txtonsideredBuilding.Text) + Convert.ToInt32(txtConsidered.Text));
    //                txtLTVonProperty.Text = Convert.ToString(Convert.ToInt32(txtTotalPropertyValue.Text) * 50 / 100);
    //                int nMinVal = 0;
    //                if (txtLoanAmountRequested.Text != "" && txtLoanEligibility.Text != "")
    //                {
    //                    nMinVal = Math.Min(Convert.ToInt32(txtLoanAmountRequested.Text), Convert.ToInt32(txtLoanEligibility.Text));
    //                    nMinVal = Math.Min(Convert.ToInt32(nMinVal), Convert.ToInt32(txtLTVonProperty.Text));
    //                    txtRecommendedLoan.Text = Convert.ToString(RoundDown(nMinVal));
    //                    if (txtRecommendedLoan.Text != "")
    //                    {
    //                        btnSubmit.Enabled = true;
    //                    }
    //                }

    //            }
    //            txtNameofInsuredPerson.Focus();
    //        }

    //    }
    //    else
    //    {
    //        btnSubmit.Enabled = false;
    //        ddlAgeOfBuilding.Focus();
    //    }
    //}

    protected void txtMarketValueSqrt_TextChanged(object sender, EventArgs e)
    {
        /* CR changes for IR-534
         * Desc: Calculate Considered Land Value based on MarketValuePerSqft
         * Changes done by: Baulin. D
         * Changes done on: 15-July-2019
         */
        #region VARIABLES
        string txtMarketValue = string.Empty;
        string txtLndArea = string.Empty;

        double dMarketValue = 0.0;
        double dLandArea = 0.0;
        #endregion

        txtMarketValue = txtMarketValueSqrt.Text.Trim();
        txtLndArea = txtLandArea.Text.Trim();

        btnSubmit.Enabled = false;

        if (!string.IsNullOrEmpty(txtMarketValue) && !string.IsNullOrEmpty(txtLndArea))
        {
            dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);
            dLandArea = Convert.ToDouble(txtLandArea.Text);

            if (dMarketValue > 0 && dLandArea > 0)
            {
                txtConsidered.Text = Convert.ToDouble(dMarketValue * dLandArea).ToString();
            }
        }
        /*End of CR changes for IR-534*/
    }

    public int RoundNum(int num)
    {
        int rem = num % 10;
        return rem >= 5 ? (num - rem + 10) : (num - rem);
    }
    public int RoundDown(int toRound)
    {
        int nValue = 0;

        if (toRound.ToString().Length < 4)
        {
            nValue = toRound - toRound % 10;
        }
        else if (toRound.ToString().Length < 6)
        {
            nValue = toRound - toRound % 100;
        }
        else
        {
            nValue = toRound - toRound % 1000;
        }
        return nValue;
    }




    protected void txtAgriIncome_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        if (ddlIntrest.SelectedItem.Text != "--Select--")
        {
            if (txtbassumedobligation.Text != "")
            {
                CalculateLoadELigibility();
            }
            else
            {
                txtbassumedobligation.Focus();
                uscMsgBox1.AddMessage("Please enter the assumed obligation", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //InsertCamLapValues();
        //InsertDraftCamLapValues("S");
        if (ddlLeadNo.SelectedItem.Text.Contains("EHF"))
        {
            if (txtEmpCode.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Code');", true);
            else if (txtEMpNAme.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Name');", true);
            else if (txtDesgn.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Designation');", true);
            else if (txtContact.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Contact Number');", true);
            /*else if (ttxEmailEmp.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Email');", true);
            else if (txtEmpCompany.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Company');", true);
            else if (txtDOJ.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Date Of Joining');", true);
            else if (txtGrade.Text.Trim() == "")
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Enter the Employee Grade');", true);
            */else
                InsertDraftCamLapValues("S");
        }
        else
            InsertDraftCamLapValues("S");
        if (cmrs > 0)
        {
           // //UpdateValues();
        }
        else { ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Failed to Save');", true); }
    }

    protected void UpdateValues()
    {
        try
        {
            System.DateTime dtpddate;
            System.DateTime dtgn;

            try
            {
                dtpddate = Convert.ToDateTime(DateTime.ParseExact(hfdcrdtghf.Value, "dd/M/yyyy", CultureInfo.InvariantCulture));//Convert.ToDateTime(hfdcrdtghf.Value);

                dtgn = Convert.ToDateTime(txtPDDate.Text);

                TimeSpan diff = dtgn.Subtract(dtpddate);

                if (diff.Days >= 0)
                {
                    con = new SqlConnection(strcon);

                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();

                    cmd = new SqlCommand("RTS_SP_UPDATE_CAM_GHF_GLAP", con);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 120000;
                    cmd.Parameters.AddWithValue("@LDID", Convert.ToInt32(ddlLeadNo.SelectedValue.ToString()));
                    cmd.Parameters.AddWithValue("@PDDATE", dtgn.ToString("MM/dd/yyyy"));
                    cmd.Parameters.AddWithValue("@RADDR", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@CAM_HOBLIG", txtbassumedobligation.Text);
                    cmd.Parameters.AddWithValue("@ID", Session["ID"].ToString()); ;//@ID
                    int rs = cmd.ExecuteNonQuery();

                    if (rs == 3)
                    {
                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Saved Successfully');window.location.reload();", true);
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   not Saved');", true);
                    }


                }
                else
                {
                    uscMsgBox1.AddMessage("PD Date should not be less than the lead Created date...", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }


    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("CAM_MFHF.aspx");
    }
    protected void InsertCamLapValues()
    {
        try
        {
            if (ddlRelationShip.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Relation ship", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlMainApplicant.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Main Source of Income", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlVintage.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Vintage", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlNature.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Nature OfBussiness/Job", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlIncomType.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Income Type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //else if (ddlLoanPurpose.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Loan Purpose", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else if (ddlCreditHistory.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Cedit History", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (rdnUrban.Checked == false && rdnRural.Checked == false)
            {
                uscMsgBox1.AddMessage("Please Select Area type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                DataTable dtIncomeDetails = new DataTable();
                dtIncomeDetails = (DataTable)ViewState["CurrentTable"];
                if (dtIncomeDetails.Columns.Contains("INCOME_SOURCE"))
                {
                    dtIncomeDetails.Columns.Remove("INCOME_SOURCE");
                }
                if (dtIncomeDetails.Columns.Contains("RELATIONSHIP"))
                {
                    dtIncomeDetails.Columns.Remove("RELATIONSHIP");
                }

                DataTable dtObligation = new DataTable();
                dtObligation = BindObligationTable();

                DataTable dtColletral = new DataTable();
                dtColletral = BindCollateralTable();

                con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertCAM", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@CAM_TYPE", "B");
                //cmdinsert.Parameters.AddWithValue("@CAM_PR_ID", "3");

                //cmdinsert.Parameters.AddWithValue("@CAM_BR_ID", txtBranchName.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LD_ID", ddlLeadNo.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_AP_ADD", txtAddress.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_ER_ID", ddlRelationShip.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_INS_ID", ddlMainApplicant.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_VN_ID", ddlVintage.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_NT_ID", ddlNature.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_IT_ID", ddlIncomType.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_PP_ID", ddlLoanPurpose.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_CH_ID", ddlCreditHistory.SelectedValue.ToString());

                cmdinsert.Parameters.AddWithValue("@CAM_AGL", txtAgriLandAcres.Text != "" ? Convert.ToDouble(txtAgriLandAcres.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_AGI", txtAgriIncome.Text != "" ? Convert.ToDouble(txtAgriIncome.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_IN", txtTotalLoanEligibility.Text != "" ? Convert.ToDouble(txtTotalLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_EMI", txtTotalEMIAmount.Text != "" ? Convert.ToDouble(txtTotalEMIAmount.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TENURE", ddlTenure.SelectedItem.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_INR", ddlIntrest.SelectedItem.Text != "--Select--" ? Convert.ToDouble(ddlIntrest.SelectedItem.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_EPL", txtEMIperLakh.Text != "" ? Convert.ToDouble(txtEMIperLakh.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_IRR", txtIIREligibility.Text != "" ? Convert.ToDouble(txtIIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_FOIR", txtFOIREligibility.Text != "" ? Convert.ToDouble(txtFOIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LAMT_REQ", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_ELG", txtLoanEligibility.Text != "" ? Convert.ToDouble(txtLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_PT_ID", ddlPropType.SelectedItem.Text.ToString());

                cmdinsert.Parameters.AddWithValue("@CAM_CS_ID", ddlConstructionStage.SelectedItem.Text.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_CE_ID", ddlConstrType.SelectedItem.Text.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_OC_ID", ddlOccupancyStatus.SelectedValue.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_UG_ID", ddlUsage.SelectedValue.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_NOT", txtNoOFtenents.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LAREA", txtLandArea.Text != "" ? Convert.ToDouble(txtLandArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_GLV", txtGuideline.Text != "" ? Convert.ToDouble(txtGuideline.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_MV", txtMarketValueSqrt.Text != "" ? Convert.ToDouble(txtMarketValueSqrt.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CLV", txtConsidered.Text != "" ? Convert.ToDouble(txtConsidered.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BAREA", txtConstrArea.Text != "" ? Convert.ToDouble(txtConstrArea.Text) : 0.0);
                //cmdinsert.Parameters.AddWithValue("@CAM_BV", txtBuildingValue.Text != "" ? Convert.ToDouble(txtBuildingValue.Text) : 0.0);
                //cmdinsert.Parameters.AddWithValue("@CAM_BA_ID", ddlAgeOfBuilding.SelectedItem.Text);
                //cmdinsert.Parameters.AddWithValue("@CAM_DEP", txtDepreciation.Text != "" ? Convert.ToDouble(txtDepreciation.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CBV", txtConstrCost.Text != "" ? Convert.ToDouble(txtConstrCost.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_TPV", txtTotalPropCost.Text != "" ? Convert.ToDouble(txtTotalPropCost.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_LTV", txtLoanEligibleLCR.Text != "" ? Convert.ToDouble(txtLoanEligibleLCR.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_RLA", txtFinancialLoanAmt.Text != "" ? Convert.ToDouble(txtFinancialLoanAmt.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_IIR_PER", txtIIRasPerLoan.Text != "" ? Convert.ToDouble(txtIIRasPerLoan.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LCR_PER", txtLCRAsPerLoan.Text != "" ? Convert.ToDouble(txtLCRAsPerLoan.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_IIR_LCR", txtIIRLCR.Text != "" ? Convert.ToDouble(txtIIRLCR.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_Deviation", txtDeviation.Text);

                cmdinsert.Parameters.AddWithValue("@CAM_PCS", txtNameofInsuredPerson.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_CBY", Session["ID"].ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_MBY", Session["ID"].ToString());

                if (rdnUrban.Checked == true)
                {
                    cmdinsert.Parameters.AddWithValue("@CAM_ATYPE", "Urban");
                }
                else if (rdnRural.Checked == true)
                {
                    cmdinsert.Parameters.AddWithValue("@CAM_ATYPE", "Rural");
                }

                cmdinsert.Parameters.AddWithValue("@tblIncome_Details", dtIncomeDetails);
                cmdinsert.Parameters.AddWithValue("@tblOBLIGATE", dtObligation);
                cmdinsert.Parameters.AddWithValue("@tblCOLLATERAL", dtColletral);

                int n = cmdinsert.ExecuteNonQuery();
                cmrs = n;
                //if (n > 0)
                //{
                //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Saved Successfully');", true);
                //    //  Response.Redirect("CAM_MFHF.aspx");
                //}
                //else
                //{
                //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Failed to Save');", true);
                //}
                con.Close();
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }


    public DataTable BindObligationTable()
    {
        DataTable dtObligation = new DataTable();
        DataRow drObligation = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string))); -  IR/RL/SEP19/09/556_New Fields Required in RTS CAM Obligation details
        dtObligation.Columns.Add(new DataColumn("CO_TYPE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_FIN", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_TENURE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_LOAN_AMT", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_SOURCE", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_BORW", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_AMOUNT", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_BAL_EMI", typeof(string)));
        dtObligation.Columns.Add(new DataColumn("CO_CIBIL", typeof(string)));

        if (txtFinanciear1.Text != "" && drpName1.SelectedItem.Text != "--Select--" && txtEMIAmount1.Text != "")
        {

            drObligation = dtObligation.NewRow();
            drObligation["CO_TYPE"] = ddlLoanType1.SelectedItem.Text != "--Select--" ? ddlLoanType1.SelectedValue : "";
            drObligation["CO_FIN"] = txtFinanciear1.Text;
            drObligation["CO_TENURE"] = "";
            drObligation["CO_LOAN_AMT"] = "";
            drObligation["CO_SOURCE"] = ddlSource1.SelectedItem.Text != "--Select--" ? ddlSource1.SelectedValue : "";
            drObligation["CO_BORW"] = drpName1.SelectedItem.Text != "--Select--" ? drpName1.SelectedItem.Text : "";
            drObligation["CO_AMOUNT"] = txtEMIAmount1.Text;
            drObligation["CO_BAL_EMI"] = txtBALEMIAmount1.Text;
            drObligation["CO_CIBIL"] = txtcibil1.Text;
            dtObligation.Rows.Add(drObligation);
        }
        if (txtFinanciear2.Text != "" && drpName2.SelectedItem.Text != "--Select--" && txtEMIAmount2.Text != "")
        {
            drObligation = dtObligation.NewRow();
            drObligation["CO_TYPE"] = ddlLoanType2.SelectedItem.Text != "--Select--" ? ddlLoanType2.SelectedValue : "";
            drObligation["CO_FIN"] = txtFinanciear2.Text;
            drObligation["CO_TENURE"] = "";
            drObligation["CO_LOAN_AMT"] = "";
            drObligation["CO_SOURCE"] = ddlSource2.SelectedItem.Text != "--Select--" ? ddlSource2.SelectedValue : "";
            drObligation["CO_BORW"] = drpName2.SelectedItem.Text;
            drObligation["CO_AMOUNT"] = txtEMIAmount2.Text;
            drObligation["CO_BAL_EMI"] = txtBALEMIAmount2.Text;
            drObligation["CO_CIBIL"] = txtcibil2.Text;
            dtObligation.Rows.Add(drObligation);
        }
        if (txtFinanciear3.Text != "" && drpName3.SelectedItem.Text != "--Select--" && txtEMIAmount3.Text != "")
        {
            drObligation = dtObligation.NewRow();
            drObligation["CO_TYPE"] = ddlLoanType3.SelectedItem.Text != "--Select--" ? ddlLoanType3.SelectedValue : "";
            drObligation["CO_FIN"] = txtFinanciear3.Text;
            drObligation["CO_TENURE"] = "";
            drObligation["CO_LOAN_AMT"] = "";
            drObligation["CO_SOURCE"] = ddlSource3.SelectedItem.Text != "--Select--" ? ddlSource3.SelectedValue : "";
            drObligation["CO_BORW"] = drpName3.SelectedItem.Text;
            drObligation["CO_AMOUNT"] = txtEMIAmount3.Text;
            drObligation["CO_BAL_EMI"] = txtBALEMIAmount3.Text;
            drObligation["CO_CIBIL"] = txtcibil3.Text;
            dtObligation.Rows.Add(drObligation);
        }
        if (txtFinanciear4.Text != "" && drpName4.SelectedItem.Text != "--Select--" && txtEMIAmount4.Text != "")
        {
            drObligation = dtObligation.NewRow();
            drObligation["CO_TYPE"] = ddlLoanType4.SelectedItem.Text != "--Select--" ? ddlLoanType4.SelectedValue : "";
            drObligation["CO_FIN"] = txtFinanciear4.Text;
            drObligation["CO_TENURE"] = "";
            drObligation["CO_LOAN_AMT"] = "";
            drObligation["CO_SOURCE"] = ddlSource4.SelectedItem.Text != "--Select--" ? ddlSource4.SelectedValue : "";
            drObligation["CO_BORW"] = drpName4.SelectedItem.Text;
            drObligation["CO_AMOUNT"] = txtEMIAmount4.Text;
            drObligation["CO_BAL_EMI"] = txtBALEMIAmount4.Text;
            drObligation["CO_CIBIL"] = txtcibil4.Text;
            dtObligation.Rows.Add(drObligation);
        }
        if (txtFinanciear5.Text != "" && drpName5.SelectedItem.Text != "--Select--" && txtEMIAmount5.Text != "")
        {
            drObligation = dtObligation.NewRow();
            drObligation["CO_TYPE"] = ddlLoanType5.SelectedItem.Text != "--Select--" ? ddlLoanType5.SelectedValue : "";
            drObligation["CO_FIN"] = txtFinanciear5.Text;
            drObligation["CO_TENURE"] = "";
            drObligation["CO_LOAN_AMT"] = "";
            drObligation["CO_SOURCE"] = ddlSource5.SelectedItem.Text != "--Select--" ? ddlSource5.SelectedValue : "";
            drObligation["CO_BORW"] = drpName5.SelectedItem.Text;
            drObligation["CO_AMOUNT"] = txtEMIAmount5.Text;
            drObligation["CO_BAL_EMI"] = txtBALEMIAmount5.Text;
            drObligation["CO_CIBIL"] = txtcibil5.Text;
            dtObligation.Rows.Add(drObligation);
        }
        return dtObligation;
    }
    public DataTable BindCollateralTable()
    {
        DataTable dtCollateral = new DataTable();
        DataRow drCollateral = null;
        // dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));     
        dtCollateral.Columns.Add(new DataColumn("CC_COLAT", typeof(string)));
        dtCollateral.Columns.Add(new DataColumn("CC_AMOUNT", typeof(string)));
        return dtCollateral;
    }
    protected void txtConstrArea_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
    }

    /*CR changes for IR-534
     Description: Calculate considered land value based on market value
     Changes done by : Baulin. D
     Changes done on : 15-July-2019    
    protected void txtGuideline_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        double dGuidline = 0.0;
        double dMarketValue = 0.0;
        double dLandArea = 0.0;
        if (txtGuideline.Text != "" && txtLandArea.Text != "")
        {
            dGuidline = Convert.ToDouble(txtGuideline.Text);
            // dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);
            dLandArea = Convert.ToDouble(txtLandArea.Text);

             txtConsidered.Text = Convert.ToInt32(dGuidline * dLandArea).ToString();

        }
    }
    End of CR changes for IR-534*/

    protected void btnCalculate_Click(object sender, EventArgs e)
    {
        try
        {
            double dGuidline = 0.0;
            double dMarketValue = 0.0;
            double dLandArea = 0.0;
            if (txtTotalLoanEligibility.Text == "")
            {
                DDLkycName.Focus();
                uscMsgBox1.AddMessage("Please Add Income Details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

            }
            else if (ddlIntrest.SelectedItem.Text == "--Select--")
            {

                uscMsgBox1.AddMessage("Please Give Intrest Rate value", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                ddlIntrest.Focus();
            }
            else if (ddlLoanProType.SelectedItem.Text == "--Select--")
            {

                uscMsgBox1.AddMessage("Please select loan type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                ddlLoanProType.Focus();
            }
            else if ((ddlLoanProType.SelectedItem.Text == "Home Purchase" || ddlLoanProType.SelectedItem.Text == "Composite Loan - Land") && txtRegistrationval.Text == "")
            {

                uscMsgBox1.AddMessage("Please Give Registration Amount", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtRegistrationval.Focus();
                btnSubmit.Enabled = false;
            }
            else if (ddlLoanProType.SelectedItem.Text == "BT" && (txtFinname.Text == "" || txtLoanAMnt.Text == "" || txtOutstandingAmt.Text == ""))
            {
                uscMsgBox1.AddMessage("Please Give All Financier Details", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtFinname.Focus();
                btnSubmit.Enabled = false;
            }
            else if (ddlLoanProType.SelectedItem.Text == "Top Up" && txtParentLeadNo.Text == "")
            {
                uscMsgBox1.AddMessage("Please Give a Parent Lead No", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                txtRegistrationval.Focus();
                btnSubmit.Enabled = false;
            }
            else
            {
                //if (txtbassumedobligation.Text != "")
                //{
                //    CalculateLoadELigibility();
                //}
                //else
                //{
                //    txtbassumedobligation.Focus();
                //    uscMsgBox1.AddMessage("Please enter the assumed obligation", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //    return;
                //}
                //if (txtMarketValueSqrt.Text != "" && txtLandArea.Text != "")
                int loantype_per = 0;
                Session["LP_PER"] = clscommon.GetLoanType_Percentage(Convert.ToInt32(ddlLoanProType.SelectedValue));
                loantype_per = Convert.ToInt32(Session["LP_PER"].ToString());

                /*CR changes for IR-534
                 Description: Calculate considered land value based on market value
                 Changes done by : Baulin. D
                 Changes done on : 15-July-2019
                 */
                //if ((txtMarketValueSqrt.Text != "" || txtMarketValueSqrt.Text != "0") && txtLandArea.Text != "")
                //{
                //    dGuidline = Convert.ToDouble(txtGuideline.Text);
                //    dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);
                //    dLandArea = Convert.ToDouble(txtLandArea.Text);
                //    txtConsidered.Text = Convert.ToDouble(dMarketValue * dLandArea).ToString();
                //}

                CalculateLTVPercentage();
                CalculateLoadELigibility();

                string txtMarketValue = txtMarketValueSqrt.Text.Trim();
                string txtLndArea = txtLandArea.Text.Trim();

                if (!string.IsNullOrEmpty(txtMarketValue) && !string.IsNullOrEmpty(txtLndArea))
                {
                    dLandArea = Convert.ToDouble(txtLandArea.Text);
                    dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);

                    if (dMarketValue > 0 && dLandArea > 0)
                    {
                        txtConsidered.Text = Convert.ToDouble(dMarketValue * dLandArea).ToString();
                    }
                }
                /*End of CR changes for IR-534*/

                //Bala changes 03/07/2017
                //if (ddlConstrType.SelectedItem.Text != "--Select--" && txtConstrArea.Text != "")
                if (txtConstrArea.Text != "")
                {
                    //double nAmnt1 = Convert.ToDouble(txConVal.Text) + Convert.ToDouble(txtAmunity.Text != "" ? txtAmunity.Text : "0");
                    double nAmnt1 = Convert.ToDouble(txConVal.Text) ;
                    double nAmnt2 = Convert.ToDouble(txConVal1.Text);
                    double nMin = Math.Min(nAmnt1, nAmnt2);

                    //txtConstrCost.Text = nMin.ToString();
                    txtConstrCost.Text = Convert.ToString(nMin+ Convert.ToDouble(txtAmunity.Text != "" ? txtAmunity.Text : "0"));

                    if (txtConsidered.Text != "")
                    {
                        txtTotalPropCost.Text = Convert.ToString(Convert.ToDouble(txtConstrCost.Text) + Convert.ToDouble(txtConsidered.Text));
                    }
                    if (txtConstrCost.Text != "")
                    {

                        double dblloanelig = txtAgriIncome.Text != "" ? Convert.ToDouble(txtAgriIncome.Text) : 0;
                        dblloanelig = dblloanelig + Convert.ToDouble(txtTotalLoanEligibility.Text);

                        //bala changes 03/07/2017
                        // txtLoanEligibleLCR.Text = Convert.ToString(Convert.ToDouble(txtConstrCost.Text) * 80 / 100);
                        txtLoanEligibleLCR.Text = Convert.ToString(clscommon.Get_LCR_LTV_Calc_Amt(Convert.ToDouble(txtConstrCost.Text), Convert.ToDouble(txtConsidered.Text), Convert.ToInt32(ddlLoanProType.SelectedValue), loantype_per));




                        double dMinVal1 = Math.Min(Convert.ToDouble(txtLoanAmountRequested.Text), Convert.ToDouble(txtLoanEligibility.Text));
                        double dMinVal2 = Math.Min(dMinVal1, Convert.ToDouble(txtLoanEligibleLCR.Text));
                        if (txtRegistrationval.Text != "")
                        {
                            dMinVal2 = Math.Min(dMinVal2, Convert.ToDouble(txtRegistrationval.Text));
                        }
                        if (txtOutstandingAmt.Text != "")
                        {
                            dMinVal2 = Math.Min(dMinVal2, Convert.ToDouble(txtOutstandingAmt.Text));
                        }
                        txtFinancialLoanAmt.Text = Convert.ToString(dMinVal2);

                        txtIIRasPerLoan.Text = Convert.ToString(Math.Round(((Convert.ToDouble(txtFinancialLoanAmt.Text) * Convert.ToDouble(txtEMIperLakh.Text)) / (dblloanelig * 100000)) * 100));
                        txtLCRAsPerLoan.Text = "0";
                        if (ddlPropType.SelectedItem.Text != "Vacant Land")
                        {
                            txtLCRAsPerLoan.Text = Convert.ToString(Math.Round((Convert.ToDouble(txtFinancialLoanAmt.Text) / Convert.ToDouble(txtConstrCost.Text)) * 100));
                        }
                        txtIIRLCR.Text = Convert.ToString(Math.Round(Convert.ToDouble(txtIIRasPerLoan.Text) + Convert.ToDouble(txtLCRAsPerLoan.Text)));
                        btnSubmit.Enabled = true;
                    }
                }

                //CRE NO CRE
                #region CRE
                if (txtrentalloaneligibilityincome.Text != "" && txtTotalLoanEligibility.Text != "")
                {
                    double number = 0.0;

                    number = ((Convert.ToDouble(txtTotalLoanEligibility.Text) * 50) / 100);

                    if (Convert.ToDouble(txtrentalloaneligibilityincome.Text) > number)
                    {
                        ddlCreNonCre.SelectedValue = "1"; // CRE 
                    }
                    else if (Convert.ToDouble(txtrentalloaneligibilityincome.Text) <= number)
                    {
                        ddlCreNonCre.SelectedValue = "2"; //Non CRE
                    }
                }
                else
                {
                    ddlCreNonCre.SelectedValue = "2"; //Non CRE
                }
                #endregion
            }
            con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_CATEGORY", con);
            cmddd.Parameters.AddWithValue("@CT_ID", "");
            cmddd.Parameters.AddWithValue("@CT_TYPE", "G");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            dtSourceOfIncome = dsdd.Tables[0];
            con.Close();
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtLoanAmountRequested_TextChanged(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
    }
    protected void ddlIntrest_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlIntrest.SelectedItem.Text != "--Select--")
        {
            //if (txtbassumedobligation.Text.Trim() != "")
            //{
            btnSubmit.Enabled = false;
            CalculateLoadELigibility();
            //    txtLoanAmountRequested.Focus();
            //}

            //else
            //{
            //    txtbassumedobligation.Focus();
            //    uscMsgBox1.AddMessage("Please enter the assumed obligation", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //    return;
            //}
        }
        else
        {
            ddlIntrest.Focus();
        }
    }

    protected void btnDraft_Click(object sender, EventArgs e)
    {
        InsertDraftCamLapValues("D");
    }
    protected void InsertDraftCamLapValues(string strType)
    {
        try
        {
            if (ddlLeadNo.SelectedItem.Text == "--Select--")
            {
                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select Lead No ');", true);
            }
            else if (ddlRelationShip.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Relation ship", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlMainApplicant.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Main Source of Income", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlVintage.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Vintage", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlNature.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Nature OfBussiness/Job", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else if (ddlIncomType.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Income Type", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            //else if (ddlLoanPurpose.SelectedItem.Text == "--Select--")
            //{
            //    uscMsgBox1.AddMessage("Please Select Loan Purpose", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else if (ddlCreditHistory.SelectedItem.Text == "--Select--")
            {
                uscMsgBox1.AddMessage("Please Select Cedit History", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
            else
            {
                DataTable dtIncomeDetails = new DataTable();
                dtIncomeDetails = (DataTable)ViewState["CurrentTable"];
                if (dtIncomeDetails.Columns.Contains("INCOME_SOURCE"))
                {
                    dtIncomeDetails.Columns.Remove("INCOME_SOURCE");
                }
                if (dtIncomeDetails.Columns.Contains("RELATIONSHIP"))
                {
                    dtIncomeDetails.Columns.Remove("RELATIONSHIP");
                }
                if (dtIncomeDetails.Columns.Contains("APP_TYPE"))
                {
                    dtIncomeDetails.Columns.Remove("APP_TYPE");
                }
                DataTable dtObligation = new DataTable();
                dtObligation = BindObligationTable();

                DataTable dtColletral = new DataTable();
                dtColletral = BindCollateralTable();

                con = new SqlConnection(strcon);
                con.Open();
                SqlCommand cmdinsert = new SqlCommand("RTS_SP_InsertCAM_New_GHF", con);
                cmdinsert.CommandType = CommandType.StoredProcedure;
                cmdinsert.Parameters.AddWithValue("@CAM_TYPE", "C");
                //cmdinsert.Parameters.AddWithValue("@CAM_PR_ID", "3");

                //cmdinsert.Parameters.AddWithValue("@CAM_BR_ID", txtBranchName.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LD_ID", ddlLeadNo.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_AP_ADD", txtAddress.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_ER_ID", ddlRelationShip.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_INS_ID", ddlMainApplicant.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_VN_ID", ddlVintage.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_NT_ID", ddlNature.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_IT_ID", ddlIncomType.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_PP_ID", ddlLoanPurpose.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_CH_ID", ddlCreditHistory.SelectedValue.ToString());

                cmdinsert.Parameters.AddWithValue("@CAM_AGL", txtAgriLandAcres.Text != "" ? Convert.ToDouble(txtAgriLandAcres.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_AGI", txtAgriIncome.Text != "" ? Convert.ToDouble(txtAgriIncome.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_IN", txtTotalLoanEligibility.Text != "" ? Convert.ToDouble(txtTotalLoanEligibility.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TOT_EMI", txtTotalEMIAmount.Text != "" ? Convert.ToDouble(txtTotalEMIAmount.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_TENURE", ddlTenure.SelectedItem.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_INR", ddlIntrest.SelectedItem.Text != "--Select--" ? Convert.ToDouble(ddlIntrest.SelectedItem.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_EPL", txtEMIperLakh.Text != "" ? Convert.ToDouble(txtEMIperLakh.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_IRR", txtIIREligibility.Text != "" ? Convert.ToDouble(txtIIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_FOIR", txtFOIREligibility.Text != "" ? Convert.ToDouble(txtFOIREligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LAMT_REQ", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_ELG", txtLoanEligibility.Text != "" ? Convert.ToDouble(txtLoanEligibility.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_HOBIG", txtbassumedobligation.Text != "" ? Convert.ToDouble(txtbassumedobligation.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_HLOAN", txtAssumdHLoan.Text != "" ? Convert.ToDouble(txtAssumdHLoan.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_PT_ID", ddlPropType.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_CS_ID", ddlConstructionStage.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_CE_ID", ddlConstrType.SelectedValue.ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_CF_ID", ddlConstFloor.SelectedValue);
             
                //cmdinsert.Parameters.AddWithValue("@CAM_PT_ID", ddlPropType.SelectedItem.Text.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_CS_ID", ddlConstructionStage.SelectedItem.Text.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_CE_ID", ddlConstrType.SelectedItem.Text.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_CF_ID", ddlConstFloor.SelectedValue);


                //cmdinsert.Parameters.AddWithValue("@CAM_OC_ID", ddlOccupancyStatus.SelectedValue.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_UG_ID", ddlUsage.SelectedValue.ToString());
                //cmdinsert.Parameters.AddWithValue("@CAM_NOT", txtNoOFtenents.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_LAREA", txtLandArea.Text != "" ? Convert.ToDouble(txtLandArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_GLV", txtGuideline.Text != "" ? Convert.ToDouble(txtGuideline.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_MV", txtMarketValueSqrt.Text != "" ? Convert.ToDouble(txtMarketValueSqrt.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_CLV", txtConsidered.Text != "" ? Convert.ToDouble(txtConsidered.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BAREA", txtConstrArea.Text != "" ? Convert.ToDouble(txtConstrArea.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_SQFT", txtSqft.Text != "" ? Convert.ToDouble(txtSqft.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_BV", txConVal.Text != "" ? Convert.ToDouble(txConVal.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_AMENITIES", txtAmunity.Text != "" ? Convert.ToDouble(txtAmunity.Text) : 0.0);   
                cmdinsert.Parameters.AddWithValue("@CAM_CBV", txtConstrCost.Text != "" ? Convert.ToDouble(txtConstrCost.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_TPV", txtTotalPropCost.Text != "" ? Convert.ToDouble(txtTotalPropCost.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LN_LTV", txtLoanEligibleLCR.Text != "" ? Convert.ToDouble(txtLoanEligibleLCR.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_RLA", txtFinancialLoanAmt.Text != "" ? Convert.ToDouble(txtFinancialLoanAmt.Text) : 0.0);

                cmdinsert.Parameters.AddWithValue("@CAM_IIR_PER", txtIIRasPerLoan.Text != "" ? Convert.ToDouble(txtIIRasPerLoan.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_LCR_PER", txtLCRAsPerLoan.Text != "" ? Convert.ToDouble(txtLCRAsPerLoan.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_IIR_LCR", txtIIRLCR.Text != "" ? Convert.ToDouble(txtIIRLCR.Text) : 0.0);
                cmdinsert.Parameters.AddWithValue("@CAM_EMP_ID", txtEmpCode.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_Deviation", txtDeviation.Text);

                cmdinsert.Parameters.AddWithValue("@CAM_PCS", txtNameofInsuredPerson.Text);
                cmdinsert.Parameters.AddWithValue("@CAM_CBY", Session["ID"].ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_MBY", Session["ID"].ToString());
                cmdinsert.Parameters.AddWithValue("@CAM_LP_ID", ddlLoanProType.SelectedValue);
                if (rdnUrban.Checked == true)
                {
                    cmdinsert.Parameters.AddWithValue("@CAM_ATYPE", "Urban");
                }
                else if (rdnRural.Checked == true)
                {
                    cmdinsert.Parameters.AddWithValue("@CAM_ATYPE", "Rural");
                }

                cmdinsert.Parameters.AddWithValue("@tblIncome_Details", dtIncomeDetails);
                cmdinsert.Parameters.AddWithValue("@tblOBLIGATE", dtObligation);
                cmdinsert.Parameters.AddWithValue("@tblCOLLATERAL", dtColletral);
                cmdinsert.Parameters.AddWithValue("@SAVETYPE", strType);
                cmdinsert.Parameters.AddWithValue("@CAM_CRE", ddlCreNonCre.SelectedItem.Text != "--Select--" ? ddlCreNonCre.SelectedItem.Text : (object)DBNull.Value);
                int n = cmdinsert.ExecuteNonQuery();
                cmrs = n;
                if (n > 0)
                {


                    //if (strType == "S")
                    //{
                    //    if (txtGuideline.Text != "" && txtMarketValueSqrt.Text != "")
                    //    {
                    //        double dGuidline = 0.0;
                    //        if (ddlPropType.SelectedItem.Text == "No RCC roofing" || ddlPropType.SelectedItem.Text == "Vacant plot")
                    //        {
                    //            dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                    //        }
                    //        else
                    //        {
                    //            dGuidline = 2 * Convert.ToDouble(txtGuideline.Text);
                    //        }
                    //        //if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text) && RadioBtnGV_No.Checked)
                    //        //{
                    //        //    sendMail();
                    //        //}
                    //        if (dGuidline < Convert.ToDouble(txtMarketValueSqrt.Text))
                    //        {
                    //            sendMail();
                    //        }
                    //    }
                    //}

                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Saved Successfully');window.location.reload()", true);
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('CAM Details for " + ddlLeadNo.SelectedItem.Text + "   Failed to Save');", true);
                }

                con.Close();
            }



        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Age", con);
        cmddd.Parameters.AddWithValue("@KYC_Name", DDLkycName.SelectedIndex != 0 ? DDLkycName.SelectedItem.Text : "");
        cmddd.Parameters.AddWithValue("@KYC_LD_ID", ddlLeadNo.SelectedIndex != 0 ? ddlLeadNo.SelectedValue : "");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();

        if (dsdd.Tables[0].Rows.Count > 0)
        {
            txtCustAge.Text = dsdd.Tables[0].Rows[0][0].ToString();
            TBAppType.Text = dsdd.Tables[0].Rows[0][1] != null ? dsdd.Tables[0].Rows[0][1].ToString() : "0";
        }
        if (DDLkycName.SelectedIndex == 0)
        {
            txtCustAge.Text = "";
        }
    }
    public void KYC_details()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_KYC", con);
        cmddd.Parameters.AddWithValue("@LD_ID", ddlLeadNo.SelectedValue.ToString().Trim());
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        DDLkycName.DataSource = dsdd;
        DDLkycName.DataTextField = "KYC_NAME";
        DDLkycName.DataValueField = "KYC_ID";
        DDLkycName.DataBind();
        DDLkycName.Items.Insert(0, new ListItem("--Select--", "0"));
        TBAppType.Text = "";
    }
    public void FetchCam()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_To_Update_Final_GHF", con);
            cmddd.Parameters.AddWithValue("@Lead_ID", ddlLeadNo.SelectedValue.ToString());
            cmddd.Parameters.AddWithValue("@CamType", "B");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            txtPensionIncome.Text = "";
            txtbxsumofrental.Text = "";
            txtbxotherincome.Text = "";
            txtrentalloaneligibilityincome.Text = "";

            if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
            {

                //// Search creteria
                txtBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
                //txtLeadNo.Text = dsdd.Tables[0].Rows[0]["LD_NO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_NO"].ToString() : "";
                txtPDDate.Text = dsdd.Tables[0].Rows[0]["LD_PD_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["LD_PD_DATE"]).ToString("dd/MMM/yyyy") : "";
                txtCAMDATE.Text = dsdd.Tables[0].Rows[0]["CAM_DATE"] != DBNull.Value ? Convert.ToDateTime(dsdd.Tables[0].Rows[0]["CAM_DATE"]).ToString("dd/MMM/yyyy") : DateTime.Now.ToString("dd/MMM/yyyy");
                ddlRelationShip.SelectedValue = dsdd.Tables[0].Rows[0]["ER_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ER_ID"].ToString() : "0";
                ddlMainApplicant.SelectedValue = dsdd.Tables[0].Rows[0]["INS_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["INS_ID"].ToString() : "0";
                BindDepndsMainAppln();
                ddlVintage.SelectedValue = dsdd.Tables[0].Rows[0]["VN_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["VN_ID"].ToString() : "0";
                ddlNature.SelectedValue = dsdd.Tables[0].Rows[0]["NT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["NT_ID"].ToString() : "0";
                ddlIncomType.SelectedValue = dsdd.Tables[0].Rows[0]["IT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["IT_ID"].ToString() : "0";
                // ddlLoanPurpose.SelectedValue = dsdd.Tables[0].Rows[0]["PP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PP_ID"].ToString() : "0";
                ddlCreditHistory.SelectedValue = dsdd.Tables[0].Rows[0]["CH_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CH_ID"].ToString() : "0";
                txtApplnName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                txtAddress.Text = dsdd.Tables[0].Rows[0]["CAM_AP_ADD"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AP_ADD"].ToString() : "";
                txtContactNo.Text = dsdd.Tables[0].Rows[0]["LD_ACNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_ACNO"].ToString() : "";
                txtMemberID.Text = dsdd.Tables[0].Rows[0]["LD_MID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_MID"].ToString() : "";
                //ddlPropType.SelectedValue = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "0";
                Bind_Loan_Process();
                ddlLoanProType.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_LP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LP_ID"].ToString() : "0";
                ShowLTProcess();
                txtRegistrationval.Text = dsdd.Tables[0].Rows[0]["CAM_REG_VALUE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_REG_VALUE"].ToString() : "";
                txtFinname.Text = dsdd.Tables[0].Rows[0]["CAM_FIN_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FIN_NAME"].ToString() : "";
                txtLoanAMnt.Text = dsdd.Tables[0].Rows[0]["CAM_FIN_LVALUE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FIN_LVALUE"].ToString() : "";
                txtOutstandingAmt.Text = dsdd.Tables[0].Rows[0]["CAM_FIN_LOUT_VALUE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FIN_LOUT_VALUE"].ToString() : "";
                txtParentLeadNo.Text = dsdd.Tables[0].Rows[0]["CAM_PARENT_LDNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_PARENT_LDNO"].ToString() : "";

                DataSet dsLead = fetchLeadDetails(txtParentLeadNo.Text);
                if (dsLead != null && dsLead.Tables[0].Rows.Count > 0)
                {
                    lblCustName.Text = dsLead.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                    lblAMnt.Text = dsLead.Tables[0].Rows[0]["LD_CRAP_AMT"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_CRAP_AMT"].ToString() : "";
                    lblAppDate.Text = dsLead.Tables[0].Rows[0]["LD_CRAP_DATE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_CRAP_DATE"].ToString() : "";
                    lblDisbDate.Text = dsLead.Tables[0].Rows[0]["LD_LOAN_DATE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_LOAN_DATE"].ToString() : "";

                }
                BindProperty();
                BindConstrStage();
                BindConstrType();
                BindConstrFloor();
                ddlPropType.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_PT_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_PT_ID"].ToString() : "0";
                //ddlConstructionStage.SelectedValue = dsdd.Tables[0].Rows[0]["CS_SCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CS_SCR"].ToString() : "0";
                ddlConstructionStage.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_CS_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CS_ID"].ToString() : "0";
                // ddlConstrType.SelectedValue = dsdd.Tables[0].Rows[0]["CE_RATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CE_RATE"].ToString() : "0";
                ddlConstrType.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_CE_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CE_ID"].ToString() : "0";
                ddlConstFloor.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_CF_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CF_ID"].ToString() : "0";
                BindTenor();
                ddlTenure.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_TENURE"] != DBNull.Value ? Convert.ToInt32(dsdd.Tables[0].Rows[0]["CAM_TENURE"]).ToString() : "";
                // ddlIntrest.SelectedValue = dsdd.Tables[0].Rows[0]["CAM_INR"] != DBNull.Value ? Convert.ToDouble(dsdd.Tables[0].Rows[0]["CAM_INR"]).ToString() : "0";
                string strIntrest = dsdd.Tables[0].Rows[0]["CAM_INR"] != DBNull.Value ? Convert.ToInt32(dsdd.Tables[0].Rows[0]["CAM_INR"]).ToString() : "0";

                ListItem lnIntrst = new ListItem(strIntrest, strIntrest);
                if (ddlIntrest.Items.Contains(lnIntrst))
                {
                    ddlIntrest.SelectedValue = strIntrest;
                }
                else
                {
                    ddlIntrest.SelectedValue = "0";
                }
                txtEMIperLakh.Text = dsdd.Tables[0].Rows[0]["CAM_EPL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EPL"].ToString() : "";
                txtIIREligibility.Text = dsdd.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_IIR"].ToString() : "";
                txtFOIREligibility.Text = dsdd.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "";
                txtLoanAmountRequested.Text = dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAMT_REQ"].ToString() : "";
                txtLoanEligibility.Text = dsdd.Tables[0].Rows[0]["CAM_LN_ELG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LN_ELG"].ToString() : "";

                txtTotalLoanEligibility.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";


                txtbassumedobligation.Text = dsdd.Tables[0].Rows[0]["CAM_HOBLIG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_HOBLIG"].ToString() : "";
                txtAssumdHLoan.Text = dsdd.Tables[0].Rows[0]["CAM_HLOAN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_HLOAN"].ToString() : "";

                btnSubmit.Enabled = false;

                SqlCommand cmddd1 = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY", con);
                cmddd1.Parameters.AddWithValue("@PT_ID", "");
                cmddd1.Parameters.AddWithValue("@PT_TYPE", "G");
                cmddd.Parameters.AddWithValue("@PRODUCT", "G-HF");
                cmddd1.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter dadd1 = new SqlDataAdapter(cmddd1);
                DataSet dsdd1 = new DataSet();
                dadd1.Fill(dsdd1);



                //if (ddlPropType.SelectedItem.Text != "--Select--")
                //{

                //    DataRow[] dr1 = dsdd1.Tables[0].Select("PT_DESC='" + ddlPropType.SelectedItem.Text + "'");
                //    lblSqrft.Text = " @ " + dr1[0].ItemArray[2].ToString() + " / Sqft ";
                //    ddlPropType.Focus();
                //}
                //ddlOccupancyStatus.SelectedValue = dsdd.Tables[0].Rows[0]["OC_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["OC_ID"].ToString() : "0";
                //ddlUsage.SelectedValue = dsdd.Tables[0].Rows[0]["UG_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["UG_ID"].ToString() : "0";
                //txtNoOFtenents.Text = dsdd.Tables[0].Rows[0]["CAM_NOT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_NOT"].ToString() : "";

                string strCamReg = dsdd.Tables[0].Rows[0]["CAM_REGNET"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_REGNET"].ToString() : "";



                txtLandArea.Text = dsdd.Tables[0].Rows[0]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAREA"].ToString() : "";
                txtGuideline.Text = dsdd.Tables[0].Rows[0]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_GLV"].ToString() : "";
                txtMarketValueSqrt.Text = dsdd.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
                txtConsidered.Text = dsdd.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CLV"].ToString() : "";
                //txtBuildUpArea.Text = dsdd.Tables[0].Rows[0]["CAM_BAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BAREA"].ToString() : "";
                //txtSqft.Text = dsdd.Tables[0].Rows[0]["CAM_SQFT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_SQFT"].ToString() : "";
                //txtBuildingValue.Text = dsdd.Tables[0].Rows[0]["CAM_BV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BV"].ToString() : "";
                //ddlAgeOfBuilding.SelectedValue = dsdd.Tables[0].Rows[0]["BA_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BA_ID"].ToString() : "0";
                //txtDepreciation.Text = dsdd.Tables[0].Rows[0]["CAM_DEP"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_DEP"].ToString() : "";
                //txtonsideredBuilding.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
                //txtTotalPropertyValue.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
                //txtLTVonProperty.Text = dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
                //txtRecommendedLoan.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
                txtConstrArea.Text = dsdd.Tables[0].Rows[0]["CAM_BAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BAREA"].ToString() : "";

                SqlCommand cmddd11 = new SqlCommand("RTS_SP_fetch_GHF_datas", con);
                cmddd11.Parameters.AddWithValue("@LreqAmt", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
                cmddd11.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter dadd11 = new SqlDataAdapter(cmddd11);
                DataSet dsdd11 = new DataSet();
                dadd11.Fill(dsdd11);
                DataTable dtBlvAl = dsdd11.Tables[0];
                double nSqrftVal = Convert.ToDouble(txtConstrArea.Text) * Convert.ToDouble(dtBlvAl.Rows[0][0]);
                txConVal1.Text = nSqrftVal.ToString();
                txtSqft.Text = dsdd.Tables[0].Rows[0]["CAM_SQFT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_SQFT"].ToString() : "";
                txtAmunity.Text = dsdd.Tables[0].Rows[0]["CAM_AMENITIES"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AMENITIES"].ToString() : "";
                txConVal.Text = dsdd.Tables[0].Rows[0]["CAM_BV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_BV"].ToString() : "";

                txtConstrCost.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
                txtIIRasPerLoan.Text = dsdd.Tables[0].Rows[0]["CAM_IIR_PER"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_IIR_PER"].ToString() : "";
                txtLCRAsPerLoan.Text = dsdd.Tables[0].Rows[0]["CAM_LCR_PER"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LCR_PER"].ToString() : "";
                txtIIRLCR.Text = dsdd.Tables[0].Rows[0]["CAM_IIR_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_IIR_LCR"].ToString() : "";
                txtTotalPropCost.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
                txtLoanEligibleLCR.Text = dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
                txtFinancialLoanAmt.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";

                txtNameofInsuredPerson.Text = dsdd.Tables[0].Rows[0]["CAM_PCS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_PCS"].ToString() : "";

                txtAgriLandAcres.Text = dsdd.Tables[0].Rows[0]["CAM_AGL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGL"].ToString() : "";
                txtAgriIncome.Text = dsdd.Tables[0].Rows[0]["CAM_AGI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_AGI"].ToString() : "";

                txtDeviation.Text = dsdd.Tables[0].Rows[0]["CAM_DEVIATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_DEVIATE"].ToString() : "";
                if (dsdd.Tables[1] != null && dsdd.Tables[1].Rows.Count > 0)
                {
                    gvIncomeDetail.DataSource = dsdd.Tables[1];
                    gvIncomeDetail.DataBind();
                    BindBorrower(dsdd.Tables[1]);
                    ViewState["CurrentTable"] = dsdd.Tables[1];
                    for (int n = 0; n < dsdd.Tables[1].Rows.Count; n++)
                    {
                        string strText = dsdd.Tables[1].Rows[n]["NAME"].ToString();
                        int nIndex = DDLkycName.Items.IndexOf(DDLkycName.Items.FindByText(strText));
                        //  DDLkycName.Items.RemoveAt(nIndex);
                    }
                    DataTable dtCurrentTable = dsdd.Tables[1];
                    double nTotalLoanEligibility = 0.0;
                    for (int n = 0; n < dtCurrentTable.Rows.Count; n++)
                    {
                        double nTempVal = dtCurrentTable.Rows[n]["FACTORED_INCOME"] != DBNull.Value ? Convert.ToDouble(dtCurrentTable.Rows[n]["FACTORED_INCOME"]) : 0.0;
                        string strIncomeSource = dtCurrentTable.Rows[n]["INCOME_SOURCE"] != DBNull.Value ? dtCurrentTable.Rows[n]["INCOME_SOURCE"].ToString() : "";
                        nTotalLoanEligibility = nTotalLoanEligibility + nTempVal;

                        if (strIncomeSource.Contains("RENT"))
                        {
                            if (txtbxsumofrental.Text == "")
                            {
                                txtbxsumofrental.Text = Convert.ToDouble(nTempVal).ToString();
                            }
                            else
                            {

                                txtbxsumofrental.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxsumofrental.Text)).ToString();
                            }
                        }
                        else if (strIncomeSource.Contains("PENSION"))
                        {
                            if (txtPensionIncome.Text == "")
                            {
                                txtPensionIncome.Text = Convert.ToDouble(nTempVal).ToString();
                            }
                            else
                            {

                                txtPensionIncome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtPensionIncome.Text)).ToString();
                            }
                        }
                        else
                        {
                            if (txtbxotherincome.Text == "")
                            {
                                txtbxotherincome.Text = Convert.ToDouble(nTempVal).ToString();
                            }
                            else
                            {

                                txtbxotherincome.Text = (Convert.ToDouble(nTempVal) + Convert.ToDouble(txtbxotherincome.Text)).ToString();
                            }
                        }
                        double rent = 0.0;
                        double Pension = 0.0;
                        double other = 0.0;

                        if (txtbxsumofrental.Text != "")
                        {
                            rent = Convert.ToDouble(txtbxsumofrental.Text);
                        }
                        if (txtPensionIncome.Text != "")
                        {
                            Pension = Convert.ToDouble(txtPensionIncome.Text);
                        }
                        if (txtbxotherincome.Text != "")
                        {
                            other = Convert.ToDouble(txtbxotherincome.Text);
                        }


                    }

                    string rentalincome = txtbxsumofrental.Text == "" ? "0" : txtbxsumofrental.Text;
                    txtrentalloaneligibilityincome.Text = Convert.ToString(Math.Min(Convert.ToDecimal(rentalincome), Convert.ToDecimal(txtbxotherincome.Text)));
                    //   DDLkycName.DataBind();
                }


                if (dsdd.Tables[2] != null && dsdd.Tables[2].Rows.Count > 0)
                {
                    for (int i = 0; i < dsdd.Tables[2].Rows.Count; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                ddlLoanType1.SelectedValue = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value && dsdd.Tables[2].Rows[i]["CO_TYPE"] !="" ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                txtFinanciear1.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                ddlSource1.SelectedValue = dsdd.Tables[2].Rows[i]["CO_SOURCE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_SOURCE"].ToString() : "";
                                drpName1.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                txtEMIAmount1.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtBALEMIAmount1.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                txtcibil1.Text = dsdd.Tables[2].Rows[i]["CO_CIBIL"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_CIBIL"].ToString() : "";
                                break;
                            case 1:
                                ddlLoanType2.SelectedValue = dsdd.Tables[2].Rows[i]["CO_TYPE"]  != DBNull.Value && dsdd.Tables[2].Rows[i]["CO_TYPE"] != "" ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                txtFinanciear2.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName2.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                ddlSource2.SelectedValue = dsdd.Tables[2].Rows[i]["CO_SOURCE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_SOURCE"].ToString() : "";
                                txtEMIAmount2.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtBALEMIAmount2.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                txtcibil2.Text = dsdd.Tables[2].Rows[i]["CO_CIBIL"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_CIBIL"].ToString() : "";
                                break;
                            case 2:
                                ddlLoanType3.SelectedValue = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value && dsdd.Tables[2].Rows[i]["CO_TYPE"] != "" ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                txtFinanciear3.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName3.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                ddlSource3.SelectedValue = dsdd.Tables[2].Rows[i]["CO_SOURCE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_SOURCE"].ToString() : "";
                                txtEMIAmount3.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtBALEMIAmount3.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                txtcibil3.Text = dsdd.Tables[2].Rows[i]["CO_CIBIL"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_CIBIL"].ToString() : "";
                                break;
                            case 3:
                                ddlLoanType4.SelectedValue = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value && dsdd.Tables[2].Rows[i]["CO_TYPE"] != "" ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                txtFinanciear4.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName4.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                ddlSource4.SelectedValue = dsdd.Tables[2].Rows[i]["CO_SOURCE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_SOURCE"].ToString() : "";
                                txtEMIAmount4.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtBALEMIAmount4.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                txtcibil4.Text = dsdd.Tables[2].Rows[i]["CO_CIBIL"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_CIBIL"].ToString() : "";
                                break;
                            case 4:
                                ddlLoanType5.SelectedValue = dsdd.Tables[2].Rows[i]["CO_TYPE"] != DBNull.Value && dsdd.Tables[2].Rows[i]["CO_TYPE"] != "" ? dsdd.Tables[2].Rows[i]["CO_TYPE"].ToString() : "";
                                txtFinanciear5.Text = dsdd.Tables[2].Rows[i]["CO_FIN"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_FIN"].ToString() : "";
                                drpName5.SelectedValue = dsdd.Tables[2].Rows[i]["CO_BORW"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BORW"].ToString() : "";
                                ddlSource5.SelectedValue = dsdd.Tables[2].Rows[i]["CO_SOURCE"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_SOURCE"].ToString() : "";
                                txtEMIAmount5.Text = dsdd.Tables[2].Rows[i]["CO_AMOUNT"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_AMOUNT"].ToString() : "";
                                txtBALEMIAmount5.Text = dsdd.Tables[2].Rows[i]["CO_BAL_EMI"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_BAL_EMI"].ToString() : "";
                                txtcibil5.Text = dsdd.Tables[2].Rows[i]["CO_CIBIL"] != DBNull.Value ? dsdd.Tables[2].Rows[i]["CO_CIBIL"].ToString() : "";
                                break;
                        }
                    }
                }

                txtTotalEMIAmount.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";
                txtEmpCode.Text = dsdd.Tables[0].Rows[0]["CAM_EMP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_EMP_ID"].ToString() : "";
                BindEMpDets();

                #region CRE
                /// CRE - NON CRE 

                if (dsdd.Tables[0].Rows[0]["CAM_CRE"] != DBNull.Value)
                {
                    if (ddlCreNonCre.Items.FindByText(Convert.ToString(dsdd.Tables[0].Rows[0]["CAM_CRE"])) != null)
                    {
                        ddlCreNonCre.ClearSelection();
                        ddlCreNonCre.Items.FindByText(dsdd.Tables[0].Rows[0]["CAM_CRE"].ToString()).Selected = true;
                    }
                    else
                    {
                        ddlCreNonCre.SelectedIndex = 0;
                    }
                }
                #endregion

            }
            con.Close();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void BindDepndsMainAppln()
    {
        if (ddlMainApplicant.SelectedIndex > 0)
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_VINTAGE", con);

            cmddd.Parameters.AddWithValue("@VN_ID", "");
            cmddd.Parameters.AddWithValue("@VN_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlVintage.DataSource = dsdd;
            ddlVintage.DataTextField = "VN_DESC";
            ddlVintage.DataValueField = "VN_ID";
            ddlVintage.DataBind();
            ddlVintage.Items.Insert(0, new ListItem("--Select--", "0"));



            ddlNature.Items.Clear();
            con = new SqlConnection(strcon);
            con.Open();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_NATURE", con);
            cmddd.Parameters.AddWithValue("@NT_ID", "");
            cmddd.Parameters.AddWithValue("@NT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlNature.DataSource = dsdd;
            ddlNature.DataTextField = "NT_DESC";
            ddlNature.DataValueField = "NT_ID";
            ddlNature.DataBind();
            ddlNature.Items.Insert(0, new ListItem("--Select--", "0"));


            ddlIncomType.Items.Clear();
            cmddd = new SqlCommand("RTS_SP_Fetch_MR_INCOME_TYPE", con);
            cmddd.Parameters.AddWithValue("@IT_ID", "");
            //cmddd.Parameters.AddWithValue("@IT_INS_ID", ddlMainApplicant.SelectedValue.ToString());
            cmddd.Parameters.AddWithValue("@IT_INS_ID", "");
            cmddd.CommandType = CommandType.StoredProcedure;
            dadd = new SqlDataAdapter(cmddd);
            dsdd = new DataSet();
            dadd.Fill(dsdd);


            ddlIncomType.DataSource = dsdd;
            ddlIncomType.DataTextField = "IT_DESC";
            ddlIncomType.DataValueField = "IT_ID";
            ddlIncomType.DataBind();
            ddlIncomType.Items.Insert(0, new ListItem("--Select--", "0"));

            con.Close();
        }
    }
    protected void btnGo_Click(object sender, EventArgs e)
    {
        BindLeadNo();
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindFinalBranch();
    }
    protected void txtSqft_TextChanged(object sender, EventArgs e)
    {
        try
        {
            btnSubmit.Enabled = false;
            DataTable dtDataG;
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_fetch_GHF_datas", con);
            cmddd.Parameters.AddWithValue("@LreqAmt", txtLoanAmountRequested.Text != "" ? Convert.ToDouble(txtLoanAmountRequested.Text) : 0.0);
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            dtDataG = dsdd.Tables[0];
            con.Close();

            double nSqrftVal = 0, nSqrftVal1 = 0;
            if (txtConstrArea.Text != "" && txtSqft.Text != "")
            {
                //nSqrftVal = Convert.ToDouble(txtBuildUpArea.Text) * Convert.ToDouble(lblSqrft.Text.Substring(2, lblSqrft.Text.IndexOf('/') - 2).Trim());
                nSqrftVal = Convert.ToDouble(txtConstrArea.Text) * Convert.ToDouble(dtDataG.Rows[0][0]);
                txConVal1.Text = nSqrftVal.ToString();
               //bala changes 29052018 int nsqft = txtSqft.Text != "" ? Convert.ToInt32(txtSqft.Text) : 0;
                double nsqft = txtSqft.Text != "" ? Convert.ToDouble(txtSqft.Text) : 0;
                nSqrftVal1 = Convert.ToDouble(txtConstrArea.Text) * Convert.ToDouble(nsqft);
                double nMinBArea = Math.Min(nSqrftVal, nSqrftVal1);
                // txtBuildingValue.Text = Convert.ToInt32(nMinBArea).ToString();
                txConVal.Text = nSqrftVal1.ToString();
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void txtEmpCode_TextChanged(object sender, EventArgs e)
    {
        BindEMpDets();
    }
    protected void BindEMpDets()
    {
        try
        {

            if (txtEmpCode.Text.Length == 4)
            {
                txtEmpCode.Text = "0" + txtEmpCode.Text;
            }
            else if (txtEmpCode.Text.Length == 4)
            {
                txtEmpCode.Text = "00" + txtEmpCode.Text;
            }
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("SELECT * from HR_EMP_DETS WHERE EMP_CODE='" + txtEmpCode.Text + "'", con);

            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
            {
                txtEMpID.Text = dsdd.Tables[0].Rows[0]["EMP_ID"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_ID"].ToString() : "";
                txtEMpNAme.Text = dsdd.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
               // txtDesgn.Text = dsdd.Tables[0].Rows[0]["ET_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["ET_DESC"].ToString() : "";
                txtDesgn.Text = dsdd.Tables[0].Rows[0]["EMP_DESIGN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_DESIGN"].ToString() : "";
                txtContact.Text = dsdd.Tables[0].Rows[0]["EMP_PHNO"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_PHNO"].ToString() : "";

                ttxEmailEmp.Text = dsdd.Tables[0].Rows[0]["EMP_EMAIL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_EMAIL"].ToString() : "";
                txtEmpCompany.Text = dsdd.Tables[0].Rows[0]["EMP_COMPANY"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_COMPANY"].ToString() : "";
                txtDOJ.Text = dsdd.Tables[0].Rows[0]["EMP_DOJ"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_DOJ"].ToString() : "";
                txtGrade.Text = dsdd.Tables[0].Rows[0]["EMP_GRADE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_GRADE"].ToString() : "";
                txtEMpNAme.Enabled = false;
                txtDesgn.Enabled = false;
                txtContact.Enabled = false;
                ttxEmailEmp.Enabled = false;
                txtEmpCompany.Enabled = false;
                txtDOJ.Enabled = false;
                txtGrade.Enabled = false;
            }
            else
            {
                txtEMpID.Text = "";
                txtEMpNAme.Text = "";
                txtDesgn.Text = "";
                txtContact.Text = "";
                ttxEmailEmp.Text = "";
                txtEmpCompany.Text = "";
                txtDOJ.Text = "";
                txtGrade.Text = "";

                txtEMpNAme.Enabled = true;
                txtDesgn.Enabled = true;
                txtContact.Enabled = true;
                ttxEmailEmp.Enabled = true;
                txtEmpCompany.Enabled = true;
                txtDOJ.Enabled = true;
                txtGrade.Enabled = true;
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlLoanProType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            btnSubmit.Enabled = false;
            ShowLTProcess();
            BindProperty();
            BindConstrStage();
            BindConstrType();
            BindConstrFloor();
            Session["LP_PER"] = clscommon.GetLoanType_Percentage(Convert.ToInt32(ddlLoanProType.SelectedValue));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ShowLTProcess()
    {
        txtRegistrationval.Text = "";
        txtFinname.Text = "";
        txtLoanAMnt.Text = "";
        txtOutstandingAmt.Text = "";
        txtParentLeadNo.Text = "";
        lblCustName.Text = "";
        lblAMnt.Text = "";
        lblAppDate.Text = "";
        lblDisbDate.Text = "";


        trLoanProcesHead.Visible = true;
        trRegAmount.Visible = false;
        trFinDetails.Visible = false;
        trLondets1.Visible = false;
        trLondets2.Visible = false;
        if (ddlLoanProType.SelectedItem.Text == "Home Purchase" || ddlLoanProType.SelectedItem.Text == "Composite Loan - Land")
        {
            trRegAmount.Visible = true;
        }

        else if (ddlLoanProType.SelectedItem.Text == "BT")
        {
            trFinDetails.Visible = true;
        }
        else if (ddlLoanProType.SelectedItem.Text == "Top Up")
        {
            trLondets1.Visible = true;
            trLondets2.Visible = true;
        }
    }
    protected void txtParentLeadNo_TextChanged(object sender, EventArgs e)
    {
        DataSet dsLead = fetchLeadDetails(txtParentLeadNo.Text);
        if (dsLead != null && dsLead.Tables[0].Rows.Count > 0)
        {
            lblCustName.Text = dsLead.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
            lblAMnt.Text = dsLead.Tables[0].Rows[0]["LD_CRAP_AMT"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_CRAP_AMT"].ToString() : "";
            lblAppDate.Text = dsLead.Tables[0].Rows[0]["LD_CRAP_DATE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_CRAP_DATE"].ToString() : "";
            lblDisbDate.Text = dsLead.Tables[0].Rows[0]["LD_LOAN_DATE"] != DBNull.Value ? dsLead.Tables[0].Rows[0]["LD_LOAN_DATE"].ToString() : "";

        }

    }

    public void CalculateLTVPercentage()
    {
        try
        {
            string strval = this.txtTotalEMIAmount.Text;
            double presentValue = 100000;
            double financingPeriod = 0.0;
            double interestRatePerYear = 0.0;
            double IIREligibilit = 0.0;
            double FOIREligibility = 0.0;
            double AgriIncome = 0.0;
            double assumeobligation = 0.0;
            double AssumdHLoan = 0.0;
            double EMIperLakh = 0.0;
            double LoanEligibility = 0.0;
            double LoanEligibilitywthotass = 0.0;
            double FOIREligibilitywthotass = 0.0;
            double RecommendLoan = 0.0;
            double RecommenLoan1 = 0.0;
            double TotalPropCost = 0.0;
            double dLandArea = 0.0;
            double Considered = 0.0;
            double dMarketValue = 0.0;
            double ConstrCost = 0.0;
            double Ltv1 = 0.0;
            double Ltv2 = 0.0;
            if (txtAgriIncome.Text != "")
            {
                AgriIncome = Convert.ToDouble(txtAgriIncome.Text);
            }
            if (ddlTenure.SelectedItem.Text != "")
            {
                financingPeriod = Convert.ToDouble(ddlTenure.SelectedItem.Text) * 12;
            }
            if (ddlIntrest.SelectedItem.Text != "--Select--")
            {
                interestRatePerYear = Convert.ToDouble(ddlIntrest.SelectedItem.Text);
            }

            if (txtLoanAmountRequested.Text != "")
            {
                if (Convert.ToDouble(txtLoanAmountRequested.Text) > Convert.ToDouble(1500000))
                {
                    AssumdHLoan = Convert.ToDouble(Convert.ToDouble(txtLoanAmountRequested.Text) * 10 / 100);
                    assumeobligation = Convert.ToDouble((Convert.ToDouble(AssumdHLoan)) * 3 / 100);
                }

            }


            EMIperLakh = GetEMI(presentValue, financingPeriod, interestRatePerYear);
            //IIREligibilit = (((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 40 / 100) / (EMIperLakh)) * 100000;
            IIREligibilit = (((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 50 / 100) / (EMIperLakh)) * 100000;
            FOIREligibility = ((((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 50 / 100) - (Convert.ToDouble(txtTotalEMIAmount.Text != "" ? txtTotalEMIAmount.Text : "0.0") + assumeobligation)) / EMIperLakh) * 100000;
            FOIREligibilitywthotass = ((((Convert.ToDouble(txtTotalLoanEligibility.Text) + AgriIncome) * 50 / 100) - (Convert.ToDouble(txtTotalEMIAmount.Text != "" ? txtTotalEMIAmount.Text : "0.0"))) / EMIperLakh) * 100000;

            if (IIREligibilit <= FOIREligibility)
            {
                LoanEligibility = Convert.ToInt32(IIREligibilit);
            }
            else if (IIREligibilit > FOIREligibility)
            {
                LoanEligibility = Convert.ToInt32(FOIREligibility);
            }

            if (IIREligibilit <= FOIREligibilitywthotass)
            {
                LoanEligibilitywthotass = Convert.ToInt32(IIREligibilit);
            }
            else if (IIREligibilit > FOIREligibilitywthotass)
            {
                LoanEligibilitywthotass = Convert.ToInt32(FOIREligibilitywthotass);
            }

            string txtMarketValue = txtMarketValueSqrt.Text.Trim();
            string txtLndArea = txtLandArea.Text.Trim();

            if (!string.IsNullOrEmpty(txtMarketValue) && !string.IsNullOrEmpty(txtLndArea))
            {
                dLandArea = Convert.ToDouble(txtLandArea.Text);
                dMarketValue = Convert.ToDouble(txtMarketValueSqrt.Text);

                if (dMarketValue > 0 && dLandArea > 0)
                {
                    Considered = Convert.ToDouble(dMarketValue * dLandArea);
                }
            }

            if (txtConstrArea.Text != "")
            {

                double nAmnt1 = Convert.ToDouble(txConVal.Text) + Convert.ToDouble(txtAmunity.Text != "" ? txtAmunity.Text : "0");
                double nAmnt2 = Convert.ToDouble(txConVal1.Text);
                double nMin = Math.Min(nAmnt1, nAmnt2);

                ConstrCost = nMin;
                // txtConstrCost.Text = Convert.ToString(Convert.ToDouble(ddlConstrType.SelectedValue) * Convert.ToDouble(txtConstrArea.Text));

                if (Considered != 0.0)
                {
                    TotalPropCost = ConstrCost + Considered;
                }
            }



            if (txtLoanAmountRequested.Text != "" && LoanEligibility != 0.0)
            {
                RecommendLoan = calculateLTV(LoanEligibility, ConstrCost, Considered);
            }
            if (txtLoanAmountRequested.Text != "" && LoanEligibilitywthotass != 0.0)
            {
                RecommenLoan1 = calculateLTV(LoanEligibilitywthotass, ConstrCost, Considered);
            };

            Ltv1 = (RecommendLoan / TotalPropCost) * 100;
            Ltv2 = (RecommenLoan1 / TotalPropCost) * 100;

            if (Ltv1 < 50 && Ltv2 < 50)
            {
                hdnltv.Value = "1";
            }
            else
            {
                hdnltv.Value = "0";
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }


    public double calculateLTV(double LoanEligibility, double ConstrCost, double Considered)
    {
        double FinancialLoanAmt = 0.0;
        double LoanEligibleLCR = 0.0;
        int loantype_per = 0;
        //Session["LP_PER"] = clscommon.GetLoanType_Percentage(Convert.ToInt32(ddlLoanProType.SelectedValue));
        loantype_per = Convert.ToInt32(Session["LP_PER"].ToString());


        if (ConstrCost != 0.0)
        {

            double dblloanelig = txtAgriIncome.Text != "" ? Convert.ToDouble(txtAgriIncome.Text) : 0;
            dblloanelig = dblloanelig + Convert.ToDouble(txtTotalLoanEligibility.Text);

            //bala changes 03/07/2017
            // txtLoanEligibleLCR.Text = Convert.ToString(Convert.ToDouble(txtConstrCost.Text) * 80 / 100);
            LoanEligibleLCR = clscommon.Get_LCR_LTV_Calc_Amt(Convert.ToDouble(ConstrCost), Convert.ToDouble(Considered), Convert.ToInt32(ddlLoanProType.SelectedValue), loantype_per);

            double dMinVal1 = Math.Min(Convert.ToDouble(txtLoanAmountRequested.Text), LoanEligibility);
            double dMinVal2 = Math.Min(dMinVal1, LoanEligibleLCR);
            if (txtRegistrationval.Text != "")
            {
                dMinVal2 = Math.Min(dMinVal2, Convert.ToDouble(txtRegistrationval.Text));
            }
            if (txtOutstandingAmt.Text != "")
            {
                dMinVal2 = Math.Min(dMinVal2, Convert.ToDouble(txtOutstandingAmt.Text));
            }
            FinancialLoanAmt = dMinVal2;
        }


        return FinancialLoanAmt;
    }
}