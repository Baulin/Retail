﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using System.Text.RegularExpressions;
using System.Net.Mail;
using Utilities;
using Tracker;
using Utilities.SessionKeys;
using DataObjects.Credit;
using Utilities.Enums;

public partial class AMCIApproval : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    Regex Rx = new Regex("^[0-9]+$");
    ClsCommon clscommon = new ClsCommon();
    public static bool blMailStatus = false;
    public static string frmID = "", toID = "", bccID = "", ccID = "", strMailBody = "";
    public string area = "", brnch = "", ldno = "", prod = "", aname = "";
    public string approvedloanamt = "";
    public string bme = "", ocie = "", variance = "", scicmts = "", rpt = "";
    public int arid, brid, dvid;
    CreateLogFiles Err = new CreateLogFiles();
    Thread mail;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["ID"] != null)
        {
            trspotppd.Visible = false;
            if (!IsPostBack)
            {
                bind();
                BindLeadNo();
                ddl_spotppd.Visible = false;
                txtothers.Visible = false;
                tdcategory1.Visible = false;
                trspotppd.Visible = false;

                //if (Session["EMPTYPEID"] != null)
                //{
                //    if (Session["EMPTYPEID"].ToString() == "18")
                //    {
                //        ddlArea.Enabled = false;
                //    }
                //    else
                //    {
                //        ddlArea.Enabled = true;
                //    }
                //}
            }
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_State", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@StateID", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, "--Select--");
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();
        //  SqlConnection con = new SqlConnection(strcon);
        con.Open();

        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, "--Select--");
        ddlBranch.Enabled = true;
    }
    public void BindLeadNo()
    {

        ////
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        //  SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_Lead_For_Sampling_Report", con);
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAM_Lead_For_Sampling_Report1", con);
        cmddd.Parameters.AddWithValue("@LD_NO", "");
        cmddd.Parameters.AddWithValue("@Lead_Type", "");
        cmddd.Parameters.AddWithValue("@Area", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue : "");
        cmddd.Parameters.AddWithValue("@Branch", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue : "");
        cmddd.Parameters.AddWithValue("@PROD","GEN");
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlLeadNo.DataSource = dsdd;
        ddlLeadNo.DataTextField = "LD_NO";
        ddlLeadNo.DataValueField = "LD_ID";
        ddlLeadNo.DataBind();
        ddlLeadNo.Items.Insert(0, "Select");
    }
    protected void ddlLeadNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlLeadNo.SelectedIndex > 0)
        {
            // clear();
            GenerateReport();
        }
        else if (ddlLeadNo.SelectedIndex == 0)
        {
            Clear();
        }
    }
    public void GenerateReport()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CAMSummary_Report", con);
        cmddd.Parameters.AddWithValue("@Lead_ID", ddlLeadNo.SelectedValue.ToString());
        cmddd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);


        if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
        {
            lblBranchName.Text = dsdd.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BR_NAME"].ToString() : "";
            lblCustomerName.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";

            lblNetIncomeafterfactoring.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_IN"].ToString() : "";
            lblNetIncomeafterfactoring_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TOT_IN"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TOT_IN"].ToString() : "";
            if (lblNetIncomeafterfactoring.Text != "" && lblNetIncomeafterfactoring_CI.Text != "")
            {
                lblNetIncomeafterfactoring_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblNetIncomeafterfactoring_CI.Text) * 100) / Convert.ToDouble(lblNetIncomeafterfactoring.Text)));
            }

            lblObligation.Text = dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TOT_EMI"].ToString() : "";
            lblObligation_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TOT_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TOT_EMI"].ToString() : "";

            if (lblObligation.Text != "" && lblObligation_CI.Text != "")
            {
                lblObligation_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblObligation_CI.Text) * 100) / Convert.ToDouble(lblObligation.Text)));
            }

            lblLandSQFT.Text = dsdd.Tables[0].Rows[0]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_LAREA"].ToString() : "";
            lblLandSQFT_CI.Text = dsdd.Tables[0].Rows[1]["CAM_LAREA"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_LAREA"].ToString() : "";
            if (lblLandSQFT.Text != "" && lblLandSQFT_CI.Text != "")
            {
                lblLandSQFT_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblLandSQFT_CI.Text) * 100) / Convert.ToDouble(lblLandSQFT.Text)));
            }

            lblReginet.Text = dsdd.Tables[0].Rows[0]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_GLV"].ToString() : "";
            lblReginet_CI.Text = dsdd.Tables[0].Rows[1]["CAM_GLV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_GLV"].ToString() : "";

            if (lblReginet.Text != "" && lblReginet_CI.Text != "")
            {
                lblReginet_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblReginet_CI.Text) * 100) / Convert.ToDouble(lblReginet.Text)));
            }


            lblMarketvalue.Text = dsdd.Tables[0].Rows[0]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_MV"].ToString() : "";
            lblMarketvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_MV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_MV"].ToString() : "";
            if (lblMarketvalue.Text != "" && lblMarketvalue_CI.Text != "")
            {
                lblMarketvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblMarketvalue_CI.Text) * 100) / Convert.ToDouble(lblMarketvalue.Text)));
            }

            lblTotalLandvalue.Text = dsdd.Tables[0].Rows[0]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CLV"].ToString() : "";
            lblTotalLandvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_CLV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_CLV"].ToString() : "";
            if (lblTotalLandvalue.Text != "" && lblTotalLandvalue_CI.Text != "")
            {
                lblTotalLandvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblTotalLandvalue_CI.Text) * 100) / Convert.ToDouble(lblTotalLandvalue.Text)));
            }

            lblBuildingType.Text = dsdd.Tables[0].Rows[0]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PT_DESC"].ToString() : "";
            lblBuildingType_CI.Text = dsdd.Tables[0].Rows[1]["PT_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["PT_DESC"].ToString() : "";


            lblAgeofbuilding.Text = dsdd.Tables[0].Rows[0]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["BA_DESC"].ToString() : "";
            lblAgeofbuilding_CI.Text = dsdd.Tables[0].Rows[1]["BA_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["BA_DESC"].ToString() : "";

            if (Rx.IsMatch(lblAgeofbuilding.Text) && Rx.IsMatch(lblAgeofbuilding_CI.Text))
            {
                if (lblAgeofbuilding.Text != "" && lblAgeofbuilding_CI.Text != "")
                {
                    lblAgeofbuilding_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblAgeofbuilding_CI.Text) * 100) / Convert.ToDouble(lblAgeofbuilding.Text)));
                }
            }
            else
            {
            }

            lblBuildingValue.Text = dsdd.Tables[0].Rows[0]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_CBV"].ToString() : "";
            lblBuildingValue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_CBV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_CBV"].ToString() : "";
            if (lblBuildingValue.Text != "" && lblBuildingValue_CI.Text != "")
            {
                lblBuildingValue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblBuildingValue_CI.Text) * 100) / Convert.ToDouble(lblBuildingValue.Text)));
            }

            lblTotalpropertyvalue.Text = dsdd.Tables[0].Rows[0]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_TPV"].ToString() : "";
            lblTotalpropertyvalue_CI.Text = dsdd.Tables[0].Rows[1]["CAM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_TPV"].ToString() : "";
            if (lblTotalpropertyvalue.Text != "" && lblTotalpropertyvalue_CI.Text != "")
            {
                lblTotalpropertyvalue_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblTotalpropertyvalue_CI.Text) * 100) / Convert.ToDouble(lblTotalpropertyvalue.Text)));
            }

            lblLoanamountrecommeded.Text = dsdd.Tables[0].Rows[0]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CAM_RLA"].ToString() : "";
            lblLoanamountrecommeded_CR.Text = dsdd.Tables[0].Rows[1]["CAM_RLA"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["CAM_RLA"].ToString() : "";
            if (ddlLeadNo.SelectedItem.ToString().Contains("MSE"))
            {
                lblBMEndUse.Text = dsdd.Tables[0].Rows[0]["PP_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PP_DESC"].ToString() : "";
                lblOCIEndUse.Text = dsdd.Tables[0].Rows[1]["PP_DESC"] != DBNull.Value ? dsdd.Tables[0].Rows[1]["PP_DESC"].ToString() : "";
                trEndUse.Visible = true;
            }
            else
                if (ddlLeadNo.SelectedItem.ToString().Contains("ASL") || ddlLeadNo.SelectedItem.ToString().Contains("SMFL"))
                {
                    lblBMEndUse.Text = clscommon.GetFormerActivity(ddlLeadNo.SelectedValue.ToString(), "B");
                    lblOCIEndUse.Text = clscommon.GetSubFormerActivity(ddlLeadNo.SelectedValue.ToString(), "S");
                    trEndUse.Visible = true;
                }
                else
                {
                    trEndUse.Visible = false;
                }
            if (lblLoanamountrecommeded.Text != "" && lblLoanamountrecommeded_CR.Text != "")
            {
                lblLoanamountrecommeded_Var.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblLoanamountrecommeded_CR.Text) * 100) / Convert.ToDouble(lblLoanamountrecommeded.Text)));
            }

            if (dsdd.Tables[3] != null && dsdd.Tables[3].Rows.Count > 0)
            {
                trRpa1.Visible = false;
                trRpa2.Visible = true;

                lblBMGvalue.Text = lblReginet.Text;
                lblFROGvalue.Text = dsdd.Tables[3].Rows[0]["RPA_GV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_GV"].ToString() : "";
                if (lblBMGvalue.Text != "" && lblFROGvalue.Text != "")
                {
                    lblVarGvalue.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFROGvalue.Text) * 100) / Convert.ToDouble(lblBMGvalue.Text)));
                }

                lblBMMarkVal.Text = lblMarketvalue.Text;
                lblFORMarkVal.Text = dsdd.Tables[3].Rows[0]["RPA_MV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_MV"].ToString() : "";
                if (lblBMMarkVal.Text != "" && lblFORMarkVal.Text != "")
                {
                    lblVarMarkVal.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFORMarkVal.Text) * 100) / Convert.ToDouble(lblBMMarkVal.Text)));
                }

                lblBMLandArea.Text = lblLandSQFT.Text;
                lblFORLandArea.Text = dsdd.Tables[3].Rows[0]["RPA_LAREA"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_LAREA"].ToString() : "";
                if (lblFORLandArea.Text != "" && lblBMLandArea.Text != "")
                {
                    lblVarLandArea.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblFORLandArea.Text) * 100) / Convert.ToDouble(lblBMLandArea.Text)));
                }

                lblBMLandValue.Text = lblTotalLandvalue.Text;
                lblForLandValue.Text = dsdd.Tables[3].Rows[0]["RPA_LV"] != DBNull.Value ? dsdd.Tables[3].Rows[0]["RPA_LV"].ToString() : "";
                if (lblBMLandValue.Text != "" && lblForLandValue.Text != "")
                {
                    lblVarLandValue.Text = Convert.ToString(100 - Math.Round((Convert.ToDouble(lblForLandValue.Text) * 100) / Convert.ToDouble(lblBMLandValue.Text)));
                }
            }
            else
            {
                trRpa1.Visible = true;
                trRpa2.Visible = false;
            }
        }
    }
    protected void ddlApproove_SelectedIndexChanged(object sender, EventArgs e)
    {


        if (ddlApproove.SelectedItem.Text == "Recommended")
        {
            //rdnSpot.Checked = false;
            //rdnPDD.Checked = false;
            //rdnBussEmpRelated.Checked = false;
            //rdnIncomeRelated.Checked = false;
            //rdnPropRelated.Checked = false;
            //rdnVerRelated.Checked = false;
            //rdnBussEmpRel.Checked = false;
            //rdnBussEmpRe2.Checked = false;
            //rdbIncomeTolerance.Checked = false;
            //rdnBuildAge.Checked = false;
            //rdnBuildArea.Checked = false;
            //rdnIncorrectBuildDet.Checked = false;
            //rdnVerRel.Checked = false;
            //trResult.Visible = false;
            //trSPot.Visible = false;
            //trBussEmpRelt.Visible = false;
            //trIncomeTol.Visible = false;
            //trPropRel.Visible = false;

            rdnSpot.Checked = false;
            rdnPDD.Checked = false;
            rdnOthers.Checked = false;
            trResult.Visible = false;
            txtFinalRcmnd.Visible = true;
            lblFinalRecmnd.Visible = true;
            ddl_spotppd.Visible = false;

        }
        else if (ddlApproove.SelectedItem.Text == "Rejected")
        {
            trResult.Visible = true;
            // trspotppd.Visible = true;
            ddl_spotppd.Visible = true;
            txtFinalRcmnd.Visible = false;
            lblFinalRecmnd.Visible = false;
            txtFinalRcmnd.Text = "";

        }

        if (trSpotTarget != null && trSpotTarget.Visible == true) { trSpotTarget.Visible = false; }
    }
    protected void rdnSpot_CheckedChanged(object sender, EventArgs e)
    {

        bind_deviation();
        tdcategory1.Visible = true;
        tdspot1.Visible = true;
        trspotppd.Visible = true;
        Otherrmks.Visible = false;
        //other.Visible = false;
        //trSPot.Visible = true;
        //trSPot.Visible = true;
        //trPDDComplete1.Visible = false;
        //trPDDComplete2.Visible = false;
        //trPDDComplete3.Visible = false;
        //rdnBussEmpRelated.Checked = false;
        //rdnIncomeRelated.Checked = false;
        //rdnPropRelated.Checked = false;
        //rdnVerRelated.Checked = false;
        //rdnBussEmpRel.Checked = false;
        //rdnBussEmpRe2.Checked = false;
        //rdbIncomeTolerance.Checked = false;
        //rdnBuildAge.Checked = false;
        //rdnBuildArea.Checked = false;
        //rdnIncorrectBuildDet.Checked = false;
        //rdnVerRel.Checked = false;
        //rdoIncomeRelated.Checked = false;
        //rdoVerificationRelated.Checked = false;
        //chkPDDIncomeRelated.Checked = false;
        //chkPDDVerficationRel.Checked = false;
        ddl_spotppd.Visible = true;
        txtothers.Visible = false;
        txtothers.Text = "";
        trSpotTarget.Visible = true;
    }
    protected void rdnPDD_CheckedChanged(object sender, EventArgs e)
    {


        bind_deviation();
        tdcategory1.Visible = true;
        tdspot1.Visible = true;
        ddl_spotppd.Visible = true;
        trspotppd.Visible = true;
        Otherrmks.Visible = false;
        //trSPot.Visible = false;
        //trPDDComplete2.Visible = false;
        //trPDDComplete3.Visible = false;
        //trBussEmpRelt.Visible = false;
        //trIncomeTol.Visible = false;
        //trPropRel.Visible = false;
        //trVerRel.Visible = false;
        //trPDDComplete1.Visible = true;
        //rdnBussEmpRelated.Checked = false;
        //rdnIncomeRelated.Checked = false;
        //rdnPropRelated.Checked = false;
        //rdnVerRelated.Checked = false;
        //rdnBussEmpRel.Checked = false;
        //rdnBussEmpRe2.Checked = false;
        //rdbIncomeTolerance.Checked = false;
        //rdnBuildAge.Checked = false;
        //rdnBuildArea.Checked = false;
        //rdnIncorrectBuildDet.Checked = false;
        //rdnVerRel.Checked = false;
        //rdoIncomeRelated.Checked = false;
        //rdoVerificationRelated.Checked = false;
        //chkPDDIncomeRelated.Checked = false;
        //chkPDDVerficationRel.Checked = false;

        txtothers.Visible = false;
        txtothers.Text = "";
        if (trSpotTarget != null && trSpotTarget.Visible == true) { trSpotTarget.Visible = false; }
    }
    protected void rdnBussEmpRelated_CheckedChanged(object sender, EventArgs e)
    {
        //if (rdnBussEmpRelated.Checked == true)
        //{
        //    trBussEmpRelt.Visible = true;

        //}
        //else
        //{
        //    rdnBussEmpRel.Checked = false;
        //    rdnBussEmpRe2.Checked = false;
        //    trBussEmpRelt.Visible = false;
        //}
        //trBussEmpRelt.Visible = true;
        //trIncomeTol.Visible = false;
        //trPropRel.Visible = false;
        //trVerRel.Visible = false;
    }
    protected void rdnIncomeRelated_CheckedChanged(object sender, EventArgs e)
    {
        //trBussEmpRelt.Visible = false;
        //trIncomeTol.Visible = true;
        //trPropRel.Visible = false;
        //trVerRel.Visible = false;
        //if (rdnIncomeRelated.Checked == true)
        //{
        //    trIncomeTol.Visible = true;
        //}
        //else
        //{
        //    rdbIncomeTolerance.Checked = false;
        //    trIncomeTol.Visible = false;
        //}
    }
    protected void rdnPropRelated_CheckedChanged(object sender, EventArgs e)
    {
        //trBussEmpRelt.Visible = false;
        //trIncomeTol.Visible = false;
        //trPropRel.Visible = true;
        //trVerRel.Visible = false;
        //if (rdnPropRelated.Checked == true)
        //{
        //    trPropRel.Visible = true;
        //}
        //else
        //{
        //    rdnBuildAge.Checked = false;
        //    rdnBuildArea.Checked = false;
        //    rdnIncorrectBuildDet.Checked = false;
        //    trPropRel.Visible = false;
        //}

    }
    protected void rdnVerRelated_CheckedChanged(object sender, EventArgs e)
    {
        //trBussEmpRelt.Visible = false;
        //trIncomeTol.Visible = false;
        //trPropRel.Visible = false;
        //trVerRel.Visible = true;

        //if (rdnVerRelated.Checked == true)
        //{
        //    trVerRel.Visible = true;
        //}
        //else
        //{
        //    rdnVerRelated.Checked = false;
        //    trVerRel.Visible = false;
        //}
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        if (ddlLeadNo.SelectedItem.Text == "Select")
        {
            uscMsgBox1.AddMessage("Please select a Lead", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            ddlLeadNo.Focus();
        }
        else if (ddlTolerance.SelectedItem.Text == "--Select--")
        {
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Tolerance');", true);
            ddlTolerance.Focus();
        }
        else if (ddlApproove.SelectedItem.Text == "--Select--")
        {
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please select Decision');", true);
            ddlApproove.Focus();
        }
        else if (ddlApproove.SelectedItem.Text == "Recommended" && txtFinalRcmnd.Text.Trim() == "")
        {
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Give Final Recommended Amount');", true);
            txtFinalRcmnd.Focus();
        }
        else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnSpot.Checked == false && rdnPDD.Checked == false && rdnOthers.Checked == false)
        {
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select Rejected status as SPOT or PPD or Others');", true);
            rdnSpot.Focus();
        }
        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnSpot.Checked == true && rdnBussEmpRelated.Checked == false
        //                                          && rdnIncomeRelated.Checked == false && rdnPropRelated.Checked == false && rdnVerRelated.Checked == false)
        //{

        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select  any one of SPOT options');", true);
        //    rdnBussEmpRelated.Focus();
        //}
        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnSpot.Checked == true && rdnBussEmpRelated.Checked == true
        //                                        && rdnBussEmpRel.Checked == false && rdnBussEmpRe2.Checked == false)
        //{

        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select  any one of Business/Employee Related options');", true);
        //    rdnBussEmpRelated.Focus();
        //}
        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnSpot.Checked == true && rdnIncomeRelated.Checked == true
        //                                        && rdbIncomeTolerance.Checked == false)
        //{

        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select Income Tolerance Level options');", true);
        //    rdnBussEmpRelated.Focus();
        //}
        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnSpot.Checked == true && rdnPropRelated.Checked == true
        //                                       && rdnBuildAge.Checked == false && rdnBuildArea.Checked == false && rdnIncorrectBuildDet.Checked == false)
        //{

        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select  any one of Proprty Related options');", true);
        //    rdnBussEmpRelated.Focus();
        //}
        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnPDD.Checked == true && rdoVerificationRelated.Checked == true && rdoIncomeRelated.Checked == true
        //     && (chkPDDIncomeRelated.Checked == false || chkPDDVerficationRel.Checked == false))
        //{
        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select  PPD Income / Verification related options');", true);
        //    rdnBussEmpRelated.Focus();
        //}
        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnSpot.Checked == true && rdnVerRelated.Checked == true
        //                                       && rdnVerRel.Checked == false)
        //{

        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select  Verification Related options');", true);
        //    rdnBussEmpRelated.Focus();
        //}
        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnPDD.Checked == true && rdoIncomeRelated.Checked == true
        //                            && chkPDDIncomeRelated.Checked == false)
        //{
        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select  PPD Income Assessment options');", true);
        //    rdnBussEmpRelated.Focus();
        //}
        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnPDD.Checked == true && rdoVerificationRelated.Checked == true
        //                  && chkPDDVerficationRel.Checked == false)
        //{
        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select  PPD Verification related options');", true);
        //    rdnBussEmpRelated.Focus();
        //}
        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnPDD.Checked == true && rdoVerificationRelated.Checked == true && rdoIncomeRelated.Checked == true
        //           && (chkPDDIncomeRelated.Checked == false || chkPDDVerficationRel.Checked == false))
        //{
        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select  PPD Income / Verification related options');", true);
        //    rdnBussEmpRelated.Focus();
        //}






        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnPDD.Checked == true && rdoIncomeRelated.Checked == true
        //                                 && rdoVerificationRelated.Checked == false)
        //{

        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select  PPD Related options');", true);
        //    rdnBussEmpRelated.Focus();
        //}
        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnPDD.Checked == true && rdoIncomeRelated.Checked == true
        //                            && chkPDDIncomeRelated.Checked == false)
        //{

        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select  PPD Income Assessment options');", true);
        //    rdnBussEmpRelated.Focus();
        //}
        //else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnPDD.Checked == true && chkPDDVerficationRel.Checked == false
        //                       && rdoVerificationRelated.Checked == true)
        //{

        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please Select  PPD Verification Related options');", true);
        //    rdnBussEmpRelated.Focus();
        //}
        else if (ddlApproove.SelectedItem.Text == "Rejected" && txtRmrk.Text.Trim() == "")
        {
            ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('Please enter remarks');", true);
            txtRmrk.Focus();
        }
        else if (ddlApproove.SelectedItem.Text == "Rejected" && rdnSpot.Checked == true
            && (txtBxEmpNo.Text.Trim() == String.Empty || txtBxEmpName.Text.Trim() == String.Empty || txtBxEmpEmail.Text.Trim() == String.Empty))
        {
            uscMsgBox1.AddMessage("Please provide employee details for SPOT", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            txtBxEmpName.Focus();
        }
        else
        {
            UpdateSamplingApprvlDatas();
        }
    }

    public void UpdateSamplingApprvlDatas()
    {
        try
        {


            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmdupdate = new SqlCommand("RTS_SP_UpdateSAApprooval", con);
            cmdupdate.CommandType = CommandType.StoredProcedure;
            cmdupdate.Parameters.AddWithValue("@SL_LD_ID", ddlLeadNo.SelectedValue.ToString());
            cmdupdate.Parameters.AddWithValue("@SL_NETIN", txtNetIncomeafterfactoringRmrk.Text);
            cmdupdate.Parameters.AddWithValue("@SL_OBLIG", txtObligationRmrk.Text);
            cmdupdate.Parameters.AddWithValue("@SL_SQFT", txtLandSQFTRmrk.Text);
            cmdupdate.Parameters.AddWithValue("@SL_GV", txtReginetRmrk.Text);
            cmdupdate.Parameters.AddWithValue("@SL_MV", txtMarketvalueRmrk.Text);
            cmdupdate.Parameters.AddWithValue("@SL_LV", txtTotalLandvalueRmrk.Text);
            cmdupdate.Parameters.AddWithValue("@SL_BTYPE", txtBuildingTypeRmrk.Text);
            cmdupdate.Parameters.AddWithValue("@SL_BAGE", txtAgeofbuildingRmrk.Text);
            cmdupdate.Parameters.AddWithValue("@SL_BV", txtBuildingValueRmrk.Text);
            cmdupdate.Parameters.AddWithValue("@SL_PV", txtTotalpropertyvalueRmrk.Text);
            cmdupdate.Parameters.AddWithValue("@SL_LAMT", txtLoanamountrecommeded.Text);
            cmdupdate.Parameters.AddWithValue("@SL_TOL", ddlTolerance.SelectedItem.Text != "--Select--" ? ddlTolerance.SelectedItem.Text : "");
            cmdupdate.Parameters.AddWithValue("@SL_DECSN", ddlApproove.SelectedItem.Text != "--Select--" ? ddlApproove.SelectedItem.Text : "");
            cmdupdate.Parameters.AddWithValue("@SL_RAMT", txtFinalRcmnd.Text != "" ? txtFinalRcmnd.Text : "0.0");

            string strRtype = "";
            if (rdnSpot.Checked == true)
            {
                strRtype = rdnSpot.Text;
            }
            else if (rdnPDD.Checked == true)
            {
                strRtype = rdnPDD.Text;
            }
            else if (rdnOthers.Checked == true)
            {
                strRtype = rdnOthers.Text;
            }
            else
            {
                strRtype = "";
            }
            cmdupdate.Parameters.AddWithValue("@SL_RTYPE", strRtype);

            string strMRisk = "";

            if (rdnSpot.Checked == true || rdnPDD.Checked == true)
            {
                strMRisk = ddl_spotppd.SelectedItem.Text != "--Select--" ? ddl_spotppd.SelectedItem.Text.Trim() : "";
            }
            else
            {
                strMRisk = txtothers.Text.ToString();
            }

            //if (rdnBussEmpRelated.Checked == true)
            //{
            //    strMRisk = strMRisk +  .Text + "|";
            //}
            //if (rdnIncomeRelated.Checked == true)
            //{
            //    strMRisk = strMRisk + rdnIncomeRelated.Text + "|";
            //}
            //if (rdnPropRelated.Checked == true)
            //{
            //    strMRisk = strMRisk + rdnPropRelated.Text + "|";
            //}
            //if (rdnVerRelated.Checked == true)
            //{
            //    strMRisk = strMRisk + rdnVerRelated.Text + "|";
            //}
            //if (rdoIncomeRelated.Checked == true)
            //{
            //    strMRisk = strMRisk + rdoIncomeRelated.Text + "|";
            //}

            //if (rdoVerificationRelated.Checked == true)
            //{
            //    strMRisk = strMRisk + rdoVerificationRelated.Text + "|";
            //}


            cmdupdate.Parameters.AddWithValue("@SL_MRISK", strMRisk);

            string strSRisk = "";
            strSRisk = txtothers.Text.Trim();
            //if (rdnBussEmpRel.Checked == true)
            //{
            //    strSRisk = strSRisk + rdnBussEmpRel.Text + "|";
            //}
            //if (rdnBussEmpRe2.Checked == true)
            //{
            //    strSRisk = strSRisk + rdnBussEmpRe2.Text + "|"; ;
            //}
            //if (rdnPropRelated.Checked == true)
            //{
            //    strSRisk = strSRisk + rdnPropRelated.Text + "|"; ;
            //}
            //if (rdbIncomeTolerance.Checked == true)
            //{
            //    strSRisk = strSRisk + rdbIncomeTolerance.Text + "|"; ;
            //}
            //if (rdnBuildAge.Checked == true)
            //{
            //    strSRisk = strSRisk + rdnBuildAge.Text + "|"; ;
            //}
            //if (rdnBuildArea.Checked == true)
            //{
            //    strSRisk = strSRisk + rdnBuildArea.Text + "|"; ;
            //}
            //if (rdnIncorrectBuildDet.Checked == true)
            //{
            //    strSRisk = strSRisk + rdnIncorrectBuildDet.Text + "|"; ;
            //}
            //if (rdnVerRel.Checked == true)
            //{
            //    strSRisk = strSRisk + rdnVerRel.Text + "|"; ;
            //}
            //if (chkPDDIncomeRelated.Checked == true)
            //{
            //    strSRisk = strSRisk + chkPDDIncomeRelated.Text + "|"; ;
            //}
            //if (chkPDDVerficationRel.Checked == true)
            //{
            //    strSRisk = strSRisk + chkPDDVerficationRel.Text + "|"; ;
            //}
            cmdupdate.Parameters.AddWithValue("@SL_SRISK", strSRisk);
            cmdupdate.Parameters.AddWithValue("@SL_RMKS", txtRmrk.Text);
            cmdupdate.Parameters.AddWithValue("@ID", Session["ID"].ToString());
            cmdupdate.Parameters.AddWithValue("@APPTYPE", "AMCIAPPROVE");

            cmdupdate.Parameters.AddWithValue("@SL_RSQFT", txtLandArea.Text);
            cmdupdate.Parameters.AddWithValue("@SL_RGV", txtGvalue.Text);
            cmdupdate.Parameters.AddWithValue("@SL_RMV", txtMarkVal.Text);
            cmdupdate.Parameters.AddWithValue("@SL_RLV", txtBMLandValue.Text);

            int n = cmdupdate.ExecuteNonQuery();
        
            SaveSpotEmployeeDetails(con);
            con.Close();

            if (n > 0)
            {

                if (ddlApproove.SelectedItem.Text == "Recommended")
                {
                    approvedloanamt = txtFinalRcmnd.Text != "" ? txtFinalRcmnd.Text : "0";
                    sendMailA(con);

                }
                else if (ddlApproove.SelectedItem.Text == "Rejected")
                {
                    bme = lblLoanamountrecommeded.Text;
                    ocie = lblLoanamountrecommeded_CR.Text;
                    variance = lblLoanamountrecommeded_Var.Text;
                    scicmts = txtRmrk.Text.Trim() != "" ? txtRmrk.Text : "NIL";
                    if (rdnSpot.Checked)
                        rpt = "SPOT";
                    if (rdnPDD.Checked)
                        rpt = "PPD";
                    if (rdnOthers.Checked)
                        rpt = "Others";

                    SendMailR(con);
                }
                //if (mail.IsAlive) { Thread.Sleep(1000); }


                string strMailStatus = "";
                string strSuccessMsg = "";

                if (blMailStatus == true)
                {
                    strMailStatus = "Successfully";
                }
                else
                {
                    strMailStatus = "Failed";
                }
                strSuccessMsg = "Mail Sent " + strMailStatus + ".";
                strSuccessMsg += "\\r\\nMail To: " + toID + " ; CC To: " + ccID + " ";

                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('SCI Approval for " + ddlLeadNo.SelectedItem.Text + "   done Successfully.\\r\\n" + strSuccessMsg + "');", true);
                //  Response.Redirect("CAM_LAP.aspx");

                bind();
                Clear();


            }
            else
            {

                ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('SCI Approval for " + ddlLeadNo.SelectedItem.Text + "   Failed ');", true);
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlTolerance_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (lblBMGvalue.Text != "" && lblFROGvalue.Text == "")
        //{
        //    ScriptManager.RegisterClientScriptBlock(this.btnSubmit, this.GetType(), "alert", "alert('RPA detail pending for " + ddlLeadNo.SelectedItem.Text + "  ');", true);
        //}
        //else
        //{
        trResult.Visible = false;

        //trSPot.Visible = false;
        //trBussEmpRelt.Visible = false;
        //trIncomeTol.Visible = false;
        //trPropRel.Visible = false;
        txtFinalRcmnd.Visible = false;
        lblFinalRecmnd.Visible = false;
        rdnSpot.Checked = false;
        rdnPDD.Checked = false;
        //rdnBussEmpRelated.Checked = false;
        //rdnIncomeRelated.Checked = false;
        //rdnPropRelated.Checked = false;
        //rdnVerRelated.Checked = false;
        //rdnBussEmpRel.Checked = false;
        //rdnBussEmpRe2.Checked = false;
        //rdbIncomeTolerance.Checked = false;
        //rdnBuildAge.Checked = false;
        //rdnBuildArea.Checked = false;
        //rdnIncorrectBuildDet.Checked = false;
        //rdnVerRel.Checked = false;
        ddlApproove.Items.Clear();
        ddlApproove.Items.Add("--Select--");
        trspotppd.Visible = false;
        if (ddlTolerance.SelectedItem.Text == "Tolerance")
        {
            trspotppd.Visible = false;
            tdcategory1.Visible = false;
            tdcategory1.Visible = false;
            ddlApproove.Items.Add("Recommended");



        }
        else if (ddlTolerance.SelectedItem.Text == "Non Tolerance")
        {
            ddlApproove.Items.Add("Recommended");
            ddlApproove.Items.Add("Rejected");
        }
        //}

        if (trSpotTarget != null && trSpotTarget.Visible == true) { trSpotTarget.Visible = false; }
    }

    public void clear()
    {
        lblBMGvalue.Text = "";
        lblBMMarkVal.Text = "";
        lblBMLandArea.Text = "";
        lblBMLandValue.Text = "";
        lblFROGvalue.Text = "";
        lblFORMarkVal.Text = "";
        lblFORLandArea.Text = "";
        lblForLandValue.Text = "";
        lblVarGvalue.Text = "";
        lblVarMarkVal.Text = "";
        lblVarLandArea.Text = "";
        lblVarLandValue.Text = "";



    }
    protected void rdoIncomeRelated_CheckedChanged(object sender, EventArgs e)
    {
        //if (rdoIncomeRelated.Checked == true)
        //{
        //    trPDDComplete2.Visible = true;
        //}
        //else
        //{
        //    chkPDDIncomeRelated.Checked = false;
        //    trPDDComplete2.Visible = false;
        //}
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("CAM_LAP__Sampling_Approval.aspx");

    }
    protected void rdoVerificationRelated_CheckedChanged(object sender, EventArgs e)
    {
        //if (rdoVerificationRelated.Checked == true)
        //{
        //    trPDDComplete3.Visible = true;
        //}
        //else
        //{
        //    chkPDDVerficationRel.Checked = false;
        //    trPDDComplete3.Visible = false;
        //}
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, "--Select--");
        ddlBranch.Enabled = true;
        BindLeadNo();

        Clear();
    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindLeadNo();
        Clear();
    }
    public void sendMailA(SqlConnection con)
    {
        try
        {
            StringBuilder cmd = new StringBuilder();


            cmd.Append("SELECT 	LD_NO 'LEADNO', LD_APNAME 'APPLICANT',(SELECT PR_NAME FROM MR_PRODUCT WHERE PR_ID=A.LD_PR_ID) 'PRODUCT',C.AR_ID 'AID',C.AR_NAME 'AREA',C.AR_DV_ID 'DID', B.BR_ID 'BID',B.BR_NAME 'BRANCH',(SELECT CONVERT(VARCHAR,SL_DATE,106) FROM LSD_CAM_SAMPLE WHERE A.LD_ID=SL_LD_ID) 'INITIATED DATE' FROM	LSD_LEAD A ");
            cmd.Append(" JOIN MR_BRANCH B ON B.BR_ID=A.LD_BR_ID ");
            cmd.Append(" JOIN MR_AREA  C ON C.AR_ID= B.BR_AR_ID ");
            cmd.Append(" WHERE A.LD_ID=");
            cmd.Append(ddlLeadNo.SelectedValue.ToString());


            SqlCommand cmddet = new SqlCommand(cmd.ToString(), con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataTable dtdet = new DataTable();
            dadet.Fill(dtdet);



            if (dtdet.Rows.Count > 0)
            {
                ldno = dtdet.Rows[0]["LEADNO"] != DBNull.Value ? dtdet.Rows[0]["LEADNO"].ToString() : "";
                aname = dtdet.Rows[0]["APPLICANT"] != DBNull.Value ? dtdet.Rows[0]["APPLICANT"].ToString() : "";

                prod = dtdet.Rows[0]["PRODUCT"] != DBNull.Value ? dtdet.Rows[0]["PRODUCT"].ToString() : "";
                area = dtdet.Rows[0]["AREA"] != DBNull.Value ? dtdet.Rows[0]["AREA"].ToString() : "";
                brnch = dtdet.Rows[0]["BRANCH"] != DBNull.Value ? dtdet.Rows[0]["BRANCH"].ToString() : "";
                arid = dtdet.Rows[0]["AID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["AID"].ToString()) : 0;
                brid = dtdet.Rows[0]["BID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["BID"].ToString()) : 0;
                dvid = dtdet.Rows[0]["DID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["DID"].ToString()) : 0;
            }

            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_EMAIL WHERE EM_BR_ID=");
            cmd.Append(brid);

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtbrnch = new DataTable();
            dadet.Fill(dtbrnch);


            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_AREA_MANAGER WHERE AM_AR_ID=");
            cmd.Append(arid);

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtarm = new DataTable();
            dadet.Fill(dtarm);




            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_DIVISION WHERE DV_ID=");
            cmd.Append(dvid);

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtdiv = new DataTable();
            dadet.Fill(dtdiv);

            toID = "";
            ccID = "";

            if (dtbrnch.Rows.Count > 0)
            {

                if (dtbrnch.Rows[0]["EM_BM"] != "" && dtbrnch.Rows[0]["EM_BM"] != DBNull.Value && dtbrnch.Rows[0]["EM_BM"].ToString() != "")
                {
                    toID = dtbrnch.Rows[0]["EM_BM"].ToString();
                }
                else toID = "RTS-HelpDesk@equitasbank.com";

                if (dtbrnch.Rows[0]["EM_AM"] != "" && dtbrnch.Rows[0]["EM_AM"] != DBNull.Value && dtbrnch.Rows[0]["EM_AM"].ToString() != "")
                {
                    ccID = dtbrnch.Rows[0]["EM_AM"].ToString();
                }


                if (dtbrnch.Rows[0]["EM_CLM"] != "" && dtbrnch.Rows[0]["EM_CLM"] != DBNull.Value && dtbrnch.Rows[0]["EM_CLM"].ToString() != "")
                {
                    ccID = ccID + ";" + dtbrnch.Rows[0]["EM_CLM"].ToString();
                }


                if (dtarm.Rows.Count > 0)
                {
                    if (dtarm.Rows[0]["AM_CREDIT"] != "" && dtarm.Rows[0]["AM_CREDIT"] != DBNull.Value && dtarm.Rows[0]["AM_CREDIT"].ToString() != "")
                    {
                        ccID = ccID + ";" + dtarm.Rows[0]["AM_CREDIT"].ToString();
                    }
                }

                if (dtdiv.Rows.Count > 0)
                {
                    if (dtdiv.Rows[0]["DV_HDEMAIL"] != "" && dtdiv.Rows[0]["DV_HDEMAIL"] != DBNull.Value && dtdiv.Rows[0]["DV_HDEMAIL"].ToString() != "")
                    {
                        ccID = ccID + ";" + dtdiv.Rows[0]["DV_HDEMAIL"].ToString();
                    }
                }

                if (toID.ToString().StartsWith(";"))
                {
                    toID = toID.Substring(1, toID.Length - 1);
                }
                if (toID.EndsWith(";"))
                {
                    toID = toID.Remove(toID.ToString().Length - 1, 1);
                }

                if (ccID.ToString().StartsWith(";"))
                {
                    ccID = ccID.Substring(1, ccID.Length - 1);
                }
                if (ccID.EndsWith(";"))
                {
                    ccID = ccID.Remove(ccID.ToString().Length - 1, 1);
                }

            }
            else
            {
                blMailStatus = false;
                return;
            }



            frmID = "RTS Alerts";


            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

           /* threadSendMails = new System.Threading.Thread(delegate()
            {
            */
                String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Sampling Approval. <br/><br/>";
                BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + ldno + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Area Name</td><td><strong>" + area + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Branch Name</td><td><strong>" + brnch + "</strong></td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + prod + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + aname + "</strong></td><td>Status</td><td><strong> Recommended / Rs." + approvedloanamt + "  </strong></td></tr></table><br/>";

                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>Credit Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";


                blMailStatus = EmailManager.sendemail(toID, "RTS Alerts", "", ccID, "Lead No. : " + ldno + " - Applicant Name : " + aname + " - Product: " + prod + " - Sampling Approved", BodyTxt, "", true);


           /* });

            threadSendMails.IsBackground = true;
            mail = threadSendMails;
            threadSendMails.Start();
            System.Threading.Thread.Sleep(5000);

            */
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    
    public void SendMailR(SqlConnection con)
    {
        try
        {
            StringBuilder cmd = new StringBuilder();


            cmd.Append("SELECT 	LD_NO 'LEADNO', LD_APNAME 'APPLICANT',(SELECT PR_NAME FROM MR_PRODUCT WHERE PR_ID=A.LD_PR_ID) 'PRODUCT',C.AR_ID 'AID',C.AR_NAME 'AREA',C.AR_DV_ID 'DID', B.BR_ID 'BID',B.BR_NAME 'BRANCH',(SELECT CONVERT(VARCHAR,SL_DATE,106) FROM LSD_CAM_SAMPLE WHERE A.LD_ID=SL_LD_ID) 'INITIATED DATE' FROM	LSD_LEAD A ");
            cmd.Append(" JOIN MR_BRANCH B ON B.BR_ID=A.LD_BR_ID ");
            cmd.Append(" JOIN MR_AREA  C ON C.AR_ID= B.BR_AR_ID ");
            cmd.Append(" WHERE A.LD_ID=");
            cmd.Append(ddlLeadNo.SelectedValue.ToString());


            SqlCommand cmddet = new SqlCommand(cmd.ToString(), con);
            SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
            DataTable dtdet = new DataTable();
            dadet.Fill(dtdet);



            if (dtdet.Rows.Count > 0)
            {
                ldno = dtdet.Rows[0]["LEADNO"] != DBNull.Value ? dtdet.Rows[0]["LEADNO"].ToString() : "";
                aname = dtdet.Rows[0]["APPLICANT"] != DBNull.Value ? dtdet.Rows[0]["APPLICANT"].ToString() : "";

                prod = dtdet.Rows[0]["PRODUCT"] != DBNull.Value ? dtdet.Rows[0]["PRODUCT"].ToString() : "";
                area = dtdet.Rows[0]["AREA"] != DBNull.Value ? dtdet.Rows[0]["AREA"].ToString() : "";
                brnch = dtdet.Rows[0]["BRANCH"] != DBNull.Value ? dtdet.Rows[0]["BRANCH"].ToString() : "";
                arid = dtdet.Rows[0]["AID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["AID"].ToString()) : 0;
                brid = dtdet.Rows[0]["BID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["BID"].ToString()) : 0;
                dvid = dtdet.Rows[0]["DID"] != DBNull.Value ? Convert.ToInt32(dtdet.Rows[0]["DID"].ToString()) : 0;
            }

            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_EMAIL WHERE EM_BR_ID=");
            cmd.Append(brid);

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtbrnch = new DataTable();
            dadet.Fill(dtbrnch);


            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_AREA_MANAGER WHERE AM_AR_ID=");
            cmd.Append(arid);

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtarm = new DataTable();
            dadet.Fill(dtarm);




            cmd = new StringBuilder();

            cmd.Append("SELECT * FROM MR_DIVISION WHERE DV_ID=");
            cmd.Append(dvid);

            cmddet = new SqlCommand(cmd.ToString(), con);
            dadet = new SqlDataAdapter(cmddet);
            DataTable dtdiv = new DataTable();
            dadet.Fill(dtdiv);

            toID = "";
            ccID = "";
            if (dtbrnch.Rows.Count > 0)
            {

                if (dtbrnch.Rows[0]["EM_BM"] != "" && dtbrnch.Rows[0]["EM_BM"] != DBNull.Value && dtbrnch.Rows[0]["EM_BM"].ToString() != "")
                {
                    toID = dtbrnch.Rows[0]["EM_BM"].ToString();
                }
                else toID = "RTS-HelpDesk@equitasbank.com";

                if (dtbrnch.Rows[0]["EM_AM"] != "" && dtbrnch.Rows[0]["EM_AM"] != DBNull.Value && dtbrnch.Rows[0]["EM_AM"].ToString() != "")
                {
                    ccID = dtbrnch.Rows[0]["EM_AM"].ToString();
                }


                if (dtbrnch.Rows[0]["EM_CLM"] != "" && dtbrnch.Rows[0]["EM_CLM"] != DBNull.Value && dtbrnch.Rows[0]["EM_CLM"].ToString() != "")
                {
                    ccID = ccID + ";" + dtbrnch.Rows[0]["EM_CLM"].ToString();
                }


                if (dtarm.Rows.Count > 0)
                {
                    if (dtarm.Rows[0]["AM_CREDIT"] != "" && dtarm.Rows[0]["AM_CREDIT"] != DBNull.Value && dtarm.Rows[0]["AM_CREDIT"].ToString() != "")
                    {
                        ccID = ccID + ";" + dtarm.Rows[0]["AM_CREDIT"].ToString();
                    }
                }

                if (dtdiv.Rows.Count > 0)
                {
                    if (dtdiv.Rows[0]["DV_HDEMAIL"] != "" && dtdiv.Rows[0]["DV_HDEMAIL"] != DBNull.Value && dtdiv.Rows[0]["DV_HDEMAIL"].ToString() != "")
                    {
                        ccID = ccID + ";" + dtdiv.Rows[0]["DV_HDEMAIL"].ToString();
                    }
                }

                if (toID.ToString().StartsWith(";;"))
                {
                    toID = toID.Substring(1, toID.Length - 1);
                }
                if (toID.ToString().StartsWith(";"))
                {
                    toID = toID.Substring(1, toID.Length - 1);
                }
                if (toID.EndsWith(";"))
                {
                    toID = toID.Remove(toID.ToString().Length - 1, 1);
                }

                if (ccID.ToString().StartsWith(";;"))
                {
                    ccID = ccID.Substring(1, ccID.Length - 1);
                }
                if (ccID.ToString().StartsWith(";"))
                {
                    ccID = ccID.Substring(1, ccID.Length - 1);
                }
                if (ccID.EndsWith(";"))
                {
                    ccID = ccID.Remove(ccID.ToString().Length - 1, 1);
                }



            }


            else
            {
                blMailStatus = false;
                return;
            }



            frmID = "RTS Alerts";


            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

          /*  threadSendMails = new System.Threading.Thread(delegate()
            {*/

                String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Sampling feedback. <br/><br/>";
                BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + ldno + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Area Name</td><td><strong>" + area + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Branch Name</td><td><strong>" + brnch + "</strong></td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + prod + "</strong></td>";
                BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + aname + "</strong></td><td>Status</td><td><strong>Rejected</strong></td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>BM-Assessed Eligibility</td><td ><strong>Rs." + bme + "</strong></td><td>OCI-Assessed Eligibility</td><td ><strong>Rs." + ocie + "</strong></td><td style='white-space:nowrap;'>Type of Variance</td><td ><strong>" + variance + " % </strong></td></tr>";
                BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>SCI Comments</td><td  colspan='5' style='white-space:normal;'><strong>" + scicmts + "  </strong></td></tr></table><br/>";


                BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/>Thanks and Regards,<br/>Credit Team</td></tr>";
                BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> *** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";


                blMailStatus = EmailManager.sendemail(toID, "RTS Alerts", "", ccID, "Report Type : " + rpt + " - Lead No. : " + ldno + " - Applicant Name : " + aname + " - Product: " + prod + " - Sampling Rejected", BodyTxt, "", true);


           /* });

            threadSendMails.IsBackground = true;
            mail = threadSendMails;
            threadSendMails.Start();
            System.Threading.Thread.Sleep(5000);
                */
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }

    public void Clear()
    {
        lblBranchName.Text = "";
        lblCustomerName.Text = "";


        lblNetIncomeafterfactoring.Text = "";
        lblObligation.Text = "";
        lblLandSQFT.Text = "";
        lblReginet.Text = "";
        lblMarketvalue.Text = "";
        lblTotalLandvalue.Text = "";
        lblBuildingType.Text = "";
        lblAgeofbuilding.Text = "";
        lblBuildingValue.Text = "";
        lblTotalpropertyvalue.Text = "";
        lblLoanamountrecommeded.Text = "";



        lblNetIncomeafterfactoring_CI.Text = "";
        lblObligation_CI.Text = "";
        lblLandSQFT_CI.Text = "";
        lblReginet_CI.Text = "";
        lblMarketvalue_CI.Text = "";
        lblTotalLandvalue_CI.Text = "";
        lblBuildingType_CI.Text = "";
        lblAgeofbuilding_CI.Text = "";
        lblBuildingValue_CI.Text = "";
        lblTotalpropertyvalue_CI.Text = "";
        lblLoanamountrecommeded_CR.Text = "";


        lblNetIncomeafterfactoring_Var.Text = "";
        lblObligation_Var.Text = "";
        lblLandSQFT_Var.Text = "";
        lblReginet_Var.Text = "";
        lblMarketvalue_Var.Text = "";
        lblTotalLandvalue_Var.Text = "";

        lblAgeofbuilding_Var.Text = "";
        lblBuildingValue_Var.Text = "";
        lblTotalpropertyvalue_Var.Text = "";
        lblLoanamountrecommeded_Var.Text = "";


        txtNetIncomeafterfactoringRmrk.Text = "";
        txtObligationRmrk.Text = "";
        txtLandSQFTRmrk.Text = "";
        txtReginetRmrk.Text = "";
        txtMarketvalueRmrk.Text = "";
        txtTotalLandvalueRmrk.Text = "";
        txtBuildingTypeRmrk.Text = "";
        txtAgeofbuildingRmrk.Text = "";
        txtBuildingValueRmrk.Text = "";
        txtTotalpropertyvalueRmrk.Text = "";
        txtLoanamountrecommeded.Text = "";


        lblBMGvalue.Text = "";
        lblBMMarkVal.Text = "";
        lblBMLandArea.Text = "";
        lblBMLandValue.Text = "";
        lblFROGvalue.Text = "";
        lblFORMarkVal.Text = "";
        lblFORLandArea.Text = "";
        lblForLandValue.Text = "";
        lblVarGvalue.Text = "";
        lblVarMarkVal.Text = "";
        lblVarLandArea.Text = "";
        lblVarLandValue.Text = "";
        txtGvalue.Text = "";
        txtMarkVal.Text = "";
        txtLandArea.Text = "";
        txtBMLandValue.Text = "";


        ddlTolerance.SelectedIndex = 0;
        ddlApproove.DataSource = null;
        ddlApproove.DataBind();

        ddlLeadNo.SelectedIndex = 0;
        if (ddlApproove.SelectedIndex > 0)
            ddlApproove.SelectedIndex = 0;

        txtFinalRcmnd.Text = "";
        txtRmrk.Text = "";

        rdnPDD.Checked = false;
        rdnSpot.Checked = false;
        rdnOthers.Checked = false;
        //rdnBussEmpRelated.Checked = false;
        //rdnIncomeRelated.Checked = false;
        //rdnPropRelated.Checked = false;
        //rdnVerRelated.Checked = false;
        //rdnBussEmpRel.Checked = false;
        //rdnBussEmpRe2.Checked = false;
        //rdbIncomeTolerance.Checked = false;
        //rdnBuildAge.Checked = false;
        //rdnBuildArea.Checked = false;
        //rdnIncorrectBuildDet.Checked = false;
        //rdnVerRel.Checked = false;
        //rdoIncomeRelated.Checked = false;
        //rdoVerificationRelated.Checked = false;
        //chkPDDIncomeRelated.Checked = false;
        //chkPDDVerficationRel.Checked = false;


        this.trResult.Visible = false;
        //this.trSPot.Visible = false;
        //this.trBussEmpRelt.Visible = false;
        //this.trIncomeTol.Visible = false;
        //this.trPropRel.Visible = false;
        //this.trVerRel.Visible = false;
        //this.trPDDComplete1.Visible = false;
        //this.trPDDComplete2.Visible = false;
        //this.trPDDComplete3.Visible = false;

        this.lblFinalRecmnd.Visible = false;
        this.txtFinalRcmnd.Visible = false;



    }

    protected void rdnOthers_CheckedChanged(object sender, EventArgs e)
    {
        if (rdnOthers.Checked == true)
        {
            //    trSPot.Visible = false;
            //    trBussEmpRelt.Visible = false;
            //    trIncomeTol.Visible = false;
            //    trPropRel.Visible = false;
            //    trVerRel.Visible = false;
            //    trPDDComplete1.Visible = false;
            //    trPDDComplete2.Visible = false;
            //    trPDDComplete3.Visible = false;
            ddl_spotppd.Visible = false;
            txtothers.Visible = true;
            trspotppd.Visible = true;
            tdcategory1.Visible = false;
            Otherrmks.Visible = true;

            // other.Visible = true;
            //trspotppd.Visible = false;
            //category1.Visible = false;
            //tdspot1.Visible = false;
        }

        else
        {
            txtothers.Visible = false;
            ddl_spotppd.Visible = true;
            txtothers.Text = "";
        }

        if (trSpotTarget != null && trSpotTarget.Visible == true) { trSpotTarget.Visible = false; }
    }

    protected void bind_deviation()
    {
        string type;
        SqlConnection con = new SqlConnection(strcon);
        con.Open();


        if (rdnSpot.Checked)
        {
            type = "S";
            Session["spotppd"] = type;

        }
        else if (rdnPDD.Checked)
        {
            type = "P";
            Session["spotppd"] = type;
        }
        else
        {
            ddl_spotppd.Visible = false;
        }
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_DEVIATION_SPOT_PPD", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@DVT_TYPE", Session["spotppd"].ToString());
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();
        ddl_spotppd.Visible = true;
        ddl_spotppd.DataSource = dsrsn;
        ddl_spotppd.DataTextField = "DVT_DESC";
        ddl_spotppd.DataValueField = "DVT_TYPE";
        ddl_spotppd.DataBind();
        ddl_spotppd.Items.Insert(0, "--Select--");
    }

    private DataSet SaveSpotEmployeeDetails(SqlConnection sqlConn)
    {
        DataSet _resultSet = new DataSet();
        Int64 _userId = 0;

        try
        {
            if (Session[SessionKeys.ID] != null)
            {
                Int64.TryParse(Convert.ToString(Session[SessionKeys.ID]), out _userId);
            }

            SpotEmployeeDo spotEmployeeDo = new SpotEmployeeDo();
            spotEmployeeDo.SpotLeadId = Convert.ToInt64(ddlLeadNo.SelectedValue.ToString());
            spotEmployeeDo.EmployeeNo = txtBxEmpNo.Text != String.Empty ? txtBxEmpNo.Text.Trim() : String.Empty;
            spotEmployeeDo.EmployeeName = txtBxEmpName.Text != String.Empty ? txtBxEmpName.Text.Trim() : String.Empty;
            spotEmployeeDo.EmployeeEmail = txtBxEmpEmail.Text != String.Empty ? txtBxEmpEmail.Text.Trim() : String.Empty;
            spotEmployeeDo.Status = Convert.ToInt64(SpotStatus.INITIATED);
            spotEmployeeDo.CreatedBy = _userId;

            _resultSet = clscommon.SaveSpotEmployeeDetails(spotEmployeeDo, sqlConn);
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return _resultSet;
    }
}