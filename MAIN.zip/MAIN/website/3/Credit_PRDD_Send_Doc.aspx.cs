﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using System.Xml;
using Tracker;
public partial class Credit_PRDD_Send_Doc : System.Web.UI.Page
{
    public static DataTable dtLawyerName = null;
    int ldid, s;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    ClsCommon clscommon = new ClsCommon();
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["AREA_ID"] != null)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                //bind();
                bindArea();
                if (ddlSendBy.SelectedItem.Text == "Courier")
                {
                    lblName.Text = "Courier Name";
                    lblNumber.Text = "POD Number:";
                    BindCourierName();
                }
            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
    }

    /*public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        SqlConnection con1 = new SqlConnection(strcon);
        con1.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con1);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con1.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //txtLeadno.Enabled = false;
        ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
        txtLeadno.Text = "";


    }*/
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    /* protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
     {
         SqlConnection con = new SqlConnection(strcon);
         con.Open();
         SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
         SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
         DataSet dsrsn = new DataSet();
         darsn.Fill(dsrsn);
         con.Close();

         ddlBranch.DataSource = dsrsn;
         ddlBranch.DataTextField = "BR_NAME";
         ddlBranch.DataValueField = "BR_ID";
         ddlBranch.DataBind();
         ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
         ddlBranch.Enabled = true;
        // ddlProduct.SelectedIndex = 0;

     }*/
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con);
        cmdrsn.CommandType = CommandType.StoredProcedure;
        cmdrsn.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.ToString() != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //txtLeadno.Enabled = false;
        txtLeadno.Text = "";
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlArea.SelectedItem.Text == "--Select--" && ddlBranch.SelectedItem.Text == "--Select--" && txtLeadno.Text == "")
            {
                gvLegalRecvDoc.Visible = true;
                Session["View"] = "All";
                //    gridbindall();
                BindBranchSendDoc();
            }
            //else if (txtLeadno.Text == "" )
            //{
            //    gvLegalRecvDoc.Visible = false;
            //    uscMsgBox1.AddMessage("Please Enter Lead No. and Select Process", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            //}
            else
            {
                gvLegalRecvDoc.Visible = true;
                Session["View"] = "F";
                //  gridbind();
                BindBranchSendDoc();
            }
            Panel2.Visible = false;
            Panel3.Visible = false;
            gvMODTDDoc.Visible = false;
            trMOTDGrid.Visible = false;
            ddlName.SelectedValue = "0";
            //ddlSendBy.SelectedValue = "0";
            txtNumber.Text = "";
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    public void BindBranchSendDoc()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_PRDD_WRK", con);
            cmd.CommandType = CommandType.StoredProcedure;
           // cmd.Parameters.AddWithValue("@PR_ID", "0");
            cmd.Parameters.AddWithValue("@LD_BR_ID", ddlBranch.SelectedIndex > 0 ? ddlBranch.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@LD_AR_ID", ddlArea.SelectedIndex > 0 ? ddlArea.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@TranStatus", "GET_DATA");
            cmd.Parameters.AddWithValue("@ReceiveType", "CRS");
            cmd.Parameters.AddWithValue("@LeadNo", txtLeadno.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //Panel1.Visible = true;
            gvLegalRecvDoc.DataSource = ds.Tables[0];
            gvLegalRecvDoc.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvLegalRecvDoc.HeaderRow.Font.Bold = true;
                gvLegalRecvDoc.HeaderRow.Cells[1].Text = "LEAD NO";
                gvLegalRecvDoc.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvLegalRecvDoc.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvLegalRecvDoc.HeaderRow.Cells[4].Text = "PD DATE";
                gvLegalRecvDoc.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvLegalRecvDoc.HeaderRow.Cells[6].Text = "BRANCH NAME";
                //gvResolve.HeaderRow.Cells[6].Text = "QUERY";

                gvLegalRecvDoc.HeaderRow.Cells[1].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[2].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[3].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[4].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[5].Wrap = false;
                gvLegalRecvDoc.HeaderRow.Cells[6].Wrap = false;
                //gvResolve.HeaderRow.Cells[6].Wrap = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }

    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Right;
        }
    }

    public void BranchSendcDocumntUpdate()
    {
        SqlConnection con = new SqlConnection(strcon);
        int ncount = 0;
        try
        {


            con.Open();
            SqlCommand cmd = new SqlCommand("RTS_SP_PRDD_WRK", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PRD_LD_ID", Session["LeadId"].ToString());
            cmd.Parameters.AddWithValue("@PRD_CR_SBY", Session["ID"].ToString());
            cmd.Parameters.AddWithValue("@TranStatus", "CR_SEND");
            // cmd.Parameters.AddWithValue("@SendBy", "C");
            cmd.Parameters.AddWithValue("@PRD_CR_COUR_ID", ddlName.SelectedIndex > 0 ? ddlName.SelectedValue.ToString() : "");
            cmd.Parameters.AddWithValue("@PRD_CR_POD_NO", txtNumber.Text);
            int n = cmd.ExecuteNonQuery();
            if (n > 0)
            {

                uscMsgBox1.AddMessage("Documents Send Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                BindBranchSendDoc();
                Panel2.Visible = false;
                Panel3.Visible = false;
                trMOTDGrid.Visible = false;
                ddlName.SelectedValue = "0";
                //ddlSendBy.SelectedValue = "0";
                txtNumber.Text = "";

                lbLeadno.Text = "";
                lbAppname.Text = "";
                lbPDdate.Text = "";
                lbLoanamt.Text = "";
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        BranchSendcDocumntUpdate();

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_Send_Document.aspx");
    }


    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
          
            int ncount = 0;
            foreach (GridViewRow grow in gvLegalRecvDoc.Rows)
            {
                RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
                LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
                //DropDownList ddrsp = grow.FindControl("Editdd") as DropDownList;
                Label lblState = grow.FindControl("lblState") as Label;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    leadno = lnbtn.Text;
                    appname = gvLegalRecvDoc.Rows[index].Cells[3].Text;
                    pddt = gvLegalRecvDoc.Rows[index].Cells[4].Text;
                    lnamt = gvLegalRecvDoc.Rows[index].Cells[5].Text;
                    //lQuery = gvResolve.Rows[index].Cells[7].Text;
                    ncount = ncount + 1;                                                       
                }


            }
            Session["Leadno"] = leadno;
            getLeadID(con);
            //bala changes 26122016 BindDocGid(con);
            lbLeadno.Visible = true;
            lbAppname.Visible = true;
            lbPDdate.Visible = true;
            lbLoanamt.Visible = true;

            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;

            lbLeadno.Text = leadno;
            lbAppname.Text = appname;
            lbPDdate.Text = pddt;
            lbLoanamt.Text = lnamt;

            Panel3.Visible = true;
            ddlName.SelectedValue = "0";
            //ddlSendBy.SelectedValue = "0";
            txtNumber.Text = "";

            con.Close();
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void fetchMOTDTD()
    {
        try
        {
            DataSet dsMOTD = new DataSet();
            dsMOTD = clscommon.Bind_MODTD_Details(Session["LeadId"].ToString());
            if (dsMOTD.Tables[0].Rows[0]["MD_MOTD_SDATE"] == DBNull.Value)
            {
                trMOTDGrid.Visible = true;
                tblFetchMOTD.Visible = false;
                tblEnterMOTD.Visible = true;

            }
            else
            {
                lblPOD.Text = dsMOTD.Tables[0].Rows[0]["MD_MOTD_POD"] != DBNull.Value ? dsMOTD.Tables[0].Rows[0]["MD_MOTD_POD"].ToString() : "";
                lblCourier.Text = dsMOTD.Tables[0].Rows[0]["MD_MOTD_CR_ID"] != DBNull.Value ? clscommon.GetCourierName(dsMOTD.Tables[0].Rows[0]["MD_MOTD_CR_ID"].ToString()) : "";
                lblSendDate.Text = Convert.ToDateTime(dsMOTD.Tables[0].Rows[0]["MD_MOTD_SDATE"]).ToString("dd/MM/yyyy");
                trMOTDGrid.Visible = true;
                tblFetchMOTD.Visible = true;
                tblEnterMOTD.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }

    }
    protected void cb_select_CheckedChanged(object sender, EventArgs e)
    {

    }
    public void BindDocGid(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("Select MDX_DOC,MDX_DTYPE from LSD_MOTD_DOCX LMD LEFT JOIN  LSD_MOTD  LM ON LMD.MDX_MD_ID =LM.MD_ID  where MD_LD_ID =" + Session["LeadId"].ToString() + "", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0 && ds.Tables[0] != null)
        {
          //bala changes 29/11/2016  Panel2.Visible = true;
            Panel3.Visible = true;
            gvMODTDDoc.Visible = true;
            gvMODTDDoc.DataSource = ds;
            gvMODTDDoc.DataBind();
        }
        else
        {
            Panel2.Visible = false;
            Panel3.Visible = false;
        }


    }
    public void getLeadID(SqlConnection con)
    {
        try
        {
            SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
            cmdbr.CommandType = CommandType.StoredProcedure;
            cmdbr.Parameters.AddWithValue("@LeadNo", Session["Leadno"].ToString());
            SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
            DataSet dsbr = new DataSet();
            dabr.Fill(dsbr);
            Session["LeadId"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlSendBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlSendBy.SelectedItem.Text == "Courier")
        {
            lblName.Text = "Courier Name";
            lblNumber.Text = "POD Number:";
            BindCourierName();
        }
        else if (ddlSendBy.SelectedItem.Text == "By Hand")
        {
            lblName.Text = "Person Name";
            lblNumber.Text = "Contact No:";
            BindPesonName();
        }
    }
    public void BindPesonName()
    {
        try
        {


            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("Select * from MR_EMPLOYEE Where EMP_ET_ID=15", con);
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);

            con.Close();
            ddlName.DataSource = dsdd;
            ddlName.DataTextField = "EMP_NAME";
            ddlName.DataValueField = "EMP_ID";
            ddlName.DataBind();
            ddlName.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void BindCourierName()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_CourierListas", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);

        con.Close();
        ddlName.DataSource = dsdd;
        ddlName.DataTextField = "CR_NAME";
        ddlName.DataValueField = "CR_ID";
        ddlName.DataBind();
        ddlName.Items.Insert(0, new ListItem("--Select--", "0"));
    }



}