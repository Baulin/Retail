﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class BC_SendApplicationtoOps : System.Web.UI.Page
{
    int  s;
    string bcacode;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string lProduct = "";
    string lQuery = "";
    string rcvquery;
    int prid;
    string query;
    int ldid;
    int qryid;
    int qryldid;
    int selectedcnt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["UNITNAME"] != null)
            {
                txtdate.Text = String.Format("{0:dd MMM yyyy}", dt);
                // txtBranch.Text = Session["UNITNAME"].ToString();
                bindArea();
                bind();
            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();
        ddlProduct.DataSource = dsdd;
        ddlProduct.DataTextField = "PR_CODE";
        ddlProduct.DataValueField = "PRD";
        ddlProduct.DataBind();
        ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));
    }

    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;


    }
    public void getLeadID(SqlConnection con)
    {
        //SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
        //cmdbr.CommandType = CommandType.StoredProcedure;
        //cmdbr.Parameters.AddWithValue("@LeadNo", Session["Leadno"].ToString());
        //SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        //DataSet dsbr = new DataSet();
        //dabr.Fill(dsbr);
        DataSet dsbr = new DataSet();
        dsbr = clscommon.GetBCApplicationForm_Details_ByBCACODE(Session["BCACODE"].ToString());
        Session["BCAId"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["BCA_ID"]);
    }
  
   
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {


            //InsertBranchResolveQueriesVal();
            InsertUpdateSendAndReceivveData();

        }

        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void InsertUpdateSendAndReceivveData()
    {
        int nCheckStatus = 0;
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            s = 0;
            con.Open();
            foreach (GridViewRow grow in gvResolve.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    s += 1;
                    nCheckStatus = 1;
                    Label lblLeadID = (Label)gvResolve.Rows[index].Cells[0].FindControl("lblLeadID");

                    ldid = lblLeadID.Text != "" ? Convert.ToInt32(lblLeadID.Text) : 0;

                    //SqlCommand cmdupdate = new SqlCommand("UpdateBCApp_Send_TO_OPs", con);
                    //cmdupdate.CommandType = CommandType.StoredProcedure;
                   
                    //cmdupdate.Parameters.AddWithValue("@BCA_ID", ldid);
                    //cmdupdate.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                  
                    //cmdupdate.ExecuteNonQuery();
                    clscommon.UpdateBCApp_Send_TO_OPs(Convert.ToInt32(lblLeadID.Text), Session["ID"].ToString());

                }
            }
            if (nCheckStatus != 0)
            {
               
               
                    uscMsgBox1.AddMessage(s + " File/s Send Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
               
            }
            gridbind();
            
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_ResolveQuery.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            Session["View"] = "All";
            gridbind();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
  
    public void gridbind()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmdprid = new SqlCommand("select PR_ID from MR_PRODUCT WHERE PR_CODE='" + ddlProduct.SelectedValue.ToString() + "'", con);
            //SqlDataAdapter daprid = new SqlDataAdapter(cmdprid);
            //DataSet dsprid = new DataSet();
            //daprid.Fill(dsprid);
            //prid = Convert.ToInt32(ddlProduct.SelectedValue);

            string[] PRARR = ddlProduct.SelectedIndex > 0 ? ddlProduct.SelectedValue.ToString().Split('-') : null;
            if (PRARR != null)
            {
                prid = Convert.ToInt32(PRARR[0].ToString());
            }
            else prid = 0;
            query = "";
            if (ddlQuery.SelectedValue.ToString() == "Credit")
            {
                query = "C";
            }
            else if (ddlQuery.SelectedValue.ToString() == "Legal")
            {
                query = "L";
            }
            else if (ddlQuery.SelectedValue.ToString() == "QC")
            {
                query = "H";
            }
            Session["QRYBY"] = query;

            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_BCA_Branch_SEND_FILE", con);
            cmd.CommandType = CommandType.StoredProcedure;
            // cmd.Parameters.AddWithValue("@PR_ID", prid);
            //cmd.Parameters.AddWithValue("@QRY_RSD_BY", "R");
            //cmd.Parameters.AddWithValue("@BCA_BR_ID", Session["BRANCHID"] != null ? ddlBranch.SelectedValue : "0");
            cmd.Parameters.AddWithValue("@BCA_CODE", txtBCACODE.Text);
            cmd.Parameters.AddWithValue("@AR_NAME", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BR_NAME", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedItem.ToString() : "");
            cmd.Parameters.AddWithValue("@BCA_APP_STAT", "Shortlisted");


            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
           // ds = clscommon.Bind_ShortlistedBC_Application("Shortlisted", Convert.ToInt32(ddlBranch.SelectedValue));
            gvResolve.DataSource = ds.Tables[0];
            gvResolve.DataBind();
           
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                //e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[7].HorizontalAlign = HorizontalAlign.Left;
            //e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        string qryby = Session["QRYBY"].ToString();
        Session["sa2"] = qryby;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Branch_ResolveQueryPopup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    protected void ddlQuery_SelectedIndexChanged(object sender, EventArgs e)
    {
        //qrydetsbind();
        // gvResolve.Visible = false;
       
    }
    protected void ddlProduct_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
}