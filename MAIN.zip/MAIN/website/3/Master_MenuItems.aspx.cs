﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Master_MenuItems : System.Web.UI.Page
{
    //ConfigurationManager.ConnectionStrings["con_Objnection"].ConnectionString;

    DataView dv = new DataView();
    int res = 0;

    SqlConnection con_obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_obj = new SqlCommand();

    SqlDataAdapter da_obj = new SqlDataAdapter();

    DataTable dt_obj = new DataTable();
    DataSet ds_obj = new DataSet();

    CreateLogFiles Err = new CreateLogFiles();

    #region Menu Insert/Update Variables
    private string PTYPE="";
    private string LM_ID = "";
    private string LM_GM_ID = "";
    private string LM_GM = "";
    private string LM_MM_ID = "";
    private string LM_MM = "";
    private string LM_SM_ID = "";
    private string LM_SM = "";
    private string LM_PAGE = "";
    private string LM_STAT = "";
    


    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            if (!IsPostBack)
            {
                Bind_MR_Menu("", "All");

            }
        }
        else
        {
            Response.Redirect("Expire.aspx", false);
        }
    }
    protected void Bind_MR_Menu(string val, string type)
    {
        try
        {



            dt_obj = new DataTable();

            con_obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_obj.State == ConnectionState.Broken || con_obj.State == ConnectionState.Closed)
                con_obj.Open();
            cmd_obj = new SqlCommand("SP_RTS_BIND_MR_MENU", con_obj);

            cmd_obj.CommandType = CommandType.StoredProcedure;
            cmd_obj.Parameters.AddWithValue("@LM_TYPE", ddlst_module.SelectedValue);

            cmd_obj.CommandTimeout = 120000;
            dt_obj.Load(cmd_obj.ExecuteReader());



            if (type == "All")
            {
                gv_menumaster.DataSource = dt_obj;

                gv_menumaster.DataBind();

                /* GROUP MENU BINDING */

                var query = (from gm in dt_obj.AsEnumerable()
                             select new
                             {
                                 LM_GM = gm.Field<string>("LM_GM"),
                                 LM_GM_ID = gm.Field<string>("LM_GM_ID"),

                             }
                            ).Distinct();



                ddlst_grpname.DataSource = query.ToList();
                ddlst_grpname.DataValueField = "LM_GM_ID";
                ddlst_grpname.DataTextField = "LM_GM";
                ddlst_grpname.DataBind();
                ddlst_grpname.Items.Insert(0, new ListItem("--Select--", "0"));


            }

            /* MAIN MENU BINDING */
            if (type == "MM")
            {
                var grymm = (from mm in dt_obj.AsEnumerable()
                             where mm.Field<Object>("LM_MM") != DBNull.Value && mm.Field<string>("LM_GM") == val

                             select new
                             {
                                 LM_MM = mm.Field<string>("LM_MM"),
                                 LM_MM_ID = mm.Field<string>("LM_MM_ID"),

                             }
                             ).Distinct();



                ddlst_menuname.DataSource = grymm.ToList();
                ddlst_menuname.DataValueField = "LM_MM_ID";
                ddlst_menuname.DataTextField = "LM_MM";
                ddlst_menuname.DataBind();
                ddlst_menuname.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlst_menuname.Items.Remove("");
            }

            /* SUB MENU BINDING */
            if (type == "SM")
            {
                var grysm = (from sm in dt_obj.AsEnumerable()
                             where sm.Field<string>("LM_SM") != "" && sm.Field<Object>("LM_SM") != DBNull.Value && sm.Field<string>("LM_MM") == val
                             select new
                             {
                                 LM_SM = sm.Field<string>("LM_SM"),
                                 LM_SM_ID = sm.Field<string>("LM_SM_ID"),

                             }
                              ).Distinct();



                ddlst_submenuname.DataSource = grysm.ToList();
                ddlst_submenuname.DataValueField = "LM_SM_ID";
                ddlst_submenuname.DataTextField = "LM_SM";
                ddlst_submenuname.DataBind();
                ddlst_submenuname.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlst_submenuname.Items.Remove("");
            }
            if (type == "ALLLIST")
            {
                gv_menumaster.DataSource = dt_obj;

                gv_menumaster.DataBind();


                /* GROUP MENU BINDING */

                var query = (from gm in dt_obj.AsEnumerable()
                             select new
                             {
                                 LM_GM = gm.Field<string>("LM_GM"),
                                 LM_GM_ID = gm.Field<string>("LM_GM_ID"),

                             }
                            ).Distinct();



                ddlst_grpname.DataSource = query.ToList();
                ddlst_grpname.DataValueField = "LM_GM_ID";
                ddlst_grpname.DataTextField = "LM_GM";
                ddlst_grpname.DataBind();
                ddlst_grpname.Items.Insert(0, new ListItem("--Select--", "0"));

                /* MAIN MENU BINDING */

                var qrymm = (from mm in dt_obj.AsEnumerable()
                             select new
                             {
                                 LM_MM = mm.Field<string>("LM_MM"),
                                 LM_MM_ID = mm.Field<string>("LM_MM_ID"),

                             }).Distinct();



                ddlst_menuname.DataSource = qrymm.ToList();
                ddlst_menuname.DataValueField = "LM_MM_ID";
                ddlst_menuname.DataTextField = "LM_MM";
                ddlst_menuname.DataBind();
                ddlst_menuname.Items.Insert(0, new ListItem("--Select--", "0"));


                /* SUB MENU BINDING */

                var qrysm = (from sm in dt_obj.AsEnumerable()
                             select new
                             {
                                 LM_SM = sm.Field<string>("LM_SM"),
                                 LM_SM_ID = sm.Field<string>("LM_SM_ID"),

                             }
                           ).Distinct();



                ddlst_submenuname.DataSource = qrysm.ToList();
                ddlst_submenuname.DataValueField = "LM_SM_ID";
                ddlst_submenuname.DataTextField = "LM_SM";
                ddlst_submenuname.DataBind();
                ddlst_submenuname.Items.Insert(0, new ListItem("--Select--", "0"));

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_obj.Dispose();
            con_obj.Close();
            con_obj.Dispose();
            da_obj.Dispose();
            SqlConnection.ClearPool(con_obj);
        }


    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow gvrw in gv_menumaster.Rows)
            {
                RadioButton rbtn = gvrw.FindControl("rb_select") as RadioButton;
                if (rbtn.Checked)
                {
                    Session["SELECTEDLMID"] = (gvrw.FindControl("lbl_lmid") as Label).Text;

                    Clear();

                    ddlst_grpname.SelectedValue = (gvrw.FindControl("lbl_gmid") as Label).Text;
                    Bind_MR_Menu(ddlst_grpname.SelectedItem.Text, "MM");

                    if ((gvrw.FindControl("lbl_mmid") as Label).Text != "")
                    {

                        ddlst_menuname.SelectedValue = (gvrw.FindControl("lbl_mmid") as Label).Text;
                        Bind_MR_Menu(ddlst_menuname.SelectedItem.Text, "SM");


                    }
                    else
                    {
                        Bind_MR_Menu(ddlst_menuname.SelectedItem.Text, "SM");
                        ddlst_menuname.SelectedValue = "0";

                    }

                    if ((gvrw.FindControl("lbl_smid") as Label).Text != "")
                    {

                        ddlst_submenuname.SelectedValue = (gvrw.FindControl("lbl_smid") as Label).Text;
                    }
                    else
                    {

                        ddlst_submenuname.SelectedValue = "0";
                    }


                    if (ddlst_grpname.SelectedIndex > 0 && (ddlst_menuname.SelectedItem.Text == "" || ddlst_menuname.SelectedValue == "0"))
                    {
                        txtbx_menudesc.Text = (gvrw.FindControl("lbl_gm") as Label).Text;

                    }
                    else if (ddlst_grpname.SelectedIndex > 0 && ddlst_menuname.SelectedIndex > 0 && (ddlst_submenuname.SelectedItem.Text == "" || ddlst_submenuname.SelectedValue == "0"))
                    {
                        txtbx_menudesc.Text = (gvrw.FindControl("lbl_mm") as Label).Text;
                    }
                    else
                    {
                        txtbx_menudesc.Text = (gvrw.FindControl("lbl_sm") as Label).Text;
                    }

                    txtbx_webpage.Text = (gvrw.FindControl("lbl_webpge") as Label).Text != "" ? (gvrw.FindControl("lbl_webpge") as Label).Text : "";

                    if ((gvrw.FindControl("lbl_stat") as Label).Text == "ACTIVE")
                    {
                        ddlst_menustat.SelectedValue = "1";
                    }
                    else
                    {
                        ddlst_menustat.SelectedValue = "0";
                    }
                    btn_addmenu.Text = "Update";
                    break;
                }

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void Clear()
    {
        if (ddlst_grpname.Items.Count > 0)
            ddlst_grpname.SelectedIndex = 0;

        if (ddlst_menuname.Items.Count > 0)
            ddlst_menuname.SelectedIndex = 0;

        if (ddlst_submenuname.Items.Count > 0)
            ddlst_submenuname.SelectedIndex = 0;

        if (ddlst_menustat.Items.Count > 0)
            ddlst_menustat.SelectedIndex = 0;

        txtbx_menudesc.Text = "";
        txtbx_webpage.Text = "";

        ddlst_module.SelectedIndex = 0;
    }


    protected void btn_addmenu_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtbx_menudesc.Text.Trim() == "" && btn_addmenu.Text != "Update")
            {

              
                uscMsgBox1.AddMessage("Please enter the Menu description", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                return;
            }

            else
            {
                if (btn_addmenu.Text == "Update")
                {
                 
                    PTYPE = "UPDATE";
                    ID = Session["ID"].ToString();// "343";// Session["ID"].ToString();



                    LM_PAGE = txtbx_webpage.Text.Trim() != "" ? txtbx_webpage.Text.Trim() : "";
                    LM_STAT = ddlst_menustat.SelectedValue;
                    LM_ID = Session["SELECTEDLMID"].ToString();


                    LM_GM = ddlst_grpname.SelectedItem.Text;
                    LM_GM_ID = ddlst_grpname.SelectedValue;

                    LM_MM = ddlst_menuname.SelectedItem.Text;
                    LM_MM_ID = ddlst_menuname.SelectedValue;
                    LM_SM = txtbx_menudesc.Text.Trim();
                    LM_SM_ID = ddlst_submenuname.SelectedValue;



                    if (ddlst_grpname.SelectedIndex > 0 && (ddlst_menuname.SelectedItem.Text == "" || ddlst_menuname.SelectedValue == "0"))
                    {
                        LM_GM = txtbx_menudesc.Text.Trim();

                    }
                    else if (ddlst_grpname.SelectedIndex > 0 && ddlst_menuname.SelectedIndex > 0 && (ddlst_submenuname.SelectedItem.Text == "" || ddlst_submenuname.SelectedValue == "0"))
                    {
                        LM_MM = txtbx_menudesc.Text.Trim();
                    }
                    else
                    {
                        LM_SM = txtbx_menudesc.Text.Trim();
                    }

                    res = Insert_Update_Menu();

                    if (res > 0)
                    {

                        btn_addmenu.Text = "Submit";
                        Bind_MR_Menu("", "ALLLIST");
                        Clear();
                        uscMsgBox1.AddMessage("Menu Item updated successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        return;
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Menu item not updated  ", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                        return;
                    }
                }
                else
                {

                    
                    PTYPE = "INSERT";
                    ID = Session["ID"].ToString();// "343";//Session["ID"].ToString();

                    LM_GM_ID = ddlst_grpname.SelectedValue;

                    LM_MM_ID = ddlst_menuname.SelectedValue;

                    LM_SM_ID = ddlst_submenuname.SelectedValue;

                    LM_PAGE = txtbx_webpage.Text.Trim() != "" ? txtbx_webpage.Text.Trim() : "";
                    LM_STAT = ddlst_menustat.SelectedValue;

                    if (ddlst_grpname.SelectedValue == "0" && ddlst_menuname.SelectedValue == "0" && ddlst_submenuname.SelectedValue == "0")
                    {
                        LM_GM = txtbx_menudesc.Text.Trim();
                    }
                    else if (ddlst_grpname.SelectedIndex > 0 && ddlst_menuname.SelectedValue == "0" && ddlst_submenuname.SelectedValue == "0")
                    {


                        LM_GM = ddlst_grpname.SelectedItem.Text;
                        LM_GM_ID = ddlst_grpname.SelectedValue;
                        LM_MM = txtbx_menudesc.Text.Trim();
                    }
                    else if (ddlst_grpname.SelectedIndex > 0 && ddlst_menuname.SelectedIndex > 0 && ddlst_submenuname.SelectedValue == "0")
                    {
                        LM_GM = ddlst_grpname.SelectedItem.Text;
                        LM_GM_ID = ddlst_grpname.SelectedValue;

                        LM_MM = ddlst_menuname.SelectedItem.Text;
                        LM_MM_ID = ddlst_menuname.SelectedValue;
                        LM_SM = txtbx_menudesc.Text.Trim();
                    }


                    res = Insert_Update_Menu();


                    if (res > 0)
                    {

                        Bind_MR_Menu("", "ALLLIST");
                  
                        uscMsgBox1.AddMessage("Menu Item added successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Menu Item not added", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }


            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_obj.Dispose();
            con_obj.Close();
            con_obj.Dispose();
            da_obj.Dispose();
            SqlConnection.ClearPool(con_obj);
        }

    }
    protected void btn_Cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_MenuItems.aspx");
    }
    protected void ddlst_grpname_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlst_grpname.SelectedItem.Text != "--Select--")
        {
            Bind_MR_Menu(ddlst_grpname.SelectedItem.Text, "MM");

        }
    }
    protected void ddlst_menuname_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlst_menuname.SelectedItem.Text != "--Select--")
        {
            Bind_MR_Menu(ddlst_menuname.SelectedItem.Text, "SM");

        }
    }

    protected void ddlst_module_SelectedIndexChanged(object sender, EventArgs e)
    {
        Bind_MR_Menu("", "All");
        
    }
    public int Insert_Update_Menu()
    {
        try
        {

            con_obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con_obj.State == ConnectionState.Broken || con_obj.State == ConnectionState.Closed)
                con_obj.Open();
            cmd_obj = new SqlCommand("SP_RTS_MR_MENU_INSERT_UPDATE", con_obj);
            cmd_obj.CommandType = CommandType.StoredProcedure;
            cmd_obj.Parameters.AddWithValue("@PTYPE", PTYPE);
            cmd_obj.Parameters.AddWithValue("@LM_ID", LM_ID);
            cmd_obj.Parameters.AddWithValue("@LM_GM_ID", LM_GM_ID);
            cmd_obj.Parameters.AddWithValue("@LM_GM", LM_GM);
            cmd_obj.Parameters.AddWithValue("@LM_MM_ID", LM_MM_ID);
            cmd_obj.Parameters.AddWithValue("@LM_MM", LM_MM);
            cmd_obj.Parameters.AddWithValue("@LM_SM_ID", LM_SM_ID);
            cmd_obj.Parameters.AddWithValue("@LM_SM", LM_SM);
            cmd_obj.Parameters.AddWithValue("@LM_PAGE", LM_PAGE);
            cmd_obj.Parameters.AddWithValue("@LM_STAT", LM_STAT);
            cmd_obj.Parameters.AddWithValue("@LM_TYPE", ddlst_module.SelectedValue);
            cmd_obj.Parameters.AddWithValue("@LM_CBY", ID);

            cmd_obj.CommandTimeout = 120000;
            int rs = cmd_obj.ExecuteNonQuery();

            if (rs > 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }


        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);

            return 0;
        }
        finally
        {
            cmd_obj.Dispose();
            con_obj.Close();
            con_obj.Dispose();
            da_obj.Dispose();
            SqlConnection.ClearPool(con_obj);
        }

    }
}