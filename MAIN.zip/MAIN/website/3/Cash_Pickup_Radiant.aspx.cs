﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class Cash_Pickup_Radiant : System.Web.UI.Page
{

    #region Common
    SqlConnection con_Obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_Obj = new SqlCommand();
    DataTable dt_obj = new DataTable();
    CreateLogFiles Err = new CreateLogFiles();
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack)
                {

                }
            }
            else Response.Redirect("~/Default.aspx");
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }

    protected void btnImport_Click(object sender, EventArgs e)
    {

        CSV();
    }

    protected void CSV()
    {
        try
        {
            Page.Validate("ValGroup");
            if (Page.IsValid)
            {
                DataTable dtPck = new DataTable();
                dtPck.Columns.Add("DATE", typeof(string));
                dtPck.Columns.Add("BRANCH", typeof(string));
                dtPck.Columns.Add("SME", typeof(string));
                dtPck.Columns.Add("TWL", typeof(string));
                dtPck.Columns.Add("MFHF", typeof(string));

                string fileExt = Path.GetExtension(fUpxlRad.PostedFile.FileName);
                string fileName = AppConstants.FileNamePrefix_Pickup + DateTime.Now.ToString("dd-MM-yyyy hhmmss") + fileExt;
                string fileUploadPath = ConfigurationManager.AppSettings[AppConstants.FileUploadPath] + "\\" + fileName;
                fUpxlRad.SaveAs(Server.MapPath(fileUploadPath));

                string filePath = Server.MapPath(fileUploadPath);
                StreamReader sr = new StreamReader(filePath);
                string rdLine = sr.ReadLine();
                int i = 0;
                while (!sr.EndOfStream)
                {
                    i++;
                    string content = sr.ReadLine();
                    string[] values = content.Split(new char[] { ',' });
                    DataRow drw = dtPck.NewRow();
                    drw["DATE"] = values[0];
                    drw["BRANCH"] = values[1];
                    drw["SME"] = values[2];
                    drw["TWL"] = values[3];
                    drw["MFHF"] = values[4];
                    dtPck.Rows.Add(drw);
                }
                if (dtPck.Rows.Count > 0)
                {
                    string dtes = string.Empty;
                    for (int j = 0; j <= dtPck.Rows.Count - 1; j++)
                    {
                        string[] dte = dtPck.Rows[j][0].ToString().Split('/');
                        dtes = dte[1] + "/" + dte[0] + "/" + dte[2];
                        dtPck.Rows[j][0] = dtes;
                        dtPck.AcceptChanges();
                    }
                    con_Obj.Open();
                    cmd_Obj = new SqlCommand("RTS_SP_DAILY_CASH_SUMMARY", con_Obj);
                    cmd_Obj.CommandType = CommandType.StoredProcedure;
                    cmd_Obj.CommandTimeout = 240000000;
                    cmd_Obj.Parameters.AddWithValue("@UDT_PKUP", dtPck);
                    cmd_Obj.Parameters.AddWithValue("@PKUP_CBY", Convert.ToString(Session["EMPID"]));
                    cmd_Obj.Parameters.AddWithValue("@PTYPE", "PKUPINSERT");
                    int res = cmd_Obj.ExecuteNonQuery();
                    if (res > 0)
                    {
                        uscMsgBox1.AddMessage("Cash Pickup Inserted Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Cash pickup Insertion Failed", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_Obj.Dispose();
            con_Obj.Close();
            con_Obj.Dispose();
            SqlConnection.ClearPool(con_Obj);
        }
    }

    public void CheckType(object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
    {
        bool isValid = true;
        if (fUpxlRad.FileName.Length > 0)
        {
            isValid = false;
            //string iconName = "";
            if (fUpxlRad.Visible & fUpxlRad.HasFile)
            {
                string origName = fUpxlRad.FileName;
                string ext = origName.Substring(origName.LastIndexOf(".")).Replace(".", "");
                if (ext.ToLower() == "csv")
                {
                    isValid = true;
                }
            }
            //else
            //    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('File upload is not an acceptable csv file.');", true);
        }
        args.IsValid = isValid;
    }
}