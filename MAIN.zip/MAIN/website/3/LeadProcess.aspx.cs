﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class LeadProcess : System.Web.UI.Page
{
     public static DataTable dtLawyerName = null;
    int ldid,s;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindLeadStatusGrid();
        }
    }
    public void BindLeadStatusGrid()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM MR_PROCESS order by PRS_SLNO", con);                    
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
          
            gvRcvfile.DataSource = ds.Tables[0];
            gvRcvfile.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvRcvfile.Visible = true;
                gvRcvfile.HeaderRow.Font.Bold = true;            
              

                gvRcvfile.HeaderRow.Cells[1].Wrap = false;
                gvRcvfile.HeaderRow.Cells[2].Wrap = false;
                gvRcvfile.HeaderRow.Cells[3].Wrap = false;
              
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Unable to Retrieve Lead Record/s ! Please check ", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
          SqlConnection con = new SqlConnection(strcon);
        try
        {
            int nQuery = 0;
            con.Open();
            TimeSpan ts = new TimeSpan();
            foreach (GridViewRow grow in gvRcvfile.Rows)
            {
                CheckBox cb_select = grow.FindControl("cb_select") as CheckBox;
                TextBox txt_pd_dt = grow.FindControl("txt_pd_dt") as TextBox;
                TextBox txtCommentDetails = grow.FindControl("txtCommentDetails") as TextBox;
                Label lblPrsID = grow.FindControl("lblPrsID") as Label;
                int index = grow.RowIndex;
                bool nWrondDate = false;
                if (cb_select.Checked)
                {
                    if (txt_pd_dt.Enabled == true)
                    {

                        if (txt_pd_dt.Text != "" && txt_pd_dt.Text != "C" && index != 0)
                        {
                            //if (DateTime.ParseExact(txt_pd_dt.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture) >= DateTime.ParseExact(DateTime.Now.ToString("dd/MM/yyyy"), "dd/MM/yyyy", CultureInfo.InvariantCulture))
                            //{
                                string strDate = DateTime.ParseExact(txt_pd_dt.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                                if (strDate != null)
                                {
                                    SqlCommand cmd = new SqlCommand("RTS_PR_Insert_lead_Status", con);
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    cmd.Parameters.AddWithValue("@LS_LD_NO", txtLeadno.Text);
                                    cmd.Parameters.AddWithValue("@LS_PRS_ID", lblPrsID.Text);
                                    cmd.Parameters.AddWithValue("@LS_CTDATE", strDate);
                                    cmd.Parameters.AddWithValue("@LS_LCOMMIT", txtCommentDetails.Text);
                                    cmd.Parameters.AddWithValue("@ID", Session["ID"].ToString());

                                    nQuery = cmd.ExecuteNonQuery();
                                }
                           // }
                            //else
                            //{
                            //    nWrondDate = true;
                            //    //uscMsgBox1.AddMessage("You cannot select a day earlier than today! ", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                            //}
                        }
                      

                       
                    }
                }
                else
                {
                   
                }
                //if (nWrondDate == true)
                //{
                //    uscMsgBox1.AddMessage("You cannot select a day earlier than today! ", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                //}
                
            }
            if (nQuery > 0)
            {
                uscMsgBox1.AddMessage("Lead Status saved Sucessfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                txtLeadno.Text = "";
                BindLeadStatusGrid();
            }
       
        }
        catch(Exception ex)
        {
            uscMsgBox1.AddMessage("Error in save Lead status ", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("LeadProcess.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {

            clear();
            SqlConnection con = new SqlConnection(strcon);
            try
            {
                if (txtLeadno.Text != "")
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("RTS_PR_LEAD_PROCESS", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@LEADNO", txtLeadno.Text);
                    cmd.Parameters.AddWithValue("@BranchID", Session["BRANCHID"].ToString());
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet dsLead = new DataSet();
                    da.Fill(dsLead);
                    int nCount = 1;
                    if (dsLead.Tables[0] != null && dsLead.Tables[0].Rows.Count > 0)
                    {
                        foreach (GridViewRow grow in gvRcvfile.Rows)
                        {

                            CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                            TextBox txt_pd_dt = grow.FindControl("txt_pd_dt") as TextBox;
                            TextBox txtCommentDetails = grow.FindControl("txtCommentDetails") as TextBox;
                            string strInputVal = dsLead.Tables[0].Rows[0][nCount] != DBNull.Value ? dsLead.Tables[0].Rows[0][nCount].ToString() : "";
                            if (strInputVal != "")
                            {
                                chkStat.Checked = true;
                                if (strInputVal == "NA")
                                {
                                    chkStat.Enabled = false;
                                    chkStat.Checked = false;
                                    txt_pd_dt.Text = strInputVal;
                                }
                                else if (strInputVal == "C")
                                {

                                    chkStat.Enabled = false;
                                }
                                else
                                {
                                    chkStat.Enabled = true;
                                    chkStat.Checked = false;
                                    string[] strVal = strInputVal.Split('|');
                                    txt_pd_dt.Text = strVal[0].ToString();
                                    txtCommentDetails.Text = strVal[1].ToString();
                                }
                            }
                            else
                            {
                                chkStat.Enabled = true;
                                //txt_pd_dt.Enabled = true;
                                //txtCommentDetails.Enabled = true;
                                chkStat.Checked = false;
                            }
                            if (nCount == 1)
                            {
                                chkStat.Enabled = false;
                                chkStat.Checked = true;
                              //  txt_pd_dt.Text = "";
                            }

                            nCount = nCount + 1;


                        }
                    }
                    else
                    {
                        uscMsgBox1.AddMessage("Please enter valid Lead No! ", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                }
                else
                {
                    uscMsgBox1.AddMessage("Please enter the Lead no! ", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                }
                
            }
            catch (Exception ex)
            {
                uscMsgBox1.AddMessage("Unable to Retrieve Lead Record/s ! Please check ", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
            }
           
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        
        foreach (GridViewRow grow in gvRcvfile.Rows)
        {
             int index = grow.RowIndex;
            CheckBox cb_select = grow.FindControl("cb_select") as CheckBox;
            TextBox txt_pd_dt = grow.FindControl("txt_pd_dt") as TextBox;
            TextBox txtCommentDetails = grow.FindControl("txtCommentDetails") as TextBox;
           
            if (cb_select.Checked)
            {
                //if (txt_pd_dt.Text == "" || )
                //{
                if (cb_select.Enabled)
                {
                    txt_pd_dt.Enabled = true;
                    txtCommentDetails.Enabled = true;
                }
                //}
            }
            else
            {
               // txt_pd_dt.Text = ""; txtCommentDetails.Text = "";
                txt_pd_dt.Enabled = false;
                txtCommentDetails.Enabled = false;
            }
        }
       
        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;
    }
    public void clear()
    {
        BindLeadStatusGrid();
        btnSubmit.Enabled = false;

    }
}