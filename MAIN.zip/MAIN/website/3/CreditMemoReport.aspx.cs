﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using Tracker;

public partial class CreditMemoReport : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    ClsCommon clscommon = new ClsCommon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ID"] != null)
        {
            ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
            scriptManager.RegisterPostBackControl(this.btncrdtmemoSubmit);
            scriptManager.RegisterPostBackControl(this.btnSubmit);

            if (!IsPostBack)
            {
                ViewState["DDLSTLDNO"] = null;
              //  BindLeadNo();
            }
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
    }
    public void BindLeadNo()
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Credit_Memo_Report", con);
            cmddd.Parameters.AddWithValue("@LD_NO", txtbxleadno.Text);
            cmddd.Parameters.AddWithValue("@Lead_Type", "");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            ViewState["DDLSTLDNO"] = dsdd.Tables[0];
            con.Close();
            //ddlLeadNo.DataSource = dsdd;
            //ddlLeadNo.DataTextField = "LD_NO";
            //ddlLeadNo.DataValueField = "LD_ID";
            //ddlLeadNo.DataBind();
            //ddlLeadNo.Items.Insert(0, "Select");
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();

        img.ImageUrl = Server.MapPath("~/Images/JPG/MIFLogo.JPG");
        tdLogo.Controls.Add(img);

        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=Credit_Memo_" + txtbxleadno.Text + ".pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        StringWriter sw0 = new StringWriter();
        HtmlTextWriter hw0 = new HtmlTextWriter(sw0);
        pnlHeader.RenderControl(hw0);

        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);

        if (!txtbxleadno.Text.Contains("TWL"))
        {
            pnlpdf.RenderControl(hw);
        }
        else
        {
            pnlTWLpdf.RenderControl(hw);
        }

        StringReader sr1 = new StringReader(sw0.ToString() + "<br/>" + sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        pdfDoc.NewPage();
        pdfDoc.HtmlStyleClass = "PdfClass";
        htmlparser.Parse(sr1);
        pdfDoc.NewPage();

        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    protected void ddlLeadNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {


            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Credit_Memo_Detail", con);
            cmddd.Parameters.AddWithValue("@LD_ID", ddlLeadNo.SelectedItem.Text != "--Select--" ? ddlLeadNo.SelectedValue.ToString() : "");
            cmddd.Parameters.AddWithValue("@Lead_Type", "");
            cmddd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
            DataSet dsdd = new DataSet();
            dadd.Fill(dsdd);
            if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
            {
                txtProduct.Text = dsdd.Tables[0].Rows[0]["PR_CODE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PR_CODE"].ToString() : "";
                txtCustname.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                txtLocation.Text = dsdd.Tables[0].Rows[0]["LOCATION"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LOCATION"].ToString() : "";


                txtApplicant.Text = dsdd.Tables[0].Rows[0]["CM_APL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_APL"].ToString() : "";
                txtCoapp1.Text = dsdd.Tables[0].Rows[0]["CM_CAPL1"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CAPL1"].ToString() : "";
                txtCoapp2.Text = dsdd.Tables[0].Rows[0]["CM_CAPL2"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CAPL2"].ToString() : "";
                txtCoapp3.Text = dsdd.Tables[0].Rows[0]["CM_CAPL3"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CAPL3"].ToString() : "";
                txtCoapp4.Text = dsdd.Tables[0].Rows[0]["CM_CAPL4"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CAPL4"].ToString() : "";
                txtCoapp5.Text = dsdd.Tables[0].Rows[0]["CM_CAPL5"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CAPL5"].ToString() : "";


                txtRentalIncome.Text = dsdd.Tables[0].Rows[0]["CM_RINC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_RINC"].ToString() : "";
                txtClubIncome.Text = dsdd.Tables[0].Rows[0]["CM_CINC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CINC"].ToString() : "";
                txtOtherObligation.Text = dsdd.Tables[0].Rows[0]["CM_OBLIG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_OBLIG"].ToString() : "";
                txtInsurPropValue.Text = dsdd.Tables[0].Rows[0]["CM_IPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_IPV"].ToString() : "";
                txtBuildingVal.Text = dsdd.Tables[0].Rows[0]["CM_BV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_BV"].ToString() : "";
                txtLandVal.Text = dsdd.Tables[0].Rows[0]["CM_LV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_LV"].ToString() : "";


                txtTotProbVal.Text = dsdd.Tables[0].Rows[0]["CM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_TPV"].ToString() : "";
                txtConstrCost.Text = dsdd.Tables[0].Rows[0]["CM_CC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CC"].ToString() : "";
                txtTenure.Text = dsdd.Tables[0].Rows[0]["CM_TNR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_TNR"].ToString() : "";
                txtROI.Text = dsdd.Tables[0].Rows[0]["CM_ROI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_ROI"].ToString() : "";


                txtLoanAmount.Text = dsdd.Tables[0].Rows[0]["CM_LMNT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_LMNT"].ToString() : "";
                txtEMI.Text = dsdd.Tables[0].Rows[0]["CM_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_EMI"].ToString() : "";

                txtActIIR.Text = dsdd.Tables[0].Rows[0]["CM_IIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_IIR"].ToString() : "";
                txtActFIR.Text = dsdd.Tables[0].Rows[0]["CM_FOIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_FOIR"].ToString() : "";

                txtLCR.Text = dsdd.Tables[0].Rows[0]["CM_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_LCR"].ToString() : "";
                txtLTV.Text = dsdd.Tables[0].Rows[0]["CM_LTV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_LTV"].ToString() : "";


                txtIIRLCR.Text = dsdd.Tables[0].Rows[0]["CM_IIR_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_IIR_LCR"].ToString() : "";
                txtLapPropLTV.Text = dsdd.Tables[0].Rows[0]["CM_LLTV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_LLTV"].ToString() : "";

                txtConditon.Text = dsdd.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "";
                lblRemarks.Text = dsdd.Tables[0].Rows[0]["CM_REMARKS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_REMARKS"].ToString() : "";
                txtApprovedBy.Text = dsdd.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
            }

            if (ddlLeadNo.SelectedItem.Text.StartsWith("MHF") || ddlLeadNo.SelectedItem.Text.StartsWith("GHF"))
            {
                trNonMFProd1.Visible = false;
                trNonMFProd2.Visible = false;
                trNonMFProd3.Visible = false;
                trNonMFProd4.Visible = false;
                trMFProd1.Visible = true;
                trMFProd2.Visible = true;
                trMFProd3.Visible = true;
            }
            else
            {
                trMFProd1.Visible = false;
                trNonMFProd1.Visible = true;
                trNonMFProd2.Visible = true;
                trNonMFProd3.Visible = true;
                trNonMFProd4.Visible = true;
                trMFProd2.Visible = false;
                trMFProd3.Visible = false;
            }

            con.Close();
        }catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void GenerateReport()
    {
        try
        {
            if (txtbxleadno.Text != "")
            {
                BindLeadNo();

                System.Data.DataTable dt = new System.Data.DataTable();

                DataTable vst = (DataTable)ViewState["DDLSTLDNO"];

                var res = from rw in vst.AsEnumerable()
                          where rw.Field<string>("LD_NO").Equals(txtbxleadno.Text)
                          select rw;

                if (res.Count() > 0)
                // (dt.Rows.Count > 0)
                {

                    dt = res.CopyToDataTable();


                    SqlConnection con = new SqlConnection(strcon);
                    con.Open();
                    SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_Credit_Memo_Detail", con);
                    cmddd.Parameters.AddWithValue("@LD_ID", dt.Rows[0]["LD_ID"] != DBNull.Value ? dt.Rows[0]["LD_ID"].ToString() : "");
                    cmddd.Parameters.AddWithValue("@Lead_Type", "");
                    cmddd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
                    DataSet dsdd = new DataSet();
                    dadd.Fill(dsdd);
                    if (dsdd.Tables[0] != null && dsdd.Tables[0].Rows.Count > 0)
                    {
                        txtleadno.Text = txtbxleadno.Text;
                        txtProduct.Text = dsdd.Tables[0].Rows[0]["PR_CODE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["PR_CODE"].ToString() : "";
                        txtCustname.Text = dsdd.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                        txtLocation.Text = dsdd.Tables[0].Rows[0]["LOCATION"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LOCATION"].ToString() : "";


                        txtApplicant.Text = dsdd.Tables[0].Rows[0]["CM_APL"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_APL"].ToString() : "";
                        txtCoapp1.Text = dsdd.Tables[0].Rows[0]["CM_CAPL1"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CAPL1"].ToString() : "";
                        txtCoapp2.Text = dsdd.Tables[0].Rows[0]["CM_CAPL2"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CAPL2"].ToString() : "";
                        txtCoapp3.Text = dsdd.Tables[0].Rows[0]["CM_CAPL3"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CAPL3"].ToString() : "";
                        txtCoapp4.Text = dsdd.Tables[0].Rows[0]["CM_CAPL4"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CAPL4"].ToString() : "";
                        txtCoapp5.Text = dsdd.Tables[0].Rows[0]["CM_CAPL5"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CAPL5"].ToString() : "";


                        txtRentalIncome.Text = dsdd.Tables[0].Rows[0]["CM_RINC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_RINC"].ToString() : "";
                        txtClubIncome.Text = dsdd.Tables[0].Rows[0]["CM_CINC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CINC"].ToString() : "";
                        txtOtherObligation.Text = dsdd.Tables[0].Rows[0]["CM_OBLIG"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_OBLIG"].ToString() : "";
                        txtInsurPropValue.Text = dsdd.Tables[0].Rows[0]["CM_IPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_IPV"].ToString() : "";
                        txtBuildingVal.Text = dsdd.Tables[0].Rows[0]["CM_BV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_BV"].ToString() : "";
                        txtLandVal.Text = dsdd.Tables[0].Rows[0]["CM_LV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_LV"].ToString() : "";


                        txtTotProbVal.Text = dsdd.Tables[0].Rows[0]["CM_TPV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_TPV"].ToString() : "";
                        txtConstrCost.Text = dsdd.Tables[0].Rows[0]["CM_CC"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CC"].ToString() : "";
                        txtTenure.Text = dsdd.Tables[0].Rows[0]["CM_TNR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_TNR"].ToString() : "";
                        txtROI.Text = dsdd.Tables[0].Rows[0]["CM_ROI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_ROI"].ToString() : "";


                        txtLoanAmount.Text = dsdd.Tables[0].Rows[0]["CM_LMNT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_LMNT"].ToString() : "";
                        txtEMI.Text = dsdd.Tables[0].Rows[0]["CM_EMI"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_EMI"].ToString() : "";

                        txtActIIR.Text = dsdd.Tables[0].Rows[0]["CM_IIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_IIR"].ToString() : "";
                        txtActFIR.Text = dsdd.Tables[0].Rows[0]["CM_FOIR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_FOIR"].ToString() : "";

                        txtLCR.Text = dsdd.Tables[0].Rows[0]["CM_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_LCR"].ToString() : "";
                        txtLTV.Text = dsdd.Tables[0].Rows[0]["CM_LTV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_LTV"].ToString() : "";


                        txtIIRLCR.Text = dsdd.Tables[0].Rows[0]["CM_IIR_LCR"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_IIR_LCR"].ToString() : "";
                        txtLapPropLTV.Text = dsdd.Tables[0].Rows[0]["CM_LLTV"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_LLTV"].ToString() : "";

                        txtConditon.Text = dsdd.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "";
                        lblRemarks.Text = dsdd.Tables[0].Rows[0]["CM_REMARKS"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["CM_REMARKS"].ToString() : "";
                        txtApprovedBy.Text = dsdd.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
                        txtApprovedDate.Text = dsdd.Tables[0].Rows[0]["APPDATE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["APPDATE"].ToString() : "";
                        lblCommericalRealEstate.Text= dsdd.Tables[0].Rows[0]["LD_CRE"] != DBNull.Value ? dsdd.Tables[0].Rows[0]["LD_CRE"].ToString() : "";
                    }

                    if (txtbxleadno.Text.StartsWith("MHF") || txtbxleadno.Text.StartsWith("GHF") || txtProduct.Text.Contains("EMP-HF"))
                    {
                        trNonMFProd1.Visible = false;
                        trNonMFProd2.Visible = false;
                        trNonMFProd3.Visible = false;
                        trNonMFProd4.Visible = false;
                        trMFProd1.Visible = true;
                        trMFProd2.Visible = true;
                        trMFProd3.Visible = true;
                    }
                    else
                    {
                        trMFProd1.Visible = false;
                        trNonMFProd1.Visible = true;
                        trNonMFProd2.Visible = true;
                        trNonMFProd3.Visible = true;
                        trNonMFProd4.Visible = true;
                        trMFProd2.Visible = false;
                        trMFProd3.Visible = false;
                    }

                    con.Close();
                }
                else
                {
                    pnlHeader.Visible = false;
                    pnlpdf.Visible = false;
                    uscMsgBox1.AddMessage("No Records Found", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
            }
            else
            {
                uscMsgBox1.AddMessage("Please enter lead number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void btncrdtmemoSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            if (txtbxleadno.Text != "")
            {
                BindLeadNo();

                System.Data.DataTable dt = new System.Data.DataTable();

                DataTable vst = (DataTable)ViewState["DDLSTLDNO"];

                var res = from rw in vst.AsEnumerable()
                          where rw.Field<string>("LD_NO").Equals(txtbxleadno.Text)
                          select rw;

                if (res.Count() > 0)
                // (dt.Rows.Count > 0)
                {

                    dt = res.CopyToDataTable();

                    string ld_id = dt.Rows[0]["LD_ID"].ToString();

                    if (!txtbxleadno.Text.Contains("TWL"))
                    {
                        trTWLCreditMemo.Visible = false;
                        trCreditMemo.Visible = true;
                        GenerateReport();
                    }
                    else
                    {
                        fillTWLCreditApprvMemo(ld_id, txtbxleadno.Text, con);
                        trTWLCreditMemo.Visible = true;
                        trCreditMemo.Visible = false;
                    }
                }
            }
           
        }
        catch(Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    public void fillTWLCreditApprvMemo(string strLeadID, string strLeadNO, SqlConnection con)
    {
        try
        {
            SqlCommand cmdCrdAprvMemo = new SqlCommand("RTS_SP_FetchCredit_Approval_Memo", con);
            cmdCrdAprvMemo.CommandType = CommandType.StoredProcedure;
            cmdCrdAprvMemo.Parameters.AddWithValue("@LeadID", strLeadID);
            SqlDataAdapter daCrdAprvMemo = new SqlDataAdapter(cmdCrdAprvMemo);
            DataSet dsCrdAprvMemo = new DataSet();
            DataSet dsCrdAprvMemo1 = new DataSet();
            dsCrdAprvMemo1 = clscommon.Get_RTS_SP_CAMFULLDETAILS_TWL(strLeadNO, "C");
            daCrdAprvMemo.Fill(dsCrdAprvMemo);
            DataSet dsMemo = new DataSet();
            dsMemo = clscommon.Get_RTS_SP_Fetch_Credit_Memo_Detail_mailer(strLeadNO, "");
          
                //Start
                if (dsMemo.Tables[0].Rows.Count > 0 && dsMemo.Tables[0] != null)
                {
                    txtTWLLeadno.Text = txtbxleadno.Text;
                    txtTWLProduct.Text = dsCrdAprvMemo.Tables[0].Rows[0]["PR_CODE"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["PR_CODE"].ToString() : "";
                    txtTWLCusName.Text = dsCrdAprvMemo.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                    string strAraAndBranch = dsCrdAprvMemo.Tables[0].Rows[0]["AR_NAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["AR_NAME"].ToString() : "";
                    txtTWLSRCofIncome.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT SOURCE OF INCOME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT SOURCE OF INCOME"].ToString() : "";
                    lblTWLMemberType.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["RELATIONSHIP WITH EQUITASIN"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["RELATIONSHIP WITH EQUITASIN"].ToString() : "";

                    if (strAraAndBranch != "")
                    {
                        strAraAndBranch = strAraAndBranch + "/";
                    }
                    // if (dsCrdAprvMemo1.Tables[0].Rows.Count > 0 && dsCrdAprvMemo1.Tables[0] != null)
                    // {
                    txtTWLApplicant.Text = dsMemo.Tables[0].Rows[0]["LD_APNAME"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["LD_APNAME"].ToString() : "";
                    txtTWLApplicant1.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT1 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT1 NAME"].ToString() : "";
                    txtTWLApplicant2.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT2 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT2 NAME"].ToString() : "";
                    txtTWLApplicant3.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT3 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT3 NAME"].ToString() : "";
                    txtTWLApplicant4.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT4 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT4 NAME"].ToString() : "";
                    txtTWLApplicant5.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT5 NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["APPLICANT5 NAME"].ToString() : "";
                    txtTWLAplAMT.Text = dsMemo.Tables[0].Rows[0]["CM_APL"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_APL"].ToString() : "0.00";

                    txtTWLCOAplAMT1.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL1"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL1"].ToString() : "0.00";
                    txtTWLCOAplAMT2.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL2"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL2"].ToString() : "0.00";
                    txtTWLCOAplAMT3.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL3"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL3"].ToString() : "0.00";
                    txtTWLCOAplAMT4.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL4"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL4"].ToString() : "0.00";
                    txtTWLCOAplAMT5.Text = dsMemo.Tables[0].Rows[0]["CM_CAPL5"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CAPL5"].ToString() : "0.00";
                    txtTWLLoanAmount.Text = dsMemo.Tables[0].Rows[0]["CM_LMNT"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LMNT"].ToString() : "0.00";
                    txtTWLEMI.Text = dsMemo.Tables[0].Rows[0]["CM_EMI"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_EMI"].ToString() : "";
                    //txtRentalIncome.Text = dsMemo.Tables[0].Rows[0]["CM_RINC"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_RINC"].ToString() : "";
                    txtTWLClubIncome.Text = dsMemo.Tables[0].Rows[0]["CM_CINC"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CINC"].ToString() : "";
                    txtTWLOtherObligation.Text = dsMemo.Tables[0].Rows[0]["CM_OBLIG"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_OBLIG"].ToString() : "";
                    // txtTWLInsurPropValue.Text = dsMemo.Tables[0].Rows[0]["CM_IPV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_IPV"].ToString() : "";
                    // txtBuildingVal.Text = dsMemo.Tables[0].Rows[0]["CM_BV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_BV"].ToString() : "0.00";
                    //txtLandVal.Text = dsMemo.Tables[0].Rows[0]["CM_LV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LV"].ToString() : "0.00";
                    // txtIIR.Text = dsMemo.Tables[0].Rows[0]["CM_IIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_IIR"].ToString() : "0.00";
                    //txtFOIR.Text = dsMemo.Tables[0].Rows[0]["CM_FOIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_FOIR"].ToString() : "0.00";
                    //  txttwlIIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_IIR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_IIR"].ToString() : "0.00";
                    //  txtFOIR.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_FOIR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_FOIR"].ToString() : "0.00";

                    txtTWLActIIR.Text = dsMemo.Tables[0].Rows[0]["CM_IIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_IIR"].ToString() : "";
                    txtTWLActFIR.Text = dsMemo.Tables[0].Rows[0]["CM_FOIR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_FOIR"].ToString() : "";
                    //Bala changes 12/0/2016 txtTWLLapPropLTV.Text = dsMemo.Tables[0].Rows[0]["CM_LLTV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LLTV"].ToString() : "";

                    txtTWLLapPropLTV.Text = dsMemo.Tables[0].Rows[0]["CM_LLTV"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LLTV"].ToString() : "";
                    //txttwlTotProbVal.Text = dsMemo.Tables[0].Rows[0]["CM_TPV"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CM_TPV"].ToString() : "";
                    txtTWLManufacturer.Text = (dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_NAME"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_NAME"].ToString() : "") + "/" + (dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_MODEL"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["LVH_MODEL"].ToString() : "");
                    txtTWLVehicleCost.Text = dsMemo.Tables[0].Rows[0]["CM_LVH_RATE"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_LVH_RATE"].ToString() : "0.00";

                    txtTWLCondition.Text = dsMemo.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "Subject to legal clearance.";
                    // txtLCRVal.Text = dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"] != DBNull.Value ? dsCrdAprvMemo1.Tables[0].Rows[0]["CAM_LTV_LCR"].ToString() : "";
                    //}
                    strAraAndBranch += dsCrdAprvMemo.Tables[0].Rows[0]["BR_NAME"] != DBNull.Value ? dsCrdAprvMemo.Tables[0].Rows[0]["BR_NAME"].ToString() : "0.00";
                    txtTWLLocation.Text = strAraAndBranch;
                    txtTWLROI.Text = dsMemo.Tables[0].Rows[0]["CM_ROI"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_ROI"].ToString() : "0.00";
                    txtTWLTenure.Text = dsMemo.Tables[0].Rows[0]["CM_TNR"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_TNR"].ToString() : "0.00";
                    /*  if (txtTenure.Text != "")
                      {
                          txtTenure.Text = Math.Round(Convert.ToDouble(txtTenure.Text) * 12).ToString();
                      }*/
                    double presentValue = 100000;
                    if (txtTWLTenure.Text != "" && txtTWLROI.Text != "")
                    {
                        // txtEMI.Text = Math.Round(GetEMI(presentValue, Convert.ToDouble(txtTenure.Text), Convert.ToDouble(txtROI.Text))).ToString();
                    }

                    //txtTWLApprovedBy.Text = Session["EMPNAME"] != null ? Session["EMPNAME"].ToString() : "";
                    //txtTWLRemarks.Text = dsMemo.Tables[0].Rows[0]["CM_REMARKS"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_REMARKS"].ToString() : "";

                    txtTWLCondition.Text = dsMemo.Tables[0].Rows[0]["CM_CREDIT"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_CREDIT"].ToString() : "";
                    txtTWLRemarks.Text = dsMemo.Tables[0].Rows[0]["CM_REMARKS"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["CM_REMARKS"].ToString() : "";
                    txtTWLApprovedBy.Text = dsMemo.Tables[0].Rows[0]["EMP_NAME"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["EMP_NAME"].ToString() : "";
                    txtTWLApprovedDate.Text = dsMemo.Tables[0].Rows[0]["APPDATE"] != DBNull.Value ? dsMemo.Tables[0].Rows[0]["APPDATE"].ToString() : "";
                }
                //END
            //}
                if (txtProduct.Text.Contains("MF") || txtProduct.Text.Contains("G-HF") || txtProduct.Text.Contains("EMP-HF"))
            {
                trMFProd1.Visible = true;
                trMFProd2.Visible = true;
                trMFProd3.Visible = true;

                trNonMFProd1.Visible = false;
                trNonMFProd2.Visible = false;
                trNonMFProd3.Visible = false;
                trNonMFProd4.Visible = false;
            }
            else
            {
                trNonMFProd1.Visible = true;
                trNonMFProd2.Visible = true;
                trNonMFProd3.Visible = true;
                trNonMFProd4.Visible = true;

                trMFProd1.Visible = false;
                trMFProd2.Visible = false;
                trMFProd3.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
           

        }
    }
}