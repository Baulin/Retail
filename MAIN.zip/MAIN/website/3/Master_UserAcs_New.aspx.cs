﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using System.Configuration;
using Tracker;

public partial class Master_UserAcs_New : System.Web.UI.Page
{
    
   
    public static Boolean treeviewselect;
    ArrayList l = new ArrayList();
    object obj;
    string v;
    string conStr = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DataSet ds = new DataSet();

   
    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter da = new SqlDataAdapter();
    DataTable dt = new DataTable();
    SqlConnection con = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddl_usrtypeLoad();
            try
            {
                DataSet ds = new DataSet();
                DataTable dtparent = new DataTable();
                DataTable dtchild = new DataTable();
                DataTable dtchild1 = new DataTable();
                dtparent = FillParentTable();
                dtparent.TableName = "A";
                dtchild = FillChildTable();
                dtchild.TableName = "B";
              
                
                ds.Tables.Add(dtparent);
                ds.Tables.Add(dtchild);
            
                ds.Relations.Add("children", dtparent.Columns["LM_GM_ID"], dtchild.Columns["LM_GM_ID"]);
              
                if (ds.Tables[0].Rows.Count > 0)
                {
                    tvTables.Nodes.Clear();

                    foreach (DataRow masterRow in ds.Tables[0].Rows)
                    {
                        if (Convert.ToString(masterRow["LM_GM_ID"]) != "")
                        {
                            TreeNode masterNode = new TreeNode((string)masterRow["LM_GM"], Convert.ToString(masterRow["LM_GM_ID"]));
                            tvTables.Nodes.Add(masterNode);
                            tvTables.CollapseAll();
                            //string strChildName = "";
                            foreach (DataRow childRow in masterRow.GetChildRows("Children"))
                            {
                                TreeNode childNode = new TreeNode((string)childRow["Menu_desc"], Convert.ToString(childRow["LM_GM_ID"]));

                                if (childNode.Text != "")
                                {
                                    masterNode.ChildNodes.Add(childNode);

                                    childNode.Value = Convert.ToString(childRow["LM_MM_ID"]);

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw new Exception("Unable to populate treeview" + ex.Message);
            }



        }






    }

    public DataTable FillParentTable()
    {
        DataSet ds = new DataSet();
        con = new SqlConnection(conStr);     
        DataTable dt = new DataTable();
        DataTable dtnew = new DataTable();
        con.Open();

        cmd = new SqlCommand("RTS_Fetch_User_ACS_Datas", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        adp.Fill(ds);
        cmd.ExecuteNonQuery();
        dt = ds.Tables[0];
        con.Close();
        dtnew = dt.Copy();

        return dtnew;
    }
    
        public DataTable FillChildTable()
    {
        con = new SqlConnection(conStr);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        DataTable dtnew = new DataTable();
        con.Open();

        cmd = new SqlCommand("RTS_Fetch_User_ACS_Datas", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        adp.Fill(ds);
        cmd.ExecuteNonQuery();
        dt = ds.Tables[1];
        con.Close();
        dtnew = dt.Copy();

        return dtnew;
    }
        public DataTable FillSubChildTable()
        {
            con = new SqlConnection(conStr);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            DataTable dtnew = new DataTable();
            con.Open();

            cmd = new SqlCommand("RTS_Fetch_User_ACS_Datas", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(ds);
            cmd.ExecuteNonQuery();
            dt = ds.Tables[2];
            con.Close();
            dtnew = dt.Copy();

            return dtnew;
        }
    protected void ddl_usrtypeLoad()
    {
       DataSet ds1 = ddlusertypeload();
        DataTable dt = ds1.Tables[0];
        ddl_usrtype.Items.Clear();

        ddl_usrtype.SelectedIndex = -1;
        ddl_usrtype.Items.Insert(0, new ListItem("--Select--", "0"));
        ddl_usrtype.DataValueField = "UTP_ID";
        ddl_usrtype.DataTextField = "UTP_DESC";
        foreach (DataRow dr in dt.Rows)
        {
            ddl_usrtype.Items.Add(new ListItem(dr["UTP_DESC"].ToString(), dr["UTP_ID"].ToString()));

        }

    }
    public DataSet ddlusertypeload()
    {
        con = new SqlConnection(conStr);

        try
        {
            DataSet ds = new DataSet();
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
            {
                con.Open();
                cmd = new SqlCommand("select DISTINCT UTP_ID,UTP_DESC from MR_USER_TYPE", con);            
                da = new SqlDataAdapter(cmd);
                da.Fill(ds);

            }
            return ds;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            return ds;
        }
        finally
        {
            con.Close();
        }

    }
    public void usrdeletebeforeinsert(int @UA_UTP_ID)
    {
        con = new SqlConnection(conStr);
        con.Open();
        SqlCommand cmd1 = new SqlCommand("delete from  MR_USER_ACS where UA_UTP_ID="+@UA_UTP_ID+"", con);
        //cmd1.CommandType = CommandType.StoredProcedure;
        //cmd1.Parameters.AddWithValue("@UA_UTP_ID", b);
        cmd1.ExecuteNonQuery();
        con.Close();
    }
    public void insetuseraccess(int UTP_ID, int LM_ID,int UA_CBY)
    {
        con = new SqlConnection(conStr);
        con.Open();
        cmd = new SqlCommand("Rts_Sp_usraccinsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UA_UTP_ID",UTP_ID);
        cmd.Parameters.AddWithValue("@UA_LM_ID", LM_ID);
        cmd.Parameters.AddWithValue("@UA_CBY",UA_CBY);
        cmd.ExecuteNonQuery();
        con.Close();

    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        try
        {
            usrdeletebeforeinsert(Convert.ToInt32(ddl_usrtype.SelectedItem.Value));
            foreach (TreeNode t in tvTables.CheckedNodes)
            {
                if (t.Checked == true)
                {
                    var dd = t.Text;
                    var s = t.Value;
                   int LM_ID = readmenuid(s);
                   if (LM_ID != 0)
                    {
                        
                       insetuseraccess(Convert.ToInt32(ddl_usrtype.SelectedItem.Value),LM_ID,1);

                    }

                }
            }
            ClientScript.RegisterStartupScript(typeof(Page), "Message", "alert('Assigned Successfully');", true);

           
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Assigned Failed", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }



    }
    public int readmenuid(string @LM_GM_ID)
    {
        con = new SqlConnection(conStr);

        con.Open();
        cmd = new SqlCommand("select LM_ID from MR_LSD_MENU  where (LM_GM_ID=" + @LM_GM_ID + " or LM_MM_ID=" + @LM_GM_ID + ") AND LM_TYPE='R' ", con);
        //cmd.CommandType = CommandType.StoredProcedure;
        //cmd.Parameters.AddWithValue("@LM_GM_ID", s);
        var count = cmd.ExecuteScalar();
     
        con.Close();
        return  Convert.ToInt16(count);
    }
    protected void ddl_usrtype_SelectedIndexChanged(object sender, EventArgs e)
    {
        treeviewselect = true;
        tvTables.Dispose();
        TreeNodeautoselect();
    }
    public DataSet treeautoselect(int i)
    {
        con = new SqlConnection(conStr);
        DataSet ds1 = new DataSet();
        try
        {

            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
            {
                con.Open();
                cmd = new SqlCommand("Rts_SP_treeview_autoselect", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UA_UTP_ID", i);
                //cmd = new SqlCommand(" select UA_LM_ID from MR_USER_ACS where UA_UTP_ID="+i+"", con);
                da = new SqlDataAdapter(cmd);
                da.Fill(ds1);



            }
            return ds1;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            return ds1;
        }
        finally
        {
            con.Close();
        }
    }
    public DataSet treeautoselectchild(int i)
    {
        con = new SqlConnection(conStr);
        DataSet ds1 = new DataSet();
        try
        {

            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
            {
                con.Open();
                cmd = new SqlCommand("Rts_Sp_treeview_autoselect1", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UA_UTP_ID", i);
                //cmd = new SqlCommand(" select UA_LM_ID from MR_USER_ACS where UA_UTP_ID="+i+"", con);
                da = new SqlDataAdapter(cmd);
                da.Fill(ds1);



            }
            return ds1;
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            return ds1;
        }
        finally
        {
            con.Close();
        }
    }
    protected void TreeNodeautoselect()
    {
        try
        {
            DataSet ds = new DataSet();
            DataTable dtparent = new DataTable();
            DataTable dtchild = new DataTable();
            dtparent =FillParentTable();
            dtparent.TableName = "A";
            dtchild = FillChildTable();
            dtchild.TableName = "B";

            ds.Tables.Add(dtparent);
            ds.Tables.Add(dtchild);

            ds.Relations.Add("children", dtparent.Columns["LM_GM_ID"], dtchild.Columns["LM_GM_ID"]);

            if (ds.Tables[0].Rows.Count > 0)
            {
                tvTables.Nodes.Clear();

                foreach (DataRow masterRow in ds.Tables[0].Rows)
                {
                    if (Convert.ToString(masterRow["LM_GM_ID"]) != "")
                    {
                    TreeNode masterNode = new TreeNode((string)masterRow["LM_GM"], Convert.ToString(masterRow["LM_GM_ID"]));
                    tvTables.Nodes.Add(masterNode);
                    DataSet dsss = new DataSet();
                    dsss = treeautoselect(Convert.ToInt32(ddl_usrtype.SelectedItem.Value));
                    if (dsss.Tables.Count != 0)
                    {
                        DataTable dt111 = dsss.Tables[0];

                        foreach (DataRow dr in dt111.Rows)
                        {
                            if (masterNode.Value == dr["LM_GM_ID"].ToString())
                            {
                                masterNode.Checked = true;
                            }

                        }
                    }
                    tvTables.CollapseAll();
                    foreach (DataRow childRow in masterRow.GetChildRows("Children"))
                    {
                        TreeNode childNode = new TreeNode((string)childRow["Menu_desc"], Convert.ToString(childRow["LM_GM_ID"]));
                        if (childNode.Text != "")
                        {

                            masterNode.ChildNodes.Add(childNode);
                            childNode.Value = Convert.ToString(childRow["LM_MM_ID"]);
                        }
                        DataSet ds1 = new DataSet();

                        ds1 = treeautoselectchild(Convert.ToInt32(ddl_usrtype.SelectedItem.Value));
                        if (ds1.Tables.Count != 0)
                        {
                            DataTable dt11 = ds1.Tables[0];

                            foreach (DataRow dr in dt11.Rows)
                            {
                                if (childNode.Value == dr["LM_MM_ID"].ToString())
                                {
                                    childNode.Checked = true;
                                }

                            }
                        }


                    }
                }
                }

            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            throw new Exception("Unable to populate treeview" + ex.Message);
        }

    }
    protected void btn_cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_UserAcs_New.aspx");
    }
}