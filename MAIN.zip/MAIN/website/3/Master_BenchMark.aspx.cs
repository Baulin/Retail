﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tracker;

public partial class Master_BenchMark : System.Web.UI.Page
{
    SqlConnection con_obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    SqlCommand cmd_obj = new SqlCommand();
       CreateLogFiles Err = new CreateLogFiles();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
              
            }
            else
            {
                Response.Redirect("Expire.aspx");
            }
        }
    }
   

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {


            con_obj = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

            if (con_obj.State == ConnectionState.Broken || con_obj.State == ConnectionState.Closed)
                con_obj.Open();

            cmd_obj = new SqlCommand("SP_RTS_EXT_BENCHMARK", con_obj);
            cmd_obj.CommandType = CommandType.StoredProcedure;

            cmd_obj.Parameters.AddWithValue("@PTYPE", "INSERT");
            cmd_obj.Parameters.AddWithValue("@RATE", txtbx_rate.Text.Trim());
            cmd_obj.Parameters.AddWithValue("@ID", Convert.ToString(Session["ID"]));
            
            


            if (cmd_obj.ExecuteNonQuery() > 0)
            {

                uscMsgBox1.AddMessage("External Benchmark / T Bill Rate added successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

            }
            else
            {

                uscMsgBox1.AddMessage("External Benchmark / T Bill Rate  not added", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
            }

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd_obj.Dispose();
            con_obj.Close();
            con_obj.Dispose();

            SqlConnection.ClearPool(con_obj);

        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Master_BenchMark.aspx");
    }
}