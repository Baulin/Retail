﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Globalization;
using Tracker;

public partial class Branch_EMI_Reminder : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();

    SqlDataAdapter dapemi = new SqlDataAdapter();

    DataTable dtbl = new DataTable();

    List<string> PERSON = new List<string>();

    DataSet dsemi = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {

        txtbxptpdate.Attributes.Add("readonly", "readonly");
        if (!IsPostBack)
        {
            if (Session["UNITNAME"] != null)
            {
                bindArea();
                try
                {

                    con = new SqlConnection(strcon);
                   

                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();

                    cmd = new SqlCommand("select CONVERT(varchar,getdate(),101)", con);
                    cmd.CommandTimeout = 120000;
                    var servdate = cmd.ExecuteScalar();
                    txtbxdtofconfirm.Text = Convert.ToDateTime(servdate.ToString()).ToString("dd-MMM-yyyy").ToUpper();

                    hdnfldservdate.Value = servdate != DBNull.Value ? servdate.ToString() : DateTime.Now.ToString("MM/dd/yyyy");
                    txtbxemibranch.Text = Session["UNITNAME"] != DBNull.Value ? Session["UNITNAME"].ToString() : "";
                    Bind_Product();
                    btnsubmitemi.Enabled = false;
                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }
                finally
                {
                    cmd.Dispose();
                    con.Close();


                }

                this.dets.Visible = false;
                this.inputs.Visible = false;
                this.colothersh.Visible = false;
                this.colothers.Visible = false;
                this.fsOthers.Visible = false;
                this.fsotherstxtbx.Visible = false;

            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
       

    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        ddlstemiproduct.SelectedIndex = 0;

    }

    protected void ddlbranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlstemiproduct.SelectedIndex = 0;
    }
    protected void Bind_Product()
    {
        try
        {

            ddlstemiproduct.Items.Clear();
            con = new SqlConnection(strcon);

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con);
            cmd.CommandType = CommandType.StoredProcedure;
            dapemi = new SqlDataAdapter(cmd);
            dtbl = new DataTable();
            dapemi.Fill(dtbl);


            ddlstemiproduct.DataSource = dtbl;
            ddlstemiproduct.DataTextField = "PR_CODE";
            ddlstemiproduct.DataValueField = "PRD";
            ddlstemiproduct.DataBind();
            ddlstemiproduct.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            // dapemi.Dispose();
            con.Close();


        }

    }
    protected void btnemiView_Click(object sender, EventArgs e)
    {
        if (ddlstemiproduct.SelectedItem.Text == "--Select--" && txtbxemiloanno.Text == "")
        {
            this.dets.Visible = false;
            this.paydetshead.Visible = false;
            this.paydets.Visible = false;
            this.calldetshead.Visible = false;
            this.calldets.Visible = false;
            this.inputs.Visible = false;
            this.colothersh.Visible = false;
            this.colothers.Visible = false;
            this.fsOthers.Visible = false;
            this.fsotherstxtbx.Visible = false;
            uscMsgBox1.AddMessage("Please select the Product or enter loan number", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);

        }
        else if (ddlstemiproduct.SelectedItem.Text != "--Select--" && txtbxemiloanno.Text == "")
        {

            Bind_LoanDets();

            this.dets.Visible = true;
            this.paydetshead.Visible = false;
            this.paydets.Visible = false;
            this.calldetshead.Visible = false;
            this.calldets.Visible = false;
            this.inputs.Visible = false;
            this.colothersh.Visible = false;
            this.colothers.Visible = false;
            this.fsOthers.Visible = false;
            this.fsotherstxtbx.Visible = false;

            div_position.Value = "0";
            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "method", "ScrollPosition();", true);


        }
        else if (txtbxemiloanno.Text != "")
        {
            Bind_LoanDets();

            this.dets.Visible = true;
            this.paydetshead.Visible = false;
            this.paydets.Visible = false;
            this.calldetshead.Visible = false;
            this.calldets.Visible = false;
            this.inputs.Visible = false;
            this.colothersh.Visible = false;
            this.colothers.Visible = false;
            this.fsOthers.Visible = false;
            this.fsotherstxtbx.Visible = false;
            div_position.Value = "0";
            ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "method", "ScrollPosition();", true);
        }
    }

    protected void Bind_LoanDets()
    {

        try
        {


            con = new SqlConnection(strcon);

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("RTS_SP_BIND_EMI_REMINDER", con);
            cmd.Parameters.AddWithValue("@LNNO", txtbxemiloanno.Text.Trim().ToUpper());
            cmd.Parameters.AddWithValue("@PROD", ddlstemiproduct.SelectedItem.Text != "--Select--" ? ddlstemiproduct.SelectedItem.Text : "");
          //Bala changes 24/02/2016
            //  cmd.Parameters.AddWithValue("@BRANCH", txtbxemibranch.Text.Trim().ToUpper());
            cmd.Parameters.AddWithValue("@BRANCH", ddlBranch.SelectedItem.Text.ToUpper());
            cmd.CommandType = CommandType.StoredProcedure;
            dapemi = new SqlDataAdapter(cmd);
            dtbl = new DataTable();
            dapemi.Fill(dtbl);
            gvloandets.DataSource = dtbl;
            gvloandets.DataBind();






        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            // dapemi.Dispose();
            con.Close();


        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        foreach (GridViewRow grow in gvloandets.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            Label lblloan = grow.FindControl("lbllnno") as Label;
            Label lblcusn = grow.FindControl("lblcusname") as Label;
            Label lbldue = grow.FindControl("lblduedt") as Label;//
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {

                //div_position.Value = index.ToString();

                //ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "method", "ScrollPosition();", true);
                Session["EMILNNO"] = lblloan.Text;
                Session["EMIDUE"] = DateTime.ParseExact(lbldue.Text, "dd MMM yyyy", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy");


                try
                {
                    con = new SqlConnection(strcon);

                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();

                    cmd = new SqlCommand("RTS_SP_EMI_APPLICANT", con);
                    cmd.Parameters.AddWithValue("@LNNO", lblloan.Text);

                    cmd.CommandType = CommandType.StoredProcedure;
                    dapemi = new SqlDataAdapter(cmd);
                    dtbl = new DataTable();
                    dapemi.Fill(dtbl);

                    string[] ARR = new string[500];
                    ARR = dtbl.Rows[0]["CUSTOMER"] != DBNull.Value ? dtbl.Rows[0]["CUSTOMER"].ToString().Split('|') : null;
                    if (ARR != null)
                    {
                        PERSON = new List<string>();
                        PERSON.Add("--Select--");
                        foreach (string s in ARR)
                        {

                            PERSON.Add(s);

                        }
                        PERSON.Add("Others");
                    }

                    ddlstlnameofperson.Items.Clear();

                    ddlstlnameofperson.DataSource = PERSON;
                    ddlstlnameofperson.DataBind();


                }
                catch (Exception ex)
                {
                    ErrorLog.WriteError(ex);
                }
                finally
                {
                    cmd.Dispose();
                    // dapemi.Dispose();
                    con.Close();


                }



                Bind_PYMNT_BNCE();
                Bind_Call_Status();
                // Bind_FieldStaff();
                ddlstfieldstaff.SelectedIndex = 0;
                ddlstmode.SelectedIndex = 0;

                txtbxothers.Text = "";
                txtbxfsothers.Text = "";
                txtbxrmks.Text = "";
                txtbxptpdate.Text = "";
                this.paydetshead.Visible = true;
                this.paydets.Visible = true;
                this.calldetshead.Visible = true;
                this.calldets.Visible = true;
                this.inputs.Visible = true;
                break;
            }
        }
        
    }
    protected void ddlstlnameofperson_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlstlnameofperson.SelectedItem.Text == "Others")
        {
            this.colothersh.Visible = true;
            this.colothers.Visible = true;
        }
        else
        {
            this.colothersh.Visible = false;
            this.colothers.Visible = false;
        }
    }
    protected void ClearEMIReminder()
    {



        // ddlstemiproduct.SelectedIndex = 0;
        txtbxemiloanno.Text = "";


        txtbxdtofconfirm.Text = "";
        txtbxmobno.Text = "";
        txtbxcusaddr.Text = "";
        txtbxduedate.Text = "";

        txtbxinstalmntno.Text = "";
        txtbxinstalmntamt.Text = "";
        txtbxoverdueamt.Text = "";

        ddlstcallstatus.SelectedIndex = 0;
        ddlstfieldstaff.SelectedIndex = 0;
        ddlstlnameofperson.SelectedIndex = 0;
        txtbxothers.Text = "";

        ddlstmode.SelectedIndex = 0;
        ddlstfund.SelectedIndex = 0;
        txtbxptpdate.Text = "";
        txtbxrmks.Text = "";

        //view click event to be called here


        this.paydetshead.Visible = false;
        this.paydets.Visible = false;
        this.calldetshead.Visible = false;
        this.calldets.Visible = false;
        this.inputs.Visible = false;
        this.colothersh.Visible = false;
        this.colothers.Visible = false;
        this.fsOthers.Visible = false;
        this.fsotherstxtbx.Visible = false;

    }
    protected void btncancelemi_Click(object sender, EventArgs e)
    {
        div_position.Value = "0";
        ClearEMIReminder();
        Bind_LoanDets();
        ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "method", "ScrollPosition();", true);
        //Response.Redirect("Branch_EMI_Reminder.aspx");
    }
    protected void btnsubmitemi_Click(object sender, EventArgs e)
    {
        if (ddlstmode.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select the mode of reminder", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }

        else if (ddlstcallstatus.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select the call status", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {
            if (ddlstcallstatus.SelectedItem.Text == "Call Attended")
            {

                if (ddlstfieldstaff.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please select the field staff", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (ddlstlnameofperson.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please select the name of person contacted", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                else if (ddlstfund.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please select the fund available", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                //else if (txtbxptpdate.Text == "" && ddlstfund.SelectedItem.Text != "No")
                //{
                //    uscMsgBox1.AddMessage("Please select the PTP date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                //}
                else if (ddlstlnameofperson.SelectedItem.Text == "Others" && txtbxothers.Text == "")
                {
                    uscMsgBox1.AddMessage("Please enter the others for name of the Person", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (ddlstfieldstaff.SelectedItem.Text == "Others" && txtbxfsothers.Text == "")
                {
                    uscMsgBox1.AddMessage("Please enter the others for Field Staff", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }

                else
                {


                    System.DateTime dtToday;
                    System.DateTime dtgn;
                    DateTime dtdue;

                    try
                    {
                        dtToday = Convert.ToDateTime(hdnfldservdate.Value);
                        //dtgn = Convert.ToDateTime(txtbxptpdate.Text);

                        if (txtbxptpdate.Text == "")
                            dtgn = Convert.ToDateTime(hdnfldservdate.Value);
                        else
                            dtgn = Convert.ToDateTime(txtbxptpdate.Text);

                        TimeSpan diff = dtgn.Subtract(dtToday);

                        if (diff.Days >= 0)
                        {
                            dtdue = Convert.ToDateTime(Session["EMIDUE"].ToString());

                            TimeSpan j = dtdue.Subtract(dtgn);

                            if (j.Days >= 0)
                            {

                                try
                                {
                                    con = new SqlConnection(strcon);

                                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                                        con.Open();

                                    cmd = new SqlCommand("RTS_SP_EMI_INSERT", con);

                                    cmd.CommandType = CommandType.StoredProcedure;
                                    cmd.CommandTimeout = 120000;
                                    cmd.Parameters.AddWithValue("@LP_CALL_TYPE", "R");
                                    cmd.Parameters.AddWithValue("@LP_LOAN_NO", Session["EMILNNO"].ToString());
                                    cmd.Parameters.AddWithValue("@LP_CST_ID", Convert.ToInt32(ddlstcallstatus.SelectedValue.ToString()));

                                    //cmd.Parameters.AddWithValue("@LP_EMP_ID", Convert.ToInt32(ddlstfieldstaff.SelectedValue.ToString()));

                                    if (ddlstfieldstaff.SelectedItem.Text == "Others")
                                        cmd.Parameters.AddWithValue("@LP_EMP_ID", txtbxfsothers.Text);
                                    else
                                        cmd.Parameters.AddWithValue("@LP_EMP_ID", ddlstfieldstaff.SelectedItem.Text);

                                    cmd.Parameters.AddWithValue("@LP_PERSON", ddlstlnameofperson.SelectedItem.Text);
                                    cmd.Parameters.AddWithValue("@LP_OTHERS", ddlstlnameofperson.SelectedItem.Text == "Others" ? txtbxothers.Text : "");
                                    cmd.Parameters.AddWithValue("@LP_MODE", ddlstmode.SelectedItem.Text);
                                    cmd.Parameters.AddWithValue("@LP_FUND", ddlstfund.SelectedValue.ToString());


                                    if (txtbxptpdate.Text == "")
                                        cmd.Parameters.AddWithValue("@LP_PTP_DATE", DBNull.Value);
                                    else
                                        cmd.Parameters.AddWithValue("@LP_PTP_DATE", txtbxptpdate.Text);

                                    cmd.Parameters.AddWithValue("@LP_REMARKS", txtbxrmks.Text);
                                    cmd.Parameters.AddWithValue("@LP_CBY", Convert.ToInt32(Session["ID"].ToString()));
                                    int rs = cmd.ExecuteNonQuery();
                                    if (rs > 0)
                                    {
                                        ClearEMIReminder();
                                        Bind_LoanDets();
                                        uscMsgBox1.AddMessage("EMI Reminder done successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                                    }
                                    else
                                    {
                                        uscMsgBox1.AddMessage("EMI Reminder not done....", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                                    }

                                }
                                catch (Exception ex)
                                {
                                    ErrorLog.WriteError(ex);
                                    uscMsgBox1.AddMessage("EMI Reminder not done....", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                                }
                                finally
                                {
                                    cmd.Dispose();
                                    // dapemi.Dispose();
                                    con.Close();
                                }
                            }
                            else
                            {
                                uscMsgBox1.AddMessage("The PTP date should be on or before the due date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                            }
                        }
                        else { uscMsgBox1.AddMessage("Please check the PTP date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention); }

                    }
                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                        uscMsgBox1.AddMessage("Please check the PTP date", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                    }


                }
            }
            else
            {
                //other then call attended cases


                if (ddlstfieldstaff.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please select the field staff", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (ddlstlnameofperson.SelectedItem.Text == "--Select--")
                {
                    uscMsgBox1.AddMessage("Please select the name of person contacted", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (ddlstlnameofperson.SelectedItem.Text == "Others" && txtbxothers.Text == "")
                {
                    uscMsgBox1.AddMessage("Please enter the others for name of the Person", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }
                else if (ddlstfieldstaff.SelectedItem.Text == "Others" && txtbxfsothers.Text == "")
                {
                    uscMsgBox1.AddMessage("Please enter the others for Field Staff", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
                }


                else
                {


                    try
                    {

                        con = new SqlConnection(strcon);

                        if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                            con.Open();

                        cmd = new SqlCommand("RTS_SP_EMI_INSERT", con);

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 120000;
                        cmd.Parameters.AddWithValue("@LP_CALL_TYPE", "R");
                        cmd.Parameters.AddWithValue("@LP_LOAN_NO", Session["EMILNNO"].ToString());
                        cmd.Parameters.AddWithValue("@LP_CST_ID", Convert.ToInt32(ddlstcallstatus.SelectedValue.ToString()));

                        if (ddlstfieldstaff.SelectedItem.Text == "Others")
                            cmd.Parameters.AddWithValue("@LP_EMP_ID", txtbxfsothers.Text);
                        else
                            cmd.Parameters.AddWithValue("@LP_EMP_ID", ddlstfieldstaff.SelectedItem.Text);

                        cmd.Parameters.AddWithValue("@LP_PERSON", ddlstlnameofperson.SelectedItem.Text);
                        cmd.Parameters.AddWithValue("@LP_OTHERS", ddlstlnameofperson.SelectedItem.Text == "Others" ? txtbxothers.Text : "");
                        cmd.Parameters.AddWithValue("@LP_MODE", ddlstmode.SelectedItem.Text);
                        cmd.Parameters.AddWithValue("@LP_FUND", DBNull.Value);
                        cmd.Parameters.AddWithValue("@LP_PTP_DATE", DBNull.Value);
                        if (txtbxrmks.Text != "")
                            cmd.Parameters.AddWithValue("@LP_REMARKS", txtbxrmks.Text);
                        else
                            cmd.Parameters.AddWithValue("@LP_REMARKS", DBNull.Value);

                        cmd.Parameters.AddWithValue("@LP_CBY", Convert.ToInt32(Session["ID"].ToString()));

                        int rs = cmd.ExecuteNonQuery();
                        if (rs > 0)
                        {
                            ClearEMIReminder();
                            Bind_LoanDets();
                            uscMsgBox1.AddMessage("EMI Reminder done successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                        }
                        else
                        {
                            uscMsgBox1.AddMessage("EMI Reminder not done successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        }

                    }
                    catch (Exception ex)
                    {
                        ErrorLog.WriteError(ex);
                        uscMsgBox1.AddMessage("EMI Reminder not done...", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                    }
                    finally
                    {
                        cmd.Dispose();
                        // dapemi.Dispose();
                        con.Close();
                    }
                }

            }
        }
    }

    protected void Bind_FieldStaff()
    {
        try
        {

            ddlstfieldstaff.Items.Clear();
            con = new SqlConnection(strcon);

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("RTS_SP_BIND_FIELD_STAFF", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@BRANCH", txtbxemibranch.Text);
            dapemi = new SqlDataAdapter(cmd);
            dtbl = new DataTable();
            dapemi.Fill(dtbl);


            ddlstfieldstaff.DataSource = dtbl;
            ddlstfieldstaff.DataTextField = "EMP_NAME";
            ddlstfieldstaff.DataValueField = "EMP_ID";
            ddlstfieldstaff.DataBind();
            ddlstfieldstaff.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            // dapemi.Dispose();
            con.Close();


        }


    }

    protected void Bind_PYMNT_BNCE()
    {
        try
        {


            con = new SqlConnection(strcon);

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("RTS_SP_BIND_EMI_PYMNT_BNCE", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LNNO", Session["EMILNNO"].ToString());
            dapemi = new SqlDataAdapter(cmd);
            dsemi = new DataSet();
            dapemi.Fill(dsemi);

            gvpaymentdets.DataSource = dsemi.Tables[0];
            gvpaymentdets.DataBind();

            gvbounce.DataSource = dsemi.Tables[1];
            gvbounce.DataBind();

            txtbxmobno.Text = dsemi.Tables[2].Rows[0]["MOBILE_NO"] != DBNull.Value ? dsemi.Tables[2].Rows[0]["MOBILE_NO"].ToString() : "";
            txtbxcusaddr.Text = dsemi.Tables[2].Rows[0]["ADDRESS"] != DBNull.Value ? dsemi.Tables[2].Rows[0]["ADDRESS"].ToString() : "";
            txtbxduedate.Text = dsemi.Tables[2].Rows[0]["DUE_DT"] != DBNull.Value ? dsemi.Tables[2].Rows[0]["DUE_DT"].ToString() : "";
            txtbxinstalmntno.Text = dsemi.Tables[2].Rows[0]["INSTLMT_NO"] != DBNull.Value ? dsemi.Tables[2].Rows[0]["INSTLMT_NO"].ToString() : "";
            txtbxinstalmntamt.Text = dsemi.Tables[2].Rows[0]["INSTLMT_AMT"] != DBNull.Value ? dsemi.Tables[2].Rows[0]["INSTLMT_AMT"].ToString() : "";
            txtbxoverdueamt.Text = dsemi.Tables[2].Rows[0]["OD_AMOUNT"] != DBNull.Value ? dsemi.Tables[2].Rows[0]["OD_AMOUNT"].ToString() : "";



            gvcalldets.DataSource = dsemi.Tables[3];
            gvcalldets.DataBind();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            // dapemi.Dispose();
            con.Close();


        }

    }

    protected void Bind_Call_Status()
    {

        try
        {

            ddlstcallstatus.Items.Clear();
            con = new SqlConnection(strcon);

            if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                con.Open();

            cmd = new SqlCommand("RTS_SP_BIND_EMI_CALLSTATUS", con);
            cmd.CommandType = CommandType.StoredProcedure;

            dapemi = new SqlDataAdapter(cmd);
            dtbl = new DataTable();
            dapemi.Fill(dtbl);


            ddlstcallstatus.DataSource = dtbl;
            ddlstcallstatus.DataTextField = "CST_DESC";
            ddlstcallstatus.DataValueField = "CST_ID";
            ddlstcallstatus.DataBind();
            ddlstcallstatus.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            cmd.Dispose();
            // dapemi.Dispose();
            con.Close();


        }
    }
    protected void ddlstcallstatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlstcallstatus.SelectedItem.Text != "Call Attended")
        {

            // ddlstfieldstaff.Enabled = false;
            //ddlstlnameofperson.Enabled = false;
            // ddlstmode.Enabled = false;
            ddlstfund.Enabled = false;
            txtbxptpdate.Enabled = false;
            //txtbxrmks.Enabled = false;


        }
        else
        {
            // ddlstfieldstaff.Enabled = true;
            // ddlstlnameofperson.Enabled = true;
            //  ddlstmode.Enabled = true;
            ddlstfund.Enabled = true;
            txtbxptpdate.Enabled = true;
            // txtbxrmks.Enabled = true;

        }
        ddlstcallstatus.Focus();
        btnsubmitemi.Enabled = true;
    }
    protected void ddlstfund_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlstfund.SelectedItem.Text == "Yes")
        {
            txtbxptpdate.Enabled = false;
            ddlstfund.Focus();
        }
        else
        {
            txtbxptpdate.Enabled = true;
            ddlstfund.Focus();
        }
    }
    protected void ddlstfieldstaff_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlstfieldstaff.SelectedItem.Text == "Others")
        {
            this.fsOthers.Visible = true;
            this.fsotherstxtbx.Visible = true;
        }
        else
        {
            this.fsOthers.Visible = false;
            this.fsotherstxtbx.Visible = false;
        }
        ddlstfieldstaff.Focus();
    }
}