﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;
using System.Net.Mail;
using Utilities;

public partial class HoOps_Send_Disb_Release : System.Web.UI.Page
{
    int ldid, s;
    int ftid;
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string to;
    string cc;
    string bcc;
    string bcc1;
    string bcc2;
    string bcc3;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    ClsCommon clscommon = new ClsCommon();
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    public static DataTable dtQuery = null;
    public static string fromID = "", toID = "", bcc2ID = "", ccID = "", strMailBody = "";
    public static bool blMailStatus = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["ID"] != null)
            {
                txtDate.Text = String.Format("{0:dd MMM yyyy}", dt);
                bind();
            }
            else
            {
                Response.Redirect("expire.aspx", false);
            }
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        // ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    //public void bind()
    //{
    //    SqlConnection con = new SqlConnection(strcon);
    //    con.Open();
    //    SqlCommand cmddd = new SqlCommand("select AR_NAME from MR_AREA", con);
    //    SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
    //    DataSet dsdd = new DataSet();
    //    dadd.Fill(dsdd);

    //    con.Close();
    //    ddlArea.DataSource = dsdd;
    //    ddlArea.DataTextField = "AR_NAME";
    //    ddlArea.DataValueField = "AR_NAME";
    //    ddlArea.DataBind();
    //    ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));

    //}
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            s = 0;
            foreach (GridViewRow grow in gvRcvfile.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    s += 1;
                    /* SqlCommand cmdbr = new SqlCommand("select LD_ID from LSD_LEAD where LD_NO='" + gvRcvfile.Rows[index].Cells[1].Text + "'", con);
                     SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
                     DataSet dsbr = new DataSet();
                     dabr.Fill(dsbr);
                     ldid = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
                     */
                    Label lblBR_Id = grow.FindControl("lblBR_Id") as Label;
                   
                    ldid = Convert.ToInt32(lblBR_Id.Text);
                    SqlCommand cmdupdate = new SqlCommand("RTS_SP_DISB_MR_BRANCH", con);
                    cmdupdate.CommandType = CommandType.StoredProcedure;
                    cmdupdate.Parameters.AddWithValue("@BR_ID", ldid);
                    cmdupdate.Parameters.AddWithValue("@PTYPE", "DISB_RLSE_UPT");
                    cmdupdate.Parameters.AddWithValue("@ID", Session["ID"].ToString());    
                    cmdupdate.ExecuteNonQuery();

                    //sendMail(con, lblLeadNo.Text);
                }
            }


            gridbind();
            lbLeadno.Text = "";
            lbAppname.Text = "";
            lbPDdate.Text = "";
            lbLoanamt.Text = "";
            ddlArea.Enabled = true;
            ddlBranch.Enabled = true;
            txtLeadno.Enabled = true;
            btnSubmit.Enabled = false;

            string strMailStatus = "";
            string strSuccessMsg = "";
            if (blMailStatus == true)
            {
                strMailStatus = "Successfully";
            }
            else
            {
                strMailStatus = "Failed";
            }
           

            strSuccessMsg = "Mail Sent " + strMailStatus + "  ";
           

            uscMsgBox1.AddMessage(s + " Blocked branches released successfully.", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }


    }
    public void sendMail(SqlConnection con, string ld_id)
    {
        try
        {
            /////// mail ///////////
            //  strMailDetail = "";

            /* SqlCommand cmddet = new SqlCommand("select ST_NAME,AR_NAME,LD_BR_ID,BR_NAME,LD_NO,PR_NAME,LD_APNAME,LD_PD_AMT,isnull(LD_CRAP_MBY,'') 'CREDITAPPRV' from LSD_LEAD A JOIN MR_BRANCH B ON A.LD_BR_ID=B.BR_ID JOIN MR_AREA C ON C.AR_ID=B.BR_AR_ID JOIN MR_STATE D ON D.ST_ID=C.AR_ST_ID JOIN MR_PRODUCT E ON A.LD_PR_ID=E.PR_ID WHERE LD_NO='" + ld_id +"'" , con);
             SqlDataAdapter dadet = new SqlDataAdapter(cmddet);
             DataSet dsdet = new DataSet();
             dadet.Fill(dsdet);

             /// to whom//////
             int nBranch_ID = dsdet.Tables[0].Rows[0]["LD_BR_ID"] != DBNull.Value ? Convert.ToInt32(dsdet.Tables[0].Rows[0]["LD_BR_ID"]) : 0;
             SqlCommand cmdmailto = new SqlCommand("SELECT EM_BM,EM_AM,EM_CM,EM_HO,EM_BCC,EM_CLM FROM MR_EMAIL where EM_BR_ID='" + nBranch_ID.ToString() + "'", con);
             SqlDataAdapter damailto = new SqlDataAdapter(cmdmailto);
             DataSet dsmailto = new DataSet();
             damailto.Fill(dsmailto);*/
            DataSet dsmailto = new DataSet();
            dsmailto = clscommon.Bind_FETCH_MR_EMAIL(ld_id);
            if (dsmailto.Tables[0].Rows.Count != 0)
            {
                to = dsmailto.Tables[0].Rows[0]["EM_BM"].ToString();
                cc = dsmailto.Tables[0].Rows[0]["EM_AM"].ToString() + ";" + dsmailto.Tables[0].Rows[0]["EM_CM"].ToString() + ";" + dsmailto.Tables[0].Rows[0]["EM_HO"].ToString();
                cc = cc.Replace("\n", "");
                bcc = "";// dsmailto.Tables[0].Rows[0]["EM_CM"].ToString();
                bcc1 = dsmailto.Tables[0].Rows[0]["EM_BCC"].ToString();
                bcc3 = dsmailto.Tables[0].Rows[0]["EM_CLM"] != DBNull.Value ? dsmailto.Tables[0].Rows[0]["EM_CLM"].ToString() : "";
            }

            //if (cc != "")
            //{
            //    cc = cc + ";retail-helpdesk@equitasbank.com;valanK@equitasbank.com;BalachandiranS@equitasbank.com;manikandane@equitasbank.com;shankarpl@equitasbank.com";
            //}
            //else
            //{
            //    cc = "retail-helpdesk@equitasbank.com;valanK@equitasbank.com;BalachandiranS@equitasbank.com;manikandane@equitasbank.com";
            //}
            if (bcc3 != "")
            {
                cc = cc.Replace(";;", ";") + ";" + bcc3;
            }

            if (bcc != "" && bcc1 != "")
            {
                bcc2 = bcc + ";" + bcc1;
            }
            else if (bcc != "")
            {
                bcc2 = bcc;
            }
            else if (bcc1 != "")
            {
                bcc2 = bcc1;
            }
            else
            {
                bcc2 = "";
            }


            // to = "ManimaranK@equitasbank.com";
            // bcc2 = "ManimaranK@equitasbank.com";
            // cc = "PalanikumarA@equitasbank.com";
            fromID = "RTS Alerts";
            toID = to;
            //  to = "ManimaranK@equitasbank.com";
            bcc2ID = bcc2;
            ccID = cc;

            // To Auto mail ///////
            System.Threading.Thread threadSendMails;

            //threadSendMails = new System.Threading.Thread(delegate()
            //{

            String BodyTxt = "<html><body><basefont face='Calibri'> Dear All,<br/><br/>The captioned file is “Ready to cheque release”. ";
            //BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td width='25%'>Lead No.</td><td><strong>" + Session["Leadno"].ToString() + "</strong></td>";
            //BodyTxt = BodyTxt + "<td>Applicant Name</td><td><strong>" + dsdet.Tables[0].Rows[0]["LD_APNAME"].ToString() + "</strong></td></tr>";
            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Product</td><td><strong>" + dsdet.Tables[0].Rows[0]["PR_NAME"].ToString() + "</strong></td>";
            //BodyTxt = BodyTxt + "<td>Loan Amount</td><td><strong>" + Session["Loanamt"] + "</strong></td></tr></table><br/><br/>";
            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Address </td><td align='center'>:</td><td><strong>" + cusaddr + "</strong></td></tr>";
            //BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><td>Mobile No.</td><td align='center'>:</td><td><strong>" + mobile + "</strong></td></tr></table><br/><br/>";
            /*  int b = dtQuery.Rows.Count;
              if (b != 0)
              {
                  BodyTxt = BodyTxt + " subject to following conditions (if any). <br/>";
                  BodyTxt = BodyTxt + " Condition <br/>";
                  BodyTxt = BodyTxt + "<table width='70%' border='1' cellpadding='4' cellspacing='1' bgcolor='#' style='font-family: Verdana, Arial, Tahoma; font-size:12px'>";
                  BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td align='center'  width='10%'>Sl. No.</td>";
                  //BodyTxt = BodyTxt + "<td  align='center'>Credit Query Details</td>";
                  //BodyTxt = BodyTxt + "<td  align='center'>Query Date</td>";
                  //BodyTxt = BodyTxt + "<td  align='center'>Response</td>";
                  //BodyTxt = BodyTxt + "<td  align='center'>Response Date</td>";

                  BodyTxt = BodyTxt + "<td  bgcolor='#FFFFFF' align='center' width='40%'>DISBURSEMENT CONDITION</td>";

                  for (int j = 0; j <= b - 1; j++)
                  {
                      int sno = j + 1;
                      BodyTxt = BodyTxt + "<tr bgcolor='#FFFFFF'><span ><td bgcolor='#FFFFFF' align='right'> " + sno + "</td>";
                      //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Query Raised"].ToString() + "</td>";
                      //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Date"].ToString() + "</td>";
                      //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response"].ToString() + "</td>";
                      //BodyTxt = BodyTxt + "<td> " + dsmail.Tables[0].Rows[j]["Response Date"].ToString() + "</td>";

                      BodyTxt = BodyTxt + "<td bgcolor='#FFFFFF'> " + dtQuery.Rows[j]["Condition"].ToString() + "</td></span></tr>";
                  }
                  BodyTxt = BodyTxt + "</table>";
              }*/

            BodyTxt = BodyTxt + "<tr><td align='left' colspan='2'><br/><br/>Thanks and Regards,<br/>Retail Ops - QC Team</td></tr>";
            BodyTxt = BodyTxt + "<tr><td align='left' colspan='5'><span style='color: #ff0000;font-style:italic'><br/><br/><strong> ** This is system generated mail. Please do not reply for this mail.</strong></span></td></tr></table></tr></table></html>";
            //sendemail("SurendharR@equitasbank.com", "VF-Telecalling<vf-telecalling@equitasbank.com>", "Escalation Mail For'" + loan + "'-'" + cusname + "'", BodyTxt, "", true);

            blMailStatus = EmailManager.sendemail(to, "RTS Alerts", bcc2, cc, "Ready To Cheque Release - " + ld_id.ToString() + " -  " + dsmailto.Tables[0].Rows[0]["LD_APNAME"].ToString() + " -  " + dsmailto.Tables[0].Rows[0]["AR_NAME"].ToString() + " -  " + dsmailto.Tables[0].Rows[0]["BR_NAME"].ToString() + "", BodyTxt, "", true);
            //sendemail("SurendharR@equitasbank.com;PrabhakaranA@equitasbank.com;Tamilalagand@equitasbank.com", "surendharr@equitasbank.com", "Test", BodyTxt, "", true);

            //strMailBody = BodyTxt.Replace("<html><body><basefont face='Calibri'> Dear All,<br/><br/> Please find the details of Credit " + ddlApprv.SelectedItem.ToString() + "<br/><br/>", "");
            //strMailBody = BodyTxt.Replace("</html>", " ");


            //});
            //// strMailDetail = to + "," + bcc2 + "," + cc;
            //threadSendMails.IsBackground = true;

            //threadSendMails.Start();
            //System.Threading.Thread.Sleep(5000);

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage(ex.ToString(), YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("HDesk_PRDD_Handover.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        
        gridbind();
    }
   
    public void gridbind()
    {

        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("RTS_SP_DISB_MR_BRANCH", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@AR_ID", ddlArea.SelectedIndex > 0 ? ddlArea.SelectedValue : "");
            cmd.Parameters.AddWithValue("@BR_ID", ddlBranch.SelectedIndex > 0 ? ddlBranch.SelectedValue : "");
            cmd.Parameters.AddWithValue("@PTYPE", "DISB_RLSE");
            cmd.Parameters.AddWithValue("@BR_SDISB_STAT", "1");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gvRcvfile.DataSource = ds.Tables[0];
            gvRcvfile.DataBind();

        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
            // uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;
           /* SqlConnection con = new SqlConnection(strcon);
            con.Open();
            foreach (GridViewRow grow in gvRcvfile.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                Label lblLeadId = grow.FindControl("lblLeadId") as Label;
                int index = grow.RowIndex;
                if (chkStat.Checked == true)
                {
                    leadno = gvRcvfile.Rows[index].Cells[1].Text;
                    ldid = Convert.ToInt32(lblLeadId.Text);

                    SqlCommand cmdqry = new SqlCommand("RTS_SP_DISB_FETCH_LSD_QUERY", con);
                    cmdqry.CommandType = CommandType.StoredProcedure;
                    cmdqry.Parameters.AddWithValue("@QRY_LD_ID", ldid);
                    cmdqry.Parameters.AddWithValue("@QRY_RSD_BY", "D");
                    SqlDataAdapter daqry = new SqlDataAdapter(cmdqry);
                    DataSet dsqry = new DataSet();
                    daqry.Fill(dsqry);
                    if (dsqry.Tables[0].Rows.Count > 0)
                    {
                        uscMsgBox1.AddMessage(leadno + " Query response pending in the branch side", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
                        // return false;

                        chkStat.Checked = false;
                    }

                }
            }
           
          


           
            con.Close();*/
            
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        //txtLeadno.Enabled = false;
        txtLeadno.Text = "";
    }

}