﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Globalization;
using Tracker;

public partial class Branch_Recieve_Doc : System.Web.UI.Page
{
    string leadno;
    string appname;
    string pddt;
    string lnamt;
    string lProduct = "";
    string lQuery = "";
    string rcvquery;
    int prid;
    string query;
    int ldid;
    int qryid;
    int qryldid;
    int selectedcnt;
    string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    DateTime dt = DateTime.Now;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UNITNAME"] != null)
            {
                txtdate.Text = String.Format("{0:dd MMM yyyy}", dt);
                //ddlArea.Items.Add(Session["AREANAME"].ToString());
                txtBranch.Text = Session["UNITNAME"].ToString();
                bindArea();
                bind();
            }
            else
            {
                Response.Redirect("default.aspx");
            }
        }
    }
    public void bind()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con);
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);
        con.Close();
        ddlProduct.DataSource = dsdd;
        ddlProduct.DataTextField = "PR_CODE";
        ddlProduct.DataValueField = "PRD";
        ddlProduct.DataBind();
        ddlProduct.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    public void bindArea()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmddd = new SqlCommand("RTS_SP_FETCH_MR_AREA_By_ACS", con);
        cmddd.CommandType = CommandType.StoredProcedure;
        cmddd.Parameters.AddWithValue("@Type", Session["USR_ACS"] != null ? Session["USR_ACS"].ToString() : "");

        if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "3")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["STATEID"] != null ? Convert.ToInt32(Session["STATEID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "4")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["DIVID"] != null ? Convert.ToInt32(Session["DIVID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "5")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["AREA_ID"] != null ? Convert.ToInt32(Session["AREA_ID"]) : 0);
        }
        else if (Session["USR_ACS"] != null && Session["USR_ACS"].ToString() == "7")
        {
            cmddd.Parameters.AddWithValue("@InputVal", Session["BRANCHID"] != null ? Convert.ToInt32(Session["BRANCHID"]) : 0);
        }
        else
        {
            cmddd.Parameters.AddWithValue("@InputVal", 0);
        }
        SqlDataAdapter dadd = new SqlDataAdapter(cmddd);
        DataSet dsdd = new DataSet();
        dadd.Fill(dsdd);



        con.Close();
        ddlArea.DataSource = dsdd;
        ddlArea.DataTextField = "AR_NAME";
        ddlArea.DataValueField = "AR_ID";
        ddlArea.DataBind();
        ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlArea.SelectedValue = Session["AREA_ID"].ToString();

        bindBranch();

    }
    public void bindBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_ID,BR_NAME from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        if (Session["USR_ACS"].ToString() == "7")
        {
            ddlBranch.SelectedValue = Session["BRANCHID"].ToString();
            ddlBranch.Enabled = false;
            ddlArea.Enabled = false;
        }
    }
    protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlCommand cmdrsn = new SqlCommand("select BR_NAME, BR_ID from MR_BRANCH A JOIN MR_AREA B ON A.BR_AR_ID=B.AR_ID WHERE AR_NAME='" + ddlArea.SelectedItem.Text.ToString() + "'", con);
        SqlDataAdapter darsn = new SqlDataAdapter(cmdrsn);
        DataSet dsrsn = new DataSet();
        darsn.Fill(dsrsn);
        con.Close();

        ddlBranch.DataSource = dsrsn;
        ddlBranch.DataTextField = "BR_NAME";
        ddlBranch.DataValueField = "BR_ID";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlBranch.Enabled = true;
        ddlProduct.SelectedIndex = 0;

    }

    protected void ddlbranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlProduct.SelectedIndex = 0;
    }
    protected void rb_select_CheckedChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        //if (ddlQuery.SelectedValue.ToString() == "QC")
        //{    
        int ncount = 0;
        foreach (GridViewRow grow in gvResolve.Rows)
        {
            RadioButton chkStat = grow.FindControl("rb_select") as RadioButton;
            LinkButton lnbtn = grow.FindControl("lnkname") as LinkButton;
            //DropDownList ddrsp = grow.FindControl("Editdd") as DropDownList;
            int index = grow.RowIndex;
            if (chkStat.Checked)
            {
                leadno = lnbtn.Text;
                appname = gvResolve.Rows[index].Cells[3].Text;
                pddt = gvResolve.Rows[index].Cells[4].Text;
                lnamt = gvResolve.Rows[index].Cells[5].Text;
                //lQuery = gvResolve.Rows[index].Cells[7].Text;
                ncount = ncount + 1;
                //rcvquery = gvResolve.Rows[index].Cells[6].Text;
                Session["Leadno"] = leadno;
                getLeadID(con);
                BindDocGid(con);
            }

            if (ncount == 0)
            {
                Panel2.Visible = false;
            }
        }


        btnSubmit.Enabled = true;
        btnCancel.Enabled = true;

        con.Close();
    }

    public void BindDocGid(SqlConnection con)
    {
        SqlCommand cmd = new SqlCommand("Select MDX_DOC,MDX_DTYPE from LSD_MOTD_DOCX LMD LEFT JOIN  LSD_MOTD  LM ON LMD.MDX_MD_ID =LM.MD_ID  where MD_LD_ID =" + Session["LeadId"].ToString() + "", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0 && ds.Tables[0] != null)
        {
            Panel2.Visible = true;
            gvMODTDDoc.Visible = true;
            gvMODTDDoc.DataSource = ds;
            gvMODTDDoc.DataBind();
        }
        else
        {
            Panel2.Visible = false;
        }


    }
    public void getLeadID(SqlConnection con)
    {
        SqlCommand cmdbr = new SqlCommand("RTS_SP_FetchLeadDetails", con);
        cmdbr.CommandType = CommandType.StoredProcedure;
        cmdbr.Parameters.AddWithValue("@LeadNo", Session["Leadno"].ToString());
        SqlDataAdapter dabr = new SqlDataAdapter(cmdbr);
        DataSet dsbr = new DataSet();
        dabr.Fill(dsbr);
        Session["LeadId"] = Convert.ToInt32(dsbr.Tables[0].Rows[0]["LD_ID"]);
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertBranchResolveQueriesVal();

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Branch_Recieve_Doc.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        if (ddlProduct.SelectedItem.Text == "--Select--")
        {
            uscMsgBox1.AddMessage("Please select the product", YaBu.MessageBox.uscMsgBox.enmMessageType.Attention);
        }
        else
        {

            BindDocRecByBranch();
            gvMODTDDoc.Visible = false;
            gvResolve.Visible = true;
        }
    }
    public void BindDocRecByBranch()
    {
        SqlConnection con = new SqlConnection(strcon);
        try
        {
            con.Open();
            //SqlCommand cmdprid = new SqlCommand("select PR_ID from MR_PRODUCT WHERE PR_CODE='" + ddlProduct.SelectedValue.ToString() + "'", con);
            //SqlDataAdapter daprid = new SqlDataAdapter(cmdprid);
            //DataSet dsprid = new DataSet();
            //daprid.Fill(dsprid);
            //  prid = Convert.ToInt32(ddlProduct.SelectedValue);

            string[] PRARR = ddlProduct.SelectedIndex > 0 ? ddlProduct.SelectedValue.ToString().Split('-') : null;
            prid = Convert.ToInt32(PRARR[0].ToString());
            query = "";


            //   SqlCommand cmd = new SqlCommand("RTS_SP_Bind_Branch_ReceiveDoc", con);

            SqlCommand cmd = new SqlCommand("RTS_SP_Bind_ReceiveDoc", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PR_ID", prid);
            //Bala changes 24/02/2016
            //cmd.Parameters.AddWithValue("@LD_BR_ID", Session["BRANCHID"] != null ? Session["BRANCHID"].ToString() : "0");
            cmd.Parameters.AddWithValue("@LD_BR_ID", ddlBranch.SelectedValue);
            cmd.Parameters.AddWithValue("@ReceiveType", "BR");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //Panel1.Visible = true;
            gvResolve.DataSource = ds.Tables[0];
            gvResolve.DataBind();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvResolve.HeaderRow.Font.Bold = true;
                gvResolve.HeaderRow.Cells[1].Text = "LEAD NO";
                gvResolve.HeaderRow.Cells[2].Text = "LEAD DATE";
                gvResolve.HeaderRow.Cells[3].Text = "APPLICANT NAME";
                gvResolve.HeaderRow.Cells[4].Text = "PD DATE";
                gvResolve.HeaderRow.Cells[5].Text = "LOAN AMOUNT";
                gvResolve.HeaderRow.Cells[6].Text = "PRODUCT";
                //gvResolve.HeaderRow.Cells[6].Text = "QUERY";

                gvResolve.HeaderRow.Cells[1].Wrap = false;
                gvResolve.HeaderRow.Cells[2].Wrap = false;
                gvResolve.HeaderRow.Cells[3].Wrap = false;
                gvResolve.HeaderRow.Cells[4].Wrap = false;
                gvResolve.HeaderRow.Cells[5].Wrap = false;
                gvResolve.HeaderRow.Cells[6].Wrap = false;
                //gvResolve.HeaderRow.Cells[6].Wrap = false;
            }
        }
        catch (Exception ex)
        {
            uscMsgBox1.AddMessage("Invalid Input", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }
    }
    protected void gvUserInfo_RowDataBound(object o, GridViewRowEventArgs e)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Assumes the Price column is at index 4
            if (e.Row.RowType == DataControlRowType.DataRow)
                //e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Left;
            e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Left;

            //e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Left;
        }
    }
    protected void Edit(object sender, EventArgs e)
    {
        LinkButton lnbtn = sender as LinkButton;
        string lndetails = lnbtn.Text;
        Session["Details"] = lndetails;
        string qryby = Session["QRYBY"].ToString();
        Session["sa2"] = qryby;
        ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.open('Branch_ResolveQueryPopup.aspx', '_blank', 'toolbar=no,location=no,statusbar=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600')", true);

    }
    public void InsertBranchResolveQueriesVal()
    {
        SqlConnection con = new SqlConnection(strcon);
        int ncount = 0;
        try
        {
            foreach (GridViewRow grow in gvMODTDDoc.Rows)
            {
                CheckBox chkStat = grow.FindControl("cb_select") as CheckBox;
                int index = grow.RowIndex;
                if (chkStat.Checked)
                {
                    ncount = ncount + 1;
                }
                else
                {
                    ncount = 0;
                }
            }
            if (ncount == 0)
            {
                uscMsgBox1.AddMessage("Document/s are missing, Can't be proceed", YaBu.MessageBox.uscMsgBox.enmMessageType.Error);
            }
            else
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("RTS_SP_Update_MODT_DOc_Values", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MD_LD_ID", Session["LeadId"].ToString());
                cmd.Parameters.AddWithValue("@ID", Session["ID"].ToString());
                cmd.Parameters.AddWithValue("@TranStatus", "BR");
                int n = cmd.ExecuteNonQuery();
                if (n > 0)
                {

                    uscMsgBox1.AddMessage("Documents Received Successfully", YaBu.MessageBox.uscMsgBox.enmMessageType.Success);
                    BindDocRecByBranch();
                    Panel2.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLog.WriteError(ex);
        }
        finally
        {
            con.Close();
        }

    }

    protected void ddlProduct_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}