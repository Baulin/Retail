﻿using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for GlobalClass
/// </summary>
public class GlobalClass
{

    public static SqlDataAdapter adap;
    public static SqlDataAdapter adap1;
    public static DataTable dt;
    public static DataTable dt1;
    // Stored image path before updating the record
    public static string imgEditPath;

    //Application Labels
    #region CAM
    public const string GuidelineValue = "Are we considering land value based on Government guideline value ? ";
    #endregion
    #region UPLOAD FORMAT REPORT
    public const string NEFT_Upload_Report_VF_File_Name = "NEFT_Upload_Format_Report_For_VF_From_{0}_to_{1}";
    public const string NEFT_Upload_Report_HF_File_Name = "NEFT_Upload_Format_Report_For_HF_From_{0}_to_{1}";

    public const string RTGS_Upload_Report_VF_File_Name = "RTGS_Upload_Format_Report_For_VF_From_{0}_to_{1}";
    public const string RTGS_Upload_Report_HF_FileName = "RTGS_Upload_Format_Report_For_HF_From_{0}_to_{1}";

    public const string IFT_Upload_Report_VF_File_Name = "IFT_Upload_Format_Report_For_VF_From_{0}_to_{1}";
    public const string IFT_Upload_Report_HF_File_Name = "IFT_Upload_Format_Report_For_HF_From_{0}_to_{1}";
    #endregion
}