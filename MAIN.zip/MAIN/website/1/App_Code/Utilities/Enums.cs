﻿using System.ComponentModel;

namespace Utilities.Enums
{
    public enum CRAprvStatus
    {
        Rejected = 0,
        Approved = 1,
        Pending = 3
    }

    public enum UserStatus
    {
        Active = 1,
        Inactive = 0
    }

    public enum UserType
    {
        User = 1,
        Developer = 2,
        Admin = 3
    }

    public enum CRStage
    {
        MovedToProduction = 8,
        UATToBeSignOff = 7,
        PatchToBeReceived = 6,
        DeliveryDateToBeReceived = 5,
        BRDApprovalPending = 4,
        BRDToBeReceived = 3,
        ToBeDiscussed = 2,
        Rejected = 1
    }

    public enum QRType
    {
        PR = 1,
        PO = 2,
        PT = 3,
        UT = 4
    }

    public enum CRAction
    {
        ForBRDUpload = 1,
        ForBRDApproval = 2,
        ForPatchUpdate = 3,
        ForPatchApproval = 4,
        ForUATDate = 5,
        ForUATSignOff = 6,
        ForLiveDate = 7,
        ForCRConfirmService = 8
    }

    public enum TechnicalInitiation
    {
        M = 1,
        NM = 2,
        AOM = 3,
        NA = 4
    }

    public enum UploadFormatReport
    {
        NEFT = 1,
        RTGS = 2,
        IFT = 3
    }

    public enum ProductType
    {
        TWL = 1,
        UL = 2,
        BL = 3,
        TF = 4,
        HF = 6
    }

    public enum ErrorMessageType
    {
        Success = 1,
        Info = 2,
        Error = 3,
        Warning = 4
    }

    public enum SortDirection
    {
        DESC = 0,
        ASC = 1,
        NOSORT = 2
    }

    public enum ErrorSeverity
    {
        Hint = 0,
        Warning = 1,
        Error = 2,
        Fatal = 3
    }

    public enum UnoLeadStatus
    {
        Available = 1,
        Locked = 2,
        Completed = 3,
        AutoClosed = 4
    }

    public enum FileType
    {
        [Description("application/pdf")]
        PDF = 1
    }

    public enum DbProvider
    {
        [Description("System.Data.SqlClient")]
        SqlClient,
        [Description("System.Data.OracleClient")]
        OracleClient,
        [Description("System.Data.OleDb")]
        OleDbClient,
        [Description("System.Data.Odbc")]
        OdbcClient
    }

    public enum DbConnections
    {
        [Description("DefaultConnection")]
        DEFAULT,
        [Description("connection")]
        UAT,
        [Description("connection")]
        PRE_PROD,
        [Description("connection")]
        PROD,
        [Description("connection")]
        REPORTS
    }

    public enum Product_Category
    {
        [Description("Declared Income")]
        Declared_Income = 1,
        [Description("Assessment")]
        Assessment = 2
    }

    public enum Assessed_Product_Name
    {
        [Description("IB-SME")]
        IB_SME = 4,
        [Description("IB-HF")]
        IB_HF = 5,
        [Description("IB-LAP")]
        IB_LAP = 6,
        [Description("IB-Agri and Allied Loans")]
        IB_Agri_And_Allied_Loans = 7,
        [Description("IB-Two wheeler Loans")]
        IB_Two_wheeler_Loans = 8,
        [Description("OD Product")]
        OD_Product = 12,
        [Description("Housing-IB")]
        Housing_IB = 14,
        [Description("CP Purchase")]
        CP_Purchase = 16,
        [Description("BB Housing")]
        BB_Housing = 17,
        [Description("BB LAP")]
        BB_LAP = 18
    }

    public enum Assessed_Product_Program
    {
        [Description("IB-M-LAP")]
        IB_M_LAP = 1,
        [Description("SME")]
        SME = 2,
        [Description("IB-MFHF")]
        IB_MFHF = 3,
        [Description("IB-G-HF")]
        IB_G_HF = 4,
        [Description("IB-G-LAP")]
        IB_G_LAP = 5,
        [Description("EMP-LAP")]
        EMP_LAP = 6,
        [Description("EMP-HF")]
        EMP_HF = 7,
        [Description("IB-TWL")]
        IB_TWL = 8,
        [Description("IB-SME-RETAIL")]
        IB_SME_RETAIL = 12,
        [Description("IB-ASL")]
        IB_ASL = 13,
        [Description("IB-ADFL")]
        IB_ADFL = 14,
        [Description("IB-LiveStock")]
        IB_LiveStock = 17,
        [Description("IB-SME-Secured-R")]
        IB_SME_Secured_R = 18,
        [Description("Medium Farmer-AL")]
        Medium_Farmer_AL = 25,
        [Description("Large Farmer-AL")]
        Large_Farmer_AL = 26,
        [Description("Very Large Farmer-AL")]
        Very_Large_Farmer_AL = 27,
        [Description("Small Marginal Farmer-AL")]
        Small_Marginal_Farmer_AL = 29,
        [Description("Pre Topup")]
        Pre_Topup = 33,
        [Description("Pre Topup-AL")]
        Pre_Topup_AL = 34,
        [Description("Pre Topup-SME Secured R")]
        Pre_Topup_SME_Secured_R = 35,
        [Description("OD Product-Assessment")]
        OD_Product_Assessment = 37,
        [Description("Housing-IB-MFHF")]
        Housing_IB_MFHF = 39,
        [Description("Housing-IB-G-HF")]
        Housing_IB_G_HF = 40,
        [Description("Housing-IB-EMP-HF")]
        Housing_IB_EMP_HF = 41,
        [Description("CP Purchase-Assessment")]
        CP_Purchase_Assessment = 43,
        [Description("BB Housing")]
        BB_Housing = 44,
        [Description("BB LAP")]
        BB_LAP = 45,
        [Description("Merchant OD")]
        Merchant_OD = 48,
        [Description("ATMA VISHWAS 2020-MLAP-Pre Topup")]
        ATMA_VISHWAS_2020_MLAP_Pre_Topup = 49,
        [Description("ATMA VISHWAS 2020-GLAP-Pre Topup")]
        ATMA_VISHWAS_2020_GLAP_Pre_Topup = 50,
        [Description("ATMA VISHWAS 2020-ASL-Pre Topup")]
        ATMA_VISHWAS_2020_ASL_Pre_Topup = 51,
        [Description("ATMA VISHWAS 2020-BL Assessed-Pre Topup")]
        ATMA_VISHWAS_2020_BL_Assessed_Pre_Topup = 52
    }

    public enum Assessed_Product_Scheme
    {
        [Description("Pre-Approval Topup")]
        IB_M_LAP_Pre_Approval_Topup = 35,
        [Description("50K-5L")]
        IB_M_LAP_50K_5L = 1,
        [Description("50K-5L")]
        IB_MFHF_50K_5L = 3,
        [Description("5.1L-30L")]
        IB_G_HF_5_1L_30L = 4,
        [Description("5L-10L")]
        IB_G_LAP_5L_10L = 2,
        [Description("25k-60k")]
        IB_TWL_25k_60k = 5,
        [Description("50K-2L")]
        IB_SME_RETAIL_50K_2L = 9,
        [Description("50K-5L")]
        IB_ASL_50K_5L = 10,
        [Description("50K-5L")]
        IB_ADFL_50K_5L = 11,
        [Description("40K-2L")]
        IB_LiveStock_40K_2L = 14,
        [Description("10L-30L")]
        IB_SME_Secured_R_10L_30L = 15,
        [Description("5.1L-10L")]
        Medium_Farmer_AL_5_1L_10L = 37,
        [Description("10.1L-20L")]
        Large_Farmer_AL_10_1L_20L = 38,
        [Description("20.1L-50L")]
        Very_Large_Farmer_AL_20_1L_50L = 39,
        [Description("50K-5L")]
        Small_Marginal_Farmer_AL_50K_5L = 41,
        [Description("Pre-Approval Topup")]
        Pre_Topup_Pre_Approval_Topup = 45,
        [Description("Pre-Approval Topup")]
        Pre_Topup_AL_Pre_Approval_Topup = 46,
        [Description("Pre-Approval Topup")]
        Pre_Topup_SME_Secured_R_Pre_Approval_Topup = 47,
        [Description("Upto 25L")]
        OD_Product_Assessment_Upto_25L = 49,
        [Description("50K-5L")]
        Housing_IB_MFHF_50K_5L = 60,
        [Description("5.1L-25L")]
        Housing_IB_G_HF_5_1L_25L = 61,
        [Description("Upto 25L")]
        CP_Purchase_Assessment_Upto_25L = 63,
        [Description("5.1L-30L")]
        BB_Housing_5_1L_30L = 64,
        [Description("BB LAP")]
        BB_LAP = 65,
        [Description("ATMA VISHWAS 2020-MLAP-Pre Topup")]
        ATMA_VISHWAS_2020_MLAP_Pre_Topup = 69,
        [Description("ATMA VISHWAS 2020-GLAP-Pre Topup")]
        ATMA_VISHWAS_2020_GLAP_Pre_Topup = 70,
        [Description("ATMA VISHWAS 2020-ASL-Pre Topup")]
        ATMA_VISHWAS_2020_ASL_Pre_Topup = 71,
        [Description("ATMA VISHWAS 2020-BL Assessed-Pre Topup")]
        ATMA_VISHWAS_2020_BL_Assessed_Pre_Topup = 72,
        [Description("BT")]
        IB_G_HF_BT = 75,
        [Description("Top up")]
        IB_G_HF_Top_up = 76,
        [Description("Home Purchase")]
        IB_G_HF_Home_Purchase = 77,
        [Description("Composite Loan – Land Purchase")]
        IB_G_HF_Composite_Loan_Land_Purchase = 78,
        [Description("Composite Loan – Construction")]
        IB_G_HF_Composite_Loan_Construction = 79,
        [Description("Composite Loan – Land & Construction")]
        IB_G_HF_Composite_Loan_Land_Construction = 80,
        [Description("Insurance Loan")]
        IB_G_HF_Insurance_Loan = 81
    }

    public enum Declared_Product_Name
    {
        [Description("IB-SME")]
        IB_SME = 1,
        [Description("IB-HF")]
        IB_HF = 2,
        [Description("Business Loan")]
        Business_Loan = 3,
        [Description("Salaried LAP")]
        Salaried_LAP = 9,
        [Description("TERM LOAN")]
        TERM_LOAN = 10,
        [Description("OD Product")]
        OD_Product = 11,
        [Description("Housing-IB")]
        Housing_IB = 13,
        [Description("CP Purchase")]
        CP_Purchase = 15
    }

    public enum Declared_Product_Program
    {
        [Description("BL-LAP")]
        BL_LAP = 9,
        [Description("BL-FIN")]
        BL_FIN = 10,
        [Description("BL-POS")]
        BL_POS = 11,
        [Description("BL-Doctor")]
        BL_Doctor = 15,
        [Description("BL-SEP")]
        BL_SEP = 16,
        [Description("IB-SME-Secured-D")]
        IB_SME_Secured_D = 19,
        [Description("IB-SME-UnSecured")]
        IB_SME_UnSecured = 20,
        [Description("IB-Affordable Home")]
        IB_Affordable_Home = 21,
        [Description("BL-ABB")]
        BL_ABB = 22,
        [Description("BL-LAR")]
        BL_LAR = 23,
        [Description("Salaried LAP")]
        Salaried_LAP = 24,
        [Description("BL-APR")]
        BL_APR = 28,
        [Description("Project Finance-Commercial")]
        Project_Finance_Commercial = 30,
        [Description("BL-SME Secured")]
        BL_SME_Secured = 31,
        [Description("IB-APR")]
        IB_APR = 32,
        [Description("OD Product-Declared")]
        OD_Product_Declared = 36,
        [Description("Housing-IB-AHF")]
        Housing_IB_AHF = 38,
        [Description("CP Purchase-Declared")]
        CP_Purchase_Declared = 42,
        [Description("Unsecured TL - Based on POS")]
        UnSecured_TL_Based_On_POS = 46,
        [Description("Unsecured OD - Based on POS")]
        UnSecured_OD_Based_On_POS = 47,
        [Description("ATMA VISHWAS 2020-Salaried LAP-Pre Topup")]
        ATMA_VISHWAS_2020_Salaried_LAP_Pre_Topup = 53,
        [Description("ATMA VISHWAS 2020-BL Declared-Pre Topup")]
        ATMA_VISHWAS_2020_BL_Declared_Pre_Topup = 54,
        [Description("IB-Mainstream LAP")]
        IB_Mainstream_LAP = 55,
    }

    public enum Declared_Product_Scheme
    {
        [Description("BL-LAP")]
        BL_LAP = 6,
        [Description("BL-FIN")]
        BL_FIN = 7,
        [Description("BL-POS")]
        BL_POS = 8,
        [Description("BL-Doctor")]
        BL_Doctor = 12,
        [Description("BL-SEP")]
        BL_SEP = 13,
        [Description("10L-50L")]
        _10L_50L = 16,
        [Description("10L-300L")]
        _10L_300L = 34,
        [Description("SEP")]
        SEP = 17,
        [Description("Doctors Program")]
        Doctors_Program = 18,
        [Description("POS")]
        POS = 19,
        [Description("SENP-Scheme-A")]
        SENP_Scheme_A = 20,
        [Description("SENP-Scheme-B")]
        SENP_Scheme_B = 21,
        [Description("Home Loan- Purchase")]
        IBAH_Home_Loan_Purchase = 22,
        [Description("Home Loan- Construction")]
        IBAH_Home_Loan_Construction = 23,
        [Description("Home Loan- Extension")]
        IBAH_Home_Loan_Extension = 24,
        [Description("Home Loan- Improvement")]
        IBAH_Home_Loan_Improvement = 25,
        [Description("Composite Loan(PLOT Purchase+Construction Loan)")]
        IBAH_Composite_Loan_PLOT_Purchase_Plus_Construction_Loan = 26,
        [Description("BT")]
        IBAH_BT = 27,
        [Description("Topup-1")]
        IBAH_Topup_1 = 28,
        [Description("Topup-2")]
        IBAH_Topup_2 = 29,
        [Description("Insurance Loan")]
        IBAH_Insurance_Loan = 32,
        [Description("LAP 10 to 300 Lacs")]
        IBAH_LAP_10_to_300_Lacs = 33,
        [Description("BL-ABB")]
        BL_ABB = 30,
        [Description("BL-LAR")]
        BL_LAR = 31,
        [Description("5.1L-50L")]
        _5_1L_50L = 36,
        [Description("BL-APR")]
        BL_APR = 40,
        [Description("TERM LOAN")]
        TERM_LOAN = 42,
        [Description("BL-SME Secured")]
        BL_SME_Secured = 43,
        [Description("IB-APR")]
        IB_APR = 44,
        [Description("Upto 200L")]
        Pre_Topup_SME_Secured_R_Upto_200L = 48,
        [Description("Home Loan- Purchase")]
        OD_Home_Loan_Purchase = 50,
        [Description("Home Loan- Construction")]
        OD_Home_Loan_Construction = 51,
        [Description("Home Loan- Extension")]
        OD_Home_Loan_Extension = 52,
        [Description("Home Loan- Improvement")]
        OD_Home_Loan_Improvement = 53,
        [Description("Composite Loan(PLOT Purchase+Construction Loan)")]
        OD_Composite_Loan_PLOT_Purchase_Plus_Construction_Loan = 54,
        [Description("BT")]
        OD_BT = 55,
        [Description("Topup-1")]
        OD_Topup_1 = 56,
        [Description("Topup-2")]
        OD_Topup_2 = 57,
        [Description("Insurance Loan")]
        OD_Insurance_Loan = 58,
        [Description("LAP 10 to 300 Lacs")]
        OD_LAP_10_to_300_Lacs = 59,
        [Description("Upto 200L")]
        Housing_IB_AHF_Upto_200L = 62,
        [Description("Unsecured TL - Based on POS")]
        UnSecured_TL_Based_On_POS = 66,
        [Description("Unsecured OD - Based on POS")]
        UnSecured_OD_Based_On_POS = 67,
        [Description("Unsecured OD - Based on Current Account")]
        UnSecured_OD_Based_On_Current_Account = 68,
        [Description("ATMA VISHWAS 2020-Salaried LAP-Pre Topup")]
        ATMA_VISHWAS_2020_Salaried_LAP_Pre_Topup = 73,
        [Description("ATMA VISHWAS 2020-BL Declared-Pre Topup")]
        ATMA_VISHWAS_2020_BL_Declared_Pre_Topup = 74
    }

    public enum PremisesType
    {
        [Description("BP")]
        BusinessPremises,
        [Description("RP")]
        ResidencePremises
    }

    public enum DataManipulationMode
    {
        INSERT,
        UPDATE,
        DELETE
    }

    public enum UserRole
    {
        [Description("ADMIN")]
        ADMIN = 1,
        [Description("BRANCH")]
        BRANCH = 2,
        [Description("CREDIT")]
        CREDIT = 3,
        [Description("LEGAL")]
        LEGAL = 4,
        [Description("HO-OPS-QC")]
        HO_OPS_QC = 5,
        [Description("HELP-DESK")]
        HELP_DESK = 6,
        [Description("HO-OPS / HELP-DESK")]
        HO_OPS_HELP_DESK = 7,
        [Description("CREDIT/HELP-DESK")]
        CREDIT_HELP_DESK = 8,
        [Description("CREDIT WO APVL")]
        CREDIT_WO_APVL = 9,
        [Description("SUPPORT")]
        SUPPORT = 10,
        [Description("RISK")]
        RISK = 11,
        [Description("OCI")]
        OCI = 12,
        [Description("SCI")]
        SCI = 13,
        [Description("AM-CI")]
        AM_CI = 14,
        [Description("CREDIT/SAMPLING")]
        CREDIT_SAMPLING = 15,
        [Description("BRANCH - PILOT")]
        BRANCH_PILOT = 16,
        [Description("HUB")]
        HUB = 17,
        [Description("PDD")]
        PDD = 18,
        [Description("LEGAL-AM")]
        LEGAL_AM = 19,
        [Description("RISK AUDIT")]
        RISK_AUDIT = 20,
        [Description("RISK HEAD")]
        RISK_HEAD = 21,
        [Description("CREDIT OPERATION")]
        CREDIT_OPERATION = 22,
        [Description("HR TRAINING")]
        HR_TRAINING = 23,
        [Description("CREDIT HO")]
        CREDIT_HO = 25,
        [Description("ABM")]
        ABM = 26,
        [Description("TWLBRANCH")]
        TWLBRANCH = 27,
        [Description("Product Manager")]
        Product_Manager = 28,
        [Description("CREDIT HEAD")]
        CREDIT_HEAD = 29,
        [Description("BUSINESS HEAD")]
        BUSINESS_HEAD = 31,
        [Description("CREDIT-MIS")]
        CREDIT_MIS = 32,
        [Description("COLLECTION")]
        COLLECTION = 33,
        [Description("MOBILE HELPDESK")]
        MOBILE_HELPDESK = 34,
        [Description("BC MANAGER")]
        BC_MANAGER = 35,
        [Description("GOLD INSPECTOR")]
        GOLD_INSPECTOR = 36,
        [Description("SALES MANAGER")]
        SALES_MANAGER = 37,
        [Description("UAM")]
        UAM = 38,
        [Description("HO-ACCESS")]
        HO_ACCESS = 40,
        [Description("LEAD-EMPCREATION")]
        LEAD_EMPCREATION = 41,
        [Description("ADMIN HO")]
        ADMIN_HO = 42,
        [Description("ALLREPORT")]
        ALLREPORT = 43,
        [Description("HO-OPS/POST DISBURSEMENT")]
        HO_OPS_POST_DISBURSEMENT = 45,
        [Description("LOANCLOSURE-HO")]
        LOANCLOSURE_HO = 46,
        [Description("MIS Coordinator")]
        MIS_Coordinator = 47,
        [Description("LEAD-EMPCREATION-PILOT")]
        LEAD_EMPCREATION_PILOT = 49,
        [Description("QC-REPORTS")]
        QC_REPORTS = 50,
        [Description("ALLREPORT_BCCONNECTOR")]
        ALLREPORT_BCCONNECTOR = 51,
        [Description("RMP")]
        RMP = 52,
        [Description("BRANCH_RPT_ACS")]
        BRANCH_RPT_ACS = 53,
        //[Description("Admin HO")]
        //Admin_HO = 57
    }

    public enum UserRoleGroup
    {
        [Description("Admin Users")]
        A = 1,
        [Description("Branch Users")]
        B = 2,
        [Description("Credit Users")]
        C = 3,
        [Description("Legal Users")]
        L = 4,
        [Description("HO-OPS Users")]
        HO = 5,
        [Description("ADMIN-HO Users")]
        AHO = 42
    }

    public enum CAM_LoanType
    {
        [Description("Home Purchase")]
        Home_Purchase = 1,
        [Description("Home Construction")]
        Home_Construction = 2,
        [Description("Home extention/Renovation")]
        Home_Extention_Renovation = 3,
        [Description("Composite Loan – Land Purchase")]
        Composite_Loan_Land_Purchase = 4,
        [Description("Composite Loan - Construction")]
        Composite_Loan_Construction = 5,
        [Description("BT")]
        BT = 6,
        [Description("Top Up")]
        Top_Up = 7,
        [Description("Composite Loan – Land & Construction")]
        Composite_Loan_Land_Construction = 8,
        [Description("Insurance Loan")]
        Insurance_Loan = 9
    }

    public enum SpotStatus
    {
        INITIATED = 1,
        [Description("BRANCH-RESPONDED")]
        BRANCH_RESPONDED = 2,
        [Description("CREDIT-APPROVED")]
        CREDIT_APPROVED = 3,
        [Description("CREDIT-REJECTED")]
        CREDIT_REJECTED = 4
    }

    public enum CustomerCategory
    {
        [Description("Existing Customer")]
        EXISTING_CUSTOMER = 1,
        [Description("New Customer")]
        NEW_CUSTOMER = 2
    }

    public enum ApplicantType
    {
        Applicant = 1,
        [Description("Co-Applicant1")]
        CoApplicant1 = 2,
        [Description("Co-Applicant2")]
        CoApplicant2 = 3,
        [Description("Co-Applicant3")]
        CoApplicant3 = 4,
        [Description("Co-Applicant4")]
        CoApplicant4 = 5,
        [Description("Co-Applicant5")]
        CoApplicant5 = 6,
        [Description("Co-Applicant6")]
        CoApplicant6 = 7,
        [Description("Co-Applicant7")]
        CoApplicant7 = 8,
        [Description("Co-Applicant8")]
        CoApplicant8 = 9,
        [Description("Co-Applicant9")]
        CoApplicant9 = 10,
        [Description("Co-Applicant10")]
        CoApplicant10 = 11
    }

    public enum Department
    {
        [Description("B")]
        BRANCH = 1,
        [Description("C")]
        CREDIT = 2,
        [Description("L")]
        LEGAL = 3,
        [Description("HO")]
        HO_OPS = 4,
        [Description("HD")]
        HELP_DESK = 5,
        [Description("RK")]
        RISK = 6
    }

    public enum FileScoreDefinition
    {
        [Description("VERY LOW RISK")]
        VERY_LOW_RISK = 1,
        [Description("LOW RISK")]
        LOW_RISK = 2,
        [Description("MEDIUM RISK")]
        MEDIUM_RISK = 3,
        [Description("HIGH RISK")]
        HIGH_RISK = 4,
        [Description("VERY HIGH RISK")]
        VERY_HIGH_RISK = 5
    }

    public enum CamType
    {
        [Description("BRANCH CAM")]
        B = 1,
        [Description("CREDIT CAM")]
        C = 2,
        [Description("SAMPLING CAM")]
        F = 3
    }
}