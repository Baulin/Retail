﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Net.Mail;
using Utilities;
using System.Web.Mail;
using System.Web.UI.WebControls;
using System.Web.Security;
using Tracker;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
/// <summary>
/// Summary description for EmailManager
/// </summary>

namespace Utilities
{
    public static class EmailContentManager
    {
       public static string strcon = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
       public static SqlCommand cmd = new SqlCommand();
       public static ClsCommon clscommon = new ClsCommon();
       public static  DataTable ds = new DataTable();
      /*  public static string GetForgotPasswordEmail(string emailaddress)
        {
            string tmpEmailContent = "";
            try
            {
                int parentid = ParentChildEnrollmentManager.GetParentIDByEmail(emailaddress);

                Parentregistration objParentName = new Parentregistration(Parentregistration.Columns.Parentid, parentid);
                string username = objParentName.Parentfirstname;
                tmpEmailContent = "Dear " + username + ",<br/><br/>" + "Thanks for using " + Config.CurrentURL + "<br/><br/>Please find your login credentials along with your auto-generated password below<br/><br/> <b>Username : <@Username@><br/><br/>Password : <@Password@></b><br/><br/>Kindly notify the administrator in case of any issues logging into the system. <br/><br/>AMALC Admin<br/>admin@amalc.com";
                tmpEmailContent = tmpEmailContent.Replace("<@Username@>", emailaddress);
                string password = AdminManagement.AdminManager.GetPasswordByEmail(emailaddress);
                tmpEmailContent = tmpEmailContent.Replace("<@Password@>", password);

            }
            catch (Exception ex)
            {
                Logger.ErrorLog(ex);
            }
            return tmpEmailContent;
        }



        */

        //public static string GetForgotPasswordByUserid(string userid)
        //{
        //    string tmpEmailContent = "";
        //    try
        //    {
               
        //        DataTable ds = new DataTable();
        //        ds = clscommon.SP_CCMS1_MRUSER_By_USRCODE(userid);
        //          if (ds.Rows.Count != 0)
        //          {
        //              string username = ds.Rows[0]["USR_NAME"].ToString();
        //              tmpEmailContent = "Dear " + username + ",<br/><br/>" + "Thanks for using " + Config.CurrentURL + "<br/><br/>Please find your login credentials along with your auto-generated password below<br/><br/> <b>Username : <@Username@><br/><br/>Password : <@Password@></b><br/><br/>Kindly notify the administrator in case of any issues logging into the system. <br/><br/>CCMS Helpdesk<br/>";
        //              tmpEmailContent = tmpEmailContent.Replace("<@Username@>", ds.Rows[0]["USR_CODE"].ToString());
        //             // string password = AdminManagement.AdminManager.GetPasswordByEmail(emailaddress);
        //              tmpEmailContent = tmpEmailContent.Replace("<@Password@>", ds.Rows[0]["USR_PWD"].ToString());
        //          }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorLog.WriteError(ex);
        //    }
        //    return tmpEmailContent;
        //}

    }
}