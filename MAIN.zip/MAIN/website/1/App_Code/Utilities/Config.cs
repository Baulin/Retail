﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;
/// <summary>
/// Summary description for Config
/// </summary>
public static class Config
{
   
    public static string CurrentURL
    {
        get
        {
            return ConfigurationManager.AppSettings["websiteUrl"];
        }
    }
   
   
}
