﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;
using System.Data;
using Tracker;
using System.Text.RegularExpressions;
/// <summary>
/// Summary description for Config
/// </summary>
namespace Utilities
{
    public static class UtilityManager
    {
        public static string GetTruncatedString(string longstring)
        {
            string truncatedstring = "";
            try
            {
                truncatedstring = longstring;
                if (longstring.Length > 50)
                {
                    truncatedstring = longstring.Substring(0, 50) + "...";
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return truncatedstring;
        }
        public static string GetCapitalFirstLetter(string longstring)
        {
            string truncatedstring = "";
            try
            {

                truncatedstring = longstring;
                char temp = truncatedstring[0];
                truncatedstring = temp.ToString().ToUpper() + longstring.Substring(1, longstring.Length - 1);
                if (truncatedstring.Length > 15)
                    truncatedstring = temp.ToString().ToUpper() + longstring.Substring(1, 15) + "...";
            }


            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return truncatedstring;
        }
        public static string GetTruncatedString(string longstring, int length)
        {
            string truncatedstring = "";
            try
            {
                truncatedstring = longstring;
                if (longstring.Length > length)
                {
                    truncatedstring = longstring.Substring(0, length) + "...";
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return truncatedstring;
        }
        public static string GetAge(DateTime Dob)
        {

            string age = "";
            try
            {
                int Years = ((int)(new DateTime(DateTime.Now.Subtract(Dob).Ticks).Year));
                Years = Years - 1;
                DateTime PastYearDate = Dob.AddYears(Years);
                int Months = 0;
                DateTime Now = DateTime.Now;
                for (int i = 1; i <= 12; i++)
                {
                    if (PastYearDate.AddMonths(i) == Now) { Months = i; break; }
                    else if (PastYearDate.AddMonths(i) >= Now)
                    {
                        Months = (i - 1);

                        break;
                    }
                }
                int Days = Now.Subtract(PastYearDate.AddMonths(Months)).Days;
                int Hours = Now.Subtract(PastYearDate).Hours;
                int Minutes = Now.Subtract(PastYearDate).Minutes;
                int Seconds = Now.Subtract(PastYearDate).Seconds;
                //age = String.Format("{0}y {1}m", Years, Months);
                //diff = hour.ToString("00") + ":" + mins.ToString("00") + ":" + secs.ToString("00");
                age = String.Format("{0}h : {1}m ago", Hours, Minutes);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return age;


        }
        public static string GetAge1(DateTime Dob)
        {

            string age = "";
            try
            {
                int Years = ((int)(new DateTime(DateTime.Now.Subtract(Dob).Ticks).Year));
                Years = Years - 1;
                DateTime PastYearDate = Dob.AddYears(Years);
                int Months = 0;
                DateTime Now = DateTime.Now;
                for (int i = 1; i <= 12; i++)
                {
                    if (PastYearDate.AddMonths(i) == Now) { Months = i; break; }
                    else if (PastYearDate.AddMonths(i) >= Now)
                    {
                        Months = (i - 1);

                        break;
                    }
                }
                int Days = Now.Subtract(PastYearDate.AddMonths(Months)).Days;
                int Hours = Now.Subtract(PastYearDate).Hours;
                int Minutes = Now.Subtract(PastYearDate).Minutes;
                int Seconds = Now.Subtract(PastYearDate).Seconds;
                //age = String.Format("{0}y {1}m", Years, Months);
                //diff = hour.ToString("00") + ":" + mins.ToString("00") + ":" + secs.ToString("00");
                if (Hours==0)
                {
                age = String.Format("{0}m ago", Minutes);
                }
                else
                {
                    age = String.Format("{0}h : {1}m ago", Hours, Minutes);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return age;


        }
        public static string RemoveCommaAtEnd(string longstring)
        {
            string truncatedstring = "";
            try
            {
                if (longstring.Length > 1)
                {
                    truncatedstring = longstring.Substring(0, longstring.Length - 1);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return truncatedstring;
        }
        public static int GetNumberOfDaysInBetween(DateTime date1, DateTime date2)
        {
            int numberofdays = 0;
            try
            {
                numberofdays = (date2 - date1).Days;
                //To include the current day 
                numberofdays++;
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return numberofdays;
        }
        public static string GetDateTimeFormt(DateTime date1)
        {
            string datetimreturn = "";
            try
            {
                datetimreturn = date1.ToString("MM/dd/yy");
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return datetimreturn;
        }

        public static string CreateRandomPassword(int PasswordLength)
        {
            string randompassword = "";
            try
            {
                string _allowedChars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ0123456789";
                Random randNum = new Random();
                char[] chars = new char[PasswordLength];
                int allowedCharCount = _allowedChars.Length;

                for (int i = 0; i < PasswordLength; i++)
                {
                    chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
                }
                randompassword = new string(chars);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return randompassword;
        }
        
        
        public static bool isValidEmailAddress(string emailaddress)
        {
            bool isvalid = false;
            try
            {
                string patternLenient = @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
                Regex reLenient = new Regex(patternLenient);
                string patternStrict = @"^(([^<>()[\]\\.,;:\s@\""]+"
                   + @"(\.[^<>()[\]\\.,;:\s@\""]+)*)|(\"".+\""))@"
                   + @"((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"
                   + @"\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+"
                   + @"[a-zA-Z]{2,}))$";
                Regex reStrict = new Regex(patternStrict);

                isvalid = reLenient.IsMatch(emailaddress);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return isvalid;
        }

        public static string GetStageName(int stageid)
        {
            string stagename = "";
            try
            {
                string[] ArrLst = new string[9];
                ArrLst[1] = "Rejected";
                ArrLst[2] = "To Be Discussed";
                ArrLst[3] = "BRD To Be Received";
                ArrLst[4] = "BRD Approval Pending";
                ArrLst[5] = "Delivery Date To Be Received";
                ArrLst[6] = "Patch To Be Received";
                ArrLst[7] = "UAT To Be SignOff";
                ArrLst[8] = "Moved To Production";
                stagename = ArrLst[stageid];

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return stagename;

        }

        public static string GetQRType(int qryid)
        {
            string stagename = "";
            try
            {
                string[] ArrLst = new string[4];
                ArrLst[1] = "PR";
                ArrLst[2] = "PO";
                ArrLst[3] = "PT";
               
                stagename = ArrLst[qryid];

            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }
            return stagename;

        }
 
    }
}