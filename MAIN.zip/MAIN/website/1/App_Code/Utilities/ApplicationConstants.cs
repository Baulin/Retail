﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tracker
{
    /// <summary>
    /// Summary description for ApplicationConstants
    /// </summary>
    public static class AppConstants
    {
        public const String ID = "ID";
        public const String Mps_Id = "MPS_ID";
        public const String User_Id = "USR_ID";
        public const String Ld_Mps_Id = "LD_MPS_ID";
        public const String BRANCHID = "BRANCHID";
        public const String LoggingEnabled = "LoggingEnabled";
        public const String LoggingPath = "LoggingPath";
        public const String FileUploadPath = "FileUploadPath";
        public const String ReportsPath = "ReportsPath";
        public const String ActiveDbConnection = "ActiveDbConnection";
        public const String DefaultDbConnection = "connection";
        public const String UnoLead = "UnoLead";

        public const String CustProfile = "CustProfile";
        public const String CustProfileKey = "CustProfileKey";

        public const String FileNamePrefix_CAM = "CAM_";
        public const String FileNamePrefix_BankChallan = "BNK_CHAL_";
        public const String FileNamePrefix_MBL_Receipt = "MBL_REC_";
        public const String FileNamePrefix_Death_Certificate = "DEATH_CERT_";
        public const String FileNamePreficx_SOA = "SOA_";
        public const String FileNamePrefix_NACH = "NACH_";
        public const String FileNamePrefix_Pickup = "Pickup";

        public const String Directory_Closure = "\\CLOSURE\\";
        public const String Directory_File = "\\File\\";
        public const String Directory_Acknowledgement = "\\Acknowledgement\\";
        public const String Directory_FIRCU = "\\FIRCU\\";

        public const String FileType_Excel_Old = ".xls";
        public const String FileType_Excel_New = ".xlsx";
        public const String FileType_Text = ".txt";
        public const String FileType_PDF = ".pdf";

        #region DB TABLE-COLUMNS
        public const String Col_PR_CODE = "PR_CODE";

        public const String Col_BR_CODE = "BR_CODE";
        public const String Col_BR_NAME = "BR_NAME";

        public const String Col_AR_NAME = "AR_NAME";
        public const String Col_AR_ID = "AR_ID";

        public const String Col_KYC_NAME = "KYC_NAME";
        public const String Col_KYC_ID = "KYC_ID";
        public const String Col_KYC_LD_ID = "KYC_LD_ID";
        public const String Col_KYC_APPL_TYPE = "KYC_APPL_TYPE";

        public const String Col_CP_SEG = "CP_SEG";
        public const String Col_CP_PROFILE = "CP_PROFILE";
        public const String Col_CP_SUB_CTRY = "CP_SUB_CTRY";
        public const String Col_CP_APPL_TYPE = "CP_APPL_TYPE";

        #region UNO LEAD BUCKET
        public const String Col_UN_LD_BUK_ID = "UN_LD_BUK_ID";
        public const String Col_UN_LD_ID = "UN_LD_ID";
        public const String Col_UN_LD_NO = "UN_LD_NO";
        public const String Col_UN_APPL_NAME = "UN_APPL_NAME";
        public const String Col_UN_MOB_NO = "UN_MOB_NO";
        public const String Col_UN_BR_CODE = "UN_BR_CODE";
        public const String Col_UN_PROD_CODE = "UN_PROD_CODE";
        public const String Col_UN_PROD_DESC = "UN_PROD_DESC";
        public const String Col_UN_RECPT_NO = "UN_RECPT_NO";
        public const String Col_UN_RECPT_TYPE = "UN_RECPT_TYPE";
        public const String Col_UN_RECPT_AMT = "UN_RECPT_AMT";
        public const String Col_UN_CBY = "UN_CBY";
        public const String Col_UN_CDATE = "UN_CDATE";
        public const String Col_UN_RTS_IMPORT_DATE = "UN_RTS_IMPORT_DATE";
        public const String Col_UN_RTS_PROC_STAT = "UN_RTS_PROC_STAT";
        public const String Col_UN_RTS_MBY = "UN_RTS_MBY";
        public const String Col_UN_RTS_MDATE = "UN_RTS_MDATE";
        #endregion

        public const String Col_RTS_LEAD_NO = "LD_NO";

        public const String Col_ITEM_KEY = "ITEM_KEY";
        public const String Col_ITEM_DESC = "ITEM_DESC";

        public const String Col_PL_LAT = "PL_LAT";
        public const String Col_PL_LONG = "PL_LONG";
        public const String Col_PL_LAT_DIR = "PL_LAT_DIR";
        public const String Col_PL_LONG_DIR = "PL_LONG_DIR";
        public const String Col_PL_LANDMARK = "PL_LANDMARK";

        public const String Col_DID_LD_ID = "DID_LD_ID";
        public const String Col_DID_KYC_ID = "DID_KYC_ID";
        public const String Col_DID_NAT_OF_INCOME = "DID_NAT_OF_INCOME";
        public const String Col_DID_INCOME = "DID_INCOME";

        public const String Col_CM_CREDIT = "CM_CREDIT";
        public const String Col_DIS_CRDT_COND = "DIS_CRDT_COND";

        public const String Col_DOD_LD_ID = "DOD_LD_ID";
        public const String Col_DOD_KYC_ID = "DOD_KYC_ID";
        public const String Col_DOD_FIN = "DOD_FIN";
        public const String Col_DOD_LTYPE = "DOD_LTYPE";
        public const String Col_DOD_SRC_OF_LOAN_IDENTF = "DOD_SRC_OF_LOAN_IDENTF";
        public const String Col_DOD_CIBIL = "DOD_CIBIL";
        public const String Col_DOD_EMI = "DOD_EMI";
        public const String Col_DOD_BAL_NO_OF_EMI = "DOD_BAL_NO_OF_EMI";

        public const String Col_EMP_CODE = "EMP_CODE";
        public const String Col_EMP_NAME = "EMP_NAME";

        public const String Col_UTP_DESC = "UTP_DESC";
        public const String Col_USR_ID = "USR_ID";

        #region UNSECURED ESFB LOAN DETAILS
        public const String Col_UELD_ID = "UELD_ID";
        public const String Col_UELD_CAM_ID = "UELD_CAM_ID";
        public const String Col_UELD_CUST_TYPE_ID = "UELD_CUST_TYPE_ID";
        public const String Col_UELD_ESFB_LN_AGRMNT = "UELD_ESFB_LN_AGRMNT";
        public const String Col_UELD_ESFB_PR_NAME = "UELD_ESFB_PR_NAME";
        public const String Col_UELD_ESFB_LN_AMT = "UELD_ESFB_LN_AMT";
        public const String Col_UELD_ESFB_LN_OS_AMT = "UELD_ESFB_LN_OS_AMT";
        #endregion

        #region UNSECURED BUSINESS DETAILS
        public const String Col_UBD_LD_ID = "UBD_LD_ID";
        public const String Col_UBD_UCAM_ID = "UBD_UCAM_ID";
        public const String Col_UBD_KYC_ID = "UBD_KYC_ID";
        public const String Col_UBD_CIBIL = "UBD_CIBIL";
        public const String Col_UBD_NAT_OF_BUSINESS = "UBD_NAT_OF_BUSINESS";
        public const String Col_UBD_NAT_OF_BUSINESS_KEY = "UBD_NAT_OF_BUSINESS_KEY";
        public const String Col_UBD_CUST_PROF_ID = "UBD_CUST_PROF_ID";
        public const String Col_UBD_SGMT_ID = "UBD_SGMT_ID";
        public const string Col_UBD_SUB_CTGRY_ID = "UBD_SUB_CTGRY_ID";
        public const String Col_UBD_SALES_BASED_ON_ASSMT = "UBD_SALES_BASED_ON_ASSMT";
        public const String Col_UBD_STAT = "UBD_STAT";
        public const String Col_UBD_CRTD_BY = "UBD_CRTD_BY";
        public const String Col_UBD_CRTD_DT = "UBD_CRTD_DT";
        public const String Col_UBD_MDFD_BY = "UBD_MDFD_BY";
        public const String Col_UBD_MDFD_DT = "UBD_MDFD_DT";
        #endregion

        #region UNSECURED OTHER LOAN DETAILS
        public const String Col_UOLD_LD_ID = "UOLD_LD_ID";
        public const String Col_UOLD_UCAM_ID = "UOLD_UCAM_ID";
        public const String Col_UOLD_FIN = "UOLD_FINs";
        public const String Col_UOLD_LN_TYPE = "UOLD_LN_TYPE";
        public const String Col_UOLD_LN_TYPE_ID = "UOLD_LN_TYPE_ID";
        public const String Col_UOLD_SANC_AMT = "UOLD_SANC_AMT";
        public const String Col_UOLD_OUTSTAND_AMT = "UOLD_OUTSTAND_AMT";
        public const String Col_UOLD_EMI_AMT = "UOLD_EMI_AMT";
        public const String Col_UOLD_TENOR = "UOLD_TENOR";
        public const String Col_UOLD_STAT = "UOLD_STAT";
        public const String Col_UOLD_CRTD_BY = "UOLD_CRTD_BY";
        public const String Col_UOLD_CRTD_DT = "UOLD_CRTD_DT";
        public const String Col_UOLD_MDFD_BY = "UOLD_MDFD_BY";
        public const String Col_UOLD_MDFD_DT = "UOLD_MDFD_DT";
        #endregion

        #endregion

        #region STORED PROCEDURES

        #region VALIDATIONS
        public const String Proc_RTS_SP_CHECK_DIS_COMPLETED = "RTS_SP_CHECK_DIS_COMPLETED";
        public const String Proc_RTS_SP_CHK_LEAD_DUPLICATION = "RTS_SP_CHECK_LEAD_DUPLICATION";
        public const String Proc_RTS_SP_VALIDATE_USER_IS_ADMIN = "RTS_SP_VALIDATE_USER_IS_ADMIN";
        public const String Proc_RTS_SP_CHK_LEAD_LOCKED_BY_USER = "RTS_SP_CHK_LEAD_LOCKED_BY_USER";
        public const String Proc_RTS_SP_VALIDATE_CREDIT_DM_COMPLETE = "RTS_SP_VALIDATE_CREDIT_DM_COMPLETE";
        public const String Proc_RTS_SP_CHK_LEAD_AVAILABLE_FOR_PICK = "RTS_SP_CHK_LEAD_AVAILABLE_FOR_PICK";
        public const String Proc_RTS_SP_VALIDATE_USER_TYPE_IS_BRANCH = "RTS_SP_VALIDATE_USER_TYPE_IS_BRANCH";
        public const String Proc_RTS_SP_UNSECURED_CHECK_PENDING_TECH_INIT = "RTS_SP_UNSECURED_CHECK_PENDING_TECH_INIT";
        public const String Proc_RTS_SP_VALIDATE_DM_ELIGIBLE_FOR_PROCESSING = "RTS_SP_VALIDATE_DM_ELIGIBLE_FOR_PROCESSING";
        #endregion

        #region GET
        public const String Proc_RTS_SP_FETCH_DM_AHF = "RTS_SP_FETCH_DM_AHF";
        public const String Proc_RTS_SP_FETCH_DM_MFHF = "RTS_SP_FETCH_DM_MFHF";
        public const String Proc_RTS_SP_FETCH_DM_SLAP = "RTS_SP_FETCH_DM_SLAP";
        public const String Proc_RTS_SP_FETCH_DM_SME_LAP = "RTS_SP_FETCH_DM_SME_LAP";
        public const String Proc_RTS_SP_FETCH_MR_AREA = "RTS_SP_FETCH_MR_AREA";
        public const String Proc_RTS_SP_FETCH_DDL_MENU = "RTS_SP_FETCH_DDL_MENU";
        public const String Proc_RTS_SP_Fetch_MR_REASON = "RTS_SP_Fetch_MR_REASON";
        public const String Proc_RTS_SP_FETCH_LEAD_DETAILS = "RTS_SP_FETCH_LEAD_DETAILS";

        public const String Proc_RTS_SP_FETCH_MR_USAGE = "RTS_SP_FETCH_MR_USAGE";
        public const String Proc_RTS_PR_FETCH_LOAN_TYPE = "RTS_PR_FETCH_LOAN_TYPE";
        public const String Proc_RTS_SP_FETCH_MR_PROPERTY = "RTS_SP_FETCH_MR_PROPERTY";
        public const String Proc_RTS_SP_FETCH_MR_OCCUPANCY = "RTS_SP_FETCH_MR_OCCUPANCY";
        public const String Proc_RTS_SP_FETCH_MR_PROPERTY_GHF = "RTS_SP_FETCH_MR_PROPERTY_GHF";
        public const String Proc_RTS_SP_FETCH_MR_PRODUCT_LOAN_CAP = "RTS_SP_FETCH_MR_PRODUCT_LOAN_CAP";
        public const String Proc_RTS_SP_FETCH_MR_CUSTOMER_CATEGORY = "RTS_SP_FETCH_MR_CUSTOMER_CATEGORY";

        public const String Proc_RTS_SP_CREDIT_CUSTOMER_PROFILE = "SP_CREDIT_CUSTOMER_PROFILE";

        public const String Proc_RTS_SP_FETCH_FINAL_CAM_AREA = "RTS_SP_FETCH_FINAL_CAM_AREA";
        public const String Proc_RTS_SP_FETCH_FINAL_CAM_BRANCH = "RTS_SP_FETCH_FINAL_CAM_BRANCH";
        public const String Proc_RTS_SP_FETCH_CAM_LEAD_DETAILS = "RTS_SP_FETCH_CAM_LEAD_DETAILS";
        public const String Proc_RTS_SP_FETCH_MR_BRANCH_BY_AREA = "RTS_SP_FETCH_MR_BRANCH_BY_AREA";
        public const String Proc_RTS_SP_FETCH_LIABILITY_BRANCHES = "RTS_SP_FETCH_LIABILITY_BRANCHES";
        public const String Proc_RTS_SP_GET_UNSECURED_CAM_REPORT = "RTS_SP_GET_UNSECURED_CAM_REPORT";
        public const String Proc_RTS_SP_FETCH_UNSECURED_LEAD_DETAILS = "RTS_SP_FETCH_UNSECURED_LEAD_DETAILS";
        public const String Proc_RTS_SP_FETCH_LEAD_DETAILS_BY_LOAN_NO = "RTS_SP_FETCH_LEAD_DETAILS_BY_LOAN_NO";
        public const String Proc_RTS_SP_FETCH_USER_DETAILS_BY_USER_ID = "RTS_SP_FETCH_USER_DETAILS_BY_USER_ID";
        public const String Proc_RTS_SP_GET_LEADS_FOR_UNSECURED_BR_CAM = "RTS_SP_GET_LEADS_FOR_UNSECURED_BR_CAM";
        public const String Proc_RTS_SP_GET_LEADS_FOR_UNSECURED_CR_CAM = "RTS_SP_GET_LEADS_FOR_UNSECURED_CR_CAM";
        public const String Proc_RTS_SP_FETCH_MERCHANT_OD_CAM_MASTER_DATA = "RTS_SP_FETCH_MERCHANT_OD_CAM_MASTER_DATA";
        public const String Proc_RTS_SP_GET_CAM_DETAILS_FOR_UNSECURED_LEADS = "RTS_SP_GET_CAM_DETAILS_FOR_UNSECURED_LEADS";
        public const String Proc_RTS_SP_FETCH_EMPLOYEE_DETAILS_BY_EMPLOYEENO = "RTS_SP_FETCH_EMPLOYEE_DETAILS_BY_EMPLOYEENO";
        public const String Proc_RTS_SP_GET_UNSECURED_CREDIT_APPROVAL_MEMO_REPORT = "RTS_SP_GET_UNSECURED_CREDIT_APPROVAL_MEMO_REPORT";

        public const String Proc_RTS_SP_GET_SPOT_CASES = "RTS_SP_GET_SPOT_CASES";
        public const String Proc_RTS_SP_GET_SPOT_DETAILS = "RTS_SP_GET_SPOT_DETAILS";
        public const String Proc_RTS_SP_GET_UNO_LEAD_BUCKET = "RTS_SP_GET_UNO_LEAD_BUCKET";
        public const String Proc_RTS_SP_GET_DECLARED_SME_SLAP_AHF = "RTS_SP_GET_DECLARED_SME_SLAP_AHF";
        public const String Proc_RTS_SP_FETCH_PREMISES_LOCATION = "RTS_SP_FETCH_PREMISES_LOCATION";
        public const String Proc_RTS_SP_GET_IB_SME_UNSECURED_OT_TL = "RTS_SP_GET_IB_SME_UNSECURED_OT_TL";
        public const String Proc_RTS_SP_GET_LEAD_APPLICANT_DETAILS = "RTS_SP_GET_LEAD_APPLICANT_DETAILS";
        public const String Proc_RTS_SP_GET_CREDIT_CUSTOMER_PROFILE = "RTS_SP_GET_CREDIT_CUSTOMER_PROFILE";
        public const String Proc_RTS_SP_GET_DROPDOWN_ITEMS_BY_GROUP = "RTS_SP_GET_DROPDOWN_ITEMS_BY_GROUP";
        public const String Proc_RTS_SP_GET_CREDIT_OD_TL_MEMO_REPORT = "RTS_SP_GET_CREDIT_OD_TL_MEMO_REPORT";
        public const String Proc_RTS_SP_GET_CREDIT_APPROVAL_MEMO_OD_TL = "RTS_SP_GET_CREDIT_APPROVAL_MEMO_OD_TL";
        public const String Proc_RTS_SP_GET_DROPDOWN_ITEMS_BY_GROUP_AND_SUBGROUP = "RTS_SP_GET_DROPDOWN_ITEMS_BY_GROUP_AND_SUBGROUP";
        #endregion

        #region INSERT
        public const String PROC_RTS_SP_INSERTDCM = "RTS_SP_INSERTDCM";
        public const String PROC_RTS_SP_INSERTDCM_AHF = "RTS_SP_INSERTDCM_AHF";
        public const String PROC_RTS_SP_INSERTDCM_SME = "RTS_SP_INSERTDCM_SME";
        public const String Proc_RTS_SP_CREATE_LEADID = "RTS_SP_CREATE_LEADID";
        public const String Proc_RTS_SP_PICK_UNO_LEAD = "RTS_SP_PICK_UNO_LEAD";
        public const String Proc_RTS_SP_INSERT_BRANCH_LEAD = "RTS_SP_INSERT_BRANCH_LEAD";
        public const String Proc_RTS_SP_INSERT_UNSECURED_CAM = "RTS_SP_INSERT_UNSECURED_CAM";
        public const String Proc_RTS_SP_INSERT_UNSECURED_BRANCH_CAM = "RTS_SP_INSERT_UNSECURED_BRANCH_CAM";
        public const String Proc_RTS_SP_INSERT_UNSECURED_CREDIT_CAM = "RTS_SP_INSERT_UNSECURED_CREDIT_CAM";
        public const String Proc_RTS_SP_INSERT_UNSECURED_CIBIL = "RTS_SP_INSERT_UNSECURED_CIBIL";
        public const String Proc_RTS_SP_INSERT_PREMISES_LOCATION = "RTS_SP_INSERT_PREMISES_LOCATION";
        public const String Proc_RTS_SP_INSERT_UNSECURED_CR_APRVL = "RTS_SP_INSERT_UNSECURED_CR_APRVL";
        public const String Proc_RTS_SP_INSERT_DECLARED_INCOME_SUMMARY = "RTS_SP_INSERT_DECLARED_INCOME_SUMMARY";
        public const String Proc_RTS_SP_INSERT_DECLARED_INCOME_DETAILS = "RTS_SP_INSERT_DECLARED_INCOME_DETAILS";
        public const String Proc_RTS_SP_INSERT_CREDIT_APPROVER_DETAILS = "RTS_SP_INSERT_CREDIT_APPROVER_DETAILS";
        public const String Proc_RTS_SP_INSERT_DECLARED_OBLIGATION_DETAILS = "RTS_SP_INSERT_DECLARED_OBLIGATION_DETAILS";
        #endregion

        #region UPDATE
        public const String Proc_RTS_SP_UNLOCK_UNO_LEAD = "RTS_SP_UNLOCK_UNO_LEAD";
        public const String Proc_RTS_SP_COMPLETE_UNO_LEAD = "RTS_SP_COMPLETE_UNO_LEAD";
        public const String Proc_RTS_SP_ADMIN_UNLOCK_UNO_LEAD = "RTS_SP_ADMIN_UNLOCK_UNO_LEAD";
        public const String Proc_RTS_SP_UPDATE_CREDIT_APPROVAL = "RTS_SP_UPDATE_CREDIT_APPROVAL";
        public const String Proc_RTS_SP_UPDATE_PREMISES_LOCATION = "RTS_SP_UPDATE_PREMISES_LOCATION";
        #endregion

        #region SAVE
        public const String Proc_RTS_SP_SAVE_SPOT_EMPLOYEE_DETAILS = "RTS_SP_SAVE_SPOT_EMPLOYEE_DETAILS";
        #endregion

        #region DELETE
        #endregion

        #region BULK INSERT
        #endregion

        #region BULK UPDATE
        #endregion

        #region REPORT
        public const String Proc_RTS_SP_RPT_DECLARED_INCOME_SUMMARY_SHEET = "RTS_SP_RPT_DECLARED_INCOME_SUMMARY_SHEET";
        public const String Proc_RTS_SP_RPT_CUMULATIVE_DECLARED_SUMMARY_SHEET = "RTS_SP_RPT_CUMULATIVE_DECLARED_SUMMARY_SHEET";
        #endregion

        #endregion

        #region DB PARAMS

        #region TABLE COLUMN PARAMS

        public const String Param_From_Date = "@FROM_DATE";
        public const String Param_To_Date = "@TO_DATE";
        public const String Param_LD_ID = "@LD_ID";
        public const String Param_BranchCode = "@BranchCode";
        public const String Param_View = "@View";
        public const String Param_LD_NO = "@LD_NO";
        public const String Param_EMP_NO = "@EMP_NO";
        public const String Param_Lead_Type = "@Lead_Type";
        public const String Param_LD_LOAN_NO = "@LD_LOAN_NO";

        public const String Param_AR_ID = "@AR_ID";
        public const String Param_AR_NAME = "@AR_NAME";
        public const String Param_AREA_ID = "@AreaID";

        public const String Param_PR_ID = "@PR_ID";
        public const String Param_PR_NAME = "@PR_NAME";

        public const String Param_BR_ID = "@BR_ID";
        public const String Param_BR_NAME = "@BR_NAME";

        public const String Param_FT_SENTBY = "@FT_SENTBY";
        public const String Param_FT_SENTTO = "@FT_SENTTO";
        public const String Param_QTYPE = "@QTYPE";

        #region DECLARED INCOME SUMMARY SHEET
        public const String Param_DIS_LD_ID = "@DIS_LD_ID";
        public const String Param_DIS_PROG = "@DIS_PROG";
        public const String Param_DIS_PTYPE = "@DIS_PTYPE";
        public const String Param_DIS_OCCSTAT = "@DIS_OCCSTAT";
        public const String Param_DIS_LAREA = "@DIS_LAREA";
        public const String Param_DIS_LVALUE = "@DIS_LVALUE";
        public const String Param_DIS_TOT_LVALUE = "@DIS_TOT_LVALUE";
        public const String Param_DIS_BAREA = "@DIS_BAREA";
        public const String Param_DIS_BVALUE = "@DIS_BVALUE";
        public const String Param_DIS_TOT_BVALUE = "@DIS_TOT_BVALUE";
        public const String Param_DIS_AMENITIES = "@DIS_AMENITIES";
        public const String Param_DIS_TOT_PVALUE = "@DIS_TOT_PVALUE";

        public const String Param_DIS_TOT_INCOME = "@DIS_TOT_INCOME";
        public const String Param_DIS_TOT_OBLIG = "@DIS_TOT_OBLIG";

        public const String Param_DIS_TENOR = "@DIS_TENOR";
        public const String Param_DIS_ROI = "@DIS_ROI";
        public const String Param_DIS_FIN_LAMOUNT = "@DIS_FIN_LAMOUNT";
        public const String Param_DIS_EMI = "@DIS_EMI";
        public const String Param_DIS_APP_IIR = "@DIS_APP_IIR";
        public const String Param_DIS_APP_FOIR = "@DIS_APP_FOIR";
        public const String Param_DIS_LTV = "@DIS_LTV";
        public const String Param_DIS_LCR = "@DIS_LCR";
        public const String Param_DIS_CRE = "@DIS_CRE";
        public const String Param_DIS_DEVIATION = "@DIS_DEVIATION";
        public const String Param_DIS_CRDT_COND = "@DIS_CRDT_COND";
        public const String Param_DIS_NOP_AL_OWN = "@DIS_NOP_AL_OWN";
        public const String Param_DIS_NOP_TB_OWN = "@DIS_NOP_TB_OWN";
        public const String Param_DIS_FILE_RECOMD_BY = "@DIS_FILE_RECOMD_BY";
        public const String Param_DIS_FILE_APPRVD_BY = "@DIS_FILE_APPRVD_BY";
        public const String Param_DIS_FILE_OFFL_MAIL_APPRVD_BY = "@DIS_FILE_OFFL_MAIL_APPRVD_BY";
        public const String Param_DIS_CBY = "@DID_CBY";
        public const String Param_DIS_MBY = "@DID_MBY";
        public const String Param_DM_TYPE = "@DM_Type";
        #endregion

        public const String Param_CAM_TYPE = "@CAM_TYPE";
        public const String Param_CAM_FIN_LDATE = "@CAM_FIN_LDATE";
        public const String Param_CAM_LN_LTV_CNST = "@CAM_LN_LTV_CNST";
        public const String Param_CAM_NO_OF_PROP_OWNED = "@CAM_NO_OF_PROP_OWNED";
        public const String Param_CAM_CUST_REQ_LPV = "@CAM_CUST_REQ_LPV";
        public const String Param_CAM_CUST_REQ_CNST = "@CAM_CUST_REQ_CNST";
        public const String Param_CAM_LAND_PRCH_LN_AMT = "@CAM_LND_PR_LN_AMT";
        public const String Param_CAM_CONS_LN_AMT = "@CAM_CONS_LN_AMT";
        public const String Param_CAM_ADD_LTV = "@CAM_ADD_LTV";
        public const String Param_PageNumber = "@PageNo";
        public const String Param_RecordsPerPage = "@RecordsPerPage";
        public const String Param_SortBy = "@SortBy";
        public const String Param_SortDirection = "@SortDirection";
        public const String Param_UserId = "@UserId";
        public const String Param_UserType = "@UserType";
        public const String Param_UserRoleGroup = "@UserRoleGroup";
        public const String Param_UnoLeadBucketId = "@UnoLeadBucketId";
        public const String Param_UnoLeadId = "@UnoLeadId";
        public const String Param_UnoLeadNo = "@UnoLeadNo";
        public const String Param_RtsLeadNo = "@RtsLeadNo";
        public const String Param_TotalNoOfRecords = "@TotalNoOfRecords";
        public const String Param_Result = "@Result";
        public const String Param_Lead_No = "@LD_NO";
        public const String Param_Lead_Id = "@LeadID";
        public const String Param_Item_Group = "@ItemGroup";
        public const String Param_Item_SubGroup = "@ItemSubGroup";
        public const String Param_USER_ID = "@USER_ID";
        public const String Param_RECOM_BY = "@RECOM_BY";
        public const String Param_APPRV_BY = "@APPRV_BY";
        public const String Param_UPDT_IN_RTS_BY = "@UPDT_IN_RTS_BY";

        public const String Param_SPT_LD_ID = "@SPT_LD_ID";
        public const String Param_SPT_EMP_NO = "@SPT_EMP_NO";
        public const String Param_SPT_EMP_NAME = "@SPT_EMP_NAME";
        public const String Param_SPT_EMP_EMAIL = "@SPT_EMP_EMAIL";
        public const String Param_SPT_BRANCH_RESP = "@SPT_BRANCH_RESP";
        public const String Param_SPT_BRANCH_RESP_BY = "@SPT_BRANCH_RESP_BY";
        public const String Param_SPT_STAT = "@SPT_STAT";
        public const String Param_SPT_CBY = "@SPT_CBY";
        public const String Param_SPT_CDATE = "@SPT_CDATE";
        public const String Param_SPT_MBY = "@SPT_MBY";
        public const String Param_SPT_MDATE = "@SPT_MDATE";

        public const String Param_PT_ID = "@PT_ID";
        public const String Param_PT_TYPE = "@PT_TYPE";
        public const String Param_PT_DESC = "@PT_DESC";
        public const String Param_PT_LT_ID = "@PT_LT_ID";

        public const String Param_OC_ID = "@OC_ID";
        public const String Param_UG_ID = "@UG_ID";

        public const String Param_PRODUCT = "@PRODUCT";
        public const String Param_TYPE = "@TYPE";
        public const String Param_SU_PRF_ID = "@SU_PRF_ID";
        public const String Param_SU_SEG_ID = "@SU_SEG_ID";

        #region UNSECURED CAM

        #region CAM SUMMARY

        public const String Param_UCAM_ID = "@UCAM_ID";
        public const String Param_UCAM_LD_ID = "@UCAM_LD_ID";
        public const String Param_UCAM_CAM_TYPE = "@UCAM_CAM_TYPE";
        public const String Param_UCAM_APPL_NAME = "@UCAM_APPL_NAME";
        public const String Param_UCAM_AR_ID = "@UCAM_AR_ID";
        public const String Param_UCAM_AR_NAME = "@UCAM_AR_NAME";
        public const String Param_UCAM_BR_ID = "@UCAM_BR_ID";
        public const String Param_UCAM_BR_NAME = "@UCAM_BR_NAME";
        public const String Param_UCAM_RES_ADDRESS = "@UCAM_RES_ADDRESS";
        public const String Param_UCAM_CONTACT_NO = "@UCAM_CONTACT_NO";
        public const String Param_UCAM_LIAB_BR_ID = "@UCAM_LIAB_BR_ID";
        public const String Param_UCAM_LIAB_BR_NAME = "@UCAM_LIAB_BR_NAME";
        public const String Param_UCAM_CUST_REQ_AMT = "@UCAM_CUST_REQ_AMT";
        public const String Param_UCAM_CUST_CTGRY = "@UCAM_CUST_CTGRY";
        public const String Param_UCAM_CUST_CTGRY_ID = "@UCAM_CUST_CTGRY_ID";
        public const String Param_UCAM_EXST_LN_AGRMNT = "@UCAM_EXST_LN_AGRMNT";
        public const String Param_UCAM_PR_NAME = "@UCAM_PR_NAME";
        public const String Param_UCAM_EXST_LN_AMT = "@UCAM_EXST_LN_AMT";
        public const String Param_UCAM_PRPTY_TYPE = "@UCAM_PRPTY_TYPE";
        public const String Param_UCAM_PRPTY_TYPE_ID = "@UCAM_PRPTY_TYPE_ID";
        public const String Param_UCAM_OCC_STAT = "@UCAM_OCC_STAT";
        public const String Param_UCAM_OCC_STAT_ID = "@UCAM_OCC_STAT_ID";
        public const String Param_UCAM_USG = "@UCAM_USG";
        public const String Param_UCAM_USG_ID = "@UCAM_USG_ID";
        public const String Param_UCAM_OTH_DT_MON_INC_FRM_BSNS = "@UCAM_OTH_DT_MON_INC_FRM_BSNS";
        public const String Param_UCAM_OTH_DT_FACT_PRCNT = "@UCAM_OTH_DT_FACT_PRCNT";
        public const String Param_UCAM_OTH_DT_FIN_INC = "@UCAM_OTH_DT_FIN_INC";
        public const String Param_UCAM_OTH_DT_POP_CITY = "@UCAM_OTH_DT_POP_CITY";
        public const String Param_UCAM_TOT_SAL_ASSMT = "@UCAM_TOT_SAL_ASSMT";
        public const String Param_UCAM_FACT_PRCNT = "@UCAM_FACT_PRCNT";
        public const String Param_UCAM_FACT_DEV_PRCNT = "@UCAM_FACT_DEV_PRCNT";
        public const String Param_UCAM_SAL_AFTR_FACTR = "@UCAM_SAL_AFTR_FACTR";
        public const String Param_UCAM_TOT_OUT_AMT = "@UCAM_TOT_OUT_AMT";
        public const String Param_UCAM_ESFB_LMT_ELIG = "@UCAM_ESFB_LMT_ELIG";
        public const String Param_UCAM_FIN_ESFB_LMT_ELIG = "@UCAM_FIN_ESFB_LMT_ELIG";
        public const String Param_UCAM_UCIC_NO = "@UCAM_UCIC_NO";
        public const String Param_UCAM_REMARKS = "@UCAM_REMARKS";
        public const String Param_UCAM_STAT = "@UCAM_STAT";
        public const String Param_UCAM_CRTD_BY = "@UCAM_CRTD_BY";
        public const String Param_UCAM_CRTD_DT = "@UCAM_CRTD_DT";
        public const String Param_UCAM_MDFD_BY = "@UCAM_MDFD_BY";
        public const String Param_UCAM_MDFD_DT = "@UCAM_MDFD_DT";

        #endregion

        #region FILE CREDIT SCORE

        public const String Param_FCS_ID = "@FCS_ID";
        public const String Param_FCS_CAM_ID = "@FCS_CAM_ID";
        public const String Param_FCS_BSNS_VINT_ID = "@FCS_BSNS_VINT_ID";
        public const String Param_FCS_MON_INC_FRM_BSNS_ID = "@FCS_MON_INC_FRM_BSNS_ID";
        public const String Param_FCS_CR_HIST_ID = "@FCS_CR_HIST_ID";
        public const String Param_FCS_RES_PREM_OWND_ID = "@FCS_RES_PREM_OWND_ID";
        public const String Param_FCS_BSNS_PREM_OWND_ID = "@FCS_BSNS_PREM_OWND_ID";
        public const String Param_FCS_LIMT_PRCNT_TRNOVR_ID = "@FCS_LIMT_PRCNT_TRNOVR_ID";
        public const String Param_FCS_SCORE = "@FCS_SCORE";
        public const String Param_FCS_DEFN = "@FCS_DEFN";

        #endregion

        #endregion

        #endregion

        #region TABLE TYPE PARAMS

        public const String Param_DT_DeclaredIncomeDetails = "@DT_DeclaredIncomeDetails";
        public const String Param_DT_DeclaredObligationDetails = "@DT_DeclaredObligationDetails";
        public const String Param_DT_UNSECURED_ESFB_LOAN_DETAILS = "@DT_UNSECURED_ESFB_LOAN_DETAILS";
        public const String Param_DT_UNSECURED_BUSINESS_DETAILS = "@DT_UNSECURED_BUSINESS_DETAILS";
        public const String Param_DT_UNSECURED_OTHER_LOAN_DETAILS = "@DT_UNSECURED_OTHER_LOAN_DETAILS";

        #endregion

        #endregion

        #region DDL DATABIND TEXT AND VALUE KEYS

        public const String DDL_DATATEXT_KEY_LD_NO = "LD_NO";
        public const String DDL_DATAVALUE_KEY_LD_ID = "LD_ID";

        public const String DDL_DATATEXT_KEY_AR_NAME = "AR_NAME";
        public const String DDL_DATAVALUE_KEY_AR_ID = "AR_ID";

        public const String DDL_DATATEXT_KEY_BR_NAME = "BR_NAME";
        public const String DDL_DATAVALUE_FLD_BR_ID = "BR_ID";

        public const String DDL_DATATEXT_KEY_LBR_NAME = "LBR_NAME";
        public const String DDL_DATAVALUE_KEY_LBR_CODE = "LBR_CODE";

        public const String DDL_DATATEXT_KEY_ITEM_KEY = "ITEM_KEY";
        public const String DDL_DATAVALUE_KEY_ITEM_DESC = "ITEM_DESC";

        public const String DDL_DATATEXT_KEY_LT_DESC = "LT_DESC";
        public const String DDL_DATAVALUE_KEY_LT_ID = "LT_ID";

        public const String DDL_DATATEXT_KEY_PT_DESC = "PT_DESC";
        public const String DDL_DATAVALUE_KEY_PT_ID = "PT_ID";

        public const String DDL_DATATEXT_KEY_OC_DESC = "OC_DESC";
        public const String DDL_DATAVALUE_KEY_OC_ID = "OC_ID";

        public const String DDL_DATATEXT_KEY_UG_DESC = "UG_DESC";
        public const String DDL_DATAVALUE_KEY_UG_ID = "UG_ID";

        public const String DDL_DATATEXT_KEY_CC_DESC = "CC_DESC";
        public const String DDL_DATAVALUE_KEY_CC_FACT_PRCNT = "CC_FACT_PRCNT";

        #endregion

        #region DROPDOWN GROUPS
        public const String DdlGroup_DIRECTION = "DIRECTION";
        public const String DdlGroup_LOAN_TYPE = "LOAN_TYPE";
        public const String DdlGroup_DIS_PROGRAMS = "DIS_PROGRAMS";
        public const String DdlGroup_PROPERTY_TYPE = "PROPERTY_TYPE";
        public const String DdlGroup_NATURE_OF_INCOME = "NATURE_OF_INCOME";
        public const String DdlGroup_OCCUPANCY_STATUS = "OCCUPANCY_STATUS";
        public const String DdlGroup_CRE_CLASSIFICATION = "CRE_CLASSIFICATION";
        public const String DdlGroup_SOURCE_OF_LOAN_IDENTIFICATION = "SOURCE_OF_LOAN_IDENTIFICATION";
        #endregion

        #region DROPDOWN SUBGROUPS
        public const String DdlSubGroup_CRE_CLASSIFICATION_AHF = "AHF";
        public const String DdlSubGroup_CRE_CLASSIFICATION_SME_SLAP = "SME_SLAP";
        #endregion

        #region GRIDVIEW COLUMN NAMES

        public const String GV_COL_ROW_ID = "ROW_ID";
        public const String GV_COL_LEAD_ID = "LD_ID";
        public const String GV_COL_KYC_ID = "KYC_ID";
        public const String GV_COL_KYC_LEAD_ID = "KYC_LD_ID";
        public const String GV_COL_SEGMENT_ID = "SEGMENT_ID";
        public const String GV_COL_CUST_PROFILE_ID = "CUST_PROFILE_ID";
        public const String GV_COL_SUB_CATEGORY_ID = "SUB_CATEGORY_ID";

        public const String GV_COL_NAME = "NAME";
        public const String GV_COL_SEGMENT = "SEGMENT";
        public const String GV_COL_APPL_TYPE = "APPL_TYPE";
        public const String GV_COL_LOAN_TYPE = "LOAN_TYPE";
        public const String GV_COL_LOAN_TYPE_ID = "LOAN_TYPE_ID";
        public const String GV_COL_FINANCIER = "FINANCIER";
        public const String GV_COL_CIBIL_SCORE = "CIBIL_SCORE";
        public const String GV_COL_CUST_PROFILE = "CUST_PROFILE";
        public const String GV_COL_SUB_CATEGORY = "SUB_CATEGORY";
        public const String GV_SANCTION_AMOUNT = "SANCTION_AMOUNT";
        public const String GV_COL_INCOME_SOURCE = "INCOME_SOURCE";
        public const String GV_COL_OUTSTANDING_AMOUNT = "OUTSTANDING_AMOUNT";
        public const String GV_COL_NATURE_OF_BUSINESS = "NATURE_OF_BUSINESS";
        public const String GV_COL_NATURE_OF_BUSINESS_KEY = "NATURE_OF_BUSINESS_KEY";
        public const String GV_COL_SALES_BASED_ON_ASSESSMENT = "SALES_BASED_ON_ASSESSMENT";
        public const String GV_COL_SOURCE_OF_LOAN_IDENTIFICATION = "SOURCE_OF_LOAN_IDENTIFICATION";
        public const String GV_COL_CIBIL = "CIBIL";
        public const String GV_COL_EMI = "EMI";
        public const String GV_COL_TENOR = "TENOR";
        public const String GV_COL_EMI_AMOUNT = "EMI_AMOUNT";
        public const String GV_COL_BALANCE_NO_OF_EMI = "BALANCE_NO_OF_EMI";
        public const String GV_COL_OBLIGATION_AMOUNT = "OBLIGATION_AMOUNT";
        public const String GV_COL_INCOME = "INCOME";

        public const String GV_COL_ESFB_CAM_ID = "ESFB_CAM_ID";
        public const String GV_COL_ESFB_LN_AMT = "ESFB_LN_AMT";
        public const string GV_COL_ESFB_PR_NAME = "ESFB_PR_NAME";
        public const String GV_COL_ESFB_LN_AGRMNT = "ESFB_LN_AGRMNT";
        public const String GV_COL_ESFB_LN_OS_AMT = "ESFB_LN_OS_AMT";

        #endregion

        #region XML FILE PATHS

        public const String XmlFolderRootPath = "XML/";
        public const String XmlFile_CAM_Percentage_Master = "CAMPercentageMaster.xml";

        #endregion

        public const String GenericErrorPageUrl = "ErrorPage.aspx?parameter=";
        public const String LoginPage = "Default.aspx";

        public const String User = "User";

        public const String ReportSource_RTS = "RTS";
        public const String ReportSlource_HF_MISDB = "HF_MISDB";
        public const String CreditConditionVisible = "CreditConditionVisible";
        public const String DeviationVisible = "DeviationVisible";
        public const String HorizontalLine = "________________________________________________________________________________";
        public const String DropdownDefaultSelection = "--Select--";

        public const String FORMAT_DateTime_DDMMYYYY = "{0:dd MMM yyyy}";
    }
}