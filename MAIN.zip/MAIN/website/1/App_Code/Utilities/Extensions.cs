﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;

namespace Tracker
{
    /// <summary>
    /// Summary description for Extensions
    /// </summary>
    public static class Extensions
    {
        #region DATETIME EXTENSIONS
        public static string ToMonthName(this DateTime dateTime)
        {
            return CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(dateTime.Month);
        }

        public static string ToShortMonthName(this DateTime dateTime)
        {
            return CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(dateTime.Month);
        }

        public static string ToDayName(this DateTime dateTime)
        {
            return CultureInfo.CurrentCulture.DateTimeFormat.GetDayName(dateTime.DayOfWeek);
        }

        public static string ToShortDayName(this DateTime dateTime)
        {
            return CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedDayName(dateTime.DayOfWeek);
        }
        #endregion

        #region DOUBLE EXTENSIONS
        public static Decimal TruncateDecimal(Decimal value, Int32 precision)
        {
            Decimal step = 0;
            Decimal tmp = 0;
            Decimal result = 0;

            try
            {
                step = (Decimal)Math.Pow(10, precision);
                tmp = Math.Truncate(step * value);
                result = tmp / step;
            }
            catch(Exception ex)
            {
                ErrorLog.WriteError(ex);
            }

            return result;
        }

        public static Double TruncateDouble(Double value, Int32 precision)
        {
            Double step = 0;
            Double tmp = 0;
            Double result = 0.0;

            try
            {
                step = (Double)Math.Pow(10, precision);
                tmp = Math.Truncate(step * value);
                result = tmp / step;
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }

            return result;
        }
        #endregion
    }
}