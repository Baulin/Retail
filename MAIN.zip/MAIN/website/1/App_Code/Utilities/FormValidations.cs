﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using Tracker;

namespace Utilities.FormValidations
{
    /// <summary>
    /// Summary description for FormValidations
    /// </summary>
    public class FormValidations
    {
        #region DECLARED INCOME SUMMARY SHEET

        public static bool AllowStringWithSpaces(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[a-zA-Z ]+$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool AllowIntegers(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[0-9]{3,7}$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool AllowDecimals(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[0-9]{1,9}([.][0-9]{1,2})?$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /*Income should contain either of the following
         * Integer with 4-8 numbers and no decimal places
         * Decimal with 4-8 numbers and 2 decimal places
         */
        public static bool IsIncomeValid(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[0-9]{4,8}([.][0-9]{1,2})?$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool IsEMIValid(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[0-9]{3,8}([.][0-9]{1,2})?$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool IsBalanceNoOfEMIValid(String data)
        {
            bool _result = false;
            Int16 _balNoOfEmi = 0;

            try
            {
                Regex _regex = new Regex("^[0-9]{1,3}$");
                _result = _regex.IsMatch(data);

                if (_result)
                {
                    Int16.TryParse(data, out _balNoOfEmi);
                    if (_balNoOfEmi < 1 || _balNoOfEmi > 180) { _result = false; }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool IsCibilValid(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^([-])?[0-9]{1,3}$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool IsAmenitiesValid(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[0-9]{1,7}([.][0-9]{1,2})?$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool IsTenorValid(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[0-9]{1,3}$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool IsROIValid(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[0-9]{1,2}([.][0-9]{1,2})?$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool IsNoOfPropertiesValid(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[0-9]{1,3}$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool IsLandAreaValid(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[0-9]{1,5}([.][0-9]{1,2})?$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool IsLandAreaCostPerSqftValid(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[0-9]{1,6}([.][0-9]{1,2})?$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool IsPopulationValid(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[0-9]{1,9}$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        #endregion

        #region MERCHANT OD PRODUCT

        public static bool IsESFBLoanAgreementNumberValid(String data)
        {
            bool _result = false;

            try
            {
                Regex _regex = new Regex("^[a-zA-Z0-9 ]*$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public static bool IsUcicNumberValid(String data)
        {
            bool _result = true;

            try
            {
                Regex _regex = new Regex("^[a-zA-Z0-9]{1,20}$");
                _result = _regex.IsMatch(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        #endregion
    }
}