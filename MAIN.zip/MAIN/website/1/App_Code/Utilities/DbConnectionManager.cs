﻿using System;
using System.Configuration;

namespace Tracker
{
    /// <summary>
    /// Summary description for DbConnectionManager
    /// </summary>
    public class DbConnectionManager
    {
        public static String GetDbConnection()
        {
            String conStr = String.Empty;

            try
            {
                conStr = ConfigurationManager.ConnectionStrings[ConfigurationManager.AppSettings[AppConstants.ActiveDbConnection]].ConnectionString;
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                conStr = ConfigurationManager.ConnectionStrings[AppConstants.DefaultDbConnection].ConnectionString;
            }

            return conStr;
        }
    }
}