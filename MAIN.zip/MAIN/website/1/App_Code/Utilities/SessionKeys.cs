﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Utilities.SessionKeys
{
    /// <summary>
    /// Summary description for SessionKeys
    /// </summary>
    public static class SessionKeys
    {
        public const String ID = "ID";
        public const String AREA_ID = "AREA_ID";
        public const String AREANAME = "AREANAME";
        public const String BRANCHID = "BRANCHID";
        public const String UNITNAME = "UNITNAME";
        public const String TYPEID = "TYPEID";
        public const String EMPNAME = "EMPNAME";
        public const String EMP_ID = "EMP_ID";
        public const String LeadId = "LeadId";
        public const String Leadno = "Leadno";
        public const String PR_ID = "PR_ID";
        public const String MPS_ID = "MPS_ID";
        public const String EMP_ET_ID = "EMP_ET_ID";
        public const String ApplName = "Appname";
        public const String LoanAmt = "Loanamt";
        public const String lblLdAcNo = "lblldAcNo";
        public const String USER_ROLE_GROUP = "USER_ROLE_GROUP";
        public const String IsBranchUser = "IsBranchUser";
        public const String CUSTOMER_CATEGORY = "CUSTOMER_CATEGORY";
        public const String FACTORING_PERCENATGE = "FACTORING_PERCENATGE";
        public const String DIS_LEAD_KYC_DETAILS = "DIS_LEAD_KYC_DETAILS";
        public const String DATA_MANIPULATION_MODE = "DATA_MANIPULATION_MODE";
        public const String LP_PER = "LP_PER";
        public const String LTV_PERCENT = "LTV_PERCENT";
        public const String FILE_RECOM_BY = "FILE_RECOM_BY";
        public const String FILE_APPRV_BY = "FILE_APPRV_BY";
        public const String MERCHANT_OD_LOAN_CAP = "MERCHANT_OD_LOAN_CAP";
        public const String KYC_CUST_PROF_DETAILS = "KYC_CUST_PROF_DETAILS";
        public const String UCAM_AR_NAME = "UCAM_AR_NAME";
        public const String UCAM_BR_NAME = "UCAM_BR_NAME";
        public const String UCAM_PR_NAME = "UCAM_PR_NAME";

        #region GRID VIEW KEYS
        public const String GV_INCOME_DETAILS = "GV_INCOME_DETAILS";
        public const String GV_BUSINESS_DETAILS = "GV_BUSINESS_DETAILS";
        public const String GV_OBLIGATION_DETAILS = "GV_OBLIGATION_DETAILS";
        public const String GV_ESFB_LOAN_DETAILS = "GV_ESFB_LOAN_DETAILS";
        public const String GV_OTHER_LOAN_DETAILS = "GV_OTHER_LOAN_DETAILS";
        #endregion

        #region PAGE LOAD KEYS
        public const String IS_LEAD_LOADED_FOR_FIRST_TIME = "IS_LEAD_LOADED_FOR_FIRST_TIME";
        #endregion
    }
}