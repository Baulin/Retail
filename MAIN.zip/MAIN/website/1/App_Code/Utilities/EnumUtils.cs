﻿using System;
using System.ComponentModel;
using System.Reflection;

namespace Utilities.Enums
{
    public class EnumUtils
    {
        public static String GetEnumValue(Enum value)
        {
            String enumValue = null;

            if (value != null)
            {
                FieldInfo fi = value.GetType().GetField(value.ToString());
                DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attributes != null && attributes.Length > 0)
                {
                    enumValue = attributes[0].Description.ToString();
                }
                else
                {
                    enumValue = value.ToString();
                }
            }

            return enumValue;
        }
    }
}