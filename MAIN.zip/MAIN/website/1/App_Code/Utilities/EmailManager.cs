﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mail;
using Utilities;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Collections;
using Tracker;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Web.Mail;
using System.Net.Mail;
using System.Xml;
/// <summary>
/// Summary description for EmailManager
/// </summary>
namespace Utilities
{

    public static class EmailManager
    {
        public static ClsCommon clscomman = new ClsCommon();
        public static Boolean sendemail(string strTo, string strFrom, string strBcc, string strCc, string strSubject, string body, string strAttachmentPath, bool IsBodyHTML)
        {
            System.Net.Mail.MailMessage mm = null;
            SmtpClient smtp = null;
            string Host = ""; string UserName = ""; string Password = ""; int PortNo = 0; bool SSLEnable = false;
            try
            {
                strTo = strTo != "" && strTo != null ? strTo.Trim() : "rts-helpdesk@equitasbank.com";
                strCc = strCc != "" && strTo != null ? strCc.Trim() : "rts-helpdesk@equitasbank.com";
                strBcc = strBcc != "" && strTo != null ? strBcc.Trim() : "";

                Array arrToArray;
                Array arrBccArray;
                Array arrCcArray;

                char[] splitter = { ';' };

                arrToArray = strTo.Split(splitter);
                arrBccArray = strBcc.Split(splitter);
                arrCcArray = strCc.Split(splitter);


                mm = new System.Net.Mail.MailMessage();
               // mm.From = new MailAddress(strFrom);

                mm.Subject = strSubject;

                mm.Body = body;

                mm.IsBodyHtml = IsBodyHTML;

                if (strTo != "")
                {
                    foreach (string s in arrToArray)
                    {
                        if (s != "")
                        {
                            mm.To.Add(new MailAddress(s));
                        }

                    }
                }

                if (strBcc != "")
                {
                    foreach (string B in arrBccArray)
                    {
                        if (B != "")
                        {
                            mm.Bcc.Add(new MailAddress(B));
                        }
                    }
                }

                if (strCc != "")
                {
                    foreach (string C in arrCcArray)
                    {
                        if (C != "")
                        {
                            mm.CC.Add(new MailAddress(C));
                        }
                    }
                }
                if (strAttachmentPath != "")
                {
                    Attachment attachFile = new Attachment(strAttachmentPath);

                    mm.Attachments.Add(attachFile);

                }
                smtp = new SmtpClient();

               
                /*
                    smtp.Host = "smtp.equitas.in";

                    smtp.EnableSsl = false; //Depending on server SSL Settings

                    System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();

                    NetworkCred.UserName = "vf-telecalling@equitasbank.com";

                    NetworkCred.Password = "Tele@1234";

                    //NetworkCred.Domain = "vfportal.equitas.in";

                    smtp.UseDefaultCredentials = true;

                    smtp.Credentials = NetworkCred;

                    //smtp.Port = 25;//Specify your port No;
                    smtp.Send(mm);
                    mm = null;
                    smtp = null;
                    return true; 
                */
               smtp = new SmtpClient();
           
             XmlDocument doc = new XmlDocument();
                doc.Load(@"D:\Mail_Configs\Mail_Configs.xml");
                XmlNodeList nodeList = doc.SelectNodes("/MailConfigurations/MailDetails[@ID='1']");
                foreach (XmlNode node in nodeList)
                {
                    Host = node.SelectSingleNode("Host").InnerText;
                    UserName = node.SelectSingleNode("UserName").InnerText;
                    Password = node.SelectSingleNode("Password").InnerText;
                    PortNo = Convert.ToInt32(node.SelectSingleNode("PortNo").InnerText);
                    if (node.SelectSingleNode("SSLEnable").InnerText == "Y")
                        SSLEnable = true;
                    else
                        SSLEnable = false;
                    mm.From = new MailAddress(UserName,strFrom);
                }
                smtp.Host = Host;
                smtp.EnableSsl = SSLEnable;
                System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
                NetworkCred.UserName = UserName;
                NetworkCred.Password = Password;
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = PortNo;
                smtp.Send(mm);
                mm = null;
                smtp = null;
                mm.Dispose();
                smtp.Dispose();
                return true;
            }
            catch(Exception ex)
            {
                ErrorLog.WriteError(ex);
                mm.Dispose();
                smtp.Dispose();
                return false;
            }
        }

        public static Boolean sendemailRPA(string strTo, string strFrom, string strBcc, string strCc, string strSubject, string body, string strAttachmentPath, bool IsBodyHTML)
        {
            System.Net.Mail.MailMessage mm = null;
            SmtpClient smtp = null;
            string Host = ""; string UserName = ""; string Password = ""; int PortNo = 0; bool SSLEnable = false;
            try
            {
                strTo = strTo != "" && strTo != null ? strTo.Trim() : "rts-helpdesk@equitasbank.com";
                strCc = strCc != "" && strTo != null ? strCc.Trim() : "rts-helpdesk@equitasbank.com";
                strBcc = strBcc != "" && strTo != null ? strBcc.Trim() : "";

                Array arrToArray;
                Array arrBccArray;
                Array arrCcArray;

                char[] splitter = { ';' };

                arrToArray = strTo.Split(splitter);
                arrBccArray = strBcc.Split(splitter);
                arrCcArray = strCc.Split(splitter);


                mm = new System.Net.Mail.MailMessage();
                // mm.From = new MailAddress(strFrom);

                mm.Subject = strSubject;

                mm.Body = body;

                mm.IsBodyHtml = IsBodyHTML;

                if (strTo != "")
                {
                    foreach (string s in arrToArray)
                    {
                        if (s != "")
                        {
                            mm.To.Add(new MailAddress(s));
                        }

                    }
                }

                if (strBcc != "")
                {
                    foreach (string B in arrBccArray)
                    {
                        if (B != "")
                        {
                            mm.Bcc.Add(new MailAddress(B));
                        }
                    }
                }

                if (strCc != "")
                {
                    foreach (string C in arrCcArray)
                    {
                        if (C != "")
                        {
                            mm.CC.Add(new MailAddress(C));
                        }
                    }
                }
                if (strAttachmentPath != "")
                {
                    Attachment attachFile = new Attachment(strAttachmentPath);

                    mm.Attachments.Add(attachFile);

                }
                smtp = new SmtpClient();


                /*
                    smtp.Host = "smtp.equitas.in";

                    smtp.EnableSsl = false; //Depending on server SSL Settings

                    System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();

                    NetworkCred.UserName = "vf-telecalling@equitasbank.com";

                    NetworkCred.Password = "Tele@1234";

                    //NetworkCred.Domain = "vfportal.equitas.in";

                    smtp.UseDefaultCredentials = true;

                    smtp.Credentials = NetworkCred;

                    //smtp.Port = 25;//Specify your port No;
                    smtp.Send(mm);
                    mm = null;
                    smtp = null;
                    return true; 
                */
                smtp = new SmtpClient();

                XmlDocument doc = new XmlDocument();
                doc.Load(@"D:\Mail_Configs\Mail_Configs.xml");
                XmlNodeList nodeList = doc.SelectNodes("/MailConfigurations/MailDetails[@ID='2']");
                foreach (XmlNode node in nodeList)
                {
                    Host = node.SelectSingleNode("Host").InnerText;
                    UserName = node.SelectSingleNode("UserName").InnerText;
                    Password = node.SelectSingleNode("Password").InnerText;
                    PortNo = Convert.ToInt32(node.SelectSingleNode("PortNo").InnerText);
                    if (node.SelectSingleNode("SSLEnable").InnerText == "Y")
                        SSLEnable = true;
                    else
                        SSLEnable = false;
                    mm.From = new MailAddress(UserName, strFrom);
                }
                smtp.Host = Host;
                smtp.EnableSsl = SSLEnable;
                System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
                NetworkCred.UserName = UserName;
                NetworkCred.Password = Password;
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = PortNo;
                smtp.Send(mm);
                mm = null;
                smtp = null;
                mm.Dispose();
                smtp.Dispose();
                return true;
            }
            catch(Exception ex)
            {
                ErrorLog.WriteError(ex);
                mm.Dispose();
                smtp.Dispose();
                return false;
            }
        }
        public static Boolean sendemail_User(string strTo, string strFrom, string strBcc, string strCc, string strSubject, string body, string strAttachmentPath, bool IsBodyHTML)
        {
            System.Net.Mail.MailMessage mm = null;
            SmtpClient smtp = null;
            string Host = ""; string UserName = ""; string Password = ""; int PortNo = 0; bool SSLEnable = false;
            try
            {
                strTo = strTo != "" && strTo != null ? strTo.Trim() : "";
                strCc = strCc != "" && strTo != null ? strCc.Trim() : "";
                strBcc = strBcc != "" && strTo != null ? strBcc.Trim() : "";

                Array arrToArray;
                Array arrBccArray;
                Array arrCcArray;

                char[] splitter = { ';' };

                arrToArray = strTo.Split(splitter);
                arrBccArray = strBcc.Split(splitter);
                arrCcArray = strCc.Split(splitter);


                mm = new System.Net.Mail.MailMessage();
              //  mm.From = new MailAddress(strFrom);

                mm.Subject = strSubject;

                mm.Body = body;

                mm.IsBodyHtml = IsBodyHTML;

                if (strTo != "")
                {
                    foreach (string s in arrToArray)
                    {
                        if (s != "")
                        {
                            mm.To.Add(new MailAddress(s));
                        }

                    }
                }

                if (strBcc != "")
                {
                    foreach (string B in arrBccArray)
                    {
                        if (B != "")
                        {
                            mm.Bcc.Add(new MailAddress(B));
                        }
                    }
                }

                if (strCc != "")
                {
                    foreach (string C in arrCcArray)
                    {
                        if (C != "")
                        {
                            mm.CC.Add(new MailAddress(C));
                        }
                    }
                }
                if (strAttachmentPath != "")
                {
                    Attachment attachFile = new Attachment(strAttachmentPath);

                    mm.Attachments.Add(attachFile);

                }
                smtp = new SmtpClient();


                /*
                    smtp.Host = "smtp.equitas.in";

                    smtp.EnableSsl = false; //Depending on server SSL Settings

                    System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();

                    NetworkCred.UserName = "vf-telecalling@equitasbank.com";

                    NetworkCred.Password = "Tele@1234";

                    //NetworkCred.Domain = "vfportal.equitas.in";

                    smtp.UseDefaultCredentials = true;

                    smtp.Credentials = NetworkCred;

                    //smtp.Port = 25;//Specify your port No;
                    smtp.Send(mm);
                    mm = null;
                    smtp = null;
                    return true; 
                */
                smtp = new SmtpClient();

                XmlDocument doc = new XmlDocument();
                doc.Load(@"D:\Mail_Configs\Mail_Configs.xml");
                XmlNodeList nodeList = doc.SelectNodes("/MailConfigurations/MailDetails[@ID='1']");
                foreach (XmlNode node in nodeList)
                {
                    Host = node.SelectSingleNode("Host").InnerText;
                    UserName = node.SelectSingleNode("UserName").InnerText;
                    Password = node.SelectSingleNode("Password").InnerText;
                    PortNo = Convert.ToInt32(node.SelectSingleNode("PortNo").InnerText);
                    if (node.SelectSingleNode("SSLEnable").InnerText == "Y")
                        SSLEnable = true;
                    else
                        SSLEnable = false;

                    mm.From = new MailAddress(UserName,strFrom);
                }
                smtp.Host = Host;
                smtp.EnableSsl = SSLEnable;
                System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
                NetworkCred.UserName = UserName;
                NetworkCred.Password = Password;
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = PortNo;
                smtp.Send(mm);
                mm = null;
                smtp = null;
                mm.Dispose();
                smtp.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                mm.Dispose();
                smtp.Dispose();
                return false;
            }
        }
        //public static void SendForgotPasswordEmail(string userid)
        //{
        //    try
        //    {
        //        string emailaddress = clscomman.GetEmailAddressByUserCode(userid);
        //        string emailcontent = EmailContentManager.GetForgotPasswordByUserid(userid);
        //        //SendEmail(emailaddress, "New Password For Change Request Portal", emailcontent);
        //        sendemail(emailaddress, "CCMS <donotreply@equitasbank.com>", "", "", "New Password For Change Request Portal", emailcontent, "", true);
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorLog.WriteError(ex);
        //    }
        //}


    }
}