﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
namespace DataAccessLayer.Base
{
    /// <summary>
    /// Summary description for Base_DAL
    /// </summary>
    public class Base_DAL
    {
        String _connString = null;
        SqlConnection _sqlConn = null;

        public Base_DAL()
        {

        }

        //public SqlConnection GetConnection
        //{
        //    get
        //    {

        //    }
        //    set
        //    {

        //    }
        //}
    }
}