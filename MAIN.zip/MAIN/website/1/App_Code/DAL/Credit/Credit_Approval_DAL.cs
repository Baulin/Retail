﻿using DataObjects.CAM.Unsecured;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Tracker;
namespace DataAccessLayer.CreditApproval
{
    /// <summary>
    /// Summary description for Credit_Approval_DAL
    /// </summary>
    public class Credit_Approval_DAL
    { 
        public Credit_Approval_DAL()
        {
            _sqlConnStr = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        }

        public Int32 _maxTimeout = 1200000;
        public String _sqlConnStr = null;
        public SqlConnection _sqlConn = null;
        public SqlCommand _sqlCmd = null;
        public SqlDataAdapter _sqlDtAdptr = null;
        private string _sqlConStr;

        public DataSet GetUnsecuredCreditApprovalMemoReport(String _leadNo)
        {
            DataSet _resultDataSet = null;

            try
            {
                using (_sqlConn = new SqlConnection(_sqlConnStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_UNSECURED_CREDIT_APPROVAL_MEMO_REPORT, _sqlConn))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_LD_NO, _leadNo);

                        using (_sqlDtAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _resultDataSet = new DataSet();
                            _sqlDtAdptr.Fill(_resultDataSet);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }

            return _resultDataSet;
        }
    }
}