﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Tracker;
using DataObjects;
using Utilities.Enums;
using System.Collections.Generic;
using Resources;
/// <summary>
/// Summary description for Common
/// </summary>
namespace DataAccessLayer
{
    public class CommonDAL
    {
        #region COMMON VARIABLES
        public String _sqlConStr = null;
        public SqlConnection _sqlCon = null;
        public SqlCommand _sqlCmd = null;
        public SqlDataAdapter _sqlDatAdptr = null;
        #endregion

        public CommonDAL()
        {
            _sqlConStr = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        }

        #region GET METHODS

        public TechnicalInitiationDo GetPendingTechnicalInitiation(int leadId)
        {
            DataTable dtPendingTechInit = null;
            TechnicalInitiationDo technicalInitiationDo = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    _sqlCmd = new SqlCommand("RTS_SP_GET_PENDING_TECH_INIT", _sqlCon);
                    _sqlCmd.CommandType = CommandType.StoredProcedure;
                    _sqlCmd.Parameters.AddWithValue("@LeadId", leadId);
                    _sqlDatAdptr = new SqlDataAdapter(_sqlCmd);
                    _sqlDatAdptr.Fill(dtPendingTechInit);

                    if (dtPendingTechInit != null && dtPendingTechInit.Rows.Count > 0)
                    {
                        technicalInitiationDo = ConvertDataTableToTechnicalInitiationDo(dtPendingTechInit);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return technicalInitiationDo;
        }

        public TechnicalInitiationRuleDo GetTechnicalInitationRule(int leadId)
        {
            DataTable dtTechInitRule = null;
            TechnicalInitiationRuleDo technicalInitiationRuleDo = null;
            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    _sqlCmd = new SqlCommand("RTS_SP_GET_TECH_INIT_RULE", _sqlCon);
                    _sqlCmd.CommandType = CommandType.StoredProcedure;
                    _sqlCmd.Parameters.AddWithValue("@LeadId", leadId);
                    _sqlDatAdptr = new SqlDataAdapter(_sqlCmd);
                    _sqlDatAdptr.Fill(dtTechInitRule);

                    if (dtTechInitRule != null && dtTechInitRule.Rows.Count > 0)
                    {
                        technicalInitiationRuleDo = ConvertDataTableToTechnicalInitiationRuleDo(dtTechInitRule);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return technicalInitiationRuleDo;
        }

        public DataSet GetUploadFormatReport(UploadFormatReportDo uploadFormatReportDo)
        {
            DataSet resultSet = null;

            try
            {
                if (uploadFormatReportDo != null)
                {
                    if (string.Equals(uploadFormatReportDo.ReportType, Convert.ToString(UploadFormatReport.NEFT)))
                    {
                        if (uploadFormatReportDo.ProductType == Convert.ToString(ProductType.HF))
                        {
                            resultSet = GetNEFTUploadFormatReportForHF(uploadFormatReportDo);
                        }
                        else
                        {
                            resultSet = GetNEFTUploadFormatReportForVF(uploadFormatReportDo);
                        }
                    }
                    if (string.Equals(uploadFormatReportDo.ReportType, Convert.ToString(UploadFormatReport.RTGS)))
                    {
                        if (uploadFormatReportDo.ProductType == Convert.ToString(ProductType.HF))
                        {
                            resultSet = GetRTGSUploadFormatReportForHF(uploadFormatReportDo);
                        }
                        else
                        {
                            resultSet = GetRTGSUploadFormatReportForVF(uploadFormatReportDo);
                        }
                    }
                    if (string.Equals(uploadFormatReportDo.ReportType, Convert.ToString(UploadFormatReport.IFT)))
                    {
                        if (uploadFormatReportDo.ProductType == Convert.ToString(ProductType.HF))
                        {
                            resultSet = GetIFTUploadFormatReportForHF(uploadFormatReportDo);
                        }
                        else
                        {
                            resultSet = GetIFTUploadFormatReportForVF(uploadFormatReportDo);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultSet;
        }

        public DataTable GetMasterAreas(String _areaId)
        {
            DataTable _resultDataTable = null;

            try
            {
                _resultDataTable = new DataTable();
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_FINAL_CAM_AREA, _sqlCon))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_AREA_ID, _areaId);
                        using (_sqlDatAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _sqlDatAdptr.Fill(_resultDataTable);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataTable;
        }

        public DataTable GetMasterBranchesByArea(String _areaId)
        {
            DataTable _resultDataTable = null;

            try
            {
                _resultDataTable = new DataTable();
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_FINAL_CAM_BRANCH, _sqlCon))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_AREA_ID, _areaId);
                        using (_sqlDatAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _sqlDatAdptr.Fill(_resultDataTable);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataTable;
        }

        public DataSet GetLiabilityBranch()
        {
            DataSet _resultDataSet = null;

            try
            {
                _resultDataSet = new DataSet();
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_LIABILITY_BRANCHES, _sqlCon))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        using (_sqlDatAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _sqlDatAdptr.Fill(_resultDataSet);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataSet;
        }

        public DataSet GetFullLeadDetails(Int64 _leadId)
        {
            DataSet _resultDataSet = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_UNSECURED_LEAD_DETAILS, _sqlCon))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_LD_ID, _leadId);

                        using (_sqlDatAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _resultDataSet = new DataSet();
                            _sqlDatAdptr.Fill(_resultDataSet);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataSet;
        }

        public DataTable GetMasterLoanType()
        {
            DataSet _resultDataSet = null;
            DataTable _resultDataTable = null;

            try
            {
                _resultDataSet = new DataSet();
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_PR_FETCH_LOAN_TYPE, _sqlCon))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;

                        using (_sqlDatAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _sqlDatAdptr.Fill(_resultDataSet);
                            if (_resultDataSet != null && _resultDataSet.Tables.Count == 1)
                            {
                                _resultDataTable = _resultDataSet.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataTable;
        }

        public DataTable GetMasterPropertyType(String _ptId, String _ptType, String _ptDesc, String _product)
        {
            DataSet _resultDataSet = null;
            DataTable _resultDataTable = null;

            try
            {
                _resultDataSet = new DataSet();
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_MR_PROPERTY, _sqlCon))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_PT_ID, _ptId);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_PT_TYPE, _ptType);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_PT_DESC, _ptDesc);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_PRODUCT, _product);

                        using (_sqlDatAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _sqlDatAdptr.Fill(_resultDataSet);
                            if (_resultDataSet != null && _resultDataSet.Tables.Count == 1)
                            {
                                _resultDataTable = _resultDataSet.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataTable;
        }

        public DataTable GetMasterOccupancyStatus(String _ocId)
        {
            DataSet _resultDataSet = null;
            DataTable _resultDataTable = null;

            try
            {
                _resultDataSet = new DataSet();
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_MR_OCCUPANCY, _sqlCon))
                    {
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_OC_ID, _ocId);
                        using (_sqlDatAdptr = new SqlDataAdapter(this._sqlCmd))
                        {
                            _sqlDatAdptr.Fill(_resultDataSet);
                            if (_resultDataSet != null && _resultDataSet.Tables.Count == 1)
                            {
                                _resultDataTable = _resultDataSet.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataTable;
        }

        public DataTable GetMasterUsage(String _ugId)
        {
            DataSet _resultDataSet = null;
            DataTable _resultDataTable = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_MR_USAGE, _sqlCon))
                    {
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UG_ID, _ugId);
                        using (_sqlDatAdptr = new SqlDataAdapter(this._sqlCmd))
                        {
                            _resultDataSet = new DataSet();
                            _sqlDatAdptr.Fill(_resultDataSet);

                            if (_resultDataSet != null && _resultDataSet.Tables.Count == 1)
                            {
                                _resultDataTable = _resultDataSet.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataTable;
        }

        public DataTable GetMasterCustomerCategory()
        {
            DataSet _resultDataSet = null;
            DataTable _resultDataTable = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_MR_CUSTOMER_CATEGORY, _sqlCon))
                    {
                        using (_sqlDatAdptr = new SqlDataAdapter(this._sqlCmd))
                        {
                            _resultDataSet = new DataSet();
                            _sqlDatAdptr.Fill(_resultDataSet);

                            if (_resultDataSet != null && _resultDataSet.Tables.Count == 1)
                            {
                                _resultDataTable = _resultDataSet.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataTable;
        }

        public DataTable GetMasterProductLoanCap(String _prodId)
        {
            DataSet _resultDataSet = null;
            DataTable _resultDataTable = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_MR_PRODUCT_LOAN_CAP, _sqlCon))
                    {
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_PR_ID, _prodId);
                        using (_sqlDatAdptr = new SqlDataAdapter(this._sqlCmd))
                        {
                            _resultDataSet = new DataSet();
                            _sqlDatAdptr.Fill(_resultDataSet);

                            if (_resultDataSet != null && _resultDataSet.Tables.Count == 1)
                            {
                                _resultDataTable = _resultDataSet.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataTable;
        }

        #endregion

        #region UNO LEAD INTEGRATION
        public UnoLeadBucketDo GetUnoLeadBucket(UnoLeadBucketDo unoLeadBucketDo)
        {
            DataTable _resultTable = null;
            UnoLeadDo _unoLeadDo = null;
            UnoLeadBucketDo _unoLeadBucketDo = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    _resultTable = new DataTable();

                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_UNO_LEAD_BUCKET, _sqlCon))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, unoLeadBucketDo.UserId);
                        //sqlCmd.Parameters.AddWithValue(AppConstants.Param_PageNumber, unoLeadBucketDo.PageNumber);
                        //sqlCmd.Parameters.AddWithValue(AppConstants.Param_RecordsPerPage, unoLeadBucketDo.RecordsPerPage);
                        //sqlCmd.Parameters.AddWithValue(AppConstants.Param_SortBy, unoLeadBucketDo.SortBy);
                        //sqlCmd.Parameters.AddWithValue(AppConstants.Param_SortDirection, Convert.ToString(unoLeadBucketDo.SortDirection));

                        SqlParameter totNoOfRecords = new SqlParameter(AppConstants.Param_TotalNoOfRecords, SqlDbType.Int);
                        totNoOfRecords.Direction = ParameterDirection.Output;
                        _sqlCmd.Parameters.Add(totNoOfRecords);

                        using (_sqlDatAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _sqlDatAdptr.Fill(_resultTable);
                        }

                        if (_resultTable != null && _resultTable.Rows.Count > 0)
                        {
                            _unoLeadBucketDo = new UnoLeadBucketDo();
                            _unoLeadBucketDo.UnoLeadBucket = new List<UnoLeadDo>();
                            _unoLeadBucketDo.RecordCount = _resultTable.Rows.Count;

                            foreach (DataRow drUnoLead in _resultTable.Rows)
                            {
                                _unoLeadDo = ConvertDataTableToUnoLeadDo(drUnoLead);
                                _unoLeadBucketDo.UnoLeadBucket.Add(_unoLeadDo);
                            }
                        }
                        else
                        {
                            _unoLeadBucketDo = new UnoLeadBucketDo() { Status = false, Message = ErrorMessages.MSG_ERR_NO_RECORDS_AVAILABLE };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _unoLeadBucketDo;
        }

        public UnoLeadDo PickUnoLead(UnoLeadDo unoLeadDo, out bool isSuccess)
        {
            bool _result = false;
            isSuccess = false;
            DataTable _resultUnoLeadDoTable = null;
            UnoLeadDo _resultUnoLeadDo = null;

            try
            {
                if (unoLeadDo != null)
                {
                    _resultUnoLeadDoTable = new DataTable();
                    using (_sqlCon = new SqlConnection(_sqlConStr))
                    {
                        using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_PICK_UNO_LEAD, _sqlCon))
                        {
                            _sqlCmd.CommandType = CommandType.StoredProcedure;
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadBucketId, unoLeadDo.UN_LD_BUK_ID);
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadNo, unoLeadDo.UN_LD_NO);
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, unoLeadDo.UserId);

                            SqlParameter transResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                            transResult.Direction = ParameterDirection.Output;
                            _sqlCmd.Parameters.Add(transResult);

                            using (_sqlDatAdptr = new SqlDataAdapter(_sqlCmd))
                            {
                                _sqlDatAdptr.Fill(_resultUnoLeadDoTable);
                            }

                            _result = (bool)(transResult.Value);
                            if (_result)
                            {
                                if (_resultUnoLeadDoTable != null && _resultUnoLeadDoTable.Rows.Count > 0)
                                {
                                    DataRow drUnoLeadDo = _resultUnoLeadDoTable.Rows[0];
                                    _resultUnoLeadDo = ConvertDataTableToUnoLeadDo(drUnoLeadDo);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            isSuccess = _result;
            return _resultUnoLeadDo;
        }

        public UnoLeadDo UnlockUnoLead(UnoLeadDo unoLeadDo, out bool isSuccess)
        {
            bool _result = false;
            DataTable _resultUnoLeadDoTable = null;
            UnoLeadDo _resultUnoLeadDo = null;

            try
            {
                if (unoLeadDo != null)
                {
                    _resultUnoLeadDoTable = new DataTable();
                    using (_sqlCon = new SqlConnection(_sqlConStr))
                    {
                        using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_UNLOCK_UNO_LEAD, _sqlCon))
                        {
                            _sqlCmd.CommandType = CommandType.StoredProcedure;
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadBucketId, unoLeadDo.UN_LD_BUK_ID);
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadNo, unoLeadDo.UN_LD_NO);
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, unoLeadDo.UserId);

                            SqlParameter transResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                            transResult.Direction = ParameterDirection.Output;
                            _sqlCmd.Parameters.Add(transResult);

                            using (_sqlDatAdptr = new SqlDataAdapter(_sqlCmd))
                            {
                                _sqlDatAdptr.Fill(_resultUnoLeadDoTable);
                            }

                            _result = (bool)(transResult.Value);
                            if (_result)
                            {
                                if (_resultUnoLeadDoTable != null && _resultUnoLeadDoTable.Rows.Count > 0)
                                {
                                    DataRow drUnoLeadDo = _resultUnoLeadDoTable.Rows[0];
                                    _resultUnoLeadDo = ConvertDataTableToUnoLeadDo(drUnoLeadDo);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            isSuccess = _result;
            return _resultUnoLeadDo;
        }

        public UnoLeadDo UnlockUnoLeadAdmin(UnoLeadDo unoLeadDo, out bool isSuccess)
        {
            bool _result = false;
            DataTable _resultUnoLeadDoTable = null;
            UnoLeadDo _resultUnoLeadDo = null;

            try
            {
                if (unoLeadDo != null)
                {
                    _resultUnoLeadDoTable = new DataTable();
                    using (_sqlCon = new SqlConnection(_sqlConStr))
                    {
                        using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_ADMIN_UNLOCK_UNO_LEAD, _sqlCon))
                        {
                            _sqlCmd.CommandType = CommandType.StoredProcedure;
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadBucketId, unoLeadDo.UN_LD_BUK_ID);
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadNo, unoLeadDo.UN_LD_NO);
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, unoLeadDo.UserId);

                            SqlParameter transResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                            transResult.Direction = ParameterDirection.Output;
                            _sqlCmd.Parameters.Add(transResult);

                            using (_sqlDatAdptr = new SqlDataAdapter(_sqlCmd))
                            {
                                _sqlDatAdptr.Fill(_resultUnoLeadDoTable);
                            }

                            _result = (bool)(transResult.Value);
                            if (_result)
                            {
                                if (_resultUnoLeadDoTable != null && _resultUnoLeadDoTable.Rows.Count > 0)
                                {
                                    DataRow drUnoLeadDo = _resultUnoLeadDoTable.Rows[0];
                                    _resultUnoLeadDo = ConvertDataTableToUnoLeadDo(drUnoLeadDo);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            isSuccess = _result;
            return _resultUnoLeadDo;
        }

        public UnoLeadDo CompleteUnoLead(UnoLeadDo unoLeadDo, SqlConnection sqlConn, SqlTransaction sqlTransaction, out bool isSuccess)
        {
            bool _result = false;
            DataTable _resultUnoLeadDoTable = null;
            UnoLeadDo _resultUnoLeadDo = null;

            try
            {
                if (unoLeadDo != null)
                {
                    _resultUnoLeadDoTable = new DataTable();

                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_COMPLETE_UNO_LEAD, sqlConn, sqlTransaction))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadBucketId, unoLeadDo.UN_LD_BUK_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadNo, unoLeadDo.UN_LD_NO);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, unoLeadDo.UN_RTS_MBY);

                        SqlParameter transResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                        transResult.Direction = ParameterDirection.Output;
                        _sqlCmd.Parameters.Add(transResult);

                        using (_sqlDatAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _sqlDatAdptr.Fill(_resultUnoLeadDoTable);
                        }

                        _result = (bool)(transResult.Value);
                        if (_result)
                        {
                            if (_resultUnoLeadDoTable != null && _resultUnoLeadDoTable.Rows.Count > 0)
                            {
                                DataRow drUnoLeadDo = _resultUnoLeadDoTable.Rows[0];
                                _resultUnoLeadDo = ConvertDataTableToUnoLeadDo(drUnoLeadDo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            isSuccess = _result;
            return _resultUnoLeadDo;
        }

        public void CheckUnoLeadAvailableForPick(UnoLeadDo unoLeadDo, out bool result)
        {
            result = false;
            try
            {
                if (unoLeadDo != null)
                {
                    using (_sqlCon = new SqlConnection(_sqlConStr))
                    {
                        if (_sqlCon.State == ConnectionState.Broken || _sqlCon.State == ConnectionState.Closed) { _sqlCon.Open(); }
                        using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_CHK_LEAD_AVAILABLE_FOR_PICK, _sqlCon))
                        {
                            _sqlCmd.CommandType = CommandType.StoredProcedure;
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadBucketId, unoLeadDo.UN_LD_BUK_ID);
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadNo, unoLeadDo.UN_LD_NO);
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, unoLeadDo.UserId);

                            SqlParameter transResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                            transResult.Direction = ParameterDirection.Output;
                            _sqlCmd.Parameters.Add(transResult);
                            _sqlCmd.ExecuteNonQuery();

                            result = (bool)(transResult.Value);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void CheckUnoLeadLockedByUser(UnoLeadDo unoLeadDo, out bool result)
        {
            result = false;

            try
            {
                if (unoLeadDo != null)
                {
                    using (_sqlCon = new SqlConnection(_sqlConStr))
                    {
                        if (_sqlCon.State == ConnectionState.Broken || _sqlCon.State == ConnectionState.Closed) { _sqlCon.Open(); }
                        using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_CHK_LEAD_LOCKED_BY_USER, _sqlCon))
                        {
                            _sqlCmd.CommandType = CommandType.StoredProcedure;
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadBucketId, unoLeadDo.UN_LD_BUK_ID);
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadNo, unoLeadDo.UN_LD_NO);
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, unoLeadDo.UserId);

                            SqlParameter transResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                            transResult.Direction = ParameterDirection.Output;
                            _sqlCmd.Parameters.Add(transResult);
                            _sqlCmd.ExecuteNonQuery();

                            result = (bool)(transResult.Value);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void CheckUnoLeadDuplication(UnoLeadDo unoLeadDo, out bool result)
        {
            result = false;
            try
            {
                if (unoLeadDo != null)
                {
                    using (_sqlCon = new SqlConnection(_sqlConStr))
                    {
                        if (_sqlCon.State == ConnectionState.Broken || _sqlCon.State == ConnectionState.Closed) { _sqlCon.Open(); }
                        using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_CHK_LEAD_LOCKED_BY_USER, _sqlCon))
                        {
                            _sqlCmd.CommandType = CommandType.StoredProcedure;
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UnoLeadNo, unoLeadDo.UN_LD_NO);

                            SqlParameter transResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                            transResult.Direction = ParameterDirection.Output;
                            _sqlCmd.Parameters.Add(transResult);
                            _sqlCmd.ExecuteNonQuery();

                            result = (bool)(transResult.Value);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void ValidateUserIsAdmin(UnoLeadDo unoLeadDo, out bool result)
        {
            result = false;

            try
            {
                if (unoLeadDo != null)
                {
                    using (_sqlCon = new SqlConnection(_sqlConStr))
                    {
                        if (_sqlCon.State == ConnectionState.Broken || _sqlCon.State == ConnectionState.Closed) { _sqlCon.Open(); }
                        using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_VALIDATE_USER_IS_ADMIN, _sqlCon))
                        {
                            _sqlCmd.CommandType = CommandType.StoredProcedure;
                            _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, unoLeadDo.UserId);

                            SqlParameter transResult = new SqlParameter(AppConstants.Param_Result, SqlDbType.Bit);
                            transResult.Direction = ParameterDirection.Output;
                            _sqlCmd.Parameters.Add(transResult);
                            _sqlCmd.ExecuteNonQuery();

                            result = (bool)(transResult.Value);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region PRIVATE METHODS
        private DataSet GetNEFTUploadFormatReportForVF(UploadFormatReportDo uploadFormatReportDo)
        {
            DataSet resultSet = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    resultSet = new DataSet();
                    _sqlCmd = new SqlCommand("RTS_NEFT_UPLOAD_FORMAT_VF", _sqlCon);
                    _sqlCmd.CommandType = CommandType.StoredProcedure;
                    _sqlCmd.Parameters.AddWithValue("@PDT", uploadFormatReportDo.ProductType != null ? uploadFormatReportDo.ProductType : string.Empty);
                    _sqlCmd.Parameters.AddWithValue("@FRDT", Convert.ToDateTime(uploadFormatReportDo.StartDate).ToString("yyyy-MMM-dd"));
                    _sqlCmd.Parameters.AddWithValue("@TODT", Convert.ToDateTime(uploadFormatReportDo.EndDate).ToString("yyyy-MMM-dd"));
                    _sqlDatAdptr = new SqlDataAdapter(_sqlCmd);

                    _sqlDatAdptr.Fill(resultSet);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultSet;
        }
        private DataSet GetNEFTUploadFormatReportForHF(UploadFormatReportDo uploadFormatReportDo)
        {
            DataSet resultSet = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    resultSet = new DataSet();
                    _sqlCmd = new SqlCommand("RTS_NEFT_UPLOAD_FORMAT_HF", _sqlCon);
                    _sqlCmd.CommandType = CommandType.StoredProcedure;
                    _sqlCmd.Parameters.AddWithValue("@PDT", uploadFormatReportDo.ProductType != null ? uploadFormatReportDo.ProductType : string.Empty);
                    _sqlCmd.Parameters.AddWithValue("@FRDT", Convert.ToDateTime(uploadFormatReportDo.StartDate).ToString("yyyy-MMM-dd"));
                    _sqlCmd.Parameters.AddWithValue("@TODT", Convert.ToDateTime(uploadFormatReportDo.EndDate).ToString("yyyy-MMM-dd"));
                    _sqlDatAdptr = new SqlDataAdapter(_sqlCmd);

                    _sqlDatAdptr.Fill(resultSet);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultSet;
        }

        private DataSet GetRTGSUploadFormatReportForVF(UploadFormatReportDo uploadFormatReportDo)
        {
            DataSet resultSet = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    resultSet = new DataSet();
                    _sqlCmd = new SqlCommand("RTS_RTGS_UPLOAD_FORMAT_VF", _sqlCon);
                    _sqlCmd.CommandType = CommandType.StoredProcedure;
                    _sqlCmd.Parameters.AddWithValue("@PDT", uploadFormatReportDo.ProductType != null ? uploadFormatReportDo.ProductType : string.Empty);
                    _sqlCmd.Parameters.AddWithValue("@FRDT", Convert.ToDateTime(uploadFormatReportDo.StartDate).ToString("yyyy-MMM-dd"));
                    _sqlCmd.Parameters.AddWithValue("@TODT", Convert.ToDateTime(uploadFormatReportDo.EndDate).ToString("yyyy-MMM-dd"));
                    _sqlDatAdptr = new SqlDataAdapter(_sqlCmd);

                    _sqlDatAdptr.Fill(resultSet);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultSet;
        }

        private DataSet GetRTGSUploadFormatReportForHF(UploadFormatReportDo uploadFormatReportDo)
        {
            DataSet resultSet = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    resultSet = new DataSet();
                    _sqlCmd = new SqlCommand("RTS_RTGS_UPLOAD_FORMAT_HF", _sqlCon);
                    _sqlCmd.CommandType = CommandType.StoredProcedure;
                    _sqlCmd.Parameters.AddWithValue("@PDT", uploadFormatReportDo.ProductType != null ? uploadFormatReportDo.ProductType : string.Empty);
                    _sqlCmd.Parameters.AddWithValue("@FRDT", Convert.ToDateTime(uploadFormatReportDo.StartDate).ToString("yyyy-MMM-dd"));
                    _sqlCmd.Parameters.AddWithValue("@TODT", Convert.ToDateTime(uploadFormatReportDo.EndDate).ToString("yyyy-MMM-dd"));
                    _sqlDatAdptr = new SqlDataAdapter(_sqlCmd);

                    _sqlDatAdptr.Fill(resultSet);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultSet;
        }

        private DataSet GetIFTUploadFormatReportForVF(UploadFormatReportDo uploadFormatReportDo)
        {
            DataSet resultSet = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    resultSet = new DataSet();
                    _sqlCmd = new SqlCommand("RTS_IFT_UPLOAD_FORMAT_VF", _sqlCon);
                    _sqlCmd.CommandType = CommandType.StoredProcedure;
                    _sqlCmd.Parameters.AddWithValue("@PDT", uploadFormatReportDo.ProductType != null ? uploadFormatReportDo.ProductType : string.Empty);
                    _sqlCmd.Parameters.AddWithValue("@FRDT", Convert.ToDateTime(uploadFormatReportDo.StartDate).ToString("yyyy-MMM-dd"));
                    _sqlCmd.Parameters.AddWithValue("@TODT", Convert.ToDateTime(uploadFormatReportDo.EndDate).ToString("yyyy-MMM-dd"));
                    _sqlDatAdptr = new SqlDataAdapter(_sqlCmd);

                    _sqlDatAdptr.Fill(resultSet);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultSet;
        }

        private DataSet GetIFTUploadFormatReportForHF(UploadFormatReportDo uploadFormatReportDo)
        {
            DataSet resultSet = null;

            try
            {
                using (_sqlCon = new SqlConnection(_sqlConStr))
                {
                    resultSet = new DataSet();
                    _sqlCmd = new SqlCommand("RTS_IFT_UPLOAD_FORMAT_HF", _sqlCon);
                    _sqlCmd.CommandType = CommandType.StoredProcedure;
                    _sqlCmd.Parameters.AddWithValue("@PDT", uploadFormatReportDo.ProductType != null ? uploadFormatReportDo.ProductType : string.Empty);
                    _sqlCmd.Parameters.AddWithValue("@FRDT", Convert.ToDateTime(uploadFormatReportDo.StartDate).ToString("yyyy-MMM-dd"));
                    _sqlCmd.Parameters.AddWithValue("@TODT", Convert.ToDateTime(uploadFormatReportDo.EndDate).ToString("yyyy-MMM-dd"));
                    _sqlDatAdptr = new SqlDataAdapter(_sqlCmd);

                    _sqlDatAdptr.Fill(resultSet);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultSet;
        }

        private String GetStringFromColumn(object column)
        {
            if ((column == DBNull.Value || (column == null))) { return null; }
            return Convert.ToString(column);
        }

        private Int64 GetIntFromColumn(object column)
        {
            Int64 int1 = 0;
            if ((column == DBNull.Value) || (column == null)) { return 0; }
            else { int1 = Convert.ToInt64(column); };

            return int1;
        }

        #endregion

        #region CONVERSION METHODS

        private TechnicalInitiationDo ConvertDataTableToTechnicalInitiationDo(DataTable dtPendingTechInit)
        {
            DataRow drPendingTechInit = null;
            TechnicalInitiationDo techlInitDo = null;

            try
            {
                if (dtPendingTechInit != null && dtPendingTechInit.Rows.Count > 0)
                {
                    drPendingTechInit = dtPendingTechInit.Rows[0];

                    techlInitDo = new TechnicalInitiationDo
                    {
                        LeadId = drPendingTechInit["LeadId"] != null ? Convert.ToInt16(drPendingTechInit["LeadId"]) : 0,
                        VALStartDate = Convert.ToDateTime(drPendingTechInit["VAL_StartDate"]),
                        VALResolveDate = Convert.ToDateTime(drPendingTechInit["VAL_ResolveDate"]),
                        FIStartDate = Convert.ToDateTime(drPendingTechInit["FI_StartDate"]),
                        FIResolveDate = Convert.ToDateTime(drPendingTechInit["FI_ResolveDate"]),
                        RCUStartDate = Convert.ToDateTime(drPendingTechInit["RCU_StartDate"]),
                        RCUResolveDate = Convert.ToDateTime(drPendingTechInit["RCU_ResolveDate"]),
                    };
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return techlInitDo;
        }

        private TechnicalInitiationRuleDo ConvertDataTableToTechnicalInitiationRuleDo(DataTable dtTechInitRule)
        {
            DataRow drTechInitRule = null;
            TechnicalInitiationRuleDo techlInitRuleDo = null;

            try
            {
                if (dtTechInitRule != null && dtTechInitRule.Rows.Count > 0)
                {
                    drTechInitRule = dtTechInitRule.Rows[0];

                    techlInitRuleDo = new TechnicalInitiationRuleDo
                    {
                        RuleID = drTechInitRule["Rule_ID"] != null ? Convert.ToInt16(drTechInitRule["Rule_ID"]) : 0,
                        ProductID = drTechInitRule["Product_ID"] != null ? Convert.ToInt16(drTechInitRule["Product_ID"]) : 0,
                        IsRuleApplicable = Convert.ToBoolean(drTechInitRule["Rule_Applicable"]),
                        FIInitiation = drTechInitRule["FI_Initiation"] != null ? Convert.ToString(drTechInitRule["FI_Initiation"]) : null,
                        RCUInitiation = drTechInitRule["RCU_Initiation"] != null ? Convert.ToString(drTechInitRule["RCU_Initiation"]) : null,
                        VALInitiation = drTechInitRule["VAL_Initiation"] != null ? Convert.ToString(drTechInitRule["VAL_Initiation"]) : null
                    };
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return techlInitRuleDo;
        }

        private UnoLeadDo ConvertDataTableToUnoLeadDo(DataRow drUnoLeadDo)
        {
            UnoLeadDo _unoLeadDo = null;

            try
            {
                if (drUnoLeadDo != null && drUnoLeadDo.Table.Rows.Count > 0)
                {
                    _unoLeadDo = new UnoLeadDo();
                    _unoLeadDo.UN_LD_BUK_ID = GetIntFromColumn(drUnoLeadDo[AppConstants.Col_UN_LD_BUK_ID]);
                    _unoLeadDo.UN_LD_NO = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_LD_NO]);
                    _unoLeadDo.UN_APPL_NAME = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_APPL_NAME]);
                    _unoLeadDo.UN_MOB_NO = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_MOB_NO]);
                    _unoLeadDo.UN_BR_CODE = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_BR_CODE]);
                    _unoLeadDo.UN_BR_NAME = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_BR_NAME]);
                    _unoLeadDo.UN_PROD_CODE = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_PROD_CODE]);
                    _unoLeadDo.UN_PROD_DESC = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_PROD_DESC]);
                    _unoLeadDo.UN_RTS_PROC_STAT = GetIntFromColumn(drUnoLeadDo[AppConstants.Col_UN_RTS_PROC_STAT]);
                    _unoLeadDo.UN_RECPT_NO = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_RECPT_NO]);
                    _unoLeadDo.UN_RECPT_TYPE = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_RECPT_TYPE]);
                    _unoLeadDo.UN_RECPT_AMT = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_RECPT_AMT]);
                    _unoLeadDo.UN_CBY = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_CBY]);
                    _unoLeadDo.UN_CDATE = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_CDATE]);
                    _unoLeadDo.UN_RTS_MBY = GetIntFromColumn(drUnoLeadDo[AppConstants.Col_UN_RTS_MBY]);
                    _unoLeadDo.UN_RTS_MDATE = GetStringFromColumn(drUnoLeadDo[AppConstants.Col_UN_RTS_MDATE]);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _unoLeadDo;
        }

        #endregion
    }
}