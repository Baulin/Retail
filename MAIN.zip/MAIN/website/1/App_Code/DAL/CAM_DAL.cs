﻿using DataObjects.CAM.Unsecured;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Tracker;
namespace DataAccessLayer.CAM
{
    /// <summary>
    /// Summary description for CAM_DAL
    /// </summary>
    public class CAM_DAL
    {
        public CAM_DAL()
        {
            _sqlConnStr = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        }

        public Int32 _maxTimeout = 1200000;
        public String _sqlConnStr = null;
        public SqlConnection _sqlConn = null;
        public SqlCommand _sqlCmd = null;
        public SqlDataAdapter _sqlDtAdptr = null;
        private string _sqlConStr;

        #region GET METHODS

        public DataSet GetLeadsForUnsecuredBranchCAM(String branchName)
        {
            DataSet _resultDataSet = null;

            try
            {
                using (_sqlConn = new SqlConnection(_sqlConnStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_LEADS_FOR_UNSECURED_BR_CAM, _sqlConn))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.CommandTimeout = _maxTimeout;

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_BR_NAME, branchName);

                        using (_sqlDtAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _resultDataSet = new DataSet();
                            _sqlDtAdptr.Fill(_resultDataSet);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataSet;
        }

        public DataSet GetLeadsForUnsecuredCreditCAM(String _areaId, String _branchId)
        {
            DataSet _resultDataSet = null;

            try
            {
                using (_sqlConn = new SqlConnection(_sqlConnStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_LEADS_FOR_UNSECURED_CR_CAM, _sqlConn))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.CommandTimeout = _maxTimeout;

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_AR_ID, _areaId);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_BR_ID, _branchId);

                        using (_sqlDtAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _resultDataSet = new DataSet();
                            _sqlDtAdptr.Fill(_resultDataSet);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataSet;
        }

        public DataSet GetFullLeadDetailsForUnsecuredCreditCAM(Int64 _leadId)
        {
            DataSet _resultDataSet = null;

            try
            {
                using (_sqlConn = new SqlConnection(_sqlConnStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_CAM_DETAILS_FOR_UNSECURED_LEADS, _sqlConn))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_LD_ID, _leadId);

                        using (_sqlDtAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _resultDataSet = new DataSet();
                            _sqlDtAdptr.Fill(_resultDataSet);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataSet;
        }

        public DataSet GetUnsecuredCAMReport(String _leadNo, String _camType)
        {
            DataSet _resultDataSet = null;

            try
            {
                using (_sqlConn = new SqlConnection(_sqlConnStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_UNSECURED_CAM_REPORT, _sqlConn))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_LD_NO, _leadNo);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_CAM_TYPE, _camType);

                        using (_sqlDtAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _resultDataSet = new DataSet();
                            _sqlDtAdptr.Fill(_resultDataSet);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultDataSet;
        }

        public DataSet GetMasterDataForCAM(String _camType)
        {
            DataSet _resultSet = new DataSet();

            try
            {
                using (_sqlConn = new SqlConnection(_sqlConnStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_MERCHANT_OD_CAM_MASTER_DATA, _sqlConn))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_CAM_TYPE, _camType);
                        _sqlCmd.CommandTimeout = _maxTimeout;

                        using (_sqlDtAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _sqlDtAdptr.Fill(_resultSet);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultSet;
        }

        #endregion

        public DataTable SaveUnsecuredBranchCAMSummary(UnsecuredCamDO _unsecuredCamSmmryDO, DataTable dtDbEsfbLoanDetails, DataTable dtDbBusinessDetails, DataTable dtDbOtherLoanDetails, Int64 _userId, out bool _result)
        {
            _result = false;
            DataTable resultTable = new DataTable();

            try
            {
                using (_sqlConn = new SqlConnection(_sqlConnStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_UNSECURED_BRANCH_CAM, _sqlConn))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.CommandTimeout = _maxTimeout;

                        //LEAD DETAILS
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_LD_ID, _unsecuredCamSmmryDO.UCAM_LD_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_CAM_TYPE, _unsecuredCamSmmryDO.UCAM_CAM_TYPE);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_APPL_NAME, _unsecuredCamSmmryDO.UCAM_APPL_NAME);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_AR_ID, _unsecuredCamSmmryDO.UCAM_AR_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_AR_NAME, _unsecuredCamSmmryDO.UCAM_AR_NAME);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_BR_ID, _unsecuredCamSmmryDO.UCAM_BR_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_BR_NAME, _unsecuredCamSmmryDO.UCAM_BR_NAME);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_RES_ADDRESS, _unsecuredCamSmmryDO.UCAM_RES_ADDRESS);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_CONTACT_NO, _unsecuredCamSmmryDO.UCAM_CONTACT_NO);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_LIAB_BR_ID, _unsecuredCamSmmryDO.UCAM_LIAB_BR_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_LIAB_BR_NAME, _unsecuredCamSmmryDO.UCAM_LIAB_BR_NAME);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_CUST_REQ_AMT, _unsecuredCamSmmryDO.UCAM_CUST_REQ_AMT);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_CUST_CTGRY_ID, _unsecuredCamSmmryDO.UCAM_CUST_CTGRY_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_CUST_CTGRY, _unsecuredCamSmmryDO.UCAM_CUST_CTGRY);

                        //PASSING DUMMY VALUES FOR OLD ESFB LOAN DETAILS
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_EXST_LN_AGRMNT, _unsecuredCamSmmryDO.UCAM_EXST_LN_AGRMNT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_PR_NAME, _unsecuredCamSmmryDO.UCAM_PR_NAME);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_EXST_LN_AMT, _unsecuredCamSmmryDO.UCAM_EXST_LN_AMT);

                        //PROPERTY OWNERSHIP DETAILS
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_PRPTY_TYPE, _unsecuredCamSmmryDO.UCAM_PRPTY_TYPE);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_PRPTY_TYPE_ID, _unsecuredCamSmmryDO.UCAM_PRPTY_TYPE_ID);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OCC_STAT, _unsecuredCamSmmryDO.UCAM_OCC_STAT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OCC_STAT_ID, _unsecuredCamSmmryDO.UCAM_OCC_STAT_ID);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_USG, _unsecuredCamSmmryDO.UCAM_USG);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_USG_ID, _unsecuredCamSmmryDO.UCAM_USG_ID);

                        //OTHER DETAILS
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OTH_DT_MON_INC_FRM_BSNS, _unsecuredCamSmmryDO.UCAM_OTH_DT_MON_INC_FRM_BSNS);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OTH_DT_FACT_PRCNT, _unsecuredCamSmmryDO.UCAM_OTH_DT_FACT_PRCNT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OTH_DT_FIN_INC, _unsecuredCamSmmryDO.UCAM_OTH_DT_FIN_INC);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OTH_DT_POP_CITY, _unsecuredCamSmmryDO.UCAM_OTH_DT_POP_CITY);

                        //ELIGIBILITY DETAILS
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_TOT_SAL_ASSMT, _unsecuredCamSmmryDO.UCAM_TOT_SAL_ASSMT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_FACT_PRCNT, _unsecuredCamSmmryDO.UCAM_FACT_PRCNT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_FACT_DEV_PRCNT, _unsecuredCamSmmryDO.UCAM_FACT_DEV_PRCNT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_SAL_AFTR_FACTR, _unsecuredCamSmmryDO.UCAM_SAL_AFTR_FACTR);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_TOT_OUT_AMT, _unsecuredCamSmmryDO.UCAM_TOT_OUT_AMT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_ESFB_LMT_ELIG, _unsecuredCamSmmryDO.UCAM_ESFB_LMT_ELIG);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_FIN_ESFB_LMT_ELIG, _unsecuredCamSmmryDO.UCAM_FIN_ESFB_LMT_ELIG);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_STAT, _unsecuredCamSmmryDO.UCAM_STAT);

                        //ESFB LOAN DETAILS GRID
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_DT_UNSECURED_ESFB_LOAN_DETAILS, dtDbEsfbLoanDetails);

                        //BUSINESS DETAILS GRID
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_DT_UNSECURED_BUSINESS_DETAILS, dtDbBusinessDetails);

                        //OTHER LOAN DETAILS GRID
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_DT_UNSECURED_OTHER_LOAN_DETAILS, dtDbOtherLoanDetails);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, _userId);

                        using (_sqlDtAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _sqlDtAdptr.Fill(resultTable);
                            _result = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return resultTable;
        }

        public DataTable SaveUnsecuredCreditCAMSummary(UnsecuredCamDO _unsecuredCamSmmryDO, DataTable dtDbEsfbLoanDetails, DataTable dtDbBusinessDetails, DataTable dtDbOtherLoanDetails, FileCreditScoreDo fileCreditScoreDo, Int64 _userId, out bool _result)
        {
            _result = false;
            DataTable resultTable = new DataTable();

            try
            {
                using (_sqlConn = new SqlConnection(_sqlConnStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_INSERT_UNSECURED_CREDIT_CAM, _sqlConn))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.CommandTimeout = _maxTimeout;

                        //LEAD DETAILS
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_LD_ID, _unsecuredCamSmmryDO.UCAM_LD_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_CAM_TYPE, _unsecuredCamSmmryDO.UCAM_CAM_TYPE);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_APPL_NAME, _unsecuredCamSmmryDO.UCAM_APPL_NAME);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_AR_ID, _unsecuredCamSmmryDO.UCAM_AR_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_AR_NAME, _unsecuredCamSmmryDO.UCAM_AR_NAME);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_BR_ID, _unsecuredCamSmmryDO.UCAM_BR_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_BR_NAME, _unsecuredCamSmmryDO.UCAM_BR_NAME);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_RES_ADDRESS, _unsecuredCamSmmryDO.UCAM_RES_ADDRESS);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_CONTACT_NO, _unsecuredCamSmmryDO.UCAM_CONTACT_NO);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_LIAB_BR_ID, _unsecuredCamSmmryDO.UCAM_LIAB_BR_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_LIAB_BR_NAME, _unsecuredCamSmmryDO.UCAM_LIAB_BR_NAME);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_CUST_REQ_AMT, _unsecuredCamSmmryDO.UCAM_CUST_REQ_AMT);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_CUST_CTGRY_ID, _unsecuredCamSmmryDO.UCAM_CUST_CTGRY_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_CUST_CTGRY, _unsecuredCamSmmryDO.UCAM_CUST_CTGRY);

                        //PASSING DUMMY VALUES FOR OLD ESFB LOAN DETAILS
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_EXST_LN_AGRMNT, _unsecuredCamSmmryDO.UCAM_EXST_LN_AGRMNT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_PR_NAME, _unsecuredCamSmmryDO.UCAM_PR_NAME);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_EXST_LN_AMT, _unsecuredCamSmmryDO.UCAM_EXST_LN_AMT);

                        //PROPERTY OWNERSHIP DETAILS
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_PRPTY_TYPE, _unsecuredCamSmmryDO.UCAM_PRPTY_TYPE);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_PRPTY_TYPE_ID, _unsecuredCamSmmryDO.UCAM_PRPTY_TYPE_ID);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OCC_STAT, _unsecuredCamSmmryDO.UCAM_OCC_STAT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OCC_STAT_ID, _unsecuredCamSmmryDO.UCAM_OCC_STAT_ID);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_USG, _unsecuredCamSmmryDO.UCAM_USG);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_USG_ID, _unsecuredCamSmmryDO.UCAM_USG_ID);

                        //OTHER DETAILS
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OTH_DT_MON_INC_FRM_BSNS, _unsecuredCamSmmryDO.UCAM_OTH_DT_MON_INC_FRM_BSNS);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OTH_DT_FACT_PRCNT, _unsecuredCamSmmryDO.UCAM_OTH_DT_FACT_PRCNT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OTH_DT_FIN_INC, _unsecuredCamSmmryDO.UCAM_OTH_DT_FIN_INC);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_OTH_DT_POP_CITY, _unsecuredCamSmmryDO.UCAM_OTH_DT_POP_CITY);

                        //ELIGIBILITY DETAILS
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_TOT_SAL_ASSMT, _unsecuredCamSmmryDO.UCAM_TOT_SAL_ASSMT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_FACT_PRCNT, _unsecuredCamSmmryDO.UCAM_FACT_PRCNT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_FACT_DEV_PRCNT, _unsecuredCamSmmryDO.UCAM_FACT_DEV_PRCNT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_SAL_AFTR_FACTR, _unsecuredCamSmmryDO.UCAM_SAL_AFTR_FACTR);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_TOT_OUT_AMT, _unsecuredCamSmmryDO.UCAM_TOT_OUT_AMT);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_ESFB_LMT_ELIG, _unsecuredCamSmmryDO.UCAM_ESFB_LMT_ELIG);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_FIN_ESFB_LMT_ELIG, _unsecuredCamSmmryDO.UCAM_FIN_ESFB_LMT_ELIG);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_STAT, _unsecuredCamSmmryDO.UCAM_STAT);

                        //ESFB LOAN DETAILS GRID
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_DT_UNSECURED_ESFB_LOAN_DETAILS, dtDbEsfbLoanDetails);

                        //BUSINESS DETAILS GRID
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_DT_UNSECURED_BUSINESS_DETAILS, dtDbBusinessDetails);

                        //OTHER LOAN DETAILS GRID
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_DT_UNSECURED_OTHER_LOAN_DETAILS, dtDbOtherLoanDetails);

                        //FILE CREDIT SCORE
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_FCS_CAM_ID, fileCreditScoreDo.FCS_CAM_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_FCS_BSNS_VINT_ID, fileCreditScoreDo.FCS_BSNS_VINT_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_FCS_MON_INC_FRM_BSNS_ID, fileCreditScoreDo.FCS_MON_INC_FRM_BSNS_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_FCS_CR_HIST_ID, fileCreditScoreDo.FCS_CR_HIST_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_FCS_RES_PREM_OWND_ID, fileCreditScoreDo.FCS_RES_PREM_OWND_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_FCS_BSNS_PREM_OWND_ID, fileCreditScoreDo.FCS_BSNS_PREM_OWND_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_FCS_LIMT_PRCNT_TRNOVR_ID, fileCreditScoreDo.FCS_LIMT_PRCNT_TRNOVR_ID);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_FCS_SCORE, fileCreditScoreDo.FCS_SCORE);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_FCS_DEFN, fileCreditScoreDo.FCS_DEFN);

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, _userId);

                        // NEW FIELDS INCLUDED
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_UCIC_NO, _unsecuredCamSmmryDO.UCAM_UCIC_NO);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_UCAM_REMARKS, _unsecuredCamSmmryDO.UCAM_REMARKS);

                        using (_sqlDtAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _sqlDtAdptr.Fill(resultTable);
                            _result = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return resultTable;
        }
    }
}