﻿using DataObjects.CAM.Unsecured;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Tracker;

namespace DataAccessLayer.CustomerProfile
{
    /// <summary>
    /// Summary description for Cust_Prof_DAL
    /// </summary>
    public class Cust_Prof_DAL
    {
        public Cust_Prof_DAL()
        {
            _sqlConnStr = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        }

        public Int32 _maxTimeout = 1200000;
        public String _sqlConnStr = null;
        public SqlConnection _sqlConn = null;
        public SqlCommand _sqlCmd = null;
        public SqlDataAdapter _sqlDtAdptr = null;
        private string _sqlConStr;

        public DataTable GetMasterCustomerProfile(String _type, String _su_Prf_Id, String _su_Seg_Id)
        {
            DataSet _resultDataSet = null;
            DataTable _resultDataTable = null;

            try
            {
                using (_sqlConn = new SqlConnection(_sqlConnStr))
                {
                    using (_sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_CREDIT_CUSTOMER_PROFILE, _sqlConn))
                    {
                        _sqlCmd.CommandType = CommandType.StoredProcedure;
                        _sqlCmd.CommandTimeout = _maxTimeout;

                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_TYPE, _type);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_SU_PRF_ID, _su_Prf_Id);
                        _sqlCmd.Parameters.AddWithValue(AppConstants.Param_SU_SEG_ID, _su_Seg_Id);
                        
                        using (_sqlDtAdptr = new SqlDataAdapter(_sqlCmd))
                        {
                            _resultDataSet = new DataSet();
                            _sqlDtAdptr.Fill(_resultDataSet);

                            if(_resultDataSet != null && _resultDataSet.Tables.Count > 0)
                            {
                                _resultDataTable = _resultDataSet.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }

            return _resultDataTable;
        }
    }
}