﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Tracker;

namespace BusinessAccessLayer.Common
{
    /// <summary>
    /// Summary description for Common_BL
    /// </summary>
    public class Common_BL
    {
        public CommonDAL _common_DAL;
        public DataTable _dt = null;
        public DataSet _ds = null;

        public String _connStr = null;
        public SqlCommand _sqlCmd = null;
        public SqlConnection _sqlConn = null;
        public SqlDataAdapter _sqlDtAdptr = null;

        public SqlConnection GetSqlDBConnection
        {
            get
            {
                _connStr = ConfigurationManager.ConnectionStrings[AppConstants.DefaultDbConnection].ConnectionString;

                if (!String.IsNullOrEmpty(_connStr))
                {
                    _sqlConn = new SqlConnection(_connStr);
                }

                return _sqlConn;
            }
        }

        public Common_BL() { _common_DAL = new CommonDAL(); }

        public DataSet GetLiabilityBranch()
        {
            try
            {
                _ds = _common_DAL.GetLiabilityBranch();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return _ds;
        }

        public DataSet GetFullLeadDetails(Int64 _leadId)
        {
            try
            {
                _ds = _common_DAL.GetFullLeadDetails(_leadId);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return _ds;
        }

        public DataTable GetMasterLoanType()
        {
            try
            {
                _dt = _common_DAL.GetMasterLoanType();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return _dt;
        }

        public DataTable GetMasterPropertyType(String _ptId, String _ptType, String _ptDesc, String _product)
        {
            try
            {
                _dt = _common_DAL.GetMasterPropertyType(_ptId, _ptType, _ptDesc, _product);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return _dt;
        }

        public DataTable GetMasterOccupancyStatus(String _ocId)
        {
            try
            {
                _dt = _common_DAL.GetMasterOccupancyStatus(_ocId);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return _dt;
        }

        public DataTable GetMasterUsage(String _ugId)
        {
            try
            {
                _dt = _common_DAL.GetMasterUsage(_ugId);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return _dt;
        }

        public DataTable GetMasterAreas(String _areaId)
        {
            try
            {
                _dt = _common_DAL.GetMasterAreas(_areaId);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return _dt;
        }

        public DataTable GetMasterBranchesByArea(String _areaId)
        {
            try
            {
                _dt = _common_DAL.GetMasterBranchesByArea(_areaId);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return _dt;
        }

        public DataTable GetMasterCustomerCategory()
        {
            try
            {
                _dt = _common_DAL.GetMasterCustomerCategory();
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return _dt;
        }

        public DataTable GetMasterProductLoanCap(String _prodId)
        {
            try
            {
                _dt = _common_DAL.GetMasterProductLoanCap(_prodId);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
                throw ex;
            }

            return _dt;
        }
    }
}