﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccessLayer.CAM;
using System.Data;
using Tracker;
using DataObjects.CAM.Unsecured;
using DataAccessLayer.CreditApproval;

namespace BusinessAccessLayer.CreditApproval
{
    /// <summary>
    /// Summary description for Credit_Approval_BL
    /// </summary>
    public class Credit_Approval_BL
    {
        private DataTable _dt = null;
        private DataSet _ds = null;
        private Credit_Approval_DAL _creditApproval_Dal = null;

        public Credit_Approval_BL()
        {
            _creditApproval_Dal = new Credit_Approval_DAL();
        }

        public DataSet GetUnsecuredCreditApprovalMemoReport(String _leadNo)
        {
            try
            {
                _ds = _creditApproval_Dal.GetUnsecuredCreditApprovalMemoReport(_leadNo);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }

            return _ds;
        }
    }
}