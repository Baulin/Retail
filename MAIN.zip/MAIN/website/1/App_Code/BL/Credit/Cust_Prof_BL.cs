﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccessLayer.CAM;
using System.Data;
using Tracker;
using DataObjects.CAM.Unsecured;
using DataAccessLayer.CustomerProfile;

namespace BusinessAccessLayer.CustomerProfile
{

    /// <summary>
    /// Summary description for Cust_Prof_BL
    /// </summary>
    public class Cust_Prof_BL
    {
        private DataTable _dt = null;
        private DataSet _ds = null;
        private Cust_Prof_DAL _custProf_Dal = null;

        public Cust_Prof_BL()
        {
            _custProf_Dal = new Cust_Prof_DAL();
        }

        public DataTable GetMasterCustomerProfile(String _type, String _su_Prf_Id, String _su_Seg_Id)
        {
            try
            {
                _dt = _custProf_Dal.GetMasterCustomerProfile(_type, _su_Prf_Id, _su_Seg_Id);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteError(ex);
            }

            return _dt;
        }
    }
}