using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Globalization;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Net;
using System.Threading;

namespace Tracker
{
    public class ErrorLog
    {
        #region PUBLIC METHODS

        public static void WriteError(string errorMessage)
        {
            string errorMsg;
            string logDirPath;
            string logFilePath;
            StreamWriter writer;

            try
            {
                logDirPath = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings[AppConstants.LoggingPath]);
                logDirPath = logDirPath + "\\" + DateTime.Now.Year + "\\" + DateTime.Now.ToShortMonthName() + "\\";
                logFilePath = logDirPath + DateTime.Today.ToString("yyyy-MM-dd") + ".txt";

                if (!Directory.Exists(logDirPath)) { Directory.CreateDirectory(logDirPath); }

                if ((!File.Exists(Path.GetFullPath(logFilePath)))) { File.Create(Path.GetFullPath(logFilePath)).Close(); }

                using (writer = File.AppendText(Path.GetFullPath(logFilePath)))
                {
                    writer.WriteLine("\r\n" + "Log Entry : ");
                    writer.WriteLine("{0}", DateTime.Now.ToString(CultureInfo.InvariantCulture));
                    errorMsg = "Error Message:" + errorMessage + "\r\n" + "Error Timestamp : " + DateTime.Now;
                    writer.WriteLine(errorMsg);
                    writer.WriteLine(AppConstants.HorizontalLine);
                    writer.Flush();
                    writer.Close();
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.Message);
            }
        }

        public static void WriteError(Exception exception)
        {
            string logDirPath;
            string logFilePath;
            StreamWriter writer;

            try
            {
                logDirPath = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings[AppConstants.LoggingPath]);
                logDirPath = logDirPath + "\\" + DateTime.Now.Year + "\\" + DateTime.Now.ToShortMonthName() + "\\";
                logFilePath = logDirPath + DateTime.Today.ToString("yyyy-MM-dd") + ".txt";

                if (!Directory.Exists(logDirPath)) { Directory.CreateDirectory(logDirPath); }

                if ((!File.Exists(Path.GetFullPath(logFilePath)))) { File.Create(Path.GetFullPath(logFilePath)).Close(); }

                using (writer = File.AppendText(Path.GetFullPath(logFilePath))) { LogException(exception, logFilePath, writer); }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.Message);
            }
        }

        public static void writeLoginDetails(string Username, string IP)
        {
            string path = HttpContext.Current.Request.ApplicationPath;
            path = path + "/LoginDetails";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            path = path + "//" + "Login_" + DateTime.Now.ToString("dd_MMM_yy") + ".txt";
            if ((!File.Exists(HttpContext.Current.Server.MapPath(path))))
            {
                File.Create(HttpContext.Current.Server.MapPath(path)).Close();
            }
            StreamWriter w = File.AppendText(HttpContext.Current.Server.MapPath(path));
            w.WriteLine("\r\n" + "Log Time : " + DateTime.Now.ToString(CultureInfo.InvariantCulture));
            string err = "UserName:" + Username + "\r\nIP :  " + IP;
            w.WriteLine(err);
            w.WriteLine("________________________________________________________________________________");
            w.Flush();
            w.Close();
        }

        public static void ResponseWrite(string InputMessage, string Response, string Username)
        {
            try
            {
                string path = HttpContext.Current.Request.ApplicationPath;
                path = path + "//ResponseLog";
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                path = path + "//" + "ResponseCheckLog_" + DateTime.Today.ToString("yyyy-MM-dd") + ".txt";
                if ((!File.Exists(HttpContext.Current.Server.MapPath(path))))
                {
                    File.Create(HttpContext.Current.Server.MapPath(path)).Close();
                }
                StreamWriter w = File.AppendText(HttpContext.Current.Server.MapPath(path));
                w.WriteLine("\r\n" + "Log Entry : ");
                w.WriteLine("{0}", DateTime.Now.ToString(CultureInfo.InvariantCulture));

                string Res = "Input :" + InputMessage + "\r\n" + "Response Message:" + Response + "\r\n" + "Response Time :" + DateTime.Now.ToString();
                w.WriteLine(Res);

                string clintIP = Dns.GetHostByName(Dns.GetHostName()).AddressList[0].ToString();
                w.WriteLine("\r\n" + "IP Address : " + clintIP);
                w.WriteLine("\r\n" + "User Name : " + Username);
                w.WriteLine(AppConstants.HorizontalLine);
                w.Flush();
                w.Close();
            }
            catch (Exception ex)
            {
                //  WriteError(ex.Message);
            }
        }

        #endregion

        #region PRIVATE METHODS

        private static void LogException(Exception exception, string logFilePath, StreamWriter writer)
        {
            string errorMsg = string.Empty;

            if (writer != null && exception != null && !string.IsNullOrEmpty(logFilePath))
            {
                if (exception is ThreadAbortException)
                {

                }
                else
                {
                    try
                    {
                        writer.WriteLine("\r\n" + "Log Entry : ");
                        writer.WriteLine("{0}", DateTime.Now.ToString(CultureInfo.InvariantCulture));
                        errorMsg = "Error Message:" + exception.Message + "\r\n" + exception.StackTrace + "\r\n" + "Error Timestamp : " + DateTime.Now;
                        writer.WriteLine(errorMsg);
                        writer.WriteLine(AppConstants.HorizontalLine);

                        //log inner-exceptions recursively
                        if (exception.InnerException != null)
                        {
                            LogException(exception.InnerException, logFilePath, writer);
                        }
                        else
                        {
                            writer.Flush();
                            writer.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        writer.Flush();
                        writer.Close();
                        System.Diagnostics.Debug.Write(ex);
                    }
                }
            }
        }

        #endregion
    }
}
