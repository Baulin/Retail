﻿using DataAccessLayer;
using DataObjects;
using System;
using System.Data;

/// <summary>
/// Summary description for ReportsBL
/// </summary>
public class ReportsBL
{
    private CommonDAL _commonDAL;

    CommonDAL commonDAL
    {
        get
        {
            if (_commonDAL == null) { _commonDAL = new CommonDAL(); }
            return _commonDAL;
        }
    }
    public ReportsBL() { }

    public DataSet GetUploadFormatReport(UploadFormatReportDo uploadFormatReportDo)
    {
        DataSet resultSet = null;

        try
        {
            resultSet = commonDAL.GetUploadFormatReport(uploadFormatReportDo);
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return resultSet;
    }
}