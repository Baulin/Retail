using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Tracker;
using Utilities.Enums;
using DataObjects.Credit;

public class ClsCommon
{
    public ClsCommon()
    {
        // TODO: Add constructor logic here
    }
    public static SqlConnection GetConnection()
    {
        // string str = "Data Source=.;Initial Catalog = YourDatabaseName;uid =sa;pwd = YourPassword";

        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
        con.Open();
        return con;
    }
    public DataTable BulkCopyInsertChecking(DataTable mydt)
    {
        using (SqlConnection con1 = new SqlConnection(System.Configuration.ConfigurationManager.AppSettings["connection"]))
        {
            SqlCommand cmd = new SqlCommand();
            SqlCommand cmd1 = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd1.Connection = con1;
            cmd1.CommandType = CommandType.Text;
            con1.Open();
            cmd.CommandText = "delete from SomeTable";
            cmd.ExecuteNonQuery();
            con1.Close();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd1.Connection = con1;
            cmd1.CommandType = CommandType.Text;
            con1.Open();
            SqlBulkCopy S = new SqlBulkCopy(con1);
            S.BatchSize = 5000;
            S.BulkCopyTimeout = 500;
            S.DestinationTableName = "TempSomeTable";
            S.WriteToServer(mydt);
            S.Close();
            con1.Close();
        }
        return mydt;
    }

    public string Check_StringData(string strone, string strtwo, string strthree)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("sp_check_string", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@strone", strone);
                    command.Parameters.AddWithValue("@strtwo", strtwo);
                    command.Parameters.AddWithValue("@strthree", strthree);

                    SqlParameter paramResult = new SqlParameter("@Result", SqlDbType.VarChar, 1000);
                    paramResult.Direction = ParameterDirection.Output;
                    command.Parameters.Add(paramResult);

                    con.Open();
                    command.ExecuteNonQuery();
                    con.Close();

                    if ((paramResult.Value != null))
                    {
                        return (paramResult.Value).ToString().Trim();
                    }
                    else
                    {
                        return string.Empty;
                    }
                }
            }
        }
    }

    public DataSet GetDataset(string strone)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("sp_Dataset", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@strone", strone);
                    DataSet Dsdataset = new DataSet();
                    adapter.Fill(Dsdataset);
                    return Dsdataset;
                }
            }
        }
    }

    public DataTable GetDataTable(string strone)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("sp_DataTable", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@strone", strone);
                    DataTable Dtdatatable = new DataTable();
                    adapter.Fill(Dtdatatable);
                    return Dtdatatable;
                }
            }
        }
    }

    public DataSet Get_Mastercodewisedesc(string TableName, string TableCode, string Tabledesc, string ParameterCode)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("sp_GetmasterCodeWise", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TableName", TableName);
                    command.Parameters.AddWithValue("@TableCode", TableCode);
                    command.Parameters.AddWithValue("@Tabledesc", Tabledesc);
                    command.Parameters.AddWithValue("@ParameterCode", ParameterCode);
                    DataSet DsMasterList = new DataSet();
                    adapter.Fill(DsMasterList);
                    return DsMasterList;
                }
            }
        }
    }

    public DataSet GetMasterDetails(string TableName, string TableCode, string Tabledesc, string codeparameter, string descparameter)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_Getmasterdetails", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TableName", TableName);
                    command.Parameters.AddWithValue("@TableCode", TableCode);
                    command.Parameters.AddWithValue("@Tabledesc", Tabledesc);
                    command.Parameters.AddWithValue("@codeparameter", codeparameter);
                    command.Parameters.AddWithValue("@descparameter", descparameter);
                    DataSet DsMasterList = new DataSet();
                    adapter.Fill(DsMasterList);
                    return DsMasterList;
                }
            }
        }
    }

    public void Insert_Update_XMLdatatable(string Strone, SqlParameter strXMLData)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("Insert_Update_XMLdatatable", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Strone", Strone);
            command.Parameters.Add(strXMLData);
            con.Open();
            command.ExecuteNonQuery();
            con.Close();
        }
    }

    public void Delete_Sample(string strone, string strtwo, string strthree)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("Delete_sometable", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@strone", strone);
            command.Parameters.AddWithValue("@strtwo", strtwo);
            command.Parameters.AddWithValue("@strthree", strthree);
            con.Open();
            command.ExecuteNonQuery();
            con.Close();
        }
    }

    public DataSet GetMasterDetailsParameterone(string TableName, string TableCode, string Tabledesc, string ParamFieldOne,
    string ParamFieldTwo, string Parmone, string Parmtwo, string codeparameter, string descparameter)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_Getmasterdetailsparameterone", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TableName", TableName);
                    command.Parameters.AddWithValue("@TableCode", TableCode);
                    command.Parameters.AddWithValue("@Tabledesc", Tabledesc);
                    command.Parameters.AddWithValue("@codeparameter", codeparameter);
                    command.Parameters.AddWithValue("@descparameter", descparameter);
                    command.Parameters.AddWithValue("@ParamFieldOne", ParamFieldOne);
                    command.Parameters.AddWithValue("@ParamFieldTwo", ParamFieldTwo);
                    command.Parameters.AddWithValue("@Parmone", Parmone);
                    command.Parameters.AddWithValue("@Parmtwo", Parmtwo);
                    DataSet DsBranchList = new DataSet();
                    adapter.Fill(DsBranchList);
                    return DsBranchList;
                }
            }
        }
    }

    public DataSet GetMasterDetailsParameterThree(string TableName, string TableCode, string Tabledesc, string ParamFieldOne,
   string ParamFieldTwo, string Parmone, string Parmtwo, string codeparameter, string descparameter)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_GetmasterdetailsparameterThree", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TableName", TableName);
                    command.Parameters.AddWithValue("@TableCode", TableCode);
                    command.Parameters.AddWithValue("@Tabledesc", Tabledesc);
                    command.Parameters.AddWithValue("@codeparameter", codeparameter);
                    command.Parameters.AddWithValue("@descparameter", descparameter);
                    command.Parameters.AddWithValue("@ParamFieldOne", ParamFieldOne);
                    command.Parameters.AddWithValue("@ParamFieldTwo", ParamFieldTwo);
                    command.Parameters.AddWithValue("@Parmone", Parmone);
                    command.Parameters.AddWithValue("@Parmtwo", Parmtwo);
                    DataSet DsBranchList = new DataSet();
                    adapter.Fill(DsBranchList);
                    return DsBranchList;
                }
            }
        }
    }

    public DataSet GetMasterDetailsStoredProcedure(string TableName, string TableCode, string Tabledesc, string ParamFieldOne,
    string ParamFieldTwo, string Parmone, string StoredProcedurename, string codeparameter, string descparameter)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand(StoredProcedurename, con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TableName", TableName);
                    command.Parameters.AddWithValue("@TableCode", TableCode);
                    command.Parameters.AddWithValue("@Tabledesc", Tabledesc);
                    command.Parameters.AddWithValue("@codeparameter", codeparameter);
                    command.Parameters.AddWithValue("@descparameter", descparameter);
                    command.Parameters.AddWithValue("@ParamFieldOne", ParamFieldOne);
                    command.Parameters.AddWithValue("@ParamFieldTwo", ParamFieldTwo);
                    command.Parameters.AddWithValue("@Parmone", Parmone);
                    DataSet DsBranchList = new DataSet();
                    adapter.Fill(DsBranchList);
                    return DsBranchList;
                }
            }
        }
    }

    public DataSet HeaderTop()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_XGENheader", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    DataSet DsBranchList = new DataSet();
                    adapter.Fill(DsBranchList);
                    return DsBranchList;
                }
            }
        }
    }


    // Start Code in vijayan 26-feb-2015

    public DataSet GetArea()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_FETCH_MR_AREA", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    DataSet Dsdataset = new DataSet();
                    adapter.Fill(Dsdataset);
                    return Dsdataset;
                }
            }
        }
    }

    public DataSet GetAreaWiseBranch(string AR_NAME)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_FETCH_MR_Branch_By_Area", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@AR_NAME", AR_NAME);
                    DataSet Dsdataset = new DataSet();
                    adapter.Fill(Dsdataset);
                    return Dsdataset;
                }
            }
        }
    }

    public DataSet GetBranchwiseDisbursedLoan(string BranchName, string ProductName, string FromDate, string Todate)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_FETCH_GETBRANCHWISEDISBLOAN", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BranchName", BranchName);
                    command.Parameters.AddWithValue("@ProductName", ProductName);
                    command.Parameters.AddWithValue("@FromDate", FromDate);
                    command.Parameters.AddWithValue("@Todate", Todate);
                    DataSet Dsdataset = new DataSet();
                    adapter.Fill(Dsdataset);
                    return Dsdataset;
                }
            }
        }
    }

    public void RTS_SP_INSERT_RETAILAUDITFORM(string TYPEOFAUDIT, string AREANAME, string BRANCHNAME, string LD_LOAN_NO, string APPLICANT_NAME,
    string PHONENUMBER, string LOAN_DISB_DATE, double LOAN_AMOUNT, double TOTAL_LOANTENOR,
    double INTREST_RATE, double PROCESSING_FEE, double ADMIN_FEE, double CREDIT_LIFE_INS,
    double PROPERTY_INS, double TECH_PROCESSING_FEE, string APPLICANT_ADDRESS, double QUESTION_1,
    string QUESTION_2, string QUESTION_3, string QUESTION_4, double QUESTION_5, string QUESTION_6,
    string QUESTION_7, double QUESTION_8, double QUESTION_9, string QUESTION_10, string QUESTION_11,
    string QUESTION_12, string QUESTION_13, string QUESTION_14, string QUESTION_15,
    double QUESTION_16, string QUESTION_17, string QUESTION_18, double QUESTION_19,
    string QUESTION_20, string QUESTION_21, string QUESTION_22, double QUESTION_23,
    string QUESTION_24, string QUESTION_25, string QUESTION_26, string QUESTION_27,
    string QUESTION_28, string QUESTION_29, string QUESTION_30, string CREATEDBY, string CREATEDON,
    string UPDATEDBY, string UPDATEDON, string Remarks)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("RTS_SP_INSERT_RETAILAUDITFORM", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@TYPEOFAUDIT", TYPEOFAUDIT);
            command.Parameters.AddWithValue("@AREANAME", AREANAME);
            command.Parameters.AddWithValue("@BRANCHNAME", BRANCHNAME);
            command.Parameters.AddWithValue("@LD_LOAN_NO", LD_LOAN_NO);
            command.Parameters.AddWithValue("@APPLICANT_NAME", APPLICANT_NAME);
            command.Parameters.AddWithValue("@PHONENUMBER", PHONENUMBER);
            command.Parameters.AddWithValue("@LOAN_DISB_DATE", LOAN_DISB_DATE);
            command.Parameters.AddWithValue("@LOAN_AMOUNT", LOAN_AMOUNT);
            command.Parameters.AddWithValue("@TOTAL_LOANTENOR", TOTAL_LOANTENOR);
            command.Parameters.AddWithValue("@INTREST_RATE", INTREST_RATE);
            command.Parameters.AddWithValue("@PROCESSING_FEE", PROCESSING_FEE);
            command.Parameters.AddWithValue("@ADMIN_FEE", ADMIN_FEE);
            command.Parameters.AddWithValue("@CREDIT_LIFE_INS", CREDIT_LIFE_INS);
            command.Parameters.AddWithValue("@PROPERTY_INS", PROPERTY_INS);
            command.Parameters.AddWithValue("@TECH_PROCESSING_FEE", TECH_PROCESSING_FEE);
            command.Parameters.AddWithValue("@APPLICANT_ADDRESS", APPLICANT_ADDRESS);
            command.Parameters.AddWithValue("@QUESTION_1", QUESTION_1);
            command.Parameters.AddWithValue("@QUESTION_2", QUESTION_2);
            command.Parameters.AddWithValue("@QUESTION_3", QUESTION_3);
            command.Parameters.AddWithValue("@QUESTION_4", QUESTION_4);
            command.Parameters.AddWithValue("@QUESTION_5", QUESTION_5);
            command.Parameters.AddWithValue("@QUESTION_6", QUESTION_6);
            command.Parameters.AddWithValue("@QUESTION_7", QUESTION_7);
            command.Parameters.AddWithValue("@QUESTION_8", QUESTION_8);
            command.Parameters.AddWithValue("@QUESTION_9", QUESTION_9);
            command.Parameters.AddWithValue("@QUESTION_10", QUESTION_10);
            command.Parameters.AddWithValue("@QUESTION_11", QUESTION_11);
            command.Parameters.AddWithValue("@QUESTION_12", QUESTION_12);
            command.Parameters.AddWithValue("@QUESTION_13", QUESTION_13);
            command.Parameters.AddWithValue("@QUESTION_14", QUESTION_14);
            command.Parameters.AddWithValue("@QUESTION_15", QUESTION_15);
            command.Parameters.AddWithValue("@QUESTION_16", QUESTION_16);
            command.Parameters.AddWithValue("@QUESTION_17", QUESTION_17);
            command.Parameters.AddWithValue("@QUESTION_18", QUESTION_18);
            command.Parameters.AddWithValue("@QUESTION_19", QUESTION_19);
            command.Parameters.AddWithValue("@QUESTION_20", QUESTION_20);
            command.Parameters.AddWithValue("@QUESTION_21", QUESTION_21);
            command.Parameters.AddWithValue("@QUESTION_22", QUESTION_22);
            command.Parameters.AddWithValue("@QUESTION_23", QUESTION_23);
            command.Parameters.AddWithValue("@QUESTION_24", QUESTION_24);
            command.Parameters.AddWithValue("@QUESTION_25", QUESTION_25);
            command.Parameters.AddWithValue("@QUESTION_26", QUESTION_26);
            command.Parameters.AddWithValue("@QUESTION_27", QUESTION_27);
            command.Parameters.AddWithValue("@QUESTION_28", QUESTION_28);
            command.Parameters.AddWithValue("@QUESTION_29", QUESTION_29);
            command.Parameters.AddWithValue("@Remarks", Remarks);
            command.Parameters.AddWithValue("@QUESTION_30", QUESTION_30);
            command.Parameters.AddWithValue("@CREATEDBY", CREATEDBY);
            command.Parameters.AddWithValue("@CREATEDON", CREATEDON);
            command.Parameters.AddWithValue("@UPDATEDBY", UPDATEDBY);
            command.Parameters.AddWithValue("@UPDATEDON", UPDATEDON);
            con.Open();
            command.ExecuteNonQuery();
            con.Close();
        }
    }

    public DataTable RTS_SP_GETLOANNOWISE_RCA(string LOAN_NO)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_GETLOANNOWISE_RCA", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LOAN_NO", LOAN_NO);
                    DataTable Dtdatatable = new DataTable();
                    adapter.Fill(Dtdatatable);
                    return Dtdatatable;
                }
            }
        }
    }


    public DataTable RTS_SP_GETLOANNOWISE_RCA_RPT(string LOAN_NO)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_GETLOANNOWISE_RCA_RPT", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LOAN_NO", LOAN_NO);
                    DataTable Dtdatatable = new DataTable();
                    adapter.Fill(Dtdatatable);
                    return Dtdatatable;
                }
            }
        }
    }

    public DataSet GetBranchwiseRiskAuditLoan(string BranchName, string ProductName)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_FETCH_GETBRANCHWISERCALOAN", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BranchName", BranchName);
                    command.Parameters.AddWithValue("@ProductName", ProductName);
                    DataSet Dsdataset = new DataSet();
                    adapter.Fill(Dsdataset);
                    return Dsdataset;
                }
            }
        }
    }

    public DataSet RTS_SP_RetailCustomerAudit_Rpt(string FromDate, string ToDate, string strArea)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_RetailCustomerAudit_Rpt", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@fromDate", FromDate);
                    command.Parameters.AddWithValue("@todate", ToDate);
                    command.Parameters.AddWithValue("@AREANAME", strArea);
                    DataSet Dsdataset = new DataSet();
                    adapter.Fill(Dsdataset);
                    return Dsdataset;
                }
            }
        }
    }
    public DataSet RTS_SP_RetailCustomerAudit_Rpt1(string FromDate, string ToDate, string type, string access)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_RetailCustomerAudit_Rpt", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@fromDate", FromDate);
                    command.Parameters.AddWithValue("@todate", ToDate);
                    command.Parameters.AddWithValue("@Type", type);
                    command.Parameters.AddWithValue("@Unit", access);
                    DataSet Dsdataset = new DataSet();
                    adapter.Fill(Dsdataset);
                    return Dsdataset;
                }
            }
        }
    }

    public DataSet Get_RTS_SP_BIND_AREAS(int USERID)
    {
          using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_BIND_AREAS", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@EMPID", USERID);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet GetStateName()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SELECT ST_ID,ST_NAME from MR_STATE ORDER BY ST_NAME", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                   
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet GetAreaName()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SELECT AR_ID,AR_NAME from MR_AREA ORDER BY AR_NAME", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet GetDivision()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SELECT DV_ID,DV_NAME from MR_DIVISION ORDER BY DV_NAME", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {

                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet GetBranch()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SELECT BR_ID,BR_NAME from MR_BRANCH ORDER BY BR_NAME", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {

                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    //public string GetUserName(string USR_CODE)
    //{
    //    string username = "";
    //    using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
    //    {
    //        using (SqlCommand command = new SqlCommand("SP_CCMS1_USER_NAME", con))
    //        {
    //            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
    //            {
    //                command.CommandType = System.Data.CommandType.StoredProcedure;
    //                command.Parameters.AddWithValue("@USR_CODE", USR_CODE);
    //                DataTable Dtdataset = new DataTable();
    //                adapter.Fill(Dtdataset);
    //                if (Dtdataset.Rows.Count > 0)
    //                {
    //                    username = Dtdataset.Rows[0]["USR_NAME"].ToString();
    //                }
    //                // return Dtdataset;
    //                return username;
    //            }
    //        }
    //    }
    //}
    public string GetUsrBRAccess(int userid)
    {
        string userbraccess = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("select * from MR_USER where USR_EMP_ID="+userid, con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                   
                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        userbraccess = Dtdataset.Rows[0]["USR_BR_ACS"].ToString();
                    }
                    // return Dtdataset;
                    return userbraccess;
                }
            }
        }
    }
    public DataSet GetAllocatedBrachesByBranchId(string strUSRBRAccess)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SELECT BR_ID,BR_NAME from MR_BRANCH where BR_ID in (" + strUSRBRAccess + ") ORDER BY BR_NAME", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {                    
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_RTS_SP_CAMFULLDETAILS(string LD_NO,string CAM_TYPE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_CAMFULLDETAILS1", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_NO", LD_NO);
                    command.Parameters.AddWithValue("@CAMTYPE", CAM_TYPE);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_RTS_SP_CAMFULLDETAILS_TWL(string LD_NO, string CAM_TYPE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_CAMFULLDETAILS1", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_NO", LD_NO);
                    command.Parameters.AddWithValue("@CAMTYPE", CAM_TYPE);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_RTS_SP_Fetch_Credit_Memo_Detail_mailer(string LD_NO, string LEAD_TYPE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_Credit_Memo_Detail_mailer", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_ID", LD_NO);
                    command.Parameters.AddWithValue("@Lead_Type", "");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_RTS_SP_Fetch_Credit_Memo_Detail_mailer_TWL(string LD_NO, string LEAD_TYPE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_Credit_Memo_Detail_mailer", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_ID", LD_NO);
                    command.Parameters.AddWithValue("@Lead_Type", "");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public void UpdateCreditEmployeeApprovalAmount1(int emp_id, int emp_aprv_amount)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("Update MR_EMPLOYEE set EMP_APRV_AMT=" + emp_id + " where EMP_ID=" + emp_id, con))
            {
                //command.CommandText = "Update MR_EMPLOYEE set EMP_APRV_AMT=" + emp_id + " where EMP_ID=" +emp_id;
                command.ExecuteNonQuery();
            }
        }



    }
    public DataSet BindDataForDelegation()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_RTS1_FETCH_DELEGATION", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                   // command.Parameters.AddWithValue("@RO_ID", "");

                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public void UpdateCreditEmployeeApprovalAmount(int emp_id, decimal emp_aprv_amount)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("RTS_UPDATE_CREDIT_EMP_APRV_AMT", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@EMP_ID", emp_id);

            command.Parameters.AddWithValue("@EMP_APRV_AMT", emp_aprv_amount);
            //command.Parameters.AddWithValue("@CR_PATCH_FILE", CR_PATCH_FILE);

            try
            {
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw ex;
                // ErrorLog.WriteError(ex.Message.ToString());
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }

    public int GetEmpAprvAmountByEmpID(int emp_id)
    {
        int emp_aprv_amt = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("select EMP_ID,EMP_CODE,ISNULL(EMP_APRV_AMT,0)'EMP_APRV_AMT' from MR_EMPLOYEE where EMP_ID=" + emp_id, con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        emp_aprv_amt = Convert.ToInt32(Dtdataset.Rows[0]["EMP_APRV_AMT"]);
                    }
                    // return Dtdataset;
                    return emp_aprv_amt;
                }
            }
        }
    }
  /*  public DataSet GetCOCMAmountByEmpID(int emp_id, int emp_aprv_amt)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SELECT EMP_ID, EMP_CODE,EMP_NAME,ET_DESC,BR_NAME ,EMP_PHNO , EMP_EMAILID, EMP_STAT,CASE WHEN EMP_STAT='1' THEN 'WORKING' ELSE 'RESIGNED' END  AS 'EMPSTATUS', EMP_TYPE [TYPE],EMP_APRV_AMT [APPROVAL AMOUNT]  FROM MR_EMPLOYEE A JOIN MR_EMP_TYPE B ON A.EMP_ET_ID=B.ET_ID JOIN MR_BRANCH C ON A.EMP_BR_ID=C.BR_ID JOIN MR_USER D ON D.USR_EMP_ID= A.EMP_ID where EMP_ET_ID in  (6,7,28) and ISNULL(EMP_APRV_AMT,0) >" + emp_aprv_amt + " and EMP_ID<>" + emp_id + " and D.USR_STAT = 1 ORDER BY EMP_CODE ASC", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }*/
    public DataSet GetCOCMAmountByEmpID(int emp_id, decimal emp_aprv_amt)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_CREDIT_APRL_ASSIGN", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@EMP_ID", emp_id);
                    command.Parameters.AddWithValue("@EMP_APRV_AMT", emp_aprv_amt);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    public DataSet GetResidencyOwnership()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_RESIDENCY", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@RO_ID", "");
                  
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
   
    public DataSet GetResidencyOwnershipByID(int RO_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_RESIDENCY", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@RO_ID", RO_ID);

                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet GetIncomeTypeByID(int IT_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_INCOME_TYPE", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@IT_ID", IT_ID);

                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet GetCreditHistoryByID(int CH_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_CR_HISTORY", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CH_ID", CH_ID);

                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*BC Moducel Starts*/
    public void UpdateApplicationBCA_CODE(int BCA_ID, string BCA_CODE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("SP_RTS_UPDATE_BC_Application_Code", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@BCA_ID", BCA_ID);
            command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
            

            try
            {
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw ex;
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }
    public DataSet GetBCApplicationForm_Details(int BCA_ID, string BCA_CODE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_RTS1_FETCH_BC_APPLICATION_FORM", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                    command.Parameters.AddWithValue("@BCA_ID", BCA_ID);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet GetBCApplicationForm_Details_ByBCACODE(string BCA_CODE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_RTS1_FETCH_BC_APPLICATION_FORM", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                  //  command.Parameters.AddWithValue("@BCA_ID", BCA_ID);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_BC_Details_ByBCACODE(string BCA_CODE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_RTS1_FETCH_BC_APPLICATION_FORM_REPORT", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                    //  command.Parameters.AddWithValue("@BCA_ID", BCA_ID);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_BC_Form_Details_BY_Application_Status(string BCA_APP_STAT)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_RTS1_FETCH_BC_APPLICATION_FORM", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BCA_APP_STAT", BCA_APP_STAT);
                  
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_BCACODE_List()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_RTS1_FETCH_BC_CODE", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                   // command.Parameters.AddWithValue("@BCA_ID", BCA_ID);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_BCACODE_List_ByBranch(int branch_id)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_RTS1_FETCH_BC_CODE", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@BCA_BR_ID", branch_id);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_BCACODE_List_ByBranch(int branch_id, string EMP_TYPE_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SP_RTS1_FETCH_BC_CODE", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@BCA_BR_ID", branch_id);
                    command.Parameters.AddWithValue("@EMP_TYPE_ID", EMP_TYPE_ID);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Bind_BC_APP_RECEIVE_WKIT_BY_BRANCH(int branchid)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Bind_BC_APP_RECEIVE_WKIT_BY_BRANCH", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                    command.Parameters.AddWithValue("@BCA_BR_ID", branchid);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    
         public DataSet Bind_Business_Connector(string branchid)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Bind_Business_Connector", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                    command.Parameters.AddWithValue("@BR_NAME", branchid);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
         public DataSet GetBCVFCodeHFCode(int BC_ID)
         {
             using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
             {
                 using (SqlCommand command = new SqlCommand("RTS_SP_Bind_BC_VFCode_HFCode", con))
                 {
                     using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                     {
                         command.CommandType = System.Data.CommandType.StoredProcedure;
                         //command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                         command.Parameters.AddWithValue("@BCA_ID", BC_ID);
                         DataSet Dtdataset = new DataSet();
                         adapter.Fill(Dtdataset);
                         return Dtdataset;
                     }
                 }

             }
         }
    public DataSet Bind_ShortlistedBC_Application(string BCA_APP_STAT,int BR_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("SELECT BCA_ID,BCA_CODE,BCA_CDATE,BCA_NAME,BCA_DOB,BCA_MBL_NO from LSD_BC_APPLICATION where BCA_VDATE is not null and BCA_BR_ID=" + BR_ID + " and BCA_SDATE is null and  BCA_APP_STAT = '" + BCA_APP_STAT + "' ORDER BY BCA_CODE", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
   
         public void UpdateBCApp_Received_By_OPs(int BCA_ID, string BCA_RBY)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("SP_RTS_UPDATE_BC_APP_RECEIVED_BY_OPs", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@BCA_ID", BCA_ID);
            command.Parameters.AddWithValue("@BCA_RBY", BCA_RBY);
            command.Parameters.AddWithValue("@BCA_RDATE", DateTime.Now);

            try
            {
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw ex;
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }
         public void UpdateBCApp_VF_HF_CODE_By_Ops(int BCA_ID, string BCA_MBY,string BCA_VF_CODE,string BCA_HF_CODE)
         {
             using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
             {
                 SqlCommand command = new SqlCommand("SP_RTS_UPDATE_BC_APP_VF_HF_CODE", con);
                 SqlDataAdapter adapter = new SqlDataAdapter(command);
                 command.CommandType = System.Data.CommandType.StoredProcedure;
                 command.Parameters.AddWithValue("@BCA_ID", BCA_ID);
                 command.Parameters.AddWithValue("@BCA_MBY", BCA_MBY);
                 command.Parameters.AddWithValue("@BCA_MDATE", DateTime.Now);
                 command.Parameters.AddWithValue("@BCA_VF_CODE",BCA_VF_CODE);
                 command.Parameters.AddWithValue("@BCA_HF_CODE", BCA_HF_CODE);

                 try
                 {
                     con.Open();
                     command.ExecuteNonQuery();
                 }
                 catch (Exception ex)
                 {
                     //throw ex;
                     ErrorLog.WriteError(ex);
                 }
                 finally
                 {
                     con.Close();
                     con.Dispose();
                 }
             }
         }
         public void UpdateBCApp_Receive_WKIT_By_Branch(int BCA_ID, string BCA_WK_RBY)
         {
             using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
             {
                 SqlCommand command = new SqlCommand("SP_RTS_UPDATE_BC_APP_RECEIVE_WKIT", con);
                 SqlDataAdapter adapter = new SqlDataAdapter(command);
                 command.CommandType = System.Data.CommandType.StoredProcedure;
                 command.Parameters.AddWithValue("@BCA_ID", BCA_ID);
                 command.Parameters.AddWithValue("@BCA_WK_RBY", BCA_WK_RBY);
                 command.Parameters.AddWithValue("@BCA_WK_RDATE", DateTime.Now);
               

                 try
                 {
                     con.Open();
                     command.ExecuteNonQuery();
                 }
                 catch (Exception ex)
                 {
                     //throw ex;
                     ErrorLog.WriteError(ex);
                 }
                 finally
                 {
                     con.Close();
                     con.Dispose();
                 }
             }
         }
         public void UpdateBCApp_SEND_WKIT_By_Ops(int BCA_ID, string BCA_WK_SBY, string BCA_WK_CR_ID, string BCA_WK_POD)
         {
             using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
             {
                 SqlCommand command = new SqlCommand("SP_RTS_UPDATE_BC_APP_SEND_WKIT", con);
                 SqlDataAdapter adapter = new SqlDataAdapter(command);
                 command.CommandType = System.Data.CommandType.StoredProcedure;
                 command.Parameters.AddWithValue("@BCA_ID", BCA_ID);
                 command.Parameters.AddWithValue("@BCA_WK_SBY", BCA_WK_SBY);
                 command.Parameters.AddWithValue("@BCA_WK_SDATE", DateTime.Now);
                 command.Parameters.AddWithValue("@BCA_WK_CR_ID", BCA_WK_CR_ID);
                 command.Parameters.AddWithValue("@BCA_WK_POD", BCA_WK_POD);

                 try
                 {
                     con.Open();
                     command.ExecuteNonQuery();
                 }
                 catch (Exception ex)
                 {
                     //throw ex;
                     ErrorLog.WriteError(ex);
                 }
                 finally
                 {
                     con.Close();
                     con.Dispose();
                 }
             }
         }
    public void UpdateBCApp_Send_TO_OPs(int BCA_ID, string BCA_SBY)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("SP_RTS_UPDATE_BC_APP_SEND_TO_OPs", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@BCA_ID", BCA_ID);
            command.Parameters.AddWithValue("@BCA_SBY", BCA_SBY);
            command.Parameters.AddWithValue("@BCA_SDATE", DateTime.Now);


            try
            {
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw ex;
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }
    public DataSet GetUnResolvedQueries_Count(int BCA_ID,string RSD_BY)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Bind_BC_Query_Count", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                    command.Parameters.AddWithValue("@QRY_BCA_ID", BCA_ID);
                    command.Parameters.AddWithValue("@QRY_RSD_BY", RSD_BY);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*BC Module End*/
    /*NACH Details Start*/
    public DataSet BindBankDetails()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_NACH_BIND_BANK", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;


                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet BindBankDetails_ByBankCode(string BK_CODE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_NACH_BIND_BANK", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BankCode", BK_CODE);
                    command.Parameters.AddWithValue("@TYPE", "FORBRANCH");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet GetBankInformation_ByBankID(int BK_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_NACH_BIND_BANK", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BankID", BK_ID);
                    command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet GetNACHDETAILS_By_NAID(int NA_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_NACH_DETAILS", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@NA_ID", NA_ID);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*NACH END*/

    /*Credit Query Starts*/
    public DataSet Bind_MRQuery()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Bind_MR_Query", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    // command.Parameters.AddWithValue("@NA_ID", NA_ID);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Bind_MRQuery_By_PRSID(int PRS_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Bind_MR_Query", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@QRY_PRS_ID", PRS_ID);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Bind_MRQuery_By_PRSTYPE(string PRS_TYPE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Bind_MR_Query", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@View", PRS_TYPE);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Bind_KYCApplicats(int LD_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_KYC_DETAILS_FETCH", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@KYC_LD_ID", LD_ID);
                    //command.Parameters.AddWithValue("@TYPE", "KYC_CREDIT");
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Bind_Queries_By_QY_QUERY(string QY_Query)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand("select QY_QUERY,QY_SQUERY from MR_QUERY  where QY_QUERY='" + QY_Query + "' ORDER BY QY_QUERY,QY_SQUERY ASC", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Bind_Courier_Details()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_CourierListas", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*Credit Query Ends*/

    public DataSet Bind_Manufacturer_Details(string mfc_code, string mfc_model)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_MANUFACTURER_DETAILS", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                    command.Parameters.AddWithValue("@MFC_CODE", mfc_code);
                    command.Parameters.AddWithValue("@MFC_MODEL", mfc_model);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    /* GOld Audit Starts */

    public void RTS_SP_INSERT_GOLD_AUDIT(int BR_ID, DateTime auditdate, int gba_mga_id, string status, string remarks, int gba_cby)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("RTS_SP_GOLD_AUDITING", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@PTYPE", "INSERTQUSGOLD");
            command.Parameters.AddWithValue("@GBA_BR_ID", BR_ID);
            command.Parameters.AddWithValue("@GBA_AUDIT_DATE", auditdate);
            command.Parameters.AddWithValue("@GBA_MGA_ID", gba_mga_id);
            command.Parameters.AddWithValue("@GBA_STATUS", status);
            command.Parameters.AddWithValue("@GBA_RMKS", remarks);
            command.Parameters.AddWithValue("@GBA_CBY", gba_cby);
            command.Parameters.AddWithValue("@GBA_CDATE", DateTime.Now);

            con.Open();
            command.ExecuteNonQuery();
            con.Close();
        }
    }

    public int Get_MR_GoldAudit_QUS_ID(int mga_type)
    {
        int mga_id = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_GOLD_AUDITING", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PTYPE", "GETMASTERQUS");
                    command.Parameters.AddWithValue("@MGA_TYPE", mga_type);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        mga_id = Convert.ToInt32(Dtdataset.Rows[0]["MGA_ID"]);
                    }
                    // return Dtdataset;
                    return mga_id;
                }
            }
        }
    }
    /*Gold Audit Ends */
    /*Starts General LAP LTV% Calculation*/
    public int Get_MR_Property_Percentage(string PR_DESC)
    {
        int pr_percent = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PT_DESC", PR_DESC);
                    command.Parameters.AddWithValue("@PT_TYPE", "");

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        pr_percent = Convert.ToInt32(Dtdataset.Rows[0]["PT_PERCENT"]);
                    }
                    // return Dtdataset;
                    return pr_percent;
                }
            }
        }
    }

    /*Ends General LAP LTV% Calculation*/
    /*Start MODTD*/
    public DataSet Bind_MODTD_Details(string LD_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MODTD_Details", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@MD_LD_ID", LD_ID);

                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public string GetCourierName(string CR_ID)
    {
        string couriername = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_Courier_Details", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CR_ID", CR_ID);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        couriername = Dtdataset.Rows[0]["CR_NAME"].ToString();
                    }
                    // return Dtdataset;
                    return couriername;
                }
            }
        }
    }
    /*End MODTD*/

    /*Property Owner MOTD Starts*/
    public string GetPropertyOwner(string propOwner_id)
    {
        string couriername = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {

            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_KYC_Applicant", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@KYC_ID", propOwner_id);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {

                        foreach (DataRow dr in Dtdataset.Rows)
                        {
                            string tmp_str = "";
                            tmp_str = dr["KYC_NAME"].ToString();
                            couriername += tmp_str + "&nbsp;&nbsp;<br/>";

                        }
                        // couriername = tmp_str;
                    }
                    // return Dtdataset;
                    return couriername;
                }
            }
        }
    }
    public string GetPropOwner(string propOwner_id)
    {
        string couriername = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_KYC_Applicant", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@KYC_ID", propOwner_id);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        couriername = Dtdataset.Rows[0]["KYC_NAME"].ToString();
                    }
                    // return Dtdataset;
                    return couriername;
                }
            }
        }
    }

    public string GetLeadId(string LD_NO)
    {
        string userbraccess = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("select * from LSD_LEAD where LD_NO='" + LD_NO + "'", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        userbraccess = Dtdataset.Rows[0]["LD_ID"].ToString();
                    }
                    // return Dtdataset;
                    return userbraccess;
                }
            }
        }
    }

    /*End Property Owner*/

    /**dsa APPLICATION**/
    /*BC Moducel Starts*/
    public void UpdateApplicationDSA_CODE(int DSA_ID, string DSA_CODE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("RTS_SP_DSA_APPLICATION", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@PTYPE", "UPDATE_CODE");
            command.Parameters.AddWithValue("@DSA_ID", DSA_ID);
            command.Parameters.AddWithValue("@DSA_CODE", DSA_CODE);
            try
            {
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw ex;
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }
    public void UpdateDSApp_POD_By_BR(int DSA_ID, string DSA_SBY, string POD_NO)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("RTS_SP_DSA_APPLICATION", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@PTYPE", "UPT_SEND_DOC_BR");
            command.Parameters.AddWithValue("@DSA_ID", DSA_ID);
            command.Parameters.AddWithValue("@DSA_DOC_SBY", DSA_SBY);
            command.Parameters.AddWithValue("@DSA_DOC_POD", POD_NO);



            try
            {
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw ex;
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }
    public void UpdateDSAApp_Received_By_OPs(int DSA_ID, string DSA_RBY)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("RTS_SP_DSA_APPLICATION", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@PTYPE", "UPT_REV_DOC_HO");
            command.Parameters.AddWithValue("@DSA_ID", DSA_ID);
            command.Parameters.AddWithValue("@DSA_DOC_RBY", DSA_RBY);
            try
            {
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw ex;
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }
    public DataSet GetDSAVFCodeHFCode(int DSA_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_DSA_APPLICATION", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                    command.Parameters.AddWithValue("@PTYPE", "BIND_CODE");
                    command.Parameters.AddWithValue("@DSA_ID", DSA_ID);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public void UpdateDSApp_VF_HF_CODE_By_Ops(int DSA_ID, string DSA_MBY, string DSA_VF_CODE, string DSA_HF_CODE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("RTS_SP_DSA_APPLICATION", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@DSA_ID", DSA_ID);
            command.Parameters.AddWithValue("@PTYPE", "UDPATE_CODE");
            command.Parameters.AddWithValue("@DSA_CODE_UBY", DSA_MBY);
            command.Parameters.AddWithValue("@DSA_VF_CODE", DSA_VF_CODE);
            command.Parameters.AddWithValue("@DSA_HF_CODE", DSA_HF_CODE);

            try
            {
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw ex;
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }
    public void UpdateDSApp_SEND_WKIT_By_Ops(int BCA_ID, string BCA_WK_SBY, string BCA_WK_CR_ID, string BCA_WK_POD)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("RTS_SP_DSA_APPLICATION", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@DSA_ID", BCA_ID);
            command.Parameters.AddWithValue("@PTYPE", "HO_WKIT_SEND_UPT");
            command.Parameters.AddWithValue("@DSA_WK_SBY", BCA_WK_SBY);
            // command.Parameters.AddWithValue("@DSA_WK_SDATE", DateTime.Now);
            command.Parameters.AddWithValue("@DSA_WK_CR_ID", BCA_WK_CR_ID);
            command.Parameters.AddWithValue("@DSA_WK_POD", BCA_WK_POD);

            try
            {
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw ex;
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }
    public void UpdateDSApp_Receive_WKIT_By_Branch(int BCA_ID, string BCA_WK_RBY)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("RTS_SP_DSA_APPLICATION", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@DSA_ID", BCA_ID);
            command.Parameters.AddWithValue("@PTYPE", "BR_WKIT_REV_UPT");
            command.Parameters.AddWithValue("@DSA_WK_RBY", BCA_WK_RBY);
            // command.Parameters.AddWithValue("@DSA_WK_RDATE", DateTime.Now);


            try
            {
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw ex;
                ErrorLog.WriteError(ex);
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }
    public DataSet Get_DSA_UnResolvedQueries_Count(int DSA_ID, string RSD_BY)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Bind_BC_Query_Count", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                    command.Parameters.AddWithValue("@DSA_ID", DSA_ID);
                    command.Parameters.AddWithValue("@QRY_RSD_BY", RSD_BY);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_DSA_Infomation(int dsa_id)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_DSA_APPLICATION", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PTYPE", "GET_DSA_DATA");

                    command.Parameters.AddWithValue("@DSAID", dsa_id);
                    //command.Parameters.AddWithValue("@AR_ID", ddlArea.SelectedItem.Text != "--Select--" ? ddlArea.SelectedValue.ToString() : "");
                    // command.Parameters.AddWithValue("@BR_ID", ddlBranch.SelectedItem.Text != "--Select--" ? ddlBranch.SelectedValue.ToString() : "");   
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public string Get_DSA_Branch_ID(string DSA_CODE)
    {
        string br_id = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_DSA_APPLICATION", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PTYPE", "GET_DSA_DATA");
                    command.Parameters.AddWithValue("@DSA_CODE", DSA_CODE);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        br_id = Dtdataset.Rows[0]["DSA_BR_ID"].ToString();
                    }
                    // return Dtdataset;
                    return br_id;
                }
            }
        }
    }

    /**eND DSA APPLICATION**/

    #region bind DSA
    public DataSet Bind_DSA(string branchid)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Bind_DSA", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@BCA_CODE", BCA_CODE);
                    command.Parameters.AddWithValue("@BR_NAME", branchid);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    #endregion
    /**eND DSA APPLICATION**/


    public string GetFormerActivity(string LD_ID)
    {
        string couriername = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_Former_Activity", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_ID", LD_ID);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        couriername = Dtdataset.Rows[0]["FA_DESC"].ToString();
                    }
                    // return Dtdataset;
                    return couriername;
                }
            }
        }
    }
    public string GetFormerActivity(string LD_ID, string cam_type)
    {
        string couriername = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_Former_Activity", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_ID", LD_ID);
                    command.Parameters.AddWithValue("@CAM_TYPE", cam_type);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        couriername = Dtdataset.Rows[0]["FA_DESC"].ToString();
                    }
                    // return Dtdataset;
                    return couriername;
                }
            }
        }
    }
    public string GetSubFormerActivity(string LD_ID)
    {
        string couriername = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_Sub_Former_Activity", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_ID", LD_ID);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        couriername = Dtdataset.Rows[0]["FAS_DESC"].ToString();
                    }
                    // return Dtdataset;
                    return couriername;
                }
            }
        }
    }
    public string GetSubFormerActivity(string LD_ID, string cam_type)
    {
        string couriername = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_Sub_Former_Activity", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_ID", LD_ID);
                    command.Parameters.AddWithValue("@CAM_TYPE", cam_type);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        couriername = Dtdataset.Rows[0]["FAS_DESC"].ToString();
                    }
                    // return Dtdataset;
                    return couriername;
                }
            }
        }
    }
    public DataSet Bind_FIRCU()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Bind_MR_FIRCU", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@EMPID", USERID);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    /*Starts RFD Hold Remarks */
    public DataSet Get_Full_RFD_Hold_Remarks_Details(string ld_no)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_RFD_HOLD", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TYPE", "GET_DATA");
                    command.Parameters.AddWithValue("@TRANS", "COUNT_RES");
                    command.Parameters.AddWithValue("@LEADNO", ld_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_Full_RFD_Hold_Remarks_Details_By_SancNo(string sanc_no)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_RFD_HOLD", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TYPE", "GET_DATA");
                    command.Parameters.AddWithValue("@TRANS", "COUNT_RES");
                    command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_RFD_Hold_Status_For_Lead(string LD_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_RFD_HOLD", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TYPE", "CHECK_UPT");
                    command.Parameters.AddWithValue("@LD_ID", LD_ID);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_RFD_Hold_Status_For_Lead_By_Lead_No(string ld_no)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_RFD_HOLD", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TYPE", "CHECK_UPT");
                    command.Parameters.AddWithValue("@LEADNO", ld_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Get_RFD_Hold_Status_For_Lead_By_Sanc_No(string sanc_no)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_RFD_HOLD", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@TYPE", "CHECK_UPT");
                    command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    /*END RFD Hold Remarks */
    public int GetRPACount(int LD_ID)
    {
        int cnt = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_GET_RPA_DETAILS", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LEADID", LD_ID);
                    // command.Parameters.AddWithValue("@CAM_TYPE", cam_type);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    // if (Dtdataset.Rows.Count > 0)
                    //{
                    //cnt = Dtdataset.Rows[0]["FAS_DESC"].ToString();
                    //}
                    // return Dtdataset;
                    cnt = Dtdataset.Rows.Count;
                    return cnt;
                }
            }
        }
    }
    /*BALA CHANGES STARTS MANUAL APPROVAL*/
    public DataSet Bind_Manual_employees()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_BIND_MR_MANUAL_EMP", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    public void UpdateCreditManualApproval(int ld_id, int man_aprv_id)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            SqlCommand command = new SqlCommand("RTS_UPDATE_CREDIT_MANUAL_APROVAL", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@LD_ID", ld_id);
            command.Parameters.AddWithValue("@MAN_ID", man_aprv_id);
            try
            {
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw ex;
                 ErrorLog.WriteError(ex.Message.ToString());
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }
    }
    /*MANUAL APPROVAL ENDS*/

    /*NEw PRODUCTs Starts*/
    public DataSet Get_Product_Category()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_PROD_CATEGORY", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@TYPE", "CHECK_UPT");
                    //command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    public DataSet Bind_Main_Product(int pc_id)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_MAIN_PROD", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@MPC_PC_ID", pc_id);
                    //command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    public DataSet Bind_MR_Product_By_Main_Product(int mpc_id)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_PRODUCT", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PR_MPC_ID", mpc_id);
                    //command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Bind_MR_Prod_Scheme_By_Product(int pr_id)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_PROD_SCHEME", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@MPS_PR_ID", pr_id);
                    //command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*New Products Ends*/
    public string GetDepositBankDetails(string PR_ID)
    {
        string bkDetails = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_Deposit_Bank_Details", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BK_PR_ID", PR_ID);
                    // command.Parameters.AddWithValue("@CAM_TYPE", cam_type);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        bkDetails = Dtdataset.Rows[0]["DT_BK_NAME"].ToString();
                    }
                    // return Dtdataset;
                    return bkDetails;
                }
            }
        }
    }

    /*Starts Top Up*/
    public string GetTopUpSchemes()
    {
        string strTopUp = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_BIND_TOPUP_SCHEMES", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    // command.Parameters.AddWithValue("@BK_PR_ID", PR_ID);
                    // command.Parameters.AddWithValue("@CAM_TYPE", cam_type);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        strTopUp = Dtdataset.Rows[0]["MPS_ID"].ToString();
                    }
                    // return Dtdataset;
                    return strTopUp;
                }
            }
        }
    }

    public DataSet Bind_TopUp_Lead_Details(string ld_no)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_BIND_BT_LEAD_DETAILS", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_NO", ld_no);
                    command.Parameters.AddWithValue("@PTYPE", "BIND_DETAILS");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Bind_TopUp_Lead_Details(string ld_no, int scheme_id)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_BIND_BT_LEAD_DETAILS", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.CommandTimeout = 0;
                    command.Parameters.AddWithValue("@LD_NO", ld_no);
                    command.Parameters.AddWithValue("@SCHEME_ID", scheme_id);
                    command.Parameters.AddWithValue("@PTYPE", "BIND_DETAILS");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    /*End Top Up*/
    public int Is_Bank_By_IFSC(string ifsc_code)
    {
        int cnt = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_BIND_BANK", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BK_IFSC", ifsc_code);
                    // command.Parameters.AddWithValue("@CAM_TYPE", cam_type);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    // if (Dtdataset.Rows.Count > 0)
                    //{
                    //cnt = Dtdataset.Rows[0]["FAS_DESC"].ToString();
                    //}
                    // return Dtdataset;
                    cnt = Dtdataset.Rows.Count;
                    return cnt;
                }
            }
        }
    }

    /*HF Related Query changes Starts*/
    public DataSet Bind_MDisbQuery_By_PRSTYPE(string PRS_TYPE)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Bind_MR_Disb_Query", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@View", PRS_TYPE);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    public DataSet Bind_MR_DISBQueries_By_QY_QUERY(string QY_Query)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_FETCH_MDISB_QUERY", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@QY_QUERY", QY_Query);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*HF Related Query Changes End*/

    /* GHF Changes Starts*/
    public int GetLoanType_Percentage(int lp_id)
    {
        int strVal = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_LOAN_PROCESS", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LT_ID", lp_id);
                    // command.Parameters.AddWithValue("@CAM_TYPE", cam_type);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        strVal = Convert.ToInt32(Dtdataset.Rows[0]["LT_PER"]);
                    }
                    // return Dtdataset;
                    return strVal;
                }
            }
        }
    }

    public double Get_LCR_LTV_Calc_Amt(double CONST_VAL, double LAND_VAL, int lp_id, int lp_per)
    {
        double strVal = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_LCR_LTV_CALC", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CONST_VAL", CONST_VAL);
                    command.Parameters.AddWithValue("@LAND_VAL", LAND_VAL);
                    command.Parameters.AddWithValue("@LP_ID", lp_id);
                    command.Parameters.AddWithValue("@LP_PER", lp_per);
                    // command.Parameters.AddWithValue("@CAM_TYPE", cam_type);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        strVal = Convert.ToDouble(Dtdataset.Rows[0]["LCR_LTV"]);
                    }
                    // return Dtdataset;
                    return strVal;
                }
            }
        }
    }
    /*GHF Changes ends*/

    public string Bind_Legal_Queries(string ld_no)
    {
        string qry="";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_RPT_PRELIMINARY_QUERIES_DETS", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LDNO", ld_no);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                   // return Dtdataset;
                     StringBuilder qry1= new StringBuilder();
                    for(int i=0;i<Dtdataset.Tables[0].Rows.Count;i++)
                    {
                        qry1.Append(Dtdataset.Tables[0].Rows[i]["QUERIES"] != DBNull.Value ? Dtdataset.Tables[0].Rows[i]["QUERIES"].ToString() + " \n " : "");
                    }
                    qry = qry1.ToString();
                    return qry;

                }
            }

        }
    }
    /*Branch KYC Aplicant Validation Starts*/
    public int Is_Applicant_Already_KYC(string app_type, string ld_no)
    {
        int cnt = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_KYC_DETAILS_FETCH", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@KYC_LD_ID", ld_no);
                    // command.Parameters.AddWithValue("@CAM_TYPE", cam_type);
                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    for (int i = 0; i < Dtdataset.Rows.Count; i++)
                    {
                        if (app_type == Dtdataset.Rows[i]["KYC_APP_TYPE"].ToString())
                        {
                            cnt = cnt + 1;
                        }
                    }
                    //return Dtdataset;
                    //cnt = Dtdataset.Rows.Count;
                    return cnt;
                }
            }
        }
    }

    /*Branch KYC Aplicant Validation Ends*/
    /*Email Master Starts*/
    public DataSet Bind_FETCH_MR_EMAIL(string ld_no)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_FETCH_MR_EMAIL", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_NO", ld_no);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    /*Email Master Ends*/

    /*Disbursed more than 30 Days & Ho Ops Ready to relead cheque starts*/
    public int Is_Ready_Cheque_Release_Done(int br_id)
    {
        int cnt = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_DISB_MR_BRANCH", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BR_ID", br_id);
                    command.Parameters.AddWithValue("@PTYPE", "DISB_RLSE");
                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);

                    if (Dtdataset.Rows.Count > 0)
                    {
                        cnt = Convert.ToInt32(Dtdataset.Rows[0]["BR_SDISB_STAT"]);
                    }

                    //return Dtdataset;
                    //cnt = Dtdataset.Rows.Count;
                    return cnt;
                }
            }
        }
    }
    /*Disbursed more than 30 Days & Ho Ops Ready to relead cheque ends*/
    /*Starts Lead close based on user access type before RFD */
    public int Is_Lead_Close_Status(string ld_id)
    {
        int cnt = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_LEAD_CLOSED_STAT", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_ID", ld_id);
                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    //if (Dtdataset.Rows.Count > 0)
                    //{
                    //    cnt = Convert.ToInt32(Dtdataset.Rows[0]["BR_SDISB_STAT"]);
                    //}
                    //return Dtdataset;
                    cnt = Dtdataset.Rows.Count;
                    return cnt;
                }
            }
        }
    }
    /*Ends Lead close based on user access type before RFD*/

    /*LEAD creation page changes Starts*/
    public DataSet Bind_FETCH_Loan_Details(string ld_loan_no)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_LEAD_DETAIL_BY_LOANNUMBER", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_LOAN_NO", ld_loan_no);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    /*Lead creation page changes Ends*/

    /*Disbursal Memo Changes Starts*/
    public DataSet Bind_DM_Loan_Type()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_DM_LOAN_TYPE", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@LD_LOAN_NO", ld_loan_no);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*Disbursal memo changes ends*/

    /* Area Type Starts*/
    public DataSet Bind_MR_Area_Type()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_Area_Type", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@TYPE", "CHECK_UPT");
                    //command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*Area Type Ends*/
    /*Construction Stage Starts*/
    public DataSet Bind_MR_DM_CONST_STAGE()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_DM_CONST_STAGE", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@TYPE", "CHECK_UPT");
                    //command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*Construction Stage Ends*/
    /*Construction Stage Starts*/
    public DataSet Bind_MR_DM_BUILDING_TYPE()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_DM_BUliDING_TYPE", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@TYPE", "CHECK_UPT");
                    //command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*Construction Stage Ends*/
    public DataSet Bind_LSD_CLSR_QUERIES(string LD_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_FETCH_LSD_CLSR_QUERY", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@QRY_LD_ID", LD_ID);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*Audit Type Starts*/
    public DataSet Bind_MR_AUDIT_TYPE()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_MR_AUDIT_TYPE", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@TYPE", "CHECK_UPT");
                    //command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*Audit Type Ends*/
    /*Email Master Starts*/
    public DataSet Bind_FETCH_MR_AREA_MANAGER(string ld_no)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_FETCH_MR_AREA_MANAGER", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_NO", ld_no);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    public DataSet Bind_FETCH_MR_AREA_MANAGER_BY_Branch(string br_id)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_FETCH_MR_AREA_MANAGER", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BR_ID", br_id);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }


    /*Email Master Ends*/

    public DataSet Bind_FETCH_MR_INTEREST(string cam_type)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_BIND_MR_INTEREST", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@View", cam_type);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    public int Get_MR_Property_Percentage(string PR_DESC, string PR_TYPE)
    {
        int pr_percent = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_MR_PROPERTY", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PT_DESC", PR_DESC);
                    command.Parameters.AddWithValue("@PT_TYPE", PR_TYPE);

                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        pr_percent = Convert.ToInt32(Dtdataset.Rows[0]["PT_PERCENT"]);
                    }
                    // return Dtdataset;
                    return pr_percent;
                }
            }
        }
    }

    public DataSet Bind_FETCH_DETAILS_BRANCH(string br_id)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_BIND_MR_BRANCH", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BR_ID", br_id);
                    //  command.Parameters.AddWithValue("@TYPE", "FORBANKID");
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }

    public int Bind_MR_BANK_Count(string ifsccode)
    {
        int cntBank = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_BIND_MR_BANK", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@BK_IFSC", ifsccode);


                    DataTable Dtdataset = new DataTable();
                    adapter.Fill(Dtdataset);
                    if (Dtdataset.Rows.Count > 0)
                    {
                        cntBank = Dtdataset.Rows.Count;
                    }
                    // return Dtdataset;
                    return cntBank;
                }
            }
        }
    }
    /*KYC Details Starts*/
    public DataSet Bind_MR_KYC_APP_DETAILS(string LD_ID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_Fetch_KYC_APP_DETAILS", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_ID", LD_ID);
                    //command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*KYC Details Ends*/

    /*KYC Details Starts*/
    public DataSet Bind_PD_Employees(string LD_NO)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_FETCH_PD_EMPLOYEES", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LD_NO", LD_NO);
                    //command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    return Dtdataset;
                }
            }

        }
    }
    /*KYC Details Ends*/
    public int Is_Source_Type_Validate(string ET_ID)
    {
        int cntType = 0;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand("RTS_SP_PRD_SRC_VALDTE", con))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    //command.Parameters.AddWithValue("@LD_NO", LD_NO);
                    //command.Parameters.AddWithValue("@LD_SANTD_NO", sanc_no);
                    DataSet Dtdataset = new DataSet();
                    adapter.Fill(Dtdataset);
                    for (int i = 0; i < Dtdataset.Tables[0].Rows.Count; i++)
                    {
                        if (Convert.ToString(Dtdataset.Tables[0].Rows[i]["ET_ID"]) == ET_ID)
                        {
                            cntType = cntType + 1;
                        }
                    }
                    return cntType;
                }
            }

        }
    }

    public DataTable GetDropDownItemsByGroup(String ItemGroup)
    {
        DataTable dropdownItems = new DataTable();

        try
        {
            using (SqlConnection sqlConn = GetConnection())
            {
                using (SqlCommand sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_DROPDOWN_ITEMS_BY_GROUP, sqlConn))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandTimeout = 1200000;
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_Item_Group, ItemGroup);
                    using(SqlDataAdapter sqlDtAdptr = new SqlDataAdapter(sqlCmd))
                    {
                        sqlDtAdptr.Fill(dropdownItems);
                    }
                }
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }

        return dropdownItems;
    }

    public DataTable GetDropDownItemsByGroupAndSubGroup(String ItemGroup, String ItemSubGroup)
    {
        DataTable dropdownItems = new DataTable();

        try
        {
            using (SqlConnection sqlConn = GetConnection())
            {
                using (SqlCommand sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_GET_DROPDOWN_ITEMS_BY_GROUP_AND_SUBGROUP, sqlConn))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandTimeout = 1200000;
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_Item_Group, ItemGroup);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_Item_SubGroup, ItemSubGroup);
                    using (SqlDataAdapter sqlDtAdptr = new SqlDataAdapter(sqlCmd))
                    {
                        sqlDtAdptr.Fill(dropdownItems);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return dropdownItems;
    }

    public bool ValidateUserTypeIsBranch(Int64 UserId)
    {
        bool _result = false;

        try
        {
            using (SqlConnection sqlConn = GetConnection())
            {
                using (SqlCommand sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_VALIDATE_USER_TYPE_IS_BRANCH, sqlConn))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandTimeout = 1200000;
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserId, UserId);
                    var result = sqlCmd.ExecuteScalar();

                    if(result != null)
                    {
                        Boolean.TryParse(Convert.ToString(result), out _result);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return _result;
    }

    public String IdentifyUserRoleGroup(Int64 UserRoleId)
    {
        Int64 _userRoleId = 0;
        String _userRoleGroup = String.Empty;

        if (UserRoleId > 0)
        {
            _userRoleId = UserRoleId;
            if (_userRoleId == Convert.ToInt64(UserRole.ADMIN_HO))
            {
                _userRoleGroup = Convert.ToString(UserRoleGroup.AHO);
            }
            else if (_userRoleId == Convert.ToInt64(UserRole.ADMIN))
            {
                _userRoleGroup = Convert.ToString(UserRoleGroup.A);
            }
            else if (_userRoleId == Convert.ToInt64(UserRole.HO_OPS_QC)
                || _userRoleId == Convert.ToInt64(UserRole.HO_OPS_HELP_DESK)
                || _userRoleId == Convert.ToInt64(UserRole.HO_OPS_POST_DISBURSEMENT))
            {
                _userRoleGroup = Convert.ToString(UserRoleGroup.HO);
            }
            else if (_userRoleId == Convert.ToInt64(UserRole.CREDIT)
                || _userRoleId == Convert.ToInt64(UserRole.CREDIT_HEAD)
                || _userRoleId == Convert.ToInt64(UserRole.CREDIT_HELP_DESK)
                || _userRoleId == Convert.ToInt64(UserRole.CREDIT_HO)
                || _userRoleId == Convert.ToInt64(UserRole.CREDIT_MIS)
                || _userRoleId == Convert.ToInt64(UserRole.CREDIT_OPERATION)
                || _userRoleId == Convert.ToInt64(UserRole.CREDIT_SAMPLING)
                || _userRoleId == Convert.ToInt64(UserRole.CREDIT_WO_APVL)
                || _userRoleId == Convert.ToInt64(UserRole.AM_CI)
                || _userRoleId == Convert.ToInt64(UserRole.SCI)
                || _userRoleId == Convert.ToInt64(UserRole.OCI))
            {
                _userRoleGroup = Convert.ToString(UserRoleGroup.C);
            }
            else if (_userRoleId == Convert.ToInt64(UserRole.BRANCH))
            {
                _userRoleGroup = Convert.ToString(UserRoleGroup.B);
            }
        }

        return _userRoleGroup;
    }

    public bool ValidateDisbursalMemoEligibleForProcessing(String LeadNo, String UserRoleGroup)
    {
        bool _result = false;
        Int64 _leadId = 0;

        try
        {
            using (SqlConnection sqlConn = GetConnection())
            {
                using (SqlCommand sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_VALIDATE_DM_ELIGIBLE_FOR_PROCESSING, sqlConn))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandTimeout = 1200000;
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_Lead_No, LeadNo);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_UserRoleGroup, UserRoleGroup);
                    var result = sqlCmd.ExecuteScalar();

                    if (result != null)
                    {
                        Int64.TryParse(Convert.ToString(result), out _leadId);
                        _result = (_leadId > 0);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return _result;
    }

    public bool ValidateDMCompletedByCredit(String LeadNo)
    {
        bool _result = false;
        Int64 _leadId = 0;

        try
        {
            using (SqlConnection sqlConn = GetConnection())
            {
                using (SqlCommand sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_VALIDATE_CREDIT_DM_COMPLETE, sqlConn))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandTimeout = 1200000;
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_Lead_No, LeadNo);
                    var result = sqlCmd.ExecuteScalar();

                    if (result != null)
                    {
                        Int64.TryParse(Convert.ToString(result), out _leadId);
                        _result = (_leadId > 0);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return _result;
    }

    public DataSet FetchLeadDetailsByLoanNumber(String loanNo)
    {
        DataSet dsLeadDetails = new DataSet();

        try
        {
            using (SqlConnection sqlConn = GetConnection())
            {
                using (SqlCommand sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_LEAD_DETAILS_BY_LOAN_NO, sqlConn))
                {
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_LD_LOAN_NO, loanNo);
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_Lead_Type, "GHF");
                    sqlCmd.CommandType = CommandType.StoredProcedure;

                    using (SqlDataAdapter sqlDtAdptr = new SqlDataAdapter(sqlCmd))
                    {
                        sqlDtAdptr.Fill(dsLeadDetails);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return dsLeadDetails;
    }

    public DataTable FetchEmployeeDetailsByEmployeeNumber(String EmpNo)
    {
        DataTable dtEmpDetails = new DataTable();

        try
        {
            using (SqlConnection sqlConn = GetConnection())
            {
                using (SqlCommand sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_EMPLOYEE_DETAILS_BY_EMPLOYEENO, sqlConn))
                {
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_EMP_NO, EmpNo);
                    sqlCmd.CommandType = CommandType.StoredProcedure;

                    using (SqlDataAdapter sqlDtAdptr = new SqlDataAdapter(sqlCmd))
                    {
                        sqlDtAdptr.Fill(dtEmpDetails);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return dtEmpDetails;
    }

    public DataTable FetchUserDetailsByUserId(Int64 UserId)
    {
        DataTable dtUserDetails = new DataTable();

        try
        {
            using (SqlConnection sqlConn = GetConnection())
            {
                using (SqlCommand sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_FETCH_USER_DETAILS_BY_USER_ID, sqlConn))
                {
                    sqlCmd.Parameters.AddWithValue(AppConstants.Param_USER_ID, UserId);
                    sqlCmd.CommandType = CommandType.StoredProcedure;

                    using (SqlDataAdapter sqlDtAdptr = new SqlDataAdapter(sqlCmd))
                    {
                        sqlDtAdptr.Fill(dtUserDetails);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return dtUserDetails;
    }

    public DataSet SaveSpotEmployeeDetails(SpotEmployeeDo spotEmployeeDo, SqlConnection sqlConn)
    {
        DataSet _resultSet = new DataSet();

        try
        {
            using (SqlCommand sqlCmd = new SqlCommand(AppConstants.Proc_RTS_SP_SAVE_SPOT_EMPLOYEE_DETAILS, sqlConn))
            {
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue(AppConstants.Param_SPT_LD_ID, spotEmployeeDo.SpotLeadId);
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_SPT_EMP_NO, spotEmployeeDo.EmployeeNo);
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_SPT_EMP_NAME, spotEmployeeDo.EmployeeName);
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_SPT_EMP_EMAIL, spotEmployeeDo.EmployeeEmail);
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_SPT_BRANCH_RESP, spotEmployeeDo.BranchResponse);
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_SPT_BRANCH_RESP_BY, spotEmployeeDo.BranchResponseBy);
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_SPT_STAT, spotEmployeeDo.Status);
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_SPT_CBY, spotEmployeeDo.CreatedBy);
                sqlCmd.Parameters.AddWithValue(AppConstants.Param_SPT_MBY, spotEmployeeDo.ModifiedBy);

                using (SqlDataAdapter sqlDtAdptr = new SqlDataAdapter(sqlCmd))
                {
                    sqlDtAdptr.Fill(_resultSet);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return _resultSet;
    }

    public Boolean ValidateIncomeTypeIsOnlyRentalOrPension(GridView gvIncomeDetail)
    {
        String _incomeType = String.Empty;
        Boolean _result = true;

        if (gvIncomeDetail != null && gvIncomeDetail.Rows.Count > 0)
        {
            foreach (GridViewRow gridViewRow in gvIncomeDetail.Rows)
            {
                if (gridViewRow != null && gridViewRow.Cells.Count > 0 && gridViewRow.Cells[2] != null)
                {
                    _incomeType = gridViewRow.Cells[2].Text.ToString();
                    if (_incomeType != null && (!_incomeType.ToLower().Contains("rent")) && (!_incomeType.ToLower().Contains("pension")))
                    {
                        _result = false;
                    }
                }
            }
        }

        return _result;
    }

    public Boolean ValidateIncomeTypeIsOnlyNonRegularAndIncomeNotConsidered(GridView gvIncomeDetail)
    {
        String _incomeType = String.Empty;
        Boolean _result = true;

        if (gvIncomeDetail != null && gvIncomeDetail.Rows.Count > 0)
        {
            foreach (GridViewRow gridViewRow in gvIncomeDetail.Rows)
            {
                if (gridViewRow != null && gridViewRow.Cells.Count > 0 && gridViewRow.Cells[2] != null)
                {
                    _incomeType = gridViewRow.Cells[2].Text.ToString();
                    if (_incomeType != null && (!_incomeType.ToLower().Contains("non regular income")) && (!_incomeType.ToLower().Contains("income not considered")))
                    {
                        _result = false;
                    }
                }
            }
        }

        return _result;
    }
}






