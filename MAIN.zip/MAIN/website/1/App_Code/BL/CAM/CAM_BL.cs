﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccessLayer.CAM;
using System.Data;
using Tracker;
using DataObjects.CAM.Unsecured;

namespace BusinessAccessLayer.CAM
{
    /// <summary>
    /// Summary description for Unsecured_CAM_BL
    /// </summary>
    public class CAM_BL
    {
        private DataTable _dt = null;
        private DataSet _ds = null;
        private CAM_DAL _cam_Dal = null;

        public CAM_BL()
        {
            _cam_Dal = new CAM_DAL();
        }

        public DataSet GetLeadsForUnsecuredBranchCAM(String branchName)
        {
            try
            {
                _ds = _cam_Dal.GetLeadsForUnsecuredBranchCAM(branchName);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _ds;
        }

        public DataSet GetLeadsForUnsecuredCreditCAM(String _areaId, String _branchId)
        {
            try
            {
                _ds = _cam_Dal.GetLeadsForUnsecuredCreditCAM(_areaId, _branchId);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _ds;
        }

        public DataSet GetFullLeadDetailsForUnsecuredCreditCAM(Int64 _leadId)
        {
            try
            {
                _ds = _cam_Dal.GetFullLeadDetailsForUnsecuredCreditCAM(_leadId);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _ds;
        }

        public DataSet GetUnsecuredCAMReport(String _leadNo, String _camType)
        {
            try
            {
                _ds = _cam_Dal.GetUnsecuredCAMReport(_leadNo, _camType);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _ds;
        }

        public DataSet GetMasterDataForCAM(String _camType)
        {
            DataSet _resultSet = null;

            try
            {
                _resultSet = _cam_Dal.GetMasterDataForCAM(_camType);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _resultSet;
        }

        public DataTable SaveUnsecuredBranchCAMSummary(UnsecuredCamDO _unsecuredCamSmmryDO, DataTable dtDbEsfbLoanDetails, DataTable dtDbBusinessDetails, DataTable dtDbOtherLoanDetails, Int64 _userId, out bool _result)
        {
            try
            {
                #region CAM SUMMARY

                //LEAD DETAILS
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_CAM_TYPE)) { _unsecuredCamSmmryDO.UCAM_CAM_TYPE = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_APPL_NAME)) { _unsecuredCamSmmryDO.UCAM_APPL_NAME = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_AR_NAME)) { _unsecuredCamSmmryDO.UCAM_AR_NAME = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_BR_NAME)) { _unsecuredCamSmmryDO.UCAM_BR_NAME = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_RES_ADDRESS)) { _unsecuredCamSmmryDO.UCAM_RES_ADDRESS = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_CONTACT_NO)) { _unsecuredCamSmmryDO.UCAM_CONTACT_NO = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_LIAB_BR_NAME)) { _unsecuredCamSmmryDO.UCAM_LIAB_BR_NAME = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_STAT)) { _unsecuredCamSmmryDO.UCAM_STAT = String.Empty; }

                Int64 _leadId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_LD_ID, out _leadId);
                _unsecuredCamSmmryDO.UCAM_LD_ID = Convert.ToString(_leadId);

                Int64 _areaId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_AR_ID, out _areaId);
                _unsecuredCamSmmryDO.UCAM_AR_ID = Convert.ToString(_areaId);

                Int64 _branchId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_BR_ID, out _branchId);
                _unsecuredCamSmmryDO.UCAM_BR_ID = Convert.ToString(_branchId);

                Int64 _liabBranchId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_LIAB_BR_ID, out _liabBranchId);
                _unsecuredCamSmmryDO.UCAM_LIAB_BR_ID = Convert.ToString(_liabBranchId);

                Double _custReqAmt = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_CUST_REQ_AMT, out _custReqAmt);
                _custReqAmt = Math.Round(_custReqAmt, 2);
                _unsecuredCamSmmryDO.UCAM_CUST_REQ_AMT = Convert.ToString(_custReqAmt);

                //CUSTOMER CATEGORY
                Double _dblCustCategoryId = 0.0;
                if (_unsecuredCamSmmryDO.UCAM_CUST_CTGRY_ID != null) { Double.TryParse(_unsecuredCamSmmryDO.UCAM_CUST_CTGRY_ID, out _dblCustCategoryId); }
                _unsecuredCamSmmryDO.UCAM_CUST_CTGRY_ID = Convert.ToString(Convert.ToInt64(_dblCustCategoryId));

                String _custCategory = null;
                if (_unsecuredCamSmmryDO.UCAM_CUST_CTGRY != null) { _custCategory = Convert.ToString(_unsecuredCamSmmryDO.UCAM_CUST_CTGRY).Trim(); }
                _unsecuredCamSmmryDO.UCAM_CUST_CTGRY = _custCategory;

                //PASSING DUMMY VALUES FOR OLD ESFB LOAN DETAILS
                String _esfbLoanAgremnt = null;
                if (!String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_EXST_LN_AGRMNT)) { _esfbLoanAgremnt = Convert.ToString(_unsecuredCamSmmryDO.UCAM_EXST_LN_AGRMNT); }
                _unsecuredCamSmmryDO.UCAM_EXST_LN_AGRMNT = _esfbLoanAgremnt;

                String _esfbProdName = null;
                if (!String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_PR_NAME)) { _esfbProdName = Convert.ToString(_unsecuredCamSmmryDO.UCAM_PR_NAME); }
                _unsecuredCamSmmryDO.UCAM_PR_NAME = _esfbProdName;

                Double _esfbLoanAmount = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_EXST_LN_AMT, out _esfbLoanAmount);
                _esfbLoanAmount = Math.Round(_esfbLoanAmount, 2);
                _unsecuredCamSmmryDO.UCAM_EXST_LN_AMT = Convert.ToString(_esfbLoanAmount);

                //PROPERTY OWNERSHIP DETAILS
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_PRPTY_TYPE)) { _unsecuredCamSmmryDO.UCAM_PRPTY_TYPE = String.Empty; }

                Int64 _propertyId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_PRPTY_TYPE_ID, out _propertyId);
                _unsecuredCamSmmryDO.UCAM_PRPTY_TYPE_ID = Convert.ToString(_propertyId);

                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_OCC_STAT)) { _unsecuredCamSmmryDO.UCAM_OCC_STAT = String.Empty; }

                Int64 _occStatId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_OCC_STAT_ID, out _occStatId);
                _unsecuredCamSmmryDO.UCAM_OCC_STAT_ID = Convert.ToString(_occStatId);

                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_USG)) { _unsecuredCamSmmryDO.UCAM_USG = String.Empty; }

                Int64 _usageId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_USG_ID, out _usageId);
                _unsecuredCamSmmryDO.UCAM_USG_ID = Convert.ToString(_usageId);

                //OTHER DETAILS
                Double _mnthlyIncmFrmBusiness = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_OTH_DT_MON_INC_FRM_BSNS, out _mnthlyIncmFrmBusiness);
                _mnthlyIncmFrmBusiness = Math.Round(_mnthlyIncmFrmBusiness, 2);
                _unsecuredCamSmmryDO.UCAM_OTH_DT_MON_INC_FRM_BSNS = Convert.ToString(_mnthlyIncmFrmBusiness);

                Double _factPrcnt = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_OTH_DT_FACT_PRCNT, out _factPrcnt);
                _factPrcnt = Math.Round(_factPrcnt, 2);
                _unsecuredCamSmmryDO.UCAM_OTH_DT_FACT_PRCNT = Convert.ToString(_factPrcnt);

                Double _finalIncome = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_OTH_DT_FIN_INC, out _finalIncome);
                _finalIncome = Math.Round(_finalIncome, 2);
                _unsecuredCamSmmryDO.UCAM_OTH_DT_FIN_INC = Convert.ToString(_finalIncome);

                Int64 _popOfLocality = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_OTH_DT_POP_CITY, out _popOfLocality);
                _unsecuredCamSmmryDO.UCAM_OTH_DT_POP_CITY = Convert.ToString(_popOfLocality);

                //ELIGIBILITY DETAILS
                Double _eligTotalAnnlBusnsTurnOvrBasedOnAssmnt = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_TOT_SAL_ASSMT, out _eligTotalAnnlBusnsTurnOvrBasedOnAssmnt);
                _eligTotalAnnlBusnsTurnOvrBasedOnAssmnt = Math.Round(_eligTotalAnnlBusnsTurnOvrBasedOnAssmnt, 2);
                _unsecuredCamSmmryDO.UCAM_TOT_SAL_ASSMT = Convert.ToString(_eligTotalAnnlBusnsTurnOvrBasedOnAssmnt);

                Double _factPercent = 0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_FACT_PRCNT, out _factPercent);
                _factPercent = Math.Round(_factPercent, 2);
                _unsecuredCamSmmryDO.UCAM_FACT_PRCNT = Convert.ToString(_factPercent);

                Double _factDevPercent = 0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_FACT_DEV_PRCNT, out _factDevPercent);
                _factDevPercent = Math.Round(_factDevPercent, 2);
                _unsecuredCamSmmryDO.UCAM_FACT_DEV_PRCNT = Convert.ToString(_factDevPercent);

                Double _limitOfTotalAssessedTurnover = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_SAL_AFTR_FACTR, out _limitOfTotalAssessedTurnover);
                _limitOfTotalAssessedTurnover = Math.Round(_limitOfTotalAssessedTurnover, 2);
                _unsecuredCamSmmryDO.UCAM_SAL_AFTR_FACTR = _limitOfTotalAssessedTurnover.ToString();

                Double _elig_TotOutstandingAmt = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_TOT_OUT_AMT, out _elig_TotOutstandingAmt);
                _elig_TotOutstandingAmt = Math.Round(_elig_TotOutstandingAmt, 2);
                _unsecuredCamSmmryDO.UCAM_TOT_OUT_AMT = _elig_TotOutstandingAmt.ToString();

                Double _limitPostObligatingOutstandingLoans = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_ESFB_LMT_ELIG, out _limitPostObligatingOutstandingLoans);
                _limitPostObligatingOutstandingLoans = Math.Round(_limitPostObligatingOutstandingLoans, 2);
                _unsecuredCamSmmryDO.UCAM_ESFB_LMT_ELIG = _limitPostObligatingOutstandingLoans.ToString();

                Double _finalEsfbEligLimit = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_FIN_ESFB_LMT_ELIG, out _finalEsfbEligLimit);
                _finalEsfbEligLimit = Math.Round(_finalEsfbEligLimit, 2);
                _unsecuredCamSmmryDO.UCAM_FIN_ESFB_LMT_ELIG = _finalEsfbEligLimit.ToString();

                #endregion

                #region ESFB LOAN DETAILS

                /* Include ESFB loan details only IF Cusomer is an 'EXISTING CUSTOMER'
                 * ELSE Remove ESFB loan Details */
                if (dtDbEsfbLoanDetails != null && dtDbEsfbLoanDetails.Rows.Count > 0 && _unsecuredCamSmmryDO.UCAM_CUST_CTGRY == "EXISTING CUSTOMER")
                {
                    foreach (DataRow drDbEsfbLoanDetail in dtDbEsfbLoanDetails.Rows)
                    {
                        String _esfbLoanAgreement = null;
                        if (drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AGRMNT] != null) { _esfbLoanAgreement = Convert.ToString(drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AGRMNT]); }
                        drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AGRMNT] = _esfbLoanAgreement;

                        String _prodName = null;
                        if (drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_PR_NAME] != null) { _prodName = Convert.ToString(drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_PR_NAME]); }
                        drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_PR_NAME] = _prodName;

                        Double _esfbLoanAmt = 0.0;
                        if (drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AMT] != null) { Double.TryParse(Convert.ToString(drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AMT]), out _esfbLoanAmt); }
                        _esfbLoanAmt = Math.Round(_esfbLoanAmt, 2);
                        drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AMT] = _esfbLoanAmt.ToString();

                        Double _esfbLoanOutstandingAmt = 0.0;
                        if (drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_OS_AMT] != null) { Double.TryParse(Convert.ToString(drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_OS_AMT]), out _esfbLoanOutstandingAmt); }
                        _esfbLoanOutstandingAmt = Math.Round(_esfbLoanOutstandingAmt, 2);
                        drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_OS_AMT] = _esfbLoanOutstandingAmt.ToString();
                    }
                }
                else
                {
                    dtDbEsfbLoanDetails = null;
                }

                #endregion

                #region BUSINESS DETAILS

                if (dtDbBusinessDetails != null && dtDbBusinessDetails.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in dtDbBusinessDetails.Rows)
                    {
                        Int64 _kycLeadId = 0;
                        if (dataRow[AppConstants.Col_UBD_LD_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_LD_ID]), out _kycLeadId); }
                        dataRow[AppConstants.Col_UBD_LD_ID] = _kycLeadId.ToString();

                        dataRow[AppConstants.Col_UBD_UCAM_ID] = null;

                        Int64 _kycId = 0;
                        if (dataRow[AppConstants.Col_UBD_KYC_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_KYC_ID]), out _kycId); }
                        dataRow[AppConstants.Col_UBD_KYC_ID] = _kycId.ToString();

                        Int64 _cibil = 0;
                        if (dataRow[AppConstants.Col_UBD_CIBIL] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_CIBIL]), out _cibil); }
                        dataRow[AppConstants.Col_UBD_CIBIL] = _cibil.ToString();

                        String _natureOfBusiness = null;
                        if (dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS] != null) { _natureOfBusiness = Convert.ToString(dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS]); }
                        dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS] = _natureOfBusiness;

                        String _natureOfBusinessKey = null;
                        if (dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS_KEY] != null) { _natureOfBusinessKey = Convert.ToString(dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS_KEY]); }
                        dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS_KEY] = _natureOfBusinessKey;

                        Int64 _custProfileId = 0;
                        if (dataRow[AppConstants.Col_UBD_CUST_PROF_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_CUST_PROF_ID]), out _custProfileId); }
                        dataRow[AppConstants.Col_UBD_CUST_PROF_ID] = _custProfileId.ToString();

                        Int64 _segmentId = 0;
                        if (dataRow[AppConstants.Col_UBD_SGMT_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_SGMT_ID]), out _segmentId); }
                        dataRow[AppConstants.Col_UBD_SGMT_ID] = _segmentId.ToString();

                        Int64 _subCtgryId = 0;
                        if (dataRow[AppConstants.Col_UBD_SUB_CTGRY_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_SUB_CTGRY_ID]), out _subCtgryId); }
                        dataRow[AppConstants.Col_UBD_SUB_CTGRY_ID] = _subCtgryId.ToString();

                        Double _annlBusnsTurnOvrBasedOnAssmnt = 0.0;
                        if (dataRow[AppConstants.Col_UBD_SALES_BASED_ON_ASSMT] != null) { Double.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_SALES_BASED_ON_ASSMT]), out _annlBusnsTurnOvrBasedOnAssmnt); }
                        _annlBusnsTurnOvrBasedOnAssmnt = Math.Round(_annlBusnsTurnOvrBasedOnAssmnt, 2);
                        dataRow[AppConstants.Col_UBD_SALES_BASED_ON_ASSMT] = _annlBusnsTurnOvrBasedOnAssmnt.ToString();

                        String _status = null;
                        if (dataRow[AppConstants.Col_UBD_STAT] != null) { _status = Convert.ToString(dataRow[AppConstants.Col_UBD_STAT]); }
                        dataRow[AppConstants.Col_UBD_STAT] = _status;

                        dataRow[AppConstants.Col_UBD_CRTD_BY] = null;
                        dataRow[AppConstants.Col_UBD_CRTD_DT] = null;
                        dataRow[AppConstants.Col_UBD_MDFD_BY] = null;
                        dataRow[AppConstants.Col_UBD_MDFD_DT] = null;
                    }
                }

                #endregion

                #region OTHER LOAN DETAILS

                if (dtDbOtherLoanDetails != null && dtDbOtherLoanDetails.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in dtDbOtherLoanDetails.Rows)
                    {
                        Int64 _uoldLeadId = 0;
                        if (dataRow[AppConstants.Col_UOLD_LD_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_LD_ID]), out _uoldLeadId); }
                        dataRow[AppConstants.Col_UOLD_LD_ID] = Convert.ToString(_uoldLeadId);

                        Int64 _camId = 0;
                        if (dataRow[AppConstants.Col_UOLD_UCAM_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_UCAM_ID]), out _camId); }
                        dataRow[AppConstants.Col_UOLD_UCAM_ID] = Convert.ToString(_camId);

                        String _financier = null;
                        if (dataRow[AppConstants.Col_UOLD_FIN] != null) { _financier = Convert.ToString(dataRow[AppConstants.Col_UOLD_FIN]); }
                        dataRow[AppConstants.Col_UOLD_FIN] = _financier;

                        String _loanType = null;
                        if (dataRow[AppConstants.Col_UOLD_LN_TYPE] != null) { _loanType = Convert.ToString(dataRow[AppConstants.Col_UOLD_LN_TYPE]); }
                        dataRow[AppConstants.Col_UOLD_LN_TYPE] = _loanType;

                        Double _sanctionAmount = 0.0;
                        if (dataRow[AppConstants.Col_UOLD_SANC_AMT] != null) { Double.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_SANC_AMT]), out _sanctionAmount); }
                        _sanctionAmount = Math.Round(_sanctionAmount, 2);
                        dataRow[AppConstants.Col_UOLD_SANC_AMT] = Convert.ToString(_sanctionAmount);

                        Double _outstandingAmount = 0.0;
                        if (dataRow[AppConstants.Col_UOLD_OUTSTAND_AMT] != null) { Double.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_OUTSTAND_AMT]), out _outstandingAmount); }
                        _outstandingAmount = Math.Round(_outstandingAmount, 2);
                        dataRow[AppConstants.Col_UOLD_OUTSTAND_AMT] = Convert.ToString(_outstandingAmount);

                        Double _emiAmount = 0.0;
                        if (dataRow[AppConstants.Col_UOLD_EMI_AMT] != null) { Double.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_EMI_AMT]), out _emiAmount); }
                        _emiAmount = Math.Round(_emiAmount, 2);
                        dataRow[AppConstants.Col_UOLD_EMI_AMT] = Convert.ToString(_emiAmount);

                        Int64 _tenor = 0;
                        if (dataRow[AppConstants.Col_UOLD_TENOR] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_TENOR]), out _tenor); }
                        dataRow[AppConstants.Col_UOLD_TENOR] = Convert.ToString(_tenor);

                        String _status = null;
                        if (dataRow[AppConstants.Col_UOLD_STAT] != null) { _status = Convert.ToString(dataRow[AppConstants.Col_UOLD_STAT]); }
                        dataRow[AppConstants.Col_UOLD_STAT] = Convert.ToString(_status);

                        dataRow[AppConstants.Col_UOLD_CRTD_BY] = null;
                        dataRow[AppConstants.Col_UOLD_CRTD_DT] = null;
                        dataRow[AppConstants.Col_UOLD_MDFD_BY] = null;
                        dataRow[AppConstants.Col_UOLD_MDFD_DT] = null;

                        Int64 _loanTypeId = 0;
                        if (dataRow[AppConstants.Col_UOLD_LN_TYPE_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_LN_TYPE_ID]), out _loanTypeId); }
                        dataRow[AppConstants.Col_UOLD_LN_TYPE_ID] = Convert.ToString(_loanTypeId);
                    }
                }

                #endregion

                _dt = _cam_Dal.SaveUnsecuredBranchCAMSummary(_unsecuredCamSmmryDO, dtDbEsfbLoanDetails, dtDbBusinessDetails, dtDbOtherLoanDetails, _userId, out _result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _dt;
        }

        public DataTable SaveUnsecuredCreditCAMSummary(UnsecuredCamDO _unsecuredCamSmmryDO, DataTable dtDbEsfbLoanDetails, DataTable dtDbBusinessDetails, DataTable dtDbOtherLoanDetails, FileCreditScoreDo fileCreditScoreDo, Int64 _userId, out bool _result)
        {
            try
            {
                #region CAM SUMMARY

                //LEAD DETAILS
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_CAM_TYPE)) { _unsecuredCamSmmryDO.UCAM_CAM_TYPE = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_APPL_NAME)) { _unsecuredCamSmmryDO.UCAM_APPL_NAME = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_AR_NAME)) { _unsecuredCamSmmryDO.UCAM_AR_NAME = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_BR_NAME)) { _unsecuredCamSmmryDO.UCAM_BR_NAME = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_RES_ADDRESS)) { _unsecuredCamSmmryDO.UCAM_RES_ADDRESS = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_CONTACT_NO)) { _unsecuredCamSmmryDO.UCAM_CONTACT_NO = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_LIAB_BR_NAME)) { _unsecuredCamSmmryDO.UCAM_LIAB_BR_NAME = String.Empty; }
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_STAT)) { _unsecuredCamSmmryDO.UCAM_STAT = String.Empty; }

                Int64 _leadId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_LD_ID, out _leadId);
                _unsecuredCamSmmryDO.UCAM_LD_ID = Convert.ToString(_leadId);

                Int64 _areaId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_AR_ID, out _areaId);
                _unsecuredCamSmmryDO.UCAM_AR_ID = Convert.ToString(_areaId);

                Int64 _branchId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_BR_ID, out _branchId);
                _unsecuredCamSmmryDO.UCAM_BR_ID = Convert.ToString(_branchId);

                Int64 _liabBranchId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_LIAB_BR_ID, out _liabBranchId);
                _unsecuredCamSmmryDO.UCAM_LIAB_BR_ID = Convert.ToString(_liabBranchId);

                Double _custReqAmt = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_CUST_REQ_AMT, out _custReqAmt);
                _custReqAmt = Math.Round(_custReqAmt, 2);
                _unsecuredCamSmmryDO.UCAM_CUST_REQ_AMT = Convert.ToString(_custReqAmt);

                //CUSTOMER CATEGORY
                Double _dblCustCategoryId = 0.0;
                if (_unsecuredCamSmmryDO.UCAM_CUST_CTGRY_ID != null) { Double.TryParse(_unsecuredCamSmmryDO.UCAM_CUST_CTGRY_ID, out _dblCustCategoryId); }
                _unsecuredCamSmmryDO.UCAM_CUST_CTGRY_ID = Convert.ToString(Convert.ToInt64(_dblCustCategoryId));

                String _custCategory = null;
                if (_unsecuredCamSmmryDO.UCAM_CUST_CTGRY != null) { _custCategory = Convert.ToString(_unsecuredCamSmmryDO.UCAM_CUST_CTGRY).Trim(); }
                _unsecuredCamSmmryDO.UCAM_CUST_CTGRY = _custCategory;

                //PASSING DUMMY VALUES FOR OLD ESFB LOAN DETAILS
                String _esfbLoanAgremnt = null;
                if (!String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_EXST_LN_AGRMNT)) { _esfbLoanAgremnt = Convert.ToString(_unsecuredCamSmmryDO.UCAM_EXST_LN_AGRMNT); }
                _unsecuredCamSmmryDO.UCAM_EXST_LN_AGRMNT = _esfbLoanAgremnt;

                String _esfbProdName = null;
                if (!String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_PR_NAME)) { _esfbProdName = Convert.ToString(_unsecuredCamSmmryDO.UCAM_PR_NAME); }
                _unsecuredCamSmmryDO.UCAM_PR_NAME = _esfbProdName;

                Double _esfbLoanAmount = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_EXST_LN_AMT, out _esfbLoanAmount);
                _esfbLoanAmount = Math.Round(_esfbLoanAmount, 2);
                _unsecuredCamSmmryDO.UCAM_EXST_LN_AMT = Convert.ToString(_esfbLoanAmount);

                //PROPERTY OWNERSHIP DETAILS
                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_PRPTY_TYPE)) { _unsecuredCamSmmryDO.UCAM_PRPTY_TYPE = String.Empty; }

                Int64 _propertyId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_PRPTY_TYPE_ID, out _propertyId);
                _unsecuredCamSmmryDO.UCAM_PRPTY_TYPE_ID = Convert.ToString(_propertyId);

                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_OCC_STAT)) { _unsecuredCamSmmryDO.UCAM_OCC_STAT = String.Empty; }

                Int64 _occStatId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_OCC_STAT_ID, out _occStatId);
                _unsecuredCamSmmryDO.UCAM_OCC_STAT_ID = Convert.ToString(_occStatId);

                if (String.IsNullOrEmpty(_unsecuredCamSmmryDO.UCAM_USG)) { _unsecuredCamSmmryDO.UCAM_USG = String.Empty; }

                Int64 _usageId = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_USG_ID, out _usageId);
                _unsecuredCamSmmryDO.UCAM_USG_ID = Convert.ToString(_usageId);

                //OTHER DETAILS
                Double _mnthlyIncmFrmBusiness = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_OTH_DT_MON_INC_FRM_BSNS, out _mnthlyIncmFrmBusiness);
                _mnthlyIncmFrmBusiness = Math.Round(_mnthlyIncmFrmBusiness, 2);
                _unsecuredCamSmmryDO.UCAM_OTH_DT_MON_INC_FRM_BSNS = Convert.ToString(_mnthlyIncmFrmBusiness);

                Double _factPrcnt = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_OTH_DT_FACT_PRCNT, out _factPrcnt);
                _factPrcnt = Math.Round(_factPrcnt, 2);
                _unsecuredCamSmmryDO.UCAM_OTH_DT_FACT_PRCNT = Convert.ToString(_factPrcnt);

                Double _finalIncome = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_OTH_DT_FIN_INC, out _finalIncome);
                _finalIncome = Math.Round(_finalIncome, 2);
                _unsecuredCamSmmryDO.UCAM_OTH_DT_FIN_INC = Convert.ToString(_finalIncome);

                Int64 _popOfLocality = 0;
                Int64.TryParse(_unsecuredCamSmmryDO.UCAM_OTH_DT_POP_CITY, out _popOfLocality);
                _unsecuredCamSmmryDO.UCAM_OTH_DT_POP_CITY = Convert.ToString(_popOfLocality);

                //ELIGIBILITY DETAILS
                Double _eligTotalAnnlBusnsTurnOvrBasedOnAssmnt = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_TOT_SAL_ASSMT, out _eligTotalAnnlBusnsTurnOvrBasedOnAssmnt);
                _eligTotalAnnlBusnsTurnOvrBasedOnAssmnt = Math.Round(_eligTotalAnnlBusnsTurnOvrBasedOnAssmnt, 2);
                _unsecuredCamSmmryDO.UCAM_TOT_SAL_ASSMT = Convert.ToString(_eligTotalAnnlBusnsTurnOvrBasedOnAssmnt);

                Double _factPercent = 0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_FACT_PRCNT, out _factPercent);
                _factPercent = Math.Round(_factPercent, 2);
                _unsecuredCamSmmryDO.UCAM_FACT_PRCNT = Convert.ToString(_factPercent);

                Double _factDevPercent = 0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_FACT_DEV_PRCNT, out _factDevPercent);
                _factDevPercent = Math.Round(_factDevPercent, 2);
                _unsecuredCamSmmryDO.UCAM_FACT_DEV_PRCNT = Convert.ToString(_factDevPercent);

                Double _limitOfTotalAssessedTurnover = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_SAL_AFTR_FACTR, out _limitOfTotalAssessedTurnover);
                _limitOfTotalAssessedTurnover = Math.Round(_limitOfTotalAssessedTurnover, 2);
                _unsecuredCamSmmryDO.UCAM_SAL_AFTR_FACTR = _limitOfTotalAssessedTurnover.ToString();

                Double _elig_TotOutstandingAmt = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_TOT_OUT_AMT, out _elig_TotOutstandingAmt);
                _elig_TotOutstandingAmt = Math.Round(_elig_TotOutstandingAmt, 2);
                _unsecuredCamSmmryDO.UCAM_TOT_OUT_AMT = _elig_TotOutstandingAmt.ToString();

                Double _limitPostObligatingOutstandingLoans = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_ESFB_LMT_ELIG, out _limitPostObligatingOutstandingLoans);
                _limitPostObligatingOutstandingLoans = Math.Round(_limitPostObligatingOutstandingLoans, 2);
                _unsecuredCamSmmryDO.UCAM_ESFB_LMT_ELIG = _limitPostObligatingOutstandingLoans.ToString();

                Double _finalEsfbEligLimit = 0.0;
                Double.TryParse(_unsecuredCamSmmryDO.UCAM_FIN_ESFB_LMT_ELIG, out _finalEsfbEligLimit);
                _finalEsfbEligLimit = Math.Round(_finalEsfbEligLimit, 2);
                _unsecuredCamSmmryDO.UCAM_FIN_ESFB_LMT_ELIG = _finalEsfbEligLimit.ToString();

                #endregion

                #region ESFB LOAN DETAILS

                /* Include ESFB loan details only IF Cusomer is an 'EXISTING CUSTOMER'
                 * ELSE Remove ESFB loan Details */
                if (dtDbEsfbLoanDetails != null && dtDbEsfbLoanDetails.Rows.Count > 0 && _unsecuredCamSmmryDO.UCAM_CUST_CTGRY == "EXISTING CUSTOMER")
                {
                    foreach (DataRow drDbEsfbLoanDetail in dtDbEsfbLoanDetails.Rows)
                    {
                        String _esfbLoanAgreement = null;
                        if (drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AGRMNT] != null) { _esfbLoanAgreement = Convert.ToString(drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AGRMNT]); }
                        drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AGRMNT] = _esfbLoanAgreement;

                        String _prodName = null;
                        if (drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_PR_NAME] != null) { _prodName = Convert.ToString(drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_PR_NAME]); }
                        drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_PR_NAME] = _prodName;

                        Double _esfbLoanAmt = 0.0;
                        if (drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AMT] != null) { Double.TryParse(Convert.ToString(drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AMT]), out _esfbLoanAmt); }
                        _esfbLoanAmt = Math.Round(_esfbLoanAmt, 2);
                        drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_AMT] = _esfbLoanAmt.ToString();

                        Double _esfbLoanOutstandingAmt = 0.0;
                        if (drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_OS_AMT] != null) { Double.TryParse(Convert.ToString(drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_OS_AMT]), out _esfbLoanOutstandingAmt); }
                        _esfbLoanOutstandingAmt = Math.Round(_esfbLoanOutstandingAmt, 2);
                        drDbEsfbLoanDetail[AppConstants.Col_UELD_ESFB_LN_OS_AMT] = _esfbLoanOutstandingAmt.ToString();
                    }
                }
                else
                {
                    dtDbEsfbLoanDetails = null;
                }

                #endregion

                #region BUSINESS DETAILS

                if (dtDbBusinessDetails != null && dtDbBusinessDetails.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in dtDbBusinessDetails.Rows)
                    {
                        Int64 _kycLeadId = 0;
                        if (dataRow[AppConstants.Col_UBD_LD_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_LD_ID]), out _kycLeadId); }
                        dataRow[AppConstants.Col_UBD_LD_ID] = _kycLeadId.ToString();

                        dataRow[AppConstants.Col_UBD_UCAM_ID] = null;

                        Int64 _kycId = 0;
                        if (dataRow[AppConstants.Col_UBD_KYC_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_KYC_ID]), out _kycId); }
                        dataRow[AppConstants.Col_UBD_KYC_ID] = _kycId.ToString();

                        Int64 _cibil = 0;
                        if (dataRow[AppConstants.Col_UBD_CIBIL] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_CIBIL]), out _cibil); }
                        dataRow[AppConstants.Col_UBD_CIBIL] = _cibil.ToString();

                        String _natureOfBusiness = null;
                        if (dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS] != null) { _natureOfBusiness = Convert.ToString(dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS]); }
                        dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS] = _natureOfBusiness;

                        String _natureOfBusinessKey = null;
                        if (dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS_KEY] != null) { _natureOfBusinessKey = Convert.ToString(dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS_KEY]); }
                        dataRow[AppConstants.Col_UBD_NAT_OF_BUSINESS_KEY] = _natureOfBusinessKey;

                        Int64 _custProfileId = 0;
                        if (dataRow[AppConstants.Col_UBD_CUST_PROF_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_CUST_PROF_ID]), out _custProfileId); }
                        dataRow[AppConstants.Col_UBD_CUST_PROF_ID] = _custProfileId.ToString();

                        Int64 _segmentId = 0;
                        if (dataRow[AppConstants.Col_UBD_SGMT_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_SGMT_ID]), out _segmentId); }
                        dataRow[AppConstants.Col_UBD_SGMT_ID] = _segmentId.ToString();

                        Int64 _subCtgryId = 0;
                        if (dataRow[AppConstants.Col_UBD_SUB_CTGRY_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_SUB_CTGRY_ID]), out _subCtgryId); }
                        dataRow[AppConstants.Col_UBD_SUB_CTGRY_ID] = _subCtgryId.ToString();

                        Double _annlBusnsTurnOvrBasedOnAssmnt = 0.0;
                        if (dataRow[AppConstants.Col_UBD_SALES_BASED_ON_ASSMT] != null) { Double.TryParse(Convert.ToString(dataRow[AppConstants.Col_UBD_SALES_BASED_ON_ASSMT]), out _annlBusnsTurnOvrBasedOnAssmnt); }
                        _annlBusnsTurnOvrBasedOnAssmnt = Math.Round(_annlBusnsTurnOvrBasedOnAssmnt, 2);
                        dataRow[AppConstants.Col_UBD_SALES_BASED_ON_ASSMT] = _annlBusnsTurnOvrBasedOnAssmnt.ToString();

                        String _status = null;
                        if (dataRow[AppConstants.Col_UBD_STAT] != null) { _status = Convert.ToString(dataRow[AppConstants.Col_UBD_STAT]); }
                        dataRow[AppConstants.Col_UBD_STAT] = _status;

                        dataRow[AppConstants.Col_UBD_CRTD_BY] = null;
                        dataRow[AppConstants.Col_UBD_CRTD_DT] = null;
                        dataRow[AppConstants.Col_UBD_MDFD_BY] = null;
                        dataRow[AppConstants.Col_UBD_MDFD_DT] = null;
                    }
                }

                #endregion

                #region OTHER LOAN DETAILS

                if (dtDbOtherLoanDetails != null && dtDbOtherLoanDetails.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in dtDbOtherLoanDetails.Rows)
                    {
                        Int64 _uoldLeadId = 0;
                        if (dataRow[AppConstants.Col_UOLD_LD_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_LD_ID]), out _uoldLeadId); }
                        dataRow[AppConstants.Col_UOLD_LD_ID] = Convert.ToString(_uoldLeadId);

                        Int64 _camId = 0;
                        if (dataRow[AppConstants.Col_UOLD_UCAM_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_UCAM_ID]), out _camId); }
                        dataRow[AppConstants.Col_UOLD_UCAM_ID] = Convert.ToString(_camId);

                        String _financier = null;
                        if (dataRow[AppConstants.Col_UOLD_FIN] != null) { _financier = Convert.ToString(dataRow[AppConstants.Col_UOLD_FIN]); }
                        dataRow[AppConstants.Col_UOLD_FIN] = _financier;

                        String _loanType = null;
                        if (dataRow[AppConstants.Col_UOLD_LN_TYPE] != null) { _loanType = Convert.ToString(dataRow[AppConstants.Col_UOLD_LN_TYPE]); }
                        dataRow[AppConstants.Col_UOLD_LN_TYPE] = _loanType;

                        Double _sanctionAmount = 0.0;
                        if (dataRow[AppConstants.Col_UOLD_SANC_AMT] != null) { Double.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_SANC_AMT]), out _sanctionAmount); }
                        _sanctionAmount = Math.Round(_sanctionAmount, 2);
                        dataRow[AppConstants.Col_UOLD_SANC_AMT] = Convert.ToString(_sanctionAmount);

                        Double _outstandingAmount = 0.0;
                        if (dataRow[AppConstants.Col_UOLD_OUTSTAND_AMT] != null) { Double.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_OUTSTAND_AMT]), out _outstandingAmount); }
                        _outstandingAmount = Math.Round(_outstandingAmount, 2);
                        dataRow[AppConstants.Col_UOLD_OUTSTAND_AMT] = Convert.ToString(_outstandingAmount);

                        Double _emiAmount = 0.0;
                        if (dataRow[AppConstants.Col_UOLD_EMI_AMT] != null) { Double.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_EMI_AMT]), out _emiAmount); }
                        _emiAmount = Math.Round(_emiAmount, 2);
                        dataRow[AppConstants.Col_UOLD_EMI_AMT] = Convert.ToString(_emiAmount);

                        Int64 _tenor = 0;
                        if (dataRow[AppConstants.Col_UOLD_TENOR] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_TENOR]), out _tenor); }
                        dataRow[AppConstants.Col_UOLD_TENOR] = Convert.ToString(_tenor);

                        String _status = null;
                        if (dataRow[AppConstants.Col_UOLD_STAT] != null) { _status = Convert.ToString(dataRow[AppConstants.Col_UOLD_STAT]); }
                        dataRow[AppConstants.Col_UOLD_STAT] = Convert.ToString(_status);

                        dataRow[AppConstants.Col_UOLD_CRTD_BY] = null;
                        dataRow[AppConstants.Col_UOLD_CRTD_DT] = null;
                        dataRow[AppConstants.Col_UOLD_MDFD_BY] = null;
                        dataRow[AppConstants.Col_UOLD_MDFD_DT] = null;

                        Int64 _loanTypeId = 0;
                        if (dataRow[AppConstants.Col_UOLD_LN_TYPE_ID] != null) { Int64.TryParse(Convert.ToString(dataRow[AppConstants.Col_UOLD_LN_TYPE_ID]), out _loanTypeId); }
                        dataRow[AppConstants.Col_UOLD_LN_TYPE_ID] = Convert.ToString(_loanTypeId);
                    }
                }

                #endregion

                #region FILE CREDIT SCORE

                if (fileCreditScoreDo != null)
                {
                    Int64 _fcsLeadId = 0;
                    Int64.TryParse(Convert.ToString(fileCreditScoreDo.FCS_LD_ID), out _fcsLeadId);
                    fileCreditScoreDo.FCS_LD_ID = Convert.ToString(_fcsLeadId);

                    Int64 _fcsBsnsVintId = 0;
                    Int64.TryParse(Convert.ToString(fileCreditScoreDo.FCS_BSNS_VINT_ID), out _fcsBsnsVintId);
                    fileCreditScoreDo.FCS_BSNS_VINT_ID = Convert.ToString(_fcsBsnsVintId);

                    Int64 _fcsMonIncFrmBsnsId = 0;
                    Int64.TryParse(Convert.ToString(fileCreditScoreDo.FCS_MON_INC_FRM_BSNS_ID), out _fcsMonIncFrmBsnsId);
                    fileCreditScoreDo.FCS_MON_INC_FRM_BSNS_ID = Convert.ToString(_fcsMonIncFrmBsnsId);

                    Int64 _fcsCrHistId = 0;
                    Int64.TryParse(Convert.ToString(fileCreditScoreDo.FCS_CR_HIST_ID), out _fcsCrHistId);
                    fileCreditScoreDo.FCS_CR_HIST_ID = Convert.ToString(_fcsCrHistId);

                    Int64 _fcsResPremOwndId = 0;
                    Int64.TryParse(Convert.ToString(fileCreditScoreDo.FCS_RES_PREM_OWND_ID), out _fcsResPremOwndId);
                    fileCreditScoreDo.FCS_RES_PREM_OWND_ID = Convert.ToString(_fcsResPremOwndId);

                    Int64 _fcsBsnsPremOwndId = 0;
                    Int64.TryParse(Convert.ToString(fileCreditScoreDo.FCS_BSNS_PREM_OWND_ID), out _fcsBsnsPremOwndId);
                    fileCreditScoreDo.FCS_BSNS_PREM_OWND_ID = Convert.ToString(_fcsBsnsPremOwndId);

                    Int64 _fcsLimtPrcntAsTrnovrId = 0;
                    Int64.TryParse(Convert.ToString(fileCreditScoreDo.FCS_LIMT_PRCNT_TRNOVR_ID), out _fcsLimtPrcntAsTrnovrId);
                    fileCreditScoreDo.FCS_LIMT_PRCNT_TRNOVR_ID = Convert.ToString(_fcsLimtPrcntAsTrnovrId);

                    Double _fcsScore = 0;
                    Double.TryParse(Convert.ToString(fileCreditScoreDo.FCS_SCORE), out _fcsScore);
                    fileCreditScoreDo.FCS_SCORE = Convert.ToString(_fcsScore);

                    String _fcsDefn = String.Empty;
                    if (fileCreditScoreDo.FCS_DEFN != null) { _fcsDefn = Convert.ToString(fileCreditScoreDo.FCS_DEFN); }
                    fileCreditScoreDo.FCS_DEFN = _fcsDefn;
                }

                #endregion

                _dt = _cam_Dal.SaveUnsecuredCreditCAMSummary(_unsecuredCamSmmryDO, dtDbEsfbLoanDetails, dtDbBusinessDetails, dtDbOtherLoanDetails, fileCreditScoreDo, _userId, out _result);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _dt;
        }
    }
}