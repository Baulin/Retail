﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FileHelpers
{


    public class ExcelHelper
    {
        //Row limits older excel verion per sheet, the row limit for excel 2003 is 65536
        const int rowLimit = 65000;
        public int aa = 1;
        public string bb;
        public static string getWorkbookTemplate()
        {

            var sb = new StringBuilder(818);
            sb.AppendFormat(@"<?xml version=""1.0""?>{0}", Environment.NewLine);
            sb.AppendFormat(@"<?mso-application progid=""Excel.Sheet""?>{0}", Environment.NewLine);
            sb.AppendFormat(@"<Workbook xmlns=""urn:schemas-microsoft-com:office:spreadsheet""{0}", Environment.NewLine);
            sb.AppendFormat(@" xmlns:o=""urn:schemas-microsoft-com:office:office""{0}", Environment.NewLine);
            sb.AppendFormat(@" xmlns:x=""urn:schemas-microsoft-com:office:excel""{0}", Environment.NewLine);
            sb.AppendFormat(@" xmlns:ss=""urn:schemas-microsoft-com:office:spreadsheet""{0}", Environment.NewLine);
            sb.AppendFormat(@" xmlns:html=""http://www.w3.org/TR/REC-html40"">{0}", Environment.NewLine);
            sb.AppendFormat(@" <Styles>{0}", Environment.NewLine);
            sb.AppendFormat(@"  <Style ss:ID=""Default"" ss:Name=""Normal"">{0}", Environment.NewLine);
            sb.AppendFormat(@"   <Alignment ss:Vertical=""Bottom""/>{0}", Environment.NewLine);
            sb.AppendFormat(@"   <Borders/>{0}", Environment.NewLine);
            sb.AppendFormat(@"   <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Size=""11"" ss:Color=""#003E3F""/>{0}", Environment.NewLine);
            sb.AppendFormat(@"   <Interior/>{0}", Environment.NewLine);
            sb.AppendFormat(@"   <NumberFormat/>{0}", Environment.NewLine);
            sb.AppendFormat(@"   <Protection/>{0}", Environment.NewLine);
            sb.AppendFormat(@"  </Style>{0}", Environment.NewLine);
            sb.AppendFormat(@"  <Style ss:ID=""s62"">{0}", Environment.NewLine);
            sb.AppendFormat(@"   <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Size=""12"" ss:Color=""#003E3F""{0}", Environment.NewLine);
            sb.AppendFormat(@"    ss:Bold=""1""/>{0}", Environment.NewLine);
            sb.AppendFormat(@"  </Style>{0}", Environment.NewLine);
            sb.AppendFormat(@"  <Style ss:ID=""s63"">{0}", Environment.NewLine);
            sb.AppendFormat(@"   <NumberFormat ss:Format=""Short Date""/>{0}", Environment.NewLine);
            sb.AppendFormat(@"  </Style>{0}", Environment.NewLine);
            sb.AppendFormat(@" </Styles>{0}", Environment.NewLine);
            sb.Append(@"{0}\r\n</Workbook>");
            return sb.ToString();










            //var sb = new StringBuilder(818);
            //sb.AppendFormat(@"<?xml version=""1.0""?>{0}", Environment.NewLine);
            //sb.AppendFormat(@"<?mso-application progid=""Excel.Sheet""?>{0}", Environment.NewLine);
            //sb.AppendFormat(@"<Workbook xmlns=""urn:schemas-microsoft-com:office:spreadsheet""{0}", Environment.NewLine);
            //sb.AppendFormat(@" xmlns:o=""urn:schemas-microsoft-com:office:office""{0}", Environment.NewLine);
            //sb.AppendFormat(@" xmlns:x=""urn:schemas-microsoft-com:office:excel""{0}", Environment.NewLine);
            //sb.AppendFormat(@" xmlns:ss=""urn:schemas-microsoft-com:office:spreadsheet""{0}", Environment.NewLine);
            //sb.AppendFormat(@" xmlns:html=""http://www.w3.org/TR/REC-html40"">{0}", Environment.NewLine);
            //sb.AppendFormat(@" <Styles>{0}", Environment.NewLine);
            //sb.AppendFormat(@"  <Style ss:ID=""Default"" ss:Name=""Normal"">{0}", Environment.NewLine);
            //sb.AppendFormat(@"   <Alignment ss:Vertical=""Bottom""/>{0}", Environment.NewLine);
            //sb.AppendFormat(@"   <Borders/>{0}", Environment.NewLine);
            //sb.AppendFormat(@"   <Font ss:FontName=""Calibri"" x:Family=""Swiss""  ss:Size=""11"" ss:Color=""#003E3F"" />{0}", Environment.NewLine);
            //sb.AppendFormat(@"   <Interior/>{0}", Environment.NewLine);
            //sb.AppendFormat(@"   <NumberFormat/>{0}", Environment.NewLine);
            //sb.AppendFormat(@"   <Protection/>{0}", Environment.NewLine);            
            //sb.AppendFormat(@"  </Style>{0}", Environment.NewLine);
            //sb.AppendFormat(@"  <Style ss:ID=""s62"">{0}", Environment.NewLine);
            //sb.AppendFormat(@"   <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Size=""12""  ss:Color=""#003E3F""{0}", Environment.NewLine);
            //sb.AppendFormat(@"    ss:Bold=""1""/>{0}", Environment.NewLine);
            //sb.AppendFormat(@"  </Style>{0}", Environment.NewLine);
            //sb.AppendFormat(@"  <Style ss:ID=""s63"">{0}", Environment.NewLine);
            //sb.AppendFormat(@"   <NumberFormat ss:Format=""Short Date""/>{0}", Environment.NewLine);
            //sb.AppendFormat(@"  </Style>{0}", Environment.NewLine);
            //sb.AppendFormat(@" </Styles>{0}", Environment.NewLine);
            //sb.Append(@"{0}\r\n</Workbook>");
            //return sb.ToString();
        }

        public static string replaceXmlChar(string input)
        {
            input = input.Replace("&", "&amp");
            input = input.Replace("<", "&lt;");
            input = input.Replace(">", "&gt;");
            input = input.Replace("\"", "&quot;");
            input = input.Replace("'", "&apos;");
            return input;
        }

        public static string getCell(Type type, object cellData)
        {
            var data = (cellData is DBNull) ? "" : cellData;
            if (type.Name.Contains("Int") || type.Name.Contains("Double") || type.Name.Contains("Decimal")) return string.Format("<Cell><Data ss:Type=\"Number\">{0}</Data></Cell>", data);
            if (type.Name.Contains("Date") && data.ToString() != string.Empty)
            {
                return string.Format("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"DateTime\">{0}</Data></Cell>", Convert.ToDateTime(data).ToString("yyyy-MM-dd"));
            }
            return string.Format("<Cell><Data ss:Type=\"String\">{0}</Data></Cell>", replaceXmlChar(data.ToString()));
        }
        public static string getWorksheets(DataSet source, string[] strSheetName)
        {

            ExcelHelper e = new ExcelHelper();
            var sw = new StringWriter();
            if (source == null || source.Tables.Count == 0)
            {
                sw.Write("<Worksheet ss:Name=\"Sheet1\">\r\n<Table>\r\n<Row><Cell><Data ss:Type=\"String\"></Data></Cell></Row>\r\n</Table>\r\n</Worksheet>");
                return sw.ToString();
            }
            //for (int i = 0; i < source.Tables.Count; i++) 
            //{
            //    source.Tables[i].Rows.Count
            //}
            foreach (DataTable dt in source.Tables)
            {
                if (strSheetName != null && strSheetName.Length > 0)
                {
                    switch (e.aa)
                    {
                        case 1:
                            e.bb = strSheetName.Length > 0 ? strSheetName[0].ToString() : "Sheet1";
                            break;

                        case 2:
                            e.bb = strSheetName.Length > 1 ? strSheetName[1].ToString() : "Sheet2";
                            break;

                        case 3:
                            e.bb = strSheetName.Length > 2 ? strSheetName[2].ToString() : "Sheet3";
                            break;
                        case 4:
                            e.bb = strSheetName.Length > 3 ? strSheetName[3].ToString() : "Sheet4";
                            break;
                        case 52:
                            e.bb = strSheetName.Length > 4 ? strSheetName[4].ToString() : "Sheet5";
                            break;

                    }
                }


                if (dt.Rows.Count == 0)
                // sw.Write("<Worksheet ss:Name=\"" + replaceXmlChar(dt.TableName) + "\">\r\n<Table>\r\n<Row><Cell  ss:StyleID=\"s62\"><Data ss:Type=\"String\"></Data></Cell></Row>\r\n</Table>\r\n</Worksheet>");
                {
                    var sheetCount = 0;
                    for (int i = 0; i <= dt.Rows.Count; i++)
                    {

                        if ((i % rowLimit) == 0)
                        {


                            //add close tags for previous sheet of the same data table
                            if ((i / rowLimit) > sheetCount)
                            {

                                sw.Write("\r\n</Table>\r\n</Worksheet>");
                                sheetCount = (i / rowLimit);
                            }
                            // string sss = replaceXmlChar(dt.TableName) + (((i / rowLimit) == 0) ? "" : Convert.ToString(i / rowLimit));
                            //sw.Write("\r\n<Worksheet ss:Name=\"" + replaceXmlChar(dt.TableName) +
                            //         (((i / rowLimit) == 0) ? "" : Convert.ToString(i / rowLimit)) + "\">\r\n<Table>");

                            sw.Write("\r\n<Worksheet ss:Name=\"" + e.bb + "\">\r\n<Table>");
                            //write column name row
                            sw.Write("\r\n<Row>");
                            foreach (DataColumn dc in dt.Columns)
                                sw.Write(string.Format("<Cell ss:StyleID=\"s62\"><Data ss:Type=\"String\">{0}</Data></Cell>", replaceXmlChar(dc.ColumnName)));
                            sw.Write("</Row>");



                        }
                        sw.Write("\r\n<Row>");
                        if (dt.Rows.Count > 0)
                        {
                            foreach (DataColumn dc in dt.Columns)
                                sw.Write(getCell(dc.DataType, dt.Rows[i][dc.ColumnName]));
                        }
                        else
                        {
                            Type ts = typeof(string);

                            sw.Write(getCell(ts, "NO RECORD/S FOUND !"));
                        }
                        sw.Write("</Row>");
                    }

                    sw.Write("\r\n</Table>\r\n</Worksheet>");

                }
                else
                {
                    //write each row data                
                    var sheetCount = 0;
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {

                        if ((i % rowLimit) == 0)
                        {


                            //add close tags for previous sheet of the same data table
                            if ((i / rowLimit) > sheetCount)
                            {

                                sw.Write("\r\n</Table>\r\n</Worksheet>");
                                sheetCount = (i / rowLimit);
                            }
                            // string sss = replaceXmlChar(dt.TableName) + (((i / rowLimit) == 0) ? "" : Convert.ToString(i / rowLimit));
                            //sw.Write("\r\n<Worksheet ss:Name=\"" + replaceXmlChar(dt.TableName) +
                            //         (((i / rowLimit) == 0) ? "" : Convert.ToString(i / rowLimit)) + "\">\r\n<Table>");

                            sw.Write("\r\n<Worksheet ss:Name=\"" + e.bb + "\">\r\n<Table>");
                            //write column name row
                            sw.Write("\r\n<Row>");
                            foreach (DataColumn dc in dt.Columns)
                                sw.Write(string.Format("<Cell ss:StyleID=\"s62\"><Data ss:Type=\"String\">{0}</Data></Cell>", replaceXmlChar(dc.ColumnName)));
                            sw.Write("</Row>");



                        }
                        sw.Write("\r\n<Row>");

                        foreach (DataColumn dc in dt.Columns)
                            sw.Write(getCell(dc.DataType, dt.Rows[i][dc.ColumnName]));


                        sw.Write("</Row>");
                    }

                    sw.Write("\r\n</Table>\r\n</Worksheet>");
                }
                e.aa = e.aa + 1;
            }

            return sw.ToString();
        }
        public static string GetExcelXml(DataTable dtInput, string filename, string[] strWorkSheetArry)
        {
            var excelTemplate = getWorkbookTemplate();
            var ds = new DataSet();
            ds.Tables.Add(dtInput.Copy());
            var worksheets = getWorksheets(ds, strWorkSheetArry);
            var excelXml = string.Format(excelTemplate, worksheets);
            return excelXml;
        }

        public static string GetExcelXml(DataSet dsInput, string filename, string[] strWorkSheetArry)
        {
            var excelTemplate = getWorkbookTemplate();
            var worksheets = getWorksheets(dsInput, strWorkSheetArry);
            var excelXml = string.Format(excelTemplate, worksheets);
            return excelXml;
        }

        public static void ToExcel(DataSet dsInput, string filename, HttpResponse response, string[] strWorkSheetArry)
        {
            var excelXml = GetExcelXml(dsInput, filename, strWorkSheetArry);
            response.Clear();
            response.AppendHeader("Content-Type", "application/vnd.ms-excel");
            response.AppendHeader("Content-disposition", "attachment; filename=" + filename);
            response.Write(excelXml);
            response.Flush();
            response.End();
        }

        public static void ToExcel(DataTable dtInput, string filename, HttpResponse response, string[] strWorkSheetArry)
        {
            var ds = new DataSet();
            ds.Tables.Add(dtInput.Copy());
            ToExcel(ds, filename, response, strWorkSheetArry);
        }

        public static void ExportDataSetToExcel(DataSet resultSet, string fileName, HttpResponse httpResponse)
        {
            #region VARIABLES
            DataGrid dataGrid = null;
            GridView gridView = null;
            GridViewRow gridViewRow = null;
            StringWriter stringWriter = new StringWriter();
            HtmlTextWriter htmlTextWriter = new HtmlTextWriter(stringWriter);
            HttpResponse response = null;
            #endregion

            try
            {
                if (httpResponse != null)
                {
                    response = httpResponse;

                    string style = @"<style> .textmode { mso-number-format:\@; } </style>";

                    response.Clear();
                    response.Buffer = true;
                    response.AddHeader("content-disposition", "attachment;filename=" + fileName + ".xls");
                    response.Charset = "";
                    response.ContentType = "application/vnd.ms-excel";
                    response.Write(style);

                    if (resultSet != null && resultSet.Tables.Count > 0)
                    {
                        foreach (DataTable resultDt in resultSet.Tables)
                        {
                            gridView = new GridView();
                            gridView.DataSource = resultDt;
                            gridView.DataBind();

                            gridView.AllowPaging = false;
                            gridView.HeaderRow.Style.Add("background-color", "#FFFFFF");
                            gridView.HeaderRow.ForeColor = Color.White;
                            gridView.BorderColor = Color.Black;
                            gridView.Font.Size = 10;

                            for (int i = 0; i < gridView.Rows.Count; i++)
                            {
                                gridViewRow = gridView.Rows[i];
                                gridViewRow.BackColor = Color.White;
                                gridViewRow.Attributes.Add("class", "textmode");
                            }

                            dataGrid = new DataGrid();
                            dataGrid.DataSource = resultDt;
                            dataGrid.DataBind();

                            for (int z = 0; z < dataGrid.Items[0].Cells.Count; z++)
                            {
                                gridView.HeaderRow.Cells[z].Style.Add("background-color", "#7F7F7F");
                                gridView.HeaderRow.Cells[z].BorderColor = Color.Black;
                            }

                            gridView.RenderControl(htmlTextWriter);
                            htmlTextWriter.WriteBreak();
                        }

                        response.Output.Write(stringWriter.ToString());
                        response.Flush();
                        response.End();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
