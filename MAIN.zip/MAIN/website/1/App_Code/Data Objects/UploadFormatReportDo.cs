﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace DataObjects
{
    /// <summary>
    /// Summary description for UploadFormatReportDo
    /// </summary>
    public class UploadFormatReportDo
    {
        public UploadFormatReportDo() { }

        public string ReportType { get; set; }
        public string ProductType { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }
}