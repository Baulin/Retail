﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utilities.Enums;

namespace DataObjects.Error
{
    /// <summary>
    /// Summary description for ErrorDo
    /// </summary>
    public class ErrorDo
    {
        public String ErrorMessage { get; set; }
        public ErrorMessageType ErrorMessageType { get; set; }
    }
}