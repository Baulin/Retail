﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace DataObjects
{
    /// <summary>
    /// Summary description for UnoLeadBucketDo
    /// </summary>
    public class UnoLeadBucketDo : PaginationDo
    {
        public List<UnoLeadDo> UnoLeadBucket { get; set; }
        public Int64 RecordCount { get; set; }
    }
}