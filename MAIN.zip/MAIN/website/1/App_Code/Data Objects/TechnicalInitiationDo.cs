﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DataObjects
{
    /// <summary>
    /// Summary description for TechnicalInitiation
    /// </summary>
    public class TechnicalInitiationDo
    {
        public int LeadId { get; set; }
        public DateTime? VALStartDate { get; set; }
        public DateTime? VALResolveDate { get; set; }
        public DateTime? FIStartDate { get; set; }
        public DateTime? FIResolveDate { get; set; }
        public DateTime? RCUStartDate { get; set; }
        public DateTime? RCUResolveDate { get; set; }
    }
}