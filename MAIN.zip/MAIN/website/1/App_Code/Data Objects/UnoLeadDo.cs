﻿using System;
namespace DataObjects
{
    /// <summary>
    /// Summary description for UnoLeadDo
    /// </summary>
    public class UnoLeadDo : BaseDo
    {
        public Int64 UN_LD_BUK_ID { get; set; }
        public String UN_LD_NO { get; set; }
        public String UN_APPL_NAME { get; set; }
        public String UN_MOB_NO { get; set; }
        public String UN_BR_CODE { get; set; }
        public String UN_BR_NAME { get; set; }
        public String UN_PROD_CODE { get; set; }
        public String UN_PROD_DESC { get; set; }
        public String UN_RECPT_NO { get; set; }
        public String UN_RECPT_TYPE { get; set; }
        public String UN_RECPT_AMT { get; set; }
        public String UN_CBY { get; set; }
        public String UN_CDATE { get; set; }
        public String UN_RTS_IMPORT_DATE { get; set; }
        public Int64 UN_RTS_PROC_STAT { get; set; }
        public Int64 UN_RTS_MBY { get; set; }
        public String UN_RTS_MDATE { get; set; }
    }
}