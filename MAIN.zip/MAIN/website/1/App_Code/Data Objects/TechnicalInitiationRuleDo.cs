﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utilities;
namespace DataObjects
{
    /// <summary>
    /// Summary description for TechnicalInitiationRuleDo
    /// </summary>
    public class TechnicalInitiationRuleDo
    {
        public int RuleID { get; set; }
        public int ProductID { get; set; }
        public bool IsRuleApplicable { get; set; }
        public string FIInitiation { get; set; }
        public string RCUInitiation { get; set; }
        public string VALInitiation { get; set; }
    }
}