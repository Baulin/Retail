﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utilities.Enums;

/// <summary>
/// Summary description for BaseDo
/// </summary>
public class BaseDo
{
    public Int64 UserId { get; set; }
    public Int64 UserAccessId { get; set; }
    public Int64 StateId { get; set; }
    public Int64 DivisionId { get; set; }
    public Int64 AreaId { get; set; }
    public Int64 BranchId { get; set; }
    public Boolean Status { get; set; }
    public ErrorSeverity ErrorSeverity { get; set; }
    public String Message { get; set; }
}