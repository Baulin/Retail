﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utilities.Enums;

/// <summary>
/// Summary description for BaseDo
/// </summary>
public class PaginationDo : BaseDo
{
    public Int64 PageNumber { get; set; }
    public Int64 RecordsPerPage { get; set; }
    public String SortBy { get; set; }
    public SortDirection SortDirection { get; set; }
}