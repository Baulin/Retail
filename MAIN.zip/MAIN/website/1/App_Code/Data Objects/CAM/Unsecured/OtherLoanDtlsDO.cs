﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace DataObjects.CAM.Unsecured
{
    /// <summary>
    /// Summary description for OtherLoanDtlsDO
    /// </summary>
    public class OtherLoanDtlsDO
    {
        public Int64 UOLD_UCAM_ID { get; set; }
        public Int64 UOLD_LD_ID { get; set; }
        public String UOLD_FIN { get; set; }
        public String UOLD_LN_TYPE_ID { get; set; }
        public String UOLD_LN_TYPE { get; set; }
        public Double UOLD_SANC_AMT { get; set; }
        public Double UOLD_OUTSTD_AMT { get; set; }
        public Double UOLD_EMI_AMT { get; set; }
        public Int64 UOLD_TENOR { get; set; }
        public Boolean UOLD_STAT { get; set; }
    }
}