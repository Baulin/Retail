﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace DataObjects.CAM.Unsecured
{
    /// <summary>
    /// Summary description for ESFBLoanDtlsDO
    /// </summary>
    public class ESFBLoanDtlsDO
    {
        public Int64 UELD_ID { get; set; }
        public Int64 UELD_CAM_ID { get; set; }
        public Int64 UELD_CUST_TYPE_ID { get; set; }
        public String UELD_ESFB_LN_AGRMNT { get; set; }
        public String UELD_ESFB_PR_NAME { get; set; }
        public Double UELD_ESFB_LN_AMT { get; set; }
        public Double UELD_ESFB_LN_OS_AMT { get; set; }
    }
}