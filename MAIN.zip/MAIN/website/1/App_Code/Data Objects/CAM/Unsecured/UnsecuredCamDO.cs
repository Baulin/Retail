﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace DataObjects.CAM.Unsecured
{
    /// <summary>
    /// Summary description for UnsecuredCamDO
    /// </summary>
    public class UnsecuredCamDO
    {
        public String UCAM_LD_ID { get; set; }
        public String UCAM_CAM_TYPE { get; set; }
        public String UCAM_APPL_NAME { get; set; }
        public String UCAM_AR_ID { get; set; }
        public String UCAM_AR_NAME { get; set; }
        public String UCAM_BR_ID { get; set; }
        public String UCAM_BR_NAME { get; set; }
        public String UCAM_RES_ADDRESS { get; set; }
        public String UCAM_CONTACT_NO { get; set; }
        public String UCAM_LIAB_BR_ID { get; set; }
        public String UCAM_LIAB_BR_NAME { get; set; }
        public String UCAM_UCIC_NO { get; set; }
        public String UCAM_CUST_REQ_AMT { get; set; }
        public String UCAM_CUST_CTGRY_ID { get; set; }
        public String UCAM_CUST_CTGRY { get; set; }
        public String UCAM_EXST_LN_AGRMNT { get; set; }
        public String UCAM_PR_NAME { get; set; }
        public String UCAM_EXST_LN_AMT { get; set; }
        public String UCAM_PRPTY_TYPE_ID { get; set; }
        public String UCAM_PRPTY_TYPE { get; set; }
        public String UCAM_OCC_STAT_ID { get; set; }
        public String UCAM_OCC_STAT { get; set; }
        public String UCAM_USG_ID { get; set; }
        public String UCAM_USG { get; set; }
        public String UCAM_OTH_DT_MON_INC_FRM_BSNS { get; set; }
        public String UCAM_OTH_DT_FACT_PRCNT { get; set; }
        public String UCAM_OTH_DT_FIN_INC { get; set; }
        public String UCAM_OTH_DT_POP_CITY { get; set; }
        public String UCAM_TOT_SAL_ASSMT { get; set; }
        public String UCAM_FACT_PRCNT { get; set; }
        public String UCAM_FACT_DEV_PRCNT { get; set; }
        public String UCAM_SAL_AFTR_FACTR { get; set; }
        public String UCAM_TOT_OUT_AMT { get; set; }
        public String UCAM_ESFB_LMT_ELIG { get; set; }
        public String UCAM_FIN_ESFB_LMT_ELIG { get; set; }
        public String UCAM_REMARKS { get; set; }
        public String UCAM_STAT { get; set; }
        public String UCAM_CRTD_BY { get; set; }
        public String UCAM_CRTD_DT { get; set; }
        public String UCAM_MDFD_BY { get; set; }
        public String UCAM_MDFD_DT { get; set; }
    }
}