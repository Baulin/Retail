﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace DataObjects.CAM.Unsecured
{
    /// <summary>
    /// Summary description for BusinessDtlsDO
    /// </summary>
    public class BusinessDtlsDO
    {
        public BusinessDtlsDO()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}