﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace DataObjects.CAM.Unsecured
{
    /// <summary>
    /// Summary description for FileCreditScoreDo
    /// </summary>
    public class FileCreditScoreDo
    {
        public String FCS_ID { get; set; }
        public String FCS_CAM_ID { get; set; }
        public String FCS_LD_ID { get; set; }
        public String FCS_BSNS_VINT_ID { get; set; }
        public String FCS_MON_INC_FRM_BSNS_ID { get; set; }
        public String FCS_CR_HIST_ID { get; set; }
        public String FCS_RES_PREM_OWND_ID { get; set; }
        public String FCS_BSNS_PREM_OWND_ID { get; set; }
        public String FCS_LIMT_PRCNT_TRNOVR_ID { get; set; }
        public String FCS_SCORE { get; set; }
        public String FCS_DEFN { get; set; }
    }
}