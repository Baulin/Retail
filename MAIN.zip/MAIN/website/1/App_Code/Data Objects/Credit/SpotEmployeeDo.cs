﻿using System;

namespace DataObjects.Credit
{
    /// <summary>
    /// Summary description for SpotEmployeeDo
    /// </summary>
    public class SpotEmployeeDo
    {
        public Int64 SpotId { get; set; }
        public Int64 SpotLeadId { get; set; }
        public string EmployeeNo { get; set; }
        public String EmployeeName { get; set; }
        public String EmployeeEmail { get; set; }
        public String BranchResponse { get; set; }
        public String BranchResponseBy { get; set; }
        public Int64 Status { get; set; }
        public Int64 CreatedBy { get; set; }
        public String CreatedDt { get; set; }
        public Int64 ModifiedBy { get; set; }
        public String ModifiedDt { get; set; }
    }
}