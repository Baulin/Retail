﻿var $maxLength = 2000;
var $creditConditionMsgPanel = 'creditConditionMsgPanel';
var $deviationsMsgPanel = 'deviationsMsgPanel';

function ValidateMaxlength(ev, $objTextArea) {
    let $charCount;
    let $charsRemaining;
    let $regex = /^[A-Za-z0-9]+$/;
    if ($objTextArea !== null) {

        $charCount = $objTextArea.val().length;

        if (($charCount == $maxLength) || ($charCount > $maxLength)) {
            $objTextArea.val($objTextArea.val().substring(0, $maxLength));
            NotifyCharCount(false);
            return false;
        }
        else {
            $charsRemaining = $maxLength - $charCount;
            NotifyCharCount(true, $charsRemaining);
            return true;
        }
    }
}

function ValidateCreditConditionMaxlength(ev, $objTextArea) {
    let $charCount;
    let $charsRemaining;
    let $regex = /^[A-Za-z0-9]+$/;
    if ($objTextArea !== null) {

        $charCount = $objTextArea.val().length;

        if (($charCount == $maxLength) || ($charCount > $maxLength)) {
            $objTextArea.val($objTextArea.val().substring(0, $maxLength));
            NotifyCharCount(false, null, $creditConditionMsgPanel);
            return false;
        }
        else {
            $charsRemaining = $maxLength - $charCount;
            NotifyCharCount(true, $charsRemaining, $creditConditionMsgPanel);
            return true;
        }
    }
}

function ValidateDeviationMaxlength(ev, $objTextArea) {
    let $charCount;
    let $charsRemaining;
    let $regex = /^[A-Za-z0-9]+$/;
    if ($objTextArea !== null) {

        $charCount = $objTextArea.val().length;

        if (($charCount == $maxLength) || ($charCount > $maxLength)) {
            $objTextArea.val($objTextArea.val().substring(0, $maxLength));
            NotifyCharCount(false, null, $deviationsMsgPanel);
            return false;
        }
        else {
            $charsRemaining = $maxLength - $charCount;
            NotifyCharCount(true, $charsRemaining, $deviationsMsgPanel);
            return true;
        }
    }
}

function NotifyCharCount($isValid, $count) {
    var $msgCntnr = $('.' + 'msgPanel');

    if ($msgCntnr != null) {
        if ($isValid) { $msgCntnr.html($count + " characters remaining"); }
        else { $msgCntnr.html("Please enter only " + $maxLength + " characters"); }
    }
}

function NotifyCharCount($isValid, $count, $msgPanel) {
    var $msgCntnr = $('.' + $msgPanel);

    if ($msgCntnr != null) {
        if ($isValid) { $msgCntnr.html($count + " characters remaining"); }
        else { $msgCntnr.html("Please enter only " + $maxLength + " characters"); }
    }
}