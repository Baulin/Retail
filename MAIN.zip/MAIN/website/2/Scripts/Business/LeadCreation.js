﻿function LeadCreation() {

    var UnoLead = document.getElementById('MainContent_txtUnoLeadNo');
    var Product = document.getElementById('MainContent_ddlProduct');
    var stsourcingbrnch = document.getElementById('MainContent_ddlstsourcingbrnch');
    var Member = document.getElementById('MainContent_ddlMember');
    var Sourcetype = document.getElementById('MainContent_ddlSourcetype');
    //var Rocode = document.getElementById('MainContent_ddlRocode');
    var Appname = document.getElementById('MainContent_txtAppname');
    var Mobileno = document.getElementById('MainContent_txtMobileno');
    var Memid = document.getElementById('MainContent_txtMemid');
    var ddllgnfee = document.getElementById('MainContent_ddlloginfee');
    var lgnfee = document.getElementById('MainContent_txtloginfee');
    var ddlinstrument = document.getElementById('MainContent_ddlinstrument');
    var instrumentno = document.getElementById('MainContent_txtinstrument');
    var ddlst_fle_hndle_type = document.getElementById('MainContent_ddlst_fle_hndle_type');
    var ddlst_fle_hndle_by = document.getElementById('MainContent_ddlst_fle_hndle_by');
    var ddlSourcetype = Sourcetype.options[Sourcetype.selectedIndex].text;

    //if (UnoLead.value == "") {
    //    alert('Please select UNO Lead');
    //    return false;
    //}
    if (Product.selectedIndex == 0) {

        alert('Please select the product');

        Product.focus();

        return false;
    }
    if (Product.value.search(/G/g) !== -1) {

        if (stsourcingbrnch.selectedIndex == 0) {
            alert('Please select the sourcing branch');
            stsourcingbrnch.focus();
            return false;
        }
    }
    if (Member.selectedIndex == 0) {
        
        alert('Please select the Is Member');
        Member.focus();
        return false;
    }


    if (Sourcetype.selectedIndex == 0) {
        alert('Please select the source type');
        Sourcetype.focus();
        return false;
    }
    /*if (Rocode.selectedIndex == 0) {
        alert('Please select the RO/SO Code');
        Rocode.focus();
        return false;
    }*/
    if (Member.selectedIndex == 1) {
        if (Memid.value == "") {
            alert('Please enter the Member ID');
            Memid.focus();
            return false;
        }
    }
    if (Appname.value == "") {
        alert('Please enter applicant name');
        Appname.focus();
        return false;
    }
    if (Mobileno.value == "") {
        alert('Please enter the mobile no');
        Mobileno.focus(); return false;
    }
    if (Mobileno.value.length < 10) {
        alert('Please enter the full mobile no');
        Mobileno.focus(); return false;
    }
    if (ddllgnfee.selectedIndex == 0) {
        alert('Please select the Login Fee Applicable');
        ddllgnfee.focus(); return false;
    }
    if (ddllgnfee.selectedIndex == 1 && lgnfee.value == "") {
        alert('Please enter the Login Fee');
        lgnfee.focus(); return false;
    }
    if (ddllgnfee.selectedIndex == 1 && lgnfee.value == 0) {
        alert('Please enter the Valid Amount.');
        lgnfee.focus(); return false;
    }
    if (ddllgnfee.selectedIndex == 1 && ddlinstrument.selectedIndex == 0) {
        alert('Please select the Nature of Instrument');
        ddlinstrument.focus(); return false;
    }

    if (ddllgnfee.selectedIndex == 1 && ddlinstrument.selectedIndex != 0 && instrumentno.value == "")
    {
        alert('Please Enter the Instrument number');
        instrumentno.focus(); return false;
    }
    if (ddllgnfee.selectedIndex == 1 && ddlinstrument.selectedIndex != 0 && instrumentno.value == 0) {
        alert('Please Enter the valid Instrument number');
        instrumentno.focus(); return false;
    }
    if (ddlst_fle_hndle_type.selectedIndex == 0 && Sourcetype.selectedIndex > 0 && ddlSourcetype == "Telecaller") {
        alert('Please select the File Handled By Type.');
        ddlst_fle_hndle_type.focus(); return false;
    }
    if (ddlst_fle_hndle_by.selectedIndex == 0 && Sourcetype.selectedIndex > 0 && ddlSourcetype == "Telecaller") {
        alert('Please select the File Handled By.');
        ddlst_fle_hndle_by.focus(); return false;
    }
    return true;
}
function IsMemberFocus() {

    var Product = document.getElementById('MainContent_ddlProduct');
    var stsourcingbrnch = document.getElementById('MainContent_ddlstsourcingbrnch');
    var Member = document.getElementById('MainContent_ddlMember');
    var Sourcetype = document.getElementById('MainContent_ddlSourcetype');
    //var Rocode = document.getElementById('MainContent_ddlRocode');
    var Appname = document.getElementById('MainContent_txtAppname');
    var Mobileno = document.getElementById('MainContent_txtMobileno');
    var Memid = document.getElementById('MainContent_txtMemid');


    if (Product.selectedIndex == 0) {

        alert('Please select the product');

        Product.focus();

        return false;
    }
    if (Product.value.search(/G/g) !== -1) {

        if (stsourcingbrnch.selectedIndex == 0) {
            alert('Please select the sourcing branch');
            stsourcingbrnch.focus();
            return false;
        }
    }
    return true;
}

function SourceTypeFocus() {

    var Product = document.getElementById('MainContent_ddlProduct');
    var stsourcingbrnch = document.getElementById('MainContent_ddlstsourcingbrnch');
    var Member = document.getElementById('MainContent_ddlMember');
    var Sourcetype = document.getElementById('MainContent_ddlSourcetype');
   // var Rocode = document.getElementById('MainContent_ddlRocode');
    var Appname = document.getElementById('MainContent_txtAppname');
    var Mobileno = document.getElementById('MainContent_txtMobileno');
    var Memid = document.getElementById('MainContent_txtMemid');


    if (Product.selectedIndex == 0) {

        alert('Please select the product');

        Product.focus();

        return false;
    }
    if (Product.value.search(/G/g) !== -1) {

        if (stsourcingbrnch.selectedIndex == 0) {
            alert('Please select the sourcing branch');
            stsourcingbrnch.focus();
            return false;
        }
    }
    if (Member.selectedIndex == 0) {

        alert('Please select the Is Member');
        Member.focus();
        return false;
    }

    return true;
}

function RCodeFocus() {

    var Product = document.getElementById('MainContent_ddlProduct');
    var stsourcingbrnch = document.getElementById('MainContent_ddlstsourcingbrnch');
    var Member = document.getElementById('MainContent_ddlMember');
    var Sourcetype = document.getElementById('MainContent_ddlSourcetype');
    //var Rocode = document.getElementById('MainContent_ddlRocode');
    var Appname = document.getElementById('MainContent_txtAppname');
    var Mobileno = document.getElementById('MainContent_txtMobileno');
    var Memid = document.getElementById('MainContent_txtMemid');


    if (Product.selectedIndex == 0) {

        alert('Please select the product');

        Product.focus();

        return false;
    }
    if (Product.value.search(/G/g) !== -1) {

        if (stsourcingbrnch.selectedIndex == 0) {
            alert('Please select the sourcing branch');
            stsourcingbrnch.focus();
            return false;
        }
    }
    if (Member.selectedIndex == 0) {

        alert('Please select the Is Member');
        Member.focus();
        return false;
    }


    if (Sourcetype.selectedIndex == 0) {
        alert('Please select the source type');
        Sourcetype.focus();
        return false;
    }
    return true;
}

function MemIDFocus() {

    var Product = document.getElementById('MainContent_ddlProduct');
    var stsourcingbrnch = document.getElementById('MainContent_ddlstsourcingbrnch');
    var Member = document.getElementById('MainContent_ddlMember');
    var Sourcetype = document.getElementById('MainContent_ddlSourcetype');
    //var Rocode = document.getElementById('MainContent_ddlRocode');
    var Appname = document.getElementById('MainContent_txtAppname');
    var Mobileno = document.getElementById('MainContent_txtMobileno');
    var Memid = document.getElementById('MainContent_txtMemid');


    if (Product.selectedIndex == 0) {

        alert('Please select the product');

        Product.focus();

        return false;
    }
    if (Product.value.search(/G/g) !== -1) {

        if (stsourcingbrnch.selectedIndex == 0) {
            alert('Please select the sourcing branch');
            stsourcingbrnch.focus();
            return false;
        }
    }
    if (Member.selectedIndex == 0) {

        alert('Please select the Is Member');
        Member.focus();
        return false;
    }


    if (Sourcetype.selectedIndex == 0) {
        alert('Please select the source type');
        Sourcetype.focus();
        return false;
    }
   /* if (Rocode.selectedIndex == 0) {
        alert('Please select the RO/SO Code');
        Rocode.focus();
        return false;
    }*/
    return true;
}
function AppNameFocus() {

    var Product = document.getElementById('MainContent_ddlProduct');
    var stsourcingbrnch = document.getElementById('MainContent_ddlstsourcingbrnch');
    var Member = document.getElementById('MainContent_ddlMember');
    var Sourcetype = document.getElementById('MainContent_ddlSourcetype');
   // var Rocode = document.getElementById('MainContent_ddlRocode');
    var Appname = document.getElementById('MainContent_txtAppname');
    var Mobileno = document.getElementById('MainContent_txtMobileno');
    var Memid = document.getElementById('MainContent_txtMemid');


    if (Product.selectedIndex == 0) {

        alert('Please select the product');

        Product.focus();

        return false;
    }
    if (Product.value.search(/G/g) !== -1) {

        if (stsourcingbrnch.selectedIndex == 0) {
            alert('Please select the sourcing branch');
            stsourcingbrnch.focus();
            return false;
        }
    }
    if (Member.selectedIndex == 0) {

        alert('Please select the Is Member');
        Member.focus();
        return false;
    }


    if (Sourcetype.selectedIndex == 0) {
        alert('Please select the source type');
        Sourcetype.focus();
        return false;
    }
   /* if (Rocode.selectedIndex == 0) {
        alert('Please select the RO/SO Code');
        Rocode.focus();
        return false;
    }*/
    if (Member.selectedIndex == 1) {
        if (Memid.value == "") {
            alert('Please enter the Member ID');
            Memid.focus();
            return false;
        }
    }
    return true;
}
function MobileFocus() {

    var Product = document.getElementById('MainContent_ddlProduct');
    var stsourcingbrnch = document.getElementById('MainContent_ddlstsourcingbrnch');
    var Member = document.getElementById('MainContent_ddlMember');
    var Sourcetype = document.getElementById('MainContent_ddlSourcetype');
   // var Rocode = document.getElementById('MainContent_ddlRocode');
    var Appname = document.getElementById('MainContent_txtAppname');
    var Mobileno = document.getElementById('MainContent_txtMobileno');
    var Memid = document.getElementById('MainContent_txtMemid');


    if (Product.selectedIndex == 0) {

        alert('Please select the product');

        Product.focus();

        return false;
    }
    if (Product.value.search(/G/g) !== -1) {

        if (stsourcingbrnch.selectedIndex == 0) {
            alert('Please select the sourcing branch');
            stsourcingbrnch.focus();
            return false;
        }
    }
    if (Member.selectedIndex == 0) {

        alert('Please select the Is Member');
        Member.focus();
        return false;
    }


    if (Sourcetype.selectedIndex == 0) {
        alert('Please select the source type');
        Sourcetype.focus();
        return false;
    }
   /* if (Rocode.selectedIndex == 0) {
        alert('Please select the RO/SO Code');
        Rocode.focus();
        return false;
    }*/
    if (Member.selectedIndex == 1) {
        if (Memid.value == "") {
            alert('Please enter the Member ID');
            Memid.focus();
            return false;
        }
    }
    if (Appname.value == "") {
        alert('Please enter applicant name');
        Appname.focus();
        return false;
    }
    return true;
}

function ReferenceSource() {
    var Product = document.getElementById('MainContent_ddlProduct');
    var stsourcingbrnch = document.getElementById('MainContent_ddlstsourcingbrnch');
    var Member = document.getElementById('MainContent_ddlMember');
    var Sourcetype = document.getElementById('MainContent_ddlSourcetype');
   // var Rocode = document.getElementById('MainContent_ddlRocode');
    var Appname = document.getElementById('MainContent_txtAppname');
    var Mobileno = document.getElementById('MainContent_txtMobileno');
    var Memid = document.getElementById('MainContent_txtMemid');
    var rocode = document.getElementById('MainContent_ddlRocode');


    if (Product.selectedIndex == 0) {

        alert('Please select the product');

        Product.focus();

        return false;
    }
    if (Product.value.search(/G/g) !== -1) {

        if (stsourcingbrnch.selectedIndex == 0) {
            alert('Please select the sourcing branch');
            stsourcingbrnch.focus();
            return false;
        }
    }
    if (Member.selectedIndex == 0) {

        alert('Please select the Is Member');
        Member.focus();
        return false;
    }
    if (Sourcetype.selectedIndex == 0) {
        alert('Please select the source type');
        Sourcetype.focus();
        return false;
    }
   /* if (rocode.selectedIndex == 0) {
        alert('Please select RO code');
        rocode.focus();
        return false;
    }*/
    return true;
}