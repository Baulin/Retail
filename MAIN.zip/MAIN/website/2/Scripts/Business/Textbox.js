﻿function validation() {
    var txtbx_first = document.getElementById('MainContent_txtbxnt1');
    if (txtbx_first.value.trim() == "") {
        alert('Please enter note 4');
        txtbx_third.text = "";
        txtbx_second.text = "";
        txtbx_first.focus();
        return false;

    }

    return true;
}
function validation1() {
    var txtbx_first = document.getElementById('MainContent_txtbxnt1');
    var txtbx_second = document.getElementById('MainContent_txtbxnt2');
    var txtbx_third = document.getElementById('MainContent_txtbxnt3');
    if (txtbx_first.value.trim() == "") {
        alert('Please enter note 4');
        txtbx_third.value = "";
        txtbx_second.value = "";
        txtbx_first.focus();
        return false;

    }
    return true;
}
function validation2() {


    var txtbx_first = document.getElementById('MainContent_txtbxnt1');
    var txtbx_second = document.getElementById('MainContent_txtbxnt2');
    var txtbx_third = document.getElementById('MainContent_txtbxnt3');

    if (txtbx_first.value.trim() == "") {
        alert('Please enter note 4');
        txtbx_third.value = "";
        txtbx_second.value = "";
        txtbx_first.focus();
        return false;

    }
    else if (txtbx_second.value.trim() == "") {

        alert('Please enter note 5');
        txtbx_second.value = "";
        txtbx_third.value = "";
        txtbx_second.focus();
        return false;
    }

    return true;
}

function validation3() {
    var txtbx_first = document.getElementById('MainContent_txtbxtitleofopinion');
    var txtbx_second = document.getElementById('MainContent_txtbxtitleofopinion1');
 
    if (txtbx_first.value.trim() == "") {
        alert('Please enter the title of Opinion');
        
        txtbx_second.value = "";
        txtbx_first.focus();
        return false;

    }
    return t2keyup();
}
function t2keyup() {

    if (document.getElementById('MainContent_btnaddT1').disabled) {
        document.getElementById('MainContent_btnaddT1').disabled = false;

    }
    return true;
}
