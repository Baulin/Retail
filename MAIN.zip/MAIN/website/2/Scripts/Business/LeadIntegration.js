﻿$(document).ready(function () {

    let $unoLeadDo = {};
    let $userId = 0;
    let $errorSeverity = { 'Hint': 0, 'Warning': 1, 'Error': 2, 'Fatal': 3 };
    let $currErrSeverity = null;

    //helper css variables
    let $display = 'display';
    let $show = 'show';
    let $hide = 'hide';

    var $refreshButton = $('#' + 'btnRefresh');
    var $unoLeadBucketDataTable = {};
    var $unoLeadBucket = $('#' + 'tblUnoLeadBucket');
    var $modal = $('#' + 'unoLeadModal');
    var $modalMessage = $('.' + 'modalMessage');
    var globalFunctionObject;
    var $genericErrorMessage = "Unexpected Error Occured. Please try later.";
    var $navMenu = $('.hideSkiplink');

    //Init DataTable
    function InitDataTable() {
        $unoLeadBucketDataTable = $unoLeadBucket.DataTable({
            scrollX: false,
            scrollY: true,
            scrollCollapse: true,
            paging: true,
            order: [[0, 'asc']],
            searching: true,
            info: false,
            fnDrawCallback: BindLeadActions,
            autoWidth: true,
            responsive: true,
            language: {
                emptyTable: "No data available",
                processing: "<div class='overlay custom-loader-background'><i class='fa fa-cog fa-spin custom-loader-color'></i></div>"
            },
            columns: [
                {
                    title: "UNO_Lead_Number_Bucket_ID",
                    data: "UN_LD_BUK_ID",
                    width: "0%",
                    visible: false
                },
                {
                    title: "Lead Number",
                    data: "UN_LD_NO",
                    width: "5%"
                },
                {
                    title: "Applicant Name",
                    data: "UN_APPL_NAME",
                    width: "20%"
                },
                {
                    title: "Phone Number",
                    data: "UN_MOB_NO",
                    width: "10%"
                },
                {
                    title: "Branch",
                    data: "UN_BR_NAME",
                    width: "10%",
                },
                {
                    title: "Product",
                    data: "UN_PROD_DESC",
                    width: "11%"
                },
                {
                    title: "Receipt Number",
                    data: "UN_RECPT_NO",
                    width: "10%"
                },
                {
                    title: "Receipt Type",
                    data: "UN_RECPT_TYPE",
                    width: "7%"
                },
                {
                    title: "Receipt Amount",
                    data: "UN_RECPT_AMT",
                    width: "10%"
                },
                {
                    title: "Lead Status",
                    data: null,
                    render: function (data) {
                        let status = "";
                        if (data.UN_RTS_PROC_STAT == 1) {
                            status = "<p class=text-info>Not Started</p>";
                        } else if (data.UN_RTS_PROC_STAT == 2) {
                            status = "<p class=text-warning>In progress</p>";
                        }
                        else if (data.UN_RTS_PROC_STAT == 3) {
                            status = "<p class=text-success>Completed</p>";
                        }
                        return status;
                    },
                    width: "10%"
                },
                {
                    title: "Action",
                    data: null,
                    render: function (data) {

                        let button = '';
                        button = RenderDataTableActionButton(data);
                        return button;
                    },
                    width: "7%"
                }
            ]
        });

        //$unoLeadBucket.on('order.dt', function () { BindLeadActions(); }); //SORT Event Listener
        //$unoLeadBucket.on('page.dt', function () { BindLeadActions(); }); //PAGING Event Listener
        //$unoLeadBucket.on('search.dt', function () { BindLeadActions(); }); //SEARCH Event Listener
    }

    function RenderDataTableActionButton(rowData) {

        let btnText, jsClass, cssClass, attrClass, unoLeadId, unoLeadNo, button = '';
        cssClass = "btn btn-block";

        if (rowData.UN_RTS_PROC_STAT == 1) {
            btnText = 'Pick';
            jsClass = "js-pickLead";
            cssClass = cssClass + " btn-info";
            attrClass = jsClass + " " + cssClass;
            button = '<button type=button class="' + attrClass + '">' + btnText + '</button>';
            return button;
        }
        else if (rowData.UN_RTS_PROC_STAT == 2) {

            if (rowData.UN_RTS_MBY == $userId) {

                let $divBtnGrp = '<div class="btn-group btn-block js-UnlockDiv" role="group">' +
                            '<button id="btnGroupSelect" type="button" class="btn btn-block btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Select</button>' +
                            '<div class="dropdown-menu btnMd" aria-labelledby="btnGroupSelect">' +
                            '<li>' +
                            '<a class="dropdown-item js-continueLead" href="#">Continue</a>' +
                            '<a class="dropdown-item js-unlockLead" href="#">Unlock</a>' +
                            '</li>' +
                            '</div>' +
                            '</div>'
                return $divBtnGrp;
            }
            else {
                btnText = 'Locked';
                jsClass = "js-lockedLead";
                cssClass = cssClass + " btn-danger";
                attrClass = jsClass + " " + cssClass;
                button = '<button type=button class="' + attrClass + '">' + btnText + '</button>';
                return button;
            }
        }
        else if (rowData.UN_RTS_PROC_STAT == 3) {
            btnText = 'Completed';
            jsClass = "js-viewLead";
            cssClass = cssClass + " btn-success";
            attrClass = jsClass + " " + cssClass;
            button = '<button type=button class="' + attrClass + '">' + btnText + '</button>';
            return button;
        }
    }

    function RenderUnoLeadBucketDataTable(unoLeadBucketDo) {
        if ($unoLeadBucketDataTable !== null && $unoLeadBucketDataTable !== undefined) {
            $unoLeadBucketDataTable.clear().draw();
            $unoLeadBucketDataTable.rows.add(unoLeadBucketDo.UnoLeadBucket);
            $unoLeadBucketDataTable.columns.adjust().draw();
        }
    }

    function BindLeadActions() {

        let $btnGrpPickLead = $('.' + 'js-pickLead');
        let $btnGrpUnlockLead = $('.' + 'js-unlockLead');
        let $btnGrpContinueLead = $('.' + 'js-continueLead');
        let $btnGrpViewLead = $('.' + 'js-viewLead');
        let $btnGrpLockedLead = $('.' + 'js-lockedLead');

        $btnGrpPickLead.off('click').on('click', function () {
            let $currRow = $(this).parents('tr');
            PickUnoLead($currRow);
        });

        $btnGrpUnlockLead.off('click').on('click', function () {
            let $divUnlockLead = $(this).parents('.js-UnlockDiv');
            let $currRow = $(this).parents('tr');
            UnlockUnoLead($currRow, $divUnlockLead);
        });

        $btnGrpContinueLead.off('click').on('click', function () {
            let $currRow = $(this).parents('tr');
            ContinueUnoLead($currRow);
        });

        $btnGrpViewLead.off('click').on('click', function () {
            return false;
        });

        $btnGrpLockedLead.off('click').on('click', function () {
            return false;
        });
    }

    function PickUnoLead($currRow) {
        let $currDataRow = {};

        if ($currRow !== null && $currRow !== undefined) {
            $currDataRow = $unoLeadBucketDataTable.row($currRow).data();

            if ($currDataRow !== null && $currDataRow !== undefined) {

                $unoLeadDo.UN_LD_BUK_ID = $currDataRow.UN_LD_BUK_ID;
                $unoLeadDo.UN_LD_NO = $currDataRow.UN_LD_NO;

                //console.log($unoLeadDo);

                let $data = { 'UnoLeadDo': $unoLeadDo };

                return $.ajax({
                    url: "Branch_LeadIntegration.aspx/PickUnoLead",
                    contentType: "application/json;charset=utf-8",
                    type: "POST",
                    dataType: "json",
                    data: JSON.stringify($data)
                })
                .done(function (response) {
                    if (response !== null && response !== undefined && response.d !== null && response.d !== undefined) {
                        let $unoLeadDo = response.d;
                        if ($unoLeadDo.Status) {
                            $currErrSeverity = null;
                            SetPickedUnoLeadData($unoLeadDo);
                        }
                        else {
                            if ($unoLeadDo.ErrorSeverity == $errorSeverity.Fatal) { $currErrSeverity = $errorSeverity.Fatal; }
                            $modalMessage.text($unoLeadDo.Message);
                            ToggleModal($show);
                        }
                    }
                })
                .fail(function (error) {
                    //console.log("Failure : PickUnoLead " + error);
                    if (error !== null && error !== undefined) {
                        //Dirty-fix to bypass CFRF issue
                        if (error.statusText == 'Unauthorized' && error.status == '401') {
                            SetPickedUnoLeadData($currDataRow);
                        }
                        else {
                            $modalMessage.text($genericErrorMessage);
                            ToggleModal($show);
                        }
                    }
                });
            }
        }
    }

    function UnlockUnoLead($currRow, $divUnlockLead) {
        let $currDataRow = {
        };

        if ($currRow !== null && $currRow !== undefined && $divUnlockLead !== null && $divUnlockLead !== undefined) {
            $currDataRow = $unoLeadBucketDataTable.row($currRow).data();

            if ($currDataRow !== null && $currDataRow !== undefined) {
                $unoLeadDo.UN_LD_BUK_ID = $currDataRow.UN_LD_BUK_ID;
                $unoLeadDo.UN_LD_NO = $currDataRow.UN_LD_NO;
                //console.log($unoLeadDo);

                let $data = {
                    'UnoLeadDo': $unoLeadDo
                };

                return $.ajax({
                    url: "Branch_LeadIntegration.aspx/UnlockUnoLead",
                    contentType: "application/json;charset=utf-8",
                    type: "POST",
                    dataType: "json",
                    data: JSON.stringify($data)
                })
                .done(function (response) {
                    if (response !== null
                        && response !== undefined
                        && response.d !== null
                        && response.d !== undefined) {

                        let $unoLeadDo = response.d;
                        if ($unoLeadDo.Status) {
                            SetUnlockedUnoLeadData($currRow, $divUnlockLead, $unoLeadDo);
                        } else {
                            if ($unoLeadDo.ErrorSeverity == $errorSeverity.Fatal) { $currErrSeverity = $errorSeverity.Fatal; }
                            $modalMessage.text($unoLeadDo.Message);
                            ToggleModal($show);
                        }
                    }
                })
                .fail(function (error) {
                    //Dirty-fix to bypass CSRF issue
                    if (error.statusText == 'Unauthorized' && error.status == '401') {
                        SetUnlockedUnoLeadDataPostError($currRow, $divUnlockLead, $unoLeadDo);
                    }
                    else {
                        $modalMessage.text($genericErrorMessage);
                        ToggleModal($show);
                    }
                });
            }
        }
    }

    function ContinueUnoLead($currRow) {
        let $currDataRow = {
        };

        if ($currRow !== null && $currRow !== undefined) {
            $currDataRow = $unoLeadBucketDataTable.row($currRow).data();

            if ($currDataRow !== null && $currDataRow !== undefined) {
                SetPickedUnoLeadData($currDataRow);
            }
        }
    }

    function GetUnoLeadBucket() {
        return $.ajax({
            url: "Branch_LeadIntegration.aspx/GetUnoLeads",
            contentType: "application/json;charset=utf-8",
            type: "GET",
            dataType: "json"
        })
            .done(function (data) {
                if (data !== null && data !== undefined && data.d !== null && data.d !== undefined) {
                    let $unoLeadBucketDo = data.d;
                    if (($unoLeadBucketDo.Status) && ($unoLeadBucketDo.RecordCount > 0)) {
                        $userId = $unoLeadBucketDo.UserId;
                        RenderUnoLeadBucketDataTable($unoLeadBucketDo);
                    } else {
                        if ($unoLeadBucketDo.ErrorSeverity == $errorSeverity.Fatal) { $currErrSeverity = $errorSeverity.Fatal; }

                        if ($unoLeadBucketDo.Message !== null || $unoLeadBucketDo.Message !== "") { $modalMessage.text($unoLeadBucketDo.Message); }
                        else { $modalMessage.text($genericErrorMessage); }

                        ToggleModal($show);
                    }
                }
            })
            .fail(function (msg) {
                console.log('FAIL - GetUnoLeadBucket');
                console.log(msg);
            });
    }

    function SetPickedUnoLeadData($unoLeadDo) {

        if (window.opener != null && !window.opener.closed) {

            var $txtUnoLeadBucket = window.opener.document.getElementById("MainContent_hdnUnoLeadBucketId");
            var $txtUnoLead = window.opener.document.getElementById("MainContent_txtUnoLeadNo");
            var $txtUnoLeadName = window.opener.document.getElementById("MainContent_txtUnoLeadName");
            var $txtUnoProdName = window.opener.document.getElementById("MainContent_txtUnoProdName");
            var $txtUnoReceiptNo = window.opener.document.getElementById("MainContent_txtUnoReceiptNo");
            var $txtUnoReceiptType = window.opener.document.getElementById("MainContent_txtUnoReceiptType");
            var $txtUnoReceiptAmt = window.opener.document.getElementById("MainContent_txtUnoReceiptAmt");
            var $txtUnoApplName = window.opener.document.getElementById("MainContent_txtAppname");
            var $txtUnoApplMobNo = window.opener.document.getElementById("MainContent_txtMobileno");
            var $txtRtsLoginFee = window.opener.document.getElementById("MainContent_txtloginfee");
            var $ddlLoginFeeAppl = $(window.opener.document.getElementById("MainContent_ddlloginfee"));
            var $instrumentNumberCntnr = $(window.opener.document.getElementById("MainContent_instrument"));

            //SET UNO Lead Data
            $txtUnoLeadBucket.value = $unoLeadDo.UN_LD_BUK_ID;
            $txtUnoLead.value = $unoLeadDo.UN_LD_NO;
            $txtUnoLeadName.value = $unoLeadDo.UN_APPL_NAME;
            $txtUnoProdName.value = $unoLeadDo.UN_PROD_DESC;
            $txtUnoReceiptNo.value = $unoLeadDo.UN_RECPT_NO;
            $txtUnoReceiptType.value = $unoLeadDo.UN_RECPT_TYPE;
            $txtUnoReceiptAmt.value = $unoLeadDo.UN_RECPT_AMT;
            $txtUnoApplName.value = $unoLeadDo.UN_APPL_NAME;
            $txtUnoApplMobNo.value = $unoLeadDo.UN_MOB_NO;

            if ($unoLeadDo.UN_RECPT_AMT > 0) {
                $ddlLoginFeeAppl.val("Y");
                $txtRtsLoginFee.value = $unoLeadDo.UN_RECPT_AMT;
            }
            else {
                $ddlLoginFeeAppl.val("N");
                $txtRtsLoginFee.value = '';
                $instrumentNumberCntnr.addClass('hide');
            }

            //RESET RTS Lead Data
            var $rtsDropdownGroup = $(window.opener.document.getElementsByClassName('js-dropDownList'));
            var $rtsTextBoxGroup = $(window.opener.document.getElementsByClassName('js-textBox'));

            if ($rtsDropdownGroup !== null && typeof $rtsDropdownGroup !== typeof undefined && $rtsDropdownGroup.length > 0) {
                $rtsDropdownGroup.each(function () {
                    if (!$(this).hasClass('js-unoInfo')) { $(this).val(-1); }
                });
            }

            if ($rtsTextBoxGroup !== null && typeof $rtsTextBoxGroup !== typeof undefined && $rtsTextBoxGroup.length > 0) {
                $rtsTextBoxGroup.each(function () {
                    if (!$(this).hasClass('js-unoInfo')) { $(this).val(""); }
                });
            }
        }

        window.close();
    }

    function SetUnlockedUnoLeadData($currRow, $divUnlockLead, $unoLeadDo) {
        let $unlockedDataRow = {
        };

        if ($divUnlockLead !== null && $divUnlockLead !== undefined && $currRow !== null && $currRow !== undefined) {

            if ($unoLeadDo !== null && $unoLeadDo !== undefined) {

                if ($unoLeadDo.UN_RTS_PROC_STAT == 1) {

                    let $leadStatus = $currRow.find('.text-warning');
                    $leadStatus.attr('class', 'text-info');
                    $leadStatus.text('Not Started');

                    let $cssClass = "js-pickLead btn btn-lg btn-block btn-info";

                    let $actionButton = $('<button type=button></button>');
                    $actionButton.attr('class', $cssClass);
                    $actionButton.text('Pick');

                    $divUnlockLead.replaceWith($actionButton);
                    BindLeadActions();
                }
            }
        }
    }

    function SetUnlockedUnoLeadDataPostError($currRow, $divUnlockLead, $unoLeadDo) {
        let $unlockedDataRow = {
        };

        if ($divUnlockLead !== null && $divUnlockLead !== undefined && $currRow !== null && $currRow !== undefined) {

            //if ($currRow !== null && $currRow !== undefined) {

            //if ($currRow.UN_RTS_PROC_STAT == 1) {

            let $leadStatus = $currRow.find('.text-warning');
            $leadStatus.attr('class', 'text-info');
            $leadStatus.text('Not Started');

            let $cssClass = "js-pickLead btn btn-lg btn-block btn-info";

            let $actionButton = $('<button type=button></button>');
            $actionButton.attr('class', $cssClass);
            $actionButton.text('Pick');

            $divUnlockLead.replaceWith($actionButton);
            BindLeadActions();
            //}
            //}
        }
    }

    function InitModal() {
        $modal.modal({ show: false });
    }

    function ToggleModal(flag) {

        if ($modal !== null && (typeof $modal !== typeof undefined) && $modal !== false) {

            if (flag === null || flag === undefined) {
                if ($modal.hasClass($show)) {
                    $modal.removeClass($show);
                    $modal.addClass($hide);
                } else if ($modal.hasClass($hide)) {
                    $modal.removeClass($hide);
                    $modal.addClass($show);
                }
            }
            else {
                if (flag == $show) {
                    $modal.modal({ show: true });
                }
                else if (flag == $hide) {
                    $modal.modal({ show: false });
                }
            }
        }
    }

    function InitPageLoad() {
        GetUnoLeadBucket().then(BindLeadActions);
    }

    function CloseModal() {

        if ($currErrSeverity == $errorSeverity.Fatal) {
            $currErrSeverity == null;
            if (window.opener !== null && !window.opener.closed) { window.close(); }
        }
    }

    //Bind page refresh on modal close
    $modal.on('hidden.bs.modal', CloseModal);
    $refreshButton.off('click').on('click', InitPageLoad);
    $navMenu.hide();

    InitModal();
    InitDataTable();
    InitPageLoad();
});