﻿$(document).ready(function () {

    let $unoLeadDo = {};
    let $userId = 0;
    let $errorSeverity = { 'Hint': 0, 'Warning': 1, 'Error': 2, 'Fatal': 3 };
    let $currErrSeverity = null;

    //helper css variables
    let $display = 'display';
    let $show = 'show';
    let $hide = 'hide';

    var $refreshButton = $('#' + 'btnRefresh');
    var $unoLeadBucketDataTable = {};
    var $unoLeadBucket = $('#' + 'tblUnoLeadBucket');
    var $modal = $('#' + 'unoLeadModal');
    var $modalMessage = $('.' + 'modalMessage');
    var globalFunctionObject;
    var $genericErrorMessage = "Unexpected Error Occured. Please try later.";

    //Init DataTable
    function InitDataTable() {
        $unoLeadBucketDataTable = $unoLeadBucket.DataTable({
            scrollX: false,
            scrollY: true,
            scrollCollapse: true,
            paging: true,
            order: [[0, 'asc']],
            searching: true,
            info: false,
            fnDrawCallback: BindLeadActions,
            autoWidth: true,
            responsive: true,
            language: {
                emptyTable: "No data available",
                processing: "<div class='overlay custom-loader-background'><i class='fa fa-cog fa-spin custom-loader-color'></i></div>"
            },
            columns: [
                {
                    title: "UNO_Lead_Number_Bucket_ID",
                    data: "UN_LD_BUK_ID",
                    width: "0%",
                    visible: false
                },
                {
                    title: "Lead Number",
                    data: "UN_LD_NO",
                    width: "5%"
                },
                {
                    title: "Applicant Name",
                    data: "UN_APPL_NAME",
                    width: "20%"
                },
                {
                    title: "Phone Number",
                    data: "UN_MOB_NO",
                    width: "10%"
                },
                {
                    title: "Branch",
                    data: "UN_BR_NAME",
                    width: "10%",
                },
                {
                    title: "Product",
                    data: "UN_PROD_DESC",
                    width: "11%"
                },
                {
                    title: "Receipt Number",
                    data: "UN_RECPT_NO",
                    width: "10%"
                },
                {
                    title: "Receipt Type",
                    data: "UN_RECPT_TYPE",
                    width: "7%"
                },
                {
                    title: "Receipt Amount",
                    data: "UN_RECPT_AMT",
                    width: "10%"
                },
                {
                    title: "Lead Status",
                    data: null,
                    render: function (data) {
                        let status = "";
                        if (data.UN_RTS_PROC_STAT == 1) {
                            status = "<p class=text-info>Not Started</p>";
                        } else if (data.UN_RTS_PROC_STAT == 2) {
                            status = "<p class=text-warning>In progress</p>";
                        }
                        else if (data.UN_RTS_PROC_STAT == 3) {
                            status = "<p class=text-success>Completed</p>";
                        }
                        return status;
                    },
                    width: "10%"
                },
                {
                    title: "Action",
                    data: null,
                    render: function (data) {

                        let button = '';
                        button = RenderDataTableActionButton(data);
                        return button;
                    },
                    width: "7%"
                }
            ]
        });

        //$unoLeadBucket.on('order.dt', function () { BindLeadActions(); }); //SORT Event Listener
        //$unoLeadBucket.on('page.dt', function () { BindLeadActions(); }); //PAGING Event Listener
        //$unoLeadBucket.on('search.dt', function () { BindLeadActions(); }); //SEARCH Event Listener
    }

    function RenderDataTableActionButton(rowData) {

        let btnText, jsClass, cssClass, attrClass, unoLeadId, unoLeadNo, button = '';
        cssClass = "btn btn-block";

        if (rowData.UN_RTS_PROC_STAT == 2) {
            btnText = 'Unlock';
            jsClass = "js-unlockLead";
            cssClass = cssClass + " btn-primary";
            attrClass = jsClass + " " + cssClass;
            button = '<button type=button class="' + attrClass + '">' + btnText + '</button>';
            return button;

        }
    }

    function RenderUnoLeadBucketDataTable(unoLeadBucketDo) {
        if ($unoLeadBucketDataTable !== null && $unoLeadBucketDataTable !== undefined) {
            $unoLeadBucketDataTable.clear().draw();
            $unoLeadBucketDataTable.rows.add(unoLeadBucketDo.UnoLeadBucket);
            $unoLeadBucketDataTable.columns.adjust().draw();
        }
    }

    function BindLeadActions() {

        let $btnGrpUnlockLead = $('.' + 'js-unlockLead');

        $btnGrpUnlockLead.off('click').on('click', function () {
            let $divUnlockLead = $(this).parents('.js-UnlockDiv');
            let $currRow = $(this).parents('tr');
            UnlockUnoLead($currRow, $divUnlockLead);
        });
    }

    function UnlockUnoLead($currRow, $divUnlockLead) {
        let $currDataRow = {
        };

        if ($currRow !== null && $currRow !== undefined && $divUnlockLead !== null && $divUnlockLead !== undefined) {
            $currDataRow = $unoLeadBucketDataTable.row($currRow).data();

            if ($currDataRow !== null && $currDataRow !== undefined) {
                $unoLeadDo.UN_LD_BUK_ID = $currDataRow.UN_LD_BUK_ID;
                $unoLeadDo.UN_LD_NO = $currDataRow.UN_LD_NO;
                //console.log($unoLeadDo);

                let $data = {
                    'UnoLeadDo': $unoLeadDo
                };

                return $.ajax({
                    url: "Unlock_Uno_Leads.aspx/UnlockUnoLeadAdmin",
                    contentType: "application/json;charset=utf-8",
                    type: "POST",
                    dataType: "json",
                    data: JSON.stringify($data)
                })
                .done(function (response) {
                    if (response !== null
                        && response !== undefined
                        && response.d !== null
                        && response.d !== undefined) {

                        let $unoLeadDo = response.d;
                        if ($unoLeadDo.Status) {
                            $modalMessage.text($unoLeadDo.Message);
                            ToggleModal($show);
                            InitPageLoad();
                        } else {
                            if ($unoLeadDo.ErrorSeverity == $errorSeverity.Fatal) { $currErrSeverity = $errorSeverity.Fatal; }
                            $modalMessage.text($unoLeadDo.Message);
                            ToggleModal($show);
                        }
                    }
                })
                .fail(function (error) {
                    //console.log("Failure : UnlockUnoLead " + error);
                    //Dirty-fix to bypass CSRF issue
                    if (error.statusText == 'Unauthorized' && error.status == '401') {
                        $modalMessage.text('Lead No : ' + $currDataRow.UN_LD_NO + ' has been unlocked successfully');
                    }
                    $modalMessage.text($unoLeadDo.Message);
                    ToggleModal($show);
                });
            }
        }
    }

    function GetUnoLockedLeads() {
        return $.ajax({
            url: "Unlock_Uno_Leads.aspx/GetUnoLeads",
            contentType: "application/json;charset=utf-8",
            type: "GET",
            dataType: "json"
        })
            .done(function (data) {
                if (data !== null && data !== undefined && data.d !== null && data.d !== undefined) {
                    let $unoLeadBucketDo = data.d;
                    if (($unoLeadBucketDo.Status) && ($unoLeadBucketDo.RecordCount > 0)) {
                        console.log('Locked Lead Count :' + $unoLeadBucketDo.RecordCount);
                        $userId = $unoLeadBucketDo.UserId;
                        RenderUnoLeadBucketDataTable($unoLeadBucketDo);
                    } else {
                        if ($unoLeadBucketDo.ErrorSeverity == $errorSeverity.Fatal) { $currErrSeverity = $errorSeverity.Fatal; }

                        if ($unoLeadBucketDo.Message !== null || $unoLeadBucketDo.Message !== "") { $modalMessage.text($unoLeadBucketDo.Message); }
                        else { $modalMessage.text($genericErrorMessage); }

                        ToggleModal($show);
                    }
                }
            })
            .fail(function (msg) {
                console.log('FAIL - GetUnoLockedLeads');
                console.log(msg);
            });
    }

    function SetUnlockedUnoLeadData($currRow, $divUnlockLead, $unoLeadDo) {
        let $unlockedDataRow = {
        };

        if ($divUnlockLead !== null && $divUnlockLead !== undefined && $currRow !== null && $currRow !== undefined) {

            if ($unoLeadDo !== null && $unoLeadDo !== undefined) {

                if ($unoLeadDo.UN_RTS_PROC_STAT == 1) {

                    let $leadStatus = $currRow.find('.text-warning');
                    $leadStatus.attr('class', 'text-info');
                    $leadStatus.text('Not Started');

                    let $cssClass = "js-pickLead btn btn-lg btn-block btn-info";

                    let $actionButton = $('<button type=button></button>');
                    $actionButton.attr('class', $cssClass);
                    $actionButton.text('Pick');

                    $divUnlockLead.replaceWith($actionButton);
                    BindLeadActions();
                }
            }
        }
    }

    function InitModal() {
        $modal.modal({ show: false });
    }

    function ToggleModal(flag) {

        if ($modal !== null && (typeof $modal !== typeof undefined) && $modal !== false) {

            if (flag === null || flag === undefined) {
                if ($modal.hasClass($show)) {
                    $modal.removeClass($show);
                    $modal.addClass($hide);
                } else if ($modal.hasClass($hide)) {
                    $modal.removeClass($hide);
                    $modal.addClass($show);
                }
            }
            else {
                if (flag == $show) {
                    $modal.modal({ show: true });
                }
                else if (flag == $hide) {
                    $modal.modal({ show: false });
                }
            }
        }
    }

    function InitPageLoad() {
        GetUnoLockedLeads().then(BindLeadActions);
    }

    $refreshButton.off('click').on('click', InitPageLoad);

    InitModal();
    InitDataTable();
    InitPageLoad();
});