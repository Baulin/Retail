


function CheckRadiant_View() {

    var area = document.getElementById('MainContent_ddlst_Area');
    var branch = document.getElementById('MainContent_ddlst_Branch');
    var lnno = document.getElementById('MainContent_txtbx_ln_no');
    var ctype = document.getElementById('MainContent_ddlst_collection_type');

    if (area.options[area.selectedIndex].text == "--Select--") {
        alert('Please select the area');
        area.focus();
        return false;
    }
    if (branch.options[branch.selectedIndex].text == "--Select--") {
        alert('Please select the branch');
        branch.focus();
        return false;

    }
    //Saravanan 18/08/2015
    if (ctype.options[ctype.selectedIndex].text == "---Select---") {
        alert('Please select the type');
        ctype.focus();
        return false;
    }
    //Saravanan 18/08/2015
    if (lnno.value.trim() == "") {
        if (ctype.options[ctype.selectedIndex].value == "C") {
            alert('Please enter the agreement number');
            lnno.focus();
            return false;
        }
        else if (ctype.options[ctype.selectedIndex].value == "I") {
            alert('Please enter the sanction number');
            lnno.focus();
            return false;
        }
    }

    return true;

}

function CheckRadiant_Submit() {
    //debugger;
    var txtlnno = document.getElementById('MainContent_txtbx_ln_sanc_no');
    var ctype = document.getElementById('MainContent_ddlst_collection_type');
    var lnno = document.getElementById('MainContent_txtbx_ln_no');

    var cltype = document.getElementById('MainContent_ddlst_coll_type');
    var dtype = document.getElementById('MainContent_ddlst_deposit_type');
    var rcno = document.getElementById('MainContent_txtbx_rcno');
    var amt = document.getElementById('MainContent_txtbx_rcamt');

    var selamt = document.getElementById('MainContent_txtMbl_Recipt_Total');    
    
    if (ctype.options[ctype.selectedIndex].value == "I") {
        if (txtlnno.value.trim() == "") {
            alert('Please retrieve the sanction details');
            lnno.focus();
            return false;
        }
    }
    if (ctype.options[ctype.selectedIndex].value == "C"){
        if (selamt.value == "" || selamt.value == "0") {
            alert('Please select atleast one row');
            return false;
        }
    }
    if (ctype.options[ctype.selectedIndex].value == "I") {
        if (cltype.options[cltype.selectedIndex].text == "--Select--") {
            alert('Please select the collection type');
            cltype.focus();
            return false;
        }
    }
    if (dtype.options[dtype.selectedIndex].text == "--Select--") {

        alert('Please select the deposit type');
        dtype.focus();
        return false;
    }
    if (dtype.options[dtype.selectedIndex].text == "--Select--") {

        alert('Please select the deposit type');
        dtype.focus();
        return false;
    }
    if (dtype.options[dtype.selectedIndex].text != "--Select--") {

        var splitvalue = dtype.options[dtype.selectedIndex].value.split("|");

        if (splitvalue != null || splitvalue[1].trim() == "") {

            if (splitvalue[1] == 'Y' && rcno.value.trim() == "") {
                alert('Please enter the receipt number');
                rcno.focus();
                return false;
            }
        }
    }   

    if (amt.value == "") {
        alert('Please enter the amount');
        amt.focus();
        return false;
    }    

    if (ctype.options[ctype.selectedIndex].value == "C") {
        if (amt.value != "" && selamt.value != "") {
            var amtp = Number(selamt.value) + Number(10);
            var amtm = Number(selamt.value) - Number(10);
            if (amt.value <= amtp && amt.value >= amtm) {
                
            }
            else
            {
                if (amt.value != selamt.value) {
                    alert('The Amount and the Mobile recipt amout are not matched');
                    amt.focus();
                    return false;
                }
            }
        }
    }    
    if (ctype.options[ctype.selectedIndex].value == "C" && dtype.options[dtype.selectedIndex].value == "1|Y") {
        var fileupload = document.getElementById('fup_Challon');
        var hasFile = fileupload.value;
        if (hasFile == '') {
            alert('Please Upload the challon');
            fileupload.focus();
            return false;
        }
        else {

        }
    }
    if (ctype.options[ctype.selectedIndex].value == "C" && dtype.options[dtype.selectedIndex].text == "DIRECT") {
        var bankName = document.getElementById('MainContent_txtDepositedBank');
        if (bankName.value == "") {
            alert('Please enter the Bank name');
            bankName.focus();
            return false;
        }
    }
    return CheckConfirm();
}

function CheckConfirm(result) {    
    var cltype = document.getElementById('MainContent_ddlst_coll_type');
    var dtype = document.getElementById('MainContent_ddlst_deposit_type');
    var rcno = document.getElementById('MainContent_txtbx_rcno');
    var amt = document.getElementById('MainContent_txtbx_rcamt');
    var txtlnno = document.getElementById('MainContent_txtbx_ln_sanc_no');
    var ctype = document.getElementById('MainContent_ddlst_collection_type');
    var product = document.getElementById('MainContent_txtbx_product');
    var rno = rcno.value.toUpperCase().trim() != "" ? rcno.value.toUpperCase() : "NIL";
    if (ctype.options[ctype.selectedIndex].value == "I") {
        if (confirm("Sanction Number: " + txtlnno.value.toUpperCase() + "\r\nReceipt No: " + rno + "\r\nProduct     : " + product.value.toUpperCase() + " \r\nAmount    : " + amt.value + "\r\nPlease Confirm to Proceed...") == true)
            return true;
        else return false;
    }
}
//Saravanan 18/08/2015
//function CheckHasFile() {
//    var fileupload = document.getElementById('MainContent_fup_Challon');
//    var hasFile = fileupload.value;
//    if (hasFile == '') {
//        alert('Please Upload the challon');
//        fileupload.focus();
//        return false;
//    }
//    return true;
//}
//Saravanan 18/08/2015


