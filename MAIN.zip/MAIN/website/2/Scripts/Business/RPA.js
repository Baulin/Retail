function CheckFirstBlock() {
    var ddlstleadno = document.getElementById('MainContent_ddlstleadno');

    var ddlstproptype = document.getElementById('MainContent_ddlstpropertytype');

    var propowner = document.getElementById('MainContent_txtbxpropertyowner');

    var propaddr = document.getElementById('MainContent_txtbxpropertyaddr');


    if (ddlstleadno.selectedIndex == 0) {
        alert('Please select the lead number');
        ddlstleadno.focus();
        return false;


    }

    if (propowner.value == "") {

        alert('Please enter the property owners name');

        propowner.focus();

        return false;
    }

    if (propaddr.value == "") {
        alert('Please enter the property address');
        propaddr.focus();
        return false;
    }

    if (ddlstproptype.selectedIndex == 0) {
        alert('Please select the property type');
        ddlstproptype.focus();
        return false;
    }




    var landglval = document.getElementById('MainContent_txtbxlandgval');

    var landmlval = document.getElementById('MainContent_txtbxmarketvalue');

    var landarea = document.getElementById('MainContent_txtbxlandarea');

    var totlandval = document.getElementById('MainContent_txtbxlandvalue');

    if (landglval.value == "") {
        alert('Please enter the land guideline value');
        landglval.focus();
        return false;
    }
    if (landmlval.value == "") {
        alert('Please enter the land market value');
        landmlval.focus();
        return false;
    }

    if (landarea.value == "") {
        alert('Please enter the land area');
        landarea.focus();
        return false;
    }
    return true;
}
function CalculateTotalLandValue() {

    var landglval = document.getElementById('MainContent_txtbxlandgval');

    var landmlval = document.getElementById('MainContent_txtbxmarketvalue');

    var landarea = document.getElementById('MainContent_txtbxlandarea');

    var totlandval = document.getElementById('MainContent_txtbxlandvalue');
    var tothf = document.getElementById('MainContent_hflandval');


    if (!isNaN(landmlval.value)) {

        if (!isNaN(landarea.value)) {
            totlandval.value = (landmlval.value * landarea.value).toFixed(2).toString();
            tothf.value = totlandval.value;
        }
        else {
            alert('Only numeric value can be allowed');
            landarea.focus();
            return false;
        }
    }
    else {
        alert('Only numeric value can be allowed');
        landmlval.focus();
        return false;
    }



    return true;
}

function CheckPropertyObservation() {



    var identify = document.getElementsByName("ctl00$MainContent$IDENTIFY");
    var develop = document.getElementsByName("ctl00$MainContent$DEVELOP");
    var residential = document.getElementsByName("ctl00$MainContent$RESIDENTIAL");
    var unapproved = document.getElementsByName("ctl00$MainContent$UNAPPROVED");

    if (!identify[0].checked && !identify[1].checked) {
        alert('Please check the plot clearly able to identify');
        document.getElementById('MainContent_pnlidentify').focus();
        return false;
    }
    if (!develop[0].checked && !develop[1].checked) {
        alert('Please check the plot situated in well developed area');
        document.getElementById('MainContent_pnldevelop').focus();
        return false;
    }
    if (!residential[0].checked && !residential[1].checked) {
        alert('Please check the plot surrounded with residences');
        document.getElementById('MainContent_pnlresidential').focus();
        return false;
    }
    if (!unapproved[0].checked && !unapproved[1].checked && !unapproved[2].checked) {
        alert('Please check the plot is unapproved or govern properyty');
        document.getElementById('MainContent_pnlunapproved').focus();
        return false;
    }

     return true;
 }
                


            
function CheckVisit() {

    var visitby = document.getElementById('MainContent_ddlstsitevisitedby');

    var visitdate = document.getElementById('MainContent_txbxdateofvisit');

    var totldval = document.getElementById('MainContent_txtbxlandvalue');

    if (visitby.selectedIndex == 0) {
        alert('Please Select Visited By');
        visitby.focus();
        return false;
    }
    if (visitdate.value == "") {
        alert('Please Select the visited date');
        visitdate.focus();
        return false;
    }
    return true;
}

function FinalCheck() {
    if (CheckFirstBlock()) {
        if (CalculateTotalLandValue()) {
            if (CheckPropertyObservation()) {

                return CheckThirdBlock();
            } else return false;
        }
        else return false;
    }
    else return false;
    return true;
}

function IntermediateCheck() {
    if (CheckFirstBlock()) {
        if (CalculateTotalLandValue()) {
            return true;
        }
        else return false;
    }
    else return false;

    return true;
}
function CheckThirdBlock() {

    var refname = document.getElementById('MainContent_txtbxref1name');
    var refaddr = document.getElementById('MainContent_txtbxref1addr');
    var refcontact = document.getElementById('MainContent_txtbxref1contactno');
    var reffback = document.getElementById('MainContent_txtbxref1feedback');

    var ref1name = document.getElementById('MainContent_txtbxref2name');
    var ref1addr = document.getElementById('MainContent_txtbxref2addr');
    var ref1contact = document.getElementById('MainContent_txtbxref2contactno');
    var ref1fback = document.getElementById('MainContent_txtbxref2feedback');

    var visitby = document.getElementById('MainContent_ddlstsitevisitedby');

    var visitdate = document.getElementById('MainContent_txbxdateofvisit');

    if (refname.value == "") {
        alert('Please enter the reference 1 name');
        refname.focus();
        return false;
    }
    if (refaddr.value == "") {
        alert('Please enter the reference 1 address');
        refaddr.focus();
        return false;
    }
    if (refcontact.value == "") {
        alert('Please enter the reference 1 contact number');
        refcontact.focus();
        return false;
    }
    if (reffback.value == "") {
        alert('please enter the reference 1 feedback');
        reffback.focus();
        return false;
    }
    if (ref1name.value == "") {
        alert('Please enter the reference 2 name');
        ref1name.focus();
        return false;
    }
    if (ref1addr.value == "") {
        alert('Please enter the reference 2 address');
        ref1addr.focus();
        return false;
    }
    if (ref1contact.value == "") {
        alert('Please enter the reference 2 contact number');
        ref1contact.focus();
        return false;
    }
    if (ref1fback.value == "") {
        alert('please enter the reference 2 feedback');
        ref1fback.focus();
        return false;
    }
    if (visitby.selectedIndex == 0) {
        alert('Please Select Visited By');
        visitby.focus();
        return false;
    }
    if (visitdate.value == "") {
        alert('Please Select the visited date');
        visitdate.focus();
        return false;
    }
    return true;
}
function ToUpperValRPA() {

    var propowner = document.getElementById('MainContent_txtbxpropertyowner').value;
    var propaddr = document.getElementById('MainContent_txtbxpropertyaddr').value;
    var ref1name = document.getElementById('MainContent_txtbxref1name').value;
    var ref1addr = document.getElementById('MainContent_txtbxref1addr').value;
    var ref1contact = document.getElementById('MainContent_txtbxref1contactno').value;
    var ref1fback = document.getElementById('MainContent_txtbxref1feedback').value;
    var ref2name = document.getElementById('MainContent_txtbxref2name').value;
    var ref2addr = document.getElementById('MainContent_txtbxref2addr').value;
    var ref2contact = document.getElementById('MainContent_txtbxref2contactno').value;
    var ref2fback = document.getElementById('MainContent_txtbxref2feedback').value;

    document.getElementById('MainContent_txtbxpropertyowner').value = propowner.toUpperCase().toString();
    document.getElementById('MainContent_txtbxpropertyaddr').value = propaddr.toUpperCase().toString();
    document.getElementById('MainContent_txtbxref1name').value = ref1name.toUpperCase().toString();
    document.getElementById('MainContent_txtbxref1addr').value = ref1addr.toUpperCase().toString();
    document.getElementById('MainContent_txtbxref1contactno').value = ref1contact.toUpperCase().toString();
    document.getElementById('MainContent_txtbxref1feedback').value = ref1fback.toUpperCase().toString();
    document.getElementById('MainContent_txtbxref2name').value = ref2name.toUpperCase().toString();
    document.getElementById('MainContent_txtbxref2addr').value = ref2addr.toUpperCase().toString();
    document.getElementById('MainContent_txtbxref2contactno').value = ref2contact.toUpperCase().toString();
    document.getElementById('MainContent_txtbxref2feedback').value = ref2fback.toUpperCase().toString();
}
